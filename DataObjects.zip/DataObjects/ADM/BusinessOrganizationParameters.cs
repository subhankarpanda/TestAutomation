﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FASTSelenium.DataObjects.ADM
{
    public class BusinessOrganizationParameters
    {
        public string IDCode = "";
        public bool newAddress = false;
        public string EntityType = "";
        public string Name1 = "";
        public string Name2 = "";
        public string LocDescription = "";
        public string TaxIdNumber = "";
        public string TitleOfficer = "";
        public string EscrowOfficer = "";
        public string SalesRep1 = "";
        public string Comments = "";
        public string Addresstype = "";
        public string AddressLine1 = "";
        public string AddressLine2 = "";
        public string AddressLine3 = "";
        public string AddressLine4 = "";
        public string City = "";
        public string State = "";
        public string Zip = "";
        public string County = "";
        public string OrgName1 = "";
        public string OrgName2 = "";
        public string PersonName = "";
        public string ABANumber = "";
        public string BankName = "";
        public string BankAddress = "";
        public string AccountNumber = "";
        public string Country = "";
        public string BuyerSellerType = "";
        public String SalesRep2 = "";
        public string BusinessEmail = "";
        public string BusinessPhone = "";
    }
}
