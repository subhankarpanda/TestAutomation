﻿
namespace FASTSelenium.DataObjects.ADM
{
    public class EmployeeSearchParameters
    {
        public string UserName = "";
        public string LoginName = "";
        public string FirstName = "";
        public string LastName = "";
        public string Region = "";
        public string Office = "";
    }
}
