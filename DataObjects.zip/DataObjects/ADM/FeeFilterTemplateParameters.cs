﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.ADM
{
    public class FeeFilterTemplateParameters
    {
        public bool Title = true;
        public bool Escrow = true;
        public bool SubEscrow = true;
        public bool SelectAll = true;
        public string TransactionType = "All";
        public string BusinessSegment = "All";
        public string Product = "All";
        public string ProgramType = "All";
        public string PropertyType = "All";
        public string UnderWriter = "All";
        public string SearchType = "All";

    }
}
