﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FASTSelenium.Common;

namespace FASTSelenium.DataObjects.ADM
{
    public class FeeSetupParameters
    {
        public string FormType = "CD";
        public string FeeCode = "";
        public string FeeType = "";
        public string GeographicType = "";
        public string FeeStatus = "Active";
        public string GLCode = "";
        public string DefaultChargeAmount = "";
        public string DefaultChargeTo = "Both";
        public string FeeDistribution = "Title";
        public string RecipientType = "";
        public string FeeOwningOfficeType = "Title Owning Office";
        public bool ThirdPartyPayee = false;
        public string ThirdPartyPayeeNameDefault = "";

        public string Description = "";
        public string LoanEstimateDescription = "";
        public bool DescriptionEditable = false;
        public bool SubjectToSalesTax = false;
        public bool CompanyIncomeFee = false;
        public bool OfficeIncomeFee = false;
        public bool TitleOfficeFee = false;
        public bool EscrowOfficeFee = false;
        public bool SalesRepFee = false;
        public bool SplitwithFAOffice = false;
        public bool SubjectToStateAssignment = false;
        public bool SubjectToCalculation = false;
        public bool SubjectToPromulgatedRate = false;

        public string BuyerSection = "B,C,H";
        public string SellerSection = "B,C,H";
        public ClosingDisclosureSection Section = ClosingDisclosureSection.B;
        public bool LenderAffiliate = false;
        public string FeeFilterName = "";        
        public string DefaultPaymentCategory = "Paid at Closing";
        public string Method = "Fee";
        public string MISMOCategory = "Fee Item";
        public string MISMOType = "203K Architectural And Engineering Fee";

    }

    public class FeesetupParameters_gfv
     {

        public string FeeDesc = null;
        public string FeeType = "Escrow Fee";
        public string LoanEstimatedesc = null;
        public bool DescEdit = false;
        public bool thirdPartyPayee= false;
        public string thirdPPayeeName = "";
        public string bSection = "B";
        public string blineno = null; 
        public string sSection= "B";
        public string slineno= null;
        public bool SubjectToSalesTax = false;
        public string DefaultChargeAmtfrom = null;
        public string DefaultChargeAmtTo = null; 
        public string FeeFilterName = null;
        public string DefaultPaymentMethod = null; 
        public string GLCode = "744 Abandon";
        public string FeeDistribution = "Title";
        public string FeeOwnigOfficeType = "Title Owning Office";
        public string DefaultPaymentCategory = "Paid at Closing";
        public ClosingDisclosureSection section = ClosingDisclosureSection.A;
        public bool SubjectToCalculation = false;
        public bool LenderAffliate = false;
        public string Geographictype = "";
    }
}
