﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.ADM
{
   public class LicenseInfoParameters
    {
        public string LicenseId = string.Empty;
        public string LicenseState = string.Empty;
        public string LicenseCounty = string.Empty;
        public string LicenseType = string.Empty;
        public string LicenseStatus = string.Empty;
    }
}
