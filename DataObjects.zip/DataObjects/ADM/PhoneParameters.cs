﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.ADM
{
    public class PhoneParameters
    {
        public string BusinessPhoneNumber = string.Empty;
        public string BusinessPhoneExtn = string.Empty;
        public string BusinessFaxNumber = string.Empty;
        public string BusinessFaxExtn = string.Empty;
        public string Email = string.Empty;
        public string PagerNumber = string.Empty;
        public string PagerExtn = string.Empty;
        public string CellularNumber = string.Empty;
        public string CellularExtn = string.Empty;
        public string HomephoneNumber = string.Empty;
        public string HomephoneExtn = string.Empty;
        public string HomeFaxNumber = string.Empty;
        public string HomeFaxExtn = string.Empty;
    }
}


