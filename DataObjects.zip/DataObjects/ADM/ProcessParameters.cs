﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.ADM
{
   public class ProcessParameters
    {
       public string ProcessName = string.Empty;
       public string ProcessType = string.Empty;
       public string TranType = string.Empty;
       public string State = string.Empty;
       public string County = string.Empty;
       public string ProcessEvent = string.Empty;
       public string[] Tasks = null;
    }
}


    