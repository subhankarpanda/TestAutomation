﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.ADM
{
    public class RoleSetupParameters
    {
        public string RoleName;
        public RoleSecurityLevel SecurityLevel = RoleSecurityLevel.Region;
        public string ActivityGroup ;
        public List<string> AvailableActivityRights = new List<string>();
       

        public static RoleSetupParameters GetInstance() {
            return new RoleSetupParameters();
        }
    }

    public enum RoleSecurityLevel{
        Corporate, Region, Office
    }
}
