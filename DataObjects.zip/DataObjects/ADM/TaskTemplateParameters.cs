﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.ADM
{
    public class TaskTemplateParameters
    {
        public string TaskName = string.Empty;
        public string TaskCategory = string.Empty;
        public string MessageTemplate = string.Empty;
        public string[] FBPRoles = null;
        public string TaskStatus = string.Empty;
        public string DeliveryMethod = string.Empty;
        public string SubjectLine = string.Empty;
        public string EmailName1 = string.Empty;
        public string EmailAddress1 = string.Empty;
        public string EmailName2 = string.Empty;
        public string EmailAddress2 = string.Empty;
        public string[] Senders = null;
        public bool IsDesignatedSender = false;
        public string DesignatedSenderName = string.Empty;
        public string DesignatedSenderEmail = string.Empty;
        public string DueTypeForFirstTask = "";
        public string WarnMin = "";
        public string DueMin = "";
        public bool PublicTask = false;
    }
}
