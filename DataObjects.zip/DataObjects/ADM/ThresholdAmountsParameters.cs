﻿namespace FASTSelenium.DataObjects.ADM
{
    public struct ThresholdAmountsParameters
    {
        public string Residential;
        public string Commercial;
        public string NewHomeSubdivision;
        public string NewHome;
        public string Subdivision;
        public string Default;
        public string TimeShare;
        public string DefaultResidential;
        public string DefaultCommercial;
    }
}
