﻿
namespace FASTSelenium.DataObjects.ADM
{
    public struct TrackChangesDialogParameters
    {
        public string TrackNo;
        public string UserNotes;
    }
}
