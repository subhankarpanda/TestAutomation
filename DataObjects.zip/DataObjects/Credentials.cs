﻿namespace FASTSelenium.DataObjects
{
    public struct Credentials
    {
        public string UserName;
        public string Password;
    }
}
