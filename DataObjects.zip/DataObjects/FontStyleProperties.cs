﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.Common;

namespace FASTSelenium.DataObjects
{
    public class FontStyleProperties
    {
        public FontStyleProperties(IWebElement element)
        {
            IsBold = setIsBold(element);
              //... complete initialization
        }

        public bool IsBold { get; set; }
        public bool IsItalics { get { throw new NotImplementedException("FontStyleProperties.IsItalics is not implemented."); } set {  } }
        public bool IsUnderlined { get { throw new NotImplementedException("FontStyleProperties.IsUnderlined is not implemented."); } set { } }
        public bool Height { get { throw new NotImplementedException("FontStyleProperties.Height is not implemented."); } set { } }


        private bool setIsBold(IWebElement element)
        {
            try
            {
                if (element.FAGetCSSValue("font-weight") == "700")
                    return true;
            
                return element.FindElement(By.TagName("b")).IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}