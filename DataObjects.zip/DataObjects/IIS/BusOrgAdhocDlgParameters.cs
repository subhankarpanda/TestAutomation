﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public struct BusOrgAdhocDlgParameters
    {
        public string EntityType;
        public string Name1;
        public string Name2;
        
        public string AddrLine1;
        public string AddrLine2;
        public string AddrLine3;
        public string AddrLine4;
        public string City;
        public string State;
        public string Zip;
        public string County;
        public string Country;

        public string BusPhone;
        public string BusFax;
        public string CellPhone;
        public string Pager;
        public string Email;

    }

    public struct EWFmuc0070
    {
        //Error Warning Messages
        public static string EWWhenNoEntity = "Entity Type Required!";
        public static string EWWhenNoName = "Name is Required";
        public static string EWWhenInvalidData = "Please correct invalid data entered.";
        public static string EntityTypeREBAMiscDisb = "Miscellaneous";
        public static string EntityTypeREBASeller = "Real Estate Broker";
        public static string EntityTypeREBAOther = "Real Estate Broker";
    }

}
