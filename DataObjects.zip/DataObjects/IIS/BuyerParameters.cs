﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public struct BuyerParameters
    {
        // Buyer Details
        public string BuyerType;
        public string EmployedBy;
        public string First;
        public string Middle;
        public string Last;
        public string Suffix;
        public string SSN;
        public bool LoanApplicant;

        //Husband Wife
        public string Husband1FirstName;
        public string HusbandFirstName;
        public string Husband1MiddleName;
        public string Husband2LastName;
        public string HusbandLastName;
        public string HusbandSpouse1SSN;
        public string HusbandSuffix;
        public bool Spouse1LoanApplicant;

        public string HusbandSpouseFirstName;
        public string HusbandSpouseMiddleName;
        public string HusbandSpouseLastName;
        public string HusbandSpouseSuffix;
        public string HusbandSpouse2SSN;
        public bool Spouse2LoanApplicant;

        public string HusbAuthzSigNam;
        public string HusbSpus1TrstType;

        public string HusSpous2TrusteNam;
        public string HusSpous2TrusteTyp;
        
        

        // Truste Estate
        public string TrusteeShortNameTwo;
        public string TrusteeName;

        public string TrustAuthorizedType;
        public string TrustTitle;
        public string TrustDated;
        public string TrustNumber;
        public bool TrustTin;
        public string TrustSsnText;
        public string TrustAuthorizedName;

        //Business Entity
        public string BusinessEntityShortname;
        public string BusinessEntitySsn;
        public bool BusinessTin;
        public string StateofIncorp;
        public string EntityType;


        // Vesting Information
        public string MaritalStatus;
        public string Vesting;
        public string AdditionalVesting;

        // Salutation and Miscellaneous Reference
        public string Salutation;
        public string MiscReference1;
        public string MiscReference2;

        // Current Phones
        public string CurrentPhoneNumber;
        public string CurrentPhoneTwo;
        public string CurrentPhoneThree;
        public string CurrentPhoneFour;
        public string CurrentPhoneFive;
        public string CurrentPhoneSix;
        public string CurrentPhoneSeven;
        public string CurrentPhoneType;

        //Extension
        public string CurrentPhExtn;
        public string CurrentPhTwoExtn;
        public string CurrentPhThreeExtn;
        public string CurrentPhFourExtn;
        public string CurrentPhFiveExtn;
        public string CurrentPhSixExtn;
        public string CurrentPhSevenExtn;
        

        // Forwarding Phones
        public string ForwardingPhoneNum;

        //Individual 
        public string IndivdAuthorzdNam;
        public string IndivdAthorzdType;

        //Current Address
        public string CurrentStreet1;
        public string CurrentStreet2;
        public string CurrentStreet3;
        public string CurrentStreet4;
        public string CurrentCity;
        public string CurrentState;
        public string CurrentCounty;
        public string CurrentZip;
        public bool CurrentSetToOthr;
        public bool CurrentSetToProperty;
        public string CurrentCountry;

        //Forward Address
        public string ForwardStreet1;
        public string ForwardStreet2;
        public string ForwardStreet3;
        public string ForwardStreet4;
        public string ForwardCity;
        public string ForwardState;
        public bool ForwardSetToOthr;
        public string ForwardCounty;
        public string ForwardCountry;
        public string ForwardZip;

    }

}
