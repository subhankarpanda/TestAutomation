﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class BuyerVestingParameters
    {
        public string Names="";
        public string CompleteVesting="";
    }
}
