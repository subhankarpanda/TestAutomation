﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public struct BuyrSellrEntySignParameters
    {
        public string NameofEntity;
        public string StateOfIncorp;
        public string EntityType;

        //Auth Signatures section
        public string AuthSignsNameOne;
        public string AuthSignsCorpTitleOne;

        //By Entities Summary  >>Name Of Entity
        public string ByNameOfEntity;
        public string ByStateOfIncorp;
        public string ByEntityType;
        public string ByContactName;
        
        //By Entity Auth Sign Section
        public string ByEntyAuthSignName ;
        public string ByEntyAuthSignTitlCorp;
        
    }
}



























