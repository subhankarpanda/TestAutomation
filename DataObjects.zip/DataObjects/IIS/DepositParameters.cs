﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class DepositParameters
    {
        public double Amount = 0;
        public string TypeofFunds = "";
        public string Representing = "";
        public string Description = "";
        public string ReceivedFrom = "";
        public string DepositedTo = "";
        public string Payor = "";
        public bool CreditToSeller = false;
        public bool CreditToBuyer = false;
        public bool CreditToOther = false;
        public string Comments = "";

        public string CheckNumber = "";
        public string ABANumber = "";
        public string AccountNumber = "";
        public string BankName = "";

        public string WireBankName = "";
        public string ConfirmationNumber = "";
        public string BankContact = "";
        public string FedRoutingNumber = "";
        public string ConfirmationTime = "";
    }

    public class DepositOutsideEscrowParameters {

        public double TotalDeposit = 0;
        public string EarnerstMoneyHeldBy_0 = "";
        public string EarnerstMoneyName_0 = "";
        public double EarnerstMoneyAmount_0 = 0;
        public double ExcessDeposit = 0;
        public double DisbursedasProceeds = 0;
        public double Curefor0Tolerance_Amount = 0;
        public string Curefor10Tolerance_Amount = "";
        public string EarnerstMoneyHeldBy_1 = "";
        public double EarnerstMoneyAmount_1 = 0;
        public string EarnerstMoneyName_1 = "";
    
    
    }
}
