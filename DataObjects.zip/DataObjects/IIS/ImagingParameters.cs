﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public struct EWFIUC0001
    {
        public static string EW1 = "Do you wish to save the current file?";
    }
}
