﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class InvoiceHistoryParameters
    {
        public string InvoiceTo = string.Empty;
        public string CurrentStatus = string.Empty;
        public string Total = string.Empty;
        public string FirstEstimated = string.Empty;
        public string FirstFinalized = string.Empty;
        public string Description = string.Empty;
        public string Amount = string.Empty;
        public string SalesTax = string.Empty;
        public string Action = string.Empty;
        public string AdjustedOrCancelled = string.Empty;
    }
}
