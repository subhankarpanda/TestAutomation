﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class NewFileNoteParameters
    {
        public string NoteType = "";
        public string FontName = "";
        public string FontSize = "";
        public string NoteText = "";
    }
}
