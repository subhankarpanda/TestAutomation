﻿namespace FASTSelenium.DataObjects.IIS
{
    public class NewFileParameters
    {
        public string BusinessSourceAdditionalRole;
        public string BusinessSourceGABcode;
        public string BusinessSourceReference;
        public string DirectedBYGABcode;
        public bool Title;
        public bool Escrow;
        public bool SubEscrow;
        public string BusinessSegment;
        public string TransactionType;
        public string TermsDatesSalesPrice;
        public string PropertyInformationName;
        public string PropertyInformationType;
        public string PropertyInformationLot;
        public string PropertyInformationBlock;
        public string PropertyInformationUnit;
        public string PropertyPropTaxAPN1;
        public string PropertyPropTaxAPN2;
        public string PropertyBookAddrLin1;
        public string PropertyBookAddrLin2;
        public string PropertyBookAddrLin3;
        public string PropertyCity;
        public string PropertyState;
        public string PropertyCounty;
        public string PropertyZipCode;
        public string Buyer1Type;
        public string Buyer1FirstName;
        public string Buyer1LastName;
        public string Buyer1SpouseName;
        public string Buyer1SpouseLastName;
        public string Buyer2Type;
        public string Buyer2FirstName;
        public string Buyer2LastName;
        public string Buyer2SpouseName;
        public string Seller1Type;
        public string Seller1FirstName;
        public string Seller1LastName;
        public string Seller2Type;
        public string Seller2FirstName;
        public string Seller2LastName;
        public string Seller2SpouseFirstName;
        public string ServiceProgramType;
        public string NewLenderInformationGABcode;
        public string AssociatedBusinessPartyGABcode;
        public string NoteType;
        public string Notes;
        
        public static NewFileParameters GetDefaultParams(string gabcode = "HUDFLINSR1")
        {
            return new NewFileParameters { BusinessSourceGABcode = gabcode, BusinessSegment = "Residential", Title = true, Escrow = true, PropertyState = "CA", TransactionType = "Sale w/Mortgage" };
        }
    }
}
