﻿
namespace FASTSelenium.DataObjects.IIS
{
    public class NewLoanParameters
    {
        public string Type = "";
        public string Amount = "";
        public string GABCode = "";
        public string MortgageInsCase = "";
    }
}
