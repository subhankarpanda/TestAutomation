﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class PDD
    {
        #region attributes
        public string NewLoanTableId { get; set; }
        public string ChargeDescription { get; set; }
        public string PDDDescription { get; set; }
        public string AdditionalDescription { get; set; }
        public string LEDescription { get; set; }
        public bool SectionBdidnotShopFor { get; set; }
        public bool LenderAffiliate { get; set; }
        public bool SectionCDidShopFor { get; set; }
        public bool SectionHOtherCosts { get; set; }
        public bool UseDefaultModify { get; set; }
        public bool UseDefaultChecked { get; set; }
        public bool PartOfCheckbox { get; set; }
        public string PayTo { get; set; }
        public string  PayeeName { get; set; }
        public double? LoanEstimateUnrounded { get; set; }
        public double? LoanEstimateRounded { get; set; }
        public double? BuyerCharge { get; set; }
        public double? BuyerAtClosing { get; set; }
        public string BuyerChargePaymentMethod { get; set; }
        public double? BuyerBeforeClosing { get; set; }
        public double? BuyerPaidbyOther { get; set; }
        public string BuyerPaidbyOtherPaymentMethod { get; set; }
        public bool BuyerDoubleAsteriskChecked { get; set; }
        public bool BuyerLenderCheckbox { get; set; }
        public double? BuyerCredit { get; set; }
        public string BuyerCreditPaymentMethod { get; set; }
        public double? SellerCharge { get; set; }
        public double? SellerPaidAtClosing { get; set; }
        public string SellerChargePaymentMethod { get; set; }
        public double? SellerPaidBeforeClosing { get; set; }
        public double? SellerPaidbyOthers { get; set; }
        public string SellerPaidbyOtherPaymentMthd { get; set; }
        public bool SellerLenderCheckbox { get; set; }
        public double? SellerCredit { get; set; }
        public string SellerCreditPaymentMethod { get; set; }
        public double? TotalCharge { get; set; }
        public bool? isPrimaryPolicy;
        public string NoMonthsPrepaid;
        public string MonthPrepaidSelect;
        #endregion

        public PDD()
        {
            this.NewLoanTableId = null;
            this.ChargeDescription = null;
            this.PDDDescription = null;
            this.SectionBdidnotShopFor = false;
            this.LenderAffiliate = false;
            this.SectionCDidShopFor = false;
            this.SectionHOtherCosts = false;
            this.UseDefaultModify = false;
            this.UseDefaultChecked = false;
            this.PayTo = null;
            this.PayeeName = null;
            this.LoanEstimateUnrounded = null;
            this.LoanEstimateRounded = null;
            this.BuyerAtClosing = null;
            this.BuyerChargePaymentMethod = null;
            this.BuyerBeforeClosing = null;
            this.BuyerPaidbyOther = null;
            this.BuyerPaidbyOtherPaymentMethod = null;
            this.BuyerDoubleAsteriskChecked = false;
            this.BuyerCredit = null;
            this.BuyerCreditPaymentMethod = null;
            this.SellerPaidAtClosing = null;
            this.SellerChargePaymentMethod = null;
            this.SellerPaidBeforeClosing = null;
            this.SellerPaidbyOthers = null;
            this.SellerPaidbyOtherPaymentMthd = null;
            this.SellerCredit = null;
            this.SellerCreditPaymentMethod = null;
        }

        public PDD(string newLoanTableId, string chargeDescription, string pDDDescription, bool sectionBdidnotShopFor, bool lenderAffiliate, bool sectionCDidShopFor, bool sectionHOtherCosts, bool useDefaultModify, bool useDefaultChecked, string payTo, string payeeName, double? loanEstimateUnrounded, double? loanEstimateRounded, double? buyerAtClosing, string buyerChargePaymentMethod, double? buyerBeforeClosing, double? buyerPaidbyOther, string buyerPaidbyOtherPaymentMethod, bool buyerDoubleAsteriskChecked, double? buyerCredit, string buyerCreditPaymentMethod, double? sellerPaidAtClosing, string sellerChargePaymentMethod, double? sellerPaidBeforeClosing, double? sellerPaidbyOthers, string sellerPaidbyOtherPaymentMthd, double? sellerCredit, string sellerCreditPaymentMethod)
        {
            this.NewLoanTableId = newLoanTableId;
            this.ChargeDescription = chargeDescription;
            this.PDDDescription = pDDDescription;
            this.SectionBdidnotShopFor = sectionBdidnotShopFor;
            this.LenderAffiliate = lenderAffiliate;
            this.SectionCDidShopFor = sectionCDidShopFor;
            this.SectionHOtherCosts = sectionHOtherCosts;
            this.UseDefaultModify = useDefaultModify;
            this.UseDefaultChecked = useDefaultChecked;
            this.PayTo = payTo;
            this.PayeeName = payeeName;
            this.LoanEstimateUnrounded = loanEstimateUnrounded;
            this.LoanEstimateRounded = loanEstimateRounded;
            this.BuyerAtClosing = buyerAtClosing;
            this.BuyerChargePaymentMethod = buyerChargePaymentMethod;
            this.BuyerBeforeClosing = buyerBeforeClosing;
            this.BuyerPaidbyOther = buyerPaidbyOther;
            this.BuyerPaidbyOtherPaymentMethod = buyerPaidbyOtherPaymentMethod;
            this.BuyerDoubleAsteriskChecked = buyerDoubleAsteriskChecked;
            this.BuyerCredit = buyerCredit;
            this.BuyerCreditPaymentMethod = buyerCreditPaymentMethod;
            this.SellerPaidAtClosing = sellerPaidAtClosing;
            this.SellerChargePaymentMethod = sellerChargePaymentMethod;
            this.SellerPaidBeforeClosing = sellerPaidBeforeClosing;
            this.SellerPaidbyOthers = sellerPaidbyOthers;
            this.SellerPaidbyOtherPaymentMthd = sellerPaidbyOtherPaymentMthd;
            this.SellerCredit = sellerCredit;
            this.SellerCreditPaymentMethod = sellerCreditPaymentMethod;
        }

    }

    public class hudPDD
    {
        #region Properties
        public string Description;
        public string PayTo;
        public bool? UseDefault;
        public decimal? BuyerCharge;
        public string BuyerPaymentMethod;
        public decimal? SellerCharge;
        public string SellerPaymentMethod;
        public string GFE;
        public bool? LenderSelectedProvider;
        public bool? PaidOnBehalfOfBorrower;

        public Dictionary<string, string> PaymentMethodsTypeID = new Dictionary<string, string> { 
            { "CHK", "384" }, 
            { "FEE", "647" }, 
            { "POC", "386" }, 
            { "POC-B", "387" }, 
            { "POC-S", "388" }, 
            { "RBL", "385" }, 
        };
        public Dictionary<string, string> GfeEntriesTypeID = new Dictionary<string, string> { 
            { "None", "1593" }, 
            { "3", "1589" }, 
            { "6", "1590" }, 
            { "11", "1591" }, 
        };

        public string BuyerPaymentMethodTypeID
        {
            get { return PaymentMethodsTypeID[BuyerPaymentMethod]; }
        }

        public string SellerPaymentMethodTypeID
        {
            get { return PaymentMethodsTypeID[SellerPaymentMethod]; }
        }

        public string GfeTypeID
        {
            get { return GfeEntriesTypeID[GFE]; }
        }
        #endregion
    }
}
