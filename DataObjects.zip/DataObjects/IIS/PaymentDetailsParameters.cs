﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class PaymentDetailsParameters
    {
        public string Description;
        public string ChargeDescription;
        public bool? UpdateDescription;
        public bool? SectionBdidnotShopFor;
        public bool? LenderAffiliate;
        public bool? SectionCDidShopFor;
        public bool? SectionHOtherCosts;
        public bool? UseDefaultModify;
        public bool? UseDefaultChecked;
        public string PayTo;
        public string PayeeName;
        public double? LoanEstimateUnrounded;
        public double? LoanEstimateRounded;
        public double? BuyerAtClosing;
        public string BuyerChargePaymentMethod;
        public double? BuyerBeforeClosing;
        public double? BuyerPaidbyOther;
        public string BuyerPaidbyOtherPaymentMethod;
        public bool? BuyerDoubleAsteriskChecked;
        public double? BuyerCredit;
        public string BuyerCreditPaymentMethod;
        public double? SellerPaidAtClosing;
        public string SellerChargePaymentMethod;
        public double? SellerPaidBeforeClosing;
        public double? SellerPaidbyOthers;
        public string SellerPaidbyOtherPaymentMthd;
        public double? SellerCredit;
        public string SellerCreditPaymentMethod;
        public string LEDescription;
        public bool PartOfCheckbox = false;
        public string NoMonthsPrepaid;
        public string AdditionalDescription;
        public bool? SellerLenderCheckbox;
        public bool? BuyerLenderCheckbox;
    }
}
