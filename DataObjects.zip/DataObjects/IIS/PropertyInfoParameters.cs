﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FASTSelenium.DataObjects.IIS
{
    public class PropertyAddressParameters
    {
        //General
        public string StreetLine1 = "";
        public string StreetLine2 = "";
        public string StreetLine3 = "";
        public string State = "";
        public string City = "";
        public string County = "";
        public string Zip = "";
        public string Country = "";

        //Legal
        public string Lot = "";
        public string Block = "";
        public string Unit = "";

        //Title Production
        public string PlantEffectvDat = "";
        public string TitlInsuMortgCls = "";
        public string Vesting = "";       
        public string EstatInterest = "";
    }
}
