﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public struct UserIDTypes
    {
        public static string UserIDInUse = "";
        public static string SplitViewWithSpace = "";
        public static string ReversedUserID = "";
    }
}
