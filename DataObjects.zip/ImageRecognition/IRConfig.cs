﻿/*
 *  Filename:   IRConfig.cs
 *  Author:     Manuel A. Cerda R.
 *  Date:       03-14-2016
 */
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.ImageRecognition
{
    public static class IRConfig
    {
        public static bool canSaveScreenSamples = false;
        public static bool saveAllSamples = false;
        /// <summary>
        ///     General Wait Time in Seconds
        /// </summary>
        public static int waitTime = 120;
        public static readonly System.Windows.Size screenSize = new System.Windows.Size(1920, 1080);

        public static string MediaPath
        {
            get { return Reports.DEPLOYDIR + "\\"; }
        }

        public static string OutputPath
        {
            get { return Reports.RUNRESULTDIR + @"\\ImageRecognition\\"; }
        }
    }    
}
