﻿using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Reflection;
using SeleniumInternalHelpers;
using FASTSelenium.ImageRecognition;

namespace FASTSelenium.Common
{
    public static partial class WebElementExtensions
    {
        public static void JSClick(this IWebElement element)
        {
            Report.UpdateLog(element, "JSClick", "", "", () =>
            {
                var js = (OpenQA.Selenium.IJavaScriptExecutor)FastDriver.WebDriver;
                var obj = js.ExecuteScript("" +
                    "if (arguments[0].onclick) { arguments[0].onclick(); }" +
                    "else if (arguments[0].fireEvent) { arguments[0].fireEvent('click'); }" +
                    "else { arguments[0].click(); }" +
                    "return arguments[0];", element);
                Playback.Wait(100);
            });
        }

        public static void JSSetText(this IWebElement element, string text)
        {
            Report.UpdateLog(element, "JSSetText", "", "", () =>
            {
                var js = (OpenQA.Selenium.IJavaScriptExecutor)FastDriver.WebDriver;
                var obj = js.ExecuteScript("" +
                    "if (arguments[0].tagName !== 'INPUT') { arguments[0].innerHTML = '" + text + "'; }" +
                    "else { arguments[0].setAttribute('value','" + text + "'); }" +
                    "if (arguments[0].onchange) { arguments[0].onchange(); }" +
                    "else if (arguments[0].fireEvent) { arguments[0].fireEvent('onchange'); }" +
                    "return arguments[0];", element);
                element.Click();
                Playback.Wait(100);
            });
        }

        public static void FAContextClick(this IWebElement element)
        {
            Report.UpdateLog(element, "ContextClick", "", "", () =>
            {
                ((IRButton)element).ContextClick();
            });
        }

        public static void FAClickAction(this IWebElement element)
        { 
            Report.UpdateLog(element, "Click", "", "", () =>
            {
                new Actions(FastDriver.WebDriver).Click(element).Perform();
            });
        }
    }
}
