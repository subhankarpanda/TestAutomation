﻿using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace FASTSelenium.Common
{
    /*  String Formats for numeric types
        (C) Currency: . . . . . . . . ($1,234.00)
        (D) Decimal:. . . . . . . . . -1234
        (E) Scientific: . . . . . . . -1.234565E+003
        (F) Fixed point:. . . . . . . -1234.57
        (G) General:. . . . . . . . . -1234
            (default):. . . . . . . . -1234 (default = 'G')
        (N) Number: . . . . . . . . . -1,234.00
        (P) Percent:. . . . . . . . . -123,456.50 %
        (R) Round-trip: . . . . . . . -1234.565
        (X) Hexadecimal:. . . . . . . FFFFFB2E
     */
    public static class StringExtensions
    {
        public static StringHelper stringHelper = null;

        /// <summary>
        /// Get money value represented in a text.
        /// </summary>
        /// <param name="amount">Input text value</param>
        /// <param name="currencySymbol">Whether result should include the currency symbol</param>
        /// <returns>money represented text</returns>
        public static string FormatAsMoney(this string amount, bool currencySymbol = false, int decimalPlaces = 2)
        {
            string money = Regex.Replace(amount, "[^0-9.]", "");    // get all digits and "." from amount

            if (money != "")
                money = decimal.Parse(money).ToString("C" + decimalPlaces);        // convert to currency format

            return currencySymbol ? money : money.Replace("$", "");
        }

        /// <summary>
        /// Get a clean text for comparisson.
        /// </summary>
        /// <param name="text">Text to be processed</param>
        /// <param name="getAbsoluteString">Whether all lowecase & trimmed spaces should be considered</param>
        /// <returns>cleaned up text</returns>
        public static string Clean(this string text, bool getAbsoluteString = false)
        {
            if (getAbsoluteString)
            {
                var _strHelper = new StringHelper() { LowerCase = true, SP = false };
                return _strHelper.CleanUp(text);
            }
            stringHelper = stringHelper ?? new StringHelper();

            return stringHelper.CleanUp(text);
        }

        /// <summary>
        /// Repeats the specified character by the specified number of times.
        /// </summary>
        /// <param name="charToRepeat">Char to be repeated</param>
        /// <param name="repeat">Number of times to repeat</param>
        /// <returns>text with repeated text</returns>
        public static string Repeat(this char charToRepeat, int repeat)
        {

            return new string(charToRepeat, repeat);
        }

        /// <summary>
        /// Repeats the specified text by the specified number of times.
        /// </summary>
        /// <param name="stringToRepeat">Text to be repeated</param>
        /// <param name="repeat">Number of times to repeat</param>
        /// <returns>text with repeated character</returns>
        public static string Repeat(this string stringToRepeat, int repeat)
        {
            var builder = new StringBuilder(repeat * stringToRepeat.Length);
            for (int i = 0; i < repeat; i++)
            {
                builder.Append(stringToRepeat);
            }
            return builder.ToString();
        }

        public static string ToUpperFirst(this string stringToChange)
        {
            return char.ToUpper(stringToChange[0]) + stringToChange.ToLowerInvariant().Substring(1);
        }

        public static int CountOccurrences(this string input, string pattern)
        {
            return Regex.Matches(input, pattern).Count;
        }

        public static string FormatAsPhoneNumber(this string rawNumber, string format = "{0:1(###)###-####}")
        {
            try
            {
                return String.Format(format, System.Convert.ToInt64(rawNumber));
            }
            catch (Exception ex)
            {
                return "NaN: " + ex.Message;
            }
        }
    }

    public static class DateTimeExtensions
    {
        public static DateTime AddBusinessDays(this DateTime current, int days)
        {
            var sign = Math.Sign(days);
            var unsignedDays = Math.Abs(days);
            for (var i = 0; i < unsignedDays; i++)
            {
                do
                {
                    current = current.AddDays(sign);
                }
                while (current.DayOfWeek == DayOfWeek.Saturday ||
                    current.DayOfWeek == DayOfWeek.Sunday);
            }
            return current;
        }

        public static DateTime SubtractBusinessDays(this DateTime current, int days)
        {
            return AddBusinessDays(current, -days);
        }

        public static DateTime ToPST(this DateTime nonPstTime)
        {
            //Link: https://msdn.microsoft.com/en-us/library/gg154758.aspx
            return nonPstTime.ToUniversalTime().AddHours(TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time").IsDaylightSavingTime(nonPstTime) ? -7 : -8);
        }

        public static string ToDateString(this DateTime dateTime, bool slash = false, bool trim = false)
        {
            string format = trim ? "M-d-yyyy" : "MM-dd-yyyy";
            if (slash) format = format.Replace('-', '/');

            return dateTime.ToString(format);
        }

        public static string ToTimeString(this DateTime dateTime, char separator = ':', bool trim = false, bool timeZone = false)
        {
            string format = trim ? "h:mm:ss tt" : "hh:mm:ss tt";
            if(separator != ':') format = format.Replace(':', separator);
            if (timeZone) format = format + " \"GMT\"zzz";

            return dateTime.ToString(format);
        }

        public static string ToString(this DateTime? d, string format)
        {
            return d == null ? "" : ((DateTime)d).ToString(format);
        }

        public static int DaysPassed(this DateTime? d1, DateTime? d2)
        {
            TimeSpan span = (d2 ?? DateTime.UtcNow).Subtract(d1 ?? DateTime.UtcNow);

            return (int)span.TotalDays;
        }

        public static bool isWeekend(this DateTime d)
        {
            var dayOfWeek = d.DayOfWeek;

            return dayOfWeek == DayOfWeek.Saturday || dayOfWeek == DayOfWeek.Sunday;
        }

        public static DateTime AddWeekDays(this DateTime d, int days)
        {
            return d.AddDays(d.GetWeekDaysCountingWeekends(days));
        }

        public static int GetWeekDaysCountingWeekends(this DateTime d, int days)
        {
            var dateAfter = d.AddDays(days);
            if (dateAfter.DayOfWeek == DayOfWeek.Saturday)
                return days + 2;
            else if (dateAfter.DayOfWeek == DayOfWeek.Sunday)
                return days + 1;

            return days;
        }

        public static string MMddyyyy(this DateTime d, char sep = '-')
        {
            var format = string.Format("MM{0}dd{1}yyyy", sep, sep);

            return d.ToString(format);
        }

        public static string hhmmsstt(this DateTime d, char sep = ':')
        {
            var format = string.Format("hh{0}mm{1}ss tt", sep, sep);

            return d.ToString(format);
        }

    }

    public static class DecimalExtension
    {
        public static string ToString(this decimal? num, string format="N")
        {
            return num == null ? "" : ((Decimal)num).ToString(format);
        }
    }

    public static class DoubleExtensions
    {
        public static string ToString(this double? num, string format="N")
        {
            return num == null ? "" : ((Decimal)num).ToString(format);
        }
    }

    public static class ObjectExtensions
    {
        /// <summary>
        /// Convert an Object to JSON String
        /// </summary>
        /// <param name="obj">Object to be converted</param>
        /// <returns>JSON String representing the Object</returns>
        public static string ToJSON(this object obj)
        {
            var _json = new JSONString(obj);

            return _json.ToString();
        }
    }

    [Microsoft.VisualStudio.TestTools.UnitTesting.TestClass]
    public class DateTimeTests
    {
        [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod]
        public void TestMethod()
        {
            System.Diagnostics.Debug.WriteLine("Clean: " + DateTime.Now.ToTimeString());
            System.Diagnostics.Debug.WriteLine("trim: " + DateTime.Now.ToTimeString(trim: true));
            System.Diagnostics.Debug.WriteLine("tz: " + DateTime.Now.ToTimeString(timeZone: true));
            System.Diagnostics.Debug.WriteLine("both: " + DateTime.Now.ToTimeString(trim: true, timeZone: true));

            System.Diagnostics.Debug.WriteLine("Clean: " + DateTime.Now.ToDateString());
            System.Diagnostics.Debug.WriteLine("trim: " + DateTime.Now.ToDateString(trim: true));
            System.Diagnostics.Debug.WriteLine("slash: " + DateTime.Now.ToDateString(slash: true));
            System.Diagnostics.Debug.WriteLine("both: " + DateTime.Now.ToDateString(trim: true, slash: true));
        }
    }
}
