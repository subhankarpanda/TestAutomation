﻿using System.Diagnostics;
using OpenQA.Selenium;
using SeleniumInternalHelpers;
using System;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq.Expressions;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium.Interactions;

namespace FASTSelenium.Common
{
    public static class PageObjectExtensions
    {
        /// <summary>
        /// Wait for element with custom timeout, to solve the problem when FAST takes too long to load certain screens.
        /// </summary>
        [Obsolete("TIMEOUT VALUE WILL BE IGNORED. Use WaitCreation without a 'timeoutSeconds' parameter. This enables to have consistent wait times across our project.")]
        public static bool WaitCreation(this PageObject page, IWebElement element, int timeoutSeconds, bool continueOnFailure = false)
        {
            return Report.UpdateLog<bool>(element, "Wait", "Visible", "", () =>
            {
                try
                {
                    page.Wait.Until(FAExpectedConditions.ElementIsVisible(element));
                }
                catch (WebDriverTimeoutException)
                {
                    if (continueOnFailure)
                        return false;
                    else
                        throw;
                }
                return true;
            });
        }

        /// <summary>
        /// Wait for element with custom timeout, to solve the problem when FAST takes too long to load certain screens.
        /// </summary>
        /// 
        public static bool WaitCreation(this PageObject page, IWebElement element, bool continueOnFailure = false)
        {
            return Report.UpdateLog<bool>(element, "Wait", "Visible", "", () =>
            {
                try
                {
                    page.Wait.Until(FAExpectedConditions.ElementIsVisible(element));
                }
                catch (WebDriverTimeoutException)
                {
                    if (continueOnFailure)
                        return false;
                    else
                        throw;
                }
                return true;
            });
        }
        
        public static void SwitchToContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();

            page.WaitForFrameAndSwitch("fraView");
            page.WaitForFrameAndSwitch("fraPageWin");
        }

        public static void SwitchToLeftNavigationPane(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
        }

        public static void SwitchToBottomFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitch("fraView");
        }

        public static void SwitchToTopFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
        }

        public static void SwitchToBottomlink(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
        }

        public static void SwitchToTitleFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
        }

        public static void SwitchToFastViewContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId("fraApp");
            page.WaitForFrameAndSwitch("fraView");
            try
            {
                page.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }
            catch (WebDriverTimeoutException)
            {
                page.WaitForFrameAndSwitch("fraView");
                page.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }
        }

        public static void SwitchToFastViewBottomFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId("fraApp");
            page.WaitForFrameAndSwitch("fraView");
            page.WaitForFrameAndSwitchByFrameId("fraViewBottom");
        }

        public static void SwitchToFastViewStatusFrame(this PageObject page)
        {
            try
            {
                page.WebDriver.SwitchTo().DefaultContent();
                page.WaitForFrameAndSwitchByFrameId("fraApp");
                page.WaitForFrameAndSwitch("fraStatus");
            }
            catch (WebDriverTimeoutException)
            {
                page.WebDriver.SwitchTo().DefaultContent();
                page.WaitForFrameAndSwitchByFrameId("fraApp");
                page.WaitForFrameAndSwitch("fraStatus");
            }
        }
        public static void SwitchToImageWorkbenchFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitch("fraView");
            page.WaitForFrameAndSwitch("fraPageWin");
            page.WaitForFrameAndSwitch("frmWorkbench");
        }

        public static void SwitchToWQTopFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitch("fraWorkQ");
            try
            {
                page.WaitForFrameAndSwitch("fraWorkQTop");
            }
            catch (WebDriverTimeoutException)
            {
                page.WaitForFrameAndSwitch("fraWorkQ");
                page.WaitForFrameAndSwitch("fraWorkQTop");
            }
        }

        #region Dialog Frames
        public static void SwitchToDialogContentFrame(this PageObject page, bool switchToFraPageWin = true)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
            //This is for backward compatibility
            //Some dialogs are inside the 'fraPageWin' frame, so try to switch to this frame if exists otherwise continue
            if (switchToFraPageWin)
            {
                try
                {
                    page.WaitForFrameAndSwitch("fraPageWin");
                  
                }
                catch { }
            }
        }

        public static void SwitchToPhraseEditorContentFrame(this PageObject page, bool switchToFraPageWin = true)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
            //This is for backward compatibility
            //Some dialogs are inside the 'fraPageWin' frame, so try to switch to this frame if exists otherwise continue
            if (switchToFraPageWin)
            {
                try
                {
                    page.WaitForFrameAndSwitch("fraPageWin");
                    page.WaitForFrameAndSwitchByFrameId("tbContentElement");
                }
                catch { }
            }
        }
        public static void SwitchToDialogLeftContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
            page.WaitForFrameAndSwitch("fraPageWin");
            page.WaitForFrameAndSwitch("leftframe");
        }
        //
        public static void SwitchToDialogRightContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
            page.WaitForFrameAndSwitch("fraPageWin");
            page.WaitForFrameAndSwitch("rightframe");
        }

        public static void SwitchToDialogContactLeftContentFrame(this PageObject page, bool switchToLowerFrame = true)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
            page.WaitForFrameAndSwitch("fraPageWin");
            page.WaitForFrameAndSwitch("rightframe");
            if (switchToLowerFrame)
                page.WaitForFrameAndSwitch("rightframe");
            else
                page.WaitForFrameAndSwitch("leftframe");
        }

        public static void SwitchToDialogContactRightContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId("FAFDialog_1_iframe");
            page.WaitForFrameAndSwitch("fraPageWin");
            page.WaitForFrameAndSwitch("leftframe");
            page.WaitForFrameAndSwitch("leftframe");
        }
        public static void SwitchToPrintDialogContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
        }

        public static void SwitchToDialogBottomFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
        }
        
        public static void SwitchToWQDialogContentFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
            page.WaitForFrameAndSwitch("fraWorkQUpload");
        }

        public static void SwitchToWQDialogFrame(this PageObject page)
        {
            page.WebDriver.SwitchTo().DefaultContent();
            page.WaitForFrameAndSwitchByFrameId(page.GetTopDialogFrameId());
        }

        #endregion

        public static void WaitForValue(this PageObject page, IWebElement tag, string expectedvalue)
        {
            page.Wait.Until(d =>
            {
                try
                {
                    if (tag.Text != string.Empty)
                        return tag.Text == expectedvalue;
                    else
                        return tag.GetAttribute("value") == expectedvalue;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
            });
        }

        public static void WaitForFrameAndSwitch(this PageObject page, string FrameName)
        {
            page.Wait.Until(d =>
            {
                try
                {
                    d.SwitchTo().Frame(FrameName);
                    return true;
                }
                catch (NoSuchFrameException)
                {
                    return false;
                }
            });
        }

        public static void WaitForFrameAndSwitchByFrameId(this PageObject page, string frameId)
        {
            page.Wait.Until(d =>
            {
                try
                {
                    d.SwitchTo().Frame(FastDriver.WebDriver.FindElement(By.Id(frameId)));
                    return true;
                }
                catch (NoSuchFrameException)
                {
                    return false;
                }
            });
        }

        private static string GetTopDialogFrameId(this PageObject page)
        {
            try
            {
                page.WebDriver.SwitchTo().DefaultContent();
                var elements = page.WebDriver.FindElements(By.XPath("//iframe[@class='dialog-iframe'][starts-with(@id, 'FAFDialog_')]"));
                return elements.LastOrDefault().GetAttribute("id");
            }
            catch (Exception)
            {
                throw new Exception("Could not find an active Modal window.");
            }
        }

        public static void FAControlKeyPress(this PageObject page, string KeyToPress)
        {
            Report.UpdateLog(FastDriver.WebDriver, "Control + " + KeyToPress, "Control + " + KeyToPress, () =>
            {
                try
                {
                    new Actions(FastDriver.WebDriver).SendKeys(Keys.Control + KeyToPress + Keys.Control).Perform();
                }
                catch (Exception)
                {
                    //Continue
                }

            });
        }
    }
}
