﻿using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium;
using System;
using OpenQA.Selenium.Support.UI;
using AutoIt;
using Microsoft.VisualStudio.TestTools.UITesting;


namespace FASTSelenium.Common
{
    public static partial class WebDriverExtensions
    {
        public static string Describe(this IWebDriver driver, string format = null, params object[] args)
        {
            if (format != null)
                return string.Format(format, args);

            Func<IWebDriver, string> getDescription = (d) =>
            {
                return d.Title ?? d.Url;
            };

            try
            {
                return getDescription(driver);
            }
            catch (WebDriverException)
            {
                return "description not available";
            }

        }

        public static void SwitchToWindow(this IWebDriver driver, string windowTitle)
        {
            try
            {
                InternalSwitchToWindow(driver, windowTitle);
            }
            catch (Exception)
            {
                //just re try
                InternalSwitchToWindow(driver, windowTitle);
            }
        }

        public static void SwitchToWindowByUrl(this IWebDriver driver, string windowTitle)
        {
            bool switched = false;
            var windowIterator = driver.WindowHandles;
            foreach (var windowHandle in windowIterator) //HACK-Jorge: To switch windows 
            {
                if (driver.SwitchTo().Window(windowHandle).Url.Contains(windowTitle.Trim()))
                {
                    switched = true;
                    break;
                }
            }
            if (!switched) throw new Exception(string.Format("Did not find Window with Url containing '{0}'", windowTitle));
        }

        public static string HandleDialogMessage(this IWebDriver driver, bool switchBackToFastWindow = true, bool clickAcceptButton = true, int timeout = 5, bool retryWithAutoIT = true)
        {
            string alertText = "No dialog present";
            if (driver.WaitForAlertToExist(timeout)) //wait for an alert to be present
            {
                var alert = driver.SwitchTo().Alert();
                alertText = alert.Text;
                if (alertText.ToLower().Contains("your password will expire in") || !clickAcceptButton)
                    alert.Dismiss();
                else
                    alert.Accept();
                Reports.UpdateDebugLog(driver.Describe(), "Alert", "Handle Dialog", "", "", alertText, Reports.Result(true), "");
            }
            else if (retryWithAutoIT) //no alert present? try again using AutoIt...
            {
                string WinDlg = "[TITLE:Message from webpage;CLASS:#32770]";
                if (AutoItX.WinExists(WinDlg) != 0)
                {
                    AutoItX.WinActivate(WinDlg);
                    alertText = AutoItX.ControlGetText(WinDlg, "", "[CLASS:Static; INSTANCE:2]");
                    if (!clickAcceptButton)
                        AutoItX.Send("{SPACE}");    // to switch from default button

                    AutoItX.Send("{ENTER}");
                    Reports.UpdateDebugLog("AutoIt", "Alert", "Handle Dialog*", "", "", alertText, Reports.Result(true), "");
                }
            }

            if (alertText == "No dialog present" || alertText == "")
                Reports.UpdateDebugLog("No dialog present", "Alert", "Handle Dialog", "", "", "Dialog not present - Continuing test execution", Reports.Result(true), "");

            if (switchBackToFastWindow)
            {
                Playback.Wait(1000); // wait for "ghost" window to disappear
                driver.SwitchToWindow(Support.FASTWindowName);
            }
            return alertText;
        }

        public static string HandleAdobeReaderDialog(this IWebDriver driver, bool switchBackToFastWindow = true, bool clickAcceptButton = true, int timeout = 5)
        {
            string alertText = "No dialog present";
            try
            {
                // try again using AutoIt
                string WinDlg = "[TITLE:Adobe Reader;CLASS:#32770]";
                if (AutoItX.WinExists(WinDlg) != 0)
                {
                    AutoItX.WinActivate(WinDlg);
                    alertText = AutoItX.ControlGetText(WinDlg, "", "[CLASS:Static; INSTANCE:2]");
                    if (clickAcceptButton)
                        AutoItX.Send("{ENTER}");
                    else
                    {
                        AutoItX.Send(FAKeys.TabAway);
                        AutoItX.Send("{ENTER}");
                    }
                }
                Reports.UpdateDebugLog(driver.Title, "Alert", "Handle Dialog", "", "", alertText, Reports.Result(true), "");
            }
            catch (Exception)
            {

            }

            return alertText;
        }

        public static void ClickSaveOnPdfCreatorDialog(this IWebDriver driver)
        {
            try
            {
                string WinDlg = "[TITLE:PDFCreator 1.7.1;CLASS:ThunderRT6FormDC]";
                if (AutoItX.WinExists(WinDlg) != 0)
                {
                    AutoItX.WinActivate(WinDlg);
                    AutoItX.ControlClick(WinDlg, "After saving open output file", "[CLASS:ThunderRT6CheckBox; INSTANCE:2]");
                    Playback.Wait(500);
                    AutoItX.ControlClick(WinDlg, "Save", "[CLASS:ThunderRT6CommandButton; INSTANCE:7]");
                }
                Reports.UpdateDebugLog(driver.Title, "Alert", "Handle PDF Creator Dialog", "", "", "", Reports.Result(true), "");
            }
            catch (Exception)
            {
                Reports.UpdateDebugLog(driver.Title, "Alert", "Handle PDF Creator Dialog", "", "", "", Reports.Result(false), "Something is wrong on PDF Creator dialog");
            }

        }

        public static void SavePdfFile(this IWebDriver driver, string fileName)
        {
            try
            {
                string WinDlg = "[TITLE:Save as;CLASS:#32770]";
                if (AutoItX.WinExists(WinDlg) != 0)
                {
                    AutoItX.WinActivate(WinDlg);
                    //AutoItX.ControlSetText(WinDlg, "File name", "[CLASS:Edit; INSTANCE:1]", fileName);
                    AutoItX.Send(fileName);
                    Playback.Wait(500);
                    AutoItX.ControlClick(WinDlg, "", "[CLASS:Button; INSTANCE:1]");
                }
                Reports.UpdateDebugLog(driver.Title, "Alert", "Save PDF to file", "", "", "", Reports.Result(true), "");
            }
            catch (Exception)
            {
                Reports.UpdateDebugLog(driver.Title, "Alert", "Save PDF to file", "", "", "", Reports.Result(false), "Something is wrong on Save as dialog");
            }

        }

        public static void ConfirmSaveAs(this IWebDriver driver, bool replace = true)
        {
            try
            {
                string WinDlg = "[TITLE:Confirm Save As;CLASS:#32770]";
                if (AutoItX.WinExists(WinDlg) != 0)
                {
                    AutoItX.WinActivate(WinDlg);

                    if (replace)
                        AutoItX.ControlClick(WinDlg, "Yes", "[CLASS:Button; INSTANCE:1]"); // Yes button
                    else
                        AutoItX.ControlClick(WinDlg, "No", "[CLASS:Button; INSTANCE:2]"); // No button
                }
                Reports.UpdateDebugLog(driver.Title, "Alert", "Confirm Save As", "", "", "", Reports.Result(true), "");
            }
            catch (Exception)
            {
                Reports.UpdateDebugLog(driver.Title, "Alert", "Confirm Save As", "", "", "", Reports.Result(true), "Confirm Save As doesn't popup");
            }

        }

        public static string HandleConfirmSaveAsDialog(this IWebDriver driver, bool switchBackToFastWindow = true, bool clickAcceptButton = true, int timeout = 5)
        {
            string alertText = "No dialog present";
            try
            {
                string WinDlg = "[TITLE:Confirm Save As;CLASS:#32770]";
                if (AutoItX.WinExists(WinDlg) != 0)
                {
                    AutoItX.WinActivate(WinDlg);
                    alertText = AutoItX.ControlGetText(WinDlg, "", "[CLASS:Static; INSTANCE:2]");
                    if (clickAcceptButton)
                    {
                        AutoItX.Send(FAKeys.TabAway);
                        AutoItX.Send("{ENTER}");
                    }
                    else
                        AutoItX.Send("{ENTER}");

                }
                Reports.UpdateDebugLog(driver.Title, "Alert", "Handle Dialog", "", "", alertText, Reports.Result(true), "");
            }
            catch (Exception)
            {

            }

            return alertText;
        }

        public static void WaitForWindowAndSwitch(this IWebDriver driver, string windowName, bool toExist = true, int timeoutSeconds = 5, bool switchBackToFAST = true)
        {
            //The following deivery windows still not converted to JQuery popup window
            //if ((windowName == Support.FASTWindowName) || (windowName == "Print Preview") || (windowName == "Real Time Mail Delivery") || (windowName == "Email Delivery") || (windowName == "Fax Delivery") || (windowName == "Image Doc Delivery") || (windowName == "Print Delivery") || (windowName == "One moment please...") || (windowName == "Blank Page") || (windowName == "FAST View") || (windowName == "Date Down Request") || (windowName == "List Phrases by Phrase Group")) 
            if (SwitchableWindows.NameList.Contains(windowName))
            {
                try
                {
                    driver.SwitchTo().DefaultContent();
                }
                catch (Exception)
                {
                    //just continue
                }

                string url = "";
                url = windowName.ToLower().StartsWith("url:") ? "with \"" + windowName.Substring(4) + "\" in url" : windowName;

                Report.UpdateLog(driver, string.Format("Wait for window {0} to {1}", url, toExist ? "exist" : "not exist"), windowName, () =>
                {
                    WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutSeconds));
                    wait.Until(w => WindowIsDisplayed(driver, windowName) == toExist);

                    // sometimes another dialog is popup, in this case don't switch back to FAST window
                    if (!toExist && switchBackToFAST)
                        driver.SwitchToWindow(Support.FASTWindowName);

                    Playback.Wait(1000); //Wait for ghost screen to disappear
                });
            }
            else
            {
                Playback.Wait(5000); //Wait for ghost screen to disappear
            }

        }

        public static void ClosePreviewWindow(this IWebDriver driver)
        {
            Report.UpdateLog(driver, "Close preview window", "", () =>
            {
                Support.CloseAllProcessStartingWith("AcroRd32");    // this only kill the AcroRd32 process, but the browser remains open
                try
                {
                    driver.SwitchToWindowByUrl(@"/Documents/Print");       // need these to close the browser
                    driver.Close();
                }
                catch (Exception ex)
                {
                    // just continue...
                    Reports.StatusUpdate("Error occurred when closing preview screen. " + ex.Message, true);
                }
                driver.SwitchToWindow(Support.FASTWindowName);
            });
        }

        public static bool WaitForAlertToExist(this IWebDriver driver, int timeoutSeconds)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeoutSeconds));
                wait.Until(w => AlertIsDisplayed(driver));
                //wait.Until(FAExpectedConditions.AlertIsPresent());
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            return true;
        }

        [Obsolete("THIS METHOD IS NO LONGER SUPPORTED. Use WaitForDeliveryWindow() using FADeliveryMethod parameter. This ensures consistency of use throughout the FrameWork.")]
        public static void WaitForDeliveryWindow(this IWebDriver driver, string deliveryMethod = "Print", int timeoutSeconds = 200)
        {
            System.Threading.Thread.Sleep(1000);
            string selectedMethod;
            switch (deliveryMethod)
            {
                case "Preview":
                    selectedMethod = "Print Preview";
                    break;
                case "RTM":
                    selectedMethod = "Real Time Mail Delivery";
                    break;
                default:
                    selectedMethod = deliveryMethod + " Delivery";
                    break;
            }

            try { driver.WaitForWindowAndSwitch(selectedMethod, true, 60); } //wait for the delivery window to show up
            catch (WebDriverTimeoutException) { throw new WebDriverTimeoutException(string.Format("'{0}' window didn't show up in {1} seconds while trying to perform delivery.", selectedMethod, timeoutSeconds)); }

            try { driver.WaitForWindowAndSwitch(selectedMethod, false, timeoutSeconds); } //wait for the delivery window to go away
            catch (WebDriverTimeoutException) { throw new WebDriverTimeoutException(string.Format("'{0}' failed after {1} seconds.", selectedMethod, timeoutSeconds)); }

            driver.SwitchToWindow(Support.FASTWindowName);
        }

        public static void WaitForDeliveryWindow(this IWebDriver driver, FADeliveryMethod method, int timeoutSeconds = 200)
        {
            System.Threading.Thread.Sleep(1000);
            string selectedMethod = FastDriver.Delivery.GetDeliveryWindowTitle(method);

            try { driver.WaitForWindowAndSwitch(selectedMethod, true, 60); } //wait for the delivery window to show up
            catch (WebDriverTimeoutException) { throw new WebDriverTimeoutException(string.Format("'{0}' window didn't show up in {1} seconds while trying to perform delivery.", selectedMethod, timeoutSeconds)); }

            try { driver.WaitForWindowAndSwitch(selectedMethod, false, timeoutSeconds); } //wait for the delivery window to go away
            catch (WebDriverTimeoutException) { throw new WebDriverTimeoutException(string.Format("'{0}' failed after {1} seconds.", selectedMethod, timeoutSeconds)); }

            driver.SwitchToWindow(Support.FASTWindowName);

        }


        public static bool WindowIsDisplayed(this IWebDriver driver, string windowTitle)
        {
            try
            {
                if (windowTitle.ToLower().StartsWith("url:"))
                    driver.SwitchToWindowByUrl(windowTitle.Substring(4));
                else
                    driver.SwitchToWindow(windowTitle);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static void HandleScriptErrorMessage(this IWebDriver driver)
        {
            if (WindowIsDisplayed(driver, "Script Error"))
            {
                driver.WaitForWindowAndSwitch("Script Error", true, 10);
                driver.FindElement(By.Name("Yes")).FAClick();
            }
        }

        public static object Execute(this IWebDriver driver, string script, bool async = false, params object[] args)
        {
            return async ? ((IJavaScriptExecutor)driver).ExecuteAsyncScript(script, args) : ((IJavaScriptExecutor)driver).ExecuteScript(script, args);
        }

        public static T Execute<T>(this IWebDriver driver, string script, bool async = false, params object[] args)
        {
            return (T)(async ? ((IJavaScriptExecutor)driver).ExecuteAsyncScript(script, args) : ((IJavaScriptExecutor)driver).ExecuteScript(script, args));
        }

        private static bool AlertIsDisplayed(IWebDriver driver)
        {
            try
            {
                driver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private static void InternalSwitchToWindow(IWebDriver driver, string windowTitle)
        {
            bool switched = false;
            var windowIterator = driver.WindowHandles;
            foreach (var windowHandle in windowIterator) //HACK-Jorge: To switch windows 
            {
                string title = driver.SwitchTo().Window(windowHandle).Title;
                if (windowTitle == Support.NoTitleWindow && title == string.Empty)
                {
                    switched = true;
                    break;
                }
                else if (title.Contains(windowTitle.Trim()))
                {
                    switched = true;
                    break;
                }
            }
            if (!switched) throw new Exception(string.Format("Did not find Window with title containing '{0}'", windowTitle));
        }

        public static void WaitForActionToComplete(this IWebDriver driver, Func<bool> action, int? timeout = null, int? idleInterval = null)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout ?? int.Parse(AutoConfig.WaitTime)));
            wait.PollingInterval = TimeSpan.FromSeconds(idleInterval ?? 1);
            try { wait.Until(d => action.Invoke()); }
            catch (WebDriverTimeoutException) { throw new WebDriverTimeoutException(string.Format("Action did not complete after {0} seconds.", timeout)); }
        }

        #region DO NOT USE
        //private static Screenshot TakeScreenshot(this IWebDriver driver)
        //{
        //    return ((ITakesScreenshot)driver).GetScreenshot();
        //}
        #endregion
    }
}
