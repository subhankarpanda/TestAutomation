﻿using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Reflection;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects;
using System.Collections.ObjectModel;
using System.Windows;

namespace FASTSelenium.Common
{
    public static partial class WebElementExtensions
    {
        #region FA Report Helper
        private static Dictionary<string, string> PropertyNamesFromTypes = new Dictionary<string, string>();
        static WebElementExtensions()
        {
            CreateCache();
        }

        private static void CreateCache()
        {
            var q = from t in Assembly.GetExecutingAssembly().GetTypes()
                    where t.BaseType == typeof(PageObject)
                    select t;

            foreach (var t in q)
            {
                var properties = t.GetProperties();

                foreach (var property in properties)
                {
                    try
                    {
                        if (property.CustomAttributes != null && property.CustomAttributes.Count() > 0)
                        {
                            var attrib = property.CustomAttributes.FirstOrDefault();
                            if (attrib.AttributeType == typeof(OpenQA.Selenium.Support.PageObjects.FindsByAttribute))
                            {
                                if (attrib.NamedArguments.Count > 1)
                                {
                                    var attribVal = attrib.NamedArguments[1].TypedValue.ToString().Replace("\"", string.Empty);
                                    if (!PropertyNamesFromTypes.ContainsKey(attribVal))
                                        PropertyNamesFromTypes.Add(attribVal, property.Name);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
        }
        #endregion

        #region FA Helpers

        public static bool FAElementInViewPort(this IWebElement element)
        {
            string execScript = @"var rect     = arguments[0].getBoundingClientRect(),
                                    vWidth   = window.innerWidth || doc.documentElement.clientWidth,
                                    vHeight  = window.innerHeight || doc.documentElement.clientHeight,
                                    efp      = function (x, y) { return document.elementFromPoint(x, y) };     

                                if (rect.right < 0 || rect.bottom < 0 
                                        || rect.left > vWidth || rect.top > vHeight)
                                    return false;

                                return (
                                      arguments[0].contains(efp(rect.left,  rect.top))
                                  ||  arguments[0].contains(efp(rect.right, rect.top))
                                  ||  arguments[0].contains(efp(rect.right, rect.bottom))
                                  ||  arguments[0].contains(efp(rect.left,  rect.bottom))
                                );";
                IJavaScriptExecutor JSExecutor = (IJavaScriptExecutor)FastDriver.WebDriver;
                return (bool)(JSExecutor.ExecuteScript(execScript, element));
        }
        public static bool FAHorizontalScrollVisible(this IWebElement element)
        {
            bool reVal = false;
            
            try
            {
                string execScript = "return arguments[0].scrollWidth  > arguments[0].clientWidth;";
                IJavaScriptExecutor scrollBarPresent = (IJavaScriptExecutor) FastDriver.WebDriver;
                reVal = (bool)(scrollBarPresent.ExecuteScript(execScript, element));
            }
            catch { }

            return reVal;
        }

        public static bool FAVerticalScrollVisible(this IWebElement element)
        {
            bool reVal = false;

            try
            {
                string execScript = "return arguments[0].scrollHeight > arguments[0].clientHeight;";
                IJavaScriptExecutor scrollBarPresent = (IJavaScriptExecutor)FastDriver.WebDriver;
                reVal = (bool)(scrollBarPresent.ExecuteScript(execScript, element));
            }
            catch { }

            return reVal;
        }

        public static bool IsDisplayed(this IWebElement element)
        {
            bool reVal = false;

            try
            {
                reVal = element.Displayed;
            }
            catch
            {
                // just continue
            }

            return reVal;
        }

        public static bool IsSelected(this IWebElement element)
        {
            bool reVal = false;

            try
            {
                reVal = element.Selected;
            }
            catch
            {
                // just continue
            }

            return reVal;
        }

        public static void FASetText(this IWebElement element, string text, bool clearFirst = true, bool continueOnFailure = false, bool isPassword = false)
        {
            if (text == null) // if nothing pass in, just skip it
                return;

            try
            {
                Report.UpdateLog(element, "Set", "Text", (isPassword ? "••••••••••••••" : text), () =>
                {
                    if (clearFirst) element.Clear();
                    element.SendKeys(text);
                });
            }
            catch (Exception)
            {
                if (continueOnFailure)
                    Reports.StatusUpdate("Unable to set Text = " + (isPassword ? "••••••••••••••" : text), true);
                else
                    throw;
            }
        }

        public static void FASendKeys(this IWebElement element, string text, bool continueOnFailure = true)
        {
            if (text == null) // if nothing pass in, just skip it
                return;

            try
            {
                Report.UpdateLog(element, "SendKeys", "Text", text, () =>
                {
                    element.SendKeys(text);
                });
            }
            catch (Exception)
            {
                if (continueOnFailure)
                    Reports.StatusUpdate("Unable to SendKyes, keys = " + text, true);
                else
                    throw;
            }
        }

        public static void FASelectContextMenuItem(this IWebElement element, bool continueOnFailure = true)
        {
            try
            {
                if(element.Exists() == false)
                {
                    throw new Exception("Element does not exist");
                }

                Report.UpdateLog(element, "SendKeys", "Enter Key", "", () =>
                {
                    element.SendKeys(Keys.Enter);
                });

                Playback.Wait(2000); // hate to use this...
                if (element.Displayed)    // try again using Click()
                {
                    Report.UpdateLog(element, "Click", "", "", () =>
                    {
                        element.Click();
                    });
                }
            }
            catch (Exception ex)
            {
                if (continueOnFailure)
                    Reports.StatusUpdate("Unable to select context menu item!", true);
                else
                    throw ex;
            }
        }

        public static void FASetCheckbox(this IWebElement element, bool? check)
        {
            if (!check.HasValue) // if nothing pass in, just skip it
                return;

            Report.UpdateLog(element, "Set", "Checkbox", check.ToString(), () =>
            {
                if (!element.Selected && check == true || element.Selected && check == false)
                {
                    element.SendKeys(FAKeys.Space);
                }
            });
        }

        public static void FASelectItemByIndex(this IWebElement element, int? _index, bool reverse = false, bool fireEvents = true)
        {
            if (!_index.HasValue || _index < 0) // if nothing pass in, just skip it
                return;

            SelectElement selectElement = new SelectElement(element);

            int index = (int)_index;
            if (reverse)
                index = selectElement.Options.Count - index;

            Report.UpdateLog(element, "SelectItem", "ByIndex", index.ToString(), () =>
            {
                selectElement.SelectByIndex(index);
                if (fireEvents)
                {
                    element.FireEvent("onchange");
                }
            });
        }

        public static void FASelectItem(this IWebElement element, string text, bool fireEvents = true)
        {
            if (text == null || text == string.Empty) // if nothing pass in, just skip it // what if there is an "empty" selection.. sometimes, first item on list
                return;

            Report.UpdateLog(element, "SelectItem", "", text, () =>
            {
                new SelectElement(element).SelectByText(text);
                if (fireEvents)
                {
                    element.FireEvent("onchange");
                }
            });
        }

        public static void FASelectItemBySendingKeys(this IWebElement element, string text)
        {
            if (text == null) // if nothing pass in, just skip it
                return;

            Report.UpdateLog(element, "SelectItem", "BySendingKeys", text, () =>
            {
                //element.Click();
                element.SendKeys(text);
            });
        }

        public static void FASelectItemBySendingKeys(this IWebElement element, uint index, bool lastFirst = false)
        {
            uint topIndex = (uint)element.FindElements(By.CssSelector("option")).Count;
            uint i = index > topIndex ? topIndex : index;
            string keys = "{" + (lastFirst ? "END" : "HOME") + "}" + ("{" + (lastFirst ? "UP" : "DOWN") + "}").Repeat((int)i) + "{ENTER}";

            Report.UpdateLog(element, "SelectItem", "BySendingKeys", keys, () =>
            {
                element.Click();
                Keyboard.SendKeys(keys);
            });
        }

        public static List<string> FAGetAllSelectedItems(this IWebElement element)
        {


            List<string> AllSelectedItems = new List<string>();
            var selectElement = new SelectElement(element);
            if (selectElement.AllSelectedOptions.Count > 0)
                for (int i = 0; i <= selectElement.AllSelectedOptions.Count - 1; i++)
                {
                    AllSelectedItems.Add(selectElement.AllSelectedOptions[i].Text.ToString());

                }
            return AllSelectedItems;
        }
        public static string FAGetSelectedItem(this IWebElement element)
        {
            return Report.UpdateLog<string>(element, "Get", "SelectedItem", "", () =>
            {
                var selectElement = new SelectElement(element);
                if (selectElement.AllSelectedOptions.Count == 0)
                    return "";
                else
                    return selectElement.SelectedOption.Text;

                // TODO: return all selected options - if needed
                // else if (selectElement.AllSelectedOptions.Count > 1)

            });
        }

        public static string FAGetAllTextFromSelect(this IWebElement element, string separator = "|")
        {
            return element.FAGetDropdownOptions().ToString(separator);
        }

        /// <summary>
        /// Get HtmlSelect element options.
        /// </summary>
        /// <param name="element">HtmlSelect web element</param>
        /// <returns>Collection of web elements</returns>
        public static IList<IWebElement> FAGetDropdownOptions(this IWebElement element)
        {
            if (element.TagName.ToLowerInvariant() != "select")
                throw new Exception("Element must be of type HtmlSelect");

            return Report.UpdateLog<IList<IWebElement>>(element, "Get", "AllOptions", "", () =>
            {
                SelectElement selectElement = new SelectElement(element);
                return selectElement.Options;
            });
        }

        public static void FAClick(this IWebElement element)
        {
            Report.UpdateLog(element, "Click", "", "", () =>
            {
                element.Click();
            });
        }

        public static void FASubmit(this IWebElement element)
        {
            Report.UpdateLog(element, "Submit", "", "", () =>
            {
                element.Submit();
            });
        }

        public static void FARightClick(this IWebElement element)
        {
            Report.UpdateLog(element, "RightClick", "", "", () =>
            {
                new Actions(FastDriver.WebDriver).ContextClick(element).Perform();
            });
        }

        public static void FADragAndDrop(this IWebElement fromElement, IWebElement toElement)
        {
            // Using the element directly from the page object is throwing a null reference exception. Need to construct a new element using MyByFactory.
            IWebElement myfromElement = GetNonPageObjectElementInstance(fromElement);
            IWebElement mytoElement = GetNonPageObjectElementInstance(toElement);

            Report.UpdateLog(myfromElement, mytoElement, "Drag and Drop", "", "", () =>
            {
                try
                {
                    new Actions(FastDriver.WebDriver).DragAndDrop(myfromElement, mytoElement).Perform();
                }
                catch (NoSuchElementException)
                {

                }

            });
        }

        public static void FADragAndDropWithOffset(this IWebElement fromElement, IWebElement toElement, int offsetX = 0, int offsetY = 0)
        {
            // Negative offsetY value = move UP from the toElement
            // Positive offsetY value = move DOWN from the toElement

            // Using the element directly from the page object is throwing a null reference exception. Need to construct a new element using MyByFactory.
            IWebElement myfromElement = GetNonPageObjectElementInstance(fromElement);
            IWebElement mytoElement = GetNonPageObjectElementInstance(toElement);

            Report.UpdateLog(myfromElement, mytoElement, "Drag and Drop with Offset", "", "", () =>
            {
                try
                {
                    int xOffset = 0;
                    int yOffset = 0;

                    xOffset = offsetX;

                    if (myfromElement.Location.Y > mytoElement.Location.Y) // myfromElement is lower than mytoElement
                        yOffset = -((myfromElement.Location.Y - mytoElement.Location.Y) - offsetY); // Drag upward therefore negative value for the yOffset
                    else // myfromElement is higher than mytoElement
                        yOffset = (mytoElement.Location.Y - myfromElement.Location.Y) + offsetY;

                    new Actions(FastDriver.WebDriver).DragAndDropToOffset(myfromElement, xOffset, yOffset).Perform();
                }
                catch (NoSuchElementException)
                {

                }

            });
        }

        public static void FADoubleClick(this IWebElement element)
        {
            Report.UpdateLog(element, "DoubleClick", "", "", () =>
            {
                new Actions(FastDriver.WebDriver).DoubleClick(element).Perform();
            });
        }

        public static string FAGetAttribute(this IWebElement element, string attribute)
        {
            return Report.UpdateLog<string>(element, "GetAttribute", attribute, "", () => element.GetAttribute(attribute));
        }

        public static string FAGetValue(this IWebElement element)
        {
            return element.FAGetAttribute("value");
        }

        public static string FAGetText(this IWebElement element)
        {
            return element.Text;
        }

        /// <summary>
        ///    Moves the mouse to the specified element.
        ///      -- still not working correctly
        /// </summary>
        /// <param name="element">The element to which to move the mouse.</param>
        /// <returns>none</returns>
        public static void FAMoveToElement(this IWebElement element)
        {
            Report.UpdateLog(element, "MoveToElement", "", "", () =>
            {
                new Actions(FastDriver.WebDriver).MoveToElement(element).Perform();
            });
        }

        public static void FAMouseOver(this IWebElement element)
        {
            string javaScript = "var evObj = document.createEvent('MouseEvents');" +
                                  "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
                                 "arguments[0].dispatchEvent(evObj);";

            Report.UpdateLog(element, "MouseOver", "", "", () =>
            {
                FastDriver.WebDriver.Execute(script: javaScript, args: element);
            });
        }
        

        /// <summary>
        /// FAGetOffset uses JQuery offset() to find the position of the element relative to its parent frame.
        /// </summary>
        /// <param name="element">The IWebElement</param>
        /// <returns>System.Drawing.Point</returns>
        public static System.Drawing.Point FAGetOffset(this IWebElement element)
        {
            System.Drawing.Point offset = new System.Drawing.Point();
            try
            {
                var pObject = FastDriver.WebDriver.Execute<Dictionary<string, object>>("return $(arguments[0]).offset()", false, element);
                offset.X = int.Parse(pObject["left"].ToString());
                offset.Y = int.Parse(pObject["top"].ToString());
            }
            catch
            {
                throw new Exception("Element offset could not be determined");
            }

            return offset;
        }

        public static System.Drawing.Point FAGetLocation(this IWebElement element)
        {
            return element.Location; ;
        }

        #endregion

        public static IWebElement FAFindElement(this ISearchContext context, ByLocator locator, string criteria)
        {
            IWebElement foundElement;
            switch (locator)
            {
                case ByLocator.ClassName:
                    foundElement = context.FindElement(By.ClassName(criteria));
                    break;
                case ByLocator.CssSelector:
                    foundElement = context.FindElement(By.CssSelector(criteria));
                    break;
                case ByLocator.Id:
                    foundElement = context.FindElement(By.Id(criteria));
                    break;
                case ByLocator.TagName:
                    foundElement = context.FindElement(By.TagName(criteria));
                    break;
                case ByLocator.XPath:
                    foundElement = context.FindElement(By.XPath(criteria));
                    break;
                default:
                    throw new ArgumentException("Provided ByLocator is not supported.");
            }

            return foundElement;
        }

        public static IEnumerable<IWebElement> FAFindElements(this ISearchContext context, ByLocator locator, string criteria)
        {
            IEnumerable<IWebElement> foundElements;
            switch (locator)
            {
                case ByLocator.ClassName:
                    foundElements = context.FindElements(By.ClassName(criteria));
                    break;
                case ByLocator.CssSelector:
                    foundElements = context.FindElements(By.CssSelector(criteria));
                    break;
                case ByLocator.Id:
                    foundElements = context.FindElements(By.Id(criteria));
                    break;
                case ByLocator.TagName:
                    foundElements = context.FindElements(By.TagName(criteria));
                    break;
                case ByLocator.XPath:
                    foundElements = context.FindElements(By.XPath(criteria));
                    break;
                default:
                    throw new ArgumentException("Provided ByLocator is not supported.");
            }

            return foundElements;
        }

        public static string FADescription(this IWebElement e)
        {
            switch (e.TagName.ToUpperInvariant())
            {
                case "A":
                case "LABEL":
                case "LI":
                case "OPTION":
                case "P":
                case "TITLE":
                case "BUTTON":
                case "H1":
                case "H2":
                case "H3":
                case "H4":
                case "H5":
                    return e.FAGetText().Trim();
                default:
                    if (!string.IsNullOrEmpty(e.GetAttribute("id")))
                    {
                        return PropertyNamesFromTypes[e.GetAttribute("id")]; //Look up the name from the dictionary using the id
                    }
                    else if (!string.IsNullOrEmpty(e.GetAttribute("name")))
                    {
                        return "Name: " + e.GetAttribute("name");
                    }
                    else if (!string.IsNullOrEmpty(e.GetAttribute("class")))
                    {
                        return "Class: " + e.GetAttribute("class");
                    }
                    else { return "Offset: " + e.Location; }
            };
        }

        public static string FATagName(this IWebElement e)
        {
            try
            {
                switch (e.TagName.ToUpperInvariant())
                {
                    case "A":
                        return "Hyperlink";
                    case "H1":
                    case "H2":
                    case "H3":
                    case "H4":
                    case "H5":
                        return "Title";
                    case "IMG":
                        return "Image";
                    case "INPUT":
                        switch (e.GetAttribute("type").ToLowerInvariant())
                        {
                            case "text":
                            case "password":
                            case "number":
                            case "date":
                            case "color":
                            case "range":
                            case "month":
                            case "week":
                            case "time":
                            case "datetime":
                            case "datetime-local":
                            case "email":
                            case "search":
                            case "tel":
                            case "url":
                                return "TextBox";
                            case "radio":
                                return "RadioButton";
                            case "submit":
                            case "button":
                                return "Button";
                            case "checkbox":
                                return "CheckBox";
                            default:
                                return e.TagName.ToUpperFirst();
                        }
                    case "LI":
                        return "ListItem";
                    case "OPTION":
                        return "DropdownItem";
                    case "P":
                        return "Text";
                    case "SELECT":
                        return "DropdownMenu";
                    case "TD":
                        return "TableCell";
                    case "TEXTAREA":
                        return "TextArea";
                    case "TITLE":
                        return "WindowTitle";
                    case "TR":
                        return "TableRow";
                    default:
                        return e.TagName.ToUpperFirst();
                };
            }
            catch (Exception)
            {
                return "description not available";
            }
        }

        public static string Describe(this IWebElement element, string format = null, params object[] args)
        {
            if (format != null)
                return string.Format(format, args);

            try
            {
                return FADescription(element);
            }
            catch (Exception)
            {
                return "description not available";
            }
        }

        public static bool FeeExistOnTable(this IWebElement tableName, string feeName)
        {
            return tableName.GetAttribute("innerHTML").Contains(feeName);
        }

        public static bool StringExistOnTable(this IWebElement tableName, string searchString, bool cleanFirst = true)
        {
            if (cleanFirst)
                return tableName.GetAttribute("innerHTML").Clean().Replace("<br>", " ").Contains(searchString);
            else
                return tableName.GetAttribute("innerHTML").Contains(searchString);
        }

        public static IWebElement FireEvent(this IWebElement element, string eventName)
        {
            string scriptToExecute = string.Format("return arguments[0].fireEvent('{0}',document.createEventObject())", eventName);
            try
            {
                FastDriver.WebDriver.Execute(script: scriptToExecute, async: false, args: element);
            }
            catch { }
            return element;
        }

        /// <summary>
        ///    Scroll element into view. using java
        ///    The element must exists on the DOM.
        /// </summary>
        /// <returns> Returns element.  whether successful or not</returns>
        public static IWebElement ScrollIntoView(this IWebElement element)
        {
            try
            {
                IJavaScriptExecutor js = (IJavaScriptExecutor)FastDriver.WebDriver;
                js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
            }
            catch { }

            return element;
        }

        /// <summary>
        ///    Check whether element presents on the DOM of a page.
        ///    This does not necessarily mean that the element is visible.
        /// </summary>
        /// <param name="timeoutSeconds">timeout to wait for element to exist (in seconds). default is 1 second.</param>
        /// <returns>True if element exists. Otherwise, returns False</returns>
        public static bool Exists(this IWebElement element, int timeoutSeconds = 1)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(timeoutSeconds));
                //wait.IgnoreExceptionTypes(typeof(StaleElementReferenceException), typeof(NoSuchElementException), typeof(ElementNotVisibleException), typeof(InvalidElementStateException));
                return wait.Until(d =>
                {
                    try
                    {
                        System.Drawing.Point dontCare = element.Location;
                        return true;
                    }
                    catch (StaleElementReferenceException)
                    {
                        Playback.Wait(500);
                        System.Drawing.Point dontCare = element.Location;
                        return true;
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                });
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        /// <summary>
        ///    Flashes a red border around the element
        /// </summary>
        /// <param name="flashes">number of times to flash. default is 3 times.</param>
        /// <returns>none</returns>
        public static void Highlight(this IWebElement element, int flashes = 3)
        {
            element.ScrollIntoView();
            string style = element.GetAttribute("style") ?? "";
            IJavaScriptExecutor js = (IJavaScriptExecutor)FastDriver.WebDriver;
            try
            {
                for (int i = 1; i <= flashes; i++)
                {
                    //"color: red; border: 3px solid red; background-color: yellow;");
                    js.ExecuteScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: red; border: 3px solid red;" + style);
                    System.Threading.Thread.Sleep(250);
                    js.ExecuteScript("arguments[0].setAttribute('style', arguments[1]);", element, style);
                }
            }
            catch (Exception e)
            {
                Reports.PrintLog("Hight light failed. " + e.Message); // debug message
            }
        }

        //public static bool IsDisplayed(this IWebElement element)
        //{
        //    bool reVal = false;

        //    try
        //    {
        //        reVal = element.Displayed;
        //    }
        //    catch
        //    {
        //        // just continue
        //}

        //    return reVal;
        //}

        public static bool IsVisible(this IWebElement element, int timeoutSeconds = 1)
        {
            var wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromMilliseconds(timeoutSeconds));
            try
            {
                wait.Until(FAExpectedConditions.ElementIsVisible(element));
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Overload for IsVisible method. This one ignores the element instance and instead waits for the locator param to be visible.
        /// </summary>
        /// <param name="element"> this will be ignored </param>
        /// <param name="locator"> Will wait for this one instead </param>
        /// <param name="timeoutSeconds"></param>
        /// <returns></returns>
        public static bool IsVisible(this IWebElement element, By locator, int timeoutSeconds = 1)
        {
            var wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromMilliseconds(timeoutSeconds));
            try
            {
                wait.Until(ExpectedConditions.ElementIsVisible(locator));
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
            return true;
        }

        public static bool IsEnabled(this IWebElement element)
        {
            try
            {
                return element.Enabled;
            }
            catch
            {
                return false;
            }

        }

        //public static bool IsSelected(this IWebElement element)
        //{
        //    return element.Selected;
        //}

        public static bool IsReadOnly(this IWebElement element)
        {
            var isReadOnly = element.GetAttribute("readonly");

            return isReadOnly != null ? Convert.ToBoolean(isReadOnly) : false;
        }

        public static void GiveFocus(this IWebElement element)
        {
            element.SendKeys("");
        }

        public static OperationResult PerformGridAction(this IWebElement element, string column, string searchValue, string cell, TableAction action, string value = "")
        {
            return Report.UpdateLog<OperationResult>(element, "Grid Action", string.Format("Col '{0}': '{1}'; Cell '{2}': {3}", column, searchValue, cell, action.ToString()), value, () =>
            {
                return InternalPerformGridAction(element, column, searchValue, cell, action, value);
            });
        }

        private static OperationResult InternalPerformGridAction(IWebElement element, string column, string searchValue, string cell, TableAction action, string value = "")
        {
            int searchColumnIndex = 0;
            int actionColumnIndex = 0;
            int rowIndex = 0;
            IWebElement headerDiv = null;
            IWebElement bodyDiv = null;
            IWebElement actionCell = null;

            if (column == string.Empty || column == null || cell == string.Empty || cell == null) //should provide valid search values
                throw new Exception("Please provide all columns required information");

            try
            {
                headerDiv = element.FindElement(By.XPath(".//div[@class='ui-grid-header-cell-row']"));
                bodyDiv = element.FindElement(By.XPath(".//div[@class='ui-grid-canvas']"));

                searchColumnIndex = GetColumnIndexFromSearchText(headerDiv, column);
                actionColumnIndex = GetColumnIndexFromSearchText(headerDiv, cell);
                rowIndex = GetRowIndexFromCellText(bodyDiv, searchValue, searchColumnIndex);

                actionCell = bodyDiv.FindElement(By.XPath(".//div[" + rowIndex.ToString() + "]/div[@role='row']/div[" + actionColumnIndex.ToString() + "]"));
            }
            catch (Exception) //capture expection and try looking for header row on sibling table
            {

                throw new NoSuchElementException("Can't find element with specified value: " + searchValue + " on column: " + column);
            }

            return PerformGridAction(action, actionCell, value);
        }

        /// <summary>
        /// Performs an action on the specified table cell based on the given arguments.
        /// </summary>
        /// <param name="columnToSearchIndex">The index of the column to search. (Base 1)</param>
        /// <param name="searchValue">The value to search within the column.</param>
        /// <param name="actionCellIndex">The index of the cell where the action will be performed. (Base 1)</param>
        /// <param name="value">The text to write in the cell (only for input cells).</param>
        /// <returns></returns>
        public static OperationResult PerformTableAction(this IWebElement element, int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int startOffRow = 1)
        {
            //WaitForElement(element, 10);
            return Report.UpdateLog<OperationResult>(element, "Table Action", string.Format("Col #{0}: '{1}'; Cell #{2}: {3}", columnToSearchIndex, searchValue, actionCellIndex, action.ToString()), value, () =>
            {
                return InternalPerformTableAction(element, columnToSearchIndex, searchValue, actionCellIndex, action, value, startOffRow);
            });
        }

        /// <summary>
        /// Performs an action on the specified table cell based on the given arguments. 
        /// <para>Usages:</para>
        /// <para>2: element.PerformTableAction("Description", "Escrow Fee", "Sel", TableAction.On);</para>
        /// <para>4: element.PerformTableAction("Description", "Escrow Fee", "#1", TableAction.On);</para>
        /// <para>3: element.PerformTableAction("#2", "Escrow Fee", "Sel", TableAction.On);</para>
        /// <para>1: element.PerformTableAction("#2", "Escrow Fee", "#1", TableAction.On);</para>
        /// </summary>
        /// <param name="column">Column header text or base 1 index.</param>
        /// <param name="searchValue">The value to search within the column.</param>
        /// <param name="cell">Column header text or base 1 index, this is used to know which cell to interact with after finding a row tha matches the previous search criteria.</param>
        /// <param name="action">Action to be performed in the result table cell.</param>
        /// <param name="value">Optional. Only used in Set methods.</param>
        /// <returns></returns>
        public static OperationResult PerformTableAction(this IWebElement element, string column, string searchValue, string cell, TableAction action, string value = "")
        {
            //WaitForElement(element, 10);
            return Report.UpdateLog<OperationResult>(element, "Table Action", string.Format("Col '{0}': '{1}'; Cell '{2}': {3}", column, searchValue, cell, action.ToString()), value, () =>
            {
                return InternalPerformTableAction(element, column, searchValue, cell, action, value);
            });
        }

        public static OperationResult PerformTableAction(this IWebElement element, int rowIndex, int columnIndex, TableAction action, string value = "", bool countVisibles = true)
        {
            return Report.UpdateLog<OperationResult>(element, "Table Action", string.Format("Row index: {0}; Cell index: {1}; Action: {2}", rowIndex, columnIndex, action.ToString()), value, () =>
            {
                if (rowIndex < 1 || columnIndex < 1)
                    throw new Exception("To search table using row/col index, index should start at 1");

                //WaitForElement(element, 10);
                IWebElement tableCell = null;
                try // Try new search method using xpath
                {
                    string tbody = ".";
                    if (element.FindElement(By.XPath("./tbody")) != null)
                        tbody = "./tbody";

                    if (countVisibles)
                        tableCell = element.FindElement(By.XPath(tbody + "//tr[not(contains(@style,'display: none') or contains(@style,'display:none'))][" + rowIndex + "]/td[" + columnIndex + "]"));
                    else
                        tableCell = element.FindElement(By.XPath(tbody + "//[" + rowIndex + "]/td[" + columnIndex + "]"));
                }
                catch (Exception) //Try old search method if exception was thrown
                {
                    try
                    {
                        if (countVisibles)
                            tableCell = element.FindElements(By.TagName("tr")).GetAllVisible()[rowIndex - 1].FindElements(By.TagName("td")).GetAllVisible()[columnIndex - 1];
                        else
                            tableCell = element.FindElements(By.TagName("tr"))[rowIndex - 1].FindElements(By.TagName("td"))[columnIndex - 1];
                    }
                    catch (NoSuchElementException)
                    {
                        throw new NoSuchElementException(string.Format("Could not find cell using row index {0} and column index {1}", rowIndex, columnIndex));
                    }
                }

                try
                {
                    return PerformAction(action, tableCell, value);
                }
                catch (StaleElementReferenceException)
                {
                    Playback.Wait(1000);
                    return PerformAction(action, tableCell, value);
                }
            });
        }

        #region Private Members
        private static OperationResult InternalPerformTableAction(IWebElement element, string column, string searchValue, string cell, TableAction action, string value = "")
        {
            int columnToSearchIndex = 0;
            int actionCellIndex = 0;
            IWebElement headerRow = null;

            if (column == string.Empty || column == null || cell == string.Empty || cell == null) //should provide valid search values
                throw new Exception("Please provide all columns required information");

            try //if this blocks throws, it means the mapped table did not have header row
            {
                headerRow = element.FindElements(By.TagName("tr")).FirstOrDefault(row => row.Displayed); //search for the first row in table
                columnToSearchIndex = column.StartsWith("#") ? int.Parse(column.Replace("#", string.Empty)) : GetIndexFromHeaderText(headerRow, column);
                actionCellIndex = cell.StartsWith("#") ? int.Parse(cell.Replace("#", string.Empty)) : GetIndexFromHeaderText(headerRow, cell);
            }
            catch (NoSuchElementException) //capture expection and try looking for header row on sibling table
            {
                try
                {
                    IWebElement headerTable = element.FindElement(By.XPath("./../../../../tr[1]/td[1]/table")); //find sibling table (this should be the header one..)
                    IWebElement tableHeader = headerTable.FindElements(By.TagName("tr")).FirstOrDefault(row => row.Displayed); //first table row (should be the header)

                    columnToSearchIndex = column.StartsWith("#") ? int.Parse(column.Replace("#", string.Empty)) : GetIndexFromHeaderText(tableHeader, column);
                    actionCellIndex = cell.StartsWith("#") ? int.Parse(cell.Replace("#", string.Empty)) : GetIndexFromHeaderText(tableHeader, cell);
                }
                catch (NoSuchElementException)
                {
                    throw new NoSuchElementException("Couldn't locate the specified header columns. Try a diferent criteria.");
                }
            }

            return InternalPerformTableAction(element, columnToSearchIndex, searchValue, actionCellIndex, action, value);
        }

        private static OperationResult InternalPerformTableAction(IWebElement element, int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int startOffRow = 1)
        {
            OperationResult result;
            result.Status = OperationStatus.Fail;
            int FoundOnRow = 0;
            IWebElement tableCell;
            List<IWebElement> allRows;

            if (columnToSearchIndex == 0 || actionCellIndex == 0)
                throw new Exception("Column and Cell index values must be 1 or higher");

            try
            {
                // these 3 lines should be able to replace the rest of this "try" code block
                //IWebElement row = element.FindElement(By.XPath(".//tr/td[" + columnToSearchIndex + "]//*[text()='" + searchValue + "']/ancestor::tr[1]"));
                //tableCell = row.FindElement(By.CssSelector("td:nth-child(" + actionCellIndex + ")"));
                //int.TryParse(row.GetAttribute("rowIndex"), out FoundOnRow);

                try
                {
                    // On large tables, the 2nd search method takes a long time, I'm keeping the 2nd search method just in case first one doesn't work on some tables
                    if (element.FindElements(By.XPath(".//tr/td[" + columnToSearchIndex + "][text()='" + searchValue + "']/ancestor::tr[1]")).Count > 0)                // 1st search
                        allRows = element.FindElements(By.XPath(".//tr/td[" + columnToSearchIndex + "][text()='" + searchValue + "']/ancestor::tr[1]")).ToList();
                    else if (element.FindElements(By.XPath(".//tr/td[" + columnToSearchIndex + "]//*[text()='" + searchValue + "']/ancestor::tr[1]")).Count > 0)        // 2nd search
                        allRows = element.FindElements(By.XPath(".//tr/td[" + columnToSearchIndex + "]//*[text()='" + searchValue + "']/ancestor::tr[1]")).ToList();
                    else
                        allRows = element.FindElements(By.TagName("tr")).Where(rows => rows.Displayed && rows.GetAttribute("innerHTML").Contains("<td")).ToList();      // 3rd search
                }
                catch (Exception)
                {
                    // Try the old search method
                    allRows = element.FindElements(By.TagName("tr")).Where(rows => rows.Displayed && rows.GetAttribute("innerHTML").Contains("<td")).ToList();
                }

                var len = allRows.Count();
                IWebElement row = null;
                for (int i = 1; i <= len; i++)
                {
                    if (i < startOffRow)
                        continue;

                    var tempRow = allRows[i - 1];

                    Func<IWebElement, bool> isFoundInText = (x) =>
                    {
                        try
                        {
                            string rowText = x.FindElement(By.CssSelector("td:nth-child(" + columnToSearchIndex + ")")).Text;
                            if (rowText.Clean() == searchValue.Clean())
                            {
                                return true;
                            }
                        }
                        catch (NotFoundException) { }

                        return false;
                    };

                    Func<IWebElement, bool> isFoundInSpanTags = (x) =>
                    {
                        try
                        {
                            List<IWebElement> allSpanTags = x.FindElements(By.XPath(".//td[" + columnToSearchIndex + "]//span")).ToList();
                            if (allSpanTags.Count != 0)
                            {
                                foreach (var tempSpan in allSpanTags)
                                {
                                    string rowText = tempSpan.Text;
                                    if (rowText.Clean() == searchValue.Clean())
                                    {
                                        return true;
                                    }

                                }
                            }
                        }
                        catch (NotFoundException) { }

                        return false;
                    };

                    Func<IWebElement, bool> isFoundInInputTags = (x) =>
                    {
                        try
                        {
                            List<IWebElement> allInputTags = x.FindElements(By.CssSelector("td:nth-child(" + columnToSearchIndex + ") input")).GetAllVisible();
                            if (allInputTags.Count != 0)
                            {
                                foreach (var tempInput in allInputTags)
                                {
                                    string rowText = tempInput.GetAttribute("value");
                                    if (rowText.Clean() == searchValue.Clean())
                                    {
                                        return true;
                                    }

                                }
                            }
                        }
                        catch (NotFoundException)
                        { }

                        return false;
                    };

                    if (isFoundInText(tempRow) || isFoundInSpanTags(tempRow) || isFoundInInputTags(tempRow))
                    {
                        row = tempRow;
                        int.TryParse(row.GetAttribute("rowIndex"), out FoundOnRow);
                        break;
                    }
                }

                tableCell = row.FindElement(By.CssSelector("td:nth-child(" + actionCellIndex + ")"));
            }
            catch (NullReferenceException ex)
            {
                throw new Exception(String.Format("Could not find value {0} in column {1}", searchValue.Trim(), columnToSearchIndex));
            }

            try
            {
                try
                {
                    result = PerformAction(action, tableCell, value);
                }
                catch (StaleElementReferenceException)
                {
                    // Try again after 1 second if get stale element exeption
                    Playback.Wait(1000);
                    result = PerformAction(action, tableCell, value);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Table Action Failed. Details: " + ex.Message);
            }

            // insert row number in result
            result.CurrentRow = FoundOnRow;

            return result;
        }

        private static int GetIndexFromHeaderText(IWebElement headerRow, string searchValue)
        {
            var columnElement = headerRow.FindElements(By.XPath(".//th | .//*[@class='WGh']")).FirstOrDefault(headerCell => headerCell.GetAttribute("textContent").Trim() == searchValue.Trim());
            if (columnElement != null) //found cell that contains 'searchValue' in header 
                return int.Parse(columnElement.GetAttribute("cellIndex")) + 1; //get index and convert to base 1
            else
                throw new NoSuchElementException(string.Format("Column {0} not found", searchValue));
        }

        private static int GetColumnIndexFromSearchText(IWebElement headerDiv, string searchValue)
        {
            ReadOnlyCollection<IWebElement> columnElements = headerDiv.FindElements(By.XPath(".//div[@role='columnheader']"));

            int retVal = 0;

            if (columnElements != null)
            {
                for (int i = 0; i <= columnElements.Count; i++)
                {
                    if (columnElements[i].FindElement(By.XPath(".//span")).Text == searchValue)
                    {
                        retVal = i + 1;
                        break;
                    }
                }

                return retVal;
            }
            else
                throw new NoSuchElementException(string.Format("Column {0} not found", searchValue));
        }

        private static int GetRowIndexFromCellText(IWebElement bodyDiv, string searchValue, int columnIndex)
        {
            ReadOnlyCollection<IWebElement> rowElements = bodyDiv.FindElements(By.XPath(".//div[@role='row']"));

            int retVal = 0;

            if (rowElements != null)
            {
                for (int i = 0; i <= rowElements.Count; i++)
                {
                    if (rowElements[i].FindElement(By.XPath(".//div[" + columnIndex.ToString() + "]/div")).Text == searchValue)
                    {
                        retVal = i + 1;
                        break;
                    }
                }

                return retVal;
            }
            else
                throw new NoSuchElementException(string.Format("Search value {0} not found", searchValue));
        }

        private static OperationResult PerformGridAction(TableAction action, IWebElement actionCell, string value = "")
        {
            OperationResult response = new OperationResult() { Message = "", Status = OperationStatus.Fail, Element = actionCell };

            IWebElement myDivElement = null;
            IWebElement myInputElement = null;
            IWebElement mySelectElement = null;

            switch (action)
            {
                case TableAction.Click:
                    myDivElement = actionCell.FindElement(By.XPath(".//div"));
                    myDivElement.Click();
                    break;
                case TableAction.DoubleClick:
                    myDivElement = actionCell.FindElement(By.XPath(".//div"));
                    new Actions(FastDriver.WebDriver).DoubleClick(myDivElement).Perform();
                    break;
                case TableAction.On:
                    myInputElement = actionCell.FindElement(By.XPath(".//input"));
                    if (!myInputElement.Selected)
                        myInputElement.SendKeys(FAKeys.Space);
                    break;
                case TableAction.Off:
                    myInputElement = actionCell.FindElement(By.XPath(".//input"));
                    if (myInputElement.Selected)
                        myInputElement.SendKeys(FAKeys.Space);
                    break;
                case TableAction.SetText:
                case TableAction.SendKeys:
                    myInputElement = actionCell.FindElement(By.XPath(".//input"));
                    if (value != string.Empty && value != null)
                    {
                        if (action == TableAction.SetText)
                            myInputElement.Clear();
                        myInputElement.SendKeys(value);
                    }
                    break;
                case TableAction.SetTextByCellIndex:
                    myInputElement = actionCell.FindElement(By.XPath(".//input"));
                    if (value != string.Empty && value != null)
                    {
                        myInputElement.Clear();
                        myInputElement.SendKeys(value);
                    }
                    break;
                case TableAction.SelectItem:
                    mySelectElement = actionCell.FindElement(By.XPath(".//select"));
                    if (value != string.Empty && value != null)
                    {
                        new SelectElement(mySelectElement).SelectByText(value);
                        mySelectElement.FireEvent("onchange");
                    }
                    break;
                case TableAction.SelectItemByIndex:
                    mySelectElement = actionCell.FindElement(By.XPath(".//select"));
                    if (value != string.Empty && value != null)
                    {
                        new SelectElement(mySelectElement).SelectByIndex(Convert.ToInt16(value));
                        mySelectElement.FireEvent("onchange");
                    }
                    break;
                case TableAction.GetSelectedItem:
                    mySelectElement = actionCell.FindElement(By.XPath(".//select"));
                    var selectElement = new SelectElement(mySelectElement);
                    if (selectElement.AllSelectedOptions.Count == 0)
                        response.Message = "";
                    else
                        response.Message = selectElement.SelectedOption.Text;
                    break;
                case TableAction.SelectItemBySendkeys:
                    mySelectElement = actionCell.FindElement(By.XPath(".//select"));
                    if (value != string.Empty && value != null)
                    {
                        mySelectElement.SendKeys(value);
                    }
                    break;
                case TableAction.GetText:
                    myDivElement = actionCell.FindElement(By.XPath(".//div"));
                    response.Message = myDivElement.Text;
                    break;
                case TableAction.GetInputValue:
                    myInputElement = actionCell.FindElement(By.XPath(".//input"));
                    response.Message = myInputElement.GetAttribute("value");
                    break;
                case TableAction.GetAttribute:
                    response.Message = actionCell.GetAttribute(value);
                    break;
                case TableAction.GetCell:
                    break;
                default:
                    throw new Exception("The specified table action has not been implemented");
            }
            response.Status = OperationStatus.Success;

            return response;
        }

        private static OperationResult PerformAction(TableAction action, IWebElement tableCell, string value = "")
        {
            OperationResult response = new OperationResult() { Message = "", Status = OperationStatus.Fail, Element = tableCell };

            switch (action)
            {
                case TableAction.Click:
                    tableCell.Click();
                    break;
                case TableAction.DoubleClick:
                    new Actions(FastDriver.WebDriver).DoubleClick(tableCell).Perform();
                    break;
                case TableAction.On:
                    var cellInputOn = tableCell.FindElements(By.TagName("input")).FirstOrDefault(i => i.Displayed);
                    if (!cellInputOn.Selected)
                        cellInputOn.SendKeys(FAKeys.Space);
                    break;
                case TableAction.Off:
                    var cellInputOff = tableCell.FindElements(By.TagName("input")).FirstOrDefault(i => i.Displayed);
                    if (cellInputOff.Selected)
                        cellInputOff.SendKeys(FAKeys.Space);
                    break;
                case TableAction.SetText:
                case TableAction.SendKeys:
                    if (value != string.Empty && value != null)
                    {
                        try
                        {
                            try
                            {
                                var input = tableCell.FindElements(By.TagName("input")).FirstOrDefault(i => i.Displayed);
                                if (action == TableAction.SetText)
                                    input.Clear();
                                input.SendKeys(value);
                            }
                            catch (Exception)
                            {
                                var input = tableCell.FindElements(By.TagName("textarea")).FirstOrDefault(i => i.Displayed);
                                if (action == TableAction.SetText)
                                    input.Clear();
                                input.SendKeys(value);
                            }
                        }
                        catch (Exception) // Closing Disclosure screen, Loan Estimate column is inside a span elemtn not input element
                        {
                            var input = tableCell.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(i => i.Displayed); //some columns has 3 span elements, only one is editable
                            if (action == TableAction.SetText)
                            {
                                input.Click(); // On span elements clear by itself doesn't work, have to click on the element first
                                input.Clear();
                            }
                            input.SendKeys(value);
                        }
                    }
                    break;
                case TableAction.SetTextByCellIndex: //TODO: this will eventually be merged with SetText as a third try, leaving it as if for the time being to avoid negative impact on SetText
                    if (value != string.Empty && value != null)
                    {
                        try
                        {
                            var input = tableCell.FindElements(By.TagName("input")).FirstOrDefault(i => i.Displayed);
                            input.Clear();
                            input.SendKeys(value);
                        }
                        catch (NullReferenceException)
                        {
                            var input = tableCell.FindElements(By.XPath(".//span/input")).FirstOrDefault(i => i.Displayed); //some cells has input tag inside span elemnt
                            input.Clear();
                            input.SendKeys(value);
                        }
                    }
                    break;
                case TableAction.SelectItem:
                    if (value != string.Empty && value != null)
                    {
                        var select = tableCell.FindElements(By.TagName("select")).FirstOrDefault(i => i.Displayed);
                        new SelectElement(select).SelectByText(value);
                        select.FireEvent("onchange");
                    }
                    break;
                case TableAction.SelectItemByIndex:
                    if (value != string.Empty && value != null)
                    {
                        var select = tableCell.FindElements(By.TagName("select")).FirstOrDefault(i => i.Displayed);
                        new SelectElement(select).SelectByIndex(Convert.ToInt16(value));
                        select.FireEvent("onchange");
                    }
                    break;
                case TableAction.GetSelectedItem:
                    var selectItem = tableCell.FindElements(By.TagName("select")).FirstOrDefault(i => i.Displayed);
                    var selectElement = new SelectElement(selectItem);
                    if (selectElement.AllSelectedOptions.Count == 0)
                        response.Message = "";
                    else
                        response.Message = selectElement.SelectedOption.Text;
                    break;
                case TableAction.SelectItemBySendkeys:
                    if (value != string.Empty && value != null)
                    {
                        var select = tableCell.FindElements(By.TagName("select")).FirstOrDefault(i => i.Displayed);
                        select.SendKeys(value);
                    }
                    break;
                case TableAction.GetText:
                    var tableCellText = tableCell.Text;
                    if (string.IsNullOrEmpty(tableCellText))
                        tableCellText = tableCell.GetAttribute("textContent");
                    response.Message = tableCellText;
                    break;
                case TableAction.GetInputValue:
                    var tableCellValue = tableCell.FindElements(By.TagName("input")).GetAllVisible().First().GetAttribute("value");
                    response.Message = tableCellValue;
                    break;
                case TableAction.GetAttribute:
                    //tableCell.Click();
                    var innerElement = tableCell.FindElements(By.TagName("input")).FirstOrDefault(i => i.Displayed);
                    response.Message = innerElement.GetAttribute(value);
                    break;
                case TableAction.GetCell:
                    break;
                case TableAction.GetElementFromTableCell:
                    if (!String.IsNullOrEmpty(value))
                    {
                        response.Element = tableCell.FindElements(By.TagName(value)).FirstOrDefault(i => i.Displayed);
                    }
                    break;
                default:
                    throw new Exception("The specified table action has not been implemented");
            }
            response.Status = OperationStatus.Success;

            return response;
        }

        private static void WaitForElement(IWebElement element, int timeoutSeconds)
        {
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(timeoutSeconds));
            wait.Until(d =>
            {
                try
                {
                    return element.Displayed;
                }
                catch (StaleElementReferenceException)
                {
                    Playback.Wait(500);
                    return element.Displayed;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
            });
        }

        private static Dictionary<string, int> GetColumns(this IWebElement table, string columnName = "Description")
        {
            Dictionary<string, int> columns = new Dictionary<string, int>();
            IWebElement headerRow = null;

            try
            {   //if this blocks throws, it means the mapped table did not have header row
                headerRow = table.FindElement(By.XPath(".//*[text()='" + columnName + "']/ancestor::tr[1]"));
            }
            catch (NoSuchElementException) //capture exception and try looking for header row on sibling table
            {
                try
                {   // have not tested
                    IWebElement headerTable = table.FindElement(By.XPath("./ancesor::table[1]//tr[1]//td[1]//table")); //find sibling table (this should be the header one..)
                    headerRow = headerTable.FindElement(By.XPath(".//*[text()='" + columnName + "']/ancestor::tr[1]"));    //first table row (should be the header)
                }
                catch (NoSuchElementException)
                {
                    headerRow = table.FindElement(By.XPath(".//*[text()[contains(.,'" + columnName + "')]]/ancestor::tr[1]"));
                    //throw new NoSuchElementException("Couldn't locate the specified header columns. Try a diferent criteria.");
                }
            }

            if (headerRow != null)
            {
                var columnElements = headerRow.FindElements(By.CssSelector(".WGh")).GetAllVisible();    // most Charges tables
                if (columnElements.Count == 0)
                    columnElements = headerRow.FindElements(By.TagName("td")).GetAllVisible();          // some Charges tables
                if (columnElements != null)
                {
                    //columns = columnElements.Distinct().ToDictionary(k => k.Text.Trim() != "" ? k.Text.Trim() : k.GetAttribute("cellIndex"), v => int.Parse(v.GetAttribute("cellIndex")) + 1);  // add 1 since we are using 1-based index
                    foreach (var columnElement in columnElements.Where(k => !columns.ContainsKey(k.Text.Trim())))
                    {
                        columns.Add(columnElement.Text.Trim() != "" ? columnElement.Text.Trim() : columnElement.GetAttribute("cellIndex"), int.Parse(columnElement.GetAttribute("cellIndex")) + 1);
                    }
                }
            }

            return columns;
        }

        #endregion

        public static int GetRowCount(this IWebElement table, bool thisTableOnly = false)
        {
            return table.FindElements(By.XPath(string.Format("./tbody{0}tr[not(contains(@style,'display: none') or contains(@style,'display:none'))]", thisTableOnly ? "/" : "//"))).Count;
            //var rows = table.FindElements(By.TagName("tr")).GetAllVisible();
            //return rows.Count();
        }

        private static IWebElement GetNonPageObjectElementInstance(IWebElement element)
        {
            // Using the element directly from the page object giving a null reference exception. Need to contruct a new element using MyByFactory.
            IWebElement non_po_element;
            try { non_po_element = element; } //try to get the By locator of an element that comes from a PO
            catch (NullReferenceException) { non_po_element = element; } //if it throws, it means the element doesn't come from a PO and you shouldn't need to convert it
            return non_po_element; //return the NON-PO element
        }

        public static int GetColumnCount(this IWebElement table, bool countVisibles = true)
        {
            var columns = new List<IWebElement>();
            if (countVisibles)
                columns = table.FindElements(By.CssSelector("tr:nth-child(2) > td")).GetAllVisible();
            else
                columns = table.FindElements(By.CssSelector("tr:nth-child(2) > td")).ToList();

            return columns.Count();
        }

        public static void EnterCharges(this IWebElement table, int Row, double? buyerCharge = null, double? buyerCredit = null, double? borrowerCharge = null, double? borrowerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, string newDescription = null, bool addNewRow = false)
        {
            table.EnterCharges("#" + Row.ToString(), buyerCharge, buyerCredit, borrowerCharge, borrowerCredit, sellerCharge, sellerCredit, loanEstimate, newDescription, addNewRow);
        }

        public static void EnterCharges(this IWebElement table, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? borrowerCharge = null, double? borrowerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, string newDescription = null, bool addNewRow = false)
        {
            int currentRow = 0;
            Dictionary<string, int> columnIndex = table.GetColumns();
            Regex currRow = new Regex(@"^#(\d)");

            Match match = currRow.Match(chargeDescription);
            if (match.Success)
            {
                currentRow = Convert.ToInt32(match.Groups[1].Value) + 1;
            }
            else if (addNewRow)
            {
                currentRow = table.GetRowCount();

                // Check if last row is NOT blank, then tab out from last column to create a new row
                if (table.PerformTableAction(currentRow, 1, TableAction.GetInputValue).Message.Trim() != "")
                {
                    int lastColumn = table.GetColumnCount();
                    table.PerformTableAction(currentRow++, lastColumn, TableAction.SetText, FAKeys.Tab).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                }

                table.PerformTableAction(currentRow, 1, TableAction.SetText, chargeDescription + Keys.Tab).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(500);
            }
            else
            {   // get row number
                currentRow = table.PerformTableAction(columnIndex["Description"], chargeDescription, columnIndex["Description"], TableAction.GetCell).CurrentRow + 1;
            }

            if (buyerCharge.HasValue)
            {
                IWebElement chargeElement = table.PerformTableAction(currentRow, columnIndex["Buyer Charge"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)buyerCharge);
            }

            if (buyerCredit.HasValue)
            {
                var chargeElement = table.PerformTableAction(currentRow, columnIndex["Buyer Credit"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)buyerCredit);
            }

            if (borrowerCharge.HasValue)
            {
                var chargeElement = table.PerformTableAction(currentRow, columnIndex["Borrower Charge"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)borrowerCharge);
            }

            if (borrowerCredit.HasValue)
            {
                var chargeElement = table.PerformTableAction(currentRow, columnIndex["Borrower Credit"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)borrowerCredit);
            }

            if (sellerCharge.HasValue)
            {
                var chargeElement = table.PerformTableAction(currentRow, columnIndex["Seller Charge"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)sellerCharge);
            }

            if (sellerCredit.HasValue)
            {
                var chargeElement = table.PerformTableAction(currentRow, columnIndex["Seller Credit"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)sellerCredit);
            }

            if (loanEstimate.HasValue)
            {
                var chargeElement = table.PerformTableAction(currentRow, columnIndex["Loan Estimate Unrounded"], TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                EnterCharge(chargeElement, (double)loanEstimate);
            }

            if (newDescription != null)
            {
                if (newDescription == "")   // delete description
                {
                    IWebElement cell = table.PerformTableAction(currentRow, columnIndex["Description"], TableAction.SetText, newDescription).Element.FindElements(By.TagName("input")).FirstOrDefault();
                    cell.Clear();
                    cell.SendKeys(FAKeys.Tab);
                }
                else
                {
                    table.PerformTableAction(currentRow, columnIndex["Description"], TableAction.SetText, newDescription).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                }
                Playback.Wait(100);
            }

        }

        private static void EnterCharge(IWebElement chargeElement, double value)
        {
            chargeElement.FASetText(FAKeys.Tab);
            chargeElement.FASetText(value.ToString() + FAKeys.Tab);
            Playback.Wait(100);
        }

        public static void VerifyCharges(this IWebElement table, int Row, string Description = null, double? buyerCharge = null, double? buyerCredit = null, double? borrowerCharge = null, double? borrowerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            table.VerifyCharges("#" + Row.ToString() + Description, buyerCharge, buyerCredit, borrowerCharge, borrowerCredit, sellerCharge, sellerCredit, loanEstimate);
        }

        public static void VerifyCharges(this IWebElement table, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? borrowerCharge = null, double? borrowerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {

            Reports.TestStep = "Verify Charges for " + chargeDescription;

            int currentRow = 0;
            CultureInfo US_format = new CultureInfo("en-US");
            Dictionary<string, int> columnIndex = table.GetColumns();
            Regex currRow = new Regex(@"^#(\d)(\w.*)");

            Match match = currRow.Match(chargeDescription);
            if (match.Success)
                currentRow = Convert.ToInt32(match.Groups[1].Value) + 1;
            else
                currentRow = table.PerformTableAction(columnIndex["Description"], chargeDescription, columnIndex["Description"], TableAction.GetCell).CurrentRow + 1;

            //Survey Charges (table id="cg_dcs") are in title in column#2
            string toolTip = table.FindElement(By.XPath(".//tr[" + currentRow + "]//td[2]//span[@title]")).GetAttribute("title");
            //Dictionary<string, string> Charge = toolTip.Replace("\r\n", "").TrimEnd(';').Split(';').ToDictionary(k => k.Split(':')[0], v => v.Contains("$") == true ? (v.Contains(",") ? v.Substring(v.IndexOf("$") + 1, v.IndexOf(",") - v.IndexOf("$") - 1) : v.Substring(v.IndexOf("$") + 1)) : "");
            Dictionary<string, string> Charge = toolTip.Replace("\r\n", "").TrimEnd(';').Split(';').ToDictionary(k => k.Split(':')[0], v => v.Contains("$") == true ? v.Substring(v.IndexOf("$") + 1) : "");

            if (match.Success)
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Description"], TableAction.GetInputValue).Message.Replace("\t", "").Replace("\r\n", "").Trim();
                string expected = match.Groups[2].Value.Trim();
                Support.AreEqual(expected, actual ?? "", "Charge Description");
            }

            if (buyerCharge.HasValue)
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Buyer Charge"], TableAction.GetText).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try using get value
                    actual = table.PerformTableAction(currentRow, columnIndex["Buyer Charge"], TableAction.GetInputValue).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try get from column 2
                    Charge.TryGetValue("Buyer", out actual);
                string expected = double.Parse(buyerCharge.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Buyer Charge");
            }

            if (buyerCredit.HasValue) // not working
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Buyer Credit"], TableAction.GetText).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try using get value
                    actual = table.PerformTableAction(currentRow, columnIndex["Buyer Credit"], TableAction.GetInputValue).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try get from column 2
                    Charge.TryGetValue("BuyerCredit", out actual);
                string expected = double.Parse(buyerCredit.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Buyer Credit");
            }

            if (borrowerCharge.HasValue)
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Borrower Charge"], TableAction.GetText).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try using get value
                    actual = table.PerformTableAction(currentRow, columnIndex["Borrower Charge"], TableAction.GetInputValue).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try get from column 2
                    Charge.TryGetValue("Borrower", out actual);
                string expected = double.Parse(borrowerCharge.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Borrower Charge");
            }

            if (borrowerCredit.HasValue)    // not working
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Borrower Credit"], TableAction.GetText).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try using get value
                    actual = table.PerformTableAction(currentRow, columnIndex["Borrower Charge"], TableAction.GetInputValue).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try get from column 2
                    Charge.TryGetValue("BorrowerCredit", out actual);
                string expected = double.Parse(borrowerCredit.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Borrower Credit");
            }

            if (sellerCharge.HasValue)
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Seller Charge"], TableAction.GetText).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try using get value
                    actual = table.PerformTableAction(currentRow, columnIndex["Seller Charge"], TableAction.GetInputValue).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try get from column 2
                    Charge.TryGetValue("Seller", out actual);
                string expected = double.Parse(sellerCharge.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Seller Charge");
            }

            if (sellerCredit.HasValue)  // not working
            {
                string actual = table.PerformTableAction(currentRow, columnIndex["Seller Credit"], TableAction.GetText).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try using get value
                    actual = table.PerformTableAction(currentRow, columnIndex["Seller Charge"], TableAction.GetInputValue).Message.Replace(" ", "").Replace("\r\n", "").Replace("\t", "").Trim();
                if (actual == "")   // try get from column 2
                    Charge.TryGetValue("SellerCredit", out actual);
                string expected = double.Parse(sellerCredit.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Seller Credit");
            }

            if (loanEstimate.HasValue)  // not working
            {
                string actual = table.FindElement(By.Id("cg_dcs_" + (currentRow - 2).ToString() + "_tga")).FAGetValue();
                string expected = double.Parse(loanEstimate.ToString()).ToString("N", US_format);
                Support.AreEqual(expected != "0.00" ? expected : "", actual ?? "", "Loan Estimate Unrounded");
            }
        }

        public static void VerifyColumn(this IWebElement table, string column, bool exists = true)
        {
            Dictionary<string, int> columnIndex = table.GetColumns();
            if (exists)
                Reports.UpdateDebugLog(table.Describe(), table.TagName, "Verify", "column exists", column, "", Reports.Result(columnIndex.ContainsKey(column)), "");
            else
                Reports.UpdateDebugLog(table.Describe(), table.TagName, "Verify", "column does not exist", column, "", Reports.Result(!columnIndex.ContainsKey(column)), "");
        }

        public static IWebElement GetParent(this IWebElement element)
        {
            return Report.UpdateLog(element, "GetParent", "", "", () =>
            {
                return element.FindElement(By.XPath("parent::*"));
            });
        }

        public static int FAGetSelectedIndex(this IWebElement element)
        {
            return Report.UpdateLog(element, "Get", " SelectedIndex", "", () =>
            {
                var selectOptions = element.FAGetDropdownOptions();
                return selectOptions.IndexOf(selectOptions.FirstOrDefault(searchContextElement => searchContextElement.IsSelected()));
            });
        }

        public static string FAGetCSSValue(this IWebElement element, string CSSProperty)
        {
            return Report.UpdateLog<string>(element, "Get", " FAGetCSSValue", "", () =>
            {
                string ret;

                try
                {
                    ret = element.GetCssValue(CSSProperty);
                }
                catch (Exception)
                {
                    ret = "";
                }
                return ret;
            });
        }

        public static FontStyleProperties FAGetFontStyleProperties(this IWebElement element)
        {
            return new FontStyleProperties(element);
        }

    }


    public static class WebElementCollectionExtensions
    {
        /// <summary>
        /// Filter a collection of web elements by its visibility.
        /// </summary>
        /// <param name="collection">Collection of web elements</param>
        /// <returns>Collection of visible web elements</returns>
        public static List<IWebElement> GetAllVisible(this IEnumerable<IWebElement> collection, Func<IWebElement, bool> filter = null)
        {
            List<IWebElement> allVisible = new List<IWebElement>();

            return (filter != null) ?
                allVisible = collection.Where(element => element.Displayed).Where(filter).ToList() :
                allVisible = collection.Where(element => element.Displayed).ToList();
        }

        /// <summary>
        /// Convert a collection of web element's text value into a single text.
        /// </summary>
        /// <param name="elementList">Collection of web elements</param>
        /// <param name="separator">Text to separate web element's text value</param>
        /// <returns>Concatenated web element's text values</returns>
        public static string ToString(this IEnumerable<IWebElement> elementList, string separator = "|")
        {
            var elementTexts = elementList.ToStringArray();
            return string.Join(separator, elementTexts);
        }

        /// <summary>
        /// Convert a collection of web elements into a List of web element's text values.
        /// </summary>
        /// <param name="elementList">Collection of web elements</param>
        /// <returns>List of web element's text values</returns>
        public static List<string> ToListString(this IEnumerable<IWebElement> elementList)
        {
            var stringList = new List<string>();
            elementList.ToList().ForEach(ele => stringList.Add(ele.Text));

            return stringList;
        }

        /// <summary>
        /// Convert a collection of web elements into a String Array of web element's text values.
        /// </summary>
        /// <param name="elementList">Collection of web elements</param>
        /// <returns>String Array of web element's text values</returns>
        public static string[] ToStringArray(this IEnumerable<IWebElement> elementList)
        {
            var stringArray = new string[elementList.Count()];
            var list = elementList.ToList();

            for (int i = 0; i < list.Count; i++)
                stringArray[i] = list[i].Text;

            return stringArray;
        }
    
    }
}