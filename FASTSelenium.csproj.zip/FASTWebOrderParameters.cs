﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.DataObjects.IIS
{
    public class FASTWebOrderParameters
    {
        public double loanAmt = 0;
        public double salesPrice = 0;
        public string propertyType = "";
        public string propertyUse = "";
        public string street = "";
        public string city = "";
        public string state = "";
        public string zip = "";
        public string apnTaxNumber = "";
        public string legalDescription = "";
        public string entityType1 = "";
        public string firstName = "";
        public string middleName = "";
        public string lastName = "";
        public string suffix1 = "";
        public string ssn1 = "";
        public string spouseFName1 = "";
        public string spouseMName1 = "";
        public string spouseLName1 = "";
        public string spouseSuffix1 = "";
        public string spouseSsn1 = "";
        public string entityType2 = "";
        public string firstName2 = "";
        public string middleName2 = "";
        public string lastName2 = "";
        public string suffix2 = "";
        public string ssn2 = "";
        public string spouseFName2 = "";
        public string spouseMName2 = "";
        public string spouseLName2 = "";
        public string spouseSuffix2 = "";
        public string spouseSsn2 = "";
    }
}
