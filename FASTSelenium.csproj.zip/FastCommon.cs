﻿using SeleniumInternalHelpers;
using FASTSelenium.Common;

namespace FASTSelenium.PageObjects
{
    public class FastCommon : PageObject
    {

        public static ICDUrlBuilder UrlBuilder;
        public string FullPath
        {
            get
            {
                return this.WebDriver.Url;
            }
        }

        internal string Navigate()
        {
            return this.Host.ToString();
        }

        public FastCommon Navigate(string Url)
        {

            this.WebDriver.Navigate().GoToUrl(Url);
            return this;
        }

        
    }
}
