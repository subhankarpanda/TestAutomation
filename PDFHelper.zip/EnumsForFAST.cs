﻿using System;

using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Reflection;
using System.ComponentModel;

namespace FASTSelenium.Common
{
    /// <summary>
    /// Set of actions that can be perfoemed when using the PerformTableAction extension
    /// </summary>
    public enum TableAction
    {
        /// <summary>To click the table cell</summary>
        Click,
        /// <summary>To double click the table cell</summary>
        DoubleClick,
        /// <summary>To set the table cell option to ON</summary>
        On,
        /// <summary>To set the table cell option to OFF</summary>
        Off,
        /// <summary>To get the inner text of the table cell</summary>
        GetText,
        /// <summary>To get the value of the input element contained within the cell</summary>
        GetAttribute,
        /// <summary>To write on the 'input' element contained within the cell</summary>
        SetText,
        /// <summary>To write on the cell using row/column index</summary>
        SetTextByCellIndex,
        /// <summary>To select an item on the 'select' element contained within the cell</summary>
        SelectItem,
        /// <summary>To select an item on the 'select' element using item index</summary>
        SelectItemByIndex,
        /// <summary>To select an item on the 'select' element contained within the cell by using sendkeys</summary>
        SelectItemBySendkeys,
        /// <summary>Gets the whole cell so you can query any element within</summary>
        GetCell,
        /// <summary>Get the selected item of the select elemtn</summary>
        GetSelectedItem,
        /// <summary>Send keystrokes to the table cell</summary>
        SendKeys,
        /// <summary>Get the value of the first visible input element within the cell</summary>
        GetInputValue,
        /// <summary>Get the element within the cell</summary>
        GetElementFromTableCell
    }

    public enum OperationStatus
    {
        Success,
        Fail
    }

    public enum ClosingDisclosureSection { A, B, C, D, E, E2, F, G, H, I, J, K, L, M, N }

    /// <summary>
    /// Selenium locator.
    /// </summary>
    public enum ByLocator { ClassName, CssSelector, Id, TagName, XPath }

    public enum TaskStatus
    {
        Start,
        Complete,
        Waive
    }

    /// <summary>
    /// To Identify which is type of Buyer/Seller in use
    /// </summary>
    public enum BuyerSellerType
    {
        Individual,
        HusbandWife,
        TrustEstate,
        BusinessEntity
    }

    public class SwitchableWindows
    {

        public static List<string> NameList
        {
            get
            {
                var list = new List<string>();
                list.Add(Support.FASTWindowName);
                list.Add("Print Preview");
                list.Add("Real Time Mail Delivery");
                list.Add("Email Delivery");
                list.Add("Fax Delivery");
                list.Add("Image Doc Delivery");
                list.Add("Print Delivery");
                list.Add("One moment please...");
                list.Add("Blank Page");
                list.Add("FAST View");
                list.Add("Date Down Request");
                list.Add("List Phrases by Phrase Group");
                list.Add("List Templates Using Specific Phrases");
                list.Add("List Phrases by Template");
                list.Add("List Templates by Template Type");
                list.Add("List Phrase Groups by Phrase Type");
                list.Add("The First American Corporation | FAST Closing fastcs");
                list.Add("Order Acknowledgement");
                list.Add("FASTWeb");


                //hacks for FAST windows that only show URLs in the title
                list.Add("Fastimages"); //imaging wires  in outgoing wire approval section
                list.Add("Loading Summary Alerts...");
                list.Add("FAST v5.0");
                list.Add(@"Add'l Lender Updates");
                list.Add("Lender Comments");
                return list;
            }

        }

    }

    public enum FADeliveryMethod
    {
        Print,
        Fax,
        Email,
        Preview,
        ImageDoc,
        PDC,
        AgentFirst,
        RTM,
        LVIS,
        WINTRACK,
        LADOTCOM,
        FASTWeb
    }

    public enum FileSearchType
    {
        FileNo,
        ExternalNo,
        InvoiceNo,
        OutsideRefNo,
        PolicyNo,
        PrincipalRefNo,
        EntityRefNo,
        BusSourceRefNo,
        Any
    }

    public enum FACorporationRole
    {
        [Description("Corporate Administrator")]
        CorporateAdministrator
    }

    public enum FAOfficeRole
    {
        [Description("Claims Underwriting Audit")]
        ClaimsUnderwritingAudit,
        [Description("CPL Creation Add on")]
        CPLCreationAddon,
        [Description("CTAAZ Escrow Assistant")]
        CTAAZEscrowAssistant,
        [Description("CTAAZ Escrow Officer")]
        CTAAZEscrowOfficer,
        [Description("Customer Service 1")]
        CustomerService1,
        [Description("Customer Service 2")]
        CustomerService2,
        [Description("Customer Service w Escrow 1")]
        CustomerServiceWEscrow1,
        [Description("Customer Service w Escrow 2")]
        CustomerServiceWEscrow2,
        [Description("Deposit in Escrow Add On")]
        DepositInEscrowAddOn,
        [Description("Document Preparation")]
        DocumentPreparation,
        [Description("East Escrow Assistant 2")]
        EastEscrowAssistant2,
        [Description("East Escrow Assistant 3")]
        EastEscrowAssistan3,
        [Description("East Escrow Assistant 4-No Dep Rights")]
        EastEscrowAssistant4NoDepRights,
        [Description("East Escrow Officer 1")]
        EastEscrowOfficer1,
        [Description("East Escrow Officer 2")]
        EastEscrowOfficer2,
        [Description("East Escrow Officer 3")]
        EastEscrowOfficer3,
        [Description("East Escrow Officer 4")]
        EastEscrowOfficer4,
        [Description("East Escrow Officer Agent Only")]
        EastEscrowOfficerAgentOnly,
        [Description("IT - all")]
        ITAll,
    }

    public static class EnumHelpers
    {
        public static string GetDescription<T>(this T enumerationValue) where T : struct
        {
            Type type = enumerationValue.GetType();
            if (!type.IsEnum)
            {
                throw new ArgumentException("EnumerationValue must be of Enum type", "enumerationValue");
            }

            //Tries to find a DescriptionAttribute for a potential friendly name
            //for the enum
            MemberInfo[] memberInfo = type.GetMember(enumerationValue.ToString());
            if (memberInfo != null && memberInfo.Length > 0)
            {
                object[] attrs = memberInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attrs != null && attrs.Length > 0)
                {
                    //Pull out the description value
                    return ((DescriptionAttribute)attrs[0]).Description;
                }
            }
            //If we have no description attribute, just return the ToString of the enum
            return enumerationValue.ToString();

        }

        public static void SetRole<T>(this T faRole, bool toggleSelection) where T : struct
        {
            FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
            string role = EnumHelpers.GetDescription<T>(faRole);
            if (toggleSelection)
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction(3, role, 1, TableAction.On);
            else
                FastDriver.RoleSelectionDialog.RolesTable.PerformTableAction(3, role, 1, TableAction.Off);
        }
    }

}
