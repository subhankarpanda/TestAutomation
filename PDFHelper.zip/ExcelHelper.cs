﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace FASTSelenium.Common.Excel
{
    public class ExcelHelper
    {
        private static string _filePath = "not_setup";
        private static string _sheetName = "not_setup";
        private static uint? _headerIndex = null;

        private static void EnsureSetup()
        {
            if (_filePath == "not_setup" || _sheetName == "not_setup" || _headerIndex == null)
                throw new System.Exception("Make sure you setup the ExcelHelper by calling ExcelHelper.Setup().");
        }

        /// <summary>
        /// Sets required ExcelHelper configuration values.
        /// </summary>
        /// <param name="filePath">Absolute file path. I. e.: 'C:\path\to\file.xlsx'</param>
        /// <param name="sheetName">The spreadsheet name. I. e.: Sheet1</param>
        /// <param name="headerIndex">[OPTIONAL] Base 1. The row where the header columns are going to be located. Pass 0 to ignore the value.</param>
        public static void Setup(string filePath, string sheetName, uint? headerIndex = null)
        {
            _filePath = filePath;
            _sheetName = sheetName;
            _headerIndex = headerIndex.HasValue ? headerIndex.Value : 0;
        }

        /// <summary>
        /// Sets cell text using header text as column locator.
        /// </summary>
        /// <param name="headerText">The text to search in the header row.</param>
        /// <param name="rowIndex">The row where the cell will be located.</param>
        /// <param name="text">The value to be set.</param>
        public static void SetTextByHeader(string headerText, uint rowIndex, string text)
        {
            EnsureSetup();
            if (_headerIndex.Value == 0)
                throw new System.Exception("Cannot not locate cells when header row = 0");

            using (var spreadsheetDocument = SpreadsheetDocument.Open(_filePath, true))
            {
                var workSheetPart = spreadsheetDocument.GetWorksheetPartByName(_sheetName);
                string headerReference = spreadsheetDocument.GetCellReference(_sheetName, headerText, _headerIndex.Value);

                string colName = Regex.Replace(headerReference, "[0-9]", "");

                workSheetPart.GetCell(colName, rowIndex).SetText(text);

                workSheetPart.Worksheet.Save();
            }
        }

        /// <summary>
        /// Sets cell text using column name as column locator.
        /// </summary>
        /// <param name="columnName">The column name as seen in Excel. I. e.: A, B, C, ..., AA, BB, CC</param>
        /// <param name="rowIndex">The row where the cell will be located.</param>
        /// <param name="text">The value to be set.</param>
        public static void SetTextByColumn(string columnName, uint rowIndex, string text)
        {
            EnsureSetup();

            using (var spreadsheetDocument = SpreadsheetDocument.Open(_filePath, true))
            {
                var workSheetPart = spreadsheetDocument.GetWorksheetPartByName(_sheetName);

                workSheetPart.GetCell(columnName, rowIndex).SetText(text);

                workSheetPart.Worksheet.Save();
            }
        }
    }

    public static class SpreadsheetDocumentExtensions
    {
        public static string GetCellReference(this SpreadsheetDocument spreadsheetDocument, string sheetName, string textToFind, uint rowIndex)
        {
            var workBookPart = spreadsheetDocument.WorkbookPart;
            var workSheetPart = spreadsheetDocument.GetWorksheetPartByName(sheetName);

            SharedStringTablePart stringTable = workBookPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault();

            var row = workSheetPart.Worksheet.GetRow(rowIndex);

            if (row != null)
            {
                foreach (Cell c in row.Elements<Cell>())
                {
                    string cellText;

                    if (c.DataType == CellValues.SharedString)
                    {
                        //the value will be a number which is an index into the shared strings table
                        int index = int.Parse(c.CellValue.InnerText);
                        cellText = stringTable.SharedStringTable.ElementAt(index).InnerText;
                    }
                    else
                    {
                        //just take the value from the cell (note this won't work for dates and other types)
                        cellText = c.CellValue.InnerText;
                    }

                    if (cellText == textToFind)
                    {
                        return c.CellReference;
                    }
                }
            }

            return null;
        }

        public static WorksheetPart GetWorksheetPartByName(this SpreadsheetDocument document, string sheetName)
        {
            IEnumerable<Sheet> sheets = document.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>().Where(s => s.Name == sheetName);

            string relationshipId = sheets.First().Id.Value;
            WorksheetPart worksheetPart = (WorksheetPart)document.WorkbookPart.GetPartById(relationshipId);

            return worksheetPart;
        }
    }

    public static class CellExtensions
    {
        public static Cell SetText(this Cell cell, string value)
        {
            cell.CellValue = new CellValue(value);
            cell.DataType = new EnumValue<CellValues>(CellValues.String);
            return cell;
        }
    }

    public static class WorksheetPartExtensions
    {
        public static Cell GetCell(this WorksheetPart worksheet, string columnName, uint rowIndex)
        {
            Row row = worksheet.Worksheet.GetRow(rowIndex);

            string cellReference = columnName + rowIndex;

            var cell = row.Elements<Cell>().FirstOrDefault(c => c.CellReference.Value == cellReference);
            if (cell == null)
                throw new System.Exception(string.Format("There's no cell with reference {0}.", cellReference));

            return cell;
        }

        public static Row GetRow(this Worksheet worksheet, uint rowIndex)
        {
            var row = worksheet.GetFirstChild<SheetData>().Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
                throw new System.Exception(string.Format("There's no row with index {0}.", rowIndex));

            return row;
        }

        //public static Row AddRow(this Worksheet worksheet)
        //{
        //    var lastRow = worksheet.GetFirstChild<SheetData>().Elements<Row>().Last();
        //    var row = worksheet.InsertAfter<Row>(new Row() { RowIndex = lastRow.RowIndex + 1 }, lastRow);
        //    worksheet.Save();
        //    return row;
        //}
    }

}
