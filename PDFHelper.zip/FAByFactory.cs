﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.Common
{
    //public static class FAByFactory
    //{
        //public static By From<T>(Expression<Func<T>> elementInExpression)
        //{
        //    return From(ReflectionUtility.GetPropertyAttribute(elementInExpression));
        //}

        //public static By From(PageObject pageObject, string propertyName)
        //{
        //    Attribute[] MyAttributes;
        //    try
        //    {
        //        var memberInfo = pageObject.GetType().GetProperty(propertyName);
        //        MyAttributes = Attribute.GetCustomAttributes(memberInfo, true);
        //        if (MyAttributes.Length == 0)
        //            throw new NullReferenceException("No attributes found on property: " + propertyName);
        //    }
        //    catch (Exception e)
        //    {
        //        throw new NullReferenceException(e.Message);
        //    }

        //    return From(MyAttributes.First<Attribute>(p => p.GetType() == typeof(FindsByAttribute)) as FindsByAttribute);
        //}

        //public static By From(IWebElement element)
        //{
        //    try
        //    {
        //        // Retrieve a FieldInfo instance corresponding to the field
        //        FieldInfo field = element.GetType().GetField("bys", BindingFlags.Instance | BindingFlags.NonPublic);

        //        List<By> fields = (List<By>)field.GetValue(element);
        //        // Retrieve the value of the field, and cast as necessary
        //        return fields.FirstOrDefault();
        //    }
        //    catch (NullReferenceException)
        //    {
        //        throw new NullReferenceException(string.Format("Couldn't find By attribute for element"));
        //    }
        //}

        //private static By From(FindsByAttribute attribute)
        //{
        //    var how = attribute.How;
        //    var usingValue = attribute.Using;
        //    switch (how)
        //    {
        //        case How.Id:
        //            return By.Id(usingValue);
        //        case How.Name:
        //            return By.Name(usingValue);
        //        case How.TagName:
        //            return By.TagName(usingValue);
        //        case How.ClassName:
        //            return By.ClassName(usingValue);
        //        case How.CssSelector:
        //            return By.CssSelector(usingValue);
        //        case How.LinkText:
        //            return By.LinkText(usingValue);
        //        case How.PartialLinkText:
        //            return By.PartialLinkText(usingValue);
        //        case How.XPath:
        //            return By.XPath(usingValue);
        //        case How.Custom:
        //            if (attribute.CustomFinderType == null)
        //            {
        //                throw new ArgumentException("Cannot use How.Custom without supplying a custom finder type");
        //            }

        //            if (!attribute.CustomFinderType.IsSubclassOf(typeof(By)))
        //            {
        //                throw new ArgumentException("Custom finder type must be a descendent of the By class");
        //            }

        //            ConstructorInfo ctor = attribute.CustomFinderType.GetConstructor(new Type[] { typeof(string) });
        //            if (ctor == null)
        //            {
        //                throw new ArgumentException("Custom finder type must expose a public constructor with a string argument");
        //            }

        //            By finder = ctor.Invoke(new object[] { usingValue }) as By;
        //            return finder;
        //    }

        //    throw new ArgumentException(string.Format(CultureInfo.InvariantCulture, "Did not know how to construct How from how {0}, using {1}", how, usingValue));
        //}
    //}

    //public static class ReflectionUtility
    //{
    //    public static string GetPropertyName<T>(Expression<Func<T>> expression)
    //    {
    //        MemberExpression body = (MemberExpression)expression.Body;
    //        return body.Member.Name;
    //    }

    //    public static FindsByAttribute GetPropertyAttribute<T>(Expression<Func<T>> expression)
    //    {
    //        MemberExpression body = (MemberExpression)expression.Body;
    //        return body.Member.GetCustomAttribute(typeof(FindsByAttribute)) as FindsByAttribute;
    //    }
    //}
}
