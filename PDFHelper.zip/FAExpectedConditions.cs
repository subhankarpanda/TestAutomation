﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.Common
{
    public class FAExpectedConditions
    {
        public static Func<IWebDriver, IAlert> AlertIsPresent()
        {
            return (driver) =>
            {
                try
                {
                    return driver.SwitchTo().Alert();
                }
                catch (NoAlertPresentException)
                {
                    return null;
                }
            };
        }

        public static Func<IWebDriver, bool> ElementIsVisible(IWebElement element)
        {
            return (driver) =>
            {
                try
                {
                    return element.Displayed;
                }
                catch
                {
                    return false;
                }
            };
        }

        public static Func<IWebDriver, bool> ElementIsNotVisible(IWebElement element)
        {
            return (driver) =>
            {
                try
                {
                    return !element.Displayed;
                }
                catch (Exception e)
                {
                    return true;
                }
            };
        }

        public static Func<IWebDriver, bool> ElementIsEnabled(IWebElement element)
        {
            return (driver) =>
            {
                try
                {
                    return element.Enabled;
                }
                catch
                {
                    return false;
                }
            };
        }

        public static Func<IWebDriver, bool> ElementIsDisabled(IWebElement element)
        {
            return (driver) =>
            {
                try
                {
                    return !element.Enabled;
                }
                catch
                {
                    return false;
                }
            };
        }
    }
}
