﻿using OpenQA.Selenium;
using System;

namespace FASTSelenium.Common
{
    public static class FAKeys
    {
        // Summary:
        //     Represents the number pad addition key.
        public static string Add { get { return Keys.Add; } }
        //
        // Summary:
        //     Represents the Alt key.
        public static string Alt { get { return Keys.Alt; } }
        //
        // Summary:
        //     Represents the Left arrow key.
        public static string ArrowDown { get { return Keys.ArrowDown; } }
        //
        // Summary:
        //     Represents the left arrow key.
        public static string ArrowLeft { get { return Keys.ArrowLeft; } }
        //
        // Summary:
        //     Represents the right arrow key.
        public static string ArrowRight { get { return Keys.ArrowRight; } }
        //
        // Summary:
        //     Represents the up arrow key.
        public static string ArrowUp { get { return Keys.ArrowUp; } }
        //
        // Summary:
        //     Represents the Backspace key.
        public static string Backspace { get { return Keys.Backspace; } }
        //
        // Summary:
        //     Represents the Cancel keystroke.
        public static string Cancel { get { return Keys.Cancel; } }
        //
        // Summary:
        //     Represents the Clear keystroke.
        public static string Clear { get { return Keys.Clear; } }
        //
        // Summary:
        //     Represents the function key COMMAND.
        public static string Command { get { return Keys.Command; } }
        //
        // Summary:
        //     Represents the Control key.
        public static string Control { get { return Keys.Control; } }
        //
        // Summary:
        //     Represents the number pad decimal separator key.
        public static string Decimal { get { return Keys.Decimal; } }
        //
        // Summary:
        //     Represents the Delete key.
        public static string Delete { get { return Keys.Delete; } }
        //
        // Summary:
        //     Represents the number pad division key.
        public static string Divide { get { return Keys.Divide; } }
        //
        // Summary:
        //     Represents the Left arrow key.
        public static string Down { get { return "{DOWN}"; } }
        //
        // Summary:
        //     Represents the End key.
        public static string End { get { return Keys.End; } }
        //
        // Summary:
        //     Represents the Enter key.
        public static string Enter { get { return Keys.Enter; } }
        //
        // Summary:
        //     Represents the equal sign key.
        public static string Equal { get { return Keys.Equal; } }
        //
        // Summary:
        //     Represents the Escape key.
        public static string Escape { get { return "{ESC}"; } }
        //
        // Summary:
        //     Represents the function key F1.
        public static string F1 { get { return Keys.F1; } }
        //
        // Summary:
        //     Represents the function key F10.
        public static string F10 { get { return Keys.F10; } }
        //
        // Summary:
        //     Represents the function key F11.
        public static string F11 { get { return Keys.F11; } }
        //
        // Summary:
        //     Represents the function key F12.
        public static string F12 { get { return Keys.F12; } }
        //
        // Summary:
        //     Represents the function key F2.
        public static string F2 { get { return Keys.F2; } }
        //
        // Summary:
        //     Represents the function key F3.
        public static string F3 { get { return Keys.F3; } }
        //
        // Summary:
        //     Represents the function key F4.
        public static string F4 { get { return Keys.F4; } }
        //
        // Summary:
        //     Represents the function key F5.
        public static string F5 { get { return Keys.F5; } }
        //
        // Summary:
        //     Represents the function key F6.
        public static string F6 { get { return Keys.F6; } }
        //
        // Summary:
        //     Represents the function key F7.
        public static string F7 { get { return Keys.F7; } }
        //
        // Summary:
        //     Represents the function key F8.
        public static string F8 { get { return Keys.F8; } }
        //
        // Summary:
        //     Represents the function key F9.
        public static string F9 { get { return Keys.F9; } }
        //
        // Summary:
        //     Represents the Help keystroke.
        public static string Help { get { return Keys.Help; } }
        //
        // Summary:
        //     Represents the Home key.
        public static string Home { get { return Keys.Home; } }
        //
        // Summary:
        //     Represents the Insert key.
        public static string Insert { get { return Keys.Insert; } }
        //
        // Summary:
        //     Represents the left arrow key.
        public static string Left { get { return Keys.Left; } }
        //
        // Summary:
        //     Represents the Alt key.
        public static string LeftAlt { get { return Keys.LeftAlt; } }
        //
        // Summary:
        //     Represents the Control key.
        public static string LeftControl { get { return Keys.LeftControl; } }
        //
        // Summary:
        //     Represents the Shift key.
        public static string LeftShift { get { return Keys.LeftShift; } }
        //
        // Summary:
        //     Represents the function key META.
        public static string Meta { get { return Keys.Meta; } }
        //
        // Summary:
        //     Represents the number pad multiplication key.
        public static string Multiply { get { return Keys.Multiply; } }
        //
        // Summary:
        //     Represents the NUL keystroke.
        public static string Null { get { return Keys.Null; } }
        //
        // Summary:
        //     Represents the number pad 0 key.
        public static string NumberPad0 { get { return Keys.NumberPad0; } }
        //
        // Summary:
        //     Represents the number pad 1 key.
        public static string NumberPad1 { get { return Keys.NumberPad1; } }
        //
        // Summary:
        //     Represents the number pad 2 key.
        public static string NumberPad2 { get { return Keys.NumberPad2; } }
        //
        // Summary:
        //     Represents the number pad 3 key.
        public static string NumberPad3 { get { return Keys.NumberPad3; } }
        //
        // Summary:
        //     Represents the number pad 4 key.
        public static string NumberPad4 { get { return Keys.NumberPad4; } }
        //
        // Summary:
        //     Represents the number pad 5 key.
        public static string NumberPad5 { get { return Keys.NumberPad5; } }
        //
        // Summary:
        //     Represents the number pad 6 key.
        public static string NumberPad6 { get { return Keys.NumberPad6; } }
        //
        // Summary:
        //     Represents the number pad 7 key.
        public static string NumberPad7 { get { return Keys.NumberPad7; } }
        //
        // Summary:
        //     Represents the number pad 8 key.
        public static string NumberPad8 { get { return Keys.NumberPad8; } }
        //
        // Summary:
        //     Represents the number pad 9 key.
        public static string NumberPad9 { get { return Keys.NumberPad9; } }
        //
        // Summary:
        //     Represents the Page Down key.
        public static string PageDown { get { return Keys.PageDown; } }
        //
        // Summary:
        //     Represents the Page Up key.
        public static string PageUp { get { return Keys.PageUp; } }
        //
        // Summary:
        //     Represents the Pause key.
        public static string Pause { get { return Keys.Pause; } }
        //
        // Summary:
        //     Represents the Return key.
        public static string Return { get { return Keys.Return; } }
        //
        // Summary:
        //     Represents the right arrow key.
        public static string Right { get { return Keys.Right; } }
        //
        // Summary:
        //     Represents the semi-colon key.
        public static string Semicolon { get { return Keys.Semicolon; } }
        //
        // Summary:
        //     Represents the number pad thousands separator key.
        public static string Separator { get { return Keys.Separator; } }
        //
        // Summary:
        //     Represents the Shift key.
        public static string Shift { get { return Keys.Shift; } }
        //
        // Summary:
        //     Represents the Spacebar key.
        public static string Space { get { return Keys.Space; } }
        //
        // Summary:
        //     Represents the number pad subtraction key.
        public static string Subtract { get { return Keys.Subtract; } }
        //
        // Summary:
        //     Represents the Tab key.
        public static string Tab { get { return Keys.Tab; } }
        //
        // Summary:
        //     Represents the Tab key when changing element focus.
        public static string TabAway { get { return "{TAB}"; } }//
        // Summary:
        //     Represents the Select All text selection with CTRL+A
        public static string SelectAll { get { return "^A"; } }
        // Summary:
        //     Copy seleted item with CTRL+C
        public static string Copy { get { return "^C"; } }
        // Summary:
        //     Cut selected item with CTRL+X
        public static string Cut { get { return "^X"; } }
        // Summary:
        //     Paste clipboard item with CTRL+V
        public static string Paste { get { return "^V"; } }
        //
        // Summary:
        //     Represents the up arrow key.
        public static string Up { get { return "{UP}"; } }

        //public static void SendKeyCombination(string modifier, string key)
        //{
        //    //needs to be implemented
        //    throw new NotImplementedException("SendKeyConbination method has yet to be implemented.");
        //}
    }
}
