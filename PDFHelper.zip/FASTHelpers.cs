﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using FASTSelenium.DataObjects.IIS;
using OpenQA.Selenium;
using FASTSelenium.PageObjects;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTWCFHelpers.FastEscrowService;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.ImageRecognition;

namespace FASTSelenium.Common
{
    [CodedUITest]
    public class FASTHelpers : MasterTestClass
    {
        private static FASTWCFHelpers.FastFileService.OrderDetailsResponse _file;
        public static FASTWCFHelpers.FastFileService.OrderDetailsResponse File
        {
            get { return _file; }
            set { throw new NotSupportedException("readonly=true"); }
        }

        #region Shared Functionalities

        public static void IRDebugging(bool debuggable, int timeout = 90)
        {
            IRConfig.canSaveScreenSamples = debuggable;
            IRConfig.saveAllSamples = debuggable;
            IRConfig.waitTime = timeout;
        }

        public static bool isIMDFormType()
        {
            return AutoConfig.FormType.ToUpperInvariant() == @"CD";
        }

        public void FAST_Login_IIS_SUPER(bool isSuperUser = true, int? regionId = null)
        {
           
            #region FAST_Login_IIS_SUP
            Reports.TestStep = "FAST_Login_IIS_SUP";

            var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };

            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            if (regionId != null)
                FAST_OpenRegionOrOffice(regionId ?? 0);
        
            #endregion

        }

        public static void FAST_Login_IIS(int fileNo = 0, int? regionId = null, Credentials? credentials = null)
        {
            #region FAST Login IIS
            Reports.TestStep = "FAST Login IIS";
            var _credentials = credentials ?? new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var url = AutoConfig.FASTHomeURL;
            FASTLogin.Login(url, _credentials, true);
            if (fileNo > 0)
            {
                if (regionId != null)
                    FAST_OpenRegionOrOffice(regionId ?? 0);
                FastDriver.TopFrame.SearchFileByFileNumber(fileNo.ToString());
                var fileId = FileService.GetFilesByFileNum(fileNo.ToString(), regionId ?? int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;
                Support.IsTrue((int)fileId > 0, "Is valid FileId ? " + fileId);

                _file = FileService.GetOrderDetails(fileId);
            }
            #endregion
        }

        public static void FAST_Login_ADM(bool isSuperUser = true, int? regionId = null)
        {
            #region FAST Login ADM
            Reports.TestStep = "FAST Login ADM";
            //var credentials = new Credentials() { UserName = Support.GetRunOption(isSuperUser ? "User_Name2" : "User_Name"), Password = Support.GetRunOption(isSuperUser ? "User_Password2" : "User_Password") };
            var credentials = new Credentials() { UserName = isSuperUser ? AutoConfig.UserNameSU : AutoConfig.UserName, Password = isSuperUser ? AutoConfig.UserPasswordSU : AutoConfig.UserPassword };
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

            if (regionId != null)
                FAST_OpenRegionOrOffice(regionId ?? 0);
            #endregion
        }

        public static void FAST_OpenRegionOrOffice(int regionId)
        {
            try
            {
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID(regionId.ToString());
                var currentInfo = FastDriver.BottomFrame.GetCurrentInfo();
                Reports.StatusUpdate("Current region = " + currentInfo["Region"], true);
            }

            catch(Exception ex)
            {
                MasterTestClass.FailTest(GetExceptionInfo(ex));
            }
        }

        public static void FAST_LoadCurrentFile(int? regionId = null)
        {
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.WaitCreation(FastDriver.TopFrame.FileNumberEditBox);
            var fileNo = FastDriver.TopFrame.FileNumberEditBox.FAGetValue();
            var fileId = FileService.GetFilesByFileNum(fileNo.ToString(), regionId ?? int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;
            Support.IsTrue((int)fileId > 0, "Is valid FileId ? " + fileId);

            _file = FileService.GetOrderDetails(fileId);
        }

        public static void FAST_WCF_CreateFile(CreateFileRequest defaultReq)
        {
            var newFile = FileService.CreateFile(defaultReq);
            var fileId = (int)newFile.FileID;
            Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

            _file = FileService.GetOrderDetails(fileId);

            Reports.TestStep = "Search File";
            FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
        }

        public static void WCF_Create_File(string BSOCD = "RESIDENTAL", string TTOCD = "SALE", decimal SPAmt = 100000, string GAB = "508", FASTWCFHelpers.FastFileService.AdditionalRoleType GABRole = FASTWCFHelpers.FastFileService.AdditionalRoleType.None, decimal loanAmt = 0, FASTWCFHelpers.FastFileService.FormType formType = FASTWCFHelpers.FastFileService.FormType.CD, string LenderID = "", bool isTO = true, bool isEO = true, bool isSEO = false, bool hasBuyer = false, bool hasSeller = false, FASTWCFHelpers.FastFileService.PhysicalAddress pAddr = null, FASTWCFHelpers.FastFileService.Product[] products = null, int? regionBUID = null, int? officeBUID = null)
        {
            #region Request
            var request = RequestFactory.GetCreateFileDefaultRequest();
            if (request != null)
            {
                request.File.BusinessSegmentObjectCD = BSOCD;
                request.File.TransactionTypeObjectCD = TTOCD;
                request.File.SalesPriceAmount = SPAmt;
                request.File.BusinessParties = new FASTWCFHelpers.FastFileService.FileBusinessParty[]
                {
                    new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        AdditionalRole = new FASTWCFHelpers.FastFileService.AdditionalRoleList(){ eAddtionalRole = GABRole },
                        AddrBookEntryID = (int)AdminService.GetGABAddressBookEntryId(GAB),
                        RoleTypeObjectCD = "BUSSOURCE"
                    }
                };
                request.File.Properties = new FASTWCFHelpers.FastFileService.Property[] 
                { 
                    new FASTWCFHelpers.FastFileService.Property() 
                    {
                        PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                        {
                            pAddr ?? new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                            { 
                                AddrLine1 = "91 NW Road",
                                //  State is Required
                                State = "CA",   
                                City = "Santa Ana", 
                                County = "Orange", 
                                Country = "USA",
                                Zip = "92701",
                            } 
                        } 
                    } 
                };
                if (!string.IsNullOrEmpty(LenderID))
                {
                    request.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                    {
                        FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = (int)AdminService.GetGABAddressBookEntryId(LenderID) },
                        NewLoanAmount = loanAmt
                    };
                }
                var services = RequestFactory.GetServices(isTO, isEO, isSEO);
                request.File.Services = services;
                if (!hasBuyer) request.File.Buyers = null;
                if (!hasSeller) request.File.Sellers = null;
                request.formType = formType;
                request.File.Products = products;
            }
            #endregion

            var newFile = FileService.CreateFile(request);
            var fileId = (int)newFile.FileID;
            Support.IsTrue((int)(newFile.FileID ?? 0) > 0, "Is valid FileId ? " + fileId);

            _file = FileService.GetOrderDetails(fileId);
        }

        public static void FAST_WCF_File_IIS(string BSOCD = "RESIDENTAL", string TTOCD = "SALE", decimal SPAmt = 100000, string GAB = "508", FASTWCFHelpers.FastFileService.AdditionalRoleType GABRole = FASTWCFHelpers.FastFileService.AdditionalRoleType.None, decimal loanAmt = 0, FASTWCFHelpers.FastFileService.FormType formType = FASTWCFHelpers.FastFileService.FormType.CD, string LenderID = "", bool isTO = true, bool isEO = true, bool isSEO = false, bool hasBuyer = false, bool hasSeller = false, FASTWCFHelpers.FastFileService.PhysicalAddress pAddr = null, FASTWCFHelpers.FastFileService.Product[] products = null, int? regionBUID = null, int? officeBUID = null)
        {
            WCF_Create_File(BSOCD, TTOCD, SPAmt, GAB, GABRole, loanAmt, formType, LenderID, isTO, isEO, isSEO, hasBuyer, hasSeller, pAddr, products);

            Reports.TestStep = "Search File";
            FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
        }

        public static void FAST_Init_File(string GABCode = "508", string LenderID = "", decimal loanAmt = 0, FASTWCFHelpers.FastFileService.AdditionalRoleType GABRole = FASTWCFHelpers.FastFileService.AdditionalRoleType.None, decimal salesPrice = 0)
        {
            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = "Create a basic file";
            FAST_WCF_File_IIS(GAB: GABCode, isTO: true, isEO: true, LenderID: LenderID, SPAmt: salesPrice, loanAmt: loanAmt, GABRole: GABRole);
            #endregion
        }

        public static void FAST_WCF_CreateNewLoan()
        {
            #region Request
            var request = new FASTWCFHelpers.FastFileService.NewLoanRequest()
                {
                    EmployeeID = 1,
                    FileID = _file.FileID,
                    Source = @"FAMOS",
                    LoanDetails = new FASTWCFHelpers.FastFileService.NewLoanDetail()
                    {
                        LenderInformation = new FASTWCFHelpers.FastFileService.PayChargeFileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("488") },
                        eFormType = FASTWCFHelpers.FastFileService.FormType.CD,
                        LoanAmount = (Decimal)199.88,
                    }
                };
            #endregion

            var response = FileService.CreateNewLoan(request);
            Support.AreEqual(response.Status.ToString(), "1");
        }

        public static void FAST_WCF_UpdateNewLoan()
        {
            #region Request
            var request = new FASTWCFHelpers.FastFileService.NewLoanRequest()
                {
                    EmployeeID = 1,
                    FileID = _file.FileID,
                    Source = @"FAMOS",
                    LoanDetails = new FASTWCFHelpers.FastFileService.NewLoanDetail()
                    {
                        LenderInformation = new FASTWCFHelpers.FastFileService.PayChargeFileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("488") },
                        eFormType = FASTWCFHelpers.FastFileService.FormType.CD,
                        LoanAmount = (Decimal)199.88,
                    },
                    MortgageBroker = new FASTWCFHelpers.FastFileService.MortgageBroker()
                    {
                        MorgageBrokerInformation = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("488") },
                    },
                    SeqNum = 1,
                };
            #endregion
            
            var response = FileService.UpdateNewLoan(request);
            Support.AreEqual(response.Status.ToString(), "1");
        }

        public static void FAST_WCF_AddBuyerSeller(string principalType = "Buyer")
        {
            #region Request
            var request = new AddBuyerSellerRequest()
            {
                BuyerSeller = new FASTWCFHelpers.FastFileService.BuyerSeller()
                {
                    BuyerSellerTypeID = 48,
                    FirstName = principalType == "Buyer" ? "Bart" : "Lisa",
                    LastName = "Simpson",
                    CurrentAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress() { 
                        AddrLine1 = "UAT Street",
                        AddrLine2 = "Unit 1",
                        BuyerSellerAddressTypeCdID = 80,
                        City = "Santa Ana",
                        Country = "USA",
                        County = "Orange",
                        State = "CA",
                        Zip = "92701"
                    },
                    SSN = "123456789",
                },
                FileID = _file.FileID ?? 0,
                PrincipalType = principalType,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
            #endregion

            var response = FileService.AddBuyerSeller(request);
            Support.AreEqual(response.Status.ToString(), "1");
        }

        public static void FAST_AddRealStateBroker(bool creditBuyer, bool creditSeller)
        {
            #region Add Real State Broker Agent
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.FindGAB("415");
            FastDriver.RealEstateBrokerAgent.FindAgentGAB("415");
            FastDriver.RealEstateBrokerAgent.TransactionCoordinator.Click();
            FastDriver.TransactionCoordinatorSummary.SwitchToContentFrame();
            FastDriver.TransactionCoordinatorSummary.New.Click();
            //  Address Book Business Organization Search
            FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "388");
            FastDriver.BottomFrame.Done();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            //
            //FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText("50");
            //Keyboard.SendKeys(FAKeys.TabAway);
            if (creditSeller)
            {
                FastDriver.RealEstateBrokerAgent.CreditSellerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FASetText("1,000,000.00");
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (creditBuyer)
            {
                FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.FASetCheckbox(true);
                FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FASetText("1,000,000.00");
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge);
            FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FASetText("500,000.00");
            Keyboard.SendKeys("{DEL 3}{TAB}");
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 10);
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FASetText("500,000.00");
            Keyboard.SendKeys("{DEL 3}{TAB}");
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true, timeout: 10);
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
            FastDriver.RealEstateBrokerAgent.CommisionChargeAmountLoanUnrounded.FASetText("999,999.99");
            FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FASetText("test-real-estate-broker-charge" + FAKeys.Tab);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge);
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge);
            Keyboard.SendKeys("{DEL}");
            FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FASetText("500,000.00");
            Keyboard.SendKeys("{TAB}{DEL}");
            FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FASetText("500,000.00");
            Keyboard.SendKeys("{TAB}{DEL}");
            FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesLoanUnrounded.FASetText("999,999.99");
            if (FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAGetAttribute("class").Contains("ExpandFalse"))
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.Click();
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription);
            Keyboard.SendKeys("{DEL}");
            FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.FASetText("test-real-estate-broker-credits" + FAKeys.Tab);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit);
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit);
            Keyboard.SendKeys("{DEL}");
            FastDriver.RealEstateBrokerAgent.REBBrokerCreditsBuyerCredit.FASetText("500,000.00");
            Keyboard.SendKeys("{TAB}{DEL}");
            FastDriver.RealEstateBrokerAgent.REBBrokerCreditsSellerCredit.FASetText("500,000.00");
            Keyboard.SendKeys("{TAB}{DEL}");
            FastDriver.RealEstateBrokerAgent.REBBrokerCreditsLoanUnrounded.FASetText("999,999.99");
            if (FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.FAGetAttribute("class").Contains("ExpandFalse"))
                FastDriver.RealEstateBrokerAgent.ExpandPOCbyBroker.Click();
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription);
            FastDriver.RealEstateBrokerAgent.POCbyBrokerDescription.FASetText("test-poc-by-broker" + FAKeys.Tab);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.RealEstateBrokerAgent.WaitCreation(FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount);
            Keyboard.SendKeys("{DEL}");
            FastDriver.RealEstateBrokerAgent.POCbyBrokerAmount.FASetText("500,000.00");
            FastDriver.RealEstateBrokerAgent.BuyerBrokerNew.Click();
            FastDriver.RealEstateBrokerAgent.FindDisbursementGAB("488");
            FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText("4,000,000.00");
            FastDriver.BottomFrame.Done();
            #endregion
        }
        
        protected void FAST_WCF_VerifyNewLoanPDD(int fileID, int seqNum, PDD pdd)
        {
            #region Verify New Loan charge PDD after GetNewLoanDetails()
            var details = FileService.GetNewLoanDetails(fileID, seqNum);
            Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
            FAST_WCF_VerifyFilePDD(details.LoanCharges.CDNewLoanCharges[0], pdd);
            #endregion
        }

        protected void FAST_WCF_VerifyNewLoanMBPDD(int fileID, int seqNum, PDD pdd)
        {
            #region Verify New Loan charge PDD after GetNewLoanDetails()
            var details = FileService.GetNewLoanDetails(fileID, seqNum);
            Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
            FAST_WCF_VerifyFilePDD(details.MortgageBroker.CDMortgageBrokerCharges[0], pdd);
            #endregion
        }

        protected FASTWCFHelpers.FastFileService.CDChargePaymentDetails DefaultCDChargePD()
        {
            return new FASTWCFHelpers.FastFileService.CDChargePaymentDetails()
            {
                AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                BuyerCharge = (decimal)100.01,
                Description = "UAT Entry",
                LEAmount = (decimal)500.00,
                SellerCharge = (decimal)100.02,
                SeqNum = 1,
            };
        }

        protected FASTWCFHelpers.FastFileService.CdChargeDetails DefaultCDChargeBSDetails()
        {
            return new FASTWCFHelpers.FastFileService.CdChargeDetails
                {
                    PaidByAtClosing = (decimal)100.01,
                    PaidByBeforeClosing = (decimal)0,
                    PaidByOthers = (decimal)0,
                    PaidByOthersPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    ePaymentMethod = FASTWCFHelpers.FastFileService.PaymentMethodType.CHK,
                };
        }

        protected void FAST_WCF_CreateOutsideEscrowCompany()
        {
            #region Request
            var defaultCharge = DefaultCDChargePD();
            defaultCharge.BuyerCharge = (Decimal)200.01;
            defaultCharge.SellerCharge = (Decimal)200.02;
            var request = new FASTWCFHelpers.FastFileService.OECRequest()
            {
                EmployeeID = 1,
                FileID = _file.FileID,
                OECInformation = new FASTWCFHelpers.FastFileService.OECInformation()
                {
                    OECCharges = new FASTWCFHelpers.FastFileService.OECCharge()
                    {
                        CDPaymentDetails = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { 
                            defaultCharge,
                        },
                    },
                    OECFileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("408"),
                    }
                },
                LoginName = AutoConfig.InterfaceUsername,
                Source = "FAMOS"
            };
            #endregion

            var response = FileService.CreateOutsideEscrowCompany(request);
            Support.AreEqual(response.Status.ToString(), "1");
        }

        protected void FAST_WCF_CreateOutsideTitleCompany()
        {
            #region Request
            var defaultCharge = DefaultCDChargePD();
            defaultCharge.BuyerCharge = (Decimal)300.01;
            defaultCharge.SellerCharge = (Decimal)300.02;
            var request = new CreateOutsideTitleCompanyRequest()
            {
                FileID = _file.FileID,
                OTCDetails = new FASTWCFHelpers.FastFileService.OTCDetails() { 
                    ChargesRetained = (decimal)10000, // Funds Deposited
                    eOTCType = FASTWCFHelpers.FastFileService.OTCType.Attorney,
                },
                OTCLendersPolicyAndEndorsementChargesCD = new FASTWCFHelpers.FastFileService.OTCLendersPolicyAndEndorsementChargesCD()
                {
                    DisplayAggregateOnCD = true,
                    OTCLendersPolicyAndEndorsementChargesListCD = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { defaultCharge },
                    TitlePremiumAdjustment = true,
                },
                OTCOwnersPolicyAndEndorsementChargesCD = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { defaultCharge },
                OTCRecordingFeesAndTransferTaxesCD = null,
                OTCTitleServiceChargesCD = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { defaultCharge },
                OutsideTitleCompanyParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("408"),
                },
                LoginName = AutoConfig.InterfaceUsername,
                Source = "FAMOS"
            };
            #endregion

            var response = FileService.CreateOutsideTitleCompany(request);
            Support.AreEqual(response.OperationResponse.Status.ToString(), "1");
        }

        protected void FAST_WCF_CreateBuyerSellerAttorney()
        {
            #region Request
            var defaultCharge = DefaultCDChargePD();
            defaultCharge.BuyerCharge = (Decimal)400.01;
            defaultCharge.SellerCharge = (Decimal)400.02;
            var request = new CreateBuyerSellerAttorneyRequest()
            {
                AttorneyParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("408"), 
                    RoleTypeObjectCD = "BUYERATTY" },
                AttorneyTypeObjectCD = "702", // number
                CDChargeList = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { defaultCharge },
                FileID = _file.FileID,
                SeqNum = 1,
                Source = "FAMOS",
                UseLatestGabVersion = true,
            };
            #endregion

            var response = FileService.CreateBuyerSellerAttorney(request);
            Support.AreEqual(response.OperationResponse.Status.ToString(), "1");
        }

        protected void FAST_AddAssumptionLoan()
        {
            #region Add Assumption Loan
            FastDriver.AssumptionLoanDetails.Open();
            // Lender Information
            FastDriver.AssumptionLoanDetails.DetailsGABcode.FASetText("388");
            FastDriver.AssumptionLoanDetails.DetailsFind.FAClick();
            // Laon Details
            FastDriver.AssumptionLoanDetails.DetailsLoanType.FASelectItem("Assumption");
            FastDriver.AssumptionLoanDetails.InterestPaidto.FASetText(DateTime.Now.AddDays(7).ToString("MM/dd/yyyy"));
            FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FASetText("50000");
            FastDriver.AssumptionLoanDetails.NextPaymentDue.FASetText(DateTime.Now.ToString("MM/dd/yyyy"));
            // Note Details
            FastDriver.AssumptionLoanDetails.NotedDate.FASetText(DateTime.Now.ToString("MM/dd/yyyy"));
            FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FASetText("5000");
            FastDriver.AssumptionLoanDetails.PaymentAmount.FASetText("5000");
            FastDriver.AssumptionLoanDetails.PaymentType.FASelectItem("Principal & Interest");
            FastDriver.AssumptionLoanDetails.PaymentPer.FASelectItem("Month");
            FastDriver.AssumptionLoanDetails.MaturityDate.FASetText(DateTime.Now.ToString("MM/dd/yyyy"));
            FastDriver.AssumptionLoanDetails.LateCharge.FASetCheckbox(true);
            FastDriver.AssumptionLoanDetails.LateChargeopt1.FAClick();
            FastDriver.AssumptionLoanDetails.LateChargePercentage.FASetText("10");
            FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FASetText("31");
            // ChargeTab
            FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
            Playback.Wait(3000);
            FastDriver.AssumptionLoanDetails.SwitchToContentFrame();
            FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FASetText("7.99");
            FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FASetText("6.99");
            FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
            Playback.Wait(3000);
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            FastDriver.PaymentDetailsDlg.Description.FASetText("UAT Charge-updated");
            FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("7.99");
            FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("6.99");
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(3000);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.AssumptionLoanCharges.SwitchToContentFrame();
            Support.AreEqual("UAT Charge-updated", FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.FAGetAttribute("value"));
            #endregion
        }

        protected string FAST_DisburseCheck(string amount)
        {
            #region PRE-CONDITION
            Reports.TestStep = "Set default check printer";
            FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
            FastDriver.PrinterConfiguration.SetDefaultPrinter();
            #endregion

            #region disburse checks
            Reports.TestStep = "Disburse OEC and OTC checks.";
            FastDriver.ActiveDisbursementSummary.Open();

            // Select disbursements and hit print
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 7, TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Print.Click();
            Playback.Wait(3000);
            FastDriver.PrintChecks.SwitchToContentFrame();
            FastDriver.PrintChecks.Deliver.FAClick();
            Playback.Wait(3000);

            //SDN dialogue
            FastDriver.WebDriver.HandleDialogMessage();
            // Print dialog @ printchecks screen
            FastDriver.PrintDlg.SendPrint("TEXT_FILE_PRINTER");
            Playback.Wait(1000);

            // Overdraft Confirmation
            if (FastDriver.WebDriver.WindowIsDisplayed("Overdraft Confirmation"))
            {
                Keyboard.SendKeys("{ENTER}");
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            else
            { // Password Confirmation
                FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                Playback.Wait(10000);
            }

            //FastDriver.WebDriver.WaitForDeliveryWindow();
            FastDriver.PrintChecks.SwitchToContentFrame();
            var checkNo = FastDriver.PrintChecks.CheckListTable.PerformTableAction(1, amount, 3, TableAction.GetText).Message.Trim();
            FastDriver.BottomFrame.Done();
            Playback.Wait(10000);

            // Verify disbursements are issued
            FastDriver.ActiveDisbursementSummary.Open();
            Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 1, TableAction.GetText).Message.Trim());
            Support.AreEqual(checkNo, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 5, TableAction.GetText).Message.Trim());
            Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 6, TableAction.GetText).Message.Trim());
            #endregion

            return checkNo;
        }

        protected void FAST_DisburseWire(string amount)
        {
            #region disburse wires
            FastDriver.ActiveDisbursementSummary.Open();

            //  Edit disbursement
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 7, TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Edit.Click();
            Playback.Wait(3000);
            FastDriver.EditDisbursement.SwitchToContentFrame();
            FastDriver.EditDisbursement.DisburseAs.FASelectItemBySendingKeys("Wire{ENTER}");
            FastDriver.EditDisbursement.Reference.FASetText("UAT1234");
            FastDriver.EditDisbursement.FromAccount.FASelectItemByIndex(1);
            FastDriver.EditDisbursement.SwitchToContentFrame();
            FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("1234");
            FastDriver.EditDisbursement.ReceivingBankName.FASetText("UAT Bank");
            FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("UAT Street, Unit 1,Santa Ana, California");
            FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("UAT0000");
            FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("UAT0000");

            //  Adding uploaded file
            FastDriver.EditDisbursement.Add.Click();
            FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();

            //  Save
            FastDriver.BottomFrame.Save();
            Playback.Wait(3000);
            FastDriver.BottomFrame.btnDone.Click();

            //  Disburse Wire 
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 1, TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Wire.Click();
            FastDriver.DisburseWires.SwitchToContentFrame();
            FastDriver.DisburseWires.Disburse.Click();
            //SDN Pop up
            FastDriver.WebDriver.HandleDialogMessage();

            //FastDriver.OverdraftConfirmationDlg.ConfirmWireTransfer();
            FastDriver.PasswordConfirmationDlg.ConfirmPassword();

            // Verify disbursement is created
            FastDriver.BottomFrame.Done();
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 1, TableAction.GetText).Message.Trim());
            Support.AreEqual("Wire", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 3, TableAction.GetText).Message.Trim());
            #endregion
        }

        protected void FAST_DisburseFee(string amount)
        {
            #region disburse fee
            FastDriver.ActiveDisbursementSummary.Open();

            // Fee Transfer disbursement
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 7, TableAction.Click);
            FastDriver.ActiveDisbursementSummary.FeeTransfer.Click();
            Playback.Wait(3000);

            //  Confirm passowrd
            FastDriver.PasswordConfirmationDlg.ConfirmPassword();
            Playback.Wait(1000);

            //  Change File Status
            FastDriver.ChangeFileStatusDlg.ConfirmStatus();
            Playback.Wait(1000);

            //  Print
            FastDriver.PrintDlg.SendPrint("TEXT_FILE_PRINTER");
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 1, TableAction.GetText).Message.Trim());
            Support.AreEqual(DateTime.Now.ToDateString(), FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 6, TableAction.GetText).Message.Trim());
            #endregion
        }

        protected void FAST_WCF_UpdateTermsDatesStatus()
        {
            #region Request
            var request = new TermsDatesStatusRequest() { 
                FileID = _file.FileID,
                SettlementDate = DateTime.Now.Add(TimeSpan.FromDays(7)),
                UpdatedEmployeeID = 1,
                Source = "FAMOS"
            };
            #endregion

            FileService.UpdateTermsDatesStatus(request);
        }

        protected string FAST_DepositInEscrow(string amount, string receivedFrom = "Buyer", string typeFund ="Cash", string representing ="Additional Closing Costs", string payorName = "Mr. Burns", string descr="")
        {
            #region Add Deposit in Escrow
            FastDriver.DepositInEscrow.Open();
            FastDriver.DepositInEscrow.Amount.FASetText(amount);
            FastDriver.DepositInEscrow.IssueDte.FASetText(DateTime.Now.ToDateString());
            FastDriver.DepositInEscrow.ReceivedFrom.FASelectItemBySendingKeys(receivedFrom);
            FastDriver.DepositInEscrow.TypeofFunds.FASelectItemBySendingKeys(typeFund);
            FastDriver.DepositInEscrow.Representing.FASelectItemBySendingKeys(representing);
            FastDriver.DepositInEscrow.Description.FASetText(descr);
            FastDriver.DepositInEscrow.Payor.FASetText(payorName);
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.WaitForAlertToExist(10);
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow:true,clickAcceptButton:false);
            FastDriver.DepositInEscrow.SwitchToContentFrame();
            var receiptNo = FastDriver.DepositInEscrow.ReceiptNo.FAGetAttribute("value");
            #endregion

            return receiptNo;
        }

        protected void FAST_AddIBATransaction(string amount)
        {
            #region Add IBA Transaction
            FastDriver.InterestBearingAccounts.Open();
            FastDriver.InterestBearingAccounts.VerifyNewButton();
            FastDriver.InterestBearingAccounts.New.FAClick();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InterestBearingAccounts.SwitchToContentFrame();
            //  Select beneficiary
            FastDriver.WebDriver.FindElement(By.CssSelector("#tabIBADetails_details_cmdBeneficiary")).FAClick();
            FastDriver.SelectIBABeneficiaryDlg.WaitForScreenToLoad();
            FastDriver.SelectIBABeneficiaryDlg.BuyerSelect.Click();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InterestBearingAccounts.SwitchToContentFrame();
            //  Select IBA Bank
            FastDriver.InterestBearingAccounts.IBABank.Click();
            FastDriver.SelectIBABankDlg.WaitForScreenToLoad();
            FastDriver.SelectIBABankDlg.IBABanks.FASelectItemByIndex(1);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.InterestBearingAccounts.SwitchToContentFrame();
            //  Enter amount in Transaction tab
            FastDriver.WebDriver.FindElement(By.CssSelector("#pnlIBADetails .TabControl > a:nth-child(2)")).FAClick();
            FastDriver.InterestBearingAccounts.TransactionTable.PerformTableAction(1, "Open IBA", 4, TableAction.SetText, amount);
            FastDriver.BottomFrame.Save();
            #endregion
        }

        protected void FAST_HoldDisbursement(string amount, string duration, string reason)
        {
            #region hold check
            FastDriver.ActiveDisbursementSummary.Open();

            //  Edit disbursement
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 7, TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Edit.Click();
            Playback.Wait(3000);
            FastDriver.EditDisbursement.SwitchToContentFrame();
            FastDriver.EditDisbursement.HoldInformation.Click();
            FastDriver.EditDisbursement.HoldFor.FASetText(duration);
            FastDriver.EditDisbursement.PurposeOfHold.FASetText(reason);

            //  Save
            FastDriver.BottomFrame.Save();
            Playback.Wait(3000);
            FastDriver.BottomFrame.btnDone.Click();

            // Verify disbursement is created
            FastDriver.BottomFrame.Done();
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, amount, 1, TableAction.GetText).Message.Trim());
            #endregion
        }
        
        protected void FAST_AddFileFees(PDD[] pddArray, string type = "All", bool isTE = true)
        {
            #region FileFees
            FastDriver.FileFees.Open();
            FastDriver.FileFees.AddFees.Click();
            FAST_FeeSearch(pddArray, type);
            //  Verify that Fee is selected
            FastDriver.FileFees.WaitForFeeScreen();

            //  Enter Buyer Charge at closing and Seller Charge at Closing
            if (!isTE)
            {
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
            }

            foreach (PDD paymentDetails in pddArray)
            {
                FAST_UpdateFileFeesPDD(paymentDetails, isTE);
            }
            #endregion
        }

        protected void FAST_FeeSearch(PDD[] pddArray, string type = "All")
        {
            #region Fee Search
            FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.FeeSearchFeeTypes);
            foreach (PDD paymentDetails in pddArray)
            {
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(type);
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(paymentDetails.ChargeDescription);
                FastDriver.FileFees.FindNow.Click();
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.FeeSearchFeeSelect);
                if (paymentDetails.ChargeDescription.Contains("*"))
                    FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
                else
                    FastDriver.FileFees.AddFeeTable.PerformTableAction(2, paymentDetails.ChargeDescription, 1, TableAction.On);
            }
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_AddOTCCalculateFees(string[,] recFees, string[,] summary = null)
        {
            #region Add Calculate Fees
            FastDriver.OTCDetail.Open();
            FastDriver.OTCDetail.CalculateFees.FAClick();
            FAST_SetCalculateFees(recFees, summary);
            #endregion
        }

        protected void FAST_AddFileFeesFACC(string[,] recFees, string[,] summary = null)
        {
            #region Add Calculate Fees
            FastDriver.FileFees.Open();
            FastDriver.FileFees.RecordingFees.FAClick();
            FastDriver.FileFees.CalculateFees.FAClick();
            FAST_SetCalculateFees(recFees, summary);
            #endregion
        }

        protected void FAST_SetCalculateFees(string[,] recFees, string[,] summary = null)
        {
            #region Set Calculate Fees
            FastDriver.CalculateFees.SwitchToContentFrame();
            if (!(FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.RecordingInfoTable) || FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.TransactionInfoTable) || FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.RecordingFeesSummaryTable)))
                throw new Exception("Could not find TransactionInfoTable, RecordingInfoTable not RecordingFeesSummaryTable");
            for (var i = 0; i < recFees.GetLength(0); i++)
            {
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem(recFees[i, 0]);
                FastDriver.CalculateFees.RecordingFeesPages.FASetText(recFees[i, 1]);
                FastDriver.CalculateFees.RecordingFeesConsiderationAmount.FASetText(recFees[i, 2]);
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                FastDriver.CalculateFees.RecordingFeesDocument(i);
            }
            FastDriver.CalculateFees.Next.FAClick();
            if (!(FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.RecordingInfoTable) || FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.TransactionInfoTable)))
                throw new Exception("Could not find TransactionInfoTable, RecordingInfoTable not RecordingFeesSummaryTable");
            FastDriver.CalculateFees.Next.FAClick();
            if (summary != null)
                FAST_UpdateCalculateFeeSummary(summary);
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_AddCalculatedFees(FACCSummary[] faccSummary, string faccUnderwriter = null, string titleProduct = "ALTA Extended Loan Policy")
        {
            #region Navigate to File Fees and click on Calculation Fees
            Reports.TestStep = "Navigate to File Fees and click on Calculation Fees";
            FastDriver.FileFees.Open();
            if (faccUnderwriter != null)
                FastDriver.FileFees.FACCUnderwriter.FASetCheckbox(true);
            FastDriver.FileFees.AllFees.FAClick();
            FastDriver.FileFees.CalculateFees.FAClick();
            #endregion

            #region Add Endorsement and Recording Fees
            Reports.TestStep = "Add Endorsement and Recording Fees";
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.TransactionInfoTable);
            FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem(titleProduct);
            FastDriver.CalculateFees.TitleFeesAdd.FAClick();
            FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.AddEndorsementsButton_Product1);
            FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
            //
            FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();
            FastDriver.FACCEndorsementsDlg.WaitCreation(FastDriver.FACCEndorsementsDlg.SelectEndorsement);
            FastDriver.FACCEndorsementsDlg.SelectEndorsement.FASetCheckbox(true);
            FastDriver.DialogBottomFrame.ClickDone();
            //
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.CalculateFees.waitForScreenToLoad();
            FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Mortgage");
            FastDriver.CalculateFees.RecordingFeesPages.FASetText("1");
            FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
            //
            FastDriver.CalculateFees.Next.FAClick();
            if (FastDriver.WebDriver.WaitForAlertToExist(5))
                FastDriver.WebDriver.HandleDialogMessage(true, true);
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingDocumentsTable);
            FastDriver.CalculateFees.Next.FAClick();
            //
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
            for (int i = 0; i < faccSummary.Count(); i++)
                FastDriver.CalculateFees.EditSummaryFee(index: i, description: faccSummary[i].FASTFeeDescription, chargeTo: faccSummary[i].ChargeTo.ToUpperFirst(), overrideReason: faccSummary[i].OverrideReason, overrideAmount: faccSummary[i].OverrideAmount.ToString("N2"));
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_WCF_VerifyCalculatedFees(FACCSummary[] faccSummary, FACCRecordingFee faccRecordingFee, TransactionInformation transactionInfo, string faccUnderwriter = null)
        {
            #region Verify File Fees with GetCalculationFees()
            Reports.TestStep = "Verify File Fees with GetCalculationFees()";
            var request = EscrowRequestFactory.GetCalculationFeesRequest(File.FileID);
            var details = EscrowService.GetCalculationFees(request);
            Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
            //
            for (int i = 0; i < faccSummary.Count(); i++)
                details.FACCCalculationSummary[i].CompareTo(faccSummary[i]);
            //
            details.FACCRecordingFees[0].CompareTo(faccRecordingFee);
            //
            details.TransactionInformation.CompareTo(transactionInfo);
            //
            Support.AreEqual(faccUnderwriter ?? "", details.FACCUnderwriter ?? "", "FACCUnderwriter");
            #endregion
        }

        protected void FAST_UpdateCalculateFeeSummary(string[,] summary)
        {
            #region Update Calculate Fee Summary
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
            //  FAST Fee Description
            FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, summary[0,0], 4, TableAction.GetCell).Element.FASelectItemBySendingKeys(index: 0, lastFirst: true);
            for (var i = 0; i < summary.GetLength(0); i++)
            {
                FastDriver.FileFeesDlg.WaitForScreenToLoad();
                FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItemBySendingKeys("All");
                FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(summary[i, 3]);
                FastDriver.FileFeesDlg.FindNow.FAClick();
                FastDriver.FileFeesDlg.FeeResult(0);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(1, 1, TableAction.On);
            }
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
            //
            for (var i = 0; i < summary.GetLength(0); i++)
            {
                var findByDesc = summary[i, 0];
                Support.AreEqual(summary[i, 2], FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 3, TableAction.GetText).Message);
                //  FAST Fee Description
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 4, TableAction.SelectItem, summary[i, 3]);
                //  Charge To
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 5, TableAction.Click);
                Keyboard.SendKeys(summary[i, 4]);
                Keyboard.SendKeys("{ENTER}");
                //  Override Reason
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 6, TableAction.Click);
                Keyboard.SendKeys(string.IsNullOrEmpty(summary[i, 5]) ? "{HOME}" : summary[i, 5]);
                Keyboard.SendKeys("{ENTER}{TAB}");
                //  Override Amount
                if (string.IsNullOrEmpty(summary[i, 5]))
                    Support.AreEqual("0.00", FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 7, TableAction.GetAttribute, "value").Message);
                else
                    FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 7, TableAction.SetText, summary[i, 6]);
                //  Split %
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 8, TableAction.SetText, summary[i, 7]);
                //  split $
                FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 9, TableAction.SetText, summary[i, 8]);
                //  Buyer Charge
                Support.AreEqual(summary[i, 9], FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 10, TableAction.GetAttribute, "value").Message);
                //  Seller Charge
                Support.AreEqual(summary[i, 10], FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 11, TableAction.GetAttribute, "value").Message);
                //  Total Charge
                Support.AreEqual(summary[i, 11], FastDriver.CalculateFees.SummaryTable.PerformTableAction(1, findByDesc, 12, TableAction.GetAttribute, "value").Message);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            #endregion
        }

        protected void FAST_UpdateRecTaxLEAmounts(double[,] LEvalues, bool recFeeRound = true, bool ttaxFeeRound = true)
        {
            #region Update Recording Tax LE Amounts
            FastDriver.FileFees.Open();
            FastDriver.FileFees.RecordingandTax.Click();
            FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
            // Edit LE Rounded amount in FileFee screen
            FastDriver.FileFees.RecordingLoanEstUnrounded.FASetText(LEvalues[0, 0].ToString("N2"));
            Keyboard.SendKeys(FAKeys.TabAway);
            if (!recFeeRound)
            {
                FastDriver.FileFees.RecordingLoanEstRounded.FASetText(LEvalues[0, 1].ToString("N2"));
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            Support.IsTrue(FastDriver.FileFees.WaitCreation(FastDriver.FileFees.GTaxBrokenImage) != recFeeRound, "Recording Fees LE rounded broken link");
            FastDriver.FileFees.TranTaxLoanEstUnrounded.FASetText(LEvalues[1, 0].ToString("N2"));
            Keyboard.SendKeys(FAKeys.TabAway);
            if (!ttaxFeeRound)
            {
                FastDriver.FileFees.TranTaxLoanEstRounded.FASetText(LEvalues[1, 1].ToString("N2"));
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            Support.IsTrue(FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TTaxBrokenImage) != ttaxFeeRound, "Transfer Tax LE rounded broken link");
            // Verify
            Support.AreEqual(Math.Floor(LEvalues[0, 1]).ToString("N2"), FastDriver.FileFees.RecordingLoanEstRounded.GetAttribute("value").Replace("$", ""));
            Support.AreEqual(Math.Floor(LEvalues[1, 1]).ToString("N2"), FastDriver.FileFees.TranTaxLoanEstRounded.GetAttribute("value").Replace("$", ""));
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_VerifyRecTaxLEAmounts(double[,] LEvalues, bool recFeeRound = true, bool ttaxFeeRound = true)
        {
            #region Verify Recording Tax LE Amounts
            FastDriver.FileFees.Open();
            FastDriver.FileFees.RecordingandTax.Click();
            FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
            Support.AreEqual(LEvalues[0, 0].ToString("N2"), FastDriver.FileFees.RecordingLoanEstUnrounded.GetAttribute("value").Replace("$", ""));
            Support.AreEqual(Math.Floor(LEvalues[0, 1]).ToString("N2"), FastDriver.FileFees.RecordingLoanEstRounded.GetAttribute("value").Replace("$", ""));
            Support.IsTrue(FastDriver.FileFees.WaitCreation(FastDriver.FileFees.GTaxBrokenImage) != recFeeRound, "Recording Fees LE rounded broken link");
            Support.AreEqual(LEvalues[1, 0].ToString("N2"), FastDriver.FileFees.TranTaxLoanEstUnrounded.GetAttribute("value").Replace("$", ""));
            Support.AreEqual(Math.Floor(LEvalues[1, 1]).ToString("N2"), FastDriver.FileFees.TranTaxLoanEstRounded.GetAttribute("value").Replace("$", ""));
            Support.IsTrue(FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TTaxBrokenImage) != ttaxFeeRound, "Transfer Tax LE rounded broken link");
            #endregion
        }

        protected void FAST_UpdateLEAmtOTC(double[,] LEvalues, bool recFeeRound = true, bool ttaxFeeRound = true)
        {
            #region Update Recording Tax LE Amounts
            FastDriver.OTCDetail.Open();
            FastDriver.OTCDetail.GRCLoanEstimateUnroundedAmount.FASetText(LEvalues[0, 0].ToString("N2"));
            Keyboard.SendKeys(FAKeys.TabAway);
            if (!recFeeRound)
            {
                FastDriver.OTCDetail.GRCLoanEstimateRoundedAmount.FASetText(LEvalues[0, 1].ToString("N2"));
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            Support.IsTrue(FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.RecFeeLEbrokenImage) != recFeeRound, "Recording Fees LE rounded broken link");
            FastDriver.OTCDetail.TTLoanEstimateUnroundedAmount.FASetText(LEvalues[1, 0].ToString("N2"));
            Keyboard.SendKeys(FAKeys.TabAway);
            if (!ttaxFeeRound)
            {
                FastDriver.OTCDetail.TTLoanEstimateRoundedAmount.FASetText(LEvalues[1, 1].ToString("N2"));
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            Support.IsTrue(FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.TTaxLEbrokenImage) != ttaxFeeRound, "Transfer Tax LE rounded broken link");
            // Verify
            Support.AreEqual(Math.Floor(LEvalues[0, 1]).ToString("N2"), FastDriver.OTCDetail.GRCLoanEstimateRoundedAmount.GetAttribute("value").Replace("$", ""));
            Support.AreEqual(Math.Floor(LEvalues[1, 1]).ToString("N2"), FastDriver.OTCDetail.TTLoanEstimateRoundedAmount.GetAttribute("value").Replace("$", ""));
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_VerifyLEAmtOTC(double[,] LEvalues, bool recFeeRound = true, bool ttaxFeeRound = true)
        {
            #region Verify LE Unrounded amount in OTC screen
            FastDriver.OTCDetail.Open();
            Support.AreEqual(LEvalues[0, 0].ToString("C2"), FastDriver.OTCDetail.GRCLoanEstimateUnroundedAmount.FAGetValue());
            Support.AreEqual(Math.Floor(LEvalues[0, 1]).ToString("C2"), FastDriver.OTCDetail.GRCLoanEstimateRoundedAmount.FAGetValue());
            Support.IsTrue(FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.RecFeeLEbrokenImage) != recFeeRound, "Recording Fees LE rounded broken link");
            Support.AreEqual(LEvalues[1, 0].ToString("C2"), FastDriver.OTCDetail.TTLoanEstimateUnroundedAmount.FAGetValue());
            Support.AreEqual(Math.Floor(LEvalues[1, 1]).ToString("C2"), FastDriver.OTCDetail.TTLoanEstimateRoundedAmount.FAGetValue());
            Support.IsTrue(FastDriver.OTCDetail.WaitCreation(FastDriver.OTCDetail.TTaxLEbrokenImage) != ttaxFeeRound, "Transfer Tax LE rounded broken link");
            #endregion
        }

        protected void FAST_UpdateLEAmtCDSectionE(double LEUnrounded, double LERounded, bool isRounded=true)
        {
            #region Update LE amount in CD Section E
            FastDriver.ClosingDisclosure.Open();
            FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionETable);
            Keyboard.SendKeys("{RIGHT 4}{DOWN 4}");
            Playback.Wait(2000);
            FastDriver.ClosingDisclosure.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E")));//td.Unrounded > span
            var LEUnroundedText = FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E td.Unrounded > span"));
            Mouse.Click(FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E")).Location);//td.Unrounded
            Playback.Wait(3000);
            Keyboard.SendKeys(FAKeys.TabAway);
            Playback.Wait(3000);
            Keyboard.SendKeys("{HOME}" + "{DEL}".Repeat(LEUnroundedText.Text.Length));
            Keyboard.SendKeys(LEUnrounded.ToString("F2"));
            Keyboard.SendKeys(FAKeys.TabAway);
            if (!isRounded)
            {
                var LERoundedText = FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E td.Rounded > span:first-child"));
                Mouse.Click(FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E")).Location);//td.Rounded
                Playback.Wait(3000);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(3000);
                Keyboard.SendKeys("{HOME}" + "{DEL}".Repeat(LERoundedText.Text.Length));
                Keyboard.SendKeys(LERounded.ToString("F2"));
                Keyboard.SendKeys("{TAB}".Repeat(2));
            }
            Support.IsTrue(FastDriver.ClosingDisclosure.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E td.Rounded span img"))) != isRounded, "CD Section E LE amount broken image");
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_VerifyLEAmtCDSectionE(double LEUnrounded, double LERounded, bool isRounded = true)
        {
            #region Verify LE amount in CD Section E
            FastDriver.ClosingDisclosure.Open();
            FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(true);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionETable);
            Keyboard.SendKeys("{RIGHT 2}{DOWN 2}");
            Support.AreEqual(LEUnrounded.ToString("C2"), FastDriver.WebDriver.FindElement(By.CssSelector("td#tdE02PlusUnrounded > span, #lblDisplayLEAmount_-1_-1")).Text);
            Support.AreEqual(Math.Floor(LERounded).ToString("C2"), FastDriver.WebDriver.FindElement(By.CssSelector("td#tdE02PlusRounded > span:first-child, #lblDisplayRoundedAmount_-1_-1")).Text);
            Support.IsTrue(FastDriver.ClosingDisclosure.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("td#tdE02PlusRounded span img, td.Rounded span img"))) != isRounded, "CD Section E LE amount broken image");
            #endregion
        }

        protected void FAST_UpdateLenderCredits(string[,] chargesTabValues=null, string[,] mortgageTabValues=null)
        {
            #region Enter Buyer credits and LE amount for Lender in New Loan - Loan Charges tab
            FastDriver.NewLoan.Open();
            if (chargesTabValues != null)
            {
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.Expand(FastDriver.NewLoan.LoanCharges_ExpandLenderCredits);
                for (var i = 0; i < chargesTabValues.GetLength(0); i++)
                {
                    if (!string.IsNullOrEmpty(chargesTabValues[i, 1]))
                        FastDriver.NewLoan.LoanCharges_LenderCreditTable.PerformTableAction(System.Convert.ToInt16(chargesTabValues[i, 0]), 1, TableAction.SetText, chargesTabValues[i, 1]);
                    FastDriver.NewLoan.LoanCharges_LenderCreditTable.PerformTableAction(System.Convert.ToInt16(chargesTabValues[i, 0]), 4, TableAction.SetText, chargesTabValues[i, 4]);
                    FastDriver.NewLoan.LoanCharges_LenderCreditTable.PerformTableAction(System.Convert.ToInt16(chargesTabValues[i, 0]), 7, TableAction.SetText, chargesTabValues[i, 7]);
                }
            }
            if (mortgageTabValues != null) 
            {
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                FastDriver.NewLoan.Expand(FastDriver.NewLoan.Mortgage_ExpandLenderCredits);
                for (var i = 0; i < mortgageTabValues.GetLength(0); i++)
                {
                    if (!string.IsNullOrEmpty(mortgageTabValues[i, 1]))
                        FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(System.Convert.ToInt16(mortgageTabValues[i, 0]), 1, TableAction.SetText, mortgageTabValues[i, 1]);
                    FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(System.Convert.ToInt16(mortgageTabValues[i, 0]), 4, TableAction.SetText, mortgageTabValues[i, 4]);
                    FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(System.Convert.ToInt16(mortgageTabValues[i, 0]), 7, TableAction.SetText, mortgageTabValues[i, 7]);
                }
            }
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_UpdateFileFeesPDD(PDD paymentDetails, bool isTE = true)
        {
            #region Update PDD in FileFees
            if (!isTE)
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, paymentDetails.ChargeDescription, 3, TableAction.Click);
            else
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, paymentDetails.ChargeDescription, 3, TableAction.Click);

            FAST_UpdatePDD(paymentDetails);
            FastDriver.FileFees.SwitchToContentFrame();

            if (paymentDetails.BuyerAtClosing != null || paymentDetails.BuyerBeforeClosing != null || paymentDetails.BuyerPaidbyOther != null)
            {
                double bCharge = (paymentDetails.BuyerAtClosing ?? 0) + (paymentDetails.BuyerBeforeClosing ?? 0) + (paymentDetails.BuyerPaidbyOther ?? 0);
                if (!isTE)
                {
                    FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                    Support.AreEqual(bCharge.ToString("N2"), FastDriver.FileFees.RecordingTable.PerformTableAction(2, paymentDetails.ChargeDescription, 4, TableAction.GetAttribute, "value").Message.Trim());
                }
                else
                {
                    FastDriver.FileFees.WaitForFeeScreen();
                    Support.AreEqual(bCharge.ToString("N2"), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, paymentDetails.ChargeDescription, 4, TableAction.GetAttribute, "value").Message.Trim());
                }
            }
            if (paymentDetails.SellerPaidAtClosing != null || paymentDetails.SellerPaidBeforeClosing != null || paymentDetails.SellerPaidbyOthers != null)
            {
                double sCharge = (paymentDetails.SellerPaidAtClosing ?? 0) + (paymentDetails.SellerPaidBeforeClosing ?? 0) + (paymentDetails.SellerPaidbyOthers ?? 0);
                if (!isTE)
                {
                    FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                    Support.AreEqual(sCharge.ToString("N2"), FastDriver.FileFees.RecordingTable.PerformTableAction(2, paymentDetails.ChargeDescription, 5, TableAction.GetAttribute, "value").Message.Trim());
                }
                else
                {
                    FastDriver.FileFees.WaitForFeeScreen();
                    Support.AreEqual(sCharge.ToString("N2"), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, paymentDetails.ChargeDescription, 7, TableAction.GetAttribute, "value").Message.Trim());
                }
            }
            #endregion
        }

        protected void FAST_UpdateOTCDetailPDD(PDD paymentDetails)
        {
            #region Update PDD in FileFees
            FastDriver.OTCDetail.RecFeesAndTTaxTable.PerformTableAction(1, paymentDetails.ChargeDescription, 1, TableAction.DoubleClick);
            FAST_UpdatePDD(paymentDetails);
            FastDriver.OTCDetail.SwitchToContentFrame();
            #endregion
        }

        protected void FAST_UpdatePDD(PDD paymentDetails)
        {
            #region Update PDD
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (paymentDetails.ChargeDescription != null)
                FastDriver.PaymentDetailsDlg.Description.FASetText(paymentDetails.ChargeDescription, continueOnFailure: true);
            if (paymentDetails.LEDescription != null) 
                FastDriver.PaymentDetailsDlg.LEDescription.FASetText(paymentDetails.LEDescription, continueOnFailure: true);
            if(FastDriver.PaymentDetailsDlg.usedefault.Exists())
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(paymentDetails.UseDefaultChecked);
            if (paymentDetails.PayeeName != null)
                FastDriver.PaymentDetailsDlg.PayeeName.FASetText(paymentDetails.PayeeName, continueOnFailure: true);
            if (paymentDetails.LoanEstimateUnrounded != null)
                FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FASetText(paymentDetails.LoanEstimateUnrounded.ToString(), continueOnFailure: true);
            if (paymentDetails.isPrimaryPolicy != null)
                FastDriver.PaymentDetailsDlg.PrimaryPolicy.FASetCheckbox(paymentDetails.isPrimaryPolicy);
            if (!string.IsNullOrEmpty(paymentDetails.NoMonthsPrepaid))
                FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FASetText(paymentDetails.NoMonthsPrepaid.ToString(), continueOnFailure: true);
            if (!string.IsNullOrEmpty(paymentDetails.MonthPrepaidSelect))
                FastDriver.PaymentDetailsDlg.MonthPrepaidSelect.FASelectItemBySendingKeys(paymentDetails.MonthPrepaidSelect.ToString());
            FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.FASetCheckbox(paymentDetails.BuyerDoubleAsteriskChecked);
            FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(paymentDetails.PartOfCheckbox);
            //  Buyer charges
            var bCharge = (paymentDetails.BuyerAtClosing ?? 0) + (paymentDetails.BuyerBeforeClosing ?? 0) + (paymentDetails.BuyerPaidbyOther ?? 0);
            if (paymentDetails.BuyerAtClosing != null || paymentDetails.BuyerBeforeClosing != null || paymentDetails.BuyerPaidbyOther != null)
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(bCharge.ToString(), continueOnFailure: true);            
            if (paymentDetails.BuyerCredit != null)
                FastDriver.PaymentDetailsDlg.BuyerCredit.FASetText(paymentDetails.BuyerCredit.ToString(), continueOnFailure: true);
            if (paymentDetails.BuyerAtClosing != null)
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText(paymentDetails.BuyerAtClosing.ToString(), continueOnFailure: true);
            if (paymentDetails.BuyerChargePaymentMethod != null)
                Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant() == "chk" ? "check" : paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToLowerInvariant());
            if (paymentDetails.BuyerBeforeClosing != null)
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(paymentDetails.BuyerBeforeClosing.ToString(), continueOnFailure: true);
            if (paymentDetails.BuyerPaidbyOther != null)
                FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FASetText(paymentDetails.BuyerPaidbyOther.ToString(), continueOnFailure: true);
            FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FASelectItemBySendingKeys(paymentDetails.BuyerPaidbyOtherPaymentMethod);
            if (paymentDetails.BuyerPaidbyOtherPaymentMethod == "Lender" || paymentDetails.BuyerPaidbyOtherPaymentMethod == "POC-L") 
                FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.FASetCheckbox(paymentDetails.BuyerLenderCheckbox);
            //  Seller charges
            var sCharge = (paymentDetails.SellerPaidAtClosing ?? 0) + (paymentDetails.SellerPaidBeforeClosing ?? 0) + (paymentDetails.SellerPaidbyOthers ?? 0);
            if (paymentDetails.SellerPaidAtClosing != null || paymentDetails.SellerPaidBeforeClosing != null || paymentDetails.SellerPaidbyOthers != null)
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(sCharge.ToString(), continueOnFailure: true);
            if (paymentDetails.SellerCredit != null)
                FastDriver.PaymentDetailsDlg.SellerCredit.FASetText(paymentDetails.SellerCredit.ToString(), continueOnFailure: true);
            if (paymentDetails.SellerPaidAtClosing != null)
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText(paymentDetails.SellerPaidAtClosing.ToString(), continueOnFailure: true);
            if (paymentDetails.SellerChargePaymentMethod != null)
                Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant() == "chk" ? "check" : paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToLowerInvariant());
            if (paymentDetails.SellerPaidBeforeClosing != null)
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText(paymentDetails.SellerPaidBeforeClosing.ToString(), continueOnFailure: true);
            if (paymentDetails.SellerPaidbyOthers != null)
                FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FASetText(paymentDetails.SellerPaidbyOthers.ToString(), continueOnFailure: true);
            FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItemBySendingKeys(paymentDetails.SellerPaidbyOtherPaymentMthd);
            if (paymentDetails.SellerPaidbyOtherPaymentMthd == "Lender" || paymentDetails.SellerPaidbyOtherPaymentMthd == "POC-L")
                FastDriver.PaymentDetailsDlg.SellerDisplayLenderOnCD.FASetCheckbox(paymentDetails.SellerLenderCheckbox);
            //  Section
            if (paymentDetails.SectionBdidnotShopFor) FastDriver.PaymentDetailsDlg.SectionB.Click();
            if (paymentDetails.SectionCDidShopFor) FastDriver.PaymentDetailsDlg.SectionC.Click();
            if (paymentDetails.SectionHOtherCosts) FastDriver.PaymentDetailsDlg.SectionH.Click();
            //
            FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            #endregion
        }

        protected void FAST_UpdatePDD(hudPDD paymentDetails)
        {
            #region Update PDD
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (paymentDetails.Description != null)
                FastDriver.PaymentDetailsDlg.Description.FASetText(paymentDetails.Description, continueOnFailure: true);
            if (paymentDetails.PayTo != null)
                FastDriver.PaymentDetailsDlg.PayTo.FASetText(paymentDetails.PayTo, continueOnFailure: true);
            if (paymentDetails.UseDefault != null)
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(paymentDetails.UseDefault);
            if (paymentDetails.BuyerCharge != null)
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(paymentDetails.BuyerCharge.ToString("N2"), continueOnFailure: true);
            if (paymentDetails.BuyerPaymentMethod != null)
                FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FASelectItem(paymentDetails.BuyerPaymentMethod);
            if (paymentDetails.SellerCharge != null)
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText(paymentDetails.SellerCharge.ToString("N2"), continueOnFailure: true);
            if (paymentDetails.SellerPaymentMethod != null)
                FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FASelectItem(paymentDetails.SellerPaymentMethod);
            if (paymentDetails.GFE != null)
                FastDriver.PaymentDetailsDlg.GFEType.FASelectItem(paymentDetails.GFE);
            if (paymentDetails.LenderSelectedProvider != null)
                FastDriver.PaymentDetailsDlg.LenderSelectedProvider.FASetCheckbox(paymentDetails.LenderSelectedProvider);
            if (paymentDetails.PaidOnBehalfOfBorrower != null)
                FastDriver.PaymentDetailsDlg.PaidonbehalfofBorrower.FASetCheckbox(paymentDetails.PaidOnBehalfOfBorrower);
            //
            FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            #endregion
        }

        protected void FAST_VerifyPDD(PDD paymentDetails)
        {
            #region Verify PDD
            Reports.TestStep = "Verify PDD";
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (paymentDetails.ChargeDescription != null)
                Support.AreEqual(paymentDetails.ChargeDescription, FastDriver.PaymentDetailsDlg.Description.FAGetValue() ?? "", "Description");
            if (paymentDetails.LEDescription != null)
                Support.AreEqual(paymentDetails.LEDescription, FastDriver.PaymentDetailsDlg.LEDescription.FAGetValue() ?? "", "LEDescription");
            if (FastDriver.PaymentDetailsDlg.usedefault.Exists())
                Support.AreEqual(paymentDetails.UseDefaultChecked.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.usedefault.GetAttribute("status"), "UseDefault");
            if (paymentDetails.PayeeName != null)
                Support.AreEqual(paymentDetails.PayeeName, FastDriver.PaymentDetailsDlg.PayeeName.FAGetValue() ?? "", "PayeeName");
            if (paymentDetails.LoanEstimateUnrounded != null)
                Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("C2"), FastDriver.PaymentDetailsDlg.LoadEstimateUnrounded.FAGetValue() ?? "", "LoadEstimateUnrounded");
            if (paymentDetails.isPrimaryPolicy != null)
                Support.AreEqual(paymentDetails.isPrimaryPolicy.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.PrimaryPolicy.FAGetAttribute("status").ToLowerInvariant(), "PrimaryPolicy");
            if (!string.IsNullOrEmpty(paymentDetails.NoMonthsPrepaid))
                Support.AreEqual(paymentDetails.NoMonthsPrepaid.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.NoMonthsPrepaid.FAGetValue().ToLowerInvariant(), "NoMonthsPrepaid");
            if (!string.IsNullOrEmpty(paymentDetails.MonthPrepaidSelect))
                Support.AreEqual(paymentDetails.MonthPrepaidSelect.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.MonthPrepaidSelect.FAGetSelectedItem().ToLowerInvariant(), "MonthPrepaidSelect");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.DoubleAsteriskIndicator.GetAttribute("status"), "DoubleAsteriskIndicator");
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.PartOf.GetAttribute("status"), "PartOf");
            //  Buyer charges
            var bCharge = (paymentDetails.BuyerAtClosing ?? 0) + (paymentDetails.BuyerBeforeClosing ?? 0) + (paymentDetails.BuyerPaidbyOther ?? 0);
            if (paymentDetails.BuyerAtClosing != null || paymentDetails.BuyerBeforeClosing != null || paymentDetails.BuyerPaidbyOther != null)
                Support.AreEqual(((Decimal)bCharge).ToString("C2"), FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue() ?? "", "BuyerCharge");
            if (paymentDetails.BuyerCredit != null)
                Support.AreEqual(((Decimal)paymentDetails.BuyerCredit).ToString("C2"), FastDriver.PaymentDetailsDlg.BuyerCredit.FAGetValue() ?? "", "BuyerCredit");
            if (paymentDetails.BuyerAtClosing != null)
                Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue() ?? "", "PaidbyBuyerAtClosing");
            if (paymentDetails.BuyerChargePaymentMethod != null)
                Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant() == "chk" ? "check" : paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToLowerInvariant(), "PaidbyBuyerAtClosingPaymentMethod");
            if (paymentDetails.BuyerBeforeClosing != null)
                Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue(), "PaidbyBuyerBeforeClosing");
            if (paymentDetails.BuyerPaidbyOther != null)
                Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue(), "PaidbyBuyerOthers");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod, FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem(), "BuyerPaidByOthersPaymentMethod");
            if (paymentDetails.BuyerPaidbyOtherPaymentMethod == "Lender" || paymentDetails.BuyerPaidbyOtherPaymentMethod == "POC-L")
                Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.BuyerDisplayLenderOnCD.GetAttribute("status"), "BuyerDisplayLenderOnCD");
            //  Seller charges
            var sCharge = (paymentDetails.SellerPaidAtClosing ?? 0) + (paymentDetails.SellerPaidBeforeClosing ?? 0) + (paymentDetails.SellerPaidbyOthers ?? 0);
            if (paymentDetails.SellerPaidAtClosing != null || paymentDetails.SellerPaidBeforeClosing != null || paymentDetails.SellerPaidbyOthers != null)
                Support.AreEqual(((Decimal)sCharge).ToString("C2"), FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue() ?? "", "SellerCharge");
            if (paymentDetails.SellerCredit != null)
                Support.AreEqual(((Decimal)paymentDetails.SellerCredit).ToString("C2"), FastDriver.PaymentDetailsDlg.SellerCredit.FAGetValue() ?? "", "SellerCredit");
            if (paymentDetails.SellerPaidAtClosing != null)
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue() ?? "", "PaidbySellerAtClosing");
            if (paymentDetails.SellerChargePaymentMethod != null)
                Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant() == "chk" ? "check" : paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToLowerInvariant(), "PaidbySellerAtClosingPaymentMethod");
            if (paymentDetails.SellerPaidBeforeClosing != null)
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue() ?? "", "PaidbySellerBeforeClosing");
            if (paymentDetails.SellerPaidbyOthers != null)
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue() ?? "", "PaidbySellerOthers");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd, FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem(), "SellerPaidByOthersPaymentMethod");
            if (paymentDetails.SellerPaidbyOtherPaymentMthd == "Lender" || paymentDetails.SellerPaidbyOtherPaymentMthd == "POC-L")
                Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), FastDriver.PaymentDetailsDlg.SellerDisplayLenderOnCD.GetAttribute("status"), "SellerDisplayLenderOnCD");
            //  Section
            if (paymentDetails.SectionBdidnotShopFor) Support.AreEqual("true", FastDriver.PaymentDetailsDlg.SectionB.GetAttribute("status"), "SectionB");
            if (paymentDetails.SectionCDidShopFor) Support.AreEqual("true", FastDriver.PaymentDetailsDlg.SectionC.GetAttribute("status"), "SectionC");
            if (paymentDetails.SectionHOtherCosts) Support.AreEqual("true", FastDriver.PaymentDetailsDlg.SectionH.GetAttribute("status"), "SectionH");
            //
            FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            #endregion
        }

        protected void FAST_VerifyPDD(hudPDD paymentDetails)
        {
            #region Verify PDD
            Reports.TestStep = "Verify PDD";
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            if (paymentDetails.Description != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.Description.FAGetValue(), paymentDetails.Description, "Description");
            if (paymentDetails.PayTo != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PayTo.FAGetValue(), paymentDetails.PayTo, "PayTo");
            if (paymentDetails.UseDefault != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.usedefault.FAGetAttribute("status").ToLowerInvariant(), paymentDetails.UseDefault.ToString().ToLowerInvariant(), "Use Default");
            if (paymentDetails.BuyerCharge != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), paymentDetails.BuyerCharge.ToString("N2"), "Buyer Charge");
            if (paymentDetails.BuyerPaymentMethod != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerPaymentMethod.FAGetSelectedItem(), paymentDetails.BuyerPaymentMethod, "Buyer Payment Method");
            if (paymentDetails.SellerCharge != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), paymentDetails.SellerCharge.ToString("N2"), "Seller Charge");
            if (paymentDetails.SellerPaymentMethod != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaymentMethod.FAGetSelectedItem(), paymentDetails.SellerPaymentMethod, "Seller Payment Method");
            if (paymentDetails.GFE != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.GFEType.FAGetSelectedItem(), paymentDetails.GFE, "GFE");
            if (paymentDetails.LenderSelectedProvider != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.LenderSelectedProvider.FAGetAttribute("status").ToLowerInvariant(), paymentDetails.LenderSelectedProvider.ToString().ToLowerInvariant(), "Lender Selected Provider");
            if (paymentDetails.PaidOnBehalfOfBorrower != null)
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidonbehalfofBorrower.FAGetAttribute("status").ToLowerInvariant(), paymentDetails.PaidOnBehalfOfBorrower.ToString().ToLowerInvariant(), "Paid On Behalf Of Borrower");
            //
            FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            #endregion
        }

        protected void FAST_VerifyUtilityProration(UtilityProration prorationDetails)
        {
            #region Verify Utility Proration
            Support.AreEqual(prorationDetails.CreditSeller.ToString().ToLowerInvariant(), FastDriver.UtilityDetail.CreditSeller.FAGetAttribute("status").ToLowerInvariant(), "Proration.CreditSeller");
            Support.AreEqual(prorationDetails.DayofClosePaidbySeller.ToString().ToLowerInvariant(), FastDriver.UtilityDetail.DayofClosePaidbySeller.FAGetAttribute("status").ToLowerInvariant(), "Proration.DayOfClosePaidbySeller");
            Support.AreEqual(((Decimal)prorationDetails.ProrationAmount).ToString("N2"), FastDriver.UtilityDetail.ProrationAmount.FAGetValue(), "Proration.Amount");
            Support.AreEqual(prorationDetails.FromDate, FastDriver.UtilityDetail.FromDate.FAGetValue(), "Proration.FromDate");
            Support.AreEqual(prorationDetails.fromInclusive.ToString().ToLowerInvariant(), FastDriver.UtilityDetail.fromInclusive.FAGetAttribute("status").ToLowerInvariant(), "Proration.FromDateInclusive");
            Support.AreEqual(prorationDetails.fromProrateDate.ToString().ToLowerInvariant(), FastDriver.UtilityDetail.fromProrateDate.FAGetAttribute("status").ToLowerInvariant(), "Proration.FromDateIsProrateDate");
            Support.AreEqual(prorationDetails.BasedOn, FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem(), "Proration.BasedOnDays");            
            Support.AreEqual(prorationDetails.Per.ToLowerInvariant(), FastDriver.UtilityDetail.Per.FAGetSelectedItem().ToLowerInvariant(), "Proration.AmountPeriod");
            Support.AreEqual(prorationDetails.ToDate, FastDriver.UtilityDetail.ToDate.FAGetValue(), "Proration.ToDate");
            Support.AreEqual(prorationDetails.toInclusive.ToString().ToLowerInvariant(), FastDriver.UtilityDetail.toInclusive.FAGetAttribute("status").ToLowerInvariant(), "Proration.ToDateInclusive");
            Support.AreEqual(prorationDetails.toProrateDate.ToString().ToLowerInvariant(), FastDriver.UtilityDetail.toProrateDate.FAGetAttribute("status").ToLowerInvariant(), "Proration.ToDateIsProrateDate");
            Support.AreEqual(prorationDetails.Description, FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue(), "Proration.Description");
            Support.AreEqual(((Decimal)prorationDetails.ProrationBuyerCharge).ToString("N2"), FastDriver.UtilityDetail.ProrationBuyerCharge.FAGetValue(), "Proration.BuyerCharge");
            Support.AreEqual(((Decimal)prorationDetails.ProrationBuyerCredit).ToString("N2"), FastDriver.UtilityDetail.ProrationBuyerCredit.FAGetValue(), "Proration.BuyerCredit");
            Support.AreEqual(((Decimal)prorationDetails.ProrationSellerCharge).ToString("N2"), FastDriver.UtilityDetail.ProrationSellerCharge.FAGetValue(), "Proration.SellerCharge");
            Support.AreEqual(((Decimal)prorationDetails.ProrationSellerCredit).ToString("N2"), FastDriver.UtilityDetail.ProrationSellerCredit.FAGetValue(), "Proration.SellerCredit");
            Support.AreEqual(((Decimal)prorationDetails.ProrationUtilityLE).ToString("N2"), FastDriver.UtilityDetail.ProrationUtilityLE.FAGetValue(), "Proration.LEAmount");
            #endregion
        }

        protected void FAST_VerifyProration(ProrationData prorationDetails)
        {
            #region Verify Proration
            Support.AreEqual(prorationDetails.CreditSeller.ToString().ToLowerInvariant(), FastDriver.ProrationDetail.CreditSeller.FAGetAttribute("status").ToLowerInvariant(), "Proration.CreditSeller");
            Support.AreEqual(prorationDetails.DayofClosePaidbySeller.ToString().ToLowerInvariant(), FastDriver.ProrationDetail.DayofClosePaidbySeller.FAGetAttribute("status").ToLowerInvariant(), "Proration.DayOfClosePaidbySeller");
            Support.AreEqual(((Decimal)prorationDetails.ProrationAmount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue(), "Proration.Amount");
            Support.AreEqual(prorationDetails.FromDate, FastDriver.ProrationDetail.FromDate.FAGetValue(), "Proration.FromDate");
            Support.AreEqual(prorationDetails.fromInclusive.ToString().ToLowerInvariant(), FastDriver.ProrationDetail.fromInclusive.FAGetAttribute("status").ToLowerInvariant(), "Proration.FromDateInclusive");
            Support.AreEqual(prorationDetails.fromProrateDate.ToString().ToLowerInvariant(), FastDriver.ProrationDetail.fromProrate.FAGetAttribute("status").ToLowerInvariant(), "Proration.FromDateIsProrateDate");
            Support.AreEqual(prorationDetails.BasedOn, FastDriver.ProrationDetail.BasedOn.FAGetSelectedItem(), "Proration.BasedOnDays");
            Support.AreEqual(prorationDetails.Per.ToLowerInvariant(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToLowerInvariant(), "Proration.AmountPeriod");
            Support.AreEqual(prorationDetails.ToDate, FastDriver.ProrationDetail.ToDate.FAGetValue(), "Proration.ToDate");
            Support.AreEqual(prorationDetails.toInclusive.ToString().ToLowerInvariant(), FastDriver.ProrationDetail.toInclusive.FAGetAttribute("status").ToLowerInvariant(), "Proration.ToDateInclusive");
            Support.AreEqual(prorationDetails.toProrateDate.ToString().ToLowerInvariant(), FastDriver.ProrationDetail.toProrate.FAGetAttribute("status").ToLowerInvariant(), "Proration.ToDateIsProrateDate");
            Support.AreEqual(prorationDetails.Description, FastDriver.ProrationDetail.Description.FAGetValue(), "Proration.Description");
            Support.AreEqual(((Decimal)prorationDetails.ProrationBuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue(), "Proration.BuyerCharge");
            Support.AreEqual(((Decimal)prorationDetails.ProrationBuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue(), "Proration.BuyerCredit");
            Support.AreEqual(((Decimal)prorationDetails.ProrationSellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue(), "Proration.SellerCharge");
            Support.AreEqual(((Decimal)prorationDetails.ProrationSellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue(), "Proration.SellerCredit");
            Support.AreEqual(((Decimal)prorationDetails.ProrationUtilityLE).ToString("N2"), FastDriver.ProrationDetail.LE_amount.FAGetValue(), "Proration.LEAmount");
            #endregion
        }

        protected void FAST_VerifyHAProration(ProrationData prorationDetails)
        {
            #region Verify Proration
            Support.AreEqual(prorationDetails.CreditSeller.ToString().ToLowerInvariant(), FastDriver.HomeownerAssociation.CreditSeller.FAGetAttribute("status").ToLowerInvariant(), "Proration.CreditSeller");
            Support.AreEqual(prorationDetails.DayofClosePaidbySeller.ToString().ToLowerInvariant(), FastDriver.HomeownerAssociation.DayofClosePaidbySeller.FAGetAttribute("status").ToLowerInvariant(), "Proration.DayOfClosePaidbySeller");
            Support.AreEqual(((Decimal)prorationDetails.ProrationAmount).ToString("N2"), FastDriver.HomeownerAssociation.ProrationAmount.FAGetValue(), "Proration.Amount");
            Support.AreEqual(prorationDetails.FromDate, FastDriver.HomeownerAssociation.FromDate.FAGetValue(), "Proration.FromDate");
            Support.AreEqual(prorationDetails.fromInclusive.ToString().ToLowerInvariant(), FastDriver.HomeownerAssociation.fromInclusive.FAGetAttribute("status").ToLowerInvariant(), "Proration.FromDateInclusive");
            Support.AreEqual(prorationDetails.fromProrateDate.ToString().ToLowerInvariant(), FastDriver.HomeownerAssociation.fromProrate.FAGetAttribute("status").ToLowerInvariant(), "Proration.FromDateIsProrateDate");
            Support.AreEqual(prorationDetails.BasedOn, FastDriver.HomeownerAssociation.BasedOn.FAGetSelectedItem(), "Proration.BasedOnDays");
            Support.AreEqual(prorationDetails.Per.ToLowerInvariant(), FastDriver.HomeownerAssociation.Per.FAGetSelectedItem().ToLowerInvariant(), "Proration.AmountPeriod");
            Support.AreEqual(prorationDetails.ToDate, FastDriver.HomeownerAssociation.ToDate.FAGetValue(), "Proration.ToDate");
            Support.AreEqual(prorationDetails.toInclusive.ToString().ToLowerInvariant(), FastDriver.HomeownerAssociation.toInclusive.FAGetAttribute("status").ToLowerInvariant(), "Proration.ToDateInclusive");
            Support.AreEqual(prorationDetails.toProrateDate.ToString().ToLowerInvariant(), FastDriver.HomeownerAssociation.toProrateDate.FAGetAttribute("status").ToLowerInvariant(), "Proration.ToDateIsProrateDate");
            Support.AreEqual(prorationDetails.Description, FastDriver.HomeownerAssociation.ProrationDescription.FAGetValue(), "Proration.Description");
            Support.AreEqual(((Decimal)prorationDetails.ProrationBuyerCharge).ToString("N2"), FastDriver.HomeownerAssociation.ProrationBuyerCharge.FAGetValue(), "Proration.BuyerCharge");
            Support.AreEqual(((Decimal)prorationDetails.ProrationBuyerCredit).ToString("N2"), FastDriver.HomeownerAssociation.ProrationBuyerCredit.FAGetValue(), "Proration.BuyerCredit");
            Support.AreEqual(((Decimal)prorationDetails.ProrationSellerCharge).ToString("N2"), FastDriver.HomeownerAssociation.ProrationSellerCharge.FAGetValue(), "Proration.SellerCharge");
            Support.AreEqual(((Decimal)prorationDetails.ProrationSellerCredit).ToString("N2"), FastDriver.HomeownerAssociation.ProrationSellerCredit.FAGetValue(), "Proration.SellerCredit");
            Support.AreEqual(((Decimal)prorationDetails.ProrationUtilityLE).ToString("N2"), FastDriver.HomeownerAssociation.ProrationLE.FAGetValue(), "Proration.LEAmount");
            #endregion
        }

        protected void FAST_AddLoanCharges_FutureRecFees(PDD[] chargeValues)
        {
            #region Add Buyer Charge for any future recording Fee
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.Expand(FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender);
            for (var i = 0; i < chargeValues.Length; i++)
            {
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(1, chargeValues[i].ChargeDescription, 3, TableAction.SetText, chargeValues[i].BuyerAtClosing.ToString());
                FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable.PerformTableAction(1, chargeValues[i].ChargeDescription, 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(chargeValues[i].UseDefaultChecked);
                if (chargeValues[i].PDDDescription != null) FastDriver.PaymentDetailsDlg.Description.FASetText(chargeValues[i].PDDDescription);
                if (chargeValues[i].PayeeName != null) FastDriver.PaymentDetailsDlg.PayeeName.FASetText(chargeValues[i].PayeeName);
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
            }
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_AddMortgage_FutureRecFees(PDD[] chargeValues, string GABCode = null)
        {
            #region Add Buyer Charge for any future recording Fee
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickMortgageBrokerTab();
            if (!string.IsNullOrEmpty(GABCode))
            {
                FastDriver.NewLoan.MortgageGABcode.FASetText(GABCode);
                FastDriver.NewLoan.MortgageFind.FAClick();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.MortgageBrokerGABlabel);
            }
            FastDriver.NewLoan.Expand(FastDriver.NewLoan.Mortgage_ExpandFutureRecFees);
            for (var i = 0; i < chargeValues.Length; i++)
            {
                FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(1, chargeValues[i].ChargeDescription, 3, TableAction.SetText, chargeValues[i].BuyerAtClosing.ToString());
                FastDriver.NewLoan.Mortgage_FutureRecFeesTable.PerformTableAction(1, chargeValues[i].ChargeDescription, 1, TableAction.DoubleClick);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.usedefault.FASetCheckbox(chargeValues[i].UseDefaultChecked);
                if (chargeValues[i].PDDDescription != null) FastDriver.PaymentDetailsDlg.Description.FASetText(chargeValues[i].PDDDescription);
                if (chargeValues[i].PayeeName != null) FastDriver.PaymentDetailsDlg.PayeeName.FASetText(chargeValues[i].PayeeName);
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.NewLoan.SwitchToContentFrame();
            }
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_VerifyOtherCosts(string[,] sectionEValues=null, string[,] sectionEplus=null, string[,] sectionIValues=null,string[,] sectionJValues=null, bool displayLE = false)
        {
            #region Verify CD Section E
            FastDriver.ClosingDisclosure.Open();
            FastDriver.ClosingDisclosure.DisplayLoanEstimate.FASetCheckbox(displayLE);
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionETable);
            Keyboard.SendKeys("{DOWN 2}");
            if (sectionEValues != null)
            {
                FAST_VerifyOtherCostsE(sectionEValues, displayLE);
            }
            if (sectionEplus != null)
            {
                FAST_VerifyOtherCostsEplus(sectionEplus, displayLE);
            }
            Keyboard.SendKeys("{DOWN 3}");
            if (sectionIValues != null)
            {
                FAST_VerifyOtherCostsI(sectionIValues, displayLE);
            }
            Keyboard.SendKeys("{DOWN 1}");
            if (sectionJValues != null)
            {
                FAST_VerifyOtherCostsJ(sectionJValues, displayLE);
            }
            #endregion
        }

        protected void FAST_VerifyOtherCostsE(string[,] sectionValues, bool displayLE=false)
        {
            #region Verify CD Section E
            Support.AreEqual(sectionValues[0,0], (FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: 1, columnIndex: 1, action: TableAction.GetText, countVisibles:false).Message), "Section E Other costs");
            Support.AreEqual(sectionValues[0,1], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: 1, columnIndex: 2, action: TableAction.GetText, countVisibles:false).Message);
            for (var i = 1; i < sectionValues.GetLength(0); i++)
            {
                Support.AreEqual(sectionValues[i, 0], (FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 1, action: TableAction.GetText).Message), "Fee Title");
                Support.AreEqual(sectionValues[i, 1], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 2, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 2], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 3, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 3], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 4, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 4], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 5, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 5], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 6, action: TableAction.GetText).Message);
                if (displayLE && sectionValues.GetLength(1)>6)
                {
                    Keyboard.SendKeys("{RIGHT 2}");
                    Support.AreEqual(sectionValues[i, 6], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 7, action: TableAction.GetText).Message);
                    Support.AreEqual(sectionValues[i, 7], FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 8, action: TableAction.GetText).Message);
                    FastDriver.ClosingDisclosure.OCSectionETable.PerformTableAction(rowIndex: i + 1, columnIndex: 8, action: TableAction.GetCell).Element.FindElement(By.TagName("img"));
                    Keyboard.SendKeys("{LEFT 2}");
                }
            }
            #endregion
        }

        protected void FAST_VerifyOtherCostsEplus(string[,] sectionValues, bool displayLE = false)
        {
            #region Verify CD Section E
            for (var i = 0; i < sectionValues.GetLength(0); i++)
            {
                Support.AreEqual(sectionValues[i, 0], (FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(rowIndex: i + 1, columnIndex: 1, action: TableAction.GetText).Message), "Fee Title");
                Support.AreEqual(sectionValues[i, 1], FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(rowIndex: i + 1, columnIndex: 2, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 2], FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(rowIndex: i + 1, columnIndex: 3, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 3], FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(rowIndex: i + 1, columnIndex: 4, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 4], FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(rowIndex: i + 1, columnIndex: 5, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 5], FastDriver.ClosingDisclosure.OCSectionEplusTable.PerformTableAction(rowIndex: i + 1, columnIndex: 6, action: TableAction.GetText).Message);
            }
            #endregion
        }

        protected void FAST_VerifyOtherCostsI(string[,] sectionValues, bool displayLE=false)
        {
            #region Verify CD Section I
            Support.AreEqual(sectionValues[0, 0], (FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: 1, columnIndex: 1, action: TableAction.GetText, countVisibles:false).Message), "Section I Other Costs");
            Support.AreEqual(sectionValues[0, 1], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: 1, columnIndex: 2, action: TableAction.GetText, countVisibles:false).Message);
            for (var i = 1; i < sectionValues.GetLength(0); i++)
            {
                Support.AreEqual(sectionValues[i, 0], (FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 1, action: TableAction.GetText).Message), "Fee Title");
                Support.AreEqual(sectionValues[i, 1], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 2, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 2], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 3, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 3], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 4, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 4], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 5, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 5], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 6, action: TableAction.GetText).Message);
                if (displayLE && sectionValues.GetLength(1) > 6)
                {
                    Keyboard.SendKeys("{RIGHT 2}");
                    Support.AreEqual(sectionValues[i, 6], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 7, action: TableAction.GetText).Message);
                    Support.AreEqual(sectionValues[i, 7], FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 8, action: TableAction.GetText).Message);
                    FastDriver.ClosingDisclosure.OCSectionITable.PerformTableAction(rowIndex: i + 1, columnIndex: 8, action: TableAction.GetCell).Element.FindElement(By.TagName("img"));
                    Keyboard.SendKeys("{LEFT 2}");
                }
            }
            #endregion
        }

        protected void FAST_VerifyOtherCostsJ(string[,] sectionValues, bool displayLE=false)
        {
            #region Verify CD Section J
            Support.AreEqual(sectionValues[0, 0], (FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: 1, columnIndex: 1, action: TableAction.GetText, countVisibles:false).Message), "Section J Other Costs");
            Support.AreEqual(sectionValues[0, 1], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: 1, columnIndex: 2, action: TableAction.GetText, countVisibles:false).Message);
            for (var i = 1; i < sectionValues.GetLength(0); i++)
            {
                Support.AreEqual(sectionValues[i, 0], (FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 1, action: TableAction.GetText).Message), "Fee Title");
                Support.AreEqual(sectionValues[i, 1], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 2, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 2], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 3, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 3], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 4, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 4], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 5, action: TableAction.GetText).Message);
                Support.AreEqual(sectionValues[i, 5], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 6, action: TableAction.GetText).Message);
                if (displayLE && sectionValues.GetLength(1) > 6)
                {
                    Keyboard.SendKeys("{RIGHT 2}");
                    Support.AreEqual(sectionValues[i, 6], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 7, action: TableAction.GetText).Message);
                    Support.AreEqual(sectionValues[i, 7], FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 8, action: TableAction.GetText).Message);
                    FastDriver.ClosingDisclosure.TotalClosingCostsTable.PerformTableAction(rowIndex: i + 1, columnIndex: 8, action: TableAction.GetCell).Element.FindElement(By.TagName("img"));
                    Keyboard.SendKeys("{LEFT 2}");
                }
            }
            #endregion
        }

        protected void FAST_VerifyRecordingItemizationTable(string[,] deedFees = null, string[,] mortgageFees = null, string[,] releaseFees = null, string[,] miscFees = null, string[,] lenderFees = null, string[,] mbFees = null)
        {
            #region Verify Recording Itemization Fees
            FastDriver.ClosingDisclosure.Open();
            FastDriver.ClosingDisclosure.Othercosts.FAClick();
            FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionETable);
            FastDriver.ClosingDisclosure.ItemizedRecordingFeePlusIcon.FAClick();
            FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.divRecordingFee);
            if (deedFees != null) 
                FAST_VerifyRecordingFeesDeed(deedFees);
            if (mortgageFees != null) 
                FAST_VerifyRecordingFeesMortgage(mortgageFees);
            if (releaseFees != null) 
                FAST_VerifyRecordingFeesRelease(releaseFees);
            if (miscFees != null) 
                FAST_VerifyRecordingFeesMisc(miscFees);
            if (lenderFees != null) 
                FAST_VerifyRecordingFeesLender(lenderFees);
            if (mbFees != null) 
                FAST_VerifyRecordingFeesMB(mbFees);
            FastDriver.ClosingDisclosure.RecordingFeeDone.FAClick();
            #endregion
        }

        protected void FAST_AddLoanCharges_Payee(string GABCode, string[] charges = null)
        {
            #region Add Loan Charges Payee
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
            FAST_AddNewLoanChargeDisbursementPayee(GABCode, charges);
            #endregion
        }

        protected void FAST_AddLoanMortgage_Payee(string GABCode, string[] charges = null)
        {
            #region Add Loan Mortgage Payee
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickMortgageBrokerTab();
            FastDriver.NewLoan.MortgagePayCharges.FAClick();
            FAST_AddNewLoanChargeDisbursementPayee(GABCode, charges);
            #endregion
        }

        protected void FAST_AddFileFeesRec_Payee(string GABCode, string[] charges = null)
        {
            #region Add File Fees Recording Payee
            FastDriver.FileFees.Open();
            FastDriver.FileFees.RecordingandTax.Click();
            FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
            FastDriver.FileFees.PayRecordingTax.FAClick();
            FAST_AddFileFeeRecDisbursementPayee(GABCode, charges);
            #endregion
        }

        protected void FAST_SelectFeesForPayee(string GABCode = null, Dictionary<string,TableAction> charges = null, bool all = false, bool none = false)
        {
            #region Add File Fees Recording Payee
            FastDriver.FileFees.Open();
            FastDriver.FileFees.RecordingandTax.Click();
            FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
            FastDriver.FileFees.PayRecordingTax.FAClick();
            FastDriver.RecordFeeTransferTaxDisb.SwitchToContentFrame();
            if (all) FastDriver.RecordFeeTransferTaxDisb.All.Click();
            if (none) FastDriver.RecordFeeTransferTaxDisb.None.Click();
            if (charges != null)
            {
                foreach (var valuePair in charges)
                {
                    FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, valuePair.Key, 1, valuePair.Value);
                }
            }
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_AddNewLoanChargeDisbursementPayee(string GABCode, string[] charges = null)
        {
            #region Add New LoanDisbursement Payee
            FastDriver.NewLoanDisbursements.SwitchToContentFrame();
            foreach (var description in charges)
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, description, 1, TableAction.Off);
            FastDriver.NewLoanDisbursements.New.FAClick();
            FastDriver.NewLoanDisbursements.GABcode.FASetText(GABCode);
            FastDriver.NewLoanDisbursements.Find.FAClick();
            FastDriver.NewLoanDisbursements.WaitCreation(FastDriver.NewLoanDisbursements.IDCode);
            foreach(var description in charges)
                FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(2, description, 1, TableAction.On);
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_AddFileFeeRecDisbursementPayee(string GABCode, string[] charges = null)
        {
            #region Add New LoanDisbursement Payee
            FastDriver.RecordFeeTransferTaxDisb.SwitchToContentFrame();
            foreach (var description in charges)
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, description, 1, TableAction.Off);
            FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
            FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText(GABCode);
            FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
            FastDriver.RecordFeeTransferTaxDisb.WaitCreation(FastDriver.NewLoanDisbursements.IDCode);
            foreach (var description in charges)
                FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, description, 1, TableAction.On);
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_VerifyRecordingFeesDeed(string[,] feeValues)
        {
            #region Verify Recording Fee - Deed
            Support.AreEqual(feeValues[0, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(1, 1, TableAction.GetText, countVisibles: false).Element.GetAttribute("textContent")), "Recording");
            Support.AreEqual(feeValues[0, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(1, 2, TableAction.GetText, countVisibles: false).Message);
            for (var i = 1; i < feeValues.GetLength(0); i++)
            {
                Support.AreEqual(feeValues[i, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(i + 1, 1, TableAction.GetCell, countVisibles: false).Element.GetAttribute("textContent")), "Deed");
                Support.AreEqual(feeValues[i, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(i + 1, 2, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 2], FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(i + 1, 3, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 3], FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(i + 1, 4, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 4], FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(i + 1, 5, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 5], FastDriver.ClosingDisclosure.ItemizedRecFeeDeedTable.PerformTableAction(i + 1, 6, TableAction.GetText, countVisibles: false).Message);
            }
            #endregion
        }

        protected void FAST_VerifyRecordingFeesMortgage(string[,] feeValues)
        {
            #region Verify Recording Fee - Mortgage
            Support.AreEqual(feeValues[0, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(1, 1, TableAction.GetText, countVisibles: false).Element.GetAttribute("textContent")), "Recording");
            Support.AreEqual(feeValues[0, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(1, 2, TableAction.GetText, countVisibles: false).Message);
            for (var i = 1; i < feeValues.GetLength(0); i++)
            {
                Support.AreEqual(feeValues[i, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(i + 1, 1, TableAction.GetCell, countVisibles: false).Element.GetAttribute("textContent")), "Mortgage");
                Support.AreEqual(feeValues[i, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(i + 1, 2, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 2], FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(i + 1, 3, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 3], FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(i + 1, 4, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 4], FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(i + 1, 5, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 5], FastDriver.ClosingDisclosure.ItemizedRecFeeMortgageTable.PerformTableAction(i + 1, 6, TableAction.GetText, countVisibles: false).Message);
            }
            #endregion
        }
        
        protected void FAST_VerifyRecordingFeesRelease(string[,] feeValues)
        {
            #region Verify Recording Fee - Release
            Support.AreEqual(feeValues[0, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(1, 1, TableAction.GetText, countVisibles: false).Element.GetAttribute("textContent")), "Recording");
            Support.AreEqual(feeValues[0, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(1, 2, TableAction.GetText, countVisibles: false).Message);
            for (var i = 1; i < feeValues.GetLength(0); i++)
            {
                Support.AreEqual(feeValues[i, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(i + 1, 1, TableAction.GetCell, countVisibles: false).Element.GetAttribute("textContent")), "Release");
                Support.AreEqual(feeValues[i, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(i + 1, 2, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 2], FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(i + 1, 3, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 3], FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(i + 1, 4, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 4], FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(i + 1, 5, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 5], FastDriver.ClosingDisclosure.ItemizedRecFeeReleaseTable.PerformTableAction(i + 1, 6, TableAction.GetText, countVisibles: false).Message);
            }
            #endregion
        }

        protected void FAST_VerifyRecordingFeesMisc(string[,] feeValues)
        {
            #region Verify Recording Fee - Miscellaneous
            Support.AreEqual(feeValues[0, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(1, 1, TableAction.GetText, countVisibles: false).Element.GetAttribute("textContent")), "Recording");
            Support.AreEqual(feeValues[0, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(1, 2, TableAction.GetText, countVisibles: false).Message);
            for (var i = 1; i < feeValues.GetLength(0); i++)
            {
                Support.AreEqual(feeValues[i, 0], (FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(i + 1, 1, TableAction.GetCell, countVisibles: false).Element.GetAttribute("textContent")), "Misc");
                Support.AreEqual(feeValues[i, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(i + 1, 2, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 2], FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(i + 1, 3, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 3], FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(i + 1, 4, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 4], FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(i + 1, 5, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 5], FastDriver.ClosingDisclosure.ItemizedRecFeeMiscTable.PerformTableAction(i + 1, 6, TableAction.GetText, countVisibles: false).Message);
            }
            #endregion
        }

        protected void FAST_VerifyRecordingFeesLender(string[,] feeValues)
        {
            #region Verify Recording Fee - Lender
            Support.AreEqual(feeValues[0, 0], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(1, 1, TableAction.GetText, countVisibles: false).Element.GetAttribute("textContent"));
            Support.AreEqual(feeValues[0, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(1, 2, TableAction.GetText, countVisibles: false).Message);
            for (var i = 1; i < feeValues.GetLength(0); i++)
            {
                Support.AreEqual(feeValues[i, 0], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(i + 1, 1, TableAction.GetCell, countVisibles: false).Element.GetAttribute("textContent"));
                Support.AreEqual(feeValues[i, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(i + 1, 2, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 2], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(i + 1, 3, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 3], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(i + 1, 4, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 4], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(i + 1, 5, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 5], FastDriver.ClosingDisclosure.ItemizedRecFeeLenderTable.PerformTableAction(i + 1, 6, TableAction.GetText, countVisibles: false).Message);
            }
            #endregion
        }

        protected void FAST_VerifyRecordingFeesMB(string[,] feeValues)
        {
            #region Verify Recording Fee - Mortgage Broker
            Support.AreEqual(feeValues[0, 0], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(1, 1, TableAction.GetText, countVisibles: false).Element.GetAttribute("textContent"));
            Support.AreEqual(feeValues[0, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(1, 2, TableAction.GetText, countVisibles: false).Message);
            for (var i = 1; i < feeValues.GetLength(0); i++)
            {
                Support.AreEqual(feeValues[i, 0], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(i + 1, 1, TableAction.GetCell, countVisibles: false).Element.GetAttribute("textContent"));
                Support.AreEqual(feeValues[i, 1], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(i + 1, 2, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 2], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(i + 1, 3, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 3], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(i + 1, 4, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 4], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(i + 1, 5, TableAction.GetText, countVisibles: false).Message);
                Support.AreEqual(feeValues[i, 5], FastDriver.ClosingDisclosure.ItemizedRecFeeMBTable.PerformTableAction(i + 1, 6, TableAction.GetText, countVisibles: false).Message);
            }
            #endregion
        }

        protected void FAST_VerifyGFaithAnalisys0Cat(string[,] chargeValues)
        {
            #region Verify Good Faith analisys 0% category
            for (var i = 0; i < chargeValues.GetLength(0); i++)
            {
                for (var j = 0; j < chargeValues.GetLength(1); j++)
                {
                    if (string.IsNullOrEmpty(chargeValues[i, j])) continue;
                    Support.AreEqual(chargeValues[i, j], FastDriver.ClosingDisclosure.GoodFaithAnalisys0Table.PerformTableAction(i + 1, j + 1, TableAction.GetText).Message);
                }
            }
            #endregion
        }

        protected void FAST_VerifyGFaithAnalisys10Cat(string[,] chargeValues)
        {
            #region Verify Good Faith analisys 10% category
            for (var i = 0; i < chargeValues.GetLength(0); i++)
            {
                for (var j = 0; j < chargeValues.GetLength(1); j++)
                {
                    if (string.IsNullOrEmpty(chargeValues[i, j])) continue;
                    Support.AreEqual(chargeValues[i, j], FastDriver.ClosingDisclosure.GoodFaithAnalisys10Table.PerformTableAction(i + 1, j + 1, TableAction.GetText).Message);
                }
            }
            #endregion
        }

        protected void FAST_VerifyLenderCreditAnalysis(string[,] chargeValues)
        {
            #region Verify Good Faith analisys 10% category
            FastDriver.ClosingDisclosure.LenderCreditAnalysis.FAClick();
            for (var i = 0; i < chargeValues.GetLength(0); i++)
            {
                for (var j = 0; j < chargeValues.GetLength(1); j++)
                {
                    if (string.IsNullOrEmpty(chargeValues[i, j])) continue;
                    Support.AreEqual(chargeValues[i, j], FastDriver.ClosingDisclosure.tblLenderCreditsSubSection.PerformTableAction(i + 1, j + 1, TableAction.GetText).Message);
                }
            }
            #endregion
        }

        protected void FAST_VerifyGFaithVariance(string[,] cat0Table=null, string[,] cat10Table=null, string[,] lenderCredits=null, double increaseTotal=0 )
        {
            #region Verify Good Faith Variance tables
            FastDriver.ClosingDisclosure.Open();
            FastDriver.ClosingDisclosure.VarianceTab.FAClick();
            Playback.Wait(4500);
            FastDriver.ClosingDisclosure.WaitForGoodFaithVarianceScreenToLoad();
            if (cat0Table != null)
                FAST_VerifyGFaithAnalisys0Cat(cat0Table);
            if (cat10Table != null)
                FAST_VerifyGFaithAnalisys10Cat(cat10Table);
            if (lenderCredits != null)
                FAST_VerifyLenderCreditAnalysis(lenderCredits);
            if (increaseTotal > 0)
            {
                if (FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.GoodFaith0and10Total, 3))
                    Support.AreEqual(increaseTotal.ToString("C2"), FastDriver.ClosingDisclosure.GoodFaith0and10Total.Text);
                else
                    Support.IsTrue(false, "Missing 'Increase in Closing Costs above legal limits - Total 0% and 10% Category'");
            }
            #endregion
        }

        protected void FAST_AdjustDeposit(string amount, int reasonIndex, string comment, bool mustScroll=false, string correctAmt= null)
        {
            #region Adjust deposits
            FastDriver.DepositSummary.Open();
            if (mustScroll)
                FastDriver.DepositSummary.Receipts_DepositActivitytable.SendKeys(OpenQA.Selenium.Keys.PageDown);
            FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(6, amount, 6, TableAction.Click);
            FastDriver.DepositSummary.Adjust.FAClick();
            FastDriver.DepositAdjustment.WaitForScreenToLoad();
            FastDriver.DepositAdjustment.AdjustmentReason.FASelectItemByIndex(reasonIndex);
            FastDriver.DepositAdjustment.Comment.FASetText(comment);
            if (FastDriver.DepositAdjustment.CorrectAmount.Exists())
                FastDriver.DepositAdjustment.CorrectAmount.FASetText(correctAmt ?? amount);
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.WaitForAlertToExist(10);
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);
            FastDriver.BottomFrame.Done();
            FastDriver.DepositSummary.WaitForScreenToLoad();
            Support.AreEqual("Adjusted", FastDriver.DepositSummary.Receipts_DepositActivitytable.PerformTableAction(6, amount, 1, TableAction.GetText).Message.Trim());
            #endregion
        }

        protected void FAST_AdjustDisbursement(string amount, int reasonIndex, string comment, bool mustScroll = false, string docNo = "")
        {
            #region Adjust deposits
            FastDriver.DisbursementHistory.Open();
            if (mustScroll)
                FastDriver.DisbursementHistory.DisbursementTable.SendKeys(OpenQA.Selenium.Keys.PageDown);
            FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(7, amount, 6, TableAction.Click);
            FastDriver.DisbursementHistory.Adjust.Click();
            FastDriver.DisbursementAdjustment.WaitForScreenToLoad();
            FastDriver.DisbursementAdjustment.AdjustmentReason.FASelectItemByIndex(reasonIndex);
            FastDriver.DisbursementAdjustment.Comment.FASetText(comment);
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.WaitForAlertToExist(10);
            FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: false);
            FastDriver.BottomFrame.Done();
            FastDriver.DisbursementHistory.WaitForScreenToLoad();
            Support.AreEqual("Iss/Adj", FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction(5, docNo, 1, TableAction.GetText).Message.Trim());
            #endregion
        }

        protected void FAST_AddRealStateBroker(string gabCode, string type, string commisionPtg="10")
        {
            #region Add Real State Broker Buyer
            FastDriver.RealEstateBrokerAgentSummary.Open();
            if (type == "Buyer")
            {
                FastDriver.RealEstateBrokerAgentSummary.BuyerBrokerName.Click();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Click();
            }
            else if (type == "Seller")
            {
                FastDriver.RealEstateBrokerAgentSummary.SellerbrokerName.Click();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Click();
            }
            else
            {
                FastDriver.RealEstateBrokerAgentSummary.NewOther.Click();
            }
            FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(gabCode);
            FastDriver.RealEstateBrokerAgent.BrokerInformationFind.Click();
            Playback.Wait(3000);
            FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(commisionPtg);
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
            #endregion
        }        
        
        protected void FAST_AddHoldFunds(bool isBuyer, string reason, string releaseDays, string charge, string gabCode, string hfCharge)
        {
            #region Hold Funds for Buyer & Seller
            FastDriver.HoldFunds.Open();
            FastDriver.BottomFrame.New();
            FastDriver.HoldFunds.WaitForScreenToLoad();
            FastDriver.HoldFunds.Reason.FASetText(reason);
            FastDriver.HoldFunds.ReleaseinDays.FASetText(releaseDays);
            if (isBuyer)
            {
                FastDriver.HoldFunds.RadbtnBuyer.Click();
                FastDriver.HoldFunds.BuyerCharge.FASetText(charge);
            }
            else
            {
                FastDriver.HoldFunds.RadbtnSeller.Click();
                FastDriver.HoldFunds.SellerCharge.FASetText(charge);
            }
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.HoldFunds.New.FAClick();
            FastDriver.HoldFunds.WaitForDisbursementScreenToLoad();
            FastDriver.HoldFunds.HoldFundBusPartyGABcode.FASetText(gabCode);
            FastDriver.HoldFunds.Find.FAClick();
            Playback.Wait(3000);
            if (string.IsNullOrEmpty(FastDriver.HoldFunds.HoldFundChargesDescription1.Text.Trim()))
            {
                FastDriver.HoldFunds.HoldFundChargesDescription1.Click();
                FastDriver.HoldFunds.HoldFundChargesDescription1.SendKeys("Test Adhoc Charge Description");
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (isBuyer)
                FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText(hfCharge);
            else
                FastDriver.HoldFunds.HoldFundSellerCharge1.FASetText(hfCharge);
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void FAST_WCF_VerifyEscrowPDD(dynamic _pdd, FASTSelenium.DataObjects.IIS.PDD paymentDetails)
        {
            #region Verify Charge Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails;

            Support.IsTrue(pdd.IsDisbursed == null || pdd.IsDisbursed == 0 || pdd.IsDisbursed == 1, "US510201 IsDisbursed flag");
            //  BuyerDetails
            Support.AreEqual(((Decimal)paymentDetails.BuyerCharge).ToString("C2"), ((Decimal)pdd.BuyerCharge).ToString("C2"), "BuyerCharge");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLBuyer.ToString().ToLowerInvariant(), "DisplayLBuyer");
            Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)pdd.PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)pdd.PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)pdd.PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod.ToLowerInvariant(), pdd.PBOthersForBuyerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForBuyerPMTypeCdID");
            Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingBuyerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingBuyerPaymentMethodTypeID");
            //
            if(string.IsNullOrEmpty(paymentDetails.ChargeDescription) == false)
                Support.AreEqual(paymentDetails.ChargeDescription, pdd.Description, "Description");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), pdd.DoubleAsteriskIndicator.ToString().ToLowerInvariant(), "DoubleAsteriskIndicator");
            //  Loan Estimate
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("N2"), ((Decimal)pdd.LEAmount).ToString("N2"), "LEAmount");
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateRounded).ToString("N2"), ((Decimal)pdd.RoundedLEAmount).ToString("N2"), "RoundedLEAmount");
            // 
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), pdd.PartOf.ToString().ToLowerInvariant(), "PartOf");
            if (string.IsNullOrEmpty(paymentDetails.PayTo) == false)
                Support.AreEqual(paymentDetails.PayTo, pdd.PayTo, "PayTo");
            if (string.IsNullOrEmpty(paymentDetails.PayeeName) == false)
                Support.AreEqual(paymentDetails.PayeeName, pdd.PayeeNameOnCDOrSettlementStmt, "PayeeName");
            //  SectionShopDetails
            if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionBdidNotShopFor)
                Support.IsTrue(paymentDetails.SectionBdidnotShopFor, "SectionBdidnotShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionCdidShopFor)
                Support.IsTrue(paymentDetails.SectionCDidShopFor, "SectionCDidShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionHotherCosts)
                Support.IsTrue(paymentDetails.SectionHOtherCosts, "SectionHOtherCosts");
            //  SellerDetails
            Support.AreEqual(((Decimal)paymentDetails.SellerCharge).ToString("C2"), ((Decimal)pdd.SellerCharge).ToString("C2"), "SellerCharge");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLSeller.ToString().ToLowerInvariant(), "DisplayLSeller");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)pdd.PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)pdd.PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)pdd.PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd.ToLowerInvariant(), pdd.PBOthersForSellerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForSellerPMTypeCdID");
            Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingSellerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingSellerPaymentMethodTypeID");
            //
            Support.AreEqual(((Decimal)paymentDetails.TotalCharge).ToString("C2"), ((Decimal)pdd.TotalCharge).ToString("C2"), "TotalCharge");
            #endregion
        }

        protected void FAST_WCF_VerifyFilePDD(dynamic _pdd, FASTSelenium.DataObjects.IIS.PDD paymentDetails)
        {
            #region Verify Charge Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastFileService.CDChargePaymentDetails;

            //  BuyerDetails
            Support.AreEqual(((Decimal)paymentDetails.BuyerCharge).ToString("C2"), ((Decimal)pdd.BuyerCharge).ToString("C2"), "BuyerCharge");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLBuyer.ToString().ToLowerInvariant(), "DisplayLBuyer");
            Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)pdd.PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)pdd.PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)pdd.PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod.ToLowerInvariant(), pdd.PBOthersForBuyerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForBuyerPMTypeCdID");
            Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingBuyerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingBuyerPaymentMethodTypeID");
            //
            if (string.IsNullOrEmpty(paymentDetails.ChargeDescription) == false)
                Support.AreEqual(paymentDetails.ChargeDescription, pdd.Description, "Description");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), pdd.DoubleAsteriskIndicator.ToString().ToLowerInvariant(), "DoubleAsteriskIndicator");
            //  Loan Estimate
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("N2"), pdd.LEAmount.ToString("N2"), "LEAmount");
            Support.AreEqual(paymentDetails.LoanEstimateRounded != null ? ((Decimal)paymentDetails.LoanEstimateRounded).ToString("N2") : Math.Round(paymentDetails.LoanEstimateUnrounded ?? 0, 0).ToString("N2"),
                pdd.RoundedLEAmount != null ? pdd.RoundedLEAmount.ToString("N2") : Math.Round(pdd.LEAmount ?? 0, 0).ToString("N2"), "RoundedLEAmount");
            // 
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), pdd.PartOf.ToString().ToLowerInvariant(), "PartOf");
            if (string.IsNullOrEmpty(paymentDetails.PayTo) == false)
                Support.AreEqual(paymentDetails.PayTo, pdd.PayTo, "PayTo");
            if (string.IsNullOrEmpty(paymentDetails.PayeeName) == false)
                Support.AreEqual(paymentDetails.PayeeName, pdd.PayeeNameOnCDOrSettlementStmt, "PayeeName");
            //  SectionShopDetails
            if (pdd.eSectionShop == FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionBdidNotShopFor)
                Support.IsTrue(paymentDetails.SectionBdidnotShopFor, "SectionBdidnotShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionCdidShopFor)
                Support.IsTrue(paymentDetails.SectionCDidShopFor, "SectionCDidShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionHotherCosts)
                Support.IsTrue(paymentDetails.SectionHOtherCosts, "SectionHOtherCosts");
            //  SellerDetails
            Support.AreEqual(((Decimal)paymentDetails.SellerCharge).ToString("C2"), ((Decimal)pdd.SellerCharge).ToString("C2"), "SellerCharge");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLSeller.ToString().ToLowerInvariant(), "DisplayLSeller");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)pdd.PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)pdd.PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)pdd.PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd.ToLowerInvariant(), pdd.PBOthersForSellerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForSellerPMTypeCdID");
            Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingSellerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingSellerPaymentMethodTypeID");
            //
            Support.AreEqual(paymentDetails.TotalCharge != null ? ((Decimal)paymentDetails.TotalCharge).ToString("C2") : ((Decimal)(paymentDetails.BuyerCharge + paymentDetails.SellerCharge)).ToString("N2"),
                pdd.TotalCharge != null ? ((Decimal)pdd.TotalCharge).ToString("C2") : ((Decimal)pdd.BuyerCharge + pdd.SellerCharge).ToString("N2"), "TotalCharge");
            #endregion
        }

        protected void FAST_WCF_VerifyFilePDD(dynamic _pdd, FASTSelenium.DataObjects.IIS.hudPDD paymentDetails)
        {
            #region Verify Charge Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastFileService.PaymentDetailsWithGFE;

            if (paymentDetails.Description != null)
                Support.AreEqual(pdd.Description, paymentDetails.Description, "Description");
            if (paymentDetails.PayTo != null)
                Support.AreEqual(pdd.PayTo, paymentDetails.PayTo, "PayTo");
            if (paymentDetails.UseDefault != null)
                Support.AreEqual(pdd.UseDefault.ToString(), paymentDetails.UseDefault.ToString(), "Use Default");
            if (paymentDetails.BuyerCharge != null)
                Support.AreEqual(pdd.BuyerCharge.ToString("N2"), paymentDetails.BuyerCharge.ToString("N2"), "Buyer Charge");
            if (paymentDetails.BuyerPaymentMethod != null)
                Support.AreEqual(pdd.BuyerPaymentMethodTypeID.ToString(), paymentDetails.BuyerPaymentMethodTypeID, "Buyer Payment Method Type ID");
            if (paymentDetails.SellerCharge != null)
                Support.AreEqual(pdd.SellerCharge.ToString("N2"), paymentDetails.SellerCharge.ToString("N2"), "Seller Charge");
            if (paymentDetails.SellerPaymentMethod != null)
                Support.AreEqual(pdd.SellerPaymentMethodTypeID.ToString(), paymentDetails.SellerPaymentMethodTypeID, "Seller Payment Method Type ID");
            if (paymentDetails.GFE != null)
                Support.AreEqual(pdd.GfeEntryTypeCdID.ToString(), paymentDetails.GfeTypeID, "GFE Type ID");
            if (paymentDetails.LenderSelectedProvider != null)
                Support.AreEqual(pdd.LenderSelectedProvider.ToString(), paymentDetails.LenderSelectedProvider.ToString(), "Lender Selected Provider");
            if (paymentDetails.PaidOnBehalfOfBorrower != null)
                Support.AreEqual(pdd.PaidOnBehalfOfBorrower.ToString(), paymentDetails.PaidOnBehalfOfBorrower.ToString(), "Paid On Behalf Of Borrower");
            #endregion
        }

        protected void PerformDelivery(string deliveryMethod, PageObject Obj)
        {
            Obj.SwitchToContentFrame();
            IWebElement DeliveryMethodCombo = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "cboMethod");
            IWebElement DeliverButton = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "btnDeliver");
            Reports.TestStep = "Perform the " + deliveryMethod + " delivery method.";
            if (DeliveryMethodCombo.IsEnabled())
            DeliveryMethodCombo.FASelectItem(deliveryMethod);
            DeliverButton.FAClick();
            if(isAlertPresent())
            FastDriver.WebDriver.HandleDialogMessage();
            switch (deliveryMethod)
            {
                case "Email":
                    {
                        FastDriver.EmailDlg.WaitForDialogToLoad();
                        FastDriver.EmailDlg.SendEmail();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Print":
                    {
                        if (!isAlertPresent())
                        {
                            FastDriver.PrintDlg.SelectPrinter();
                            FastDriver.PrintDlg.ClickPrint();
                            HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        }
                        else
                        {
                            Reports.StatusUpdate("Printer is not configured correctly", false);
                        }
                        break;
                    }
                case "Fax":
                    {
                        FastDriver.FaxDlg.WaitForScreenToLoad();
                        FastDriver.FaxDlg.SendFax();
                         HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        break;
                    }
                case "Preview":
                    {
                        if (HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 250 ? 250 : int.Parse(AutoConfig.WaitTime) * 3))
                        {
                            Reports.TestStep = "Save PDF file";
                            string tempPdfFile = @"C:\Temp\temp.PDF";
                            SavePDFFile(tempPdfFile);
                        }
                        break;
                    }
                case "Imagedoc":
                    {
                        FastDriver.ImageDocDlg.WaitForScreenToLoad();
                        FastDriver.ImageDocDlg.ImageDoc.FAClick();
                        HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        break;
            }
                case "WINTRACK":
                    {
                        HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        break;
        }
                case "LVIS":
                    {
                        HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        break;
                    }
                case "FASTWEB":
                    {
                        HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        break;
                    }
                case "LA.COM":
                    {
                        HandleDeliveryFailure(@"LA.COM", int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        break;
                    }
            }
        }
        //
        private void SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Random ran = new Random();
                int ranNumber = ran.Next(250);
                Playback.Wait(5000);
                PDFFilePath = PDFFilePath.Replace(".PDF", ranNumber + ".PDF");

                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
        }
        //
        private bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FADeliveryMethod method = new FADeliveryMethod();
                if (!deliveryMethod.Equals(@"LA.COM", StringComparison.CurrentCultureIgnoreCase))
                method=(FADeliveryMethod)System.Enum.Parse(typeof(FADeliveryMethod), deliveryMethod,true);
                else
                    method = FADeliveryMethod.LADOTCOM;
                try
                {
                    string selectedMethod = FastDriver.Delivery.GetDeliveryWindowTitle(method);
                    //FastDriver.WebDriver.WaitForWindowAndSwitch(selectedMethod, true, 15);
                    FastDriver.WebDriver.SwitchTo().DefaultContent();
                    WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(15));
                    wait.Until(w => FastDriver.WebDriver.WindowIsDisplayed(selectedMethod) == true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }//wait for the delivery window to show up
                catch (WebDriverTimeoutException)
                {

                    if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                    {
                        FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                        FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                        FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    }
                    else if (FastDriver.PasswordConfirmationDlg.IsPasswordConfirmationDialogPresent())
                    { // Password Confirmation
                        FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                    }
                }
                FastDriver.WebDriver.WaitForDeliveryWindow(method, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }
        //
        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                if (Message.Contains("No printer") || Message.Contains("error while populating printers"))
                {
                    Reports.StatusUpdate("Printer is not configured", false);
                }
                else if (string.IsNullOrEmpty(Message))
                {
                    return false;
                }

                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }

        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);

        }
        protected void ProjectFileChk(bool projectfileCHK = true,string OfficeBUID="7879")
        {

            Reports.TestStep = "Make projectfile checked";

            ADMLOGIN(AutoConfig.UserNameSU, AutoConfig.UserPasswordSU);

            Reports.TestStep = "Navigate to Region Level.";
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office");
            FastDriver.SecuritySelectRegionOffice.WaitForScreenToLoad();
            FastDriver.SecuritySelectRegionOffice.SelectRegionOffice(AutoConfig.SelectedRegionBUID);

            Reports.TestStep = "Navigate to Auto cd office and check the Assign policy check box";
            FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>" + OfficeBUID);
            Playback.Wait(5000);
            FastDriver.OfficeSetupOffice.SwitchToContentFrame();
            FastDriver.OfficeSetupOffice.ProjectFile.FASetCheckbox(projectfileCHK);
            FastDriver.BottomFrame.Done();


        }


        #endregion

        /// <summary>
        /// Find Visible IWebElement
        /// </summary>
        /// <param name="locator">ByLocator</param>
        /// <param name="criteria">Criteria</param>
        /// <returns>Found IWebElement</returns>
        public static IWebElement FindVisibleElement(ByLocator locator, string criteria)
        {
            List<IWebElement> list = FastDriver.WebDriver.FAFindElements(locator, criteria).ToList();

            return list.Where<IWebElement>(x => x.Displayed).First();
        }

        /// <summary>
        /// Convert an Object to JSON String
        /// </summary>
        /// <param name="obj">Object to be converted</param>
        /// <returns>JSON String representing the Object</returns>
        public static string ToJSON<T>(object obj)
        {
            var _json = obj.ToJSON();

            Reports.StatusUpdate(typeof(T).Name, status: true, controlType: "Object", action: "ToJSON", property: "http://jsonparseronline.com/", actualValue: _json);

            return _json;
        }

        /// <summary>
        /// Click with the Mouse Pointer directly
        /// </summary>
        /// <param name="point">Screen Point</param>
        /// <param name="mouseButton">Mouse Button</param>
        /// <param name="keyModifier">Key Modifier</param>
        public static void MouseClick(System.Drawing.Point point, System.Windows.Forms.MouseButtons mouseButton = System.Windows.Forms.MouseButtons.Left, System.Windows.Input.ModifierKeys keyModifier = System.Windows.Input.ModifierKeys.None)
        {
            Reports.StatusUpdate(controlDescription: "Mouse", status: true, controlType: "System Input Device", action: mouseButton.ToString() + "~Click", expectedValue: point.ToString());
            Mouse.Click(mouseButton, keyModifier, point);
        }

        /// <summary>
        /// Move the Mouse Pointer for hovering
        /// </summary>
        /// <param name="point">Screen Point</param>
        public static void MouseMove(System.Drawing.Point point)
        {
            Reports.StatusUpdate(controlDescription: "Mouse", status: true, controlType: "System Input Device", action: "Move", expectedValue: point.ToString());
            Mouse.Move(point);
        }

        /// <summary>
        /// Send text with the System Keyboard directly
        /// </summary>
        /// <param name="text">Text</param>
        /// <param name="keyModifier">Key Modifier</param>
        public static void KeyboardSendKeys(string text, System.Windows.Input.ModifierKeys keyModifier = System.Windows.Input.ModifierKeys.None)
        {
            Reports.StatusUpdate(controlDescription: "Keyboard", status: true, controlType: "System Input Device", action: "SendKeys", expectedValue: string.Format("Keys:{0} Modifier:{1}", text, keyModifier));
            Keyboard.SendKeys(text, keyModifier);
        }

        /// <summary>
        ///     Gets the center point on the screen
        /// </summary>
        /// <returns>Graphic Point</returns>
        public static System.Drawing.Point GetCenterPoint()
        {
            int documentWidth = Convert.ToInt32(FastDriver.WebDriver.Execute("return window.innerWidth"));
            int documentHeight = Convert.ToInt32(FastDriver.WebDriver.Execute("return window.innerHeight"));

            return new System.Drawing.Point(documentWidth / 2, documentHeight / 2);
        }

        /// <summary>
        ///     Gets the text available in the system clipboard
        /// </summary>
        /// <returns>Text String</returns>
        public static string GetClipboardText()
        {
            try
            {
                return System.Windows.Forms.Clipboard.GetText();
            }
            catch
            {
                return string.Empty;
            }
        }

        /// <summary>
        ///     Clear the system clipboard data
        /// </summary>
        public static void ClearClipboard()
        {
            System.Windows.Forms.Clipboard.Clear();
        }

        public static bool AutoClearClipboard = false;

        #region NextGen
        public static FASTWCFHelpers.FastFileService.CreateFileRequest GetNextGenWCFFileRequest()
        {
            CreateFileRequest nextGenRequest = FileRequestFactory.GetCreateFileDefaultRequest();
            nextGenRequest.Source = "LVIS";
            nextGenRequest.File.Services[0].OfficeInfo.RegionID = 12837;
            nextGenRequest.File.Services[0].OfficeInfo.BUID = 12839;
            nextGenRequest.File.Services[1].OfficeInfo.RegionID = 12837;
            nextGenRequest.File.Services[1].OfficeInfo.BUID = 12839;
            nextGenRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", 12837);

            return nextGenRequest;
        }

        public static bool NextGen_FAST_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using FAST GUI.";
                FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
                try
                {
                    FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
                }
                catch
                {
                    Reports.StatusUpdate("Duplicate file search screen is disabled.", true);
                }

                FastDriver.QuickFileEntry.CreateStandardFile();
                FAST_LoadCurrentFile(12837);
            }
            catch
            {
                throw new Exception("File could not be created");
            }

            return true;
        }

        public static bool NextGen_WCF_CreateFile()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public static bool NextGen_WCF_CreateFileWithNewLoan()
        {
            try
            {
                Reports.TestStep = "Create File using web service.";
                var nextGenRequest = GetNextGenWCFFileRequest();
                nextGenRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan()
                {
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", 12837) },
                    LiabilityAmount = 5000.02m,
                    NewLoanAmount = 5000.01m,
                };
                nextGenRequest.File.SalesPriceAmount = 2500.0m;
                nextGenRequest.File.LiabilityAmount = 5000.0m;
                FAST_WCF_CreateFile(nextGenRequest);
            }
            catch
            {
                return false;
            }

            return true;
        }

        /// <summary>
        ///     Create Doc using the Web Service CreateDocument
        /// </summary>
        /// <param name="templateID"></param>
        /// <param name="empid"></param>
        /// <param name="src"></param>
        /// <returns>Document ID</returns>
        public static int CreateDoc(int templateID, int empid = 1, string src = "FAMOS", int regionId = 12837)
        {
            DocumentResponse docresponseobj = CreateDocumentusingWCFService(templateID, empid, src, regionId);
            Support.AreEqual("1", docresponseobj.Status.ToString());
            Support.AreEqual("Create Document Successfully.", docresponseobj.StatusDescription.ToString());
            int DocumentID = System.Convert.ToInt32(docresponseobj.DocumentID);
            Reports.PrintLog(DocumentID.ToString());

            return DocumentID;
        }

        private static DocumentResponse CreateDocumentusingWCFService(int templateID, int empid, string src, int regionId)
        {
            var CreateDocReq = FileRequestFactory.GetCreateDocumentDefaultRequest(FASTHelpers.File.FileID ?? 0, templateID);
            CreateDocReq.TitleReportDocumentID = null;
            CreateDocReq.EmployeeID = empid;
            CreateDocReq.TemplateRegionID = regionId;
            CreateDocReq.LoginName = "fastts\fastqa07";
            CreateDocReq.Source = src;

            return FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);
        }

        /// <summary>
        ///     Verify if template exists by using the Web Service GetDefaultDocTemplates
        /// </summary>
        /// <param name="TemplatePos"></param>
        /// <param name="docTemplateTypeID"></param>
        /// <param name="tempdesc"></param>
        /// <param name="empid"></param>
        /// <param name="src"></param>
        /// <returns>Template ID</returns>
        public static int VerifyTemplates(int TemplatePos, int docTemplateTypeID, string tempdesc, string empobjcd = "5", string src = "FAMOS", int regionId = 12837)
        {
            DocTemplateResponse responceObj = GetDefaultDocTemplates(docTemplateTypeID, regionId, tempdesc, empobjcd);
            Support.AreEqual("1", responceObj.Status.ToString());
            //Support.AreEqual(tempdesc, responceObj.Templates.Length > TemplatePos ? responceObj.Templates[TemplatePos].Descr.ToString() : "", "Template Description");
            int templateID = responceObj.Templates.Length > TemplatePos ? responceObj.Templates[TemplatePos].TemplateID.Value : -1;
            Reports.PrintLog(templateID.ToString());
            Reports.StatusUpdate("Did the web service GetDocTemplates returned templates? " + (responceObj.Status == 1 && templateID != -1).ToString().ToUpperInvariant(), true);
            Reports.StatusUpdate("Template ID: " + templateID, true);

            return templateID;
        }

        /// <summary>
        ///     Get Default Doc Templates 
        /// </summary>
        /// <param name="DocTemplateTypeId"></param>
        /// <param name="regionId"></param>
        /// <param name="tempdesc"></param>
        /// <param name="empobjcd"></param>
        /// <returns></returns>
        public static DocTemplateResponse GetDefaultDocTemplates(int DocTemplateTypeId = 0, int regionId = 0, string tempdesc = null, string empobjcd = null)
        {

            Reports.TestStep = "Call GetDocTemplates service to get TemplateID, DocType and Document name";
            var GetDocTempReq = DocumentRequestFactory.GetDocTemplatesDefaultRequest(DocTemplateTypeId, regionId, tempdesc, empobjcd);
            return FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);

        }

        /// <summary>
        ///     Create a New Template
        /// </summary>
        /// <param name="templateName"></param>
        /// <param name="templateDesc"></param>
        /// <param name="templateType"></param>
        /// <param name="officeId"></param>
        public static void CreateNewTemplate(string templateName, string templateDesc, string templateType, int officeId = 12738)
        {
            Reports.TestDescription = "Create templates for use with the rest of DocGen tests";

            FAST_Login_ADM(isSuperUser: false);
            FAST_OpenRegionOrOffice(officeId);

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region templates

            // *** Create Templates (if not already exit in environment)
            // SAN-NEXTGEN100 NEXTGEN_SAN_EscrowInstruction_DoNotTouch      => copied from QAMJJP0010 "Escrow Instruction QA MJJP Test 1"
            // SAN-NEXTGEN200 NEXTGEN_SAN_TitleReports_DoNotTouch           => copied from QAMJJP0011 "Title Report QA MJJP 1"
            // SAN-NEXTGEN300 NEXTGEN_SAN_LenderPolicy_DoNotTouch           => copied from QAMJJP0003 "Lender Policy QA MJJP Test 1"
            // SAN-NEXTGEN400 NEXTGEN_SAN_OwnerPolicy_DoNotTouch            => copied from QAMJJP0001 "Owner Policy QA MJJP Test 1"
            // SAN-NEXTGEN500 NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch   => from TQ02 "Template QA MJJP-DO NOT TOUCH02"

            string[] templates = new string[5];
            templates[0] = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch";
            templates[1] = "NEXTGEN_SAN_TitleReports_DoNotTouch";
            templates[2] = "NEXTGEN_SAN_LenderPolicy_DoNotTouch";
            templates[3] = "NEXTGEN_SAN_OwnerPolicy_DoNotTouch";
            templates[4] = "NEXTGEN_SAN_EndorsementGuarantee_DoNotTouch";

            string[] tempname = new string[5];
            tempname[0] = "SAN-NEXTGEN100";
            tempname[1] = "SAN-NEXTGEN200";
            tempname[2] = "SAN-NEXTGEN300";
            tempname[3] = "SAN-NEXTGEN400";
            tempname[4] = "SAN-NEXTGEN500";

            string[] temptype = new string[5];
            temptype[0] = "Escrow Instruction";
            temptype[1] = "Title Reports";
            temptype[2] = "Lender Policy";
            temptype[3] = "Owner Policy";
            temptype[4] = "Endorsement/Guarantee";

            #endregion

            #region Verify that Sanity_Automation Template is present
            Reports.TestStep = "Check Sanity_Automation Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDesc);
            #endregion

            if (templateExists == false)
            {

                #region Create Escrow Instruction

                if (templateType == "Escrow Instruction")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Escrow Instruction QA MJJP Test 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Escrow Instruction QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[0]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[0]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[0]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Create Title Reports

                if (templateType == "Title Reports")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Title Report QA MJJP 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Title Report QA MJJP 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[1]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[1]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[1]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Create Lender Policy

                if (templateType == "Lender Policy")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Lender Policy QA MJJP Test 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Lender Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[2]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[2]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[2]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Create Owner Policy

                if (templateType == "Owner Policy")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Owner Policy QA MJJP Test 1");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Owner Policy QA MJJP Test 1", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[3]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[3]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[3]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion
                #region Endorsement/Guarantee

                if (templateType == "Endorsement/Guarantee")
                {
                    Reports.TestStep = "Creating Automation Template " + templateDesc + " required for Sanity";
                    FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
                    FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem("All");
                    FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("Template QA MJJP-DO NOT TOUCH02");
                    FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
                    FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", "Template QA MJJP-DO NOT TOUCH02", "Description", TableAction.Click).Element.FARightClick();
                    FastDriver.NextGenDocumentPreparation.CopyTemplate.FASelectContextMenuItem();
                    FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                    FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(tempname[4]);
                    FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(temptype[4]);
                    FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText(templates[4]);
                    if (FastDriver.NextGenDocumentPreparation.UnderConstruction.FAGetAttribute("Checked") == "true")
                        FastDriver.NextGenDocumentPreparation.UnderConstruction.FAClick();
                    FastDriver.NextGenDocumentPreparation.Save.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Loading filters.. please wait...", false);
                    Reports.StatusUpdate("Template: " + templateDesc + " just created", true);
                }
                else
                {
                    Reports.StatusUpdate("Template: " + templateDesc + " already exist or not required", true);
                }

                #endregion

            }

            CloseRelatedProcesses();
        }
        #endregion NextGen

        #region Additional test attributes

        [Conditional("DEBUG")]
        [DebuggerStepThrough]
        public static void EnableSavingIRSamples()
        {
            FASTSelenium.ImageRecognition.IRConfig.canSaveScreenSamples = true;
        }

        public static void CloseRelatedProcesses()
        {
            Support.CloseAllProcessStartingWith("AcroRd");
            Support.CloseAllProcessStartingWith("iexplore");
            Support.CloseAllProcessStartingWith("IEDriverServer");
        }

        [TestInitialize]
        public override void TestInitialize()
        {
            Support.stringHelper = new StringHelper() { NBSP = true, CR = true, LF = true, SP = true };
            StringExtensions.stringHelper = new StringHelper() { NBSP = true, CR = false, LF = false };
            // the different StringHelper classes is to avoid dependency across both projects.
            base.TestInitialize();
        }
        
        #endregion
    }


    public class CodedUIInteractions
    {

        public static bool HandleFileDownloadPrompt_WithPauseAndResume()
        {
            bool IsFileDownloadPromptClosed = false;
            try
            {
                BrowserWindow wnd = new BrowserWindow();
                wnd.SearchProperties[UITestControl.PropertyNames.ClassName] = "IEFrame";

                WinToolBar toolBar = new WinToolBar(wnd);
                //toolBar.SearchProperties["ClassName"] = "DirectUIHWND";
                //toolBar.FilterProperties["TechnologyName"] = "MSAA";
                //toolBar.SearchProperties["ControlType"] = "ToolBar";
                toolBar.SearchProperties[WinToolBar.PropertyNames.Name] = "Notification";
                toolBar.DrawHighlight();

                /*WinButton cancelButton = new WinButton(toolBar);
                cancelButton.SearchProperties[WinButton.PropertyNames.Name] = "Cancel";
                cancelButton.SearchProperties[WinButton.PropertyNames.FriendlyName] = "Cancel";
                cancelButton.SearchProperties[WinButton.PropertyNames.ClassName] = "DirectUIHWND";
                cancelButton.DrawHighlight();

                WinButton viewDownloads = new WinButton(toolBar);
                viewDownloads.SearchProperties[WinButton.PropertyNames.Name] = "View downloads";
                viewDownloads.SearchProperties[WinButton.PropertyNames.ClassName] = "DirectUIHWND";
                viewDownloads.DrawHighlight();*/

               

                while(toolBar.Exists)
                {
                    
                    //Mouse.Click(cancelButton);
                    Playback.Wait(2000);
                    Support.CloseAllProcessStartingWith("AcroRd");
                    try
                    {
                        toolBar.Find();
                    }
                    catch(Exception e)
                    {
                        Reports.StatusUpdate("File download prompt disappeared !", true);
                        IsFileDownloadPromptClosed = true;
                        break;
                    }
                }
                wnd.SetFocus();
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("NOT AN APP DEFECT ! Exception occurred while handling file download prompt/could not find the prompt : " + ex.Message + "\r\n Method :HandleFileDownloadPrompt_WithPauseAndResume()", true);
                return false;
            }
            return IsFileDownloadPromptClosed;
        }

        public static bool HandleDownloadPrompt()
        {
            bool IsTIFFFileOpened = false;
            try
            {
                BrowserWindow wnd = new BrowserWindow();
                wnd.SearchProperties["ClassName"] = "IEFrame";
                //wnd.SearchProperties["FriendlyName"] = "Notification";
                //wnd.DrawHighlight();
                //   wnd.WindowTitles.Add("http://azuvniisfint441.fastts.firstam.net/ - FAST v10.0");

                WinButton openButton = new WinButton(wnd);
                openButton.SearchProperties[WinButton.PropertyNames.Name] = "Open";
                //openButton.SearchProperties[WinButton.PropertyNames.ControlType] = "Button";
                //openButton.DrawHighlight();

                WinButton cancelButton = new WinButton(wnd);
                cancelButton.SearchProperties[WinButton.PropertyNames.Name] = "Cancel";

                WinSplitButton splitButton = new WinSplitButton(wnd);
                splitButton.SearchProperties[WinButton.PropertyNames.Name] = "Save";
                //splitButton.DrawHighlight();

                /*WinToolBar toolBar = new WinToolBar(wnd);
                toolBar.SearchProperties["ClassName"] = "DirectUIHWND";
                toolBar.SearchProperties["TechnologyName"] = "MSAA";
                toolBar.SearchProperties["ControlType"] = "ToolBar";
                toolBar.SearchProperties["Name"] = "Notification";*/
                //toolBar.DrawHighlight();

                WinControl dropDownButton = new WinControl(splitButton);
                dropDownButton.SearchProperties[UITestControl.PropertyNames.ControlType] = "DropDownButton";
                //dropDownButton.SearchProperties[UITestControl.PropertyNames.ClassName] = "DirectUIHWND";
                //dropDownButton.SearchProperties[UITestControl.TechnologyName] = "MSAA";
                //dropDownButton.SearchProperties["ControlType"] = "DropDownButton";
                //dropDownButton.DrawHighlight();

                /*  WinWindow SaveAsDlg = new WinWindow();
                  SaveAsDlg.SearchProperties["ClassName"] = "#32770";
                  SaveAsDlg.SearchProperties["Name"] = "SaveAs";

                  WinEdit FileNameEdit = new WinEdit(SaveAsDlg);
                  FileNameEdit.SearchProperties["Name"] = "File name:";
                  FileNameEdit.SearchProperties["ControlType"] = "Edit";

                  WinButton SaveButton = new WinButton(SaveAsDlg);
                  SaveButton.SearchProperties["Name"] = "Save";
                  SaveButton.SearchProperties["ControlType"] = "Button";*/
                //Playback.Wait(3000);

                if (openButton.Exists && splitButton.Exists && cancelButton.Exists)
                {
                    IsTIFFFileOpened = true;
                    Mouse.Click(cancelButton);
                }
                wnd.SetFocus();

                WinWindow PDFViewer = new WinWindow();
                PDFViewer.SearchProperties.Add("ClassName", "WindowsForms10.Window", PropertyExpressionOperator.Contains); // "WindowsForms10.Window.8.app.0.33c0d9d";
                PDFViewer.SearchProperties.Add("Name", "Simply Scanning+", PropertyExpressionOperator.Contains); // "WindowsForms10.Window.8.app.0.33c0d9d";
                if (PDFViewer.Exists)
                {
                    WinTitleBar titleBar = new WinTitleBar(PDFViewer);
                    titleBar.SearchProperties.Add("ClassName", "WindowsForms10.Window", PropertyExpressionOperator.Contains);
                    //titleBar.SearchProperties.Add("ClassName", "WindowsForms10.Window", PropertyExpressionOperator.Contains); 
                    WinButton closeBtn = new WinButton(titleBar);
                    closeBtn.SearchProperties["Name"] = "Close";
                    Mouse.Click(closeBtn);
                }

                try
                {
                    // BrowserWindow sBr = new BrowserWindow();
                    //sBr.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
                    //sBr.SearchProperties["ClassName"] = "IEFrame";
                    //sBr.SearchProperties.Add("Name", "Fastimages", PropertyExpressionOperator.Contains);
                    //sBr.SetFocus();
                    HtmlControl dlgCloseButton = new HtmlControl(wnd);
                    dlgCloseButton.SearchProperties["InnerText"] = "http -- Webpage Dialog";
                    dlgCloseButton.SearchProperties["TagName"] = "SPAN";
                    dlgCloseButton.SearchProperties["ClassName"] = "HtmlPane";
                    /* if (dlgCloseButton.Exists)
                     {
                         dlgCloseButton.Find();
                         //Reports.StatusUpdate("The TIFF dialog must have opened.", true);
                     }*/
                }
                catch (Exception ex)
                {
                    Reports.StatusUpdate("Exception while trying to identify the TIFF empty dialog close button. Exception : " + ex.Message, true);
                }
                //Keyboard.SendKeys("%{SPACE}C");

                //Keyboard.SendKeys("{A}");

                //var fileName = FileNameEdit.GetProperty("Text");
                //Mouse.Click(SaveButton);
                return IsTIFFFileOpened;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while handling file download prompt/could not find the prompt : " + ex.Message, true);
                return false;
            }

        }
    }
}
