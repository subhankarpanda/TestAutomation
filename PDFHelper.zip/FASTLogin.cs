﻿using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects;
using OpenQA.Selenium.IE;
using System;
using System.IO;
using System.Configuration;
using OpenQA.Selenium;
using System.Windows.Forms;

namespace FASTSelenium.Common
{
    public class FASTLogin
    {
        public static bool useEnsureCleanSession = true;
        public static bool useIntroduceInstabilityByIgnoringProtectedModeSettings = true;
        public static bool useIgnoreZoomLevel = true;
        public static InternetExplorerUnexpectedAlertBehavior useUnexpectedAlertBehavior = InternetExplorerUnexpectedAlertBehavior.Ignore;

        public static void Login(string URL, Credentials credentials, bool cleanSession = true)
        {
            try
            {
                Reports.StatusUpdate("First Login Attempt.", true);
                Support.CloseAllProcessStartingWith("iexplore"); //TODO: remove this form here. This is not the concern of the login method
                StartDriver(cleanSession);
                PerformInternalLogin(URL, credentials);
            }
            catch (Exception ex) //Handle 'The HTTP request to the remote WebDriver server for URL {URL} timed out after 60 seconds' error
            {
                Reports.StatusUpdate("Second Login Attempt." + Environment.NewLine + "First attempt threw exception '" + ex.Message + "'", true);
                Support.CloseAllProcessStartingWith("iexplore");
                FastDriver.WebDriver.Quit();
                StartDriver(cleanSession);
                PerformInternalLogin(URL, credentials);
            }
        }

        public static void Start(bool cleanSession = true, bool closeIeprocess = true)
        {
            if (closeIeprocess)
            {
                Support.CloseAllProcessStartingWith("iexplore");
            }
            StartDriver(cleanSession);
        }

        public static IWebDriver OpenIE()
        {
            return FastDriver.LaunchBrowser<InternetExplorerDriver>();
        }

        #region Private members

        private static void StartDriver(bool cleanSession)
        {
            if (cleanSession)
            {
                Support.CloseAllProcessStartingWith("TransportManager");
                FASTLogin.DeleteDownloadefiles();

                FastDriver.InternetExplorerOptions = new InternetExplorerOptions()
                {
                    EnsureCleanSession = useEnsureCleanSession,
                    UnexpectedAlertBehavior = useUnexpectedAlertBehavior,
                    IntroduceInstabilityByIgnoringProtectedModeSettings = useIntroduceInstabilityByIgnoringProtectedModeSettings,
                    IgnoreZoomLevel = useIgnoreZoomLevel,
                };
            }
            else
            {
                FastDriver.InternetExplorerOptions = new InternetExplorerOptions()
                {
                    UnexpectedAlertBehavior = useUnexpectedAlertBehavior,
                    IntroduceInstabilityByIgnoringProtectedModeSettings = useIntroduceInstabilityByIgnoringProtectedModeSettings,
                    IgnoreZoomLevel = useIgnoreZoomLevel,
                };
            }

            FastDriver.LaunchBrowser<InternetExplorerDriver>();
            FastDriver.WebDriver.Manage().Window.Maximize();
        }

        #endregion

        #region Protected members

        protected static void PerformInternalLogin(string URL, Credentials credentials)
        {
            FastDriver.LoginScreen.Login(URL, credentials);
            FastDriver.HomePage.WaitForHomeScreen(reportBuildNumber: true);
        }

        #endregion

        #region Delete FAST related files

        public static void DeleteDownloadefiles()
        {
            try
            {
                string sDirectory = Reports.DEPLOYDIR;
                string commandArg = "";

                Support.GetEmbeddedFile("FASTSelenium", "Common.Support.RemoveDLLs64bit.bat", sDirectory + "\\RemoveDLLs64bit.bat");
                Support.GetEmbeddedFile("FASTSelenium", "Common.Support.RemoveDLLs32bit.bat", sDirectory + "\\RemoveDLLs32bit.bat");

                commandArg = sDirectory + string.Format("\\RemoveDLLs{0}bit.bat", Environment.Is64BitOperatingSystem ? "64" : "32");

                Support.ExecuteCommand(commandArg);
            }
            catch (Exception e)
            {
                string msg = e.Message;
            }
        }

        #endregion
    }
}
