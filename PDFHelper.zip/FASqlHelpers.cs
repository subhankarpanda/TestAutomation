﻿using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.Common
{
    public static class FASqlHelpers
    {
        public static void GenerateDataForIncomingWire()
        {
            string myConnString = AutoConfig.FASTPRODConnectionString;
            string myQueryString = @"Begin Tran
                                    update BankAccount 
                                    set BusinessUnitID = 191, AccountNum='47D3025416B031DC6BD9F5E7C6AEF13A', ActiveStatusCd=1, DepositAcctFlag=1, BistroWireAcctFlag=1 where BankAcctID=8993
                                    update BankBranch
                                    set RoutingNum='122241255', BusinessUnitID=191 where BankID=714

                                    INSERT INTO [IncomingWireDetail]
                                               ([IncomingWireID]
                                               ,[Amount]
                                               ,[AccountNum]
                                               ,[TypeID]
                                               ,[TypeCode]
                                               ,[ConfirmRef]
                                               ,[IMAD]
                                               ,[OMAD]
                                               ,[SNDBKABA]
                                               ,[SNDBKNAME]
                                               ,[RCVBKABA]
                                               ,[OriginatorID]
                                               ,[OriginatorName]
                                               ,[OGB]
                                               ,[BNF]
                                               ,[OBI]
                                               ,[RCVBKINFO]
                                               ,[BBKINFO]
                                               ,[IBKINFO]
                                               ,[BNFINFO]
                                               ,[BBI]
                                               ,[RFB]
                                               ,[IssueDate]
                                               ,[Status]
                                               ,[StatusChgUserID]
                                               ,[StatusChgDate]
                                               ,[WireActionTaken]
                                               ,[ACHDescription]
                                               ,[ACHSECCode]
                                               ,[ACHTraceNum]
                                               ,[ACHODFI]
                                               ,[ACHIndividualCompanyName]
                                               ,[ACHAddenda]
                                               ,[ACHRecordTypeCode]
                                               ,[ACHAddendaTypeCode]
                                               ,[ACHPaymentInfo]
                                               ,[ACHAddendaSeqNum]
                                               ,[ACHEntryDetailSeqNum])
                                       select top 40
                                               IncomingWireID
                                               ,[Amount]
                                               ,'47D3025416B031DC6BD9F5E7C6AEF13A' [AccountNum]
                                               ,[TypeID]
                                               ,[TypeCode]
                                              ,[ConfirmRef]
                                               ,[IMAD]
                                               ,[OMAD]
                                               ,[SNDBKABA]
                                               ,[SNDBKNAME]
                                               ,[RCVBKABA]
                                               ,[OriginatorID]
                                               ,[OriginatorName]
                                               ,[OGB]
                                               ,[BNF]
                                               ,[OBI]
                                               ,[RCVBKINFO]
                                               ,[BBKINFO]
                                               ,[IBKINFO]
                                               ,[BNFINFO]
                                               ,[BBI]
                                               ,[RFB]
                                               ,[IssueDate]
                                               ,1898 [Status]
                                               ,[StatusChgUserID]
                                               ,[StatusChgDate]
                                               ,[WireActionTaken]
                                               ,[ACHDescription]
                                               ,[ACHSECCode]
                                               ,[ACHTraceNum]
                                               ,[ACHODFI]
                                               ,[ACHIndividualCompanyName]
                                               ,[ACHAddenda]
                                               ,[ACHRecordTypeCode]
                                               ,[ACHAddendaTypeCode]
                                               ,[ACHPaymentInfo]
                                               ,[ACHAddendaSeqNum]
                                               ,[ACHEntryDetailSeqNum]
                                          FROM [IncomingWireDetail] where TypeID=1911 order by 1 desc	--IW

                                          INSERT INTO [IncomingWireDetail]
                                               ([IncomingWireID]
                                               ,[Amount]
                                               ,[AccountNum]
                                               ,[TypeID]
                                               ,[TypeCode]
                                               ,[ConfirmRef]
                                               ,[IMAD]
                                               ,[OMAD]
                                               ,[SNDBKABA]
                                               ,[SNDBKNAME]
                                               ,[RCVBKABA]
                                               ,[OriginatorID]
                                               ,[OriginatorName]
                                               ,[OGB]
                                               ,[BNF]
                                               ,[OBI]
                                               ,[RCVBKINFO]
                                               ,[BBKINFO]
                                               ,[IBKINFO]
                                               ,[BNFINFO]
                                               ,[BBI]
                                               ,[RFB]
                                               ,[IssueDate]
                                               ,[Status]
                                               ,[StatusChgUserID]
                                               ,[StatusChgDate]
                                               ,[WireActionTaken]
                                               ,[ACHDescription]
                                               ,[ACHSECCode]
                                               ,[ACHTraceNum]
                                               ,[ACHODFI]
                                               ,[ACHIndividualCompanyName]
                                               ,[ACHAddenda]
                                               ,[ACHRecordTypeCode]
                                               ,[ACHAddendaTypeCode]
                                               ,[ACHPaymentInfo]
                                               ,[ACHAddendaSeqNum]
                                               ,[ACHEntryDetailSeqNum])
                                       select top 40
                                               IncomingWireID
                                               ,[Amount]
                                               ,'47D3025416B031DC6BD9F5E7C6AEF13A' [AccountNum]
                                               ,[TypeID]
                                               ,[TypeCode]
                                              ,[ConfirmRef]
                                               ,[IMAD]
                                               ,[OMAD]
                                               ,[SNDBKABA]
                                               ,[SNDBKNAME]
                                               ,[RCVBKABA]
                                               ,[OriginatorID]
                                               ,[OriginatorName]
                                               ,[OGB]
                                               ,[BNF]
                                               ,[OBI]
                                               ,[RCVBKINFO]
                                               ,[BBKINFO]
                                               ,[IBKINFO]
                                               ,[BNFINFO]
                                               ,[BBI]
                                               ,[RFB]
                                               ,[IssueDate]
                                               ,1898 [Status]
                                               ,[StatusChgUserID]
                                               ,[StatusChgDate]
                                               ,[WireActionTaken]
                                               ,[ACHDescription]
                                               ,[ACHSECCode]
                                               ,[ACHTraceNum]
                                               ,[ACHODFI]
                                               ,[ACHIndividualCompanyName]
                                               ,[ACHAddenda]
                                               ,[ACHRecordTypeCode]
                                               ,[ACHAddendaTypeCode]
                                               ,[ACHPaymentInfo]
                                               ,[ACHAddendaSeqNum]
                                               ,[ACHEntryDetailSeqNum]
                                          FROM [IncomingWireDetail] where TypeID=1912 order by 1 desc	--ACH

                                    commit";

            ExecuteSqlCommand(myConnString, myQueryString);

        }

        public static void DisableSymantecWireApprovalFlag(int BUID = 1487)
        {
            string myConnString = AutoConfig.FASTPRODConnectionString;
            string myQueryString = @"update BusinessUnit set SymantecWireApprovalFlag = NULL where BusinessUnitID in (" + BUID.ToString() + ")";

            ExecuteSqlCommand(myConnString, myQueryString);
        }

        public static void DeleteAgentNetAccount(string employeeId, string appUserID)
        {
            string myConnString = AutoConfig.FASTPRODConnectionString;
            string myQueryString = "Delete FROM EmployeeApplicationUserXref WHERE FASTEmployeeID=" + employeeId + " AND ApplicationUserID='" + appUserID + "'";

            ExecuteSqlCommand(myConnString, myQueryString);
        }
        public static void ArchiveFile(int fileId, string date = null) // '2016-01-01',  this is Q1 of 2016
        {
            if (date == null)
                date = DateTime.Now.AddDays(-60).ToString("yyyy-MM-dd");

            string myConnString = AutoConfig.FASTPRODConnectionString; 
            myConnString = myConnString.Replace("User ID=mtsuser", "User ID=archiver");
            myConnString = myConnString.Replace("Password=*evaltrain", "Password=fastarchive");
            string myQueryString = @"exec cparchivemain " + fileId + ", '" + date + "'";

            ExecuteSqlCommand(myConnString, myQueryString);
        }
        private static void ExecuteSqlCommand(string connectionString, string queryString)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(queryString, connection);
            command.Connection.Open();
            command.ExecuteNonQuery();
        }

        public static int FindFastWebOrder(int regionID = 1487)
        {
            int fileID = 0;

            SqlConnection connection = new SqlConnection(AutoConfig.FASTPRODConnectionString);
            string myQueryString = @"Select Top 1 sf.FileID
                                        From CustomerOrder co (NoLock)
                                        Join ServiceFile sf (NoLock) On co.OrderID = sf.OrderID
                                        Where co.SourceApplID = 3  --FAST Web
                                        And sf.OwnerOfficeID = " + regionID.ToString() + " Order By sf.FileID Desc";
                                        
            SqlCommand command = new SqlCommand(myQueryString, connection);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            try
            {
                reader.Read();
                fileID = Convert.ToInt32(reader[0].ToString());
                return fileID;
            }
            finally
            {
                reader.Close();
                
            }
        }

        public static int FindDepositListID(string fileID)
        {
            int depositListID = 0;

            SqlConnection connection = new SqlConnection(AutoConfig.FASTPRODConnectionString);
            string myQueryString = @"select DepositListID from InEscrowDeposit where FileID = " + fileID;

            SqlCommand command = new SqlCommand(myQueryString, connection);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    if (reader[0].ToString() != "")
                    {
                        depositListID = Convert.ToInt32(reader[0].ToString());
                        break;
                    }
                }
                
                return depositListID;
            }
            finally
            {
                reader.Close();
            }
        }

        public static int FindInEscrowID(string fileID)
        {
            int inEscrowID = 0;

            SqlConnection connection = new SqlConnection(AutoConfig.FASTPRODConnectionString);
            string myQueryString = @"select InEscrowID from InEscrowDeposit where FileID = " + fileID;

            SqlCommand command = new SqlCommand(myQueryString, connection);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            try
            {
                while (reader.Read())
                {
                    if (reader[0].ToString() != "")
                    {
                        inEscrowID = Convert.ToInt32(reader[0].ToString());
                        break;
                    }
                }

                return inEscrowID;
            }
            finally
            {
                reader.Close();
            }
        }

        public static DataSet ExecuteSQLQuery(string myQueryString)
        {
            if (!myQueryString.ToUpper().Contains("SELECT"))
                throw new Exception("Query string is not a select statement!");

            DataSet ds = new DataSet();
            SqlConnection myConnection = new SqlConnection(AutoConfig.FASTPRODConnectionString);
            SqlDataAdapter da = new SqlDataAdapter(myQueryString, myConnection);
            da.Fill(ds);
            myConnection.Close();
            myConnection.Dispose();
            da.Dispose();
            return ds;
        }
    }
}
