﻿using SeleniumInternalHelpers;
using System;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.PageObjects.ADM;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.Common
{
    public class FastDriver : SUTDriver
    {
        public static string BaseUrlConfigKey = "BaseUrl";

        //This is not working. We are never instantiating the FastDriver class. Moved it to MasterTestClass.TestInitialize().
        //public FastDriver()
        //{
        //    PageObjectFactory.DefaultWaitTime = AutoConfig.WaitTime;
        //}

        #region File Site Page Objects

        public static DepositAdjustmentConfirmation DepositAdjustmentConfirmation
        {
            get { return FastDriver.GetPage<DepositAdjustmentConfirmation>(); }
        }
        public static FACCWorkbenchDlg FACCWorkbenchDlg
        {
            get { return FastDriver.GetPage<FACCWorkbenchDlg>(); }
        }
        //public static ImagingWorkBenchNonActiveX ImagingWorkBenchNonActiveX
        //{
        //    get { return FastDriver.GetPage<ImagingWorkBenchNonActiveX>(); }
        //}
        public static PaymentDetailsDlgProjectWorkbench PaymentDetailsDlgProjectWorkbench
        {
            get { return FastDriver.GetPage<PaymentDetailsDlgProjectWorkbench>(); }
        }
        //public static FACCRecalculationConfirmDlg FACCRecalculationConfirmDlg
        //{
        //    get { return FastDriver.GetPage<FACCRecalculationConfirmDlg>(); }
        //}
        public static SaveDocumentNonActiveX SaveDocumentNonActiveX
        {
            get { return FastDriver.GetPage<SaveDocumentNonActiveX>(); }
        }

        public static LenderCommentsPopup LenderCommentsPopup
        {
            get { return FastDriver.GetPage<LenderCommentsPopup>(); }
        }
        
        public static TrackDlg TrackDlg
        {
            get { return FastDriver.GetPage<TrackDlg>(); }
        }

        public static FileSiteLeftNavigationPane FileSiteLeftNavigationPane
        {
            get { return FastDriver.GetPage<FileSiteLeftNavigationPane>(); }
        }

        public static ImagingWorkBenchNonActiveX ImagingWorkBenchNonActiveX
        {
            get { return FastDriver.GetPage<ImagingWorkBenchNonActiveX>(); }
        }

        public static RTMLogDetailsWindow RTMLogDetailsWindow
        {
            get { return FastDriver.GetPage<RTMLogDetailsWindow>(); }
        }

        public static MessageDlg MessageDlg
        {
            get { return FastDriver.GetPage<MessageDlg>(); }
        }
        
        public static CDBorrowerInfo CDBorrowerInfo
        {
            get { return FastDriver.GetPage<CDBorrowerInfo>(); }
        }

        public static AddSimultaneousProduct AddSimultaneousProduct
        {
            get { return FastDriver.GetPage<AddSimultaneousProduct>(); }
        }
        public static CDLenderDlg CDLenderDlg
        {
            get { return FastDriver.GetPage<CDLenderDlg>(); }
        }
        
        public static CDSellerInfo CDSellerInfo
        {
            get { return FastDriver.GetPage<CDSellerInfo>(); }
        }

        public static CDSettlementAgentInfo CDSettlementAgentInfo
        {
            get { return FastDriver.GetPage<CDSettlementAgentInfo>(); }
        }

        public static CDPropertyInfo CDPropertyInfo
        {
            get { return FastDriver.GetPage<CDPropertyInfo>(); }
        }

        public static TransactionCoordinatorSummary TransactionCoordinatorSummary
        {
            get { return FastDriver.GetPage<TransactionCoordinatorSummary>(); }
        }

        public static TableCharges TableCharges
        {
            get { return FastDriver.GetPage<TableCharges>(); }
        }

        public static IEMessageDlg IEMessageDlg
        {
            get { return FastDriver.GetPage<IEMessageDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary ActiveDisbursementSummary
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(); }
        }

        public static YearRangeDialog YearRangeDialog
        {
            get { return FastDriver.GetPage<YearRangeDialog>(); }
        }

        public static ProrationMisc ProrationMisc
        {
            get { return FastDriver.GetPage<ProrationMisc>(); }
        }

        public static MinMaxDialog MinMaxDialog
        {
            get { return FastDriver.GetPage<MinMaxDialog>(); }
        }

        public static CD CD
        {
            get { return FastDriver.GetPage<CD>(); }
        }

        public static AddIBATransactionDlg AddIBATransactionDlg
        {
            get { return FastDriver.GetPage<AddIBATransactionDlg>(); }
        }

        public static AddNewMiscellaneousTaskDlg AddNewMiscellaneousTaskDlg
        {
            get { return FastDriver.GetPage<AddNewMiscellaneousTaskDlg>(); }
        }

        public static AddOTCFees AddOTCFees
        {
            get { return FastDriver.GetPage<AddOTCFees>(); }
        }

        public static AddProcessToFileWorkflowDlg AddProcessToFileWorkflowDlg
        {
            get { return FastDriver.GetPage<AddProcessToFileWorkflowDlg>(); }
        }

        public static AddressBookSearchDlg AddressBookSearchDlg
        {
            get { return FastDriver.GetPage<AddressBookSearchDlg>(); }
        }

        public static AddRTMPackageAddressesDlg AddRTMPackageAddressesDlg
        {
            get { return FastDriver.GetPage<AddRTMPackageAddressesDlg>(); }
        }

        public static AddTasksfromProcessTemplateScreenDlg AddTasksfromProcessTemplateScreenDlg
        {
            get { return FastDriver.GetPage<AddTasksfromProcessTemplateScreenDlg>(); }
        }

        public static AdHocDocuments AdHocDocuments
        {
            get { return FastDriver.GetPage<AdHocDocuments>(); }
        }

        public static AdjustmentMisc AdjustmentMisc
        {
            get { return FastDriver.GetPage<AdjustmentMisc>(); }
        }

        public static AdjustmentOffset AdjustmentOffset
        {
            get { return FastDriver.GetPage<AdjustmentOffset>(); }
        }

        public static AgentNetCredentialsDlg AgentNetCredentialsDlg
        {
            get { return FastDriver.GetPage<AgentNetCredentialsDlg>(); }
        }

        public static AssignChargestoHUD1LineNumbers AssignChargestoHUD1LineNumbers
        {
            get { return FastDriver.GetPage<AssignChargestoHUD1LineNumbers>(); }
        }

        public static FACCRecalculationConfirmDlg FACCRecalculationConfirmDlg
        {
            get { return FastDriver.GetPage<FACCRecalculationConfirmDlg>(); }
        }

        public static LinkTitlePolicyDlg LinkTitlePolicyDlg
        {
            get { return FastDriver.GetPage<LinkTitlePolicyDlg>(); }
        }


        public static AssignFeetoPropertyStates AssignFeetoPropertyStates
        {
            get { return FastDriver.GetPage<AssignFeetoPropertyStates>(); }
        }

        public static AssocDocSeqDlg AssocDocSeqDlg
        {
            get { return FastDriver.GetPage<AssocDocSeqDlg>(); }
        }

        public static AssociateDocs AssociateDocs
        {
            get { return FastDriver.GetPage<AssociateDocs>(); }
        }

        public static AssociateFeesReporting AssociateFeesReporting
        {
            get { return FastDriver.GetPage<AssociateFeesReporting>(); }
        }

        public static AssumptionLoanCharges AssumptionLoanCharges
        {
            get { return FastDriver.GetPage<AssumptionLoanCharges>(); }
        }

        public static AssumptionLoanDetails AssumptionLoanDetails
        {
            get { return FastDriver.GetPage<AssumptionLoanDetails>(); }
        }

        public static AssumptionLoanParties AssumptionLoanParties
        {
            get { return FastDriver.GetPage<AssumptionLoanParties>(); }
        }

        public static AssumptionLoanRecording AssumptionLoanRecording
        {
            get { return FastDriver.GetPage<AssumptionLoanRecording>(); }
        }

        public static AssumptionLoanSummary AssumptionLoanSummary
        {
            get { return FastDriver.GetPage<AssumptionLoanSummary>(); }
        }

        public static AttachMessage AttachMessage
        {
            get { return FastDriver.GetPage<AttachMessage>(); }
        }

        public static AttorneyDetail AttorneyDetail
        {
            get { return FastDriver.GetPage<AttorneyDetail>(); }
        }

        public static AttorneySummary AttorneySummary
        {
            get { return FastDriver.GetPage<AttorneySummary>(); }
        }

        public static BusinessProgramsHistoryDlg BusinessProgramsHistoryDlg
        {
            get { return FastDriver.GetPage<BusinessProgramsHistoryDlg>(); }
        }

        public static BusOrgAdhocDlg BusOrgAdhocDlg
        {
            get { return FastDriver.GetPage<BusOrgAdhocDlg>(); }
        }

        public static BuyerSellerAdditionalInformation BuyerSellerAdditionalInformation
        {
            get { return GetPage<BuyerSellerAdditionalInformation>(); }
        }

        public static BuyerSellerEntitySignatures BuyerSellerEntitySignatures
        {
            get { return FastDriver.GetPage<BuyerSellerEntitySignatures>(); }
        }

        public static BuyerSellerSetup BuyerSellerSetup
        {
            get { return GetPage<BuyerSellerSetup>(); }
        }

        public static BuyerSellerSummary BuyerSellerSummary
        {
            get { return GetPage<BuyerSellerSummary>(); }
        }

        public static BuyerVesting BuyerVesting
        {
            get { return GetPage<BuyerVesting>(); }
        }

        public static CalculateFees CalculateFees
        {
            get { return FastDriver.GetPage<CalculateFees>(); }
        }

        public static CancelDlg CancelDlg
        {
            get { return FastDriver.GetPage<CancelDlg>(); }
        }

        public static ChangeFileStatusDlg ChangeFileStatusDlg
        {
            get { return FastDriver.GetPage<ChangeFileStatusDlg>(); }
        }

        public static ChangeOwningOfficeRemoveServiceType ChangeOwningOfficeRemoveServiceType
        {
            get { return FastDriver.GetPage<ChangeOwningOfficeRemoveServiceType>(); }
        }

        public static CheckDetailsDlg CheckDetailsDlg
        {
            get { return FastDriver.GetPage<CheckDetailsDlg>(); }
        }

        

        public static ClosingDisclosure ClosingDisclosure
        {
            get { return GetPage<ClosingDisclosure>(); }
        }

        public static TexasDisclosure TexasDisclosure
        {
            get { return GetPage<TexasDisclosure>(); }
        }

        public static TexasDisclosurePDF TexasDisclosurePDF
        {
            get { return GetPage<TexasDisclosurePDF>(); }
        }

        public static CDN03Popup CDN03Popup
        {
            get { return GetPage<CDN03Popup>(); }
        }

        public static CDN04Popup CDN04Popup
        {
            get { return GetPage<CDN04Popup>(); }
        }

        public static CDN05Popup CDN05Popup
        {
            get { return GetPage<CDN05Popup>(); }
        }
        public static CDN06Popup CDN06Popup
        {
            get { return GetPage<CDN06Popup>(); }
        }

        public static CDL03Popup CDL03Popup
        {
            get { return GetPage<CDL03Popup>(); }
        }

        public static CDL06Popup CDL06Popup
        {
            get { return GetPage<CDL06Popup>(); }
        }

        public static CDL04Popup CDL04Popup
        {
            get { return GetPage<CDL04Popup>(); }
        }
        public static ClosingDisclosureGFV ClosingDisclosureGFV
        {
            get { return GetPage<ClosingDisclosureGFV>(); }
        }

        public static ClosingProtectionLetter ClosingProtectionLetter
        {
            get { return FastDriver.GetPage<ClosingProtectionLetter>(); }
        }

        public static ConfirmationDlg ConfirmationDlg
        {
            get { return FastDriver.GetPage<ConfirmationDlg>(); }
        }

        public static CopyDocuments CopyDocuments
        {
            get { return FastDriver.GetPage<CopyDocuments>(); }
        }

        public static CopyFrom CopyFrom
        {
            get { return FastDriver.GetPage<CopyFrom>(); }
        }

        public static DateDownRequest DateDownRequest
        {
            get { return FastDriver.GetPage<DateDownRequest>(); }
        }

        public static Deliveryservername Deliveryservername
        {
            get { return FastDriver.GetPage<Deliveryservername>(); }
        }

        public static DeliveryTestSettings DeliveryTestSettings
        {
            get { return FastDriver.GetPage<DeliveryTestSettings>(); }
        }

        public static DepositAdjustment DepositAdjustment
        {
            get { return FastDriver.GetPage<DepositAdjustment>(); }
        }

        public static DepositinEscrow DepositInEscrow
        {
            get { return FastDriver.GetPage<DepositinEscrow>(); }
        }

        public static ExchangeDeposit ExchangeDeposit
        {
            get { return FastDriver.GetPage<ExchangeDeposit>(); }
        }

        public static ViewStatementOfTheAccount ViewStatementOfTheAccount
        {
            get { return FastDriver.GetPage<ViewStatementOfTheAccount>(); }
        }

        public static DepositList DepositList
        {
            get { return FastDriver.GetPage<DepositList>(); }
        }

        public static DepositOutsideEscrow DepositOutsideEscrow
        {
            get { return FastDriver.GetPage<DepositOutsideEscrow>(); }
        }

        public static DepositSummary DepositSummary
        {
            get { return FastDriver.GetPage<DepositSummary>(); }
        }

        public static FASTSelenium.PageObjects.IIS.DisbursementAdjustment DisbursementAdjustment
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.DisbursementAdjustment>(); }
        }

        public static DisbursementHistory DisbursementHistory
        {
            get { return FastDriver.GetPage<DisbursementHistory>(); }
        }

        public static DisburseWires DisburseWires
        {
            get { return FastDriver.GetPage<DisburseWires>(); }
        }

        public static DuplicateFileSearch DuplicateFileSearch
        {
            get { return FastDriver.GetPage<DuplicateFileSearch>(); }
        }

        public static Dlg Dlg
        {
            get { return FastDriver.GetPage<Dlg>(); }
        }

        public static DocPackageDlg DocPackageDlg
        {
            get { return FastDriver.GetPage<DocPackageDlg>(); }
        }

        public static DocPrepTextEditorDlg DocPrepTextEditorDlg
        {
            get { return FastDriver.GetPage<DocPrepTextEditorDlg>(); }
        }

        public static DocumentDeliveryScriptlet DocumentDeliveryScriptlet
        {
            get { return FastDriver.GetPage<DocumentDeliveryScriptlet>(); }
        }

        public static DocumentDetailsScreen DocumentDetailsScreen
        {
            get { return FastDriver.GetPage<DocumentDetailsScreen>(); }
        }

        public static DocumentEdit DocumentEdit
        {
            get { return FastDriver.GetPage<DocumentEdit>(); }
        }

        public static DocumentInfo DocumentInfo
        {
            get { return FastDriver.GetPage<DocumentInfo>(); }
        }

        public static DocumentNameDlg DocumentNameDlg
        {
            get { return FastDriver.GetPage<DocumentNameDlg>(); }
        }

        public static DocumentPhrasesDlg DocumentPhrasesDlg
        {
            get { return FastDriver.GetPage<DocumentPhrasesDlg>(); }
        }

        public static DocumentPreparation DocumentPreparation
        {
            get { return FastDriver.GetPage<DocumentPreparation>(); }
        }

        public static DocumentPreparationMenu DocumentPreparationMenu
        {
            get { return FastDriver.GetPage<DocumentPreparationMenu>(); }
        }

        public static DocumentPreparationwin DocumentPreparationwin
        {
            get { return FastDriver.GetPage<DocumentPreparationwin>(); }
        }

        public static DocPrepTextEditorDlg DocumentPreparationTextEditorDlg
        {
            get { return GetPage<DocPrepTextEditorDlg>(); }
        }

        public static DocumentRepository DocumentRepository
        {
            get { return FastDriver.GetPage<DocumentRepository>(); }
        }
        public static FASTSelenium.PageObjects.IIS.NextGenDocumentRepository NextGenDocumentRepository
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.NextGenDocumentRepository>(); }
        }
        public static DocumentRetainDeleteDlg DocumentRetainDeleteDlg
        {
            get { return FastDriver.GetPage<DocumentRetainDeleteDlg>(); }
        }

        public static DetailsDlg DetailsDlg
        {
            get { return FastDriver.GetPage<DetailsDlg>(); }
        }

        public static SectionBreakDlg SectionBreakDlg
        {
            get { return FastDriver.GetPage<SectionBreakDlg>(); }
        }

        public static DeleteDlg DeleteDlg
        {
            get { return FastDriver.GetPage<DeleteDlg>(); }
        }

        public static UnFinalizeDlg UnFinalizeDlg
        {
            get { return FastDriver.GetPage<UnFinalizeDlg>(); }
        }

        public static DuplicateFileSearchResults DuplicateFileSearchResults
        {
            get { return FastDriver.GetPage<DuplicateFileSearchResults>(); }
        }

        public static FASTSelenium.PageObjects.IIS.EditDisbursement EditDisbursement
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.EditDisbursement>(); }
        }

        public static EditDocumentDlg EditDocumentDlg
        {
            get { return FastDriver.GetPage<EditDocumentDlg>(); }
        }

        public static EditNameDocumentDlg EditNameDocumentDlg
        {
            get { return FastDriver.GetPage<EditNameDocumentDlg>(); }
        }

        public static Editor Editor
        {
            get { return FastDriver.GetPage<Editor>(); }
        }

        public static EditorDeleteDlg EditorDeleteDlg
        {
            get { return FastDriver.GetPage<EditorDeleteDlg>(); }
        }

        public static EditorDlg EditorDlg
        {
            get { return FastDriver.GetPage<EditorDlg>(); }
        }

        public static EditPhraseMarkerDlg EditPhraseMarkerDlg
        {
            get { return FastDriver.GetPage<EditPhraseMarkerDlg>(); }
        }

        public static EmailDlg EmailDlg
        {
            get { return FastDriver.GetPage<EmailDlg>(); }
        }

        public static EmailHistory EmailHistory
        {
            get { return FastDriver.GetPage<EmailHistory>(); }
        }

        public static EmailSearchDlg EmailSearchDlg
        {
            get { return FastDriver.GetPage<EmailSearchDlg>(); }
        }

        public static EmployeeSelectionbyOfficeDlg EmployeeSelectionbyOfficeDlg
        {
            get { return FastDriver.GetPage<EmployeeSelectionbyOfficeDlg>(); }
        }

        public static Epolicy Epolicy
        {
            get { return FastDriver.GetPage<Epolicy>(); }
        }

        public static EscrowFileBalanceSummary EscrowFileBalanceSummary
        {
            get { return FastDriver.GetPage<EscrowFileBalanceSummary>(); }
        }

        public static FASTSelenium.PageObjects.IIS.EventTrackingLog EventTrackingLog
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.EventTrackingLog>(); }
        }

        public static EventTrackingLogDlg EventTrackingLogDlg
        {
            get { return FastDriver.GetPage<EventTrackingLogDlg>(); }
        }

        public static ExchangeCompany ExchangeCompany
        {
            get { return GetPage<ExchangeCompany>(); }
        }

        public static ExchangeFileEntry ExchangeFileEntry
        {
            get { return GetPage<ExchangeFileEntry>(); }
        }

        public static ExchangePropertiesLegalDescription  ExchangePropertiesLegalDecription{ 
            get { return GetPage<ExchangePropertiesLegalDescription>(); } 
        }

        public static ExcludedReceipts ExcludedReceipts
        {
            get { return FastDriver.GetPage<ExcludedReceipts>(); }
        }

        public static ExclusionCommentDlg ExclusionCommentDlg
        {
            get { return FastDriver.GetPage<ExclusionCommentDlg>(); }
        }

        public static FACCEndorsementsDlg FACCEndorsementsDlg
        {
            get { return FastDriver.GetPage<FACCEndorsementsDlg>(); }
        }

        public static FACCProductsDlg FACCProductsDlg
        {
            get { return FastDriver.GetPage<FACCProductsDlg>(); }
        }

        public static FASTClosingfastcs FASTClosingfastcs
        {
            get { return FastDriver.GetPage<FASTClosingfastcs>(); }
        }

        public static FASTView FASTView
        {
            get { return FastDriver.GetPage<FASTView>(); }
        }

        public static FastViewEditor FastViewEditor
        {
            get { return FastDriver.GetPage<FastViewEditor>(); }
        }

        public static FastViewFileNotes FastViewFileNotes
        {
            get { return FastDriver.GetPage<FastViewFileNotes>(); }
        }

        public static FastViewFileSearch FastViewFileSearch
        {
            get { return FastDriver.GetPage<FastViewFileSearch>(); }
        }

        public static FASTWeb FASTWeb
        {
            get { return FastDriver.GetPage<FASTWeb>(); }
        }

        public static FastWebLogin FastWebLogin
        {
            get { return FastDriver.GetPage<FastWebLogin>(); }
        }

        public static FaxDlg FaxDlg
        {
            get { return FastDriver.GetPage<FaxDlg>(); }
        }

        public static FeePaymentDetailsDlg FeePaymentDetailsDlg
        {
            get { return FastDriver.GetPage<FeePaymentDetailsDlg>(); }
        }

        public static FileFees FileFees
        {
            get { return FastDriver.GetPage<FileFees>(); }
        }

        public static MiscEscrowEditDlg MiscEscrowEditDlg
        {
            get { return FastDriver.GetPage<MiscEscrowEditDlg>(); }
        }

        public static FileFeesDlg FileFeesDlg
        {
            get { return FastDriver.GetPage<FileFeesDlg>(); }
        }

        public static FileHomepage FileHomepage
        {
            get { return FastDriver.GetPage<FileHomepage>(); }
        }

        public static FileNotes FileNotes
        {
            get { return FastDriver.GetPage<FileNotes>(); }
        }

        public static FileNotesEditor FileNotesEditor
        {
            get { return FastDriver.GetPage<FileNotesEditor>(); }
        }

        public static FileNumberSearchSelectionDlg FileNumberSearchSelectionDlg
        {
            get { return FastDriver.GetPage<FileNumberSearchSelectionDlg>(); }
        }

        public static FileSearch FileSearch
        {
            get { return FastDriver.GetPage<FileSearch>(); }
        }

        public static FileSearchDlg FileSearchDlg
        {
            get { return FastDriver.GetPage<FileSearchDlg>(); }
        }

        public static FileSideBusinessPartyOrganizationSetUpDlg FileSideBusinessPartyOrganizationSetUpDlg
        {
            get { return FastDriver.GetPage<FileSideBusinessPartyOrganizationSetUpDlg>(); }
        }

        public static FileSummary FileSummary
        {
            get { return FastDriver.GetPage<FileSummary>(); }
        }

        public static FileSummaryDlg FileSummaryDlg
        {
            get { return FastDriver.GetPage<FileSummaryDlg>(); }
        }

        public static FileWorkflow FileWorkflow
        {
            get { return FastDriver.GetPage<FileWorkflow>(); }
        }

        public static FilterSelectionCriteriaDlg FilterSelectionCriteriaDlg
        {
            get { return FastDriver.GetPage<FilterSelectionCriteriaDlg>(); }
        }

        public static FindDlg FindDlg
        {
            get { return FastDriver.GetPage<FindDlg>(); }
        }

        public static FireInsuranceDlg FireInsuranceDlg
        {
            get { return FastDriver.GetPage<FireInsuranceDlg>(); }
        }

        public static FullScreenImageViewerDlg FullScreenImageViewerDlg
        {
            get { return FastDriver.GetPage<FullScreenImageViewerDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.GABEntryRequestDlg GABEntryRequestDlg
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.GABEntryRequestDlg>(); }
        }

        public static GenericEmail GenericEmail
        {
            get { return FastDriver.GetPage<GenericEmail>(); }
        }

        public static GenericEmailDlg GenericEmailDlg
        {
            get { return FastDriver.GetPage<GenericEmailDlg>(); }
        }

        public static GFEEntry GFEEntry
        {
            get { return FastDriver.GetPage<GFEEntry>(); }
        }

        public static GFEEntryGFE GFEEntryGFE
        {
            get { return FastDriver.GetPage<GFEEntryGFE>(); }
        }

        public static GFEToleranceSummary GFEToleranceSummary
        {
            get { return FastDriver.GetPage<GFEToleranceSummary>(); }
        }

        public static GFEEntryLoanTerms GFEEntryLoanTerms
        {
            get { return FastDriver.GetPage<GFEEntryLoanTerms>(); }
        }

        public static HoldFunds HoldFunds
        {
            get { return FastDriver.GetPage<HoldFunds>(); }
        }

        public static HoldFundsSummary HoldFundsSummary
        {
            get { return FastDriver.GetPage<HoldFundsSummary>(); }
        }

        public static HomeownerAssociation HomeownerAssociation
        {
            get { return FastDriver.GetPage<HomeownerAssociation>(); }
        }

        public static HomeownerAssociationSummary HomeownerAssociationSummary
        {
            get { return FastDriver.GetPage<HomeownerAssociationSummary>(); }
        }

        public static HomeWarrantyDetail HomeWarrantyDetail
        {
            get { return FastDriver.GetPage<HomeWarrantyDetail>(); }
        }

        public static HomeWarrantySummary HomeWarrantySummary
        {
            get { return FastDriver.GetPage<HomeWarrantySummary>(); }
        }

        public static HUD1PrintOptions HUD1PrintOptions
        {
            get { return FastDriver.GetPage<HUD1PrintOptions>(); }
        }

        public static IBAProductTypeInformationDlg IBAProductTypeInformationDlg
        {
            get { return FastDriver.GetPage<IBAProductTypeInformationDlg>(); }
        }

        public static IBATransactionApproval IBATransactionApproval
        {
            get { return FastDriver.GetPage<IBATransactionApproval>(); }
        }

        public static IBATransactionStatusDlg IBATransactionStatusDlg
        {
            get { return FastDriver.GetPage<IBATransactionStatusDlg>(); }
        }

        public static IBATransactionSummary IBATransactionSummary
        {
            get { return FastDriver.GetPage<IBATransactionSummary>(); }
        }

        public static Icon Icon
        {
            get { return FastDriver.GetPage<Icon>(); }
        }

        public static ImageDetails ImageDetails
        {
            get { return FastDriver.GetPage<ImageDetails>(); }
        }

        public static ImageDetailsScreen ImageDetailsScreen
        {
            get { return FastDriver.GetPage<ImageDetailsScreen>(); }
        }

        public static ImageDocDlg ImageDocDlg
        {
            get { return FastDriver.GetPage<ImageDocDlg>(); }
        }

        public static ImagingWorkBench ImagingWorkBench
        {
            get { return FastDriver.GetPage<ImagingWorkBench>(); }
        }

        public static IndexInformation IndexInformation
        {
            get { return FastDriver.GetPage<IndexInformation>(); }
        }

        public static InspectionRepairDetail InspectionRepairDetail
        {
            get { return FastDriver.GetPage<InspectionRepairDetail>(); }
        }

        public static InspectionRepairDetailDlg InspectionRepairDetailDlg
        {
            get { return FastDriver.GetPage<InspectionRepairDetailDlg>(); }
        }

        public static InspectionRepairOther InspectionRepairOther
        {
            get { return FastDriver.GetPage<InspectionRepairOther>(); }
        }

        public static InspectionRepairPest InspectionRepairPest
        {
            get { return FastDriver.GetPage<InspectionRepairPest>(); }
        }

        public static InspectionRepairSeptic InspectionRepairSeptic
        {
            get { return FastDriver.GetPage<InspectionRepairSeptic>(); }
        }

        public static InspectionRepairSummary InspectionRepairSummary
        {
            get { return FastDriver.GetPage<InspectionRepairSummary>(); }
        }

        public static InsuranceEarth InsuranceEarth
        {
            get { return FastDriver.GetPage<InsuranceEarth>(); }
        }

        public static InsuranceEarthDlg InsuranceEarthDlg
        {
            get { return FastDriver.GetPage<InsuranceEarthDlg>(); }
        }

        public static InsuranceFire InsuranceFire
        {
            get { return FastDriver.GetPage<InsuranceFire>(); }
        }

        public static Insuranceflood Insuranceflood
        {
            get { return FastDriver.GetPage<Insuranceflood>(); }
        }

        public static InsurancefloodDlg InsurancefloodDlg
        {
            get { return FastDriver.GetPage<InsurancefloodDlg>(); }
        }

        public static InsuranceOther InsuranceOther
        {
            get { return FastDriver.GetPage<InsuranceOther>(); }
        }

        public static InsuranceOtherDlg InsuranceOtherDlg
        {
            get { return FastDriver.GetPage<InsuranceOtherDlg>(); }
        }

        public static InsuranceSummary InsuranceSummary
        {
            get { return FastDriver.GetPage<InsuranceSummary>(); }
        }

        public static InsuranceSummaryDlg InsuranceSummaryDlg
        {
            get { return FastDriver.GetPage<InsuranceSummaryDlg>(); }
        }

        public static InsuranceWind InsuranceWind
        {
            get { return FastDriver.GetPage<InsuranceWind>(); }
        }

        public static InsuranceWindDlg InsuranceWindDlg
        {
            get { return FastDriver.GetPage<InsuranceWindDlg>(); }
        }

        public static InterestBearingAccounts InterestBearingAccounts
        {
            get { return FastDriver.GetPage<InterestBearingAccounts>(); }
        }

        public static InvoiceCommentDlg InvoiceCommentDlg
        {
            get { return FastDriver.GetPage<InvoiceCommentDlg>(); }
        }

        public static InvoiceFees InvoiceFees
        {
            get { return FastDriver.GetPage<InvoiceFees>(); }
        }

        public static FASTSelenium.PageObjects.IIS.InvoiceHistory InvoiceHistory
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.InvoiceHistory>(); }
        }

        public static IssueDisbursements IssueDisbursements
        {
            get { return FastDriver.GetPage<IssueDisbursements>(); }
        }

        public static IssueManualCheck IssueManualCheck
        {
            get { return FastDriver.GetPage<IssueManualCheck>(); }
        }

        public static IssueWireDisbursement IssueWireDisbursement
        {
            get { return FastDriver.GetPage<IssueWireDisbursement>(); }
        }

        public static LeaseDetail LeaseDetail
        {
            get { return FastDriver.GetPage<LeaseDetail>(); }
        }

        public static LeaseSummary LeaseSummary
        {
            get { return FastDriver.GetPage<LeaseSummary>(); }
        }

        public static LenderPoliciesDlg LenderPoliciesDlg
        {
            get { return FastDriver.GetPage<LenderPoliciesDlg>(); }
        }

        public static LoanInvestors LoanInvestors
        {
            get { return FastDriver.GetPage<LoanInvestors>(); }
        }

        public static LoanInvestorsDlg LoanInvestorsDlg
        {
            get { return FastDriver.GetPage<LoanInvestorsDlg>(); }
        }

        public static ManualCheckReceiptReason ManualCheckReceiptReason
        {
            get { return FastDriver.GetPage<ManualCheckReceiptReason>(); }
        }

        public static MgmtCheckDetailDlg MgmtCheckDetailDlg
        {
            get { return FastDriver.GetPage<MgmtCheckDetailDlg>(); }
        }

        public static MiscDisbursementDetail MiscDisbursementDetail
        {
            get { return FastDriver.GetPage<MiscDisbursementDetail>(); }
        }

        public static MiscDisbursementDetailDlg MiscDisbursementDetailDlg
        {
            get { return FastDriver.GetPage<MiscDisbursementDetailDlg>(); }
        }

        public static MiscellaneousDisbursementSummary MiscellaneousDisbursementSummary
        {
            get { return FastDriver.GetPage<MiscellaneousDisbursementSummary>(); }
        }

        public static MoveWorkQMessageDlg MoveWorkQMessageDlg
        {
            get { return FastDriver.GetPage<MoveWorkQMessageDlg>(); }
        }

        public static MyFASTToday MyFASTToday
        {
            get { return FastDriver.GetPage<MyFASTToday>(); }
        }

        public static WorkQueueMessageDlg WorkQueueMessageDlg
        {
            get { return FastDriver.GetPage<WorkQueueMessageDlg>(); }
        }

        public static NewFileEntry NewFileEntry
        {
            get { return FastDriver.GetPage<NewFileEntry>(); }
        }

        public static FASTSelenium.PageObjects.IIS.NewLoan NewLoan
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.NewLoan>(); }
        }

        public static NewLoanDisbursements NewLoanDisbursements
        {
            get { return FastDriver.GetPage<NewLoanDisbursements>(); }
        }

        public static NewLoanDlg NewLoanDlg
        {
            get { return FastDriver.GetPage<NewLoanDlg>(); }
        }

        public static NewLoanSummary NewLoanSummary
        {
            get { return FastDriver.GetPage<NewLoanSummary>(); }
        }

        public static OfficeSelectionDlg OfficeSelectionDlg
        {
            get { return FastDriver.GetPage<OfficeSelectionDlg>(); }
        }

        public static WebDlg OpenDocumentWindow
        {
            get { return GetPage<WebDlg>(); }
        }

        public static OpenImageDlg OpenImageDlg
        {
            get { return FastDriver.GetPage<OpenImageDlg>(); }
        }

        public static OrderAck OrderAck
        {
            get { return FastDriver.GetPage<OrderAck>(); }
        }

        public static OTCDetail OTCDetail
        {
            get { return FastDriver.GetPage<OTCDetail>(); }
        }

        public static OutsideEscrowCompanyDetail OutsideEscrowCompanyDetail
        {
            get { return FastDriver.GetPage<OutsideEscrowCompanyDetail>(); }
        }

        public static OutsideEscrowCompanySummary OutsideEscrowCompanySummary
        {
            get { return FastDriver.GetPage<OutsideEscrowCompanySummary>(); }
        }

        public static OutsideTitleCompanyDetail OutsideTitleCompanyDetail
        {
            get { return GetPage<OutsideTitleCompanyDetail>(); }
        }

        public static OutsideTitleSummary OutsideTitleSummary
        {
            get { return FastDriver.GetPage<OutsideTitleSummary>(); }
        }

        public static OverdraftConfirmationDlg OverdraftConfirmationDlg
        {
            get { return FastDriver.GetPage<OverdraftConfirmationDlg>(); }
        }


        public static PasswordConfirmationDlg PasswordConfirmationDlg
        {
            get { return FastDriver.GetPage<PasswordConfirmationDlg>(); }
        }

        public static Paste Paste
        {
            get { return FastDriver.GetPage<Paste>(); }
        }

        public static PathDetailsDlg PathDetailsDlg
        {
            get { return FastDriver.GetPage<PathDetailsDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.PayeeDetails PayeeDetails
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.PayeeDetails>(); }
        }

        public static PayeeDetailsDlg PayeeDetailsDlg
        {
            get { return FastDriver.GetPage<PayeeDetailsDlg>(); }
        }

        public static PayeeSearchDlg PayeeSearchDlg
        {
            get { return FastDriver.GetPage<PayeeSearchDlg>(); }
        }

        public static UW_EmployeeSearchDlg UW_EmployeeSearchDlg
        {
            get { return FastDriver.GetPage<UW_EmployeeSearchDlg>(); }
        }
        public static PaymentConfirmationDlg PaymentConfirmationDlg
        {
            get { return FastDriver.GetPage<PaymentConfirmationDlg>(); }
        }

        //This should be PaymentDetailsFileFeesDlg
        public static FASTSelenium.PageObjects.IIS.PaymentDetails PaymentDetails
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.PaymentDetails>(); }
        }

        public static PaymentDetailsDlg PaymentDetailsDlg
        {
            get { return FastDriver.GetPage<PaymentDetailsDlg>(); }
        }

        public static PaymentDetailsNewLoanDlg PaymentDetailsNewLoanDlg
        {
            get { return FastDriver.GetPage<PaymentDetailsNewLoanDlg>(); }
        }

        public static PaymentDetailsPayoffLoanLoanChargesDlg PaymentDetailsPayoffLoanLoanChargesDlg
        {
            get { return FastDriver.GetPage<PaymentDetailsPayoffLoanLoanChargesDlg>(); }
        }

        public static PaymentDialogDlg PaymentDialogDlg
        {
            get { return FastDriver.GetPage<PaymentDialogDlg>(); }
        }

        public static PayoffDemandManualRequestDlg PayoffDemandManualRequestDlg
        {
            get { return FastDriver.GetPage<PayoffDemandManualRequestDlg>(); }
        }

        public static PayoffDemandRequestDlg PayoffDemandRequestDlg
        {
            get { return FastDriver.GetPage<PayoffDemandRequestDlg>(); }
        }

        public static PayoffLoanCharges PayoffLoanCharges
        {
            get { return FastDriver.GetPage<PayoffLoanCharges>(); }
        }

        public static PayoffLoanDetails PayoffLoanDetails
        {
            get { return FastDriver.GetPage<PayoffLoanDetails>(); }
        }

        public static PayoffLoanParites PayoffLoanParites
        {
            get { return FastDriver.GetPage<PayoffLoanParites>(); }
        }

        public static PayoffLoanRecording PayoffLoanRecording
        {
            get { return FastDriver.GetPage<PayoffLoanRecording>(); }
        }

        public static PayoffLoanSummary PayoffLoanSummary
        {
            get { return FastDriver.GetPage<PayoffLoanSummary>(); }
        }

        public static PDCDeliveryDlg PDCDeliveryDlg
        {
            get { return FastDriver.GetPage<PDCDeliveryDlg>(); }
        }

        public static PendingFileSearch PendingFileSearch
        {
            get { return FastDriver.GetPage<PendingFileSearch>(); }
        }

        public static PhraseResequenceDlg PhraseResequenceDlg
        {
            get { return FastDriver.GetPage<PhraseResequenceDlg>(); }
        }

        public static PolicyNumberListDlg PolicyNumberListDlg
        {
            get { return FastDriver.GetPage<PolicyNumberListDlg>(); }
        }

        public static PrintChecks PrintChecks
        {
            get { return FastDriver.GetPage<PrintChecks>(); }
        }

        public static PrintDlg PrintDlg
        {
            get { return FastDriver.GetPage<PrintDlg>(); }
        }

        public static PrinterConfiguration PrinterConfiguration
        {
            get { return FastDriver.GetPage<PrinterConfiguration>(); }
        }

        public static PrintEscrowSetlleStmt PrintEscrowSetlleStmt
        {
            get { return FastDriver.GetPage<PrintEscrowSetlleStmt>(); }
        }

        public static ProblemList1Dlg ProblemList1Dlg
        {
            get { return FastDriver.GetPage<ProblemList1Dlg>(); }
        }

        //public static ProductListDlg ProductListDlg
        //{
        //    get { return FastDriver.GetPage<ProductListDlg>(); }
        //}

        public static ProductSelectionDialog ProductSelectionDialog
        {
            get { return FastDriver.GetPage<ProductSelectionDialog>(); }
        }

        public static ProductSelectionDlg ProductSelectionDlg
        {
            get { return FastDriver.GetPage<ProductSelectionDlg>(); }
        }

        public static ProductsListDlg ProductsListDlg
        {
            get { return FastDriver.GetPage<ProductsListDlg>(); }
        }

        public static ProgramTypesDlg ProgramTypesDlg
        {
            get { return FastDriver.GetPage<ProgramTypesDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.ProgramTypeStatus ProgramTypeStatus
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.ProgramTypeStatus>(); }
        }

        public static PropertiesSummary PropertiesSummary
        {
            get { return FastDriver.GetPage<PropertiesSummary>(); }
        }

        public static PropertyTaxCheck PropertyTaxCheck
        {
            get { return FastDriver.GetPage<PropertyTaxCheck>(); }
        }

        public static PropertyTaxInfoAnnualTax PropertyTaxInfoAnnualTax
        {
            get { return FastDriver.GetPage<PropertyTaxInfoAnnualTax>(); }
        }

        public static PropertyTaxInfoGeneral PropertyTaxInfoGeneral
        {
            get { return FastDriver.GetPage<PropertyTaxInfoGeneral>(); }
        }

        public static PropertyTaxInfoLegalDesciption PropertyTaxInfoLegal
        {
            get { return GetPage<PropertyTaxInfoLegalDesciption>(); }
        }

        public static PropertyTaxInfoLegalDesciption PropertyTaxInfoLegalDesciption
        {
            get { return FastDriver.GetPage<PropertyTaxInfoLegalDesciption>(); }
        }

        public static PropertyTaxInfoSpecialTax PropertyTaxInfoSpecialTax
        {
            get { return FastDriver.GetPage<PropertyTaxInfoSpecialTax>(); }
        }

        public static PropertyTaxInfoSupplementalTax PropertyTaxInfoSupplementalTax
        {
            get { return FastDriver.GetPage<PropertyTaxInfoSupplementalTax>(); }
        }

        public static PropertyTaxInfoTitleProd PropertyTaxInfoTitleProd
        {
            get { return FastDriver.GetPage<PropertyTaxInfoTitleProd>(); }
        }

        public static PropertyTaxSummary PropertyTaxSummary
        {
            get { return FastDriver.GetPage<PropertyTaxSummary>(); }
        }

        public static ProrationDateChangedDlg ProrationDateChangedDlg
        {
            get { return FastDriver.GetPage<ProrationDateChangedDlg>(); }
        }

        public static ProrationDetail ProrationDetail
        {
            get { return FastDriver.GetPage<ProrationDetail>(); }
        }

        public static ProrationTax ProrationTax
        {
            get { return FastDriver.GetPage<ProrationTax>(); }
        }

        public static ProrationRent ProrationRent
        {
            get { return FastDriver.GetPage<ProrationRent>(); }
        }

        public static PublishDocumentsDlg PublishDocumentsDlg
        {
            get { return FastDriver.GetPage<PublishDocumentsDlg>(); }
        }

        public static QASettings QASettings
        {
            get { return FastDriver.GetPage<QASettings>(); }
        }

        public static QuickFileEntry QuickFileEntry
        {
            get { return FastDriver.GetPage<QuickFileEntry>(); }
        }

        public static QuickRefiFileEntry QuickRefiFileEntry
        {
            get { return FastDriver.GetPage<QuickRefiFileEntry>(); }
        }

        public static RateTypeSelectDlg RateTypeSelectDlg
        {
            get { return FastDriver.GetPage<RateTypeSelectDlg>(); }
        }

        public static RealEstateBrokerAgent RealEstateBrokerAgent
        {
            get { return FastDriver.GetPage<RealEstateBrokerAgent>(); }
        }

        public static RealEstateBrokerAgentSummary RealEstateBrokerAgentSummary
        {
            get { return FastDriver.GetPage<RealEstateBrokerAgentSummary>(); }
        }

        public static RealTimeMailDeliveryEventDetails RealTimeMailDeliveryEventDetails
        {
            get { return FastDriver.GetPage<RealTimeMailDeliveryEventDetails>(); }
        }

        public static RealTimeMailDeliveryEventDetailsDlg RealTimeMailDeliveryEventDetailsDlg
        {
            get { return FastDriver.GetPage<RealTimeMailDeliveryEventDetailsDlg>(); }
        }

        public static RealTimeMailDlg RealTimeMailDlg
        {
            get { return FastDriver.GetPage<RealTimeMailDlg>(); }
        }

        public static ReasonforchangeDlg ReasonforchangeDlg
        {
            get { return FastDriver.GetPage<ReasonforchangeDlg>(); }
        }

        public static ReceiptAdjustmentDlg ReceiptAdjustmentDlg
        {
            get { return FastDriver.GetPage<ReceiptAdjustmentDlg>(); }
        }

        public static ReceiptToFile ReceiptToFile
        {
            get { return FastDriver.GetPage<ReceiptToFile>(); }
        }

        public static RecordedDocsDlg RecordedDocsDlg
        {
            get { return FastDriver.GetPage<RecordedDocsDlg>(); }
        }

        public static RecordFeeTransferTaxDisb RecordFeeTransferTaxDisb
        {
            get { return FastDriver.GetPage<RecordFeeTransferTaxDisb>(); }
        }

        public static RegionalBusinessProgramsSelectionDlg RegionalBusinessProgramsSelectionDlg
        {
            get { return FastDriver.GetPage<RegionalBusinessProgramsSelectionDlg>(); }
        }

        public static RenameDocDlg RenameDocDlg
        {
            get { return FastDriver.GetPage<RenameDocDlg>(); }
        }

        public static RequestPolicyNumber RequestPolicyNumber
        {
            get { return FastDriver.GetPage<RequestPolicyNumber>(); }
        }

        public static ReserveFileDlg ReserveFileDlg
        {
            get { return GetPage<ReserveFileDlg>(); }
        }

        public static ReserveFileNumber ReserveFileNumber
        {
            get { return FastDriver.GetPage<ReserveFileNumber>(); }
        }

        public static RetaininQDeleteDlg RetaininQDeleteDlg
        {
            get { return FastDriver.GetPage<RetaininQDeleteDlg>(); }
        }

        public static RotateCustom RotateCustom
        {
            get { return FastDriver.GetPage<RotateCustom>(); }
        }

        public static RPNProductSelectionDlg RPNProductSelectionDlg
        {
            get { return FastDriver.GetPage<RPNProductSelectionDlg>(); }
        }

        public static RPNVoidDlg RPNVoidDlg
        {
            get { return FastDriver.GetPage<RPNVoidDlg>(); }
        }

        public static RTM RTM
        {
            get { return FastDriver.GetPage<RTM>(); }
        }

        public static RTMMailToAddresseesDlg RTMMailToAddresseesDlg
        {
            get { return FastDriver.GetPage<RTMMailToAddresseesDlg>(); }
        }

        public static RTMPackageCountDlg RTMPackageCountDlg
        {
            get { return FastDriver.GetPage<RTMPackageCountDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.SaveDocument SaveDocument
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.SaveDocument>(); }
        }

        public static SaveDocumentDlg SaveDocumentDlg
        {
            get { return FastDriver.GetPage<SaveDocumentDlg>(); }
        }

        public static SaveMyFastTodayFilterDlg SaveMyFastTodayFilterDlg
        {
            get { return FastDriver.GetPage<SaveMyFastTodayFilterDlg>(); }
        }

        public static ScanFolder ScanFolder
        {
            get { return FastDriver.GetPage<ScanFolder>(); }
        }

        public static SDNTrackingSummary SDNTrackingSummary
        {
            get { return FastDriver.GetPage<SDNTrackingSummary>(); }
        }

        public static SearchApprovedAttorneyDlg SearchApprovedAttorneyDlg
        {
            get { return FastDriver.GetPage<SearchApprovedAttorneyDlg>(); }
        }

        public static SearchPageDlg SearchPageDlg
        {
            get { return FastDriver.GetPage<SearchPageDlg>(); }
        }

        public static SearchTypeDialogDlg SearchTypeDialogDlg
        {
            get { return FastDriver.GetPage<SearchTypeDialogDlg>(); }
        }

        public static SearchVendor SearchVendor
        {
            get { return FastDriver.GetPage<SearchVendor>(); }
        }

        public static SearchVendorSummary SearchVendorSummary
        {
            get { return FastDriver.GetPage<SearchVendorSummary>(); }
        }

        public static FASTSelenium.PageObjects.IIS.SelectBusinessProgramsDlg SelectBusinessProgramsDlg
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.SelectBusinessProgramsDlg>(); }
        }

        public static SelectExcReqInfNote SelectExcReqInfNote
        {
            get { return FastDriver.GetPage<SelectExcReqInfNote>(); }
        }

        public static SelectFeeDlg SelectFeeDlg
        {
            get { return FastDriver.GetPage<SelectFeeDlg>(); }
        }

        public static SelectIBABankDlg SelectIBABankDlg
        {
            get { return FastDriver.GetPage<SelectIBABankDlg>(); }
        }

        public static SelectIBABeneficiaryDlg SelectIBABeneficiaryDlg
        {
            get { return FastDriver.GetPage<SelectIBABeneficiaryDlg>(); }
        }

        public static SelectInstructionsDlg SelectInstructionsDlg
        {
            get { return FastDriver.GetPage<SelectInstructionsDlg>(); }
        }

        public static SelectSuccessorPathDlg SelectSuccessorPathDlg
        {
            get { return FastDriver.GetPage<SelectSuccessorPathDlg>(); }
        }

        public static SelectScannerDialog SelectScannerDialog
        {
            get { return FastDriver.GetPage<SelectScannerDialog>(); }
        }

        public static SelectSuccessorTaskDlg SelectSuccessorTaskDlg
        {
            get { return FastDriver.GetPage<SelectSuccessorTaskDlg>(); }
        }

        public static SelectWireInstructionsDlg SelectWireInstructionsDlg
        {
            get { return FastDriver.GetPage<SelectWireInstructionsDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.ServiceFee ServiceFee
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.ServiceFee>(); }
        }

        public static ServiceFeeDetailsDlg ServiceFeeDetailsDlg
        {
            get { return FastDriver.GetPage<ServiceFeeDetailsDlg>(); }
        }

        public static ServiceFeeLink ServiceFeeLink
        {
            get { return FastDriver.GetPage<ServiceFeeLink>(); }
        }

        public static SignatureSigning SignatureSigning
        {
            get { return FastDriver.GetPage<SignatureSigning>(); }
        }

        public static SpellingErrorDlg SpellingErrorDialog
        {
            get { return GetPage<SpellingErrorDlg>(); }
        }

        public static SpellingErrorDlg SpellingErrorDlg
        {
            get { return FastDriver.GetPage<SpellingErrorDlg>(); }
        }

        public static SplitDisbursement SplitDisbursement
        {
            get { return FastDriver.GetPage<SplitDisbursement>(); }
        }

        public static SplitDocumentScreenDlg SplitDocumentScreenDlg
        {
            get { return FastDriver.GetPage<SplitDocumentScreenDlg>(); }
        }

        public static SplitFeeDisbursements SplitFeeDisbursements
        {
            get { return FastDriver.GetPage<SplitFeeDisbursements>(); }
        }

        public static SplitGFE4LenderSelectedProvider SplitGFE4LenderSelectedProvider
        {
            get { return FastDriver.GetPage<SplitGFE4LenderSelectedProvider>(); }
        }

        public static StarterReference StarterReference
        {
            get { return FastDriver.GetPage<StarterReference>(); }
        }

        public static SurveyDetail SurveyDetail
        {
            get { return FastDriver.GetPage<SurveyDetail>(); }
        }

        public static SurveyDetailDlg SurveyDetailDlg
        {
            get { return FastDriver.GetPage<SurveyDetailDlg>(); }
        }

        public static SurveySummary SurveySummary
        {
            get { return FastDriver.GetPage<SurveySummary>(); }
        }

        public static SurveyTitle SurveyTitle
        {
            get { return FastDriver.GetPage<SurveyTitle>(); }
        }

        //public static TabFrameBottomDlg TabFrameBottomDlg
        //{
        //    get { return FastDriver.GetPage<TabFrameBottomDlg>(); }
        //}

        public static TaskCommentEditDlg TaskCommentEditDlg
        {
            get { return FastDriver.GetPage<TaskCommentEditDlg>(); }
        }

        public static TaskDetails TaskDetails
        {
            get { return FastDriver.GetPage<TaskDetails>(); }
        }

        public static TaskDetailsDlg TaskDetailsDlg
        {
            get { return FastDriver.GetPage<TaskDetailsDlg>(); }
        }

        public static TaskNameSelection TaskNameSelection
        {
            get { return FastDriver.GetPage<TaskNameSelection>(); }
        }

        public static TaskOfficeSelectionDlg TaskOfficeSelectionDlg
        {
            get { return FastDriver.GetPage<TaskOfficeSelectionDlg>(); }
        }

        public static TermsDatesStatus TermsDatesStatus
        {
            get { return FastDriver.GetPage<TermsDatesStatus>(); }
        }

        public static ThumbnailImageViewerDlg ThumbnailImageViewerDlg
        {
            get { return FastDriver.GetPage<ThumbnailImageViewerDlg>(); }
        }

        public static ThumbnailPrint ThumbnailPrint
        {
            get { return FastDriver.GetPage<ThumbnailPrint>(); }
        }

        public static Title Title
        {
            get { return FastDriver.GetPage<Title>(); }
        }

        public static titleDlg titleDlg
        {
            get { return FastDriver.GetPage<titleDlg>(); }
        }

        public static TitleReportSelection TitleReportSelection
        {
            get { return FastDriver.GetPage<TitleReportSelection>(); }
        }

        public static TitleSelection TitleSelection
        {
            get { return FastDriver.GetPage<TitleSelection>(); }
        }

        public static TitleVestingDlg TitleVestingDlg
        {
            get { return FastDriver.GetPage<TitleVestingDlg>(); }
        }

        public static ToleranceCureDescriptionDlg ToleranceCureDescriptionDlg
        {
            get { return FastDriver.GetPage<ToleranceCureDescriptionDlg>(); }
        }

        public static TopFrame TopFrame
        {
            get { return FastDriver.GetPage<TopFrame>(); }
        }

        public static TransferDetailsDlg TransferDetailsDlg
        {
            get { return FastDriver.GetPage<TransferDetailsDlg>(); }
        }

        public static TrialBalanceNoteDlg TrialBalanceNoteDlg
        {
            get { return FastDriver.GetPage<TrialBalanceNoteDlg>(); }
        }

        public static TrustAccounting TrustAccounting
        {
            get { return FastDriver.GetPage<TrustAccounting>(); }
        }

        public static UnderwriterAgentDetailDlg UnderwriterAgentDetailDlg
        {
            get { return FastDriver.GetPage<UnderwriterAgentDetailDlg>(); }
        }

        public static UploadDocumentDlg UploadDocumentDlg
        {
            get { return FastDriver.GetPage<UploadDocumentDlg>(); }
        }

        public static UploadFileToQueueDlg UploadFileToQueueDlg
        {
            get { return FastDriver.GetPage<UploadFileToQueueDlg>(); }
        }

        public static UtilityDetail UtilityDetail
        {
            get { return FastDriver.GetPage<UtilityDetail>(); }
        }

        public static UtilitySummary UtilitySummary
        {
            get { return FastDriver.GetPage<UtilitySummary>(); }
        }

        public static ViewDeliveryInstrucionsDlg ViewDeliveryInstrucionsDlg
        {
            get { return FastDriver.GetPage<ViewDeliveryInstrucionsDlg>(); }
        }

        public static ViewSettlementStatement ViewSettlementStatement
        {
            get { return FastDriver.GetPage<ViewSettlementStatement>(); }
        }

        public static NCSViewSettlementStatement NCSViewSettlementStatement
        {
            get { return FastDriver.GetPage<NCSViewSettlementStatement>(); }
        }
        public static ViewFractionalSettlementStmt ViewFractionalSettlementStmt
        {
            get { return FastDriver.GetPage<ViewFractionalSettlementStmt>(); }
        }  

        public static VoidDlg VoidDlg
        {
            get { return FastDriver.GetPage<VoidDlg>(); }
        }

        public static LoanEstimareWariningDlg LoanEstimareWariningDlg
        {
            get { return FastDriver.GetPage<LoanEstimareWariningDlg>(); }
        }

        public static WarningDlg WarningDlg
        {
            get { return FastDriver.GetPage<WarningDlg>(); }
        }

        public static WatermarkDlg WatermarkDlg
        {
            get { return FastDriver.GetPage<WatermarkDlg>(); }
        }

        public static WeekendWarning WeekendWarning
        {
            get { return FastDriver.GetPage<WeekendWarning>(); }
        }

        public static WireDisbursementApproval WireDisbursementApproval
        {
            get { return FastDriver.GetPage<WireDisbursementApproval>(); }
        }

        public static WireDisbursementSummary WireDisbursementSummary
        {
            get { return FastDriver.GetPage<WireDisbursementSummary>(); }
        }

        public static WorkFlowTriggerNames WorkFlowTriggerNames
        {
            get { return FastDriver.GetPage<WorkFlowTriggerNames>(); }
        }

        public static WorkFlowTriggerNamesDlg WorkFlowTriggerNamesDlg
        {
            get { return FastDriver.GetPage<WorkFlowTriggerNamesDlg>(); }
        }

        public static WorkgroupSelectionDlg WorkgroupSelectionDlg
        {
            get { return FastDriver.GetPage<WorkgroupSelectionDlg>(); }
        }

        public static WorkGroupSelectionDlg WorkGroupSelectionDlg
        {
            get { return FastDriver.GetPage<WorkGroupSelectionDlg>(); }
        }

        public static WorkQueueMessageDetailsDlg WorkQueueMessageDetailsDlg
        {
            get { return FastDriver.GetPage<WorkQueueMessageDetailsDlg>(); }
        }

        public static WorkQueueMessageLogDlg WorkQueueMessageLogDlg
        {
            get { return FastDriver.GetPage<WorkQueueMessageLogDlg>(); }
        }

        public static WorkQueueMessagesBrowser WorkQueueMessagesBrowser
        {
            get { return FastDriver.GetPage<WorkQueueMessagesBrowser>(); }
        }

        public static AttachMessage AttachMessageDlg
        {
            get { return FastDriver.GetPage<AttachMessage>(); }
        }

        public static WorkQueueMessagesBrowserDlg WorkQueueMessagesBrowserDlg
        {
            get { return FastDriver.GetPage<WorkQueueMessagesBrowserDlg>(); }
        }

        public static WorkQueueMessagesBrowserDlgB QueuePriorityDlg
        {
            get { return FastDriver.GetPage<WorkQueueMessagesBrowserDlgB>(); }
        }

        public static FASTSelenium.PageObjects.IIS.WorkQueueTop WorkQueueTop
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.WorkQueueTop>(); }
        }

        public static FASTSelenium.PageObjects.IIS.LenderUpdatesReviewDlg LenderUpdatesReviewDlg
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.LenderUpdatesReviewDlg>(); }
        }

        public static FASTSelenium.PageObjects.IIS.LenderUpdatesSingleWindow LenderUpdatesSingleWindow
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.LenderUpdatesSingleWindow>(); }
        }

        public static FASTSelenium.PageObjects.ClosingDisclosureEventsLog ClosingDisclosureEventsLog
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.ClosingDisclosureEventsLog>(); }
        }

        public static FASTSelenium.PageObjects.CDLenderReviewPopUp CDLenderReviewPopUp
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.CDLenderReviewPopUp>(); }
        }

        public static FASTSelenium.PageObjects.OtherCDUpdatesReview OtherCDUpdatesReview
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.OtherCDUpdatesReview>(); }
        }

        public static _1099S _1099S
        {
            get { return FastDriver.GetPage<_1099S>(); }
        }

        public static ProjectWorkBench ProjectWorkBench
        {
            get { return FastDriver.GetPage<ProjectWorkBench>(); }
        }

        public static AKANames AKANames
        {
            get { return FastDriver.GetPage<AKANames>(); }
        }

        public static IBATransactionPastBankCutoffTimeDlg IBATransactionPastBankCutoffTimeDlg
        {
            get { return FastDriver.GetPage<IBATransactionPastBankCutoffTimeDlg>(); }
        }

        public static DepositReceiptHistory DepositReceiptHistory
        {
            get { return FastDriver.GetPage<DepositReceiptHistory>(); }
        }

        public static NextGenDocumentPreparation NextGenDocumentPreparation
        {
            get { return FastDriver.GetPage<NextGenDocumentPreparation>(); }
        }
        public static SalePrice_OwnerPolicyLiabilityDlg SalePrice_OwnerPolicyLiabilityDlg
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.IIS.SalePrice_OwnerPolicyLiabilityDlg>(); }
        }
        
        public static Subordination Subordination
        {
            get { return FastDriver.GetPage<Subordination>(); }
        }
        
        public static Subordination_Summary Subordination_Summary
        {
            get { return FastDriver.GetPage<Subordination_Summary>(); }
        }

        public static SellerSelectionDlg SellerSelectionDlg
        {
            get { return FastDriver.GetPage<SellerSelectionDlg>(); }
        }

        public static FastViewFileSearchDialog FastViewFileSearchDialog
        {
            get { return FastDriver.GetPage<FastViewFileSearchDialog>(); }
        }

        #endregion

        #region ADM Page Objects

        public static WorkFlowTemplateReports WorkFlowTemplateReports
        {
            get { return GetPage<WorkFlowTemplateReports>(); }
        }

        public static ChangeHistory ChangeHistory
        {
            get { return GetPage<ChangeHistory>(); }
        }

        public static GABCompareDlg GABCompareDlg
        {
            get { return GetPage<GABCompareDlg>(); }
        }

        public static ViewAddContactsDlg ViewAddContactsDlg
        {
            get { return GetPage<ViewAddContactsDlg>(); }
        }

        public static RoleSelectionDialog RoleSelectionDialog
        {
            get { return GetPage<RoleSelectionDialog>(); }
        }

        //public static SecuritySelectRegionOffice SecuritySelectRegionOffice
        //{
        //    get { return GetPage<SecuritySelectRegionOffice>(); }
        //}

        public static CustomerSearch CustomerSearch
        {
            get { return GetPage<CustomerSearch>(); }
        }


        public static AddressBookSearch AddressBookSearch
        {
            get { return GetPage<AddressBookSearch>(); }
        }

        public static FeeSelectionCriteria FeeSelectionCriteria
        {
            get { return GetPage<FeeSelectionCriteria>(); }
        }
        
        public static AdmPrintDlg AdmPrintDlg
        {
            get { return FastDriver.GetPage<AdmPrintDlg>(); }
        }

        public static ADMProgramTypesDlg ADMProgramTypesDlg
        {
            get { return FastDriver.GetPage<ADMProgramTypesDlg>(); }
        }

        public static ADMSelectBusinessProgramsDlg ADMSelectBusinessProgramsDlg
        {
            get { return FastDriver.GetPage<ADMSelectBusinessProgramsDlg>(); }
        }

        public static AdrBookSrchDlg AdrBookSrchDlg
        {
            get { return FastDriver.GetPage<AdrBookSrchDlg>(); }
        }

        public static AssignBusinessPrograms AssignBusinessPrograms
        {
            get { return FastDriver.GetPage<AssignBusinessPrograms>(); }
        }

        public static AttachmentSelectionCriteriaDlg AttachmentSelectionCriteriaDlg
        {
            get { return FastDriver.GetPage<AttachmentSelectionCriteriaDlg>(); }
        }

        public static AttachmentSequenceDlg AttachmentSequenceDlg
        {
            get { return FastDriver.GetPage<AttachmentSequenceDlg>(); }
        }

        public static AutoWaiveTasksWebpageDialogDlg AutoWaiveTasksWebpageDialogDlg
        {
            get { return FastDriver.GetPage<AutoWaiveTasksWebpageDialogDlg>(); }
        }

        public static BankBranchOfficeAccountSummaryDlg BankBranchOfficeAccountSummaryDlg
        {
            get { return FastDriver.GetPage<BankBranchOfficeAccountSummaryDlg>(); }
        }

        public static BankDetail BankDetail
        {
            get { return FastDriver.GetPage<BankDetail>(); }
        }

        public static BankDetailDlg BankDetailDlg
        {
            get { return FastDriver.GetPage<BankDetailDlg>(); }
        }

        public static BankSummary BankSummary
        {
            get { return FastDriver.GetPage<BankSummary>(); }
        }

        public static BestMatchSimulator BestMatchSimulator
        {
            get { return FastDriver.GetPage<BestMatchSimulator>(); }
        }

        public static BestMatchSimulatorMatrixDlg BestMatchSimulatorMatrixDlg
        {
            get { return FastDriver.GetPage<BestMatchSimulatorMatrixDlg>(); }
        }

        public static BestMatchSimulatorSimProTemplates BestMatchSimulatorSimProTemplates
        {
            get { return FastDriver.GetPage<BestMatchSimulatorSimProTemplates>(); }
        }

        public static BusinessOrgRelationships BusinessOrgRelationships
        {
            get { return FastDriver.GetPage<BusinessOrgRelationships>(); }
        }

        public static BusOrgContactRelationships BusOrgContactRelationships
        {
            get { return FastDriver.GetPage<BusOrgContactRelationships>(); }
        }

        public static BPSetupCompareGABReqContactDlg BPSetupCompareGABReqContactDlg
        {
            get { return FastDriver.GetPage<BPSetupCompareGABReqContactDlg>(); }
        }

        public static BPSetupCompareRegGABContactDlg BPSetupCompareRegGABContactDlg
        {
            get { return FastDriver.GetPage<BPSetupCompareRegGABContactDlg>(); }
        }

        public static BusinessPartyContactSetupDlg BusinessPartyContactSetupDlg
        {
            get { return FastDriver.GetPage<BusinessPartyContactSetupDlg>(); }
        }

        public static BusPartyOrgSetUp BusinessPartyOrganizationSetUp
        {
            get { return FastDriver.GetPage<BusPartyOrgSetUp>(); }
        }

        public static BusinessPartyOrganizationSetUpDlg BusinessPartyOrganizationSetUpDlg
        {
            get { return FastDriver.GetPage<BusinessPartyOrganizationSetUpDlg>(); }
        }

        public static MaintainCorporateBusinessProgram MaintainCorporateBusinessProgram
        {
            get { return FastDriver.GetPage<MaintainCorporateBusinessProgram>(); }
        }

        public static BusinessUnitRoleAssignment BusinessUnitRoleAssignment
        {
            get { return FastDriver.GetPage<BusinessUnitRoleAssignment>(); }
        }

        public static BusinessUnitSelectionDlg BusinessUnitSelectionDlg
        {
            get { return FastDriver.GetPage<BusinessUnitSelectionDlg>(); }
        }

        public static BusOrgSearchDlg BusOrgSearchDlg
        {
            get { return FastDriver.GetPage<BusOrgSearchDlg>(); }
        }

        public static BusPartyContactSetup BusPartyContactSetup
        {
            get { return FastDriver.GetPage<BusPartyContactSetup>(); }
        }

        public static BusPartyContactsList BusPartyContactsList
        {
            get { return FastDriver.GetPage<BusPartyContactsList>(); }
        }

        public static BusPartyOrg BusPartyOrg
        {
            get { return FastDriver.GetPage<BusPartyOrg>(); }
        }

        public static BusPartyOrgeSubscriptionsDlg BusPartyOrgeSubscriptionsDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgeSubscriptionsDlg>(); }
        }

        public static BusPartyOrgExtCustomerDlg BusPartyOrgExtCustomerDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgExtCustomerDlg>(); }
        }

        public static BusPartyOrgHoriGABEntryReqDlg BusPartyOrgHoriGABEntryReqDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgHoriGABEntryReqDlg>(); }
        }

        public static BusPartyOrgHoriRegionalGABRecDlg BusPartyOrgHoriRegionalGABRecDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgHoriRegionalGABRecDlg>(); }
        }

        public static BusPartyOrgRegionalGABContacts BusPartyOrgRegionalGABContacts
        {
            get { return FastDriver.GetPage<BusPartyOrgRegionalGABContacts>(); }
        }

        public static BusPartyOrgGABRequestContacts BusPartyOrgGABRequestContacts
        {
            get { return FastDriver.GetPage<BusPartyOrgGABRequestContacts>(); }
        }

        public static BusPartyOrgSetUp BusPartyOrgSetUp
        {
            get { return FastDriver.GetPage<BusPartyOrgSetUp>(); }
        }

        public static BusPartyOrgSetUpAddToGABDlg BusPartyOrgSetUpAddToGABDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgSetUpAddToGABDlg>(); }
        }

        public static BusPartyOrgVerticalRegGABDlg BusPartyOrgVerticalRegGABDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgVerticalRegGABDlg>(); }
        }

        public static BusPartyOrgVertiGABEntryReqDlg BusPartyOrgVertiGABEntryReqDlg
        {
            get { return FastDriver.GetPage<BusPartyOrgVertiGABEntryReqDlg>(); }
        }

        public static CitySelectionDlg CitySelectionDlg
        {
            get { return FastDriver.GetPage<CitySelectionDlg>(); }
        }

        public static CommentCodeSearchDlg CommentCodeSearchDlg
        {
            get { return FastDriver.GetPage<CommentCodeSearchDlg>(); }
        }

        //Team                  :  ServReq-Team2 (Production Support)
        //Iteration             :  r09
        //UserStory             :  User Story 837583
        //TestCase              :  864455
        //Appended By/ Created By: Shobhit
        public static SalesRepSrchDlg SalesRepSrchDlg
        {
            get { return FastDriver.GetPage<SalesRepSrchDlg>(); }
        }
        //end


        public static ChangeHistoryDlg ChangeHistoryDlg
        {
            get { return FastDriver.GetPage<ChangeHistoryDlg>(); }
        }

        public static FASTSelenium.PageObjects.ADM.ChargeDetails ChargeDetails
        {
            get { return FastDriver.GetPage<FASTSelenium.PageObjects.ADM.ChargeDetails>(); }
        }

        public static ChngHistDlg ChngHistDlg
        {
            get { return FastDriver.GetPage<ChngHistDlg>(); }
        }

        public static CopyNotificationToDlg CopyNotificationToDlg
        {
            get { return FastDriver.GetPage<CopyNotificationToDlg>(); }
        }

        public static CorporateProblemLog CorporateProblemLog
        {
            get { return FastDriver.GetPage<CorporateProblemLog>(); }
        }

        public static CorporateProblemLogDlg CorporateProblemLogDlg
        {
            get { return FastDriver.GetPage<CorporateProblemLogDlg>(); }
        }

        public static CorporateProcessSummary CorporateProcessSummary
        {
            get { return FastDriver.GetPage<CorporateProcessSummary>(); }
        }

        public static CountySelectionDlg CountySelectionDlg
        {
            get { return FastDriver.GetPage<CountySelectionDlg>(); }
        }

        public static CPUProductionOffice CPUProductionOffice
        {
            get { return FastDriver.GetPage<CPUProductionOffice>(); }
        }

        public static CustomaryWorkgroups CustomaryWorkgroups
        {
            get { return FastDriver.GetPage<CustomaryWorkgroups>(); }
        }

        public static CustomerOptionsScreen CustomerOptionsScreen
        {
            get { return FastDriver.GetPage<CustomerOptionsScreen>(); }
        }

        public static DataElementsDlg DataElementsDlg
        {
            get { return FastDriver.GetPage<DataElementsDlg>(); }
        }

        public static DataElementSelectionDlg DataElementSelectionDlg
        {
            get { return FastDriver.GetPage<DataElementSelectionDlg>(); }
        }

        public static DictionaryManagement DictionaryManagement
        {
            get { return FastDriver.GetPage<DictionaryManagement>(); }
        }

        public static DocPrepReports DocPrepReports
        {
            get { return FastDriver.GetPage<DocPrepReports>(); }
        }

        public static DocPrepReports1 DocPrepReports1
        {
            get { return FastDriver.GetPage<DocPrepReports1>(); }
        }

        public static DocPrepReports2 DocPrepReports2
        {
            get { return FastDriver.GetPage<DocPrepReports2>(); }
        }

        public static DocPrepReportsPGPT DocPrepReportsPGPT
        {
            get { return FastDriver.GetPage<DocPrepReportsPGPT>(); }
        }

        public static DocPrepReportsPGPT1 DocPrepReportsPGPT1
        {
            get { return FastDriver.GetPage<DocPrepReportsPGPT1>(); }
        }

        public static DocPrepReportsPhraseGroupsbyPhraseType DocPrepReportsPhraseGroupsbyPhraseType
        {
            get { return FastDriver.GetPage<DocPrepReportsPhraseGroupsbyPhraseType>(); }
        }

        public static DocPrepReportsPhrasesbyPhraseGroup DocPrepReportsPhrasesbyPhraseGroup
        {
            get { return FastDriver.GetPage<DocPrepReportsPhrasesbyPhraseGroup>(); }
        }

        public static DocPrepReportsPhrasesbyTemplate DocPrepReportsPhrasesbyTemplate
        {
            get { return FastDriver.GetPage<DocPrepReportsPhrasesbyTemplate>(); }
        }

        public static DocPrepReportsPhrasesbyTemplate1 DocPrepReportsPhrasesbyTemplate1
        {
            get { return FastDriver.GetPage<DocPrepReportsPhrasesbyTemplate1>(); }
        }

        public static DocPrepReportsTemplatesbyTemplateType DocPrepReportsTemplatesbyTemplateType
        {
            get { return FastDriver.GetPage<DocPrepReportsTemplatesbyTemplateType>(); }
        }

        public static DocPrepReportsTemplatesbyTemplateType1 DocPrepReportsTemplatesbyTemplateType1
        {
            get { return FastDriver.GetPage<DocPrepReportsTemplatesbyTemplateType1>(); }
        }

        public static DocPrepReportsTemplatesUsingPhrases DocPrepReportsTemplatesUsingPhrases
        {
            get { return FastDriver.GetPage<DocPrepReportsTemplatesUsingPhrases>(); }
        }

        public static DocPrepReportsTemplatesUsingPhrases1 DocPrepReportsTemplatesUsingPhrases1
        {
            get { return FastDriver.GetPage<DocPrepReportsTemplatesUsingPhrases1>(); }
        }

        public static DocumentDeliveryFileEventSetupDlg DocumentDeliveryFileEventSetupDlg
        {
            get { return FastDriver.GetPage<DocumentDeliveryFileEventSetupDlg>(); }
        }

        public static DocumentDeliveryProcessEventSetupDlg DocumentDeliveryProcessEventSetupDlg
        {
            get { return FastDriver.GetPage<DocumentDeliveryProcessEventSetupDlg>(); }
        }

        public static DocumentDeliverySelectionDlg DocumentDeliverySelectionDlg
        {
            get { return FastDriver.GetPage<DocumentDeliverySelectionDlg>(); }
        }

        public static DocumentDeliveryTaskEventSetupDlg DocumentDeliveryTaskEventSetupDlg
        {
            get { return FastDriver.GetPage<DocumentDeliveryTaskEventSetupDlg>(); }
        }

        public static DocumentSelectionDlg DocumentSelectionDlg
        {
            get { return FastDriver.GetPage<DocumentSelectionDlg>(); }
        }

        public static DocumentSequencingDlg DocumentSequencingDlg
        {
            get { return FastDriver.GetPage<DocumentSequencingDlg>(); }
        }

        public static EditCommentsDlg EditCommentsDlg
        {
            get { return FastDriver.GetPage<EditCommentsDlg>(); }
        }

        public static EditElectronicDeliveryGroup EditElectronicDeliveryGroup
        {
            get { return FastDriver.GetPage<EditElectronicDeliveryGroup>(); }
        }

        public static EditPhrase EditPhrase
        {
            get { return FastDriver.GetPage<EditPhrase>(); }
        }

        public static EditPhraseMarkerPropertiesDlg EditPhraseMarkerPropertiesDlg
        {
            get { return FastDriver.GetPage<EditPhraseMarkerPropertiesDlg>(); }
        }

        public static ElectronicDeliveryGroup ElectronicDeliveryGroup
        {
            get { return FastDriver.GetPage<ElectronicDeliveryGroup>(); }
        }

        public static EmployedByStatus EmployedByStatus
        {
            get { return FastDriver.GetPage<EmployedByStatus>(); }
        }

        public static EmployeeSearch EmployeeSearch
        {
            get { return FastDriver.GetPage<EmployeeSearch>(); }
        }

        public static EmployeeSecurity EmployeeSecurity
        {
            get { return FastDriver.GetPage<EmployeeSecurity>(); }
        }

        public static EmployeeSecurityChangeHistory EmployeeSecurityChangeHistory
        {
            get { return FastDriver.GetPage<EmployeeSecurityChangeHistory>(); }
        }

        public static EmployeeSetup EmployeeSetup
        {
            get { return FastDriver.GetPage<EmployeeSetup>(); }
        }

        public static EscrowChargeSetup EscrowChargeSetup
        {
            get { return FastDriver.GetPage<EscrowChargeSetup>(); }
        }

        public static ExternalCustomerDlg ExternalCustomerDlg
        {
            get { return FastDriver.GetPage<ExternalCustomerDlg>(); }
        }

        public static ExternalSystemResponseDlg ExternalSystemResponseDlg
        {
            get { return FastDriver.GetPage<ExternalSystemResponseDlg>(); }
        }

        public static FeeFilterReports FeeFilterReports
        {
            get { return FastDriver.GetPage<FeeFilterReports>(); }
        }

        public static FeeFilterTemplateSummaryDlg FeeFilterTemplateSummaryDlg
        {
            get { return FastDriver.GetPage<FeeFilterTemplateSummaryDlg>(); }
        }

        public static FeeFilterTemplateEdit FeeFilterTemplateEdit
        {
            get { return FastDriver.GetPage<FeeFilterTemplateEdit>(); }
        }

        public static FeeFilterTemplatesSummary FeeFilterTemplatesSummary
        {
            get { return FastDriver.GetPage<FeeFilterTemplatesSummary>(); }
        }

        public static FeeList2 FeeList2
        {
            get { return FastDriver.GetPage<FeeList2>(); }
        }

        public static FeeSetup FeeSetup
        {
            get { return FastDriver.GetPage<FeeSetup>(); }
        }

        public static FieldChangedTaskEventSetup FieldChangedTaskEventSetup
        {
            get { return FastDriver.GetPage<FieldChangedTaskEventSetup>(); }
        }

        public static FieldChangedTaskEventSetupDlg FieldChangedTaskEventSetupDlg
        {
            get { return FastDriver.GetPage<FieldChangedTaskEventSetupDlg>(); }
        }

        public static FormMaintenance FormMaintenance
        {
            get { return FastDriver.GetPage<FormMaintenance>(); }
        }

        public static FormMaintenanceSummary FormMaintenanceSummary
        {
            get { return FastDriver.GetPage<FormMaintenanceSummary>(); }
        }

        //public static FASTSelenium.PageObjects.ADM.GABEntryRequestDlg GABEntryRequestDlg
        //{
        //    get { return FastDriver.GetPage<FASTSelenium.PageObjects.ADM.GABEntryRequestDlg>(); }
        //}

        public static GABEntryRequestQueue GABEntryRequestQueue
        {
            get { return FastDriver.GetPage<GABEntryRequestQueue>(); }
        }

        public static GABMasterDetail GABMasterDetail
        {
            get { return FastDriver.GetPage<GABMasterDetail>(); }
        }

        public static GABMasterList GABMasterList
        {
            get { return FastDriver.GetPage<GABMasterList>(); }
        }

        public static GABMergeContacts GABMergeContacts
        {
            get { return FastDriver.GetPage<GABMergeContacts>(); }
        }

        public static GeneralLedgerList GeneralLedgerList
        {
            get { return FastDriver.GetPage<GeneralLedgerList>(); }
        }

        public static GeneralLedgerSetup GeneralLedgerSetup
        {
            get { return FastDriver.GetPage<GeneralLedgerSetup>(); }
        }

        public static GeograficFilterSelectionDlg GeograficFilterSelectionDlg
        {
            get { return FastDriver.GetPage<GeograficFilterSelectionDlg>(); }
        }

        public static groupElementsDlg groupElementsDlg
        {
            get { return FastDriver.GetPage<groupElementsDlg>(); }
        }

        public static IBABankSetup IBABankSetup
        {
            get { return FastDriver.GetPage<IBABankSetup>(); }
        }

        public static ImageSelectionDlg ImageSelectionDlg
        {
            get { return FastDriver.GetPage<ImageSelectionDlg>(); }
        }

        public static ImageTriggerProcessEventSetupDlg ImageTriggerProcessEventSetupDlg
        {
            get { return FastDriver.GetPage<ImageTriggerProcessEventSetupDlg>(); }
        }

        public static ImageTriggerTaskEventSetupDlg ImageTriggerTaskEventSetupDlg
        {
            get { return FastDriver.GetPage<ImageTriggerTaskEventSetupDlg>(); }
        }

        public static ImportantIndicatorsDlg ImportantIndicatorsDlg
        {
            get { return FastDriver.GetPage<ImportantIndicatorsDlg>(); }
        }

        public static ImportTasksfromProcessTemplateDlg ImportTasksfromProcessTemplateDlg
        {
            get { return FastDriver.GetPage<ImportTasksfromProcessTemplateDlg>(); }
        }

        public static IncomingWires IncomingWires
        {
            get { return FastDriver.GetPage<IncomingWires>(); }
        }

        public static IncomingWireViewDetails IncomingWireViewDetails
        {
            get { return FastDriver.GetPage<IncomingWireViewDetails>(); }
        }

        public static LeftFrame LeftFrame
        {
            get { return FastDriver.GetPage<LeftFrame>(); }
        }

        public static LicenseInformationDlg LicenseInformationDlg
        {
            get { return FastDriver.GetPage<LicenseInformationDlg>(); }
        }

        public static LicenseInfoChangeHistoryDlg LicenseInfoChangeHistoryDlg
        {
            get { return FastDriver.GetPage<LicenseInfoChangeHistoryDlg>(); }
        }

        public static LicenseInformationStatusDlg LicenseInformationStatusDlg
        {
            get { return FastDriver.GetPage<LicenseInformationStatusDlg>(); }
        }

        public static ListPhraseGroupsbyPhraseType ListPhraseGroupsbyPhraseType
        {
            get { return FastDriver.GetPage<ListPhraseGroupsbyPhraseType>(); }
        }

        public static ListPhrasesbyPhraseGroup ListPhrasesbyPhraseGroup
        {
            get { return FastDriver.GetPage<ListPhrasesbyPhraseGroup>(); }
        }

        public static ListPhrasesbyTemplate ListPhrasesbyTemplate
        {
            get { return FastDriver.GetPage<ListPhrasesbyTemplate>(); }
        }

        public static ListTemplatesbyTemplateType ListTemplatesbyTemplateType
        {
            get { return FastDriver.GetPage<ListTemplatesbyTemplateType>(); }
        }

        public static ListTemplatesUsingSpecificPhrases ListTemplatesUsingSpecificPhrases
        {
            get { return FastDriver.GetPage<ListTemplatesUsingSpecificPhrases>(); }
        }

        public static MaintainBusinessPrograms MaintainBusinessPrograms
        {
            get { return FastDriver.GetPage<MaintainBusinessPrograms>(); }
        }

        public static ManageWorkQueues ManageWorkQueues
        {
            get { return FastDriver.GetPage<ManageWorkQueues>(); }
        }

        public static ManageWorkQueueUsers ManageWorkQueueUsers
        {
            get { return FastDriver.GetPage<ManageWorkQueueUsers>(); }
        }

        public static MessageTemplateSelectionDlg MessageTemplateSelectionDlg
        {
            get { return FastDriver.GetPage<MessageTemplateSelectionDlg>(); }
        }

        public static MortgageProductsDlg MortgageProductsDlg
        {
            get { return FastDriver.GetPage<MortgageProductsDlg>(); }
        }

        public static NotesEntryDlg NotesEntryDlg
        {
            get { return FastDriver.GetPage<NotesEntryDlg>(); }
        }

        public static NotificationEmailAddressesDlg NotificationEmailAddressesDlg
        {
            get { return FastDriver.GetPage<NotificationEmailAddressesDlg>(); }
        }

        public static NotificationSetup NotificationSetup
        {
            get { return FastDriver.GetPage<NotificationSetup>(); }
        }

        public static NotificationSummary NotificationSummary
        {
            get { return FastDriver.GetPage<NotificationSummary>(); }
        }

        public static OfficeGroupSetup OfficeGroupSetup
        {
            get { return FastDriver.GetPage<OfficeGroupSetup>(); }
        }

        public static OfficeSelection OfficeSelection
        {
            get { return FastDriver.GetPage<OfficeSelection>(); }
        }

        public static OfficeSelectionsDlg OfficeSelectionsDlg
        {
            get { return FastDriver.GetPage<OfficeSelectionsDlg>(); }
        }

        public static OfficeSetupBankAccounts OfficeSetupBankAccounts
        {
            get { return FastDriver.GetPage<OfficeSetupBankAccounts>(); }
        }

        public static OfficeSetupOffice OfficeSetupOffice
        {
            get { return FastDriver.GetPage<OfficeSetupOffice>(); }
        }

        public static OfficeSetupPayeeAssignments OfficeSetupPayeeAssignments
        {
            get { return FastDriver.GetPage<OfficeSetupPayeeAssignments>(); }
        }

        public static OfficeSetupUnderwriters OfficeSetupUnderwriters
        {
            get { return FastDriver.GetPage<OfficeSetupUnderwriters>(); }
        }

        public static OfficeSummary OfficeSummary
        {
            get { return FastDriver.GetPage<OfficeSummary>(); }
        }

        public static OpenOrderDocumentCopies OpenOrderDocumentCopies
        {
            get { return FastDriver.GetPage<OpenOrderDocumentCopies>(); }
        }

        public static OrderListFormatDlg OrderListFormatDlg
        {
            get { return FastDriver.GetPage<OrderListFormatDlg>(); }
        }

        public static PendingRefreshSummary PendingRefreshSummary
        {
            get { return FastDriver.GetPage<PendingRefreshSummary>(); }
        }

        public static PhraseConditionsDlg PhraseConditionsDlg
        {
            get { return FastDriver.GetPage<PhraseConditionsDlg>(); }
        }

        public static PhraseCopy PhraseCopy
        {
            get { return FastDriver.GetPage<PhraseCopy>(); }
        }

        public static PhraseEditorDlg PhraseEditorDlg
        {
            get { return FastDriver.GetPage<PhraseEditorDlg>(); }
        }

        public static BuyerSellerSignatureDlg BuyerSellerSignatureDlg
        {
            get { return FastDriver.GetPage<BuyerSellerSignatureDlg>(); }
        }

        public static PhraseGroupMaintenance PhraseGroupMaintenance
        {
            get { return FastDriver.GetPage<PhraseGroupMaintenance>(); }
        }

        public static PhraseGroupMaintenanceSummary PhraseGroupMaintenanceSummary
        {
            get { return FastDriver.GetPage<PhraseGroupMaintenanceSummary>(); }
        }

        public static PhraseGroupSelectDlg PhraseGroupSelectDlg
        {
            get { return FastDriver.GetPage<PhraseGroupSelectDlg>(); }
        }

        public static PhraseMaintenance PhraseMaintenance
        {
            get { return FastDriver.GetPage<PhraseMaintenance>(); }
        }

        public static PhraseMaintenancetitle PhraseMaintenancetitle
        {
            get { return FastDriver.GetPage<PhraseMaintenancetitle>(); }
        }

        public static PhraseSelectDlg PhraseSelectDlg
        {
            get { return FastDriver.GetPage<PhraseSelectDlg>(); }
        }

        public static PreviousSessionsDlg PreviousSessionsDlg
        {
            get { return FastDriver.GetPage<PreviousSessionsDlg>(); }
        }

        public static ProblemListDlg ProblemListDlg
        {
            get { return FastDriver.GetPage<ProblemListDlg>(); }
        }

        public static ProcessEventSelection ProcessEventSelection
        {
            get { return FastDriver.GetPage<ProcessEventSelection>(); }
        }

        public static ProcessEventSelectionDlg ProcessEventSelectionDlg
        {
            get { return FastDriver.GetPage<ProcessEventSelectionDlg>(); }
        }

        public static ProcessingRegionSetup ProcessingRegionSetup
        {
            get { return FastDriver.GetPage<ProcessingRegionSetup>(); }
        }

        public static ProcessingRegionSummary ProcessingRegionSummary
        {
            get { return FastDriver.GetPage<ProcessingRegionSummary>(); }
        }

        public static ProcessTemplateSelectionCriteria ProcessTemplateSelectionCriteria
        {
            get { return GetPage<ProcessTemplateSelectionCriteria>(); }
        }

        public static ProcessTemplateTasksDlg ProcessTemplateTasksDlg
        {
            get { return FastDriver.GetPage<ProcessTemplateTasksDlg>(); }
        }

        public static ProductionCenterSelectDlg ProductionCenterSelectDlg
        {
            get { return FastDriver.GetPage<ProductionCenterSelectDlg>(); }
        }

        public static ProductListDlg ProductListDlg
        {
            get { return FastDriver.GetPage<ProductListDlg>(); }
        }

        public static ProductSetup ProductSetup
        {
            get { return FastDriver.GetPage<ProductSetup>(); }
        }

        public static ProfileAssignment ProfileAssignment
        {
            get { return FastDriver.GetPage<ProfileAssignment>(); }
        }

        public static ProfileSecurityChangeHistory ProfileSecurityChangeHistory
        {
            get { return FastDriver.GetPage<ProfileSecurityChangeHistory>(); }
        }

        public static ProfileSetup ProfileSetup
        {
            get { return FastDriver.GetPage<ProfileSetup>(); }
        }

        public static ProfileStatus ProfileStatus
        {
            get { return FastDriver.GetPage<ProfileStatus>(); }
        }

        public static ProgramTypeEdit ProgramTypeEdit
        {
            get { return FastDriver.GetPage<ProgramTypeEdit>(); }
        }

        public static ProgramTypeReport ProgramTypeReport
        {
            get { return FastDriver.GetPage<ProgramTypeReport>(); }
        }

        public static ProgramTypes ProgramTypes
        {
            get { return FastDriver.GetPage<ProgramTypes>(); }
        }

        public static ProgramTypeSetup ProgramTypeSetup
        {
            get { return FastDriver.GetPage<ProgramTypeSetup>(); }
        }

        //public static FASTSelenium.PageObjects.ADM.ProgramTypeStatus ProgramTypeStatus
        //{
        //    get { return FastDriver.GetPage<FASTSelenium.PageObjects.ADM.ProgramTypeStatus>(); }
        //}

        public static RegionalBusinessPrograms RegionalBusinessPrograms
        {
            get { return FastDriver.GetPage<RegionalBusinessPrograms>(); }
        }

        public static RegionalDeliveryDestination RegionalDeliveryDestination
        {
            get { return FastDriver.GetPage<RegionalDeliveryDestination>(); }
        }

        public static RegionalProblemLog RegionalProblemLog
        {
            get { return FastDriver.GetPage<RegionalProblemLog>(); }
        }

        public static RegionalProcessEdit RegionalProcessEdit
        {
            get { return FastDriver.GetPage<RegionalProcessEdit>(); }
        }

        public static RegionalProcessSummary RegionalProcessSummary
        {
            get { return FastDriver.GetPage<RegionalProcessSummary>(); }
        }

        public static RegionselectionDlg RegionselectionDlg
        {
            get { return FastDriver.GetPage<RegionselectionDlg>(); }
        }

        public static RelationshipRoleDlg RelationshipRoleDlg
        {
            get { return FastDriver.GetPage<RelationshipRoleDlg>(); }
        }

        public static ReturnWire ReturnWire
        {
            get { return FastDriver.GetPage<ReturnWire>(); }
        }

        public static RoleBusinessUnitAssignment RoleBusinessUnitAssignment
        {
            get { return FastDriver.GetPage<RoleBusinessUnitAssignment>(); }
        }

        public static RoleChangeHistory RoleChangeHistory
        {
            get { return FastDriver.GetPage<RoleChangeHistory>(); }
        }

        public static RoleMaintenanceSummary RoleMaintenanceSummary
        {
            get { return FastDriver.GetPage<RoleMaintenanceSummary>(); }
        }

        public static RoleSetup RoleSetup
        {
            get { return FastDriver.GetPage<RoleSetup>(); }
        }

        public static ScheduleExtracts ScheduleExtracts
        {
            get { return FastDriver.GetPage<ScheduleExtracts>(); }
        }

        public static SearchTypesDlg SearchTypesDlg
        {
            get { return FastDriver.GetPage<SearchTypesDlg>(); }
        }

        public static SecurityOfficeGroupChangeHistory SecurityOfficeGroupChangeHistory
        {
            get { return FastDriver.GetPage<SecurityOfficeGroupChangeHistory>(); }
        }

        public static SecurityOfficeGroupSetup SecurityOfficeGroupSetup
        {
            get { return FastDriver.GetPage<SecurityOfficeGroupSetup>(); }
        }

        //public static FASTSelenium.PageObjects.ADM.SelectBusinessProgramsDlg SelectBusinessProgramsDlg
        //{
        //    get { return FastDriver.GetPage<FASTSelenium.PageObjects.ADM.SelectBusinessProgramsDlg>(); }
        //}

        public static SelectCustomaryWorkgroups SelectCustomaryWorkgroups
        {
            get { return FastDriver.GetPage<SelectCustomaryWorkgroups>(); }
        }

        public static SelectCustomaryWorkgroupsDlg SelectCustomaryWorkgroupsDlg
        {
            get { return FastDriver.GetPage<SelectCustomaryWorkgroupsDlg>(); }
        }

        public static SelectFBPRolesDlg SelectFBPRolesDlg
        {
            get { return FastDriver.GetPage<SelectFBPRolesDlg>(); }
        }

        public static SelectInstructionDlg SelectInstructionDlg
        {
            get { return FastDriver.GetPage<SelectInstructionDlg>(); }
        }

        public static BusinessOrgSearchDlg BusinessOrgSearchDlg
        {
            get { return FastDriver.GetPage<BusinessOrgSearchDlg>(); }
        }
        public static SelectionCriteriaDlg SelectionCriteriaDlg
        {
            get { return FastDriver.GetPage<SelectionCriteriaDlg>(); }
        }

        public static PropertySelectionDlg PropertySelectionDlg
        {
            get { return FastDriver.GetPage<PropertySelectionDlg>(); }
        }

        public static OfiiceGroupOfficeSelectionDlg OfiiceGroupOfficeSelectionDlg
        {
            get { return FastDriver.GetPage<OfiiceGroupOfficeSelectionDlg>(); }
        }

        public static SelectCommentCodeDlg SelectCommentCodeDlg
        {
            get { return FastDriver.GetPage<SelectCommentCodeDlg>(); }
        }

        public static SelectOfficeDlg SelectOfficeDlg
        {
            get { return FastDriver.GetPage<SelectOfficeDlg>(); }
        }

        public static SelectPhraseGroupPhraseDlg SelectPhraseGroupPhraseDlg
        {
            get { return FastDriver.GetPage<SelectPhraseGroupPhraseDlg>(); }
        }

        public static SelectProductionCentersWebpageDialogDlg SelectProductionCentersWebpageDialogDlg
        {
            get { return FastDriver.GetPage<SelectProductionCentersWebpageDialogDlg>(); }
        }

        public static SpecialInstructionsSetup SpecialInstructionsSetup
        {
            get { return FastDriver.GetPage<SpecialInstructionsSetup>(); }
        }

        public static StateFilterSelectionDlg StateFilterSelectionDlg
        {
            get { return FastDriver.GetPage<StateFilterSelectionDlg>(); }
        }

        public static StateLocalInformation StateLocalInformation
        {
            get { return FastDriver.GetPage<StateLocalInformation>(); }
        }

        public static StateSelectionDlg StateSelectionDlg
        {
            get { return FastDriver.GetPage<StateSelectionDlg>(); }
        }

        public static StatusEdit StatusEdit
        {
            get { return FastDriver.GetPage<StatusEdit>(); }
        }

        public static SuccessorSetupDlg SuccessorSetupDlg
        {
            get { return FastDriver.GetPage<SuccessorSetupDlg>(); }
        }

        public static TabFrameBottomDlg TabFrameBottomDlg
        {
            get { return FastDriver.GetPage<TabFrameBottomDlg>(); }
        }

        public static TaskTemplateSelection TaskTemplateSelection
        {
            get { return FastDriver.GetPage<TaskTemplateSelection>(); }
        }

        public static TaskTemplateSelectionDlg TaskTemplateSelectionDlg
        {
            get { return FastDriver.GetPage<TaskTemplateSelectionDlg>(); }
        }

        public static TemplateFilterSelectionDlg TemplateFilterSelectionDlg
        {
            get { return FastDriver.GetPage<TemplateFilterSelectionDlg>(); }
        }

        public static TemplateMaintenanceFiltering TemplateMaintenanceFiltering
        {
            get { return FastDriver.GetPage<TemplateMaintenanceFiltering>(); }
        }

        public static TemplateMaintenanceFormating TemplateMaintenanceFormating
        {
            get { return FastDriver.GetPage<TemplateMaintenanceFormating>(); }
        }

        public static TemplateMaintenanceInformation TemplateMaintenanceInformation
        {
            get { return FastDriver.GetPage<TemplateMaintenanceInformation>(); }
        }

        public static TemplateMaintenancePhrase TemplateMaintenancePhrase
        {
            get { return FastDriver.GetPage<TemplateMaintenancePhrase>(); }
        }

        public static TemplateMaintenanceSummary TemplateMaintenanceSummary
        {
            get { return FastDriver.GetPage<TemplateMaintenanceSummary>(); }
        }

        public static TemplateMaintenanceValidation TemplateMaintenanceValidation
        {
            get { return FastDriver.GetPage<TemplateMaintenanceValidation>(); }
        }

        public static TransactionTypesDlg TransactionTypesDlg
        {
            get { return FastDriver.GetPage<TransactionTypesDlg>(); }
        }

        public static TransferWire TransferWire
        {
            get { return FastDriver.GetPage<TransferWire>(); }
        }


        public static ViewChangeStatus ViewChangeStatus
        {
            get { return FastDriver.GetPage<ViewChangeStatus>(); }
        }

        public static WorkgroupSelectDlg WorkgroupSelectDlg
        {
            get { return FastDriver.GetPage<WorkgroupSelectDlg>(); }
        }

        public static WorkgroupSummary WorkgroupSummary
        {
            get { return FastDriver.GetPage<WorkgroupSummary>(); }
        }

        public static WorkQueueProcessEventSetupDlg WorkQueueProcessEventSetupDlg
        {
            get { return FastDriver.GetPage<WorkQueueProcessEventSetupDlg>(); }
        }

        public static WorkQueueSearchDlg WorkQueueSearchDlg
        {
            get { return FastDriver.GetPage<WorkQueueSearchDlg>(); }
        }

        public static WorkQueueSetup WorkQueueSetup
        {
            get { return FastDriver.GetPage<WorkQueueSetup>(); }
        }

        public static WorkQueueTaskEventSetupDlg WorkQueueTaskEventSetupDlg
        {
            get { return FastDriver.GetPage<WorkQueueTaskEventSetupDlg>(); }
        }

        //public static FASTSelenium.PageObjects.ADM.WorkQueueTop WorkQueueTop
        //{
        //    get { return FastDriver.GetPage<FASTSelenium.PageObjects.ADM.WorkQueueTop>(); }
        //}

        public static WorkQueueUserSearchDlg WorkQueueUserSearchDlg
        {
            get { return FastDriver.GetPage<WorkQueueUserSearchDlg>(); }
        }

        public static BuyerSellerSplitDlg BuyerSellerSplitDlg
        {
            get { return FastDriver.GetPage<BuyerSellerSplitDlg>(); }
        }

        public static TrackChangeHistoryDialog TrackChangeHistoryDialog
        {
            get { return FastDriver.GetPage<TrackChangeHistoryDialog>(); }
        }

        public static TemplateSelectionDlg TemplateSelectionDlg
        {
            get { return FastDriver.GetPage<TemplateSelectionDlg>(); }
        }

        public static DocumentEditor DocumentEditor
        {
            get { return FastDriver.GetPage<DocumentEditor>(); }
        }

        public static ThresholdAmountSetup ThresholdAmountSetup
        {
            get { return FastDriver.GetPage<ThresholdAmountSetup>(); }
        }

        public static RegionalOutgoingWireSummary RegionalOutgoingWireSummary
        {
            get { return FastDriver.GetPage<RegionalOutgoingWireSummary>(); }
        }


        #region SRT-ServReq
        //Team                  :  ServReq-Team1
        //Iteration             :  r08
        //UserStory             :  User Story 815236
        //TestCase              :  830103,830795,838861
        //Appended By/ Created By: Osama

        public static CommentCodeDlg CommentCodeDlg
        {
            get { return FastDriver.GetPage<CommentCodeDlg>(); }
        }

        public static CommentCodes CommentCodes
        {
            get { return FastDriver.GetPage<CommentCodes>(); }
        }
        //end
        #endregion
        #endregion

        #region Common Page Objects

        public static StatusBarFrame StatusBarFrame
        {
            get { return GetPage<StatusBarFrame>(); }
        }
        public static TitleFrame TitleFrame
        {
            get { return GetPage<TitleFrame>(); }
        }

        public static BottomFrame BottomFrame
        {
            get { return GetPage<BottomFrame>(); }
        }

        public static Delivery Delivery
        {
            get { return GetPage<Delivery>();  }
        }

        public static PDFDocument PDFDocument
        {
            get { return GetPage<PDFDocument>(); }
        }

        public static DialogBottomFrame DialogBottomFrame
        {
            get { return FastDriver.GetPage<DialogBottomFrame>(); }
        }

        public static HomePage HomePage
        {
            get { return FastDriver.GetPage<HomePage>(); }
        }

        public static LeftNavigation LeftNavigation
        {
            get { return FastDriver.GetPage<LeftNavigation>(); }
        }

        public static LoginScreen LoginScreen
        {
            get { return FastDriver.GetPage<LoginScreen>(); }
        }

        public static BottomLinks BottomLinks
        {
            get { return GetPage<BottomLinks>(); }
        }

        public static FASTSelenium.PageObjects.SecuritySelectRegionOffice SecuritySelectRegionOffice
        {
            get { return GetPage<FASTSelenium.PageObjects.SecuritySelectRegionOffice>(); }
        }

        public static FastErrorMessageList FastErrorMessageList
        {
            get { return GetPage<FastErrorMessageList>(); }
        }

        public static DialogTitleBar DialogTitleBar
        {
            get { return GetPage<DialogTitleBar>(); }
        }


        #endregion

        #region SRT-ServReq
        //Team                           :  SRT-Team2
        //Iteration                      :  r08
        //Appended By/ Created By        :  Diego Hilario

        public static BeneficiaryNoteDetailsDlg BeneficiaryNoteDetailsDlg
        {
            get { return FastDriver.GetPage<BeneficiaryNoteDetailsDlg>(); }
        }
        #endregion





      
        /// <summary>Creates a given order using WCF and reflects the action in the test report.</summary>
        /// <param name="fileRequest">The order creation request to be sent to WCF.</param>
        public static string FACreateFileFromWCF(CreateFileRequest fileRequest = null)
        {
            return Report.UpdateLog<string>(WebDriver, "Create order using WCF", "", () =>
            {
                var fileCreated = FileService.CreateFile(fileRequest);
                if (fileCreated.OperationResponse.Status == -1)
                    throw new Exception("Error creating file using WCF: " + fileCreated.OperationResponse.StatusDescription);
                try
                {
                    Reports.StatusUpdate("Using form type " + AutoConfig.FormType, true);
                    Reports.StatusUpdate("File ID: " + fileCreated.FileID.Value, true);
                    return FileService.GetOrderDetails((int)fileCreated.FileID).FileNumber;
                }
                catch (Exception)
                {
                    throw new Exception("Error getting file information");
                }
            });
        }

        public static int FACreateFileGetFileId(CreateFileRequest fileRequest = null)
        {
            return Report.UpdateLog<int>(WebDriver, "Create order using WCF", "", () =>
            {
                var fileCreated = FileService.CreateFile(fileRequest);
                if (fileCreated.OperationResponse.Status != -1)
                {
                    Reports.StatusUpdate("Using form type " + AutoConfig.FormType, true);
                    Reports.StatusUpdate("File ID: " + fileCreated.FileID.Value, true);
                    return (int)fileCreated.FileID;
                }
                else
                    throw new Exception("Error creating file using WCF. Details: " + fileCreated.OperationResponse.StatusDescription);
            });
        }
    }
}
