﻿using FASTWCFHelpers.DataObjects;
using System;

namespace FASTSelenium.Common
{
    public interface ICDUrlBuilder
    {
        string Generate(Uri Host, FileInformation File);

    }
}