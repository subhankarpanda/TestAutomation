﻿using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Diagnostics;
using System.IO;
using System.Net;

namespace FASTSelenium.Common
{
    public static class IOHelper
    {
        public static void CreateDirectory(string DirectoryName)
        {
            if (!Directory.Exists(DirectoryName))
            {
                Directory.CreateDirectory(DirectoryName);
            }
        }

        public static byte[] ConvertFileToByteArray(string documentPath)
        {
            if (File.Exists(documentPath))
            {
                Reports.StatusUpdate("Converting file to byte array", true);
                return File.ReadAllBytes(documentPath);
            }
            else
            {
                throw new IOException("File not exists!");
            }

        }

        public static OperationStatus DownloadFile(string URL, string directory, string fileName)
        {
            try
            {
                CreateDirectory(directory);
                var client = new WebClient();
                client.DownloadFile(URL, string.Format("{0}{1}{2}", directory, directory.EndsWith(@"\") ? "" : @"\", fileName));
                return OperationStatus.Success;
            }
            catch (Exception)
            {
                return OperationStatus.Fail;
            }
        }

        public static void Run(string filePath)
        {
            var runFile = new Process();
            runFile.StartInfo.FileName = filePath;
            runFile.StartInfo.CreateNoWindow = false;
            runFile.StartInfo.UseShellExecute = true;
            runFile.Start();
        }

        public static void DeleteDirectory(string directoryName)
        {
            if (!Directory.Exists(directoryName))
            {
                Directory.Delete(directoryName, true);
            }
        }

        public static OperationStatus WriteText(string textToWrite, string path)
        {
            try
            {
                File.WriteAllText(string.Format(@"{0}\Debug.txt", path), textToWrite);
                return OperationStatus.Success;
            }
            catch (Exception)
            {

                return OperationStatus.Fail;
            }

        }

        public static string ReadFile(string filePath)
        {
            string returnValue = "";
            if (File.Exists(filePath))
            {
                returnValue = File.ReadAllText(filePath);
            }
            return returnValue;
        }
    }
}
