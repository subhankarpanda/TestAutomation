﻿using System;
using FASTWCFHelpers.DataObjects;

namespace FASTSelenium.Common
{
    public class LegacyUrlBuilder : ICDUrlBuilder
    {
        string tokenPath = "FASTLink/CD/ClosingDisclosureGUI?FQID=HM_OE_CL_CDC&CFID=7160466,--FileId--,IMD2503F31,7158988&CBUID=--RegionId--,--OfficeId--,1,--RegionId--,--OfficeId--,0";

        public string Generate(Uri Host, FileInformation File)
        {
            {
                var path = tokenPath.Replace("--FileId--", File.FileNumber).Replace("--OfficeId--", File.OfficeID.ToString()).Replace("--RegionId--", File.RegionID.ToString());

                return Host.ToString() + path;
            }
        }
    }
}
