﻿using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Diagnostics;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.TestManagement.Client;
using SeleniumInternalHelpers;
using System.Net;

namespace FASTSelenium.Common
{
    [CodedUITest]
    [DeploymentItem(@"Common\Utilities\AutoItX3.dll")]
    [DeploymentItem(@"Common\Utilities\Microsoft.TeamFoundation.Client.dll")]
    public abstract class MasterTestClass
    {
        public static void FailTest(string errorMessage)
        {
            Support.Fail(errorMessage);
            if (FastDriver.WebDriver != null)
                FastDriver.WebDriver.Quit();
            Support.CloseAllProcessStartingWith("AcroRd"); //close all instances of Adobe Reader
        }

        [TestInitialize]
        public virtual void TestInitialize()
        {
            //Use 0 for off, 1 for error, 2 for warn, 3 for info, and 4 for verbose
            //Playback.PlaybackSettings.LoggerOverrideState = "4";

            if (Support.TESTENVIRONMENT == "")
                GetTestSettingsName(TestContext);
            Reports.InitTest(TestContext);

            try
            {
                AutoConfig.Initialize(); //initialize AutoConfig class
            }
            catch (Exception ex)
            {
                FailTest(ex.Message); //stop test execution if there's a bad config selected
            }

            PageObjectFactory.DefaultWaitTime = AutoConfig.WaitTime;
            Support.bStartReporting = true;
            Support.OverallErrorMessage = "";
            PerformRequiredRegistrySettings();

            CreateTestReportLink(); // create and attached a link to actual result on test agent
            TestContext.AddResultFile(Reports.DEPLOYDIR + "\\TestResult.html");
        }

        [TestCleanup]
        public virtual void CleanupTest()
        {
            Reports.UpdateResult(TestContext);
            if (FastDriver.WebDriver != null)
                FastDriver.WebDriver.Quit();
            Support.CloseAllProcessStartingWith("AcroRd"); //close all instances of Adobe Reader
        }

        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;

        #region Registry Settings

        public static void PerformRequiredRegistrySettings()
        {
            // We need to set this Protected Mode for IE before launching it.
            try
            {
                //Set compatibility mode = off for all sites
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\BrowserEmulation", "AllSitesCompatibilityMode", 0);

                // Set value of "Enabled Protected Mode" to disabled for all Zones
                string keyName = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\";
                for (int zone = 1; zone <= 4; zone++)
                {
                    Registry.SetValue(keyName + zone, "2500", 1); // 0 = enabled; 1 = disabled
                    //Allow websites to open windows without address or status bars
                    Registry.SetValue(keyName + zone, "2104", 1); // 0 = enabled; 1 = disabled
                }

                // Allow Programatic clipboard access (in Trusted Sites zone only) - to avoid dealing with Silverlight clipboard access popup
                // For more details.. https://support.microsoft.com/en-us/kb/182569
                Registry.SetValue(keyName + 2, "1407", 0); // 0 = enabled; 1 = prompt, 2 = disabled

                // Set IE zoom level to 100%
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Zoom", "ZoomFactor", 100000);

                // Disable script debugger and script error notification
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main", "DisableScriptDebuggerIE", "yes");              //string value “yes” or “no”
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main", "Disable Script Debugger", "yes");
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main", "Error Dlg Displayed On Every Error", "no");       //string value “yes” or “no”

                // Turn off pop-up blocker
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\New Windows", "PopupMgr", 0);

                // Add current test URLs (both IIS and ADM) to trusted site
                keyName = @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\";
                var uri = new Uri(AutoConfig.FASTHomeURL);
                Registry.SetValue(keyName + uri.Host, uri.Scheme, 2);
                uri = new Uri(AutoConfig.FASTAdmURL);
                Registry.SetValue(keyName + uri.Host, uri.Scheme, 2);

                ToggleDisplayPDFinBrowser(false); //Turn off 'Display PDF in brower' for Adobe Arobat Reader X and XI

                // Set PDFCreator default tray setting
                //Registry.SetValue(@"HKEY_CURRENT_USER\Software\SMS\PrintManager\1487\731\PDFCreator", "BinName", "Printer auto select");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error modifying IE's settings; " + ex.Message);
            }

            // Disable Windows Error Reporting.
            try
            {
                Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\Windows Error Reporting", "ForceQueue", 1);
                Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\Windows Error Reporting\Consent", "DefaultConsent", 1);
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\Windows Error Reporting", "DontShowUI", 1);
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\Windows Error Reporting", "Disabled", 1);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Unable to disable Windows Error Reporting; " + ex.Message);
            }
        }

        #region Acrobat Reader configurations
        public static void SetDisplayPDFinBrowser_ON()
        {
            SetDisplayPDFinBrowerSetting(true);
        }

        public static void SetDisplayPDFinBrowser_OFF()
        {
            SetDisplayPDFinBrowerSetting(false);
        }

        private static void SetDisplayPDFinBrowerSetting(bool set1)
        {
            if (Registry.GetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserIntegration", null) != null)
            {
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserIntegration", set1 ? "1" : "0", RegistryValueKind.DWord);
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bAllowByteRangeRequests", set1 ? "1" : "0", RegistryValueKind.DWord);
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserDisplayInReadMode", set1 ? "1" : "0", RegistryValueKind.DWord);
            }

            if (Registry.GetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserIntegration", null) != null)
            {
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserIntegration", set1 ? "1" : "0", RegistryValueKind.DWord);
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bAllowByteRangeRequests", set1 ? "1" : "0", RegistryValueKind.DWord);
                Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserDisplayInReadMode", set1 ? "1" : "0", RegistryValueKind.DWord);
            }
        }
                
        private static void SetAdobeAccessibilityReadMode()
        {
            SetAdobeRegistry("Accessibility", "bCheckReadMode", "1");
        }

        private static void UnsetAdobeAccessibilityReadMode()
        {
            SetAdobeRegistry("Accessibility", "bCheckReadMode", "0");
        }

        private static void SetAdobeAccessibilityWizard()
        {
            SetAdobeRegistry("Accessibility", "iWizardRun", "1");
        }

        private static void UnsetAdobeAccessibilityWizard()
        {
            SetAdobeRegistry("Accessibility", "iWizardRun", "0");
        }

        public static void TurnOffAcrobatReaderAccessibilityWizard()
        {
            SetAdobeAccessibilityReadMode();
            SetAdobeAccessibilityWizard();
        }

        private static void SetAdobeSDIMaximizeNextDoc()
        {
            SetAdobeRegistry("SDI", "bMaximizeNextDocument", "1");
        }

        private static void UnsetAdobeSDIMaximizeNextDoc()
        {
            SetAdobeRegistry("SDI", "bMaximizeNextDocument", "0");
        }

        private static void SetAdobeSDINullDocMaximized()
        {
            SetAdobeRegistry("SDI", "bNullDocMaximized", "1");
        }

        private static void UnsetAdobeSDINullDocMaximized()
        {
            SetAdobeRegistry("SDI", "bNullDocMaximized", "0");
        }

        public static void AcrobatReaberStartMaximized()
        {
            SetAdobeSDIMaximizeNextDoc();
            SetAdobeSDINullDocMaximized();
        }

        private static void SetAdobeRenderingAntialiasGraphics()
        {
            SetAdobeRegistry("Originals", "bAntialiasGraphics", "1");
        }

        private static void UnsetAdobeRenderingAntialiasGraphics()
        {
            SetAdobeRegistry("Originals", "bAntialiasGraphics", "0");
        }

        private static void SetAdobeRenderingAntialiasImages()
        {
            SetAdobeRegistry("Originals", "bAntialiasImages", "1");
        }

        private static void UnsetAdobeRenderingAntialiasImages()
        {
            SetAdobeRegistry("Originals", "bAntialiasImages", "0");
        }

        private static void SetAdobeRenderingAntialiasText()
        {
            SetAdobeRegistry("Originals", "bAntialiasText", "1");
        }

        private static void UnsetAdobeRenderingAntialiasText()
        {
            SetAdobeRegistry("Originals", "bAntialiasText", "0");
        }

        public static void SetAdobeRenderingNoSmoothing()
        {
            UnsetAdobeRenderingAntialiasText();
            UnsetAdobeRenderingAntialiasImages();
            UnsetAdobeRenderingAntialiasGraphics();
        }

        public static void SetAdobeDefaultZoom100()
        {
            SetAdobeRegistry("Originals", "iDefaultZoomScale", "65536");
            SetAdobeRegistry("Originals", "iDefaultZoomType", "0");
        }

        private static void SetAdobeRegistry(string type, string key, string value)
        {
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\" + type.ToUpperFirst(), key, value, RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\" + type.ToUpperFirst(), key, value, RegistryValueKind.DWord);
        }
        #endregion

        public static void SetSilverlightClipboardPermission_YES()
        {
            SetSilverlightClipboardPermission(true);
        }

        public static void SetSilverlightClipboardPermission_NO()
        {
            SetSilverlightClipboardPermission(false);
        }

        private static void SetSilverlightClipboardPermission(bool set17)
        {
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\AppDataLow\Software\Microsoft\Silverlight\Permissions\" + AutoConfig.FASTHomeURL.Replace("/smsfast", ":80").ToLowerInvariant(), "Clipboard", set17 ? "17" : "0", RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\AppDataLow\Software\Microsoft\Silverlight\Permissions\" + AutoConfig.FASTAdmURL.Replace("/smsfast", ":80").ToLowerInvariant(), "Clipboard", set17 ? "17" : "0", RegistryValueKind.DWord);
        }

        #endregion

        [ClassCleanup]
        public static void CleanupClass()
        {
            Process.Start("taskkill", "/F /IM IEDriverServer.exe");
        }

        public static string GetExceptionInfo(Exception ex, int maxLevel = 3)
        {
            try
            {
                var stackTrace = new StackTrace(ex, true);
                string message = "";
                int index = 1;

                for (int i = stackTrace.FrameCount - 1; i > 0 && i >= (stackTrace.FrameCount - maxLevel); i--)
                {
                    var frame = stackTrace.GetFrame(i);
                    if (frame == null || frame.GetFileName() == null)
                        continue;
                    var _fileInfo = new System.IO.FileInfo(frame.GetFileName());
                    message += string.Format("\n{0} File: {1}\n{2} Line: {3}", index, _fileInfo.Name, index, frame.GetFileLineNumber());
                    if (maxLevel == index || i == 0)
                        message += string.Format("\nMessage: {0}", ex.Message);
                    index++;
                }

                return message;
            }
            catch(Exception ex2)
            {
                return GetExceptionInfo(ex2);
            }
        }

        private static void GetTestSettingsName(TestContext tcontext)
        {
            try
            {
                if (tcontext.Properties["__Tfs_TestRunId__"] != null)
                {
                    var tfsUri = tcontext.Properties["__Tfs_TfsServerCollectionUrl__"].ToString();      // http://tfs.corp.firstam.com:8080/tfs/defaultcollection 
                    var teamProject = tcontext.Properties["__Tfs_TeamProject__"].ToString();            // AT_FAST
                    var testRunId = (int)tcontext.Properties["__Tfs_TestRunId__"];

                    using (TfsTeamProjectCollection teamProjectCollection = new TfsTeamProjectCollection(new Uri(tfsUri)))
                    {
                        ITestManagementService testManagementService = (ITestManagementService)teamProjectCollection.GetService(typeof(ITestManagementService));
                        ITestManagementTeamProject testManagementTeamProject = testManagementService.GetTeamProject(teamProject);

                        ITestRunBase testRunBase = testManagementTeamProject.TestRuns.Find(testRunId);
                        var testSettings = testRunBase.TestSettings;
                        tcontext.Properties.Add("__Tfs_TestSettings__", testSettings);

                        if (testSettings != null)
                            Support.TESTENVIRONMENT = testSettings.Name;

                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error getting TestSettings' name from MTM.", ex);
            }
        }

        private static void CreateTestReportLink()
        {
            string resultFilePath = Reports.DEBUGLOG;
            string testAgentName = Dns.GetHostName();   // get only host name portion of the test agent

            if (Reports.IsMTMExecutions)
                resultFilePath = resultFilePath.Replace("C:", @"\\" + testAgentName);

            string linkToReportFileContent = "<!DOCTYPE HTML><html lang=\"en-US\"><head><meta charset=\"UTF-8\">" +
                                             "<meta http-equiv=\"refresh\" content=\"1;url=" + resultFilePath + "\">" +
                                             "<script type=\"text/javascript\">window.location.href = \"" + resultFilePath + "\"</script>" +
                                             "<title>Test Result</title></head><body>" +
                                             "If you are not redirected automatically, please follow the link:<br>" +
                                             "<a href='" + resultFilePath + "'>" + resultFilePath + "</a></body></html>";

            System.IO.File.WriteAllText(Reports.DEPLOYDIR + "\\TestResult.html", linkToReportFileContent);
            System.IO.File.WriteAllText(Reports.RUNRESULTDIR + "\\_TestSummary.html", linkToReportFileContent.Replace(resultFilePath, Reports.SummaryLogFile));
        }
        
        /// <summary>
        /// Toggles whether PDF will be shown in-browser or by opening an instance of Adobe Reader
        /// </summary>
        /// <param name="toggle">true: ON; false: OFF</param>
        public static void ToggleDisplayPDFinBrowser(bool toggle)
        {
            string value = toggle ? "1" : "0";

            //Toggle 'Display PDF in brower' for Adobe Arobat Reader X
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserIntegration", value, RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bAllowByteRangeRequests", value, RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\10.0\Originals", "bBrowserDisplayInReadMode", value, RegistryValueKind.DWord);

            //Toggle 'Display PDF in brower' for Adobe Arobat Reader XI
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserIntegration", value, RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bAllowByteRangeRequests", value, RegistryValueKind.DWord);
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\Adobe\Acrobat Reader\11.0\Originals", "bBrowserDisplayInReadMode", value, RegistryValueKind.DWord);
        }
    }
}
