﻿using AutoIt;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Text;
using System.Windows.Input;

namespace FASTSelenium.Common
{
    public static class PDFHelper
    {
        #region Methods
        public static int GetPdfPageCount(string PDFPath)
        {
            PdfReader pdfReader = new PdfReader(PDFPath);
            return pdfReader.NumberOfPages;
        }

        public static string ReadSSPDF(string PDFFileWithPath, string searchString, string columnName, bool combined = true, bool CD = true)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            string result = string.Empty;
            string text = string.Empty;
            
            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                text = text + PdfTextExtractor.GetTextFromPage(reader, i);
            }

            try
            {
                if (combined)
                {
                    if (columnName == "BuyerDebit" || columnName == "BuyerCredit" || columnName == "BuyerCharge")
                    {
                        int first = text.IndexOf(searchString) + searchString.Length;
                        int last = 0;
                        string str2 = "";

                        if (CD)
                        {
                            last = text.IndexOf("\n", first);
                            str2 = text.Substring(first, last - first).Trim();
                        }
                        else
                        {
                            last = text.LastIndexOf("\n", first);
                            str2 = text.Substring(last, (first - searchString.Length) - last).Trim();
                        }

                        char[] delimiterChar = { ' ' };

                        if (str2.Split(delimiterChar).Length == 1)
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "BuyerDebit" || columnName == "BuyerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "BuyerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else
                            result = "";
                    }
                    else if (columnName == "SellerDebit" || columnName == "SellerCredit" || columnName == "SellerCharge")
                    {
                        int first = text.IndexOf(searchString);
                        int last = 0;
                        string str2 = "";

                        if (CD)
                        {
                            if (searchString == "Due To Seller") //Special case 'Due To Seller' doesn't display charge correctly
                            {
                                searchString = "Due To Seller \n";
                                first = text.IndexOf(searchString);
                                last = text.IndexOf("\n", first + searchString.Length);
                                str2 = text.Substring(first + searchString.Length, last - (first + searchString.Length)).Trim();
                                if (str2 == "")
                                {
                                    searchString = "Due To Seller";
                                    first = text.IndexOf(searchString);
                                    last = text.LastIndexOf("\n", first);
                                    str2 = text.Substring(last, first - last).Trim();
                                }
                            }
                            else
                            {
                                last = text.LastIndexOf("\n", first);
                                str2 = text.Substring(last, first - last).Trim();
                            }
                        }
                        else
                        {
                            last = text.IndexOf("\n", first);
                            str2 = text.Substring(first + searchString.Length, last - (first + searchString.Length)).Trim();
                        }

                        char[] delimiterChar = { ' ' };

                        if (str2.Split(delimiterChar).Length == 1)
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "SellerDebit" || columnName == "SellerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "SellerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else
                            result = "";
                    }
                    else
                        result = "";
                }
                else
                {
                    if (columnName == "BuyerDebit" || columnName == "BuyerCharge" || columnName == "BuyerCredit" || columnName == "SellerDebit" || columnName == "SellerCredit" || columnName == "SellerCharge")
                    {
                        int first = text.IndexOf(searchString) + searchString.Length;
                        int last = text.IndexOf("\n", first);
                        string str2 = text.Substring(first, last - first).Trim();
                        char[] delimiterChar = { ' ' };

                        if (str2.Split(delimiterChar).Length == 1)
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "BuyerDebit" || columnName == "BuyerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "BuyerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && (columnName == "SellerDebit" || columnName == "SellerCharge"))
                        {
                            result = str2.Split(delimiterChar)[0];
                        }
                        else if (str2.Split(delimiterChar).Length > 1 && columnName == "SellerCredit")
                        {
                            result = str2.Split(delimiterChar)[1];
                        }
                        else
                            result = "";
                    }
                }
            }
            catch(Exception e)
            {
                result = "No match found! " + e.Message;
            }

            return result;
        }

        public static string ReadPdfFile(string PDFFileWithPath)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            string text = string.Empty;

            for (int i = 1; i <= reader.NumberOfPages; i++)
            {
                text = text + PdfTextExtractor.GetTextFromPage(reader, i);
            }

            reader.Close();
            return text;
        }

        public static string ReadPdfPageSize(string PDFFileWithPath)
        {
            PdfReader reader = new PdfReader(PDFFileWithPath);
            int pageNmbr = 1;
            iTextSharp.text.Rectangle pagesize = reader.GetPageSize(pageNmbr);

            reader.Close();
            return pagesize.ToString();
        }

        public static string SavePDFFile(string pdfName = null,bool isSimplePDFViewer = false)
        {
            string savePath = @"C:\Reports\" + DateTime.Today.ToString("MMMddyyyy");
            IOHelper.CreateDirectory(savePath);
            string tempPdfFile = savePath + "\\" + (pdfName ?? "temp") + "_" + DateTime.Now.ToString("hh-mm") + ".pdf";

            try
            {
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Playback.Wait(10000); //To give Adobe a little bit time to load
                if (isSimplePDFViewer)
                {
                    AutoItX.Send("^+S", 0);
                }
                else
                { 
                    AutoItX.Send("!fap", 0);
                }
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                AutoItX.WinWait("Save As", "", 20); //Switch to Browser Window
                AutoItX.WinActivate("Save As");

                Report.UpdateLog(FastDriver.WebDriver, "PDF path", tempPdfFile, () =>
                {
                    AutoItX.ControlSetText("Save As", "", "[CLASS:Edit;INSTANCE:1]", tempPdfFile);
                });
                Playback.Wait(10000);                                                   //Increasing wait time to avoid inconsistancy
                Report.UpdateLog(FastDriver.WebDriver, "Button", "Save", () =>
                {
                    AutoItX.ControlEnable("Save As", "", "[CLASS:Button;Text:&Save]");
                    Playback.Wait(10000);
                    AutoItX.ControlClick("Save As", "", "[CLASS:Button;Text:&Save]");
                });
                Playback.Wait(7000);
                if (isSimplePDFViewer)
                    AutoItX.Send("!+{F4}");
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }
            catch (Exception e)
            {
                Reports.StatusUpdate(String.Format("Error: {0}", e.Message), false);
            }
            return tempPdfFile;
        }

        public static string SavePDF(string fileName)
        {
            string savePath = @"C:\Reports\PDF_Delivery";
            IOHelper.CreateDirectory(savePath);
            string pdfFilePath = savePath + @"\" + fileName + "_" + Support.RandomString("NAN");
            Playback.Wait(5000);
            AutoItX.Send("^+S", 0);
            AutoItX.WinWait("Save As", "", 20);
            AutoItX.WinActivate("Save As");
            AutoItX.ControlSend("Save As", "", "[CLASS:Edit;INSTANCE:1]", pdfFilePath + "{ENTER}");
            Playback.Wait(3000);
            AutoItX.ControlEnable("Save As", "", "[CLASS:Button;Text:&Save]");
            AutoItX.ControlClick("Save As", "", "[CLASS:Button;Text:&Save]");
            return pdfFilePath + ".pdf";
        }

        public static void DebugPDF(string fileName)
        {
            var pdfReader = new PdfReader(fileName);
            StringBuilder text = new StringBuilder();
            for (int i = 1; i <= pdfReader.NumberOfPages; i++)
            {
                text.Append(PdfTextExtractor.GetTextFromPage(pdfReader, i));
            }
            IOHelper.CreateDirectory(@"C:\Reports\PDF_Delivery");
            IOHelper.WriteText(text.ToString(), @"C:\Reports\PDF_Delivery");
        }

        #endregion
    }
}
