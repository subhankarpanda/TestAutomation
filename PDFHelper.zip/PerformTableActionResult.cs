﻿
using OpenQA.Selenium;
namespace FASTSelenium.Common
{
    public struct OperationResult
    {
        public OperationStatus Status;
        public IWebElement Element;
        public string Message;
        public int CurrentRow;
    }
}
