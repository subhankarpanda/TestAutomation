﻿using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium;
using System;

namespace FASTSelenium.Common
{
    /// <summary>
    /// DO NOT TOUCH THIS CODE WITHOUT AUTHORIZATION. 
    /// EVERY TEST STEP GOES TROUGHT THESE METHODS, BREAKING THESE MEANS BREAKING EVERYTHING.
    /// </summary>
    public class Report
    {
        public static void UpdateLog(IWebElement element, string method, string property, string value, Action action)
        {
            Support.ctrlstartTime = DateTime.Now;
            //DO NOT GET ELEMENT ATTRIBUTES WITHOUT USING TRY CATCH
            var elementDesc = element.Describe();
            var elementTagName = element.FATagName();

            try
            {
                action();
                Reports.UpdateDebugLog(elementDesc, elementTagName, method, property, value, "", Reports.Result(true), "");
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(elementDesc, elementTagName, method, property, value, "", Reports.Result(false), e.Message);
                throw e;
            }
        }

        public static void UpdateLog(IWebElement fromElement, IWebElement toElement, string method, string property, string value, Action action)
        {
            Support.ctrlstartTime = DateTime.Now;
            //DO NOT GET ELEMENT ATTRIBUTES WITHOUT USING TRY CATCH
            var fromElementDesc = fromElement.Describe();
            var fromElementTagName = fromElement.FATagName();

            //DO NOT GET ELEMENT ATTRIBUTES WITHOUT USING TRY CATCH
            var toElementDesc = toElement.Describe();
            var toElementTagName = toElement.FATagName();

            try
            {
                action();
                Reports.UpdateDebugLog("Drag from: " + fromElementDesc + " To: " + toElementDesc, "From: " + fromElementTagName + " To: " + toElementTagName, method, property, value, "", Reports.Result(true), "");
            }
            //Never ever catch all exceptions
            //To Do: figure out a way to report without catch all exceptions
            //Jorge: We just catch it to report the action failed, but then we throw it.. (A better way to do this would be more than welcome though!)
            catch (Exception e)
            {
                Reports.UpdateDebugLog("Drag from: " + fromElementDesc + " To: " + toElementDesc, "From: " + fromElementTagName + " To: " + toElementTagName, method, property, value, "", Reports.Result(true), "");
                throw e;
            }
        }

        public static T UpdateLog<T>(IWebElement element, string method, string property, string value, Func<T> func)
        {
            Support.ctrlstartTime = DateTime.Now;
            //DO NOT GET ELEMENT ATTRIBUTES WITHOUT USING TRY CATCH
            var elementDesc = element.Describe();
            var elementTagName = element.FATagName();

            try
            {
                var ret = func.Invoke();
                Reports.UpdateDebugLog(elementDesc, elementTagName, method, property, value, (ret is string) ? ret.ToString() : "", Reports.Result(true), "");
                return ret;
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(elementDesc, elementTagName, method, property, value, "", Reports.Result(false), e.Message);
                throw;
            }
        }

        public static void UpdateLog(IWebDriver driver, string actionName, string value, Action action)
        {
            Support.ctrlstartTime = DateTime.Now;
            var driverDesc = driver.Describe();

            try
            {
                action.Invoke();
                Reports.UpdateDebugLog(driverDesc, "Driver", actionName, "", value, "", Reports.Result(true), "");
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(driverDesc, "Driver", actionName, "", value, "", Reports.Result(false), e.Message);
                throw e;
            }
        }

        public static T UpdateLog<T>(IWebDriver driver, string actionName, string value, Func<T> func)
        {
            Support.ctrlstartTime = DateTime.Now;
            var driverDesc = driver.Describe();

            try
            {
                var ret = func.Invoke();
                Reports.UpdateDebugLog(driverDesc, "Driver", actionName, "", value, (ret is string) ? ret.ToString() : "", Reports.Result(true), "");
                return ret;
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(driverDesc, "Driver", actionName, "", value, "", Reports.Result(false), e.Message);
                throw e;
            }
        }
    }
}
