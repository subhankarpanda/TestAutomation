using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ADMProgramTypesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClearAll")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_0_chkSelPgm")]
		public IWebElement SelectProgramName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_dgridPrograms")]
		public IWebElement ProgramNameTable { get; set; }

		#endregion

	}
}
