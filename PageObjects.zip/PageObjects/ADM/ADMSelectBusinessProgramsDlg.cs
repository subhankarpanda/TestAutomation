using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class ADMSelectBusinessProgramsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSelBP_0_chkSelBP")]
		public IWebElement BusinessProgramNames { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
		public IWebElement BusinessProgrammeTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
		public IWebElement BusinessProgramTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_0_chkSelBP")]
		public IWebElement dgridSelBP0SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_1_chkSelBP")]
		public IWebElement dgridSelBP1SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_2_chkSelBP")]
		public IWebElement dgridSelBP2SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_3_chkSelBP")]
		public IWebElement dgridSelBP3SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_4_chkSelBP")]
		public IWebElement dgridSelBP4SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_5_chkSelBP")]
		public IWebElement dgridSelBP5SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_6_chkSelBP")]
		public IWebElement dgridSelBP6SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_7_chkSelBP")]
		public IWebElement dgridSelBP7SelBP { get; set; }

		#endregion

        public ADMSelectBusinessProgramsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? BusinessProgrammeTable);
            return this;
        }

        public string ToggleBusinessProgram(bool selectBusName = true)
        {
            for (int i = 1; i < BusinessProgramTable.GetRowCount(); i++)
            {
                if (selectBusName)
                {
                    if (!BusinessProgramTable.PerformTableAction(i, 1, TableAction.GetElementFromTableCell, "input").Element.Selected)
                    {
                        BusinessProgramTable.PerformTableAction(i, 1, TableAction.On);
                        return BusinessProgramTable.PerformTableAction(i, 2, TableAction.GetElementFromTableCell, "span").Element.FAGetText();
                    }
                }
                else
                {
                    if (BusinessProgramTable.PerformTableAction(i, 1, TableAction.GetElementFromTableCell, "input").Element.Selected)
                    {
                        BusinessProgramTable.PerformTableAction(i, 1, TableAction.Off);
                        return BusinessProgramTable.PerformTableAction(i, 2, TableAction.GetElementFromTableCell, "span").Element.FAGetText();
                    }
                }
            }
            return "";
        }

        public void VerifyTableOrder()
        {
            List<string> sortedList = new List<string>();
            List<string> tempList = new List<string>();
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                sortedList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(1).FAGetText());
            }

            //Sorting the List
            sortedList.Sort();

            //System list
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                tempList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(1).FAGetText());
            }

            //Verify whether the elements are sorted
            for (int i = 0; i < sortedList.Count; i++)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(sortedList.ElementAt(i), tempList.ElementAt(i));
            }

        }

    }
}
