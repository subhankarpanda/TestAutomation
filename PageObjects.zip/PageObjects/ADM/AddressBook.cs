﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System;
using FASTSelenium.DataObjects.ADM;
using System.ComponentModel;

namespace FASTSelenium.PageObjects.ADM
{
    public class AddressBookSearch : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkActiveOnly")]
        public IWebElement SearchActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "btnClearSearchFlds")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnFind")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewEntry")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "typetable")]
        public IWebElement EntityType { get; set; }

        [FindsBy(How = How.Id, Using = "txtEntityName")]
        public IWebElement EntityName { get; set; }

        [FindsBy(How = How.Id, Using = "lblEntityName")]
        public IWebElement EntityNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "txtEntityID")]
        public IWebElement EntityID { get; set; }

        [FindsBy(How = How.Id, Using = "txtCiy")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "txtCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "selState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "txtContfirstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "radioAddrType_0")]
        public IWebElement MailingAddress { get; set; }

        [FindsBy(How = How.Id, Using = "radioAddrType_1")]
        public IWebElement BusinessAddress { get; set; }

        [FindsBy(How = How.Id, Using = "btnStatus")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddToGAB")]
        public IWebElement AddToGAB { get; set; }

        [FindsBy(How = How.Id, Using = "btnGABDetailsHorizantal")]
        public IWebElement GABDetailsHorizontal { get; set; }

        [FindsBy(How = How.Id, Using = "btnGABDetailsVertical")]
        public IWebElement GABDetailsVertical { get; set; }

        [FindsBy(How = How.Id, Using = "btnStatus")]
        public IWebElement OrgDetailsViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "btnCompareContacts")]
        public IWebElement CompareContacts { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSearchResults")]
        public IWebElement SearchResults { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSearchResults_0_lblStatus")]
        public IWebElement ActiveElement { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSearchResults_0_lblEBus")]
        public IWebElement eBusinessIcon { get; set; }

        [FindsBy(How = How.Id, Using = "lblRecordCount")]
        public IWebElement RecordsCount { get; set; }

        #endregion

        public void GetActiveOnlyStatus()
        {
            this.SwitchToContentFrame();
            SearchActiveOnly.FAGetAttribute("Checked");

        }

        [Description("Search Addess Book")]
        public virtual AddressBookSearch SearchAddressBook(string gabID = null, string entityType = null, string entityName = null, string city = null, string county = null, string state = null, string contact1stName = null, string contactLastname = null, bool? activeOnly = null)
        {
            WaitForScreenToLoad();
            EntityID.FASetText(gabID);
            EntityType.FASelectItem(entityType);
            EntityName.FASetText(entityName);
            City.FASetText(city);
            County.FASetText(county);
            State.FASelectItem(state);
            FirstName.FASetText(contact1stName);
            LastName.FASetText(contactLastname);
            SearchActiveOnly.FASetCheckbox(activeOnly);
            Find.FAClick();
            WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            WaitForScreenToLoad(SearchResults);
            return this;
        }

        [Description("Edit Address")]
        public virtual void EditAddress(string data)
        {
            this.SearchResults.PerformTableAction(7, data, 1, TableAction.Click);
            Edit.FAClick();
        }

        [Description("Create new address book entry")]
        public virtual void CreateNewAddressEntry(BusinessOrganizationParameters newBussOrg)
        {
            ClickNew().WaitForScreenToLoad().FillNewBusinessOrganizationForm(newBussOrg);
            FastDriver.BottomFrame.Done();
        }

        [Description("Click on button to create new address")]
        public BusPartyOrgSetUp ClickNew()
        {
            this.SwitchToContentFrame();
            New.Click();
            return FastDriver.BusPartyOrgSetUp;
        }

        [Description("Navigate to Address book search")]
        public AddressBookSearch Open()
        {
            FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book");
            this.WaitForScreenToLoad();
            return this;
        }

        public AddressBookSearch WaitForSearchResultsToLoad()
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(SearchResults);
                return this;
            }
            catch (StaleElementReferenceException)
            {
                System.Threading.Thread.Sleep(1000);

                this.SwitchToContentFrame();
                this.WaitCreation(SearchResults);
                return this;
            }
        }

        public AddressBookSearch WaitForSearchResultsToLoad(int timeout = 5)
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(SearchResults);
                return this;
            }
            catch (StaleElementReferenceException)
            {
                System.Threading.Thread.Sleep(1000);

                this.SwitchToContentFrame();
                this.WaitCreation(SearchResults);
                return this;
            }
        }

        public AddressBookSearch WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? EntityID);
            return this;
        }

        public void EditGAB(string GAB)
        {
            try
            {
                this.Open();
                this.SearchAddressBook(GAB);
                this.EditAddress(GAB);
                FastDriver.BusPartyOrgSetUp.WaitForScreenToLoad();
            }
            catch
            {
                throw;
            }

        }
    }
}
