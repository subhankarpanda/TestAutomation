using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class AdmPrintDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Name, Using = "Select Printer")]
		public IWebElement SelectPrinter { get; set; }

		[FindsBy(How = How.Name, Using = "Number of copies:")]
		public IWebElement Numberofcopies { get; set; }

		[FindsBy(How = How.Name, Using = "Pages:")]
		public IWebElement Radio { get; set; }

		[FindsBy(How = How.Name, Using = "Print")]
		public IWebElement Print { get; set; }

		[FindsBy(How = How.Name, Using = "Cancel")]
		public IWebElement Cancel { get; set; }

		#endregion

	}
}
