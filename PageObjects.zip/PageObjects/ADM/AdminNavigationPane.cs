﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;

namespace FASTSelenium.PageObjects.ADM
{
    public class AdminNavigationPane : PageObject
    {
        [FindsBy(How = How.CssSelector, Using = "#n1>a")]
        public IWebElement Home { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='System Maintenance']>a")]
        public IWebElement SystemMaintenance { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Others']>a")]
        public IWebElement Others { get; set; }

        public AdminNavigationPane LoadHomePage()
        {
            this.SwitchToLeftNavigationPane();
            Home.Click();
            
            return this;
        }

        public SystemMaintenanceNavigation ExpandSystemMaintenanceNavigation()
        {
            this.SwitchToLeftNavigationPane();
            SystemMaintenance.Click();
            
            return FastDriver.GetPage<SystemMaintenanceNavigation>();
        }

        public AdminOthersNavigation LoadOthersNavigation()
        {
            this.SwitchToLeftNavigationPane();
            Others.Click();
            
            return FastDriver.GetPage<AdminOthersNavigation>();
        }
    }
}