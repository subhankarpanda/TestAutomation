﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class AdminOthersNavigation : PageObject
    {
        [FindsBy(How = How.CssSelector, Using = "#n4>a")]
        public IWebElement SelectOffice { get; set; }

        //public SecuritySelectRegionOffice LoadSelectRegionOfficeScreen()
        //{
        //    this.SwitchToLeftNavigationPane();
        //    SelectOffice.Click();
        //    return FastDriver.GetPage<SecuritySelectRegionOffice>();
        //}
    }
}