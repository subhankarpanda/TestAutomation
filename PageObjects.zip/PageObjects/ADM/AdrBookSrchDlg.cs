using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class AdrBookSrchDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNewGABEntry")]
		public IWebElement NewGAB { get; set; }

		[FindsBy(How = How.Id, Using = "cmdModifyGABEntry")]
		public IWebElement ModifyGAB { get; set; }

		[FindsBy(How = How.Id, Using = "cmdClearSearchFlds")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFind")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "comboTypetable")]
		public IWebElement EntityType { get; set; }

		[FindsBy(How = How.Id, Using = "textEntityName")]
		public IWebElement EntityName { get; set; }

		[FindsBy(How = How.Id, Using = "textEntityID")]
		public IWebElement EntityID { get; set; }

		[FindsBy(How = How.Id, Using = "textCiy")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "textCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "textContfirstName")]
		public IWebElement firstName { get; set; }

		[FindsBy(How = How.Id, Using = "textLastName")]
		public IWebElement LastName { get; set; }

		[FindsBy(How = How.Id, Using = "rblAddressType_0")]
		public IWebElement MailingAddress { get; set; }

		[FindsBy(How = How.Id, Using = "rblAddressType_1")]
		public IWebElement BusinessAddress { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdClearAll")]
		public IWebElement ClearAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "dgGAB")]
		public IWebElement SearchResults { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRefresh")]
		public IWebElement Refresh { get; set; }

		#endregion

	}
}
