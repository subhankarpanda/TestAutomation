using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class AssignBusinessPrograms : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnAssign")]
		public IWebElement AssigntoOffices { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_0_labelBPName")]
		public IWebElement BusinessProgram { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_1_labelBPName")]
		public IWebElement BusinessProgram1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_3_labelBPName")]
		public IWebElement BusinessProgram3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_2_labelBPName")]
		public IWebElement BusinessProgram2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_4_labelBPName")]
		public IWebElement BusinessProgram4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
        public IWebElement BusinessProgramTable { get; set; }



		#endregion

        public AssignBusinessPrograms WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AssigntoOffices);
        
            return this;
        }

        public void VerifyTableOrder()
        {
            List<string> sortedList = new List<string>();
            List<string> tempList = new List<string>();
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                sortedList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Sorting the List
            sortedList.Sort();

            //System list
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                tempList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Verify whether the elements are sorted
            for (int i = 0; i < sortedList.Count; i++)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(sortedList.ElementAt(i), tempList.ElementAt(i));
            }

        }

    }
}
