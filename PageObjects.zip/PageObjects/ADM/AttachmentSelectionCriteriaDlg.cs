using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class AttachmentSelectionCriteriaDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnClearAll")]
		public IWebElement ClearAll { get; set; }

		[FindsBy(How = How.Id, Using = "dgDocuments_0_lblDocName")]
		public IWebElement Invoice { get; set; }

		[FindsBy(How = How.Id, Using = "Id dgDocuments_1_lblDocName")]
		public IWebElement AFFIXINV { get; set; }

		[FindsBy(How = How.Id, Using = "Id dgDocuments_2_lblDocName")]
		public IWebElement Row3 { get; set; }

		[FindsBy(How = How.Id, Using = "Id dgDocuments_3_lblDocName")]
		public IWebElement Row4 { get; set; }

		[FindsBy(How = How.LinkText, Using = "AND")]
		public IWebElement AND { get; set; }

		[FindsBy(How = How.LinkText, Using = "OR")]
		public IWebElement OR { get; set; }

		[FindsBy(How = How.Id, Using = "txtCondition")]
		public IWebElement Condition { get; set; }

		#endregion

	}
}
