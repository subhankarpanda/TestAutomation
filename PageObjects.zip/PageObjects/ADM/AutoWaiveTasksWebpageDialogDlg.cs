using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class AutoWaiveTasksWebpageDialogDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "FIUC0001Reg ")]
		public IWebElement FIUC0001Reg { get; set; }

        [FindsBy(How = How.Id, Using = "idGVTableBody")]
        public IWebElement AutoWaiveTasksTable { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Select1 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Select2 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Select3 { get; set; }

		#endregion

        #region Useful Methods
        public AutoWaiveTasksWebpageDialogDlg WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Auto Waive Tasks", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(AutoWaiveTasksTable);
            return this;
        }
        #endregion

    }
}
