using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BankBranchOfficeAccountSummaryDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridBankBranchAccountSummary")]
		public IWebElement BankAccountSummaryTable { get; set; }

        #endregion

        #region Useful Methods
        public BankBranchOfficeAccountSummaryDlg WaitForScreenToLoad()
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();//switchToFraPageWin: true);
            this.WaitCreation(BankAccountSummaryTable);
            return this;
        }
        #endregion
    }
}
