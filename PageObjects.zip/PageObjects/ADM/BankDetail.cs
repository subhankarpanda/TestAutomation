using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BankDetail : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdViewAccount")]
		public IWebElement ViewAccounts { get; set; }

		[FindsBy(How = How.Id, Using = "textFASTBankCode")]
		public IWebElement FASTBankCode { get; set; }

		[FindsBy(How = How.Id, Using = "textSMSBankCode")]
		public IWebElement SMSBankCode { get; set; }

		[FindsBy(How = How.Id, Using = "chkBistroWireInterface")]
		public IWebElement WireInterfaceBank { get; set; }

		[FindsBy(How = How.Id, Using = "textRoutingNumber")]
		public IWebElement RoutingNumber { get; set; }

		[FindsBy(How = How.Id, Using = "textBankBranchNumber")]
		public IWebElement BankBranchNumber { get; set; }

		[FindsBy(How = How.Id, Using = "textName1")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "textName2")]
		public IWebElement Name2 { get; set; }

		[FindsBy(How = How.Id, Using = "textLocDiv")]
		public IWebElement LocDescription { get; set; }

		[FindsBy(How = How.Id, Using = "comboCheckTemplate")]
		public IWebElement CheckTemplate { get; set; }

		[FindsBy(How = How.Id, Using = "chk2part")]
		public IWebElement CheckStock2part { get; set; }

		[FindsBy(How = How.Id, Using = "chk4part")]
		public IWebElement CheckStock4part { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrCopy")]
		public IWebElement Copy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrDelete")]
		public IWebElement Delete { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_cmdAdd")]
		public IWebElement Apply { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboAddressType")]
		public IWebElement AddressType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine1")]
		public IWebElement AddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine2")]
		public IWebElement AddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine3")]
		public IWebElement AddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine4")]
		public IWebElement AddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_cmdAddPhoneType")]
		public IWebElement PhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_cmdDeletePhoneEntry")]
		public IWebElement PhonesDelete { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement BusPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_0_textNumber")]
		public IWebElement BusPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_0_textExtension")]
		public IWebElement BusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_0_textComments")]
		public IWebElement BusPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement BusFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_1_textNumber")]
		public IWebElement BusFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_1_textExtension")]
		public IWebElement BusFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_1_textComments")]
		public IWebElement BusFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement EmailType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_2_textNumber")]
		public IWebElement EmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_2_textComments")]
		public IWebElement EmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement PagerType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_3_textNumber")]
		public IWebElement PagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_3_textExtension")]
		public IWebElement PagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_3_textComments")]
		public IWebElement PagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement CellularType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_4_textNumber")]
		public IWebElement CellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_4_textExtension")]
		public IWebElement CellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_4_textComments")]
		public IWebElement CellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement HomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_5_textNumber")]
		public IWebElement HomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_5_textExtension")]
		public IWebElement HomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_5_textComments")]
		public IWebElement HomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement HomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_6_textNumber")]
		public IWebElement HomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_6_textExtension")]
		public IWebElement HomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlElectronicAddressDetail_dgridPhoneTypes_6_textComments")]
		public IWebElement HomeFaxComments { get; set; }
        
		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Errormessage { get; set; }

		#endregion

        #region Recursive Methods
        public BankDetail WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(FASTBankCode);
            return this;
        }
        #endregion
    }
}
