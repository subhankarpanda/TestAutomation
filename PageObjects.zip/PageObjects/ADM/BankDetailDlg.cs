using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BankDetailDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdViewAccount")]
		public IWebElement ViewAccounts { get; set; }

		[FindsBy(How = How.Id, Using = "textName1")]
		public IWebElement BankName { get; set; }

		[FindsBy(How = How.Id, Using = "textLocDiv")]
		public IWebElement BankLoc { get; set; }

        #endregion


        public BankDetailDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ViewAccounts);
            return this;
        }

	}
}
