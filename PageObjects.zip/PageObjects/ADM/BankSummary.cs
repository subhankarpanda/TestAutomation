using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BankSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBankSummary_10_labelName")]
		public IWebElement AutomationBankelt { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBankSummary_dgridBankSummary")]
		public IWebElement BankSummaryTable { get; set; }

		#endregion

        #region Recursive Methods

        public BankSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New);
            return this;
        }
        #endregion

    }
}
