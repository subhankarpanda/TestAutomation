using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BestMatchSimulator : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNewSession")]
		public IWebElement NewSession { get; set; }

		[FindsBy(How = How.Id, Using = "btnSaveSession")]
		public IWebElement SaveSession { get; set; }

		[FindsBy(How = How.Id, Using = "btnPreviousSession")]
		public IWebElement PreviousSession { get; set; }

		[FindsBy(How = How.Id, Using = "txtRegionBUID")]
		public IWebElement RegionBUID { get; set; }

		[FindsBy(How = How.Id, Using = "txtSSName")]
		public IWebElement SimulatorSessionName { get; set; }

		[FindsBy(How = How.Id, Using = "txtBSSearchName")]
		public IWebElement BusinessSourceSearchName { get; set; }

		[FindsBy(How = How.Id, Using = "btnBSSearch")]
		public IWebElement BusinessSourceSearch { get; set; }

		[FindsBy(How = How.Id, Using = "lblBSID")]
		public IWebElement BusinessSourceIDCode { get; set; }

		[FindsBy(How = How.Id, Using = "lblBSName")]
		public IWebElement BusinessSourceName { get; set; }

		[FindsBy(How = How.Id, Using = "cmbBSAddlRoleType")]
		public IWebElement BusinessSourceAdditionalRoleType { get; set; }

		[FindsBy(How = How.Id, Using = "txtDirBySearchName")]
		public IWebElement DirectedBySearchName { get; set; }

		[FindsBy(How = How.Id, Using = "btnDBSearch")]
		public IWebElement DirectedBySearch { get; set; }

		[FindsBy(How = How.Id, Using = "cmbDirByAddlRoleType")]
		public IWebElement DirectedByAddlRoleType { get; set; }

		[FindsBy(How = How.Id, Using = "txtLenderSearchName")]
		public IWebElement LenderSearchName { get; set; }

		[FindsBy(How = How.Id, Using = "btnLenderSearch")]
		public IWebElement LenderSearch { get; set; }

		[FindsBy(How = How.Id, Using = "cmbService")]
		public IWebElement ServiceType { get; set; }

        [FindsBy(How = How.Id, Using = "lstProductTypes")]
		public IWebElement ProductTypes { get; set; }

		[FindsBy(How = How.Id, Using = "cmbTransType")]
		public IWebElement TransactionType { get; set; }

		[FindsBy(How = How.Id, Using = "cmbBussSegment")]
		public IWebElement BussinessSegment { get; set; }

		[FindsBy(How = How.Id, Using = "cmbFileOwnOff")]
		public IWebElement FileOwningOffice { get; set; }

		[FindsBy(How = How.Id, Using = "cmbPropType")]
		public IWebElement PropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "cmbProgramType")]
		public IWebElement ProgramType { get; set; }

		[FindsBy(How = How.Id, Using = "cmbOrderSource")]
		public IWebElement OrderSource { get; set; }

		[FindsBy(How = How.Id, Using = "cmbSearchType")]
		public IWebElement SearchType { get; set; }

		[FindsBy(How = How.Id, Using = "cmbState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "cmbCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "cmbCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "rdoTrigger")]
		public IWebElement Trigger { get; set; }

        [FindsBy(How = How.XPath, Using = "//b[contains(text(),'Trigger')]")]
        public IWebElement TriggerText { get; set; }

		[FindsBy(How = How.Id, Using = "rdoProcessType")]
		public IWebElement ProcessType { get; set; }

		[FindsBy(How = How.Id, Using = "cmbInvokeType")]
		public IWebElement InvokeType { get; set; }

		[FindsBy(How = How.Id, Using = "idInvoke")]
		public IWebElement Invoke { get; set; }

		[FindsBy(How = How.Id, Using = "lblSSID")]
		public IWebElement SimulatorSessionID { get; set; }

        [FindsBy(How = How.Id, Using = "dgridCAN_dgridCAN")]
        public IWebElement CandidateProcessTemplatesTable { get; set; }

		#endregion

        public BestMatchSimulator WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? NewSession);
            return this;
        }

        public void Open()
        {
            FastDriver.LeftNavigation.Navigate<BestMatchSimulator>("Home>System Maintenance>Process Setup>Best Match Simulator").WaitForScreenToLoad();
        }

        public void ClickPreviousSession()
        {
            this.PreviousSession.FAClick();
            FastDriver.PreviousSessionsDlg.WaitForScreenToLoad();
        }
	}
}
