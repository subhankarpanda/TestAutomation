using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BestMatchSimulatorMatrixDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//table/tbody/tr/td[@class='cFrameBody']/table")]
		public IWebElement FilterMatchTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@title='close']")]
        public IWebElement CloseButton { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement CandidateMatchMatrixTable { get; set; }

		#endregion

        public BestMatchSimulatorMatrixDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FilterMatchTable);
            return this;
        }
	}
}
