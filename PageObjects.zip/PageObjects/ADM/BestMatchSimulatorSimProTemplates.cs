using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BestMatchSimulatorSimProTemplates : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnWorkflow")]
		public IWebElement ShowWorkflow { get; set; }

		[FindsBy(How = How.Id, Using = "btnBMWMM")]
		public IWebElement BestMatchViewMatchMatrix { get; set; }

		[FindsBy(How = How.Id, Using = "btnCANMM")]
		public IWebElement CandidateMatchViewMatchMatrix { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBMW_dgridBMW")]
		public IWebElement BestMatchTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCAN_dgridCAN")]
		public IWebElement CandidateMatchTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "AUTO_DONOTTOUCH_Template Setup Maintenan")]
		public IWebElement BestMatchTemplate { get; set; }

		[FindsBy(How = How.LinkText, Using = "AUTO_DONOT_TOUCH_StandardTemplateForSani")]
		public IWebElement CandidateMatchTemplate { get; set; }

		#endregion

        public BestMatchSimulatorSimProTemplates WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? CandidateMatchTable);
            return this;
        }
	}
}
