using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusOrgSearchDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmbBusOrg")]
		public IWebElement BusinessSourceOrg { get; set; }

        [FindsBy(How = How.Id, Using = "lstBusOrgs")]
        public IWebElement ListBusinessOrg { get; set; }

		[FindsBy(How = How.Id, Using = "txtStartWith")]
		public IWebElement StartWith { get; set; }

		[FindsBy(How = How.Id, Using = "btnFind")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.LinkText, Using = "Earthquake Ins. 1 for HUD Testing Name 1")]
		public IWebElement BusinessOrgselect { get; set; }

		[FindsBy(How = How.LinkText, Using = "Lenders Advantage")]
		public IWebElement BusinessOrgselectLender { get; set; }

		#endregion

        public BusOrgSearchDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? BusinessSourceOrg);
            return this;
        }
	}
}
