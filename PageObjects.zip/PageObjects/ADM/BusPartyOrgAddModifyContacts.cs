﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;

namespace FASTSelenium.PageObjects.ADM
{
    public class BusPartyOrgRegionalGABContacts : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdViewChangeStatus")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "dgridBusinessContacts_dgridBusinessContacts")]
        public IWebElement ContactsTable { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement LicenseInfoNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnEdit")]
        public IWebElement LicenseInfoEdit { get; set; }

        [FindsBy(How = How.Id, Using = "textFirstName")]
        public IWebElement ContactFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "textSecondName")]
        public IWebElement ContactLastName { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement LicenseInfoTable { get; set; }

        #endregion

        public BusPartyOrgRegionalGABContacts WaitForScreenToLoad(IWebElement element = null, bool lowerFrame = false)
        {
            this.SwitchToDialogContactLeftContentFrame(lowerFrame);
            this.WaitCreation(element ?? ViewChangeStatus);

            return this;
        }

        public BusPartyOrgRegionalGABContacts AddContact(string firstName, string lastName)
        {
            //WaitForScreenToLoad(ContactsTable);
            if (New.Enabled)
            {
                New.FAClick();
            }
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                WaitForScreenToLoad(ContactFirstName, true);
                return ContactFirstName.Enabled;
            }, timeout: 20);
            ContactFirstName.FASetText(firstName);
            ContactLastName.FASetText(lastName);

            return this;
        }
    }

    public class BusPartyOrgGABRequestContacts : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdViewChangeStatus")]
        public IWebElement ViewChangeStatus { get; set; }

        #endregion

        public BusPartyOrgGABRequestContacts WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogRightContentFrame();
            this.WaitCreation(element ?? ViewChangeStatus);

            return this;
        }
    }
}