﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class BusinessOrgRelationships : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement AddBusOrg { get; set; }

        [FindsBy(How = How.Id, Using = "btnChangeStatus")]
        public IWebElement ViewChangeBusOrgStatus { get; set; }

        [FindsBy(How = How.Id, Using = "chkBusOrgActive")]
        public IWebElement ActiveOnlyBusOrgChk { get; set; }

        [FindsBy(How = How.Id, Using = "chkContActive")]
        public IWebElement ActiveOnlyBusContChk { get; set; }

        [FindsBy(How = How.Id, Using = "btnContAdd")]
        public IWebElement AddBusCont { get; set; }

        [FindsBy(How = How.Id, Using = "btnContChangeStatus")]
        public IWebElement ViewChangeBusContStatus { get; set; }

        [FindsBy(How = How.Id, Using = "grdRelationship")]
        public IWebElement BusOrgRelationshipsTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdContacts")]
        public IWebElement BusContRelationshipsTable { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "grdRelationship_0_btnRoleAdd")]
        public IWebElement AddRoleRelationship { get; set; }

        [FindsBy(How = How.Id, Using = "grdContacts_0_btnRoleAdd")]
        public IWebElement AddRoleContacts { get; set; }
        #endregion

        public void AddRelationship(bool isBusOrg)
        {
            FastDriver.BusinessOrgRelationships.WaitForScreenToLoad();

            if (isBusOrg)
            {
                AddBusOrg.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
            }
            else
            {
                AddBusCont.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
            }
        }

        public BusinessOrgRelationships WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AddBusOrg);
            return this;
        }
    }
}
