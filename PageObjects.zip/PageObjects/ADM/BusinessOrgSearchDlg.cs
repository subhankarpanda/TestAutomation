﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTSelenium.PageObjects.ADM
{
    public class BusinessOrgSearchDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "txtEnterPriceNum")]
        public IWebElement EnterpriseNo { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewGABEntry")]
        public IWebElement NewGAB { get; set; }

        [FindsBy(How = How.Id, Using = "cmdModifyGABEntry")]
        public IWebElement ModifyGAB { get; set; }

        [FindsBy(How = How.Id, Using = "cmdClearSearchFlds")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFind")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "comboTypetable")]
        public IWebElement EntityType { get; set; }

        [FindsBy(How = How.Id, Using = "textEntityName")]
        public IWebElement EntityName { get; set; }

        [FindsBy(How = How.Id, Using = "textEntityID")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "textCiy")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "textCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "comboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "textContfirstName")]
        public IWebElement ContactFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "textLastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressType_0")]
        public IWebElement UseMailingAddress { get; set; }

        [FindsBy(How = How.Id, Using = "dgGAB")]
        public IWebElement ResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAdd")]
        public IWebElement AddResults { get; set; }
        #endregion

        public BusinessOrgSearchDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.WebDriver.WaitForWindowAndSwitch("Business Org Search", timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Find);

            return this;
        }

        public BusinessOrgSearchDlg WaitForDialogToLoad(IWebElement Element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Element ?? Find);

            return this;
        }

        public BusinessOrgSearchDlg WaitForDialogToLoad_0(IWebElement Element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Element ?? Find);

            return this;
        }

        public BusinessOrgSearchDlg FindContact(string EntiType = null, string City = null, string EntityName = null, string IDCode = null, string County = null, string State = null, string Contact1stName = null, string LastName = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(this.IDCode);
            this.EntityType.FASelectItem(EntiType);
            this.City.FASetText(City);
            this.EntityName.FASetText(EntityName);
            this.IDCode.FASetText(IDCode);
            this.County.FASetText(County);
            this.State.FASelectItem(State);
            this.ContactFirstName.FASetText(Contact1stName);
            this.LastName.FASetText(LastName);
            this.Find.FAClick();
            return this;
        }

        public void FindAndSelectContact(string IDCode)
        {
            this.FindContact(IDCode: IDCode);
            this.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 20);
            this.WaitForScreenToLoad(this.ResultsTable);
            this.ResultsTable.PerformTableAction("ID Code", IDCode, "Select", TableAction.On);
            this.AddResults.FAClick();
        }
    }
}
