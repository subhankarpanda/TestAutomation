using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using FASTSelenium.DataObjects.ADM;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusPartyContactSetup : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "dgridBP_dgridBP")]
        public IWebElement BusinessProgramNameTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//body/span[@id='__FAFErrorMessageList']/ul/li")]
        public IWebElement MessagePane { get; set; }

		[FindsBy(How = How.Id, Using = "cmdExternalCustomer")]
		public IWebElement ExternalCustomer { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "textFirstName")]
		public IWebElement FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "cmdVersionCheck")]
		public IWebElement Version { get; set; }

		[FindsBy(How = How.Id, Using = "comboTitleOfficer")]
		public IWebElement TitleOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "textSecondName")]
		public IWebElement LastName { get; set; }

		[FindsBy(How = How.Id, Using = "comboEscrowOfficer")]
		public IWebElement EscrowOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "textDelegateName")]
		public IWebElement DelegateName { get; set; }

        [FindsBy(How = How.Id, Using = "labelStatus")]
        public IWebElement StatusLabel { get; set; }

		[FindsBy(How = How.Id, Using = "comboSalesRep1")]
		public IWebElement SalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "comboSalesRep2")]
		public IWebElement SalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "cmdView")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "textComments")]
		public IWebElement ContactComments { get; set; }

		[FindsBy(How = How.Id, Using = "txtCustomerPreference")]
		public IWebElement CustomerPreference { get; set; }

		[FindsBy(How = How.Id, Using = "cmdHistory")]
		public IWebElement History { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSelectBP")]
		public IWebElement BusProgramAddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddessDisplay_dgridAddessDisplay")]
		public IWebElement AddressesTable { get; set; }

        [FindsBy(How = How.Id, Using = "cmdRelationships")]
        public IWebElement Relationships { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrNew")]
		public IWebElement AddressesNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrCopy")]
		public IWebElement AddressesCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrDelete")]
		public IWebElement AddressesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_cmdAdd")]
		public IWebElement Apply { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboAddressType")]
		public IWebElement AddressType { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine1")]
		public IWebElement AddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine2")]
		public IWebElement AddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine3")]
		public IWebElement AddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine4")]
		public IWebElement AddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_chkEmailStatus")]
		public IWebElement StatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdAddPhoneType")]
		public IWebElement PhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdDeletePhoneEntry")]
		public IWebElement PhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdNotification")]
		public IWebElement Notification { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement BusPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textNumber")]
		public IWebElement BusNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textExtension")]
		public IWebElement BusExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_cboNotificationType")]
		public IWebElement BusNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textComments")]
		public IWebElement BusComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement BusFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textNumber")]
		public IWebElement BusFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textExtension")]
		public IWebElement BusFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_cboNotificationType")]
		public IWebElement BusFaxNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textComments")]
		public IWebElement BusFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement EmailType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_textNumber")]
		public IWebElement EmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_cboNotificationType")]
		public IWebElement EmailNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_textComments")]
		public IWebElement EmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement PagerType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textNumber")]
		public IWebElement PagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textExtension")]
		public IWebElement PagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_cboNotificationType")]
		public IWebElement PagerNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textComments")]
		public IWebElement PagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement CellularType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textNumber")]
		public IWebElement CellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textExtension")]
		public IWebElement CellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_cboNotificationType")]
		public IWebElement CellularNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textComments")]
		public IWebElement CellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement HomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textNumber")]
		public IWebElement HomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textExtension")]
		public IWebElement HomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_cboNotificationType")]
		public IWebElement HomePhoneNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textComments")]
		public IWebElement HomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement HomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textNumber")]
		public IWebElement HomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textExtension")]
		public IWebElement HomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_cboNotificationType")]
		public IWebElement HomeFaxNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textComments")]
		public IWebElement HomeFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement LicenseInformationNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement LicenseInformationTable { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement ContactLicenseInformationNew { get; set; }
        

		#endregion

        public BusPartyContactSetup WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(FirstName);
            return this;
        }

        public BusPartyContactSetup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FirstName);
            return this;
        }
        //
        public Dictionary<string, string> GetAddressDetails(string AddressType)
        {
            
            this.SwitchToContentFrame();
            Reports.TestStep = "Get contact address ADM";
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            if (this.AddressesTable.FAGetText().Contains(AddressType))
            {
                AllDetails.Add("Status", this.AddressesTable.PerformTableAction("Type", AddressType, "Type", TableAction.Click).Status.ToString());
                //AllDetails.Add("AddressType", AddressType.FAGetSelectedItem());
                AllDetails.Add("AddressLine1", AddressLine1.FAGetValue());
                AllDetails.Add("AddressLine2", AddressLine2.FAGetValue());
                AllDetails.Add("AddressLine3", AddressLine3.FAGetValue());
                AllDetails.Add("AddressLine4", AddressLine4.FAGetValue());
                //AllDetails.Add("BuyerSellerType", BuyerSellerType.FAGetSelectedItem());
                AllDetails.Add("Country", Country.FAGetSelectedItem());
                AllDetails.Add("City", City.FAGetValue());
                AllDetails.Add("State", State.FAGetSelectedItem());
                AllDetails.Add("Zip", Zip.FAGetValue());
                AllDetails.Add("County", County.FAGetValue());
            }
            return AllDetails;
        }
        //
        public BusinessOrganizationParameters SetNewAddressDetails(BusinessOrganizationParameters busOrg)
        {
            try
            {
                this.SwitchToContentFrame();
                if (busOrg == null)
                {
                    busOrg = new BusinessOrganizationParameters();
                    busOrg.Addresstype = "Mailing";
                    busOrg.AddressLine1 = "Line 1";
                    busOrg.AddressLine2 = "Line 2";
                    busOrg.AddressLine3 = "Line 3";
                    busOrg.City = "Albany";
                    busOrg.State = "CA";
                    busOrg.Zip = "92707";
                    busOrg.County = "Alameda";
                    busOrg.Country = "USA";
                }
                Reports.TestStep = "Set contact address ADM";
                Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad();
                AddressesNew.FAClick();
                Thread.Sleep(3000);
                this.WaitForScreenToLoad();
                AddressType.FASelectItem(busOrg.Addresstype);
                AddressLine1.FASetText(busOrg.AddressLine1);
                AddressLine2.FASetText(busOrg.AddressLine2);
                AddressLine3.FASetText(busOrg.AddressLine3);
                AddressLine4.FASetText(busOrg.AddressLine4);
                City.FASetText(busOrg.City);
                State.FASelectItem(busOrg.State);
                Zip.FASetText(busOrg.Zip);
                County.FASetText(busOrg.County);
                Country.FASelectItem(busOrg.Country);
                Apply.FAClick();
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return busOrg;
        }
        //
        public BusinessOrganizationParameters ChangeAddressDetails(string OldAddressType, BusinessOrganizationParameters busOrg)
        {
            
            try
            {
                this.SwitchToContentFrame();
                Reports.TestStep = "Change contact address ADM";
                Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad();
                AddressesTable.PerformTableAction("Type", OldAddressType, "Type", TableAction.Click);
                AddressType.FASelectItem(busOrg.Addresstype);
                AddressLine1.FASetText(busOrg.AddressLine1);
                AddressLine2.FASetText(busOrg.AddressLine2);
                AddressLine3.FASetText(busOrg.AddressLine3);
                AddressLine4.FASetText(busOrg.AddressLine4);
                Country.FASelectItem(busOrg.Country);
                City.FASetText(busOrg.City);
                State.FASelectItem(busOrg.State);
                Zip.FASetText(busOrg.Zip);
                County.FASetText(busOrg.County);
                Apply.FAClick();
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception" + ex.Message, false);
            }
            return busOrg;
        }
        //
        //
        public bool RemoveAddress(string AddressType)
        {
            
            try
            {
                this.SwitchToContentFrame();
                Reports.TestStep = "Remove contact address ADM";
                Version.FAClick();
                if (AddressesTable.FAGetText().Contains(AddressType))
                {
                    AddressesTable.PerformTableAction("Type", AddressType, "Type", TableAction.Click);
                    AddressesRemove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                    this.WaitForScreenToLoad();
                    return true;
                }
                else return false;
                
            }
            catch
            {
                return false;
            }

        }
        //
        public Dictionary<string, string> CreateNewContactForBusOrg(string FirstName = "", string LastName = "", BusinessOrganizationParameters BusOrgParams = null, PhoneParameters PhoneParams = null)
        {
            try
            {
                Dictionary<string, string> ContactName = new Dictionary<string, string>();
                this.WaitForScreenToLoad();
                Reports.TestStep = "To create new business party contact for the Bus Org.";
                string RanStr=Guid.NewGuid().GetHashCode().ToString("x");
                if (string.IsNullOrEmpty(FirstName))
                    this.FirstName.FASetText("FN" + RanStr.Substring(0,4));
                else
                    this.FirstName.FASetText(FirstName);
                if (string.IsNullOrEmpty(LastName))
                {
                    this.LastName.FASetText("LN" + RanStr.Substring(3, 4));
                    LastName=this.LastName.FAGetValue();
                }
                else
                    this.FirstName.FASetText(LastName);
                this.SalesRep1.FASelectItemByIndex(1);
                this.SalesRep2.FASelectItemByIndex(2);
 
                SetNewAddressDetails(BusOrgParams);
                SetPhoneDetailsForContact(PhoneParams);
                ContactName.Add("FirstName", FastDriver.BusPartyContactSetup.FirstName.FAGetValue());
                ContactName.Add("LastName", FastDriver.BusPartyContactSetup.LastName.FAGetValue());
                FastDriver.BottomFrame.Done();
                return ContactName;
            }
            catch
            {
                throw;
            }

        }
        //
        public void SetPhoneDetailsForContact(PhoneParameters Phones=null)
        {
            if(Phones==null)
            {
                Phones = new PhoneParameters();
                Phones.BusinessPhoneNumber=@"(121)212-1212";
                Phones.BusinessPhoneExtn = @"222";
                Phones.BusinessFaxNumber=@"(232)323-2323";
                Phones.Email=@"contact@test.com";
                Phones.PagerNumber=@"(343)434-3434";
                Phones.CellularNumber=@"(454)545-4545";
            }
            this.BusNumber.FASetText(Phones.BusinessPhoneNumber);
            this.BusExtension.FASetText(Phones.BusinessPhoneExtn);
            this.BusFaxNumber.FASetText(Phones.BusinessFaxNumber);
            this.EmailNumber.FASetText(Phones.Email);
            this.PagerNumber.FASetText(Phones.PagerNumber);
            this.CellularNumber.FASetText(Phones.CellularNumber);

        }
        //
        public List<LicenseInfoParameters> GetLicenseInfo(string ID = "")
        {
            this.WaitForScreenToLoad();

            List<LicenseInfoParameters> AllLicenses = new List<LicenseInfoParameters>();

            for (int i = 1; i <= LicenseInformationTable.GetRowCount(); i++)
            {
                LicenseInfoParameters LicenseInfo = new LicenseInfoParameters
                {
                    LicenseId = string.Empty,
                    LicenseState = string.Empty,
                    LicenseCounty = string.Empty,
                    LicenseType = string.Empty,
                    LicenseStatus = string.Empty,
                };
                LicenseInfo.LicenseId = LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                LicenseInfo.LicenseState = LicenseInformationTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                LicenseInfo.LicenseCounty = LicenseInformationTable.PerformTableAction(i, 3, TableAction.GetText).Message;
                LicenseInfo.LicenseType = LicenseInformationTable.PerformTableAction(i, 4, TableAction.GetText).Message;
                LicenseInfo.LicenseStatus = LicenseInformationTable.PerformTableAction(i, 5, TableAction.GetText).Message;
                if (!string.IsNullOrEmpty(ID))
                {
                    if (LicenseInfo.LicenseId.Equals(ID))
                    {
                        AllLicenses.Add(LicenseInfo);
                        break;
                    }
                }
                else
                {
                    AllLicenses.Add(LicenseInfo);
                }


            }

            return AllLicenses;
        }
        //
        public LicenseInfoParameters CreateNewLicense(string State, string StateLicenseType, string County = "", string CoLicenseType = "")
        {
            try
            {
                this.WaitForScreenToLoad();
                LicenseInfoParameters LicenseInfo = new LicenseInfoParameters();
                this.LicenseInformationNew.FAClick();
                Thread.Sleep(2000);
                string ID = FastDriver.LicenseInformationDlg.CreateNewLicense(State, StateLicenseType, County, CoLicenseType);
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.LicenseInformationTable.GetRowCount(); i++)
                {
                    string Act_ID = this.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (Act_ID.Equals(ID))
                    {
                        LicenseInfo = GetLicenseInfo(ID)[0];
                        break;
                    }
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);
                return LicenseInfo;
            }
            catch
            {
                throw;
            }

        }
        //
        public bool CreateNMLS()
        {
            try
            {
                this.WaitForScreenToLoad();
                this.LicenseInformationNew.FAClick();
                Thread.Sleep(2000);
                FastDriver.LicenseInformationDlg.WaitForScreenToLoad();
                Random RanNum = new Random(2351674);
                FastDriver.LicenseInformationDlg.ID.FASetText(RanNum.Next().ToString());
                string ID = FastDriver.LicenseInformationDlg.ID.FAGetText();
                FastDriver.LicenseInformationDlg.NMLS.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.LicenseInformationTable.GetRowCount(); i++)
                {
                    string Act_ID = this.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (Act_ID.Equals(ID))
                        return true;
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
	}
}
