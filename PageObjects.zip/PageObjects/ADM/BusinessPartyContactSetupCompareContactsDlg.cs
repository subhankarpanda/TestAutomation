using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BPSetupCompareGABReqContactDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "textFirstName")]
		public IWebElement CompareGABReqFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "textSecondName")]
		public IWebElement CompareGABReqSecondName { get; set; }

		[FindsBy(How = How.Id, Using = "txtCustomerPreference")]
		public IWebElement CompareGABReqCustomerPreference { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrNew")]
		public IWebElement CompareGABReqAddressesNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrCopy")]
		public IWebElement CompareGABReqAddressesCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrDelete")]
		public IWebElement CompareGABReqAddressesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_cmdAdd")]
		public IWebElement CompareGABReqAddressesApply { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboAddressType")]
		public IWebElement CompareGABReqAddressType { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine1")]
		public IWebElement CompareGABReqAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine2")]
		public IWebElement CompareGABReqAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine3")]
		public IWebElement CompareGABReqAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine4")]
		public IWebElement CompareGABReqAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCity")]
		public IWebElement CompareGABReqCity { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboState")]
		public IWebElement CompareGABReqState { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textZip")]
		public IWebElement CompareGABReqZip { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCounty")]
		public IWebElement CompareGABReqCounty { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboCountry")]
		public IWebElement CompareGABReqCountry { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_chkEmailStatus")]
		public IWebElement CompareGABReqStatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdAddPhoneType")]
		public IWebElement CompareGABReqPhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdDeletePhoneEntry")]
		public IWebElement CompareGABReqPhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement CompareGABReqBusPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textNumber")]
		public IWebElement CompareGABReqBusPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textExtension")]
		public IWebElement CompareGABReqBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textComments")]
		public IWebElement CompareGABReqBusPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement CompareGABReqBusFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textNumber")]
		public IWebElement CompareGABReqBusFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textExtension")]
		public IWebElement CompareGABReqBusFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textComments")]
		public IWebElement CompareGABReqBusFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement CompareGABReqEmailType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_textNumber")]
		public IWebElement CompareGABReqEmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_textComments")]
		public IWebElement CompareGABReqEmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement CompareGABReqPagerType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textNumber")]
		public IWebElement CompareGABReqPagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textExtension")]
		public IWebElement CompareGABReqPagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textComments")]
		public IWebElement CompareGABReqPagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement CompareGABReqCellularType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textNumber")]
		public IWebElement CompareGABReqCellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textExtension")]
		public IWebElement CompareGABReqCellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textComments")]
		public IWebElement CompareGABReqCellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement CompareGABReqHomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textNumber")]
		public IWebElement CompareGABReqHomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textExtension")]
		public IWebElement CompareGABReqHomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textComments")]
		public IWebElement CompareGABReqHomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement CompareGABReqHomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textNumber")]
		public IWebElement CompareGABReqHomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textExtension")]
		public IWebElement CompareGABReqHomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textComments")]
		public IWebElement CompareGABReqHomeFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_7_comboPhoneType")]
		public IWebElement CompareGABReqCFNotificationType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_7_textNumber")]
		public IWebElement CompareGABReqCFNotificationNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_7_textComments")]
		public IWebElement CompareGABReqCFNotificationComments { get; set; }

		#endregion

	}
	public class BPSetupCompareRegGABContactDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "textFirstName")]
		public IWebElement CompareRegGABFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "textSecondName")]
		public IWebElement CompareRegGABSecondName { get; set; }

		[FindsBy(How = How.Id, Using = "txtCustomerPreference")]
		public IWebElement CompareRegGABCustomerPreference { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrNew")]
		public IWebElement CompareRegGABAddressesNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrCopy")]
		public IWebElement CompareRegGABAddressesCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrDelete")]
		public IWebElement CompareRegGABAddressesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_cmdAdd")]
		public IWebElement CompareRegGABAddressesApply { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboAddressType")]
		public IWebElement CompareRegGABAddressType { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine1")]
		public IWebElement CompareRegGABAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine2")]
		public IWebElement CompareRegGABAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine3")]
		public IWebElement CompareRegGABAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine4")]
		public IWebElement CompareRegGABAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCity")]
		public IWebElement CompareRegGABCity { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboState")]
		public IWebElement CompareRegGABState { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textZip")]
		public IWebElement CompareRegGABZip { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCounty")]
		public IWebElement CompareRegGABCounty { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_comboCountry")]
		public IWebElement CompareRegGABCountry { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_chkEmailStatus")]
		public IWebElement CompareRegGABStatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdAddPhoneType")]
		public IWebElement CompareRegGABPhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_cmdDeletePhoneEntry")]
		public IWebElement CompareRegGABPhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement CompareRegGABBusPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textNumber")]
		public IWebElement CompareRegGABBusPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textExtension")]
		public IWebElement CompareRegGABBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textComments")]
		public IWebElement CompareRegGABBusPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement CompareRegGABBusFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textNumber")]
		public IWebElement CompareRegGABBusFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textExtension")]
		public IWebElement CompareRegGABBusFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textComments")]
		public IWebElement CompareRegGABBusFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement CompareRegGABEmailType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_textNumber")]
		public IWebElement CompareRegGABEmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_2_textComments")]
		public IWebElement CompareRegGABEmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement CompareRegGABPagerType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textNumber")]
		public IWebElement CompareRegGABPagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textExtension")]
		public IWebElement CompareRegGABPagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_3_textComments")]
		public IWebElement CompareRegGABPagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement CompareRegGABCellularType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textNumber")]
		public IWebElement CompareRegGABCellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textExtension")]
		public IWebElement CompareRegGABCellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_4_textComments")]
		public IWebElement CompareRegGABCellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement CompareRegGABHomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textNumber")]
		public IWebElement CompareRegGABHomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textExtension")]
		public IWebElement CompareRegGABHomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_5_textComments")]
		public IWebElement CompareRegGABHomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement CompareRegGABHomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textNumber")]
		public IWebElement CompareRegGABHomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textExtension")]
		public IWebElement CompareRegGABHomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_6_textComments")]
		public IWebElement CompareRegGABHomeFaxComments { get; set; }

		#endregion

	}
}
