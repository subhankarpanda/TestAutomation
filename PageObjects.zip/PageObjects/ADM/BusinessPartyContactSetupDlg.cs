using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusinessPartyContactSetupDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "textFirstName")]
		public IWebElement FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "txtCustomerPreference")]
		public IWebElement CustomerPreference { get; set; }

		[FindsBy(How = How.Id, Using = "textSecondName")]
		public IWebElement SecondName { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textAddrLine1")]
		public IWebElement Street { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressDetail1_textCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement BusinessPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textNumber")]
		public IWebElement BusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textExtension")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_0_textComments")]
		public IWebElement BusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement BusinessFaxPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textNumber")]
		public IWebElement BusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textExtension")]
		public IWebElement BusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_textComments")]
		public IWebElement BusinessFaxComments { get; set; }

		#endregion

	}
}
