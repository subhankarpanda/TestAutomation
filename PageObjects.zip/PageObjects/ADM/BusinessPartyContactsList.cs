using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusPartyContactsList : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdViewChangeStatus")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBusinessContacts")]
		public IWebElement ContactList { get; set; }

		[FindsBy(How = How.Id, Using = "chkActiveOnly")]
		public IWebElement ActiveOnly { get; set; }

		#endregion

        public BusPartyContactsList WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New);
            return this;
        }

        public BusPartyContactsList WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }

        public void EditContactForGAB(string ContactLastName)
        {
            FastDriver.BusPartyContactsList.WaitForScreenToLoad();
            try
            {
                ContactList.PerformTableAction("#3", ContactLastName, "#3", TableAction.Click);
                Edit.FAClick();
                FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
            }
            catch
            {
                throw new Exception(@"This GAB may not have contact having lastname=" + ContactLastName + " Please check in ADM.");
            }
            
        }

        /// <summary>
        /// This method clicks on the new button of the Bus PartyContactlist page.
        /// </summary>
        public void ClickNew()
        {
            this.New.FAClick();
            FastDriver.BusPartyContactSetup.WaitForScreenToLoad();
        }
	}
}
