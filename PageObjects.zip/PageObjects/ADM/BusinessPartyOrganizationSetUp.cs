using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects.ADM;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.ADM
{
    public class BusPartyOrgSetUp : PageObject
    {
        #region WebElements
        //Mau: All these web properties should not exist until they are needed

        [FindsBy(How = How.Id, Using = "PhoneType1_dgridPhoneTypes_1_lblNotificationStatus")]
        public IWebElement BusFaxNotificationStatus { get; set; }

        [FindsBy(How = How.Id, Using = "cmdeSubscriptions")]
        public IWebElement eSubscriptions { get; set; }

        [FindsBy(How = How.Id, Using = "cmdRelationships")]
        public IWebElement Relationships { get; set; }

        [FindsBy(How = How.Id, Using = "cmdCustomerOption")]
        public IWebElement CustomerOption { get; set; }

        [FindsBy(How = How.Id, Using = "cmdExternalCustomer")]
        public IWebElement ExternalCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "cmdViewAddContacts")]
        public IWebElement ViewAddContacts { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAdditionalLocs")]
        public IWebElement AdditionalLocations { get; set; }

        [FindsBy(How = How.Id, Using = "cmdVersionCheck")]
        public IWebElement Version { get; set; }

        [FindsBy(How = How.Id, Using = "cboCorporateParent")]
        public IWebElement CorporateParent { get; set; }

        [FindsBy(How = How.Id, Using = "chkStremLine")]
        public IWebElement StreamLineProcess { get; set; }

        [FindsBy(How = How.Id, Using = "cboBuyerSellerType")]
        public IWebElement BuyerSellerType { get; set; }

        [FindsBy(How = How.Id, Using = "cboEntityType")]
        public IWebElement EntityType { get; set; }

        [FindsBy(How = How.Id, Using = "cboGrade")]
        public IWebElement Grade { get; set; }

        [FindsBy(How = How.Id, Using = "txtIDCode")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "txtName1")]
        public IWebElement Name1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtName2")]
        public IWebElement Name2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtLocDesc")]
        public IWebElement LocDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtTaxId")]
        public IWebElement TaxIdNumber { get; set; }

        [FindsBy(How = How.Id, Using = "labelStatusDisp")]
        public IWebElement StatusLabel { get; set; }

        [FindsBy(How = How.Id, Using = "cmdViewChangeStatus")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "cboPrimaryContact")]
        public IWebElement PrimaryContact { get; set; }

        [FindsBy(How = How.Id, Using = "cboTitleAgentType")]
        public IWebElement TitleAgentType { get; set; }

        [FindsBy(How = How.Id, Using = "cboTitleOfficer")]
        public IWebElement TitleOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "cboEscrowOfficer")]
        public IWebElement EscrowOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "cboSalesRep1")]
        public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "cboSalesRep2")]
        public IWebElement SalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "txtLicNum")]
        public IWebElement LicenceNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLicType")]
        public IWebElement LicenceType { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnExpBP")]
        public IWebElement LicenseInformationExpand { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_chkActiveonly")]
        public IWebElement LicenseInformationActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement LicenseInformationNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnEdit")]
        public IWebElement LicenseInformationEdit { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnViewChangeStatus")]
        public IWebElement LicenseInformationViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnViewChangeHistory")]
        public IWebElement LicenseInformationChangeHistory { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement LicenseInformationTable { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddRemoveMorProd")]
        public IWebElement MortgageProductsAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdHistory")]
        public IWebElement BusinessProgramHistory { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSelectBP")]
        public IWebElement BusinessProgramAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "txtOrgName1")]
        public IWebElement OrgName1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtOrgName2")]
        public IWebElement OrgName2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtPersonName")]
        public IWebElement PersonName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAddress_dgridAddress")]
        public IWebElement AddressTable { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddressNew")]
        public IWebElement AddressesNew { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddressCopy")]
        public IWebElement AddressesCopy { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddressDelete")]
        public IWebElement AddressesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_cmdAdd")]
        public IWebElement AddressesApply { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboAddressType")]
        public IWebElement AddressType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine1")]
        public IWebElement AddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine2")]
        public IWebElement AddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine3")]
        public IWebElement AddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine4")]
        public IWebElement AddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCity")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textZip")]
        public IWebElement Zip { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboCountry")]
        public IWebElement Country { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_chkEmailStatus")]
        public IWebElement StatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdAddPhoneType")]
        public IWebElement PhonesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdDeletePhoneEntry")]
        public IWebElement PhonesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdNotification")]
        public IWebElement Notification { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_comboPhoneType")]
        public IWebElement BusinessPhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textNumber")]
        public IWebElement BusinessPhoneTypeNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textExtension")]
        public IWebElement BusinessPhoneTypeExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_cboNotificationType")]
        public IWebElement BusinessNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textComments")]
        public IWebElement BusinessPhoneTypeComments { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_comboPhoneType")]
        public IWebElement BusinessFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textNumber")]
        public IWebElement BusinessFaxTypeNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textExtension")]
        public IWebElement BusinessFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_cboNotificationType")]
        public IWebElement BusinessFaxNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textComments")]
        public IWebElement BusinessFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_comboPhoneType")]
        public IWebElement EmailType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textNumber")]
        public IWebElement EmailNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_cboNotificationType")]
        public IWebElement EmailNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_lblNotificationStatus")]
        public IWebElement EmailNotificationStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textComments")]
        public IWebElement EmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_comboPhoneType")]
        public IWebElement PagerType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textNumber")]
        public IWebElement PagerNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textExtension")]
        public IWebElement PagerExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_cboNotificationType")]
        public IWebElement PagerNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textComments")]
        public IWebElement PagerComments { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_comboPhoneType")]
        public IWebElement CellularType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textNumber")]
        public IWebElement CellularNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textExtension")]
        public IWebElement CellularExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_cboNotificationType")]
        public IWebElement CellularNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textComments")]
        public IWebElement CellularComments { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_comboPhoneType")]
        public IWebElement HomePhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textNumber")]
        public IWebElement HomePhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textExtension")]
        public IWebElement HomePhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_cboNotificationType")]
        public IWebElement HomePhoneNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textComments")]
        public IWebElement HomePhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_comboPhoneType")]
        public IWebElement HomeFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textNumber")]
        public IWebElement HomeFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textExtension")]
        public IWebElement HomeFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_cboNotificationType")]
        public IWebElement HomeFaxNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textComments")]
        public IWebElement HomeFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "cmdInstAddRemove")]
        public IWebElement InstructionsAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "txtTIClause")]
        public IWebElement TitleInsuranseMortgageClause { get; set; }

        [FindsBy(How = How.Id, Using = "txtHazClause")]
        public IWebElement HazardLossPayeeClause { get; set; }

        [FindsBy(How = How.Id, Using = "txtCustomerPreference")]
        public IWebElement CustomerPreference { get; set; }

        [FindsBy(How = How.Id, Using = "txtABANum")]
        public IWebElement ABANumber { get; set; }

        [FindsBy(How = How.Id, Using = "chkDGC")]
        public IWebElement DataGovernanceCertified { get; set; }

        [FindsBy(How = How.Id, Using = "txtBankName")]
        public IWebElement BankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtGovernedBy")]
        public IWebElement DataGovernedBy { get; set; }

        [FindsBy(How = How.Id, Using = "txtBankAddr")]
        public IWebElement BankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtGovernedOn")]
        public IWebElement DataGovernedOn { get; set; }

        [FindsBy(How = How.Id, Using = "txtAccountNum")]
        public IWebElement AccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtTechExcelNum")]
        public IWebElement TicketNumber { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "chkManual")]
        public IWebElement Manual { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddModContact")]
        public IWebElement AddModifyContact { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddressCopy")]
        public IWebElement Copy { get; set; }

        [FindsBy(How = How.Id, Using = "cboStatus")]
        public IWebElement RequestStatus { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInstructions_dgridInstructions")]
        public IWebElement InstructionsTable { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_labelCityStateZip")]
        public IWebElement CityProvince { get; set; }

        [FindsBy(How = How.LinkText, Using = "Address Type: Only one Mailing address is allowed.")]
        public IWebElement Error { get; set; }

        [FindsBy(How = How.Id, Using = "dgridBP_dgridBP")]
        public IWebElement BusinessProgramNameTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtABANum")]
        public IWebElement WireABANum { get; set; }

        [FindsBy(How = How.Id, Using = "txtBankName")]
        public IWebElement WireBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtBankAddr")]
        public IWebElement WireBankAddr { get; set; }

        [FindsBy(How = How.Id, Using = "txtAccountNum")]
        public IWebElement WireAccountNum { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_lblNotificationStatus")]
        public IWebElement NotAvailablePain { get; set; }

        [FindsBy(How = How.Id, Using = "chkQCClosing")]
        public IWebElement QCClosingClient { get; set; }

        [FindsBy(How = How.Id, Using = "dgridMortProduct_dgridMortProduct")]
        public IWebElement MortgageProductsTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement LoanInvestorNew { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp3")]
        public IWebElement MortgageProductsExpand { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement WarningPane { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanInvestors_grdLoanInvestors")]
        public IWebElement LoanInvestorsTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement LoanInvestorsRemove { get; set; }

        [FindsBy(How = How.Id, Using = "btnViewDetails")]
        public IWebElement LoanInvestorsDetails { get; set; }

        [FindsBy(How = How.Id, Using = "grdContacts_grdContacts")]
        public IWebElement LoanInvestorsContactsTable { get; set; }

        [FindsBy(How = How.Id, Using = "labelAddressBookIDDisp")]
        public IWebElement AddressBookID { get; set; }

        [FindsBy(How = How.Id, Using = "labelOriginalAddressBookIDDisp")]
        public IWebElement OriginalAddressBookID { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_dgridPhoneTypes")]
        public IWebElement NotificationTable { get; set; }
        
        #endregion

        public BusPartyOrgSetUp FillNewBusinessOrganizationForm(BusinessOrganizationParameters busOrg)
        {
            EntityType.FASelectItem(busOrg.EntityType);
            if (IDCode.IsEnabled())
            IDCode.FASetText(busOrg.IDCode);
            Name1.FASetText(busOrg.Name1);
            Name2.FASetText(busOrg.Name2);
            LocDescription.FASetText(busOrg.LocDescription);
            TaxIdNumber.FASetText(busOrg.TaxIdNumber);
            TitleOfficer.FASelectItem(busOrg.TitleOfficer);
            EscrowOfficer.FASelectItem(busOrg.EscrowOfficer);
            Comments.FASetText(busOrg.Comments);
            //LicenceNumber.FASetText(@"License123"); // License # is missing in EVAL02
            //LicenceType.FASetText(@"Title Insurance");

            if (busOrg.newAddress)
            {
                AddressesNew.FAClick();
                AddressType.FASelectItem(busOrg.Addresstype);
                AddressLine1.FASetText(busOrg.AddressLine1);
                AddressLine2.FASetText(busOrg.AddressLine2);
                AddressLine3.FASetText(busOrg.AddressLine3);
                AddressLine4.FASetText(busOrg.AddressLine4);
                BuyerSellerType.FASelectItem(busOrg.BuyerSellerType);
                Country.FASelectItem(busOrg.Country);  
                City.FASetText(busOrg.City);
                State.FASelectItem(busOrg.State);
                Zip.FASetText(busOrg.Zip);
                County.FASetText(busOrg.County);
                AddressesApply.FAClick();
                             
                    
            }

            OrgName1.FASetText(busOrg.OrgName1);
            OrgName2.FASetText(busOrg.OrgName2);
            PersonName.FASetText(busOrg.PersonName);
            ABANumber.FASetText(busOrg.ABANumber);
            BankName.FASetText(busOrg.BankName);
            BankAddress.FASetText(busOrg.BankAddress);
            AccountNumber.FASetText(busOrg.AccountNumber);
            return this;
        }

        public Dictionary<string, string> GetDetails
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("EntityType", EntityType.FAGetSelectedItem());
                AllDetails.Add("IDCode", IDCode.FAGetValue());
                AllDetails.Add("Name1", Name1.FAGetValue());
                AllDetails.Add("Name2", Name2.FAGetValue());
                AllDetails.Add("LocDescription", LocDescription.FAGetValue());
                AllDetails.Add("Comments", Comments.FAGetValue());
                AllDetails.Add("AddressType", AddressType.FAGetSelectedItem());
                AllDetails.Add("AddressLine1", AddressLine1.FAGetValue());
                AllDetails.Add("AddressLine2", AddressLine2.FAGetValue());
                AllDetails.Add("AddressLine3", AddressLine3.FAGetValue());
                AllDetails.Add("AddressLine4", AddressLine4.FAGetValue());
                AllDetails.Add("BuyerSellerType", BuyerSellerType.FAGetSelectedItem());
                AllDetails.Add("Country", Country.FAGetSelectedItem());
                AllDetails.Add("City", City.FAGetValue());
                AllDetails.Add("State", State.FAGetSelectedItem());
                AllDetails.Add("Zip", Zip.FAGetValue());
                AllDetails.Add("County", County.FAGetValue());
                AllDetails.Add("ABANumber", ABANumber.FAGetValue());
                AllDetails.Add("BankName", BankName.FAGetValue());
                AllDetails.Add("BankAddress", BankAddress.FAGetValue());
                AllDetails.Add("AccountNumber", AccountNumber.FAGetValue());
                return AllDetails;
            }
        }

        public BusPartyOrgSetUp WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? IDCode);
            return this;
        }
        //
        public Dictionary<string, string> GetAddressDetails(string AddressType)
        {
            
            this.SwitchToContentFrame();
            Reports.TestStep = "Get address details";
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            if (this.AddressTable.FAGetText().Contains(AddressType))
            {
                AllDetails.Add("Status",this.AddressTable.PerformTableAction("Type", AddressType, "Type", TableAction.Click).Status.ToString());
                Thread.Sleep(3000);
                //AllDetails.Add("AddressType", AddressType.FAGetSelectedItem());
                AllDetails.Add("AddressLine1", AddressLine1.FAGetValue());
                AllDetails.Add("AddressLine2", AddressLine2.FAGetValue());
                AllDetails.Add("AddressLine3", AddressLine3.FAGetValue());
                AllDetails.Add("AddressLine4", AddressLine4.FAGetValue());
                AllDetails.Add("BuyerSellerType", BuyerSellerType.FAGetSelectedItem());
                AllDetails.Add("Country", Country.FAGetSelectedItem());
                AllDetails.Add("City", City.FAGetValue());
                AllDetails.Add("State", State.FAGetSelectedItem());
                AllDetails.Add("Zip", Zip.FAGetValue());
                AllDetails.Add("County", County.FAGetValue());
            }
                return AllDetails;
        }
        //
        public BusinessOrganizationParameters SetNewAddressDetails(BusinessOrganizationParameters busOrg)
        {

            this.SwitchToContentFrame();
            Reports.TestStep = "Set New Address";
                Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad();
                AddressesNew.FAClick();
                AddressType.FASelectItem(busOrg.Addresstype);
                AddressLine1.FASetText(busOrg.AddressLine1);
                AddressLine2.FASetText(busOrg.AddressLine2);
                AddressLine3.FASetText(busOrg.AddressLine3);
                AddressLine4.FASetText(busOrg.AddressLine4);
                Country.FASelectItem(busOrg.Country);
                City.FASetText(busOrg.City);
                State.FASelectItem(busOrg.State);
                Zip.FASetText(busOrg.Zip);
                County.FASetText(busOrg.County);
                AddressesApply.FAClick();
                return busOrg;
        }

        public BusinessOrganizationParameters ChangeAddressDetails(string OldAddressType,BusinessOrganizationParameters busOrg)
        {
            try
            {              
                this.SwitchToContentFrame();
                Reports.TestStep = "CHange Address details";
                Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad();
                AddressTable.PerformTableAction("Type", OldAddressType, "Type", TableAction.Click);
                Thread.Sleep(3000);
                AddressType.FASelectItem(busOrg.Addresstype);
                AddressLine1.FASetText(busOrg.AddressLine1);
                AddressLine2.FASetText(busOrg.AddressLine2);
                AddressLine3.FASetText(busOrg.AddressLine3);
                AddressLine4.FASetText(busOrg.AddressLine4);
                Country.FASelectItem(busOrg.Country);
                City.FASetText(busOrg.City);
                State.FASelectItem(busOrg.State);
                Zip.FASetText(busOrg.Zip);
                County.FASetText(busOrg.County);
                AddressesApply.FAClick();
                Thread.Sleep(2000);
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Exception" + ex.Message, false);
            }
            return busOrg;
        }
        //
        public bool RemoveAddress(string AddressType)
        {
            try
            {
                
                this.SwitchToContentFrame();
                Reports.TestStep = "Remove Address";
                Version.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad();
                if (AddressTable.FAGetText().Contains(AddressType))
                {
                    AddressTable.PerformTableAction("Type", AddressType, "Type", TableAction.Click);
                    AddressesRemove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage();
                    this.WaitForScreenToLoad();
                    return true;
                }
                else return false;

            }
            catch
            {
                return false;
            }

        }
        //
        public Dictionary<string, string[]> GetPhoneDetails()
        {
            this.SwitchToContentFrame();
            Reports.TestStep = "Get Phone details";
            Dictionary<string, string[]> PhoneDetails = new Dictionary<string, string[]>();
            try
            {
                PhoneDetails.Add(this.BusinessPhoneType.FAGetSelectedItem(), new[] {this.BusinessPhoneTypeNumber.FAGetValue(),this.BusinessPhoneTypeExtension.FAGetValue()});
                PhoneDetails.Add(this.BusinessFaxType.FAGetSelectedItem(), new[] {this.BusinessFaxTypeNumber.FAGetValue(),this.BusinessFaxExtension.FAGetValue()});
                PhoneDetails.Add(this.EmailType.FAGetSelectedItem(), new[] {this.EmailNumber.FAGetValue(),""});
                PhoneDetails.Add(this.PagerType.FAGetSelectedItem(), new[] {this.PagerNumber.FAGetValue(),this.PagerExtension.FAGetValue()});
                PhoneDetails.Add(this.CellularType.FAGetSelectedItem(), new[] {this.CellularNumber.FAGetValue(),this.CellularExtension.FAGetValue()});
                PhoneDetails.Add(this.HomePhoneType.FAGetSelectedItem(), new[] {this.HomePhoneNumber.FAGetValue(),this.HomePhoneExtension.FAGetValue()});
                PhoneDetails.Add(this.HomeFaxType.FAGetSelectedItem(), new[] { this.HomeFaxNumber.FAGetValue(), this.HomeFaxExtension.FAGetValue() });
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);

            }

                return PhoneDetails;            
        }
        //
        public Dictionary<string, string> GetChangedWireInstructions(bool DataGovtChecked = false)
        {
            this.WaitForScreenToLoad();
            Dictionary<string, string> WireInstructions = new Dictionary<string, string>();
            Random RanNum=new Random(3456);
            int Max = 1234567;
            ABANumber.FASetText(RanNum.Next(Max).ToString());
            BankName.FASetText("Test Bank" + RanNum.Next(Max).ToString());
            BankAddress.FASetText("Test Bank street1");
            AccountNumber.FASetText(RanNum.Next(Max).ToString());
            TicketNumber.FASetText(RanNum.Next(Max).ToString());
            DataGovernanceCertified.FASetCheckbox(DataGovtChecked);

            WireInstructions.Add("ABANumber", ABANumber.FAGetValue());
            WireInstructions.Add("BankName", BankName.FAGetValue());
            WireInstructions.Add("BankAddress", BankAddress.FAGetValue());
            WireInstructions.Add("AccountNumber", AccountNumber.FAGetValue());
           // WireInstructions.Add("TicketNumber", TicketNumber.FAGetValue());
            WireInstructions.Add("DataGovernanceCertified", DataGovernanceCertified.IsSelected().ToString());
            return WireInstructions;


        }

        //
        //
        public List<LicenseInfoParameters> GetLicenseInfo(string ID="")
        {
            this.WaitForScreenToLoad();

            List<LicenseInfoParameters> AllLicenses = new List<LicenseInfoParameters>();

                for (int i = 1; i <= LicenseInformationTable.GetRowCount(); i++)
                {
                    LicenseInfoParameters LicenseInfo = new LicenseInfoParameters
                    {
                        LicenseId = string.Empty,
                        LicenseState = string.Empty,
                        LicenseCounty = string.Empty,
                        LicenseType = string.Empty,
                        LicenseStatus = string.Empty,
                    };
                    LicenseInfo.LicenseId = LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    LicenseInfo.LicenseState = LicenseInformationTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                    LicenseInfo.LicenseCounty = LicenseInformationTable.PerformTableAction(i, 3, TableAction.GetText).Message;
                    LicenseInfo.LicenseType = LicenseInformationTable.PerformTableAction(i, 4, TableAction.GetText).Message;
                    LicenseInfo.LicenseStatus = LicenseInformationTable.PerformTableAction(i, 5, TableAction.GetText).Message;
                    if (!string.IsNullOrEmpty(ID))
                    {
                        if (LicenseInfo.LicenseId.Equals(ID))
                        {
                            AllLicenses.Add(LicenseInfo);
                            break;
                        }
                    }
                    else
                    {
                        AllLicenses.Add(LicenseInfo);
                    }


            }

            return AllLicenses;
        }

        //
        //
        public LicenseInfoParameters CreateNewLicense(string State, string StateLicenseType, string County = "", string CoLicenseType = "")
        {
            try
            {
                this.WaitForScreenToLoad();
                LicenseInfoParameters LicenseInfo = new LicenseInfoParameters();
                this.LicenseInformationNew.FAClick();
                Thread.Sleep(2000);
                string ID = FastDriver.LicenseInformationDlg.CreateNewLicense(State, StateLicenseType, County, CoLicenseType);
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.LicenseInformationTable.GetRowCount(); i++)
                {
                    string Act_ID = this.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (Act_ID.Contains(ID))
                    {
                        LicenseInfo = GetLicenseInfo(ID)[0];
                        break;
                    }
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);
                return LicenseInfo;
            }
            catch
            {
                throw;
            }

        }

        //
        public bool CreateNMLS()
        {
            try
            {
                this.WaitForScreenToLoad();
                this.LicenseInformationNew.FAClick();
                Thread.Sleep(2000);
                FastDriver.LicenseInformationDlg.WaitForScreenToLoad();
                Random RanNum = new Random(2351674);
                FastDriver.LicenseInformationDlg.ID.FASetText(RanNum.Next().ToString());
                string ID = FastDriver.LicenseInformationDlg.ID.FAGetText();
                FastDriver.LicenseInformationDlg.NMLS.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.LicenseInformationTable.GetRowCount(); i++)
                {
                    string Act_ID = this.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (Act_ID.Equals(ID))
                        return true;
                }
                return false;
            }
            catch

            {
                throw;
            }
        }
        //

        public BusPartyOrgSetUp ClickVersion()
        {
            this.Version.FAClick();
            this.WaitForScreenToLoad();
            return this;
        }
    }
}
