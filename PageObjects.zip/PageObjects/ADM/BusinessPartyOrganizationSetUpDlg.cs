using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusinessPartyOrganizationSetUpDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnAddModContact")]
		public IWebElement AddModifyContact { get; set; }

		[FindsBy(How = How.Id, Using = "cmdViewAddContacts")]
		public IWebElement ViewAddContacts { get; set; }

		[FindsBy(How = How.Id, Using = "cboBuyerSellerType")]
		public IWebElement BuyerSellerType { get; set; }

		[FindsBy(How = How.Id, Using = "cboEntityType")]
		public IWebElement EntityType { get; set; }

		[FindsBy(How = How.Id, Using = "cboGrade")]
		public IWebElement Grade { get; set; }

		[FindsBy(How = How.Id, Using = "txtIDCode")]
		public IWebElement IDCode { get; set; }

		[FindsBy(How = How.Id, Using = "chkManual")]
		public IWebElement Manual { get; set; }

		[FindsBy(How = How.Id, Using = "txtName1")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtName2")]
		public IWebElement Name2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtLocDesc")]
		public IWebElement LocDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtTaxId")]
		public IWebElement TaxId { get; set; }

		[FindsBy(How = How.Id, Using = "cboPrimaryContact")]
		public IWebElement PrimaryContact { get; set; }

		[FindsBy(How = How.Id, Using = "cboTitleAgentType")]
		public IWebElement TitleAgentType { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "txtEntryInstructions")]
		public IWebElement EntryInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressCopy")]
		public IWebElement Copy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressDelete")]
		public IWebElement Delete { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_cmdAdd")]
		public IWebElement Apply { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboAddressType")]
		public IWebElement AddressType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine1")]
		public IWebElement AddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine2")]
		public IWebElement AddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine3")]
		public IWebElement AddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine4")]
		public IWebElement AddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCity")]
		public IWebElement AddressCity { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboState")]
		public IWebElement AddressState { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textZip")]
		public IWebElement AddressZip { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCounty")]
		public IWebElement AddressCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboCountry")]
		public IWebElement AddressCountry { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_chkEmailStatus")]
		public IWebElement StatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdAddPhoneType")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdDeletePhoneEntry")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement BusinessPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textNumber")]
		public IWebElement BusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textExtension")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textComments")]
		public IWebElement BusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement BusinessFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textNumber")]
		public IWebElement BusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textExtension")]
		public IWebElement BusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textComments")]
		public IWebElement BusinessFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement EmailType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textNumber")]
		public IWebElement EmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textComments")]
		public IWebElement EmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement PagerType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textNumber")]
		public IWebElement PagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textExtension")]
		public IWebElement PagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textComments")]
		public IWebElement PagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement CellularType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textNumber")]
		public IWebElement CellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textExtension")]
		public IWebElement CellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textComments")]
		public IWebElement CellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement HomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textNumber")]
		public IWebElement HomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textExtension")]
		public IWebElement HomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textComments")]
		public IWebElement HomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement HomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textNumber")]
		public IWebElement HomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textExtension")]
		public IWebElement HomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textComments")]
		public IWebElement HomeFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "txtAdminComments")]
		public IWebElement AdminComments { get; set; }

		[FindsBy(How = How.Id, Using = "cboStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "cmdcancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddress_dgridAddress")]
		public IWebElement AddressTable { get; set; }

		#endregion

        #region Useful Method
        public BusinessPartyOrganizationSetUpDlg WaitForScreenToLoad(string windowName = "Add to GAB", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? IDCode);
            return this;
        }
        #endregion

    }
}
