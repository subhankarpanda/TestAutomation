using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusPartyOrgHoriRegionalGABRecDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboCorporateParent")]
		public IWebElement RegionalGABRecordCorporateParent { get; set; }

		[FindsBy(How = How.Id, Using = "chkStremLine")]
		public IWebElement RegionalGABRecordStreamLineProcess { get; set; }

		[FindsBy(How = How.Id, Using = "cboBuyerSellerType")]
		public IWebElement RegionalGABRecordBuyerSellerType { get; set; }

		[FindsBy(How = How.Id, Using = "cboEntityType")]
		public IWebElement RegionalGABRecordEntityType { get; set; }

		[FindsBy(How = How.Id, Using = "cboGrade")]
		public IWebElement RegionalGABRecordGrade { get; set; }

		[FindsBy(How = How.Id, Using = "txtIDCode")]
		public IWebElement RegionalGABRecordIDCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtName1")]
		public IWebElement RegionalGABRecordName1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtName2")]
		public IWebElement RegionalGABRecordName2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtLocDesc")]
		public IWebElement RegionalGABRecordLocDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtTaxId")]
		public IWebElement RegionalGABRecordTaxIdNumber { get; set; }

		[FindsBy(How = How.Id, Using = "cboPrimaryContact")]
		public IWebElement RegionalGABRecordPrimaryContact { get; set; }

		[FindsBy(How = How.Id, Using = "cboTitleAgentType")]
		public IWebElement RegionalGABRecordTitleAgentType { get; set; }

		[FindsBy(How = How.Id, Using = "cboTitleOfficer")]
		public IWebElement RegionalGABRecordTitleOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "cboEscrowOfficer")]
		public IWebElement RegionalGABRecordEscrowOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "cboSalesRep1")]
		public IWebElement RegionalGABRecordSalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "cboSalesRep2")]
		public IWebElement RegionalGABRecordSalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement RegionalGABRecordComments { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressNew")]
		public IWebElement RegionalGABRecordAddressesNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressCopy")]
		public IWebElement RegionalGABRecordAddressesCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressDelete")]
		public IWebElement RegionalGABRecordAddressesDelete { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_cmdAdd")]
		public IWebElement RegionalGABRecordAddressesApply { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboAddressType")]
		public IWebElement RegionalGABRecordAddressType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine1")]
		public IWebElement RegionalGABRecordAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine2")]
		public IWebElement RegionalGABRecordAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine3")]
		public IWebElement RegionalGABRecordAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine4")]
		public IWebElement RegionalGABRecordAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCity")]
		public IWebElement RegionalGABRecordCity { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboState")]
		public IWebElement RegionalGABRecordState { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textZip")]
		public IWebElement RegionalGABRecordZip { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCounty")]
		public IWebElement RegionalGABRecordCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboCountry")]
		public IWebElement RegionalGABRecordCountry { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_chkEmailStatus")]
		public IWebElement RegionalGABRecordStatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdAddPhoneType")]
		public IWebElement RegionalGABRecordPhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdDeletePhoneEntry")]
		public IWebElement RegionalGABRecordPhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement RegionalGABRecordBusinessPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textNumber")]
		public IWebElement RegionalGABRecordBusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textExtension")]
		public IWebElement RegionalGABRecordBusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textComments")]
		public IWebElement RegionalGABRecordBusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement RegionalGABRecordBusinessFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textNumber")]
		public IWebElement RegionalGABRecordBusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textExtension")]
		public IWebElement RegionalGABRecordBusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textComments")]
		public IWebElement RegionalGABRecordBusinessFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement RegionalGABRecordEmailType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textNumber")]
		public IWebElement RegionalGABRecordEmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textComments")]
		public IWebElement RegionalGABRecordEmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement RegionalGABRecordCellularType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textNumber")]
		public IWebElement RegionalGABRecordCellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textExtension")]
		public IWebElement RegionalGABRecordCellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textComments")]
		public IWebElement RegionalGABRecordCellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement RegionalGABRecordPagerType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textNumber")]
		public IWebElement RegionalGABRecordPagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textExtension")]
		public IWebElement RegionalGABRecordPagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textComments")]
		public IWebElement RegionalGABRecordPagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement RegionalGABRecordHomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textNumber")]
		public IWebElement RegionalGABRecordHomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textExtension")]
		public IWebElement RegionalGABRecordHomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textComments")]
		public IWebElement RegionalGABRecordHomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement RegionalGABRecordHomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textNumber")]
		public IWebElement RegionalGABRecordHomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textExtension")]
		public IWebElement RegionalGABRecordHomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textComments")]
		public IWebElement RegionalGABRecordHomeFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "txtAdminComments")]
		public IWebElement RegionalGABRecordGABProcessingComments { get; set; }

		[FindsBy(How = How.Id, Using = "cboStatus")]
		public IWebElement RegionalGABRecordStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDone")]
		public IWebElement RegionalGABRecordDone { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement RegionalGABRecordLicenseInformationNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnEdit")]
        public IWebElement RegionalGABRecordLicenseInformationEdit { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement RegionalGABRecordLicenseInformationTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddModContact")]
        public IWebElement RegionalGABRecordAddModifyContact { get; set; }

        #endregion

        public BusPartyOrgHoriRegionalGABRecDlg WaitForScreenToLoad(IWebElement element = null)
        {
            Playback.Wait(5000);        //Needs to explicity wait to load the dlg
            this.SwitchToDialogLeftContentFrame();
            this.WaitCreation(element ?? RegionalGABRecordCorporateParent);

            return this;
        }

    }
	public class BusPartyOrgHoriGABEntryReqDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboBuyerSellerType")]
		public IWebElement GABEntryRequestBuyerSellerType { get; set; }

		[FindsBy(How = How.Id, Using = "cboEntityType")]
		public IWebElement GABEntryRequestEntityType { get; set; }

		[FindsBy(How = How.Id, Using = "cboGrade")]
		public IWebElement GABEntryRequestGrade { get; set; }

		[FindsBy(How = How.Id, Using = "txtIDCode")]
		public IWebElement GABEntryRequestIDCode { get; set; }

		[FindsBy(How = How.Id, Using = "chkManual")]
		public IWebElement GABEntryRequestManual { get; set; }

		[FindsBy(How = How.Id, Using = "txtName1")]
		public IWebElement GABEntryRequestName1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtName2")]
		public IWebElement GABEntryRequestName2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtLocDesc")]
		public IWebElement GABEntryRequestLocDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtTaxId")]
		public IWebElement GABEntryRequestTaxIdNumber { get; set; }

		[FindsBy(How = How.Id, Using = "cboPrimaryContact")]
		public IWebElement GABEntryRequestPrimaryContact { get; set; }

		[FindsBy(How = How.Id, Using = "cboTitleAgentType")]
		public IWebElement GABEntryRequestTitleAgentType { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement GABEntryRequestBusOrgComments { get; set; }

		[FindsBy(How = How.Id, Using = "txtEntryInstructions")]
		public IWebElement GABEntryRequestEntryInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressNew")]
		public IWebElement GABEntryRequestAddressesNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressCopy")]
		public IWebElement GABEntryRequestAddressesCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddressDelete")]
		public IWebElement GABEntryRequestAddressesDelete { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_cmdAdd")]
		public IWebElement GABEntryRequestAddressesApply { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboAddressType")]
		public IWebElement GABEntryRequestAddressType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine1")]
		public IWebElement GABEntryRequestAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine2")]
		public IWebElement GABEntryRequestAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine3")]
		public IWebElement GABEntryRequestAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine4")]
		public IWebElement GABEntryRequestAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCity")]
		public IWebElement GABEntryRequestCity { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboState")]
		public IWebElement GABEntryRequestState { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textZip")]
		public IWebElement GABEntryRequestZip { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCounty")]
		public IWebElement GABEntryRequestCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboCountry")]
		public IWebElement GABEntryRequestCountry { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_chkEmailStatus")]
		public IWebElement GABEntryRequestStatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdAddPhoneType")]
		public IWebElement GABEntryRequestPhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_cmdDeletePhoneEntry")]
		public IWebElement GABEntryRequestPhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement GABEntryRequestBusinessPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textNumber")]
		public IWebElement GABEntryRequest_BusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textExtension")]
		public IWebElement GABEntryRequest_BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_0_textComments")]
		public IWebElement GABEntryRequest_BusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement GABEntryRequest_BusinessFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textNumber")]
		public IWebElement GABEntryRequestBusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textExtension")]
		public IWebElement GABEntryRequestBusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_1_textComments")]
		public IWebElement GABEntryRequestBusinessFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement GABEntryRequestEmailType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textNumber")]
		public IWebElement GABEntryRequestEmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_2_textComments")]
		public IWebElement GABEntryRequestEmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement GABEntryRequestPagerType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textNumber")]
		public IWebElement GABEntryRequestPagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textExtension")]
		public IWebElement GABEntryRequestPagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_3_textComments")]
		public IWebElement GABEntryRequestPagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement GABEntryRequestCellularType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textNumber")]
		public IWebElement GABEntryRequestCellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textExtension")]
		public IWebElement GABEntryRequestCellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_4_textComments")]
		public IWebElement GABEntryRequestCellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement GABEntryRequestHomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textNumber")]
		public IWebElement GABEntryRequestHomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textExtension")]
		public IWebElement GABEntryRequestHomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_5_textComments")]
		public IWebElement GABEntryRequestHomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement GABEntryRequestHomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textNumber")]
		public IWebElement GABEntryRequestHomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textExtension")]
		public IWebElement GABEntryRequestHomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ctlPhoneTypes_dgridPhoneTypes_6_textComments")]
		public IWebElement GABEntryRequestHomeFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "txtAdminComments")]
		public IWebElement GABEntryRequestGABProcessingComments { get; set; }

		[FindsBy(How = How.Id, Using = "cboStatus")]
		public IWebElement GABEntryRequestStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDone")]
		public IWebElement GABEntryRequestDone { get; set; }

        #endregion

        public BusPartyOrgHoriGABEntryReqDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogRightContentFrame();
            this.WaitCreation(element ?? GABEntryRequestBuyerSellerType);

            return this;
        }

    }
}
