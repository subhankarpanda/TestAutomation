using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusPartyOrgeSubscriptionsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "gdesubInfo_0_flgeSubscriptions")]
		public IWebElement ePayoff { get; set; }

		[FindsBy(How = How.Id, Using = "gdesubInfo_1_flgeSubscriptions")]
		public IWebElement eTitlePolicyDelivery { get; set; }

		#endregion

        public BusPartyOrgeSubscriptionsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? ePayoff);

            return this;
        }
	}
}
