using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusPartyOrg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdViewChangeStatus")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBusinessOrganizationsList")]
		public IWebElement AdditionalLocationTable { get; set; }

		#endregion

        #region Useful Methods
        public void ClickOnNew()
        {
            WaitForScreenToLoad();
            New.FAClick();
            FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad(FastDriver.BusinessPartyOrganizationSetUp.IDCode);
        }

        public BusPartyOrg WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New);
            return this;
        }
        #endregion
    }
}
