﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Threading;

namespace FASTSelenium.PageObjects.ADM
{
    public class BusinessUnitRoleAssignment : PageObject
    {
        int waitTime = Convert.ToInt32(AutoConfig.WaitTime);
        #region WebElements

        [FindsBy(How = How.Id, Using = "lblEmpname")]
        public IWebElement EmployeeNameLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@onclick,'213')]")]
        public IWebElement AssociatiatedRoleExpandIcon { get; set; }

        [FindsBy(How = How.Id, Using = "btnBUAddRemove")]
        public IWebElement AddRemoveBusinessUnitsButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnRoleAddRemove")]
        public IWebElement AddRemoveRolesButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnReset")]
        public IWebElement ResetButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement SaveButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement DoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgBus_dgBus")]
        public IWebElement BusinessUnitsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgBus_dgBus")]
        public IWebElement AssignedBusinessUnitsTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement ExpandIcon { get; set; }

        [FindsBy(How = How.Id, Using = "dgRoles_dgRoles")]
        public IWebElement AssociatedRolesTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement RoleExpandIcon { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement ExpandRoles { get; set; }

        [FindsBy(How = How.LinkText, Using = "Work Queue Maintenance and Assignment")]
        public IWebElement WorkQueueRole { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement RoleExpandIcon1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "New File Entry")]
        public IWebElement NFERole { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement ExpandIconRegion { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement RoleExpandIcon2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement ExpandSection { get; set; }

        #endregion

        public BusinessUnitRoleAssignment WaitForScreenToLoad(IWebElement element=null, int timeOut=25)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? BusinessUnitsTable, waitTime);
            return this;
        }


        public void SelectBusinessUnit(string bUID = "", string businessUnitName="")
        {
            //IWebElement cellInnerElements = null;
            try
            {
                bool isExpanded = false;
                if (!string.IsNullOrEmpty(bUID))
                {
                    BusinessUnitsTable.PerformTableAction(2, bUID, 2, TableAction.Click).Element.FindElement(By.XPath(".//preceding-sibling::td[1]//img")).FAClick(); ;
                    isExpanded = true;
                }
                else
                {
                    BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedRegionBUID, 2, TableAction.Click).Element.FindElement(By.XPath(".//preceding-sibling::td[1]//img")).FAClick(); 
                    isExpanded = true;
                }
                if (!string.IsNullOrEmpty(businessUnitName) && !isExpanded)
                {
                    BusinessUnitsTable.PerformTableAction(4, businessUnitName, 4, TableAction.Click).Element.FindElement(By.XPath(".//preceding-sibling::td[1]//img")).FAClick();
                }
                this.WaitForScreenToLoad();
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            
            
        }

        public void SelectOfficeUnderBusinessUnits(string officeBUID = "", string officeName = "")
        {
            bool isExpanded = false;
            if (!string.IsNullOrEmpty(officeBUID))
            {
                BusinessUnitsTable.PerformTableAction(2, officeBUID, 2, TableAction.Click);
            }
            else
            {
                BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeBUID, 2, TableAction.Click);
            }

            if (!string.IsNullOrEmpty(officeName) && !isExpanded)
            {
                BusinessUnitsTable.PerformTableAction(2, officeBUID, 1, TableAction.Click).Element.FindElement(By.TagName("IMG")).FAClick();
                this.WaitForScreenToLoad();
                BusinessUnitsTable.PerformTableAction(4, officeName, 4, TableAction.Click);
                isExpanded = true;
            }
            else
            {
                try
                {
                    BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeBUID, 1, TableAction.Click).Element.FindElement(By.TagName("IMG")).FAClick();
                }
                catch
                {
                    Reports.StatusUpdate("Already expanded", true);
                }
                    this.WaitForScreenToLoad();
                    BusinessUnitsTable.PerformTableAction(4, AutoConfig.SelectedOfficeName, 4, TableAction.Click);
                
            }

            this.WaitForScreenToLoad();
        }

        public void SelectOfficeUnderBusinessUnits_(string officeBUID = "", string officeName = "")
        {
            bool isExpanded = false;
            if (!string.IsNullOrEmpty(officeBUID))
            {
                BusinessUnitsTable.PerformTableAction(2, officeBUID, 2, TableAction.Click);
                isExpanded = true;
            }
            else
            {
                BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeBUID, 2, TableAction.Click);
                isExpanded = true;
            }
            if (!string.IsNullOrEmpty(officeName) && !isExpanded)
            {
                BusinessUnitsTable.PerformTableAction(4, officeName, 4, TableAction.Click);
                isExpanded = true;
            }
            else if (!isExpanded)
            {
                BusinessUnitsTable.PerformTableAction(2, AutoConfig.SelectedOfficeName, 2, TableAction.Click);
            }
            this.WaitForScreenToLoad();
        }
        //
      /*  public bool SelectRole(string roleGroup, string roleName)
        {
            try
            {
                this.WaitCreation(AssociatedRolesTable);
                AssociatedRolesTable.PerformTableAction(2, roleGroup, 2, TableAction.Click).Element.FindElement(By.XPath(".//preceding-sibling::td[1]//img")).FAClick();
                var element = AssociatedRolesTable.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Clean() == roleName);
                //var element1 = AssociatedRolesTable.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Trim() == roleName && p.IsVisible());//adding IsVisible() throws error "Couldn't find By attribute for element.
               
                if (element == null)
                    return false;
               
            }
            catch(Exception e)
            {
                Reports.StatusUpdate("Method:SelectRole()\n\r Error : "+e.Message, false);
                return false;
            }
            return true;
        }*/

        public bool CheckActivityRightInRole(string RoleName, string ActivityRight)
        {
            try
            {
                this.WaitCreation(AssociatedRolesTable);
                AssociatedRolesTable.PerformTableAction(2, RoleName, 2, TableAction.Click).Element.FindElement(By.XPath(".//preceding-sibling::td[1]//img")).FAClick();
                var elemnt = AssociatedRolesTable.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Clean() == ActivityRight);
                //var element1 = AssociatedRolesTable.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Trim() == roleName && p.IsVisible());//adding IsVisible() throws error "Couldn't find By attribute for element.
                    if(elemnt!=null)
                        return true;
                    else
                        return false;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Method:CheckActivityRightInRole() in BusinessUnitRoleAssignment screen. \n\r Error : " + ex.Message, false);
                return false;
            }
        }
        //
        public bool isRolePresentWithRequiredActivityRight(string Role, string ActivityRight)
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<EmployeeSecurity>(@"Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.SearchAndSelectEmployee(@"fastts\fastqa07");
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
                FastDriver.BusinessUnitRoleAssignment.SelectOfficeUnderBusinessUnits(AutoConfig.SelectedOfficeBUID);
                bool isActivityRightPresent = FastDriver.BusinessUnitRoleAssignment.CheckActivityRightInRole(Role, ActivityRight);
                return isActivityRightPresent;
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return false;
            }
        }
        //
        public void ExpandTheRoles(string RegionBUID, string OfficeBUID)
        {
            FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
            IWebElement ExpandParent = FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("BUID", RegionBUID, "#1", TableAction.GetCell).Element;
            IWebElement Expand = ExpandParent.FindElement(By.TagName("img"));
            for (int i = 0; i < 7; i++)
            {
                Expand.FAClick();
                System.Threading.Thread.Sleep(3000);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                if (FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.FAGetText().Contains(OfficeBUID))
                {
                    FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("BUID", OfficeBUID, "BUID", TableAction.Click);
                    FastDriver.BusinessUnitRoleAssignment.WaitCreation(FastDriver.BusinessUnitRoleAssignment.AssociatedRolesTable);

                    break;
                }
            }
        }

        public void ExpandAssociatedRole(string RoleName)
        {
            FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
            try
            {
                IWebElement ParentElement = FastDriver.BusinessUnitRoleAssignment.AssociatedRolesTable.PerformTableAction(2, RoleName, 1, TableAction.GetCell).Element;
                IWebElement ExpandIcon = ParentElement.FindElement(By.XPath("./img"));
                ExpandIcon.Click();
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        //
        public List<IWebElement> roles;
        public List<IWebElement> RemoveAssociatedRolesforfastqa06()
        {
              List<IWebElement> roles;

               FastDriver.LeftNavigation.Navigate<EmployeeSecurity>(@"Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText("fastts\\fastqa06");
                FastDriver.EmployeeSecurity.RegionDropdown.FASelectItem("QA Automation Region - DO NOT TOUCH");
                FastDriver.EmployeeSecurity.SearchNowButton.FAClick();
                FastDriver.EmployeeSecurity.WaitForScreenToLoad();
                FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction(2, 1, TableAction.DoubleClick);
   
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
               // FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("Name", "QA Automation Region - DO NOT TOUCH", "QA Automation Region - DO NOT TOUCH", TableAction.Click);
                FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
                FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();

                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
                List<IWebElement> rows = FastDriver.RoleSelectionDialog.RolesTable.FindElements(By.TagName("tr")).ToList();
                roles = new List<IWebElement>();
                for (int row = 1; rows.Count - 1 >= row; row++)
                {
                    string chk = rows[row].FindElements(By.TagName("td"))[0].FindElement(By.TagName("input")).GetAttribute("checked");
                    if (chk != null)
                    {

                        rows[row].FindElements(By.TagName("td"))[0].FindElement(By.TagName("input")).FASetCheckbox(false);
                        roles.Add(rows[row].FindElements(By.TagName("td"))[0].FindElement(By.TagName("input")));
                    }
                }
               
                FastDriver.DialogBottomFrame.ClickDone();
               
                Thread.Sleep(3000);
               FastDriver.BottomFrame.Save();

               FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
               FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
               FastDriver.TrackChangeHistoryDialog.DoneButton.JSClick();
               Playback.Wait(1000);
               return roles;
        }
        public void ResetRolesforfastqa06(List<IWebElement> roles)
        {
            
            FastDriver.LeftNavigation.Navigate<EmployeeSecurity>(@"Home>System Maintenance>Security Maintenance>Employee Security").WaitForScreenToLoad();
            FastDriver.EmployeeSecurity.LoginNameTextbox.FASetText("fastts\\fastqa06");
            FastDriver.EmployeeSecurity.RegionDropdown.FASelectItem("QA Automation Region - DO NOT TOUCH");
            FastDriver.EmployeeSecurity.SearchNowButton.FAClick();
            FastDriver.EmployeeSecurity.WaitForScreenToLoad();
            FastDriver.EmployeeSecurity.ResultsTable.PerformTableAction(2, 1, TableAction.DoubleClick);

            FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
            FastDriver.BusinessUnitRoleAssignment.SelectBusinessUnit(AutoConfig.SelectedRegionBUID);
            // FastDriver.BusinessUnitRoleAssignment.BusinessUnitsTable.PerformTableAction("Name", "QA Automation Region - DO NOT TOUCH", "QA Automation Region - DO NOT TOUCH", TableAction.Click);
            FastDriver.BusinessUnitRoleAssignment.WaitForScreenToLoad();
            FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();

            FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
            if (roles.Count > 0)
            {
                foreach (IWebElement role in roles)
                {

                    role.FASetCheckbox(true);
                }
            }

            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(8000);
            FastDriver.BottomFrame.Save();
            Thread.Sleep(1000);
            FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
            FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
            FastDriver.TrackChangeHistoryDialog.DoneButton.JSClick();
        }

        //public BusinessUnitRoleAssignment ClickBUID(string BUID)
        //{
        //    this.SwitchToContentFrame();
        //    this.WaitCreation(BusinessUnitsTable);
        //    BusinessUnitsTable.PerformTableAction(2, BUID, 3, TableAction.Click);
        //    
        //    return this;
        //}

        //public RoleSelectionDialog ClickAddBusinessRoles()
        //{
        //    this.SwitchToContentFrame();
        //    AddRemoveRolesButton.Click();
        //    
        //    return FastDriver.GetPage<RoleSelectionDialog>();
        //}

        //public BusinessUnitRoleAssignment ClickDone()
        //{
        //    this.SwitchToBottomFrame();
        //    this.WaitCreation(DoneButton);
        //    DoneButton.Click();
        //    
        //    return this;
        //}

        public void AddRole()
        {
            FastDriver.BusinessUnitRoleAssignment.AddRemoveRolesButton.FAClick();
            Thread.Sleep(15000);
            FastDriver.RoleSelectionDialog.WaitForScreenToLoad();

            FastDriver.RoleSelectionDialog.WaitForScreenToLoad();
            List<IWebElement> rows = FastDriver.RoleSelectionDialog.RolesTable.FindElements(By.TagName("tr")).ToList();
            List<IWebElement> roles = new List<IWebElement>();
            for (int row = 1; rows.Count - 1 >= row; row++)
            {
                string chk = rows[row].FindElements(By.TagName("td"))[0].FindElement(By.TagName("input")).GetAttribute("checked");
                if (chk != null)
                {

                    rows[row].FindElements(By.TagName("td"))[0].FindElement(By.TagName("input")).FASetCheckbox(false);
                    roles.Add(rows[row].FindElements(By.TagName("td"))[0].FindElement(By.TagName("input")));
                }
            }

            FastDriver.DialogBottomFrame.ClickDone();
        }

        #region dynamic WebElements
        public IWebElement ExpandButton(int ExpandRowIndex)
        {
            return FastDriver.WebDriver.FindElement(By.CssSelector("#dgBus_dgBus tr:nth-child(" + ExpandRowIndex + ") img"));
        }

        #endregion
    }
}