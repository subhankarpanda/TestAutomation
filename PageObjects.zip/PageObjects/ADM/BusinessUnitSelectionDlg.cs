using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class BusinessUnitSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlRegions")]
		public IWebElement SelectaRegions { get; set; }

		[FindsBy(How = How.Id, Using = "optOfficeGroup")]
		public IWebElement OfficeGroup { get; set; }

		[FindsBy(How = How.Id, Using = "optOffice")]
		public IWebElement Offices { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_dgBus")]
		public IWebElement BussinesUnitTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgBus_dgBus")]
        public IWebElement AvailableBussinesUnitsTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdChkAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemoveAll")]
		public IWebElement ClearAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "btnRefresh")]
		public IWebElement Refresh { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelBus_0_chkAssign")]
		public IWebElement Assignment { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelBus_0_chkAssociate")]
		public IWebElement Associate { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_0_chkSelect")]
		public IWebElement AvailableBusiness1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_0_lblBUID")]
		public IWebElement AvailableBusiness1BUID { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_0_lblCode")]
		public IWebElement AvailableBusiness1Code { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_1_chkSelect")]
		public IWebElement AvailableBusiness2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_1_lblBUID")]
		public IWebElement AvailableBusiness2BUID { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_1_lblCode")]
		public IWebElement AvailableBusiness2Code { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelBus_dgSelBus")]
		public IWebElement SelectedBUTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelBus_0_chkAssign")]
		public IWebElement SelectedBusiness1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelBus_1_chkAssign")]
		public IWebElement SelectedBusiness2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelBus_0_chkAssociate")]
		public IWebElement AssociatedBusiness1 { get; set; }

        #endregion


        #region Useful Methods
        public BusinessUnitSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Add);
            return this;
        }

        public bool VerifyBUisSelected(string businessUnit)
        {
            WaitForScreenToLoad();
            return SelectedBUTable.FAGetText().Contains(businessUnit) ? true : false;
        }
        #endregion
    }
}
