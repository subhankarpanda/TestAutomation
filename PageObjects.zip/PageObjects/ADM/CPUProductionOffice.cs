using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class CPUProductionOffice : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgOfficeDetails")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement AddNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "cboProductionOffice")]
		public IWebElement ProductionOffice { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }

		[FindsBy(How = How.Id, Using = "txtDeliveryAddress")]
		public IWebElement DeliveryAddress { get; set; }

        #endregion

        public CPUProductionOffice WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Table);
            return this;
        }
    }
}
