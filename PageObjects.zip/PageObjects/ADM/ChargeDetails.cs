using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ChargeDetails : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboProcessType")]
		public IWebElement ProcessType { get; set; }

		[FindsBy(How = How.Id, Using = "rblHUDType_0")]
		public IWebElement HUDTypeAll { get; set; }

		[FindsBy(How = How.Id, Using = "rblHUDType_1")]
		public IWebElement HUDTypeHud { get; set; }

		[FindsBy(How = How.Id, Using = "rblHUDType_2")]
		public IWebElement HUDTypeLegacy { get; set; }

		[FindsBy(How = How.Id, Using = "cboHUDType")]
		public IWebElement HUDType { get; set; }

		[FindsBy(How = How.Id, Using = "chkStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "chkChargeOnly")]
		public IWebElement ChargeOnly { get; set; }

		[FindsBy(How = How.Id, Using = "chkAdhoc")]
		public IWebElement AdhocChargeEntry { get; set; }

		[FindsBy(How = How.Id, Using = "chkDaysOf")]
		public IWebElement DaysOfClosePaidbySeller { get; set; }

		[FindsBy(How = How.Id, Using = "txtChargeDescr")]
		public IWebElement ChargeDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtChargeCode")]
		public IWebElement ChargeCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtBuyerChrg")]
		public IWebElement BuyerCharges { get; set; }

		[FindsBy(How = How.Id, Using = "txtBuyerCrdt")]
		public IWebElement BuyerCredits { get; set; }

		[FindsBy(How = How.Id, Using = "txtSellerChrg")]
		public IWebElement SellerCharges { get; set; }

		[FindsBy(How = How.Id, Using = "txtSellerCrdt")]
		public IWebElement SellerCredits { get; set; }

		[FindsBy(How = How.Id, Using = "chkEditDesc")]
		public IWebElement EditDescription { get; set; }

		[FindsBy(How = How.Id, Using = "chkBuyerChrg")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "chkBuyerCrdt")]
		public IWebElement BuyerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "chkSellerChrg")]
		public IWebElement SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "chkSellerCrdt")]
		public IWebElement SellerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "cboGFEDefault")]
		public IWebElement GFEDefault { get; set; }

		[FindsBy(How = How.Id, Using = "chkEditGFE")]
		public IWebElement EditGFE { get; set; }

		[FindsBy(How = How.Id, Using = "chkLSPDefault")]
		public IWebElement LenderSelectedProviderDefault { get; set; }

		[FindsBy(How = How.Id, Using = "chkEditProvider")]
		public IWebElement EditProvider { get; set; }

		[FindsBy(How = How.Id, Using = "cboPaymentType")]
		public IWebElement DefaultPaymentMethod { get; set; }

		[FindsBy(How = How.LinkText, Using = "Special Charges")]
		public IWebElement SpecialCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "Standard/Miscellaneous Charges")]
		public IWebElement StandardMislaneousCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "Interest Charges")]
		public IWebElement InterestCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "Impound Charges")]
		public IWebElement ImpoundCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "Prorate Charges")]
		public IWebElement ProrateCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "Itemized Charges")]
		public IWebElement ItemizedCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "1200 Section RBL Charges")]
		public IWebElement SectionRBLCharges { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous 104 Charges")]
		public IWebElement Mislaneous104Charges { get; set; }

		[FindsBy(How = How.LinkText, Using = "POC Items ")]
		public IWebElement POCItems { get; set; }

		#endregion

	}
}
