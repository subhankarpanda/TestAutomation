using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ChngHistDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridTemplateEvents_dgridTemplateEvents")]
		public IWebElement ChangeHistory { get; set; }

		[FindsBy(How = How.Id, Using = "dgridNotificationEvents_0_lblEvent")]
		public IWebElement Events { get; set; }

		#endregion

	}
}
