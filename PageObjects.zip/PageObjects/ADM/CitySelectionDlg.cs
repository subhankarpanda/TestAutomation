﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class CitySelectionDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "btnCheckAll")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdCounty_grdCounty")]
        public IWebElement CityTable { get; set; }
        #endregion

        #region Useful Methods
        public CitySelectionDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(CityTable);
            return this;
        }
        #endregion
    }

}
