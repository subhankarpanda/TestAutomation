﻿#region SRT-ServReq
//Team                  :  ServReq-Team1
//Iteration             :  r08
//UserStory             :  User Story 815236
//TestCase              :  830103,830795,838861
//Appended By/ Created By: Osama
using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class CommentCodeDlg : PageObject
    {

        #region WebElements
        [FindsBy(How = How.Id, Using = "dgridTTCommentCode_dgridTTCommentCode")]
        public IWebElement CommentCodeTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkCommentCodeRequired")]
        public IWebElement CommentCodeRequired { get; set; }


        #endregion

        public CommentCodeDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? CommentCodeTable);
            return this;
        }
    }
}
#endregion