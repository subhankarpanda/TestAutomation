﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class CommentCodeSearchDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtFind")]
        public IWebElement FindField { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNext")]
        public IWebElement FindNextButton { get; set; }

        [FindsBy(How = How.Id, Using = "chkWholeWord")]
        public IWebElement WholeWordCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "rdUp")]
        public IWebElement UpRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "rdDown")]
        public IWebElement DownRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "chkMatchCase")]
        public IWebElement MatchCaseCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement CancelButton { get; set; }
        #endregion

        #region Methods

        public CommentCodeSearchDlg WaitForScreenToLoad(string windowName = "Select Comment Code")
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(FindField);
            return this;
        }

        #endregion
    }
}
