﻿#region SRT-ServReq
//Team                  :  ServReq-Team1
//Iteration             :  r08
//UserStory             :  User Story 815236
//TestCase              :  830103,830795,838861
//Appended By/ Created By: Osama
using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class CommentCodes : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "gridCommentCodeResults")]
        public IWebElement CommentCodeTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnViewChangeStatus")]
        public IWebElement ViewChangeStatus { get; set; }

        #endregion

        public CommentCodes WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }
    }
}
#endregion