using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class CorporateProblemLog : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProbLog_8_txtProbDesc")]
		public IWebElement ProblemDescription { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProbLog")]
		public IWebElement ProblemLogTable { get; set; }

		#endregion


        public CorporateProblemLog WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Add);

            return this;
        }

	}
}
