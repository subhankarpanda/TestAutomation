﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class CorporateProcessSummary : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "chkActiveonly")]
        public IWebElement ActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "cmdRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdView")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProcSummary_dgridProcSummary")]
        public IWebElement ProcessSummaryTable { get; set; }
        #endregion

        #region  Useful Methods
        public CorporateProcessSummary WaitForScreenToLoad(IWebElement element = null)
        {
            Playback.Wait(5000);
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? ProcessSummaryTable);
            return this;
        }

        public CorporateProcessSummary CreateCorpProcess(string processName, string processCategory)
        {
            WaitForScreenToLoad(New);
            WaitForScreenToLoad(ProcessSummaryTable);
            int rowCount = ProcessSummaryTable.GetRowCount();
            Playback.Wait(10000);
            New.FAClick();
            Playback.Wait(5000);
            FastDriver.WebDriver.WaitForActionToComplete(() => {
                    return ProcessSummaryTable.GetRowCount() == (rowCount + 1);
                }, timeout: 120, idleInterval: 2);
            ProcessSummaryTable.PerformTableAction(rowCount, 2, TableAction.SetText, processName);
            ProcessSummaryTable.PerformTableAction(rowCount, 3, TableAction.SelectItemByIndex, "1");
            ProcessSummaryTable.PerformTableAction(rowCount, 4, TableAction.SelectItem, processCategory);
            return this;
        }
        #endregion
    }
}
