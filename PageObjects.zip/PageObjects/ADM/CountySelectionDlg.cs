using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class CountySelectionDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnCheckAll")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdCounty_0_chkSelCounty")]
        public IWebElement grdCounty0SelCounty { get; set; }

        [FindsBy(How = How.Id, Using = "grdCounty_1_chkSelCounty")]
        public IWebElement grdCounty1SelCounty { get; set; }

        [FindsBy(How = How.Id, Using = "grdCounty_10_lblCounty")]
        public IWebElement grdCounty10SelCounty { get; set; }

        [FindsBy(How = How.Id, Using = "grdCounty_grdCounty")]
        public IWebElement Table { get; set; }

        #endregion

        public CountySelectionDlg WaitForScreenToLoad(IWebElement element = null, bool citySelection = false, bool ltRegOfficeSelection = false)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Clear);
            return this;
        }


    }
}
