using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class CustomaryWorkgroups : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdSelectWG")]
		public IWebElement AddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "dgridCustomaryWG")]
        public IWebElement CustomaryWorkgroupTable { get; set; }

		#endregion

        #region Useful Methods
        public CustomaryWorkgroups WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(AddRemove);
            return this;
        }
        #endregion
    }
}
