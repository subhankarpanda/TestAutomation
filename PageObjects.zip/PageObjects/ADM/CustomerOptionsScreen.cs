using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class CustomerOptionsScreen : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkDirectSignTrack")]
		public IWebElement Integrate { get; set; }

		[FindsBy(How = How.Id, Using = "radIndividual")]
		public IWebElement IndividualAttachments { get; set; }

		[FindsBy(How = How.Id, Using = "radGroupAttachments")]
		public IWebElement GroupAttachments { get; set; }

		[FindsBy(How = How.Id, Using = "btnDocumentSequence")]
		public IWebElement Sequence { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddRemoveDocuments")]
		public IWebElement DocumentsAddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "btnImageAddremove")]
		public IWebElement ImagesAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "dgridImages")]
        public IWebElement ImagesTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgriDocuments")]
        public IWebElement DocumentsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@bordercolor='lightgrey']")]
        public IWebElement CustomerOptionsTable { get; set; }


		#endregion

        #region Useful Methods
        public CustomerOptionsScreen WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(DocumentsAddRemove);
            return this;
        }
        #endregion
    }
}
