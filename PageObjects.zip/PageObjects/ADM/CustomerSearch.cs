﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class CustomerSearch : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "custAddress")]
        public IWebElement CustomerAddress { get; set; }

        [FindsBy(How = How.Id, Using = "customer_license")]
        public IWebElement CustomerLicense { get; set; }

        [FindsBy(How = How.Id, Using = "customer_location")]
        public IWebElement LocDescription { get; set; }

        [FindsBy(How = How.Id, Using = "customer_phone")]
        public IWebElement CustomerPhone { get; set; }

        [FindsBy(How = How.Id, Using = "customer_email")]
        public IWebElement CustomerEmail { get; set; }
        

        [FindsBy(How = How.Id, Using = "facetListUl")]
        public IWebElement EntitySearchResult { get; set; }

        [FindsBy(How = How.Id, Using = "CityFacet_wrapper")]
        public IWebElement CitySearchResult { get; set; }
  

        //[FindsBy(How = How.CssSelector, Using = "class=\"custtype ng-binding\"")]
        //public IWebElement Customertype { get; set; }

        [FindsBy(How = How.Id, Using = "custName")]
        public IWebElement custName { get; set; }



        [FindsBy(How = How.Id, Using = "custType")]
        public IWebElement custType { get; set; }


        [FindsBy(How = How.Id, Using = "searchBox")]
        public IWebElement searchBox { get; set; }

        [FindsBy(How = How.Id, Using = "searchbutton")]
        public IWebElement searchbutton { get; set; }

        [FindsBy(How = How.Id, Using = "expandCustomer")]
        public IWebElement ExpandCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "customer_status")]
        public IWebElement CustomerStatus { get; set; }

        [FindsBy(How = How.Id, Using = "search_suggest")]
        public IWebElement AutoSuggestion { get; set; }

        [FindsBy(How = How.Id, Using = "customer_code")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "searchsortorder")]
        public IWebElement Sortby { get; set; }

        [FindsBy(How = How.Id, Using = "resultdiv")]
        public IWebElement ResultPage { get; set; }

        [FindsBy(How = How.Id, Using = "showhideFavArrow")]
        public IWebElement OpenFavorite { get; set; }

        [FindsBy(How = How.Id, Using = "showHideFavImage")]
        public IWebElement CloseFavorite { get; set; }

        [FindsBy(How = How.Id, Using = "favSearchBox")]
        public IWebElement favSearchBox { get; set; }



        // Favorite sections        

        //Contact Icon
        [FindsBy(How = How.Id, Using = "expandContacts")]
        public IWebElement ContactIcon { get; set; }

        // Ep/et drop down 
        [FindsBy(How = How.Id, Using = "ePeTfilterlist")]
        public IWebElement eP_eT_Dropdown { get; set; }


        // Michelle 

        [FindsBy(How = How.Id, Using = "favCountSpan")]
        public IWebElement favCountSpan { get; set; }


        [FindsBy(How = How.Id, Using = "removeFromFavorite")]
        public IWebElement removeFromFavorite_list { get; set; }

        [FindsBy(How = How.Id, Using = "removeFavorite")]
        public IWebElement removeFavorite { get; set; }

        //[FindsBy(How = How.Id, Using = "addFavorite")]
        //public IWebElement FavStar { get; set; }

        [FindsBy(How = How.Id, Using = "addFavorite")]
        public IWebElement addFavorite_icon { get; set; }


        [FindsBy(How = How.Id, Using = "favObjectCdId")]
        public IWebElement favObjectCdId { get; set; }


        [FindsBy(How = How.Id, Using = "favCustomerEntityType")]
        public IWebElement favCustomerEntityType { get; set; }


        [FindsBy(How = How.Id, Using = "favCustomerName")]
        public IWebElement favCustomerName { get; set; }

        // active/inactive status list
        [FindsBy(How = How.Id, Using = "statusfilterlist")]
        public IWebElement statusfilterlist { get; set; }

        // Status on result screen


        [FindsBy(How = How.Id, Using = "customer_status")]
        public IWebElement customer_status { get; set; }

        [FindsBy(How = How.Id, Using = "cust_cont_search")]
        public IWebElement cust_contact_searchtextBox { get; set; }

        [FindsBy(How = How.Id, Using = "cont_Name")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "cont_Email")]
        public IWebElement contact_email { get; set; }



        [FindsBy(How = How.Id, Using = "cont_Phone")]
        public IWebElement Contact_bus_phone { get; set; }




        [FindsBy(How = How.Id, Using = "TypeFacet_searchbox")]
        public IWebElement TypeFacet_searchbox { get; set; }

        [FindsBy(How = How.Id, Using = "City_facet_searchbox")]
        public IWebElement City_facet_searchbox { get; set; }

        [FindsBy(How = How.Id, Using = "State_facet_searchbox")]
        public IWebElement State_facet_searchbox { get; set; }

        [FindsBy(How = How.Id, Using = "facetListUl")]
        public IWebElement facetListUl { get; set; }

        [FindsBy(How = How.Id, Using = "EntityType_facet_showHideFacet")]
        public IWebElement EntityType_facet_showHideFacet { get; set; }

        [FindsBy(How = How.Id, Using = "City_facet_showHideFacet")]
        public IWebElement City_facet_showHideFacet_1 { get; set; }

        [FindsBy(How = How.Id, Using = "State_facet_showHideFacet")]
        public IWebElement State_facet_showHideFacet_1 { get; set; }


        [FindsBy(How = How.Id, Using = "0_custrow")]
        public IWebElement WholePage { get; set; }


        [FindsBy(How = How.Id, Using = "0_custrow")]
        public IWebElement FirstCusResult { get; set; }

        [FindsBy(How = How.Id, Using = "1_custrow")]
        public IWebElement SecondCusResult { get; set; }

        [FindsBy(How = How.Id, Using = "2_custrow")]
        public IWebElement thirdCusResult { get; set; }

        [FindsBy(How = How.Id, Using = "3_custrow")]
        public IWebElement fourthCusResult { get; set; }

        [FindsBy(How = How.Id, Using = "4_custrow")]
        public IWebElement FifthCusResult { get; set; }

        [FindsBy(How = How.Id, Using = "customer_location")]
        public IWebElement customer_location { get; set; }

        [FindsBy(How = How.Id, Using = "favAddressId")]
        public IWebElement favAddress { get; set; }

        [FindsBy(How = How.Id, Using = "0_fav_row`")]
        public IWebElement Fav_list_row1 { get; set; }


        [FindsBy(How = How.Id, Using = "0_suggestRow")]
        public IWebElement Autosugestionrow1 { get; set; }
        [FindsBy(How = How.Id, Using = "1_suggestRow")]
        public IWebElement Autosugestionrow2 { get; set; }
        [FindsBy(How = How.Id, Using = "2_suggestRow")]
        public IWebElement Autosugestionrow3 { get; set; }
        [FindsBy(How = How.Id, Using = "3_suggestRow")]
        public IWebElement Autosugestionrow4 { get; set; }

        // NEW FUNCTIONALITY ADDED RECENTLY 

        // RECENT SEARCH 
        [FindsBy(How = How.Id, Using = "0rsli")]
        public IWebElement recentSearch_1 { get; set; }

        [FindsBy(How = How.Id, Using = "1rsli")]
        public IWebElement recentSearch_2 { get; set; }

        [FindsBy(How = How.Id, Using = "2rsli")]
        public IWebElement recentSearch_3 { get; set; }

        [FindsBy(How = How.Id, Using = "3rsli")]
        public IWebElement recentSearch_4 { get; set; }

        [FindsBy(How = How.Id, Using = "4rsli")]
        public IWebElement recentSearch_5 { get; set; }

        [FindsBy(How = How.Id, Using = "5rsli")]
        public IWebElement recentSearch_6 { get; set; }

        [FindsBy(How = How.Id, Using = "6rsli")]
        public IWebElement recentSearch_7 { get; set; }

        [FindsBy(How = How.Id, Using = "7rsli")]
        public IWebElement recentSearch_8 { get; set; }

        [FindsBy(How = How.Id, Using = "8rsli")]
        public IWebElement recentSearch_9 { get; set; }

        [FindsBy(How = How.Id, Using = "9rsli")]
        public IWebElement recentSearch_10 { get; set; }

        [FindsBy(How = How.Id, Using = "newbutton")]
        public IWebElement NewCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "helpbutton")]
        public IWebElement helpbutton { get; set; }

        [FindsBy(How = How.Id, Using = "custfilter")]
        public IWebElement FilterByCUST { get; set; }

        [FindsBy(How = How.Id, Using = "contfilter")]
        public IWebElement FilterByCONT { get; set; }

        [FindsBy(How = How.Id, Using = "movetopdiv")]
        public IWebElement movetop { get; set; }

        [FindsBy(How = How.Id, Using = "viewmorediv")]
        public IWebElement viewmorediv { get; set; }

        [FindsBy(How = How.Id, Using = "viewmorediv")]
        public IWebElement NoMorereslt { get; set; }

        [FindsBy(How = How.Id, Using = "recentSearchUL")]
        public IWebElement recentSearchLIST { get; set; }





        //TAG CLOUD

        [FindsBy(How = How.Id, Using = "tagcloudDiv")]
        public IWebElement TAGCLOUDDIV { get; set; }

        [FindsBy(How = How.Id, Using = "EntityType_facet_searchbox")]
        public IWebElement EntityType_facet_searchbox { get; set; }


        // Filterby option

        [FindsBy(How = How.Id, Using = "custfilter")]
        public IWebElement filterbycustomer { get; set; }

        [FindsBy(How = How.Id, Using = "contfilter")]
        public IWebElement filterbycontact { get; set; }



        //FileSide objects:

        [FindsBy(How = How.Id, Using = "CityFacet_searchbox")]
        public IWebElement CityFacet_searchbox { get; set; }

        [FindsBy(How = How.Id, Using = "StateFacet_searchbox")]
        public IWebElement StateFacet_searchbox { get; set; }

        [FindsBy(How = How.Id, Using = "favcustomername")]
        public IWebElement favcustomername { get; set; }

        [FindsBy(How = How.Id, Using = "facetDiv")]
        public IWebElement facetList { get; set; }






        #endregion

        public CustomerSearch WaitForScreenToLoad()
        {
            for (int i = 0; i < 3; i++)
            {
                //  WholePage.FindElement(By.Id(i + "_custrow")).GetAttribute("class") == "row_0_ssd";
            }
            this.SwitchToContentFrame();
            this.WaitCreation(searchBox, 1000);
            return this;
        }

        public CustomerSearch Open()
        {
            FastDriver.LeftNavigation.Navigate<CustomerSearch>("Home>System Maintenance>Customer Search");
            this.WaitForScreenToLoad();
            return this;
        }



        string[] searchStrings;
        public void HighlightResults(string SearchString)
        {
            searchStrings = SearchString.Split(' ');
            searchBox.SendKeys(SearchString);
            searchbutton.FAClick();
            this.WaitForScreenToLoad();
            List<IWebElement> resultList = new List<IWebElement>();
            resultList = FastDriver.WebDriver.FindElements(By.ClassName("highlight")).GetAllVisible();

            for (int i = 0; i < resultList.Count; i++)
            {
                int x = (i / searchStrings.Length + 1);
                Reports.StatusUpdate("Search string '" + resultList[i].FAGetText() + "' is highlighted in Line " + x, CompareHighight(resultList[i].FAGetText()));
            }
        }

        private bool CompareHighight(string resultText)
        {
            foreach (var str in searchStrings)
            {
                if (resultText.ToLower() == str.ToLower())
                    return true;
            }
            return false;
        }

    }

}