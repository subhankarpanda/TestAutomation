using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DataElementSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboDataElementGrp")]
		public IWebElement DataElementGroup { get; set; }

		[FindsBy(How = How.Id, Using = "txtDataElementObj")]
		public IWebElement DataElement { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSelect")]
		public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgridDataElements_0")]
        public IWebElement SearchResult { get; set; }
        
        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }
        [FindsBy(How = How.Id, Using = "dgridDataElements_dgridDataElements")]
        public IWebElement SearchResultsTable { get; set; }

        public IWebElement GetSearchResult(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("dgridDataElements_" + index));
        }

		#endregion

        public DataElementSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Data Element Selection", true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Select);

            return this;
        }
	}
}
