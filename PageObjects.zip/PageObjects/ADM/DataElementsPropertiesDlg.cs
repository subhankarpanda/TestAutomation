using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DataElementsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtCatDesc")]
		public IWebElement CatalogDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "cboFormat")]
		public IWebElement Format { get; set; }

		[FindsBy(How = How.Id, Using = "cboPicture")]
		public IWebElement PictureSelection { get; set; }

		[FindsBy(How = How.Id, Using = "txtPicture")]
		public IWebElement PictureTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "ChkReadOnlyInd")]
		public IWebElement ReadOnly { get; set; }

		[FindsBy(How = How.Id, Using = "cboCase")]
		public IWebElement Case { get; set; }

		[FindsBy(How = How.Id, Using = "cboAlignment")]
		public IWebElement Alignment { get; set; }

		[FindsBy(How = How.Id, Using = "cboRequired")]
		public IWebElement Required { get; set; }

		[FindsBy(How = How.Id, Using = "txtIndex")]
		public IWebElement Index { get; set; }

		[FindsBy(How = How.Id, Using = "txtInitValue")]
		public IWebElement InitialValue { get; set; }

		[FindsBy(How = How.Id, Using = "txtfrmName")]
		public IWebElement formFieldName { get; set; }

		[FindsBy(How = How.Id, Using = "cmdsave")]
		public IWebElement Ok { get; set; }

		#endregion

        public DataElementsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Data Element Properties", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Name);
            return this;
        }

	}
}
