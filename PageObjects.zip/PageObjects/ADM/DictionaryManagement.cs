using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DictionaryManagement : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboWordList")]
		public IWebElement Search { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "txtnewvalue")]
		public IWebElement NewValue { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDictionary_0_lblCustom")]
		public IWebElement AddedValue { get; set; }

		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement ErrorMsg { get; set; }

        [FindsBy(How = How.Id, Using = "dgridDictionary_dgridDictionary")]
        public IWebElement CustomWordsTable { get; set; }

		#endregion

        #region Useful Methods
        public DictionaryManagement WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Add);
            return this;
        }
        #endregion

    }
}
