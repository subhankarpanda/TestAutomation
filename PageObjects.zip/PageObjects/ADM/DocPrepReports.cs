using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocPrepReports : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement GenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisp")]
		public IWebElement DisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectPhraseGroupName { get; set; }

		[FindsBy(How = How.LinkText, Using = "2")]
		public IWebElement PageLink { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectPhraseGroups { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectPhraseTypeName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_lblName")]
		public IWebElement CPL { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectTemplates { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectTemplateType { get; set; }

		[FindsBy(How = How.LinkText, Using = "/smsfast/images/eagle.jpg")]
		public IWebElement EagleImage { get; set; }

		#endregion
        public DocPrepReports WaitForScreenToLoad(IWebElement elememt = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(elememt ?? SelectAll);

            return this;
        }
	}
	public class DocPrepReports2 : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement GenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayItems")]
		public IWebElement DisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectPhraseGroupName { get; set; }

		[FindsBy(How = How.LinkText, Using = "2")]
		public IWebElement PageLink { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectPhraseGroups { get; set; }

		[FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
		public IWebElement SelectPhraseTypeName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_lblName")]
		public IWebElement CPL { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectTemplates { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectTemplateType { get; set; }

		[FindsBy(How = How.LinkText, Using = "/smsfast/images/eagle.jpg")]
		public IWebElement EagleImage { get; set; }

		#endregion

	}
	public class DocPrepReports1 : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement GenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayItems")]
		public IWebElement DisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectPhraseGroupName { get; set; }

		[FindsBy(How = How.LinkText, Using = "2")]
		public IWebElement PageLink { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectPhraseGroups { get; set; }

		[FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
		public IWebElement SelectPhraseTypeName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_lblName")]
		public IWebElement CPL { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectTemplates { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectTemplateType { get; set; }

		[FindsBy(How = How.LinkText, Using = "/smsfast/images/eagle.jpg")]
		public IWebElement EagleImage { get; set; }

		#endregion

	}
}
