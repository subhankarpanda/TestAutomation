using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocPrepReportsTemplatesUsingPhrases : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement SelectGroupGenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectGroupSelectPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectGroupSelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisp")]
		public IWebElement SelectGroupDisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectGroupSelectCheckbox { get; set; }

		[FindsBy(How = How.LinkText, Using = "2")]
		public IWebElement SelectGrouplink2 { get; set; }

		[FindsBy(How = How.Id, Using = "cmdGenerateReport")]
		public IWebElement SelectPhraseGenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayItems")]
		public IWebElement SelectPhraseDisplayItems { get; set; }

		[FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
		public IWebElement SelectPhraseselectcheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_dgridSel")]
		public IWebElement DocPrepReportsTemplatesUsingPhrasesTable { get; set; }

		#endregion

        #region Useful Methods
        public DocPrepReportsTemplatesUsingPhrases WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SelectGroupGenerateReport);
            return this;
        }
        #endregion

    }
	public class DocPrepReportsTemplatesUsingPhrases1 : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement SelectGroupGenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectGroupSelectPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectGroupSelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisp")]
		public IWebElement SelectGroupDisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectGroupSelectCheckbox { get; set; }

		[FindsBy(How = How.LinkText, Using = "2")]
		public IWebElement SelectGrouplink2 { get; set; }

		[FindsBy(How = How.Id, Using = "cmdGenerateReport")]
		public IWebElement SelectPhraseGenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayItems")]
		public IWebElement SelectPhraseDisplayItems { get; set; }

		[FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
		public IWebElement SelectPhraseselectcheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_dgridReportSel")]
		public IWebElement DocPrepReportsTemplatesUsingPhrasesTable { get; set; }

		#endregion

        #region Useful Methods
        public DocPrepReportsTemplatesUsingPhrases1 WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SelectPhraseGenerateReport);
            return this;
        }
        #endregion

    }
}
