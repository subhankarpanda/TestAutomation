using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocPrepReportsTemplatesbyTemplateType : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement GenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectTemplates { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisp")]
		public IWebElement SelectGroupDisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectTemplateGroupcheckBox1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_1_chkSelt")]
		public IWebElement SelectTemplateGroupcheckBox2 { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayItems")]
		public IWebElement SelectTemplateDisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
		public IWebElement SelectTemplateSelectTemplateCheckBox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_dgridSel")]
		public IWebElement DocPrepReportsTemplatesbyTemplateTypeTable { get; set; }

		#endregion

        public DocPrepReportsTemplatesbyTemplateType WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GenerateReport);
            return this;
        }
	}
	public class DocPrepReportsTemplatesbyTemplateType1 : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdGenRpt")]
		public IWebElement GenerateReport { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSel")]
		public IWebElement SelectTemplates { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisp")]
		public IWebElement SelectGroupDisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
		public IWebElement SelectTemplateGroupcheckBox1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_1_chkSelt")]
		public IWebElement SelectTemplateGroupcheckBox2 { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayItems")]
		public IWebElement SelectTemplateDisplayPhraseText { get; set; }

		[FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
		public IWebElement SelectTemplateSelectTemplateCheckBox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSel_dgridSel")]
		public IWebElement DocPrepReportsTemplatesbyTemplateTypeTable { get; set; }

		#endregion

	}
}
