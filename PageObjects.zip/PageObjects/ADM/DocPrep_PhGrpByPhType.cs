using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class DocPrepReportsPGPT : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdGenRpt")]
        public IWebElement GenerateReportPhraseType { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSel")]
        public IWebElement SelectPhraseGroups { get; set; }

        [FindsBy(How = How.Id, Using = "chkSelAll")]
        public IWebElement SelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisp")]
        public IWebElement DisplayPhraseText { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
        public IWebElement SelectPhraseType1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSel_1_chkSelt")]
        public IWebElement SelectPhraseType2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSel_2_chkSelt")]
        public IWebElement SelectPhraseType3 { get; set; }

        [FindsBy(How = How.Id, Using = "cmdGenRpt")]
        public IWebElement GenerateReportPhraseGroup { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayItems")]
        public IWebElement DisplayItemsGroup { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
        public IWebElement SelectPhraseGroup1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_2_chkSelect")]
        public IWebElement SelectPhraseGroup2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_3_chkSelect")]
        public IWebElement SelectPhraseGroup3 { get; set; }

        #endregion

        public DocPrepReportsPGPT WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SelectAll);
            return this;
        }

    }

    public class DocPrepReportsPGPT1 : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdGenRpt")]
        public IWebElement GenerateReportPhraseType { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSel")]
        public IWebElement SelectPhraseGroups { get; set; }

        [FindsBy(How = How.Id, Using = "chkSelAll")]
        public IWebElement SelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisp")]
        public IWebElement DisplayPhraseText { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSel_0_chkSelt")]
        public IWebElement SelectPhraseType1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSel_1_chkSelt")]
        public IWebElement SelectPhraseType2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSel_2_chkSelt")]
        public IWebElement SelectPhraseType3 { get; set; }

        [FindsBy(How = How.Id, Using = "cmdGenerateReport")]
        public IWebElement GenerateReportPhraseGroup { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayItems")]
        public IWebElement DisplayItemsGroup { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_1_chkSelect")]
        public IWebElement SelectPhraseGroup1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_2_chkSelect")]
        public IWebElement SelectPhraseGroup2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridReportSel_3_chkSelect")]
        public IWebElement SelectPhraseGroup3 { get; set; }

        #endregion

        public DocPrepReportsPGPT1 WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SelectAll);
            return this;
        }
    }
}
