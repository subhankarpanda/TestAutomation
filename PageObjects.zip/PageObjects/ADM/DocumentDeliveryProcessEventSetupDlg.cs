using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocumentDeliveryProcessEventSetupDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "btnDelete")]
		public IWebElement Delete { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "lstSelDelMethods")]
		public IWebElement SelDelMethods { get; set; }

        [FindsBy(How = How.Id, Using = "DelliveryMethodSelections")]
        public IWebElement SelDelUnsuccessful { get; set; }

		[FindsBy(How = How.LinkText, Using = "PRINT PREVIEW")]
		public IWebElement PrintPreview { get; set; }

		#endregion

        public DocumentDeliveryProcessEventSetupDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //this.WebDriver.WaitForWindowAndSwitch("Document Delivery Process Event Setup", timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Done);

            return this;
        }

	}
}
