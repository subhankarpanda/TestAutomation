using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocumentDeliverySelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlSelDocType")]
		public IWebElement TemplateType { get; set; }

		[FindsBy(How = How.Id, Using = "btnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "btnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "ddlSelSource")]
		public IWebElement Source { get; set; }

		[FindsBy(How = How.Id, Using = "ddlSelState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "ddlSelCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "txtTemplateDescr")]
		public IWebElement TemplateDescription { get; set; }

		[FindsBy(How = How.Id, Using = "ddlSelCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelTemp")]
		public IWebElement SelectTemplates { get; set; }

		[FindsBy(How = How.Id, Using = "dgGridDoc_dgGridDoc")]
		public IWebElement SearchResultsTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgGridDoc_0_chkSelect")]
		public IWebElement Selectchkbox0 { get; set; }

		[FindsBy(How = How.Id, Using = "dgGridDoc_1_chkSelect")]
		public IWebElement Selectchkbox1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblSearchResults")]
        public IWebElement ResultsCounter { get; set; }

        [FindsBy(How = How.Id, Using = "lblPgNum")]
        public IWebElement PageCounter { get; set; }

		#endregion

        #region Useful Methods
        public DocumentDeliverySelectionDlg WaitForScreenToLoad(string windowName = "Document Delivery Selection", IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? TemplateType);
            return this;
        }

        public void Find()
        {
            this.FindNow.FAClick();
            this.WaitCreation(Selectchkbox0);
        }
        #endregion
    }
}
