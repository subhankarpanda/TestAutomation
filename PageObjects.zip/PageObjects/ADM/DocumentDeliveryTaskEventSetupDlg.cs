using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocumentDeliveryTaskEventSetupDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "btnDelete")]
		public IWebElement Delete { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "lstSelDelMethods")]
		public IWebElement DeliveryMethods { get; set; }

		[FindsBy(How = How.Id, Using = "idGVTableBody")]
		public IWebElement TempTable { get; set; }

		#endregion

        #region Useful Methods
        public DocumentDeliveryTaskEventSetupDlg WaitForScreenToLoad(string windowName = "Document Delivery Task Event Setup")
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(DeliveryMethods);
            return this;
        }
        #endregion
    }
}
