using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.ImageRecognition;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using SeleniumInternalHelpersSupportLibrary;
using AutoIt;
using System.Diagnostics;
using FASTSelenium.ImageRecognition;



namespace FASTSelenium.PageObjects.ADM
{
	public class DocumentEditor : PageObject
	{       
        public DocumentEditor()
            : base()
        {
            IRHelpers.InitElements<DocumentEditor>(this);
        }

        #region IR Elements | Deployment Items from "ImageRecognition\Media\DocRep\*"

        [IRFindsBy(URI = "IR_DR_DefaultSectionBreak.BMP", Width = 80, Height = 80, OffsetLeft = 238, OffsetTop = 130, Text = "Default Section Berak")]
        public IRButton DefaultSectionBreak { get; set; }
        
        [IRFindsBy(URI = "DR_DE_PhareArrowWhite.BMP", Width = 80, Height = 80, OffsetLeft = 786, OffsetTop = 241, Text = "Default Section Berak")]
        public IRButton DefaultSectionBreak1 { get; set; }

        [IRFindsBy(URI = "DR_DE_PhareArrowWhite1.BMP", Width = 80, Height = 80, OffsetLeft = 786, OffsetTop = 241, Text = "Default Section Berak")]
        public IRButton DefaultSectionBreak2 { get; set; }

        [IRFindsBy(URI = "IR_DR_DefaultSectionBreak_Insert.BMP", Width = 80, Height = 80, OffsetLeft = 246, OffsetTop = 180, Text = "Default Section Berak Insert")]
        public IRButton DefaultSectionBreak_Insert { get; set; }

        [IRFindsBy(URI = "IR_DR_DefaultSectionBreak_Insert_Below.BMP", Width = 80, Height = 80, OffsetLeft = 418, OffsetTop = 205, Text = "Default Section Berak Insert Below")]
        public IRButton DefaultSectionBreak_Insert_Below { get; set; }

        [IRFindsBy(URI = "IR_DR_DefaultSectionBreak_Insert_Below_Phrase.BMP", Width = 80, Height = 80, OffsetLeft = 746, OffsetTop = 210, Text = "Default Section Berak Insert Below Phrase")]
        public IRButton DefaultSectionBreak_Insert_Below_Phrase { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 80, Height = 120, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 70, Height = 180, OffsetLeft = 200, OffsetTop = 110, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase3 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 70, Height = 110, OffsetLeft = 220, OffsetTop = 890, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase2 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 80, Height = 80, OffsetLeft = 220, OffsetTop = 230, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase4 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 80, Height = 80, OffsetLeft = 220, OffsetTop = 250, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase5 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 80, Height = 120, OffsetLeft = 220, OffsetTop = 130, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase6 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 80, Height = 120, OffsetLeft = 223, OffsetTop = 137, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase7 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert.BMP", Width = 100, Height = 100, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase8 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Insert1.BMP", Width = 80, Height = 80, OffsetLeft = 235, OffsetTop = 938, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase9 { get; set; }


        [IRFindsBy(URI = "DR_DE_BelowRightError.bmp", Width = 70, Height = 110, OffsetLeft = 237, OffsetTop = 850, Text = "Insert Phrase Arrow")]
        public IRButton IRInsertPhrase10 { get; set; }
        
        
        
        
        
        
        [IRFindsBy(URI = "DR_DE_F_PC.bmp", Width = 100, Height = 100, Text = "Phrase Condition")]
        public IRButton IRInsertPhraseCondition { get; set; }
        
        //[IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 680, OffsetTop = 164, Text = "Current Line")]
        //public IRButton IRDocumentCurrentLine6 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 100, Height = 100, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom { get; set; }        

        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 80, Height = 100, OffsetLeft = 230, OffsetTop = 880, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom2 { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 100, Height = 100, OffsetLeft = 240, OffsetTop = 230, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom3 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 100, Height = 100, OffsetLeft = 240, OffsetTop = 260, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom4 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 100, Height = 100, OffsetLeft = 240, OffsetTop = 290, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom5 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 100, Height = 120, OffsetLeft = 240, OffsetTop = 170, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom6 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Bottom.BMP", Width = 100, Height = 100, OffsetLeft = 230, OffsetTop = 900, Text = "Insert Phrase Bottom")]
        public IRButton IRInsertPhraseBottom7{ get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search.BMP", Width = 120, Height = 120, Text = "Insert Search")]
        public IRButton IRInsertSearch { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search.BMP", Width = 120, Height = 160, OffsetLeft = 1350, OffsetTop = 160, Text = "Insert Search")]
        public IRButton IRInsertSearch2 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search.BMP", Width = 120, Height = 160, OffsetLeft = 568, OffsetTop = 178, Text = "Insert Search")]
        public IRButton IRInsertSearch3 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search.BMP", Width = 120, Height = 80, OffsetLeft = 560, OffsetTop = 780, Text = "Insert Search")]
        public IRButton IRInsertSearch4 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search.BMP", Width = 120, Height = 140, OffsetLeft = 1140, OffsetTop = 168, Text = "Insert Search")]
        public IRButton IRInsertSearch5 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search.BMP", Width = 120, Height = 140, OffsetLeft = 730, OffsetTop = 150, Text = "Insert Search")]
        public IRButton IRInsertSearch6 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search_1st.BMP", Width = 120, Height = 120, Text = "Insert Phrase Search")]
        public IRButton IRInsertSearch1st { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Button_Search_1st.BMP", Width = 120, Height = 140, OffsetLeft = 568, OffsetTop = 790, Text = "Insert Phrase Search")]
        public IRButton IRInsertSearch1st2 { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Button_Search_1st.BMP", Width = 120, Height = 120, OffsetLeft = 568, OffsetTop = 238, Text = "Insert Phrase Search")]
        public IRButton IRInsertSearch1st3 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search_1st.BMP", Width = 120, Height = 120, OffsetLeft = 568, OffsetTop = 178, Text = "Insert Phrase Search")]
        public IRButton IRInsertSearch1st4 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search_2nd.BMP", Width = 120, Height = 120, Text = "Insert Template Search")]
        public IRButton IRInsertSearch2nd { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Button_Search_2nd.BMP", Width = 120, Height = 120, OffsetLeft = 568, OffsetTop = 308, Text = "Insert Template Search")]
        public IRButton IRInsertSearch2nd2 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search_2nd.BMP", Width = 100, Height = 80, OffsetLeft = 550, OffsetTop = 830, Text = "Insert Template Search")]
        public IRButton IRInsertSearch2nd3 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Search_2nd.BMP", Width = 100, Height = 60, OffsetLeft = 720, OffsetTop = 164, Text = "Insert Template Search")]
        public IRButton IRInsertSearch2nd4 { get; set; }


        [IRFindsBy(URI = "DR_DE_RegionalForm.bmp", Width = 120, Height = 20, OffsetLeft = 377, OffsetTop = 840, Text = "Regional Form")]
        public IRButton IRInsertRegionalForm { get; set; }



        [IRFindsBy(URI = "DR_DE_Select_Form_Document.bmp", Width = 180, Height = 20, OffsetLeft = 375, OffsetTop = 130, Text = "[Select Form Document]")]
        public IRButton IRSelectFormDocument { get; set; }


        [IRFindsBy(URI = "DR_DE_Select_Form_Option.bmp", Width = 250, Height = 20, OffsetLeft = 375, OffsetTop = 174, Text = "[Select Form Document Option]")]
        public IRButton IRSelectFormDocumentOption { get; set; }


        [IRFindsBy(URI = "DR_DE_Insert.bmp", Width = 180, Height = 20, OffsetLeft = 375, OffsetTop = 200, Text = "Insert")]
        public IRButton IRSelectFormInsert { get; set; }

        [IRFindsBy(URI = "DR_DE_SaveBGgray.BMP", Width = 80, Height = 80, OffsetLeft = 1600, OffsetTop = 30, Text = "Save")]
        public IRButton IRSaveBGgray { get; set; }
        
        [IRFindsBy(URI = "DR_DE_Save.BMP", Width = 120, Height = 60, Text = "Save")]
        public IRButton IRSave { get; set; }
        
        [IRFindsBy(URI = "DR_DE_Save.BMP", Width = 120, Height = 80, OffsetLeft = 1850, OffsetTop = 30, Text = "Save")]
        public IRButton IRSave2 { get; set; }

        [IRFindsBy(URI = "DR_DE_Save.BMP", Width = 80, Height = 80, OffsetLeft = 1600, OffsetTop = 30, Text = "Save")]
        public IRButton IRSave3 { get; set; }

        [IRFindsBy(URI = "DR_DE_Save.BMP", Width = 120, Height = 80, OffsetLeft = 1600, OffsetTop = 50, Text = "Save")]
        public IRButton IRSave4 { get; set; }

        [IRFindsBy(URI = "DR_DE_Save.BMP", Width = 120, Height = 80, OffsetLeft = 1850, OffsetTop = 30, Text = "Save")]
        public IRButton IRSave5 { get; set; }

        [IRFindsBy(URI = "DR_DE_Save1.bmp", Width = 120, Height = 80, OffsetLeft = 1200, OffsetTop = 50, Text = "Save")]
        public IRButton IRSave1 { get; set; }        
        
        [IRFindsBy(URI = "DR_DE_F_Misc.BMP", Width = 80, Height = 80, OffsetLeft = 540, OffsetTop = 200, Text = "Misc")]
        public IRButton IRInsertPhraseMisc { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Misc.BMP", Width = 80, Height = 80, OffsetLeft = 388, OffsetTop = 310, Text = "Misc")]
        public IRButton IRInsertPhraseMisc2 { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Misc.BMP", Width = 80, Height = 80, OffsetLeft = 380, OffsetTop = 854, Text = "Misc")]
        public IRButton IRInsertPhraseMisc3 { get; set; }

        [IRFindsBy(URI = "DR_DE_RestartNumbering.BMP", Width = 80, Height = 80, OffsetLeft = 380, OffsetTop = 900, Text = "Restart Numbering")]
        public IRButton IRInsertRestartNumbering { get; set; }

        [IRFindsBy(URI = "DR_DE_RestartNumbering.BMP", Width = 80, Height = 40, OffsetLeft = 380, OffsetTop = 250, Text = "Restart Numbering")]
        public IRButton IRInsertRestartNumbering2 { get; set; }

        [IRFindsBy(URI = "DR_DE_RestartNumbering.BMP", Width = 80, Height = 40, OffsetLeft = 550, OffsetTop = 280, Text = "Restart Numbering")]
        public IRButton IRInsertRestartNumbering3 { get; set; }

        [IRFindsBy(URI = "DR_DE_RestartNumbering.BMP", Width = 80, Height = 40, OffsetLeft = 540, OffsetTop = 310, Text = "Restart Numbering")]
        public IRButton IRInsertRestartNumbering4 { get; set; }

        [IRFindsBy(URI = "DR_DE_DlgInsertButton.BMP", Width = 80, Height = 60, OffsetLeft = 310, OffsetTop = 160, Text = "Insert")]
        public IRButton IRInsertDlgButton { get; set; }

        [IRFindsBy(URI = "DR_DE_DlgInsertButton.BMP", Width = 80, Height = 40, OffsetLeft = 380, OffsetTop = 430, Text = "Insert")]
        public IRButton IRInsertDlgButton2 { get; set; }

        [IRFindsBy(URI = "DR_DE_F_Button_Create.BMP", Width = 160, Height = 60, Text = "Create")]
        public IRButton IRInsertPhraseCreate { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Button_Create.BMP", Width = 160, Height = 60, OffsetLeft = 960, OffsetTop = 540, Text = "Create")]
        public IRButton IRInsertPhraseCreate2 { get; set; }
        
        [IRFindsBy(URI = "DR_DE_F_Button_Create.BMP", Width = 160, Height = 60, OffsetLeft = 830, OffsetTop = 518, Text = "Create")]
        public IRButton IRInsertPhraseCreate3 { get; set; }

        [IRFindsBy(URI = "DR_DE_PhareArrowWhite.BMP", Width = 50, Height = 50, OffsetLeft = 210, OffsetTop = 130, Text = "Insert Phrase Element not selected Arrow")]
        public IRButton IRInsertPhraseArrowWhite { get; set; }

        [IRFindsBy(URI = "DR_DE_PhraseMove.BMP", Width = 50, Height = 50, OffsetLeft = 230, OffsetTop = 180, Text = "Move Phrase")]
        public IRButton IRInsertPhraseMove { get; set; }

        [IRFindsBy(URI = "DR_DE_PhraseBelowGray.BMP", Width = 40, Height = 40, OffsetLeft = 410, OffsetTop = 200, Text = "Move Phrase Below")]
        public IRButton IRInsertPhraseBelowGray { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80,  Text = "Current Line")]
        public IRButton IRDocumentCurrentLine { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 624, OffsetTop = 164, Text = "Current Line")]
        public IRButton IRDocumentCurrentLine2 { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 500, OffsetTop = 150, Text = "Current Line")]
        public IRButton IRDocumentCurrentLine3 { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 890, OffsetTop = 164, Text = "Current Line")]
        public IRButton IRDocumentCurrentLine4 { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 653, OffsetTop = 150, Text = "Current Line")]
        public IRButton IRDocumentCurrentLine5 { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 680, OffsetTop = 164, Text = "Current Line")]
        public IRButton IRDocumentCurrentLine6 { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLine.BMP", Width = 80, Height = 80, OffsetLeft = 720, OffsetTop = 184, Text = "Current Line")]
        public IRButton IRDocumentCurrentLine7 { get; set; }

        [IRFindsBy(URI = "DR_DE_CM_InsertDataElement.BMP", Width = 60, Height = 30, Text = "Current Line")]
        public IRButton IR_CM_InsertDataElement { get; set; }

        [IRFindsBy(URI = "DR_DE_CM_InsertDataElement.BMP", Width = 80, Height = 30, OffsetLeft = 896, OffsetTop = 170, Text = "Current Line")]
        public IRButton IR_CM_InsertDataElement2 { get; set; }

        [IRFindsBy(URI = "DR_DE_CM_InsertDataElement.BMP", Width = 80, Height = 30, OffsetLeft = 686, OffsetTop = 168, Text = "Current Line")]
        public IRButton IR_CM_InsertDataElement3 { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_DownArrow.BMP", Width = 200, Height = 100, Text = "Down Arrow")]
        public IRButton IRToolsDownArrow { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_DownArrow.BMP", Width = 200, Height = 100, OffsetLeft = 1180, OffsetTop = 50, Text = "Down Arrow")]
        public IRButton IRToolsDownArrow2 { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_EmailDelivery.BMP", Width = 120, Height = 60, Text = "Email Delivery")]
        public IRButton IRToolsEmailDelivery { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_EmailDelivery.BMP", Width = 120, Height = 60, OffsetLeft = 1100, OffsetTop = 150, Text = "Email Delivery")]
        public IRButton IRToolsEmailDelivery2 { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_FaxDelivery.BMP", Width = 120, Height = 60, Text = "Fax Delivery")]
        public IRButton IRToolsFaxDelivery { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_FaxDelivery.BMP", Width = 120, Height = 60, OffsetLeft = 1100, OffsetTop = 125, Text = "Fax Delivery")]
        public IRButton IRToolsFaxDelivery2 { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_PreviewDelivery.BMP", Width = 120, Height = 60, Text = "Preview Delivery")]
        public IRButton IRToolsPreviewDelivery { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_PreviewDelivery.BMP", Width = 120, Height = 60, OffsetLeft = 1100, OffsetTop = 76, Text = "Preview Delivery")]
        public IRButton IRToolsPreviewDelivery2 { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_PrintDelivery.BMP", Width = 120, Height = 60, Text = "Print Delivery")]
        public IRButton IRToolsPrintDelivery { get; set; }

        [IRFindsBy(URI = "DR_DE_ActionArrow.BMP", Width = 80, Height = 80, Text = "Action Arrow")]
        public IRButton IR_CM_ActionArrow { get; set; }

        [IRFindsBy(URI = "DR_DE_Tools_PrintDelivery.BMP", Width = 120, Height = 60, OffsetLeft = 1100, OffsetTop = 100, Text = "Print Delivery")]
        public IRButton IRToolsPrintDelivery2 { get; set; }

        [IRFindsBy(URI = "DR_DE_FIEL_SearchPhrase.BMP", Width = 127, Height = 33, Text = "Search Phrase")]
        public IRButton IRSearchPhrase { get; set; }

        [IRFindsBy(URI = "DR_DE_SectionBreak.BMP", Width = 80, Height = 40, OffsetLeft = 380, OffsetTop = 890, Text = "Section Break")]
        public IRButton IRInsertSectionBreak { get; set; }

        [IRFindsBy(URI = "DR_DE_SectionBreak.BMP", Width = 80, Height = 40, OffsetLeft = 380, OffsetTop = 230, Text = "Section Break")]
        public IRButton IRInsertSectionBreak2 { get; set; }

        [IRFindsBy(URI = "DR_DE_SectionBreak.BMP", Width = 80, Height = 80, OffsetLeft = 530, OffsetTop = 250, Text = "Section Break")]
        public IRButton IRInsertSectionBreak3 { get; set; }

        [IRFindsBy(URI = "DR_DE_PhraseInsert.BMP", Width = 50, Height = 50, OffsetLeft = 230, OffsetTop = 150, Text = "Insert")]
        public IRButton IRPhraseInsert { get; set; }

        [IRFindsBy(URI = "DR_DE_PhraseInsert.BMP", Width = 50, Height = 50, OffsetLeft = 230, OffsetTop = 180, Text = "Insert")]
        public IRButton IRPhraseInsert2 { get; set; }

        [IRFindsBy(URI = "DR_DE_PhraseAboveWhite.BMP", Width = 50, Height = 50, OffsetLeft = 400, OffsetTop = 150, Text = "Above")]
        public IRButton IRPhraseInsertAbove { get; set; }

        [IRFindsBy(URI = "DR_DE_PhraseAboveWhite.BMP", Width = 50, Height = 50, OffsetLeft = 400, OffsetTop = 180, Text = "Above")]
        public IRButton IRPhraseInsertAbove2 { get; set; }

        [IRFindsBy(URI = "DR_DE_Delete.BMP", Width = 40, Height = 40, OffsetLeft = 240, OffsetTop = 270, Text = "Delete")]
        public IRButton IRPhraseDelete { get; set; }

        [IRFindsBy(URI = "DR_DE_PleaseGrayText.BMP", Width = 80, Height = 40, OffsetLeft = 450, OffsetTop = 380, Text = "Please provide a reason for remove phrase")]
        public IRButton IRPhraseDeleteReasonText { get; set; }

        [IRFindsBy(URI = "DR_DE_ReasonOK.BMP", Width = 40, Height = 40, OffsetLeft = 650, OffsetTop = 500, Text = "OK")]
        public IRButton IRPhraseDeleteReasonOK { get; set; }

        [IRFindsBy(URI = "DR_DE_Finalize.BMP", Width = 80, Height = 40, OffsetLeft = 1320, OffsetTop = 50, Text = "Finalize")]
        public IRButton IRFinalize { get; set; }

        [IRFindsBy(URI = "DR_DE_Finalize1.bmp", Width = 80, Height = 30, OffsetLeft = 420, OffsetTop = 80, Text = "Finalize")]
        public IRButton IRFinalize1 { get; set; }



        [IRFindsBy(URI = "DR_DE_Unfinalize.BMP", Width = 120, Height = 40, OffsetLeft = 1330, OffsetTop = 50, Text = "Unfinalize")]
        public IRButton IRUnfinalize { get; set; }

        [IRFindsBy(URI = "DR_DE_UnfinalizeBlack.BMP", Width = 120, Height = 40, OffsetLeft = 1330, OffsetTop = 50, Text = "Unfinalize")]
        public IRButton IRUnfinalizeBlack { get; set; }

        [IRFindsBy(URI = "DR_DE_PleaseGrayText.BMP", Width = 80, Height = 40, OffsetLeft = 1350, OffsetTop = 190, Text = "Please provide a reason for remove phrase")]
        public IRButton IRUnfinalizeReasonText { get; set; }

        [IRFindsBy(URI = "DR_DE_ReasonOK.BMP", Width = 80, Height = 80, OffsetLeft = 1530, OffsetTop = 290, Text = "OK")]
        public IRButton IRUnfinalizeReasonOK { get; set; }

        [IRFindsBy(URI = "DR_DE_CurrentLineColon.bmp", Width = 40, Height = 40, OffsetLeft = 540, OffsetTop = 250, Text = "Current Line")]
        public IRButton IRDocumentCurrentLineEdit { get; set; }


       


        [IRFindsBy(URI = "DR_DE_UnfinalizedEdit.bmp", Width = 120, Height = 40, OffsetLeft = 520, OffsetTop = 80, Text = "Unfinalize")]
        public IRButton IRUnfinalizeEdited { get; set; }

        [IRFindsBy(URI = "DR_DE_Please_Text_Edit.bmp", Width = 80, Height = 40, OffsetLeft = 540, OffsetTop = 200, Text = "Please provide a reason for remove phrase")]
        public IRButton IRUnfinalizeReasonTextEdit { get; set; }

        [IRFindsBy(URI = "DR_DE_UnFilanalizeOk.bmp", Width = 50, Height = 50, OffsetLeft = 740 , OffsetTop = 330, Text = "OK")]
        public IRButton IRUnfinalizeReasonOKEdit { get; set; }
        
        [IRFindsBy(URI = "DR_DE_WaterMark_None.bmp", Width = 100, Height = 40, OffsetLeft = 984, OffsetTop = 55, Text = "None")]
        public IRButton IRDocWaterNone { get; set; }

        [IRFindsBy(URI = "DR_DE_WatermarkDraft.BMP", Width = 100, Height = 40, OffsetLeft = 984, OffsetTop = 68, Text = "Draft")]
        public IRButton IRDocWaterDraft { get; set; }

        [IRFindsBy(URI = "DR_DE_WatermarkProForma.BMP", Width = 120, Height = 40, OffsetLeft = 984, OffsetTop = 88, Text = "ProForma")]
        public IRButton IRDocWaterProForma { get; set; }

        [IRFindsBy(URI = "DR_DE_WaterMark_Select.bmp", Width = 35, Height = 35, OffsetLeft = 1072, OffsetTop = 50, Text = "Dropbown Arrow")]
        public IRButton IRDocWaterSelect { get; set; }

        [IRFindsBy(URI = "DR_DE_DeliveryN.bmp", Width = 100, Height = 28, OffsetLeft = 1100, OffsetTop = 52, Text = "Delivery")]
        public IRButton IRDocDeliveryN { get; set; }


        [IRFindsBy(URI = "DR_DE_AutoNumber.bmp", Width = 28, Height = 28, OffsetLeft = 270, OffsetTop = 100, Text = "Insert Auto Number")]
        public IRButton IRDocAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_DocView_Remove_AutoNumber.bmp", Width = 187, Height = 17, OffsetLeft = 768, OffsetTop = 265, Text = "Insert Context Auto Number")]
        public IRButton IRDocContextRemoveAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_InsertDocAutoNumber.bmp", Width = 175, Height = 18, OffsetLeft = 768, OffsetTop = 265, Text = "Insert Context Auto Number")]
        public IRButton IRDocContextAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_Select_Context_AutoNumber.bmp", Width = 155, Height = 18, OffsetLeft = 768, OffsetTop = 290, Text = "Insert Select Context Auto Number")]
        public IRButton IRDocSelectContextAutonumber { get; set; }


        //[IRFindsBy(URI = "DR_DE_Select_AutoNumber_Option.bmp", Width = 90, Height = 25, OffsetLeft = 540, OffsetTop = 440, Text = "Insert Auto Number Option")]
        //public IRButton IRDocSelectAutonumberOption { get; set; }


        //[IRFindsBy(URI = "DR_DE_Select_Context_AutoNumber_Option.bmp", Width = 93, Height = 18, OffsetLeft = 559, OffsetTop = 450, Text = "Insert Auto Number Option")]
        //public IRButton IRDocSelectAutonumberOption1 { get; set; }

        //[IRFindsBy(URI = "DR_DE_AutoNumberOK.bmp", Width = 34, Height = 20, OffsetLeft = 711, OffsetTop = 439, Text = "Insert Auto Number OK")]
        //public IRButton IRDocSelectAutonumberOK { get; set; }








        [IRFindsBy(URI = "DR_DE_Template_AutoNumber.bmp", Width = 28, Height = 28, OffsetLeft = 320, OffsetTop = 75, Text = "Insert Auto Number")]
        public IRButton IRTemplateAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_InsertContextAutoNumber.bmp", Width = 175, Height = 18, OffsetLeft = 668, OffsetTop = 265, Text = "Insert Context Auto Number")]
        public IRButton IRTemplateContextAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_Select_Context_AutoNumber.bmp", Width = 155, Height = 18, OffsetLeft = 668, OffsetTop = 290, Text = "Insert Select Context Auto Number")]
        public IRButton IRTemplateSelectContextAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_Select_AutoNumber_Option.bmp", Width = 90, Height = 25, OffsetLeft = 540, OffsetTop = 440, Text = "Insert Auto Number Option Format 1")]
        public IRButton IRTemplateSelectAutonumberOption { get; set; }





        [IRFindsBy(URI = "DR_DE_Select_Context_AutoNumber_Option.bmp", Width = 93, Height = 18, OffsetLeft = 559, OffsetTop = 450, Text = "Insert Auto Number Option Format A")]
        public IRButton IRTemplateSelectAutonumberOption1 { get; set; }

        [IRFindsBy(URI = "DR_DE_AutoNumberOK.bmp", Width = 34, Height = 20, OffsetLeft = 711, OffsetTop = 439, Text = "Insert Auto Number OK")]
        public IRButton IRTemplateSelectAutonumberOK { get; set; }

        [IRFindsBy(URI = "DR_DE_Select_AutoNumber.bmp", Width = 28, Height = 28, OffsetLeft = 340, OffsetTop = 75, Text = "Auto Number")]
        public IRButton IRTemplateSelectAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_TemplatePhraseTypeNGS.bmp", Width = 158, Height = 20, OffsetLeft = 50, OffsetTop = 150, Text = "Phrase Type")]
        public IRButton IRTemplatePhraseType { get; set; }


        [IRFindsBy(URI = "DR_DE_PhraseViewAutoNumber.bmp", Width = 28, Height = 28, OffsetLeft = 38, OffsetTop = 91, Text = "Autonumber")]
        public IRButton IRPhraseViewAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_Select_Context_AutoNumber.bmp", Width = 153, Height = 18, OffsetLeft = 764, OffsetTop = 242, Text = "Select Context Phrase Auto Number")]
        public IRButton IRPhraseSelectContextAutonumber { get; set; }


        [IRFindsBy(URI = "DR_DE_Numbering_Properties.bmp", Width = 125, Height = 17, OffsetLeft = 764, OffsetTop = 267, Text = "Phrase Numbering Properties")]
        public IRButton IRPhraseNumberingProperties { get; set; }

        [IRFindsBy(URI = "DR_DE_Remove_AutoNumberContext.bmp", Width = 185, Height = 22, OffsetLeft = 306, OffsetTop = 186, Text = "Remove Autonumber")]
        public IRButton IRRemovePhraseViewAutonumber { get; set; }


        [IRFindsBy(URI = "DDR_DE_RemoverAutoNumber1.bmp", Width = 22, Height = 23, OffsetLeft = 295, OffsetTop = 165, Text = "Remove Autonumber 1")]
        public IRButton IRRemovePhraseViewAutonumber1 { get; set; }



        [IRFindsBy(URI = "DR_DE_Remove_PhraseView_AutoNumber.bmp", Width = 28, Height = 28, OffsetLeft = 2, OffsetTop = 80, Text = "Remove Autonumber")]
        public IRButton IRRemovePhraseViewAutonumberIcon { get; set; }

        [IRFindsBy(URI = "DR_DE_Template_Remove_AutoNumber.bmp", Width = 187, Height = 17, OffsetLeft = 668, OffsetTop = 265, Text = "Remove Template Autonumber")]
        public IRButton IRRemoveTemplateAutonumber { get; set; }

        [IRFindsBy(URI = "DR_DE_Numbering_Properties.bmp", Width = 130, Height = 17, OffsetLeft = 668, OffsetTop = 340, Text = "Numbering Properties")]
        public IRButton IRNumberingProperties { get; set; }

        [IRFindsBy(URI = "DR_DE_GPhrase.bmp", Width = 200, Height = 18, OffsetLeft = 65, OffsetTop = 150, Text = "GQ01/PQ01 -Phrase")]
        public IRButton IRGPhraseType { get; set; }

        [IRFindsBy(URI = "DR_DE_Del_DownICon.bmp", Width = 20, Height = 20, OffsetLeft = 1180, OffsetTop = 56, Text = "Dropbown Arrow")]
        public IRButton IRDocDel_Down { get; set; }

        [IRFindsBy(URI = "DR_DE_Del_DownICon1.bmp", Width = 18, Height = 18, OffsetLeft = 1180, OffsetTop = 56, Text = "Dropbown Arrow")]
        public IRButton IRDocDel_Down1 { get; set; }

        [IRFindsBy(URI = "DR_DE_Savenew.bmp", Width = 30, Height = 15, OffsetLeft = 1235, OffsetTop = 60, Text = "Save")]
        public IRButton IRDocSave { get; set; }


        [IRFindsBy(URI = "DR_DE_Draft1.bmp", Width = 35, Height = 20, OffsetLeft = 994, OffsetTop = 98, Text = "Draft")]
        public IRButton IRDoc_Draft { get; set; }

        [IRFindsBy(URI = "DR_DE_Delivery_DropDown.bmp", Width = 15, Height = 15, OffsetLeft = 1180, OffsetTop = 60, Text = "Down Arrow")]
        public IRButton IRDocDeliveryDropDown { get; set; }


        [IRFindsBy(URI = "DR_DE_Delivery1.bmp", Width = 50, Height = 15, OffsetLeft = 1128, OffsetTop = 60, Text = "Delivery")]
        public IRButton IRDocDelivery { get; set; }

        [IRFindsBy(URI = "DR_DE_Preview1.bmp", Width = 60, Height = 15, OffsetLeft = 1141, OffsetTop = 80, Text = "Delivery")]
        public IRButton IRDocDeliveryPreview { get; set; }

        [IRFindsBy(URI = "DR_DE_ScrollUpArrow.BMP", Width = 60, Height = 40, OffsetLeft = 1630, OffsetTop = 86, Text = "Scroll Up Arrow")]
        public IRButton IRScrollUpArrow { get; set; }
               
        
        //******************************//
        [IRFindsBy(URI = "DR_DE_ShowBuyerElement.bmp", Width = 70, Height = 13, OffsetLeft = 330, OffsetTop = 168, Text = "Buyer Element")]
        public IRButton DP_PE_FirstDE { get; set; }

        [IRFindsBy(URI = "DP_PE_DataElement2.bmp", Width = 15, Height = 15, OffsetLeft = 560, OffsetTop = 125, Text = "Down Arrow")]
        public IRButton DP_PE_SecondDE { get; set; }

        [IRFindsBy(URI = "DR_DE_ShowDataElementProperty.bmp", Width = 160, Height = 18, OffsetLeft = 400, OffsetTop = 180, Text = "Show Data Element")]
        public IRButton DP_PE_FirstDE_Properties { get; set; }

        [IRFindsBy(URI = "DP_PE_ContextMent_DEProperty.bmp", Width = 15, Height = 15, OffsetLeft = 560, OffsetTop = 125, Text = "Down Arrow")]
        public IRButton DP_PE_SecondDE_Properties { get; set; }

        //*****************************//
        [IRFindsBy(URI = "DR_DE_BuyerDataElementBGWhite.BMP", Width = 80, Height = 30, OffsetTop = 260, OffsetLeft = 730, Text = "No Selected Data Element Buyer")]
        public IRButton IRDataElement_BuyerBGWhite { get; set; }

        [IRFindsBy(URI = "DR_DE_BuyerDataElementBGgray.BMP", Width = 80, Height = 40, OffsetTop = 194, OffsetLeft = 560, Text = "No Selected Data Element Buyer")]
        public IRButton IRDataElement_BuyerBGgray { get; set; }

        [IRFindsBy(URI = "DR_DE_SellerDataElementBGgray.BMP", Width = 80, Height = 40, OffsetTop = 214, OffsetLeft = 560, Text = "No Selected Data Element Seller")]
        public IRButton IRDataElement_SellerBGgray { get; set; }

        [IRFindsBy(URI = "DR_DE_BuyerDataElement.BMP", Width = 80, Height = 30, OffsetTop = 260, OffsetLeft = 730, Text = "Data Element Buyer")]
        public IRButton IRDataElement_Buyer { get; set; }
        
        [IRFindsBy(URI = "DR_DE_SellerDataElement.BMP", Width = 80, Height = 40, OffsetTop = 270, OffsetLeft = 730, Text = "Data Element Seller")]
        public IRButton IRDataElement_Seller { get; set; }

        [IRFindsBy(URI = "DR_DE_Phrases_DocumentIcon.BMP", Width = 80, Height = 40, OffsetTop = 140, OffsetLeft = 20, Text = "Phrase Document Icon")]
        public IRButton IRPhrases_DocumentIcon { get; set; }

        [IRFindsBy(URI = "DR_DE_Phrases_SectionIcon.BMP", Width = 80, Height = 40, OffsetTop = 110, OffsetLeft = 20, Text = "Phrase Section Icon")]
        public IRButton IRPhrases_SectionIcon { get; set; }

        [IRFindsBy(URI = "DR_DE_CopyIcon.BMP", Width = 40, Height = 40, OffsetTop = 50, OffsetLeft = 345, Text = "Copy Button")]
        public IRButton IRCopyButton { get; set; }

        [IRFindsBy(URI = "DR_DE_CopyIcon.BMP", Width = 40, Height = 40, OffsetTop = 50, OffsetLeft = 90, Text = "Copy Button")]
        public IRButton IRCopyButton_PE { get; set; }

        [IRFindsBy(URI = "DR_DE_CutIcon.BMP", Width = 40, Height = 40, OffsetTop = 50, OffsetLeft = 320, Text = "Cut Button")]
        public IRButton IRCutButton { get; set; }

        [IRFindsBy(URI = "DR_DE_CutIcon.BMP", Width = 40, Height = 40, OffsetTop = 50, OffsetLeft = 64, Text = "Cut Button")]
        public IRButton IRCutButton_PE { get; set; }

        [IRFindsBy(URI = "DR_DE_PasteIcon.BMP", Width = 40, Height = 40, OffsetTop = 50, OffsetLeft = 370, Text = "Paste Button")]
        public IRButton IRPasteButton { get; set; }

        [IRFindsBy(URI = "DR_DE_PasteIcon.BMP", Width = 40, Height = 40, OffsetTop = 50, OffsetLeft = 114, Text = "Paste Button")]
        public IRButton IRPasteButton_PE { get; set; }

        [IRFindsBy(URI = "DR_DE_ContextMenu_Cut.BMP", Width = 40, Height = 40, OffsetLeft = 750, OffsetTop = 340, Text = "Cut (Context Menu)")]
        public IRButton IRCut_ContextMenu { get; set; }

        [IRFindsBy(URI = "DR_DE_ContextMenu_Paste.BMP", Width = 40, Height = 40, OffsetLeft = 750, OffsetTop = 370, Text = "Paste (Context Menu)")]
        public IRButton IRPaste_ContextMenu { get; set; }

        [IRFindsBy(URI = "DR_DE_ContextMenu_Cut.BMP", Width = 40, Height = 40, OffsetLeft = 580, OffsetTop = 300, Text = "Cut (Context Menu)")]
        public IRButton IRCut_ContextMenu_PE { get; set; }

        [IRFindsBy(URI = "DR_DE_ContextMenu_Paste.BMP", Width = 40, Height = 40, OffsetLeft = 580, OffsetTop = 276, Text = "Paste (Context Menu)")]
        public IRButton IRPaste_ContextMenu_PE { get; set; }

        #endregion

        #region WebElements

        [FindsBy(How = How.Id, Using = "closeButton")]
		public IWebElement Close { get; set; }

        [FindsBy(How = How.Id, Using = "editorTitle")]
		public IWebElement DocumentTitle { get; set; }

        [FindsBy(How = How.Id, Using = "editorControlObject")]
        public IWebElement DocumentEditorObject { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/button/span[text()='Yes']")]
        public IWebElement Yes { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/button/span[text()='No']")]
        public IWebElement No { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/button/span[text()='Cancel']")]
        public IWebElement Cancel { get; set; }
        
		#endregion

        #region Services
              
        public DocumentEditor WaitForScreenToLoad(int WaitTimeInSeconds = 300)
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(WaitTimeInSeconds));
            wait.Until(d =>
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                WebDriver.SwitchTo().Frame("fraEditor");
                return DocumentEditorObject.Exists();
            });
            return this;
        }

        public System.Drawing.Point getCenter() {

            this.WaitForScreenToLoad();

            return FASTHelpers.GetCenterPoint();
        }

        public void IsImageVisible(IRButton imageelement)
        {
            IJavaScriptExecutor js = FastDriver.WebDriver as IJavaScriptExecutor;
            js.ExecuteScript("return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0", imageelement);
           
        }


        #endregion

        public void IRCut(bool retryWithKB = false)
        {
            FASTHelpers.ClearClipboard();
            var cutButton = FastDriver.DocumentEditor.IRCutButton;
            if (cutButton.DelayOnce(3).Visible() == false)
            {
                cutButton = FastDriver.DocumentEditor.IRCutButton_PE;
            }
            Support.IsTrue(cutButton.Visible(), "Cut option is enabled");
            cutButton.FAClick();
            Playback.Wait(1000);
            if (string.IsNullOrEmpty(FASTHelpers.GetClipboardText()))
            {
                cutButton.DoubleClick();
            }
            if (retryWithKB && string.IsNullOrEmpty(FASTHelpers.GetClipboardText()))
            {
                FASTHelpers.KeyboardSendKeys(FAKeys.Cut);
            }
        }

        public void IRPaste()
        {
            var pasteButton = FastDriver.DocumentEditor.IRPasteButton;
            if (pasteButton.DelayOnce(3).Visible() == false)
            {
                pasteButton = FastDriver.DocumentEditor.IRPasteButton_PE;
            }
            Support.IsTrue(pasteButton.DelayOnce(3).Visible(), "Paste option is enabled");
            pasteButton.MultiClick(1).DoubleClick();
        }

        public void IRCopy(bool retryIfNoAlert = false)
        {
            var copyButton = FastDriver.DocumentEditor.IRCopyButton;
            if (copyButton.DelayOnce(3).Visible() == false)
            {
                copyButton = FastDriver.DocumentEditor.IRCopyButton_PE;
            }
            Support.IsTrue(copyButton.DelayOnce(3).Visible(), "Copy option is enabled");
            copyButton.MultiClick(1).DoubleClick();
            if (retryIfNoAlert == true && FastDriver.WebDriver.WaitForAlertToExist(3) == false)
            {
                copyButton.DoubleClick();
            }
        }

        public string IRClickSave()
        {
            if (this.IRSaveBGgray.DelayOnce(6).Visible())
            {
                this.IRSaveBGgray.Hover();
                this.IRSaveBGgray.ContextHighlight().DoubleClick();
            }
            else if (this.IRSave2.Visible())
            {
                this.IRSave2.Hover();
                this.IRSave2.ContextHighlight().DoubleClick();
            }
            else if (this.IRSave3.Visible())
            {
                this.IRSave3.Hover();
                this.IRSave3.ContextHighlight().DoubleClick();
            }

            else if (this.IRSave1.Visible())  
            {
                this.IRSave1.Hover();
                this.IRSave1.ContextHighlight().DoubleClick();
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Save' was not found by ImageRecognition");
            }

            Microsoft.VisualStudio.TestTools.UITesting.Playback.Wait(15000);
            return HandleAlertMessage(maxTry: 3);
        }

        public string HandleAlertMessage(int maxTry = 5)
        {
            string errorMessage = string.Empty;
            int count = 0;
            while (FastDriver.WebDriver.WaitForAlertToExist(2) && count < maxTry)
            {
                errorMessage = FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false);
                count++;
            }

            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.SwitchToContentFrame();

            return errorMessage;
        }
        
        public void IRSelectWatermark(IRButton watermark)
        {
            this.IRDocWaterSelect.DelayOnce(10).ContextHighlight().FAClick();
            watermark.DelayOnce(10).ContextHighlight().FAClick();
        }

        public void IRDelivery(IRButton Delivery)
        {
              this.IRToolsDownArrow.DelayOnce(30).ContextHighlight().FAClick();
              Delivery.DelayOnce(10).ContextHighlight().FAClick();
                

        }

        public void IRDelivery1(IRButton Preview)
        {           
            this.IRDocDelivery.DelayOnce(10).ContextHighlight().FAClick();           
            Preview.DelayOnce(10).ContextHighlight().FAClick();

        }



       

        public void IRDocumentInsertTemplate()
        {
            if (this.IRDocumentCurrentLine2.DelayOnce(60).Visible())   // 1920 * 1280
            {
                this.IRDocumentCurrentLine2.FAClick();
                FASTHelpers.KeyboardSendKeys("NextGenDocPrep Sanity Testing test case 19");
                this.IRDocumentCurrentLine4.DelayOnce(3).ContextClick();
                this.IR_CM_InsertDataElement2.DelayOnce(3).FAClick();
                this.IRInsertSearch2.DelayOnce(1).ContextHighlight().DoubleClick();
            }
            else if (this.IRDocumentCurrentLine3.Visible())    //  1680 * 1050
            {
                this.IRDocumentCurrentLine3.FAClick();
                FASTHelpers.KeyboardSendKeys("NextGenDocPrep Sanity Testing test case 19");
                this.IRDocumentCurrentLine5.DelayOnce(3).ContextClick();
                this.IR_CM_InsertDataElement2.DelayOnce(3).FAClick();
                this.IRInsertSearch2.DelayOnce(1).ContextHighlight().DoubleClick();
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Document Current Line' was not found by ImageRecognition");
            }
            FASTHelpers.KeyboardSendKeys(FAKeys.Enter);
            Microsoft.VisualStudio.TestTools.UITesting.Playback.Wait(3000);
        }

        public void HandlePhraseSelectionDlg(string tplPhraseName, string phraseDescription)
        {
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            try
            {
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
            }
            catch 
            {
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(2, tplPhraseName, 2, TableAction.Click);
            }
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
        }

        public void InsertPhraseBelow(string tplPhraseName, string phraseDescription)
        {
            if (this.IRInsertPhrase3.Visible())
            {
                this.IRInsertPhrase3.ContextClick();
                this.IRInsertPhraseBottom3.FAClick();
                this.IRInsertSearch1st3.ContextHighlight();
                this.IRInsertSearch1st3.FAClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextClick();
                this.IRInsertPhraseBottom2.FAClick();
                this.IRInsertSearch4.ContextHighlight();
                this.IRInsertSearch4.FAClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            this.HandlePhraseSelectionDlg(tplPhraseName, phraseDescription);
        }

        public void InsertPhraseBelowAndSave(string tplPhraseName, string phraseDescription)
        {
            this.InsertPhraseBelow(tplPhraseName, phraseDescription);
            //this.SaveAndClose();
            this.CloseEditor();
        }


        
        public void InsertAutoNumbering()
        {
            //this.InsertPhraseBelow(tplPhraseName, phraseDescription);

            Reports.TestStep = "Click on Phrase.";
            this.IRGPhraseType.DelayOnce(20).ContextHighlight().FAClick();
           
            Reports.TestStep = "Click on Current Line";
            this.IRDocumentCurrentLine7.DelayOnce(10).ContextHighlight().ContextClick();
            Reports.TestStep = "Click on Remove Auto Number";
            if (this.IRDocContextRemoveAutonumber.DelayOnce(10).Visible() == true)
            {
                this.IRDocContextRemoveAutonumber.DelayOnce(10).ContextHighlight().FAClick();
                Reports.TestStep = "Click on Current Line";
                this.IRDocumentCurrentLine7.DelayOnce(10).ContextHighlight().ContextClick();
            }

            Reports.TestStep = "Verify if Auto-Numbering properties in the toolbar it is active and visible.";
            if (this.IRDocContextAutonumber.DelayOnce(10).ContextHighlight().Visible() == true)
                Support.AreEqual("True", "True", "Auto-Numbering properties in the toolbar it is active and visible.");
            
            Reports.TestStep = "Click on auto Number.";
            this.IRDocContextAutonumber.DelayOnce(10).ContextHighlight().FAClick();
            Playback.Wait(1000);

            Reports.TestStep = "Right Click on Current Line.";
            this.IRDocumentCurrentLine7.DelayOnce(10).ContextHighlight().ContextClick();

            Reports.TestStep = "Verify Select Auto-Numbering properties in the context menu.";
            if (this.IRDocSelectContextAutonumber.DelayOnce(10).ContextHighlight().Visible() == true)
                Support.AreEqual("True", "True", "Auto-Numbering properties in the toolbar it is active and visible.");



            Reports.TestStep = "Click on Select Auto Number.";
            this.IRDocSelectContextAutonumber.ContextHighlight().DelayOnce(10).FAClick();

            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Reports.TestStep = "Select Auto-Number option properties in the context menu.";
            this.IRTemplateSelectAutonumberOption.ContextHighlight().DelayOnce(10).FAClick();
            this.IRTemplateSelectAutonumberOption1.ContextHighlight().DelayOnce(10).FAClick();

            Reports.TestStep = "Click on OK in Autonumber Dialog.";
            this.IRTemplateSelectAutonumberOK.ContextHighlight().DelayOnce(10).FAClick();

            FastDriver.DocumentEditor.WaitForScreenToLoad();

            Playback.Wait(1000);
            this.CloseEditor();
            
        }


        public void NumberingProperties()
        {
          


            Reports.TestStep = "Click on Phrase.";
            this.IRTemplatePhraseType.DelayOnce(20).ContextHighlight().FAClick();
            Playback.Wait(1000);
            Reports.TestStep = "Right Click on Current Line.";
            this.IRDocumentCurrentLine2.ContextHighlight().ContextClick();


            Reports.TestStep = "Remove auto Number if exist and save.";
            if (this.IRRemoveTemplateAutonumber.DelayOnce(10).Visible() == true)
            {
                this.IRRemoveTemplateAutonumber.DelayOnce(10).ContextHighlight().FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Right Click on Current Line.";
                this.IRDocumentCurrentLine2.DelayOnce(20).ContextHighlight().ContextClick();

            }


            Reports.TestStep = "Verify if Numbering Properties is enabled or disabled.";
            
            if (this.IRNumberingProperties.DelayOnce(10).ContextHighlight().Enabled == false)
            {
                Support.AreEqual("True", "True", "Numbering Properties is disabled in the menu."); 
            }

            FastDriver.DocumentEditor.WaitForScreenToLoad();

            Playback.Wait(1000);
            this.CloseEditor();


        }

        public void Select_AutoNumber_Template_Edit(string templateType, string templateName)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Search for Existing Template
            Reports.TestStep = "Search for Existing Template";
            FastDriver.NextGenDocumentPreparation.SearchExistingTemplate(templateType, templateName);
            #endregion

            #region Select a Template and right click for View/Edit Template option
            Reports.TestStep = "Select a Template and right click for View/Edit Template option";
            FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
            Playback.Wait(3000);
            #endregion


            #region Edit template
            Reports.TestStep = "Edit template";

            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);          
            FastDriver.NextGenDocumentPreparation.Save.Highlight(8);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
            FastDriver.NextGenDocumentPreparation.Editor.FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(5000);
            #endregion
            #region Click on Phrase and Insert Auto Number
            this.SelectTemplateAutoNumbering();
            #endregion

            Playback.Wait(1000);

            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);         
         
            FastDriver.NextGenDocumentPreparation.Save.Highlight(8);          
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
           
            #region Click on Template Phrases tab
            Reports.TestStep = "Click on Template Phrases tab";
            Playback.Wait(1000);           
            FastDriver.NextGenDocumentPreparation.TemplatePhrases.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Loading Phrases.. please wait...", true, 10);
            #endregion


            #region Right click Phrase from Phrase Table and click on Properties
            Reports.TestStep = "Right click Phrase from Phrase Table and click on Properties";
            FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.Highlight(5);
            FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(2, 2, TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.Highlight(5);
            FastDriver.NextGenDocumentPreparation.PropertiesphraseContext.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.DesPhrasesName);
            Playback.Wait(1000); 
            #endregion

            #region Click on Phrase View Button
            Reports.TestStep = "Click on Phrase View Button";
            FastDriver.NextGenDocumentPreparation.PhraseViewDe.Highlight(5);
            FastDriver.NextGenDocumentPreparation.PhraseViewDe.FAClick();
            #endregion

            #region Wait for screen to load
            Reports.TestStep = "Wait for screen to load";
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(7000);
            this.PhraseViewAutoNumbering();
            Playback.Wait(1000);
            FastDriver.NextGenDocumentPreparation.TemplateProperties.Highlight(5); 
            FastDriver.NextGenDocumentPreparation.TemplateProperties.FAClick();           
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
            FastDriver.NextGenDocumentPreparation.Save.Highlight(8);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            Playback.Wait(2000);  
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion
            

            #region Search for a phrase group
            Reports.TestStep = "Search for a phrase group.";
            FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
            FastDriver.NextGenDocumentPreparation.SelectPhraseType("Escrow Phrase[ESCROW]");
            FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText("NEXTGEN-SAN-EscrowPhrase-DoNotTouch");

            Reports.TestStep = "Click on Search button";
            FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            #endregion


            #region Right click the Phrase and select Properties from context menu
            Reports.TestStep = "Right click the Phrase and select Properties from context menu";
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType);
            FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.Highlight(5); 
            
            
            FastDriver.NextGenDocumentPreparation.PhrasesSearchResult.PerformTableAction(1, 2, TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.PropertiesPhrase.Highlight(5); 
            FastDriver.NextGenDocumentPreparation.PropertiesPhrase.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.EditPhraseGroup);
           
            Playback.Wait(5000);
            #endregion


            #region Select a Phrase from the Phrases list
            Reports.TestStep = "Select a Phrase from the Phrases list";
            FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseListTable.Highlight(5);
            FastDriver.NextGenDocumentPreparation.PhraseGR_PhraseListTable.PerformTableAction(1, 2, TableAction.GetCell).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.EditPhrasetable.Highlight(5);
            FastDriver.NextGenDocumentPreparation.EditPhrasetable.FAClick();
          
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseProperties);
            Playback.Wait(1000);

            #endregion


            #region Click on Phrase View Button
            Reports.TestStep = "Click on Phrase View Button";
            FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(5);
            FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
            #endregion

            #region Wait for screen to load
            Reports.TestStep = "Wait for screen to load";
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(7000);
            this.PhraseViewAutoNumbering();
            Playback.Wait(1000);
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.PhraseProperties);
            FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion
        }


        public void SelectTemplateAutoNumbering()
        {

            Reports.TestStep = "Click on Phrase.";
            this.IRTemplatePhraseType.DelayOnce(20).ContextHighlight().FAClick();
            Playback.Wait(1000);
            Reports.TestStep = "Right Click on Current Line.";
            this.IRDocumentCurrentLine2.ContextHighlight().ContextClick();  
           
            
            Reports.TestStep = "Remove auto Number if exist and save.";
            if (this.IRRemoveTemplateAutonumber.DelayOnce(10).Visible() == true)
            {
                this.IRRemoveTemplateAutonumber.DelayOnce(10).ContextHighlight().FAClick();
                Playback.Wait(2000);
                Reports.TestStep = "Right Click on Current Line.";
                this.IRDocumentCurrentLine2.DelayOnce(20).ContextHighlight().ContextClick();
            
            }      
           
            
            Reports.TestStep = "Click on auto Number.";
            if (this.IRTemplateContextAutonumber.DelayOnce(10).ContextHighlight().Visible() == true)
            {
                Support.AreEqual("True", "True", "Auto-Numbering properties in the toolbar it is active and visible.");
            }
            this.IRTemplateContextAutonumber.DelayOnce(10).ContextHighlight().FAClick();
            Playback.Wait(1000);

            Reports.TestStep = "Right Click on Current Line.";
            this.IRDocumentCurrentLine2.DelayOnce(10).ContextHighlight().ContextClick();

            Reports.TestStep = "Verify Select Auto-Numbering properties in the context menu.";
            this.IRTemplateSelectContextAutonumber.ContextHighlight().DelayOnce(10).FAClick();
            
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Reports.TestStep = "Select Auto-Number option properties in the context menu.";
            this.IRTemplateSelectAutonumberOption.ContextHighlight().DelayOnce(10).FAClick();
            this.IRTemplateSelectAutonumberOption1.ContextHighlight().DelayOnce(10).FAClick();

            Reports.TestStep = "Click on OK in Autonumber Dialog.";
            this.IRTemplateSelectAutonumberOK.ContextHighlight().DelayOnce(10).FAClick();

            FastDriver.DocumentEditor.WaitForScreenToLoad();

            Playback.Wait(1000);
            this.CloseEditor();

        }






        public void PhraseViewAutoNumbering()
        {


            Playback.Wait(1000);  
            Reports.TestStep = "Verify if Autonumbering icon is visible";
            if (this.IRRemovePhraseViewAutonumberIcon.Visible() == true)
                Support.AreEqual("True", "True", "Auto-Numbering properties in the toolbar is active and visible.");

           
            Reports.TestStep = "Click on Current Line";
            this.IRDocumentCurrentLine7.ContextHighlight().ContextClick();   
            

            Reports.TestStep = "Verify Select Auto-Numbering properties in the context menu.";
            this.IRPhraseSelectContextAutonumber.ContextHighlight().DelayOnce(10).FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();

            Reports.TestStep = "Verify Auto-Number option Format is Selected.";

            string autoText = this.IRTemplateSelectAutonumberOption1.FAGetText(); 
            if (this.IRTemplateSelectAutonumberOption1.ContextHighlight().DelayOnce(10).Visible() == true)
            {
                Support.AreEqual(autoText, "Insert Auto Number Option Format A", true);
            }
           
            Reports.TestStep = "Click on OK in Autonumber Dialog.";
            this.IRTemplateSelectAutonumberOK.ContextHighlight().DelayOnce(10).FAClick();

            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(1000);
            this.CloseEditor();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.DesPhrasesName);
            Playback.Wait(1000);
            FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(5); 
            FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();   
          
            
        }




        public void Regional_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateType)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion
            
            
            #region Create template
            Reports.TestStep = "Create a new template";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
            FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();

            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
            FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
            string templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));

            FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("TEST-Template-Regional" + Support.RandomString(templateDescription.Repeat(2)));

            FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            #endregion

            #region Insert template
            Reports.TestStep = "Insert template";
            FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
            FastDriver.NextGenDocumentPreparation.Editor.FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(5000);
            // FastDriver.DocumentEditor.InsertRegionFormBelowAndSave(groupName + "/" + phraseName, phraseDescription);
            FastDriver.DocumentEditor.InsertRegionFormBelowAndSave();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
            //Playback.Wait(1000);
            //FastDriver.NextGenDocumentPreparation.Save.Highlight(5); 
            //FastDriver.NextGenDocumentPreparation.Save.FAClick();
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
            #endregion

         
        }


        public void Regional_Template_Edit(string templateType, string templateName)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Search for Existing Template
            Reports.TestStep = "Search for Existing Template";
            FastDriver.NextGenDocumentPreparation.SearchExistingTemplate(templateType, templateName);
            #endregion

            #region Select a Template and right click for View/Edit Template option
            Reports.TestStep = "Select a Template and right click for View/Edit Template option";
            FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
            Playback.Wait(3000);
            #endregion 
          
            #region Check Under Construction Checkbox and Click on Save
            Reports.TestStep = "Check Under Construction Checkbox and Click on Save";
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
            Playback.Wait(1000);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            #endregion

            #region Edit template
            Reports.TestStep = "Edit template";
            FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
            FastDriver.NextGenDocumentPreparation.Editor.FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(5000);
            
            FastDriver.DocumentEditor.InsertRegionFormBelowAndSave();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
            Playback.Wait(5000);
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

            FastDriver.NextGenDocumentPreparation.Save.Highlight(8);
            
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
            #endregion


        }


        public void InsertRegionFormBelowAndSave()
        {
            this.InsertRegionFormBelow();
            //this.SaveAndClose();
            this.CloseEditor();
        }     
      

        public void InsertRegionFormBelow()
        {
            
                this.IRInsertPhrase10.DelayOnce(30).ContextHighlight().ContextClick();
                this.IRInsertPhraseBottom2.ContextHighlight().FAClick();               
                this.IRInsertRegionalForm.ContextHighlight();
                this.IRInsertRegionalForm.FAClick();
                this.HandlePhraseMarker();                
        }


        public void AutoNumber_Template_Edit(string templateType, string templateName)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Search for Existing Template
            Reports.TestStep = "Search for Existing Template";
            FastDriver.NextGenDocumentPreparation.SearchExistingTemplate(templateType, templateName);
            #endregion

            #region Select a Template and right click for View/Edit Template option
            Reports.TestStep = "Select a Template and right click for View/Edit Template option";
            FastDriver.NextGenDocumentPreparation.TemplateResultsTable.PerformTableAction("Description", templateName, "Description", TableAction.Click).Element.FARightClick();
            FastDriver.NextGenDocumentPreparation.ViewEditTemplateTemplsearch.FASelectContextMenuItem();
            Playback.Wait(3000);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(true);
            FastDriver.NextGenDocumentPreparation.Save.Highlight(8);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();            
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);

            #endregion          
            
           
            #region Edit template
            Reports.TestStep = "Edit template";
            FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
            FastDriver.NextGenDocumentPreparation.Editor.FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(6000);        
          
            #endregion

            #region Click on Phrase and Insert Auto Number
            this.NumberingProperties();
            #endregion

            #region Save Template
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);    
            FastDriver.NextGenDocumentPreparation.Save.Highlight(8);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.Open(); 
            #endregion

           
        }





        public void HandlePhraseMarker()
        {
            
                this.IRSelectFormDocument.ContextHighlight().FAClick();
                this.IRSelectFormDocumentOption.ContextHighlight().FAClick();

                this.IRSelectFormInsert.ContextHighlight().DoubleClick();
                Playback.Wait(5000);
                FastDriver.DocumentEditor.WaitForScreenToLoad();             
             
        }




        //public void InsertPhraseMarker(string reason)
        //{

        //    if (this.IRUnfinalizeEdited.Visible())
        //    {
        //        this.IRUnfinalizeEdited.ContextHighlight().FAClick();
        //    }

        //    this.IRUnfinalizeReasonTextEdit.ContextHighlight().FAClick();

        //    Keyboard.SendKeys(reason);
        //    Playback.Wait(1000);
        //    this.IRUnfinalizeReasonOKEdit.ContextHighlight().Click();

        //}




        public void PhraseInsertAbovePhrase()
        {
            this.IRInsertPhraseArrowWhite.ContextClick();
            this.IRPhraseInsert.FAClick();
            this.IRPhraseInsertAbove.FAClick();
            this.IRInsertSearch6.DoubleClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
        }

        public void InsertMultiplePhrase()
        {
            if (this.IRInsertPhrase3.Visible())
            {
                this.IRInsertPhrase3.ContextClick();
                this.IRInsertPhraseBottom3.FAClick();
                this.IRInsertSearch1st3.ContextHighlight();
                this.IRInsertSearch1st3.DoubleClick();
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextClick();
                this.IRInsertPhraseBottom2.FAClick();
                this.IRInsertSearch4.ContextHighlight();
                this.IRInsertSearch4.DoubleClick();
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText("0088/883 , DE12/SLL1");
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, "0088/883", 1, TableAction.Click);

            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
            this.SaveAndClose();
        }

        public void InsertSamePhraseMultipleTimes()
        {
            if (this.IRInsertPhrase3.Visible())
            {
                this.IRInsertPhrase3.ContextClick();
                this.IRInsertPhraseBottom3.FAClick();
                this.IRInsertSearch1st3.ContextHighlight();
                this.IRInsertSearch1st3.DoubleClick();
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextClick();
                this.IRInsertPhraseBottom2.FAClick();
                this.IRInsertSearch4.ContextHighlight();
                this.IRInsertSearch4.DoubleClick();
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Description.FASetText("0088/883 , 0088/883 , 0088/883");
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, "0088/883", 1, TableAction.Click);

            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
            this.SaveAndClose();
        }

        public void PhraseInsertAboveMisc()
        {
            this.IRInsertPhraseArrowWhite.ContextClick();
            this.IRPhraseInsert.FAClick();
            this.IRPhraseInsertAbove.FAClick();
            this.IRInsertPhraseMisc.DoubleClick();
        }

        public void AcceptCreateMisc()
        {
            Microsoft.VisualStudio.TestTools.UITesting.Keyboard.SendKeys(FAKeys.TabAway);
            if (this.IRInsertPhraseCreate.Visible())
                this.IRInsertPhraseCreate.DoubleClick();
            else if (this.IRInsertPhraseCreate3.Visible())
                this.IRInsertPhraseCreate3.DoubleClick();
            else
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Create' was not found by ImageRecognition");
        }

        public void InsertMiscPhrase()
        {
            if (this.IRInsertPhrase3.Visible())
            {
                this.IRInsertPhrase3.ContextClick();
                this.IRInsertPhraseBottom3.FAClick();
                this.IRInsertPhraseMisc2.ContextHighlight();
                this.IRInsertPhraseMisc2.DoubleClick();
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextClick();
                this.IRInsertPhraseBottom2.FAClick();
                this.IRInsertPhraseMisc3.ContextHighlight();
                this.IRInsertPhraseMisc3.DoubleClick();
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }

            this.AcceptCreateMisc();
            //
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
        }

        public void InsertMiscPhraseAndSave()
        {
            this.InsertMiscPhrase();
            this.SaveAndClose();
        }

        public void PhraseInsertRestartNumbering()
        {
            this.IRInsertPhraseArrowWhite.DelayOnce(3).ContextClick();
            this.IRPhraseInsert2.DelayOnce(1).FAClick();
            this.IRPhraseInsertAbove2.DelayOnce(1).FAClick();
            this.IRInsertRestartNumbering4.ContextHighlight();
            this.IRInsertRestartNumbering4.FAClick();
            this.IRInsertDlgButton.DelayOnce(3).ContextHighlight();
            this.IRInsertDlgButton.FAClick();
            FASTHelpers.KeyboardSendKeys("{ENTER}");
            //
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
        }

        public void InsertRestartNumbering()
        {
            if (this.IRInsertPhrase3.DelayOnce(3).Visible())
            {
                this.IRInsertPhrase3.ContextClick();
                this.IRInsertPhraseBottom3.FAClick();
                this.IRInsertRestartNumbering2.ContextHighlight();
                this.IRInsertRestartNumbering2.FAClick();
                this.IRInsertDlgButton.DelayOnce(3).ContextHighlight();
                this.IRInsertDlgButton.FAClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextClick();
                this.IRInsertPhraseBottom2.DelayOnce(1).FAClick();
                this.IRInsertRestartNumbering.DelayOnce(1).ContextHighlight();
                this.IRInsertRestartNumbering.FAClick();
                this.IRInsertDlgButton.DelayOnce(3).ContextHighlight();
                this.IRInsertDlgButton.FAClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }
            //
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
        }

        public void InsertRestartNumberingAndSave()
        {
            this.InsertRestartNumbering();
            this.SaveAndClose();
        }

        public void FinalizeDocument()
        {
            this.IRFinalize.FAClick();
            if (this.IRUnfinalize.DelayOnce(3).Visible() == false)
                this.IRFinalize.FAClick();
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.IsTrue(this.IRUnfinalize.DelayOnce(10).Visible(), "Unfinalize button should be displayed");
        }


        public void FinalizeDocument1()
        {
            this.IRFinalize1.ContextHighlight().FAClick();
            Playback.Wait(3000);  
            
        }

        public void UnfinalizeDocument(string reason)
        {
            if (this.IRUnfinalize.Visible())
            {
                this.IRUnfinalize.FAClick();
            }
            else
            {
                this.IRUnfinalizeBlack.FAClick();
            }
            this.IRUnfinalizeReasonText.DelayOnce(3).FAClick();
            this.IRUnfinalizeReasonOK.FAClick();
            FASTHelpers.KeyboardSendKeys(reason);
            Microsoft.VisualStudio.TestTools.UnitTesting.Assert.IsTrue(this.IRFinalize.OverOffset(60, 0).DelayOnce(10).Visible(), "Finalize button should be displayed");
        }

        public void UnfinalizeDocumentEdit(string reason)
        {
           
            if (this.IRUnfinalizeEdited.Visible())
            {
                this.IRUnfinalizeEdited.ContextHighlight().FAClick();
            }
            
            this.IRUnfinalizeReasonTextEdit.ContextHighlight().FAClick() ;
           
            Keyboard.SendKeys(reason);
            Playback.Wait(1000);  
            this.IRUnfinalizeReasonOKEdit.ContextHighlight().Click() ; 
            
        }


        public void PhraseDelete(string reason)
        {
            this.IRInsertPhraseArrowWhite.DelayOnce(3).ContextClick();
            this.IRPhraseDelete.DelayOnce(1).FAClick();
            this.IRPhraseDeleteReasonText.DelayOnce(1).FAClick();
            FASTHelpers.KeyboardSendKeys(reason);
            this.IRPhraseDeleteReasonOK.DelayOnce(1).FAClick();
        }

        public void PhraseMoveBelow()
        {
            this.IRInsertPhraseArrowWhite.DelayOnce(3).ContextClick();
            this.IRInsertPhraseMove.DelayOnce(1).FAClick();
            this.IRInsertPhraseBelowGray.DelayOnce(1).FAClick();
        }

        public void PhraseMoveAbove()
        {
            this.IRInsertPhraseArrowWhite.OverOffset(0, 30).DelayOnce(3).ContextClick();
            this.IRInsertPhraseMove.OverOffset(0, 30).DelayOnce(1).FAClick();
            this.IRPhraseInsertAbove2.OverOffset(0, 30).DelayOnce(1).FAClick();
        }

        public void PhraseInsertAboveSectionBreak()
        {            
            this.IRInsertPhraseArrowWhite.DelayOnce(3).ContextClick();
            this.IRPhraseInsert2.DelayOnce(1).FAClick();
            this.IRPhraseInsertAbove2.DelayOnce(1).FAClick();
            this.IRInsertSectionBreak3.ContextHighlight();
            this.IRInsertSectionBreak3.FAClick();
            this.IRInsertDlgButton2.DelayOnce(3).ContextHighlight();
            this.IRInsertDlgButton2.FAClick();
            FASTHelpers.KeyboardSendKeys("{ENTER}");
            //
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
        }

        public void InsertSectionBreak()
        {
            if (this.IRInsertPhrase3.Visible())
            {
                this.IRInsertPhrase3.ContextClick();
                this.IRInsertPhraseBottom3.FAClick();
                this.IRInsertSectionBreak3.DelayOnce(1).ContextHighlight().FAClick();
                this.IRInsertDlgButton2.DelayOnce(3).ContextHighlight().FAClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextClick();
                this.IRInsertPhraseBottom2.DelayOnce(1).FAClick();
                this.IRInsertSectionBreak.DelayOnce(1).ContextHighlight().FAClick();
                this.IRInsertDlgButton2.DelayOnce(3).ContextHighlight().FAClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
            }
            //
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
        }

        public void InsertSectionBreakAndSave()
        {
            this.InsertSectionBreak();
            this.SaveAndClose();
        }

        public void InsertDataElement()
        {
            var currentLine = this.IRDocumentCurrentLine2;
            if (currentLine.DelayOnce(10).Visible() == false)
                currentLine.DelayOnce(60);
            currentLine.FAClick();
            Microsoft.VisualStudio.TestTools.UITesting.Keyboard.SendKeys(FAKeys.Enter);
            this.IRDocumentCurrentLine6.DelayOnce(3).ContextClick();
            this.IR_CM_InsertDataElement3.DelayOnce(3).FAClick();
            this.IRInsertSearch5.DoubleClick();
            Microsoft.VisualStudio.TestTools.UITesting.Keyboard.SendKeys(FAKeys.Enter);
            FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
            FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
            FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
            FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
            FastDriver.DataElementSelectionDlg.Select.FAClick();
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
            this.SaveAndClose();
        }

        public void CloseEditor()
        {
            this.Close.FAClick();
            if (this.WaitCreation(this.Yes, continueOnFailure: true))
                this.Yes.FAClick();
            Microsoft.VisualStudio.TestTools.UITesting.Playback.Wait(6000);
        }

        public void SaveAndClose()
        {
            Microsoft.VisualStudio.TestTools.UITesting.Playback.Wait(3000);
            FASTHelpers.MouseClick(this.getCenter());
            FASTHelpers.KeyboardSendKeys("{HOME}");
            FASTHelpers.KeyboardSendKeys("{PGUP}");
            var scrollUpArrow = this.IRScrollUpArrow;
            if (scrollUpArrow.DelayOnce(3).Visible())
            {
                scrollUpArrow.ContextHighlight().MultiClick(3).FAClick();
                FASTHelpers.KeyboardSendKeys("{PGUP}");
            }
            this.IRClickSave();
            this.WaitForScreenToLoad();
            this.CloseEditor();
        }

        public void HandleInsertTemplateDlg(string templateType, int index = 1)
        {
            FastDriver.TemplateSelectionDlg.WaitForScreenToLoad();
            FastDriver.TemplateSelectionDlg.TemplateType.FASelectItem(templateType);
            Microsoft.VisualStudio.TestTools.UITesting.Playback.Wait(5000);
            FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction(index, 1, TableAction.Click);
            string templateDescription = FastDriver.TemplateSelectionDlg.TemplateTable.PerformTableAction(1, 2, TableAction.GetText).Message;
            FastDriver.DialogBottomFrame.ClickDone();
        }

        public void PhraseInsertAboveTemplate()
        {
            this.IRInsertPhraseArrowWhite.DelayOnce(3).ContextClick();
            this.IRPhraseInsert.DelayOnce(1).FAClick();
            this.IRPhraseInsertAbove.DelayOnce(1).FAClick();
            this.IRInsertSearch2nd4.DelayOnce(1).DoubleClick();
            FASTHelpers.KeyboardSendKeys("{ENTER}");
            Playback.Wait(6000);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Template Selection", true, 30);
        }

        public void InsertTemplate(string templateType, int index = 1)
        {
            if (this.IRInsertPhrase5.DelayOnce(10).Visible())
            {
                this.IRInsertPhrase5.ContextClick();
                this.IRInsertPhraseBottom5.FAClick();
                this.IRInsertSearch2nd2.DelayOnce(3).DoubleClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else if (this.IRInsertPhrase2.Visible())
            {
                this.IRInsertPhrase2.ContextHighlight().ContextClick();
                this.IRInsertPhraseBottom2.ContextHighlight().FAClick();
                this.IRInsertSearch2nd3.DelayOnce(1).DoubleClick();
                FASTHelpers.KeyboardSendKeys("{ENTER}");
            }
            else
            {
                SeleniumInternalHelpersSupportLibrary.Support.Fail("'Insert Phrase/Search Template' was not found by ImageRecognition");
            }
            Playback.Wait(6000);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Template Selection", true, 30);
            this.HandleInsertTemplateDlg(templateType, index);
        }

        public void InsertTemplateAndSave(string templateType, int index = 1)
        {
            this.InsertTemplate(templateType, index);
            this.SaveAndClose();
        }

        public void InsertDataElementwithIDandIndex(string DataElementID, string indexvalue)
        {
            var currentLine = this.IRDocumentCurrentLine2;
            if (currentLine.DelayOnce(10).Visible() == false)
                currentLine.DelayOnce(60);
            currentLine.FAClick();
            Microsoft.VisualStudio.TestTools.UITesting.Keyboard.SendKeys(FAKeys.Enter);
            this.IRDocumentCurrentLine6.DelayOnce(3).ContextClick();
            this.IR_CM_InsertDataElement3.DelayOnce(3).FAClick();
            this.IRInsertSearch5.DoubleClick();
            Microsoft.VisualStudio.TestTools.UITesting.Keyboard.SendKeys(FAKeys.Enter);
            FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
            FastDriver.DataElementSelectionDlg.DataElement.FASetText(DataElementID);
            FastDriver.DialogBottomFrame.ClickDone();
            Playback.Wait(5000);
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
            FastDriver.DocumentEditor.DP_PE_FirstDE.ContextHighlight().DelayOnce(10).ContextClick() ;            
            FastDriver.DocumentEditor.DP_PE_FirstDE_Properties.ContextHighlight().DelayOnce(10).FAClick();
            FastDriver.DataElementsDlg.WaitForScreenToLoad();
            FastDriver.DataElementsDlg.Index.FASetText(indexvalue);
            FastDriver.DataElementsDlg.Ok.FAClick();
            Playback.Wait(2000);
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
            FastDriver.DocumentEditor.DP_PE_SecondDE.Highlight();
            FastDriver.DocumentEditor.DP_PE_SecondDE.FAClick();
            FastDriver.DocumentEditor.DP_PE_SecondDE.FARightClick();
            FastDriver.DocumentEditor.DP_PE_SecondDE_Properties.FAClick();
            FastDriver.DataElementsDlg.WaitForScreenToLoad();
            FastDriver.DataElementsDlg.Index.FASetText(indexvalue);
            FastDriver.DataElementsDlg.Ok.FAClick();
            Playback.Wait(2000);
            FastDriver.WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            this.WaitForScreenToLoad();
            this.SaveAndClose();
        }


    }

}

