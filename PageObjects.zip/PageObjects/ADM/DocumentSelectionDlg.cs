using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class DocumentSelectionDlg : PageObject
    {
        public string WindowTitle { get { return "Document Selection"; } }

        #region WebElements

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_0_chkSelect1")]
        public IWebElement SelectDocument { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_0_cboRequired")]
        public IWebElement Required { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_dgDocuments")]
        public IWebElement DocumentSelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_1_chkSelect1")]
        public IWebElement Select1Document { get; set; }

        [FindsBy(How = How.Id, Using = "ddlRegion")]
        public IWebElement Region { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTemplateType")]
        public IWebElement TemplateType { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_0_chkSelect")]
        public IWebElement Results0Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_0_cboStatus")]
        public IWebElement Results0Status { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_0_cboRequired")]
        public IWebElement Results0Required { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_0_chkAutoCreate")]
        public IWebElement Results0AutoCreate { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_1_chkSelect")]
        public IWebElement Results1Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_0_chkSelect")]
        public IWebElement SelectDocument1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_dgSearchResults")]
        public IWebElement DocumnentSearchTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_2_chkSelect")]
        public IWebElement Results2Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_3_chkSelect")]
        public IWebElement Results3Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_4_chkSelect")]
        public IWebElement Results4Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_5_chkSelect")]
        public IWebElement Results5Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_6_chkSelect")]
        public IWebElement Results6Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_7_chkSelect")]
        public IWebElement Results7Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_8_chkSelect")]
        public IWebElement Results8Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_9_chkSelect")]
        public IWebElement Results9Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_10_chkSelect")]
        public IWebElement Results10Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_11_chkSelect")]
        public IWebElement Results11Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_12_chkSelect")]
        public IWebElement Results12Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_13_chkSelect")]
        public IWebElement Results13Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_14_chkSelect")]
        public IWebElement Results14Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_15_chkSelect")]
        public IWebElement Results15Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_16_chkSelect")]
        public IWebElement Results16Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_17_chkSelect")]
        public IWebElement Results17Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_18_chkSelect")]
        public IWebElement Results18Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_19_chkSelect")]
        public IWebElement Results19Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_20_chkSelect")]
        public IWebElement Results20Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_21_chkSelect")]
        public IWebElement Results21Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_2_chkSelect1")]
        public IWebElement Select2Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_3_chkSelect1,Name")]
        public IWebElement Select3Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_4_chkSelect1,Name")]
        public IWebElement Select4Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_5_chkSelect1,Name")]
        public IWebElement Select5Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_6_chkSelect1,Name")]
        public IWebElement Select6Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_7_chkSelect1,Name")]
        public IWebElement Select7Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_8_chkSelect1,Name")]
        public IWebElement Select8Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_9_chkSelect1,Name")]
        public IWebElement Select9Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_10_chkSelect1,Name")]
        public IWebElement Select10Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_11_chkSelect1,Name")]
        public IWebElement Select11Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_12_chkSelect1,Name")]
        public IWebElement Select12Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_13_chkSelect1,Name")]
        public IWebElement Select13Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_14_chkSelect1,Name")]
        public IWebElement Select14Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_15_chkSelect1,Name")]
        public IWebElement Select15Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_16_chkSelect1,Name")]
        public IWebElement Select16Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_17_chkSelect1,Name")]
        public IWebElement Select17Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_18_chkSelect1,Name")]
        public IWebElement Select18Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_19_chkSelect1,Name")]
        public IWebElement Select19Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_20_chkSelect1,Name")]
        public IWebElement Select20Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_21_chkSelect1,Name")]
        public IWebElement Select21Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_22_chkSelect1")]
        public IWebElement Select22Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_23_chkSelect1")]
        public IWebElement Select23Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_24_chkSelect1")]
        public IWebElement Select24Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_25_chkSelect1")]
        public IWebElement Select25Document { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_23_lblDocName")]
        public IWebElement ClosingBuyerOnly { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_24_lblDocName")]
        public IWebElement ClosingCombined { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_25_lblDocName")]
        public IWebElement ClosingSellerOnly { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_26_lblDocName")]
        public IWebElement ClosingSubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_23_cboStatus")]
        public IWebElement Status1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_24_cboStatus")]
        public IWebElement Status2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_25_cboStatus")]
        public IWebElement Status3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_26_cboStatus")]
        public IWebElement Status4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_23_cboRequired")]
        public IWebElement Required1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_24_cboRequired")]
        public IWebElement Required2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_25_cboRequired")]
        public IWebElement Required3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_26_cboRequired")]
        public IWebElement Required4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_23_chkAutoCreate")]
        public IWebElement AutoCreate1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_24_chkAutoCreate")]
        public IWebElement AutoCreate2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_25_chkAutoCreate")]
        public IWebElement AutoCreate3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults_26_chkAutoCreate")]
        public IWebElement AutoCreate4 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPgNum")]
        public IWebElement PageCounter { get; set; }

        [FindsBy(How = How.Id, Using = "txtSearchValue")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "ddlRegion")]
        public IWebElement Source { get; set; }

        [FindsBy(How = How.Id, Using = "btnNext")]
        public IWebElement Next { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrev")]
        public IWebElement Previous { get; set; }
        #endregion

        #region Useful Methods
        public DocumentSelectionDlg WaitForScreenToLoad(IWebElement element = null, bool switchToFraPageWin = true)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin);
            this.WaitCreation(element ?? Clear);
            return this;
        }

        public DocumentSelectionDlg WaitForDocumentSelectionToRefresh(string value = null)
        {
            this.WaitForValue(PageCounter, value);
            return this;
        }

        public DocumentSelectionDlg WaitForScreenLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(WindowTitle, timeoutSeconds: 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FindNow);
            return this;
        }


        #endregion


    }
}
