using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class DocumentSequencingDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtPackage")]
		public IWebElement Package { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDocUp")]
		public IWebElement Up { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDocDown")]
		public IWebElement Down { get; set; }

		[FindsBy(How = How.Id, Using = "dgDocs_dgDocs")]
		public IWebElement SequenceTable { get; set; }

		#endregion

        #region Useful Methods
        public DocumentSequencingDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Up);
            return this;
        }
        #endregion

    }
}
