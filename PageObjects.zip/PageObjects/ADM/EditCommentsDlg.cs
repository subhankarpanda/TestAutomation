using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class EditCommentsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "Button1")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

        #endregion

        public EditCommentsDlg WaitForScreenToLoad()
        {
            
            this.SwitchToDialogContentFrame(switchToFraPageWin:false);
            this.WaitCreation(Done);
            return this;
        }
    }
}
