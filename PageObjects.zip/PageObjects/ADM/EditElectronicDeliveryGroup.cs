using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class EditElectronicDeliveryGroup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "FAFTxtFaxGroupName")]
		public IWebElement FaxGroupName { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtFaxNumber")]
		public IWebElement FaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtPhoneNumber")]
		public IWebElement PhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtEmailID")]
		public IWebElement EmailID { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtAddressLine1")]
		public IWebElement AddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtAddressLine2")]
		public IWebElement AddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtAddressLine3")]
		public IWebElement AddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtAddressLine4")]
		public IWebElement AddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "txtCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "cboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "txtZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtDescription")]
		public IWebElement Description { get; set; }

		#endregion

        public EditElectronicDeliveryGroup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Description, true);
            return this;
        }
	}
}
