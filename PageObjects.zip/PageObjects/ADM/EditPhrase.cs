using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class EditPhrase : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement PhraseGroupCode { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "cmdProperties")]
		public IWebElement PhraseProperties { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEditor")]
		public IWebElement PhraseEditor { get; set; }

		[FindsBy(How = How.LinkText, Using = "Phrase Group/Phrase Code:  ")]
        public IWebElement PhraseGroupPhraseCode { get; set; }
        #endregion

        public EditPhrase Open()
        {
            FastDriver.LeftNavigation.Navigate<EditPhrase>("Home>System Maintenance>Document Preparation>Edit Phrase");
            this.WaitForScreenToLoad();

            return this;
        }

        public EditPhrase WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? PhraseGroupCode);

            return this;
        }
	}
}
