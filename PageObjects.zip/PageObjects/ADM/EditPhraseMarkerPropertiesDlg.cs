using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class EditPhraseMarkerPropertiesDlg : PageObject
	{
        public string WindowTitle { get { return "Edit Phrase Marker Properties"; } }

		#region WebElements

		[FindsBy(How = How.Id, Using = "cboFrmName")]
		public IWebElement FormName { get; set; }

		[FindsBy(How = How.Id, Using = "chkLDRFrms")]
		public IWebElement LoadDocPrepRegionForms { get; set; }

		[FindsBy(How = How.Id, Using = "chkPBrk")]
		public IWebElement PageBreak { get; set; }

		[FindsBy(How = How.Id, Using = "chkAuto")]
		public IWebElement AutoOutlineRestart { get; set; }

		#endregion

        public EditPhraseMarkerPropertiesDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(WindowTitle, true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FormName);

            return this;
        }

        public EditPhraseMarkerPropertiesDlg EnterInformation(string formName, bool regionForms = false, bool pageBreak = false, bool autoOutlineRestart = false)
        {
            WaitForScreenToLoad(FormName);

            FormName.FASelectItem(formName);
            LoadDocPrepRegionForms.FASetCheckbox(regionForms);
            PageBreak.FASetCheckbox(pageBreak);
            AutoOutlineRestart.FASetCheckbox(autoOutlineRestart);
            //anyone can add more interaction steps, just add optional patameters and default to null

            return this;
        }

	}
}
