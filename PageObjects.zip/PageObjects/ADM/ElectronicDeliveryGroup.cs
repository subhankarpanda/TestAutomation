using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ElectronicDeliveryGroup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridGroupSummary")]
		public IWebElement SummaryTable { get; set; }

		#endregion

        public ElectronicDeliveryGroup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SummaryTable, true);
            return this;
        }
	}
}
