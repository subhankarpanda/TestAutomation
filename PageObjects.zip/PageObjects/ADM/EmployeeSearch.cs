using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.ADM;
using System.ComponentModel;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.ADM
{
    public class EmployeeSearch : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtLoginName")]
        public IWebElement LoginName { get; set; }

        [FindsBy(How = How.Id, Using = "btnSearchNow")]
        public IWebElement SearchNow { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "comboRegion")]
        public IWebElement Region { get; set; }

        [FindsBy(How = How.Id, Using = "comboOffice")]
        public IWebElement Office { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "dgridEmployeeSummary")]
        public IWebElement SearchResultsEmployees { get; set; }

        [FindsBy(How = How.Id, Using = "dgridEmployeeSummary_0_lblLoginName")]
        public IWebElement LoginNameElement { get; set; }

        #endregion

        public EmployeeSearch WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoginName);
            return this;
        }

        [Description("Search Employee")]
        public virtual EmployeeSearch SearchEmployee(EmployeeSearchParameters employee)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoginName);
            Region.FASelectItem(employee.Region);
            Playback.Wait(3000);
            this.SwitchToContentFrame();
            this.WaitCreation(LoginName);
            Office.FASelectItem(employee.Office);
            LoginName.FASetText(employee.LoginName);
            FirstName.FASetText(employee.FirstName);
            LastName.FASetText(employee.LastName);
            SearchNow.FAClick();
            return this;
        }

        [Description("Edit Employee")]
        public virtual void EditEmployee(string searchCriteria)
        {
            FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(1, "[" + searchCriteria + "]", 1, TableAction.Click);
            FastDriver.EmployeeSearch.Edit.Click();
            FastDriver.EmployeeSetup.WaitForScreenToLoad();
        }

        public EmployeeSearch Open()
        {
            FastDriver.LeftNavigation.Navigate<EmployeeSetup>("Home>System Maintenance>Employee Setup");
            return this.WaitForScreenToLoad();
        }

        public EmployeeSetup ClickOnNew()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New);
            New.FAClick();

            return FastDriver.GetPage<EmployeeSetup>();
        }
    }
}
