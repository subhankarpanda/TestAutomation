﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;

namespace FASTSelenium.PageObjects.ADM
{
    public class EmployeeSecurity : PageObject
    {
        [FindsBy(How = How.Id, Using = "txtLoginName")]
        public IWebElement LoginNameTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstName")]
        public IWebElement FirstNameTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement LastNameTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "comboRegion")]
        public IWebElement RegionDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "comboOffice")]
        public IWebElement OfficeDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "btnSearchNow")]
        public IWebElement SearchNowButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewSearch")]
        public IWebElement NewSearchButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgridEmployeeSummary")]
        public IWebElement ResultsTable { get; set; }



        public EmployeeSecurity WaitForScreenToLoad(IWebElement element = null, int timeout = 10)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? LoginNameTextbox);
            return this;
        }
        

        //public EmployeeSecutiry SearchEmployee(EmployeeSearchParameters employee)
        //{
        //    this.SwitchToContentFrame();
        //    this.WaitCreation(LoginNameTextbox);
        //    LoginNameTextbox.SendKeys(employee.LoginName);
        //    FirstNameTextbox.SendKeys(employee.FirstName);
        //    LastNameTextbox.SendKeys(employee.LastName);
        //    RegionDropdown.SendKeys(employee.Region);
        //    OfficeDropdown.SendKeys(employee.Office);
        //    SearchNowButton.Click();
        //    
        //    return this;
        //}

        //public BusinessUnitRoleAssignment DoubleClickUserInSearchResults(string user)
        //{
        //    this.SwitchToContentFrame();
        //    this.WaitCreation(ResultsTable);
        //    ResultsTable.PerformTableAction(2, user, 3, TableAction.DoubleClick);
        //    
        //    return FastDriver.GetPage<BusinessUnitRoleAssignment>();
        //}
        public void SearchAndSelectEmployee(string User,string RegionName="",string OfficeName="")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoginNameTextbox);
            LoginNameTextbox.FASetText(User);
            if (!string.IsNullOrEmpty(RegionName))
                RegionDropdown.FASelectItem(RegionName);
            if (!string.IsNullOrEmpty(OfficeName))
                OfficeDropdown.FASelectItem(OfficeName);
            SearchNowButton.Click();
            System.Threading.Thread.Sleep(4000);
            this.WaitCreation(ResultsTable);
            ResultsTable.PerformTableAction(1, "[" + User.ToUpper() + "]", 1, TableAction.DoubleClick);
        }

        public EmployeeSecurity Open()
        {
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>System Maintenance>Security Maintenance>Employee Security");
            this.WaitForScreenToLoad();
            return this;
        }
    }
}
