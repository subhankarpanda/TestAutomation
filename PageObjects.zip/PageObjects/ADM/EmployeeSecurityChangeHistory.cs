using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class EmployeeSecurityChangeHistory : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "divGridBody")]
		public IWebElement View { get; set; }

		[FindsBy(How = How.Id, Using = "dgEmpHistoryEvents_dgEmpHistoryEvents")]
		public IWebElement SecurityHistoryTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgEmpHistoryEvents_dgEmpHistoryEvents")]
        public IWebElement SecurityHistory { get; set; }

		[FindsBy(How = How.LinkText, Using = "BUID")]
		public IWebElement Columns { get; set; }

		#endregion

        #region Useful Methods
        public EmployeeSecurityChangeHistory WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SecurityHistoryTable);
            return this;
        }
        #endregion

	}
}
