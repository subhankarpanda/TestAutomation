using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
    public class EmployeeSetup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnEmpSecurity")]
        public IWebElement ViewEmployeeSecurity { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "textIDCode")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddRemoveWorkGroup")]
        public IWebElement AddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "textFirstName")]
        public IWebElement FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "optAll")]
        public IWebElement All { get; set; }

        [FindsBy(How = How.Id, Using = "textMiddleName")]
        public IWebElement MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "optNone")]
        public IWebElement None { get; set; }

        [FindsBy(How = How.Id, Using = "textLastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "optSelected")]
        public IWebElement Selected { get; set; }

        [FindsBy(How = How.Id, Using = "textInitials")]
        public IWebElement Initials { get; set; }

        [FindsBy(How = How.Id, Using = "textSuffix")]
        public IWebElement Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "textEmployeeID")]
        public IWebElement EmployeeID { get; set; }

        [FindsBy(How = How.Id, Using = "chkOffGroup")]
        public IWebElement VirtualInbox { get; set; }

        [FindsBy(How = How.Id, Using = "txtProfileName")]
        public IWebElement AssignedProfileName { get; set; }

        [FindsBy(How = How.Id, Using = "lboxEmpFunTypes")]
        public IWebElement EmployeeTypes { get; set; }

        [FindsBy(How = How.Id, Using = "textUserName")]
        public IWebElement UserName { get; set; }

        [FindsBy(How = How.Id, Using = "textDescription")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "cboHighlightSignaturesOption")]
        public IWebElement HighlightSignatures { get; set; }

        [FindsBy(How = How.Id, Using = "chkContractor")]
        public IWebElement Contractor { get; set; }

        [FindsBy(How = How.Id, Using = "FromDt")]
        public IWebElement FromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ToDt")]
        public IWebElement ToDate { get; set; }

        [FindsBy(How = How.Id, Using = "comboRegion")]
        public IWebElement HomeRegion { get; set; }

        [FindsBy(How = How.Id, Using = "comboHomeOffice")]
        public IWebElement HomeOffice { get; set; }

        [FindsBy(How = How.Id, Using = "cmdView")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "employeeSignature")]
        public IWebElement SignatureFile { get; set; }

        [FindsBy(How = How.Id, Using = "textSignTitle1")]
        public IWebElement SignatureTitle1 { get; set; }

        [FindsBy(How = How.Id, Using = "textSignTitle2")]
        public IWebElement SignatureTitle2 { get; set; }

        [FindsBy(How = How.Id, Using = "textSignTitle3")]
        public IWebElement SignatureTitle3 { get; set; }

        [FindsBy(How = How.Id, Using = "textComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddrNew")]
        public IWebElement NewAddress { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddrCopy")]
        public IWebElement CopyAddres { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddrDelete")]
        public IWebElement RemoveAddress { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_cmdAdd")]
        public IWebElement AddresDetailApply { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboAddressType")]
        public IWebElement AddressType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine1")]
        public IWebElement AddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine2")]
        public IWebElement AddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine3")]
        public IWebElement AddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textAddrLine4")]
        public IWebElement AddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCity")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textZip")]
        public IWebElement Zip { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_textCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "ctlPhysicalAddressDetail_comboCountry")]
        public IWebElement Country { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_cmdAddPhoneType")]
        public IWebElement PhonesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_cmdDeletePhoneEntry")]
        public IWebElement PhonesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_cmdNotification")]
        public IWebElement PhonesNotification { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_0_comboPhoneType")]
        public IWebElement BusinessPhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_0_textNumber")]
        public IWebElement BusinessPhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_0_textExtension")]
        public IWebElement BusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_0_cboNotificationType")]
        public IWebElement BusinessPhoneNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_0_textComments")]
        public IWebElement BusinessPhoneComment { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_1_comboPhoneType")]
        public IWebElement BusinessFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_1_textNumber")]
        public IWebElement BusinessFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_1_textExtension")]
        public IWebElement BusinessFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_1_cboNotificationType")]
        public IWebElement BusinessFaxNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_1_textComments")]
        public IWebElement BusinessFaxComment { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_2_comboPhoneType")]
        public IWebElement EmailType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_2_textNumber")]
        public IWebElement EmailTypeEmailID { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_2_cboNotificationType")]
        public IWebElement EmailTypeNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_2_textComments")]
        public IWebElement EmailTypeComment { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_3_comboPhoneType")]
        public IWebElement CellularType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_3_textNumber")]
        public IWebElement CellularTypeNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_3_textExtension")]
        public IWebElement CellularTypeExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_3_cboNotificationType")]
        public IWebElement CellularTypeNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_3_textComments")]
        public IWebElement CellularTypeComment { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_4_comboPhoneType")]
        public IWebElement PagerType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_4_textNumber")]
        public IWebElement PagerTypeNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_4_textExtension")]
        public IWebElement PagerTypeExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_4_cboNotificationType")]
        public IWebElement PagerTypeNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_4_textComments")]
        public IWebElement PagerTypeComment { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_5_comboPhoneType")]
        public IWebElement HomePhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_5_textNumber")]
        public IWebElement HomePhoneTypeNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_5_textExtension")]
        public IWebElement HomePhoneTypeExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_5_cboNotificationType")]
        public IWebElement HomePhoneTypeNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_5_textComments")]
        public IWebElement HomePhoneTypeComment { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_6_comboPhoneType")]
        public IWebElement HomeFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_6_textNumber")]
        public IWebElement HomeFaxTypeNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_6_textExtension")]
        public IWebElement HomeFaxTypeExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_6_cboNotificationType")]
        public IWebElement HomeFaxTypeNotificationType { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_6_textComments")]
        public IWebElement HomeFaxTypeComment { get; set; }

        [FindsBy(How = How.Id, Using = "cmdAddVendor")]
        public IWebElement AddVender { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDeleteVendor")]
        public IWebElement RemoveVendor { get; set; }

        [FindsBy(How = How.Id, Using = "dgridVendorInfo_0_cboVendor")]
        public IWebElement VendorType { get; set; }

        [FindsBy(How = How.Id, Using = "dgridVendorInfo_0_txtUserName")]
        public IWebElement VendorInfoUserName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridVendorInfo_0_txtVendorPassword")]
        public IWebElement VendorInfoPassword { get; set; }

        [FindsBy(How = How.Id, Using = "dgridVendorInfo_0_txtVendorAcctNum")]
        public IWebElement VendorInfoAccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_dgridPhoneTypes")]
        public IWebElement PhonesTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Escrow Assistant']")]
        public IWebElement RoleEAssistant { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Escrow Officer']")]
        public IWebElement RoleEOfficer { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Other']")]
        public IWebElement RoleOther { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Sales Rep']")]
        public IWebElement SalesRep { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Title Assistant']")]
        public IWebElement RoleTAssistant { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Title Officer']")]
        public IWebElement RoleTOfficer { get; set; }

        //[FindsBy(How = How.LinkText, Using = "Exchange Assistant")]
        //public IWebElement RoleExAssistant { get; set; }

        //[FindsBy(How = How.LinkText, Using = "Exchange Officer")]
        //public IWebElement RoleExOfficer { get; set; }

        //[FindsBy(How = How.LinkText, Using = "LastName: Last Name is a required field.")]
        //public IWebElement LastNameErrorMessage { get; set; }

        //[FindsBy(How = How.LinkText, Using = "Initials: Employee initials are a required field.")]
        //public IWebElement InitialsErrorMessage { get; set; }

        //[FindsBy(How = How.LinkText, Using = "FunctionTypeCdID: Function Type Code is required.")]
        //public IWebElement FunctionTypeErrorMessage { get; set; }

        //[FindsBy(How = How.LinkText, Using = "HomeOfficeID: Home Office designation is required to set up an Employee.")]
        //public IWebElement HomeOfficeErrorMessage { get; set; }

        //[FindsBy(How = How.LinkText, Using = "Descr: A function description is required for OTHER.")]
        //public IWebElement OtherDesciptionErrorMessage { get; set; }

        //[FindsBy(How = How.LinkText, Using = "LoginName: NT User Name already exists ")]
        //public IWebElement NTUserErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "labelStatus")]
        public IWebElement StatusElement { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement IDCodeErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_2_lblNotificationStatus")]
        public IWebElement EmailTypeNotificationStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ctlElectronicAddress_dgridPhoneTypes_1_lblNotificationStatus")]
        public IWebElement BusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "textADUserName")]
        public IWebElement ADUserName { get; set; }
        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Underwriter']")]
        public IWebElement RoleUnderwriter { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='Branch Manager']")]
        public IWebElement BranchManager { get; set; }

        [FindsBy(How = How.Id, Using = "txtUWLimit")]
        public IWebElement UWLiabilityAuthorityLimit { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement LicenseInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnViewChangeStatus")]
        public IWebElement LicenseInfoViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement LicenseInfoNew { get; set; }

        #endregion

        public EmployeeSetup WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(IDCode);
            return this;
        }
        //
        public EmployeeSearch Open()
        {
            FastDriver.LeftNavigation.Navigate<EmployeeSearch>("Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
            return FastDriver.EmployeeSearch;
        }
        //
        public bool SelectRoles(string[] Roles)
        {
            try
            {
                this.WaitForScreenToLoad();
                OpenQA.Selenium.Support.UI.SelectElement ele = new OpenQA.Selenium.Support.UI.SelectElement(EmployeeTypes);
                ele.DeselectAll();
                for (int i = 0; i < Roles.Length; i++)
                {
                        ele.SelectByText(Roles[i]);
                }

                //Validate that the required roles are selected

                List<string> SelectedRoles = ele.AllSelectedOptions.ToListString();

                for (int i = 0; i < Roles.Length; i++)
                {
                    if (!SelectedRoles.Contains(Roles[0]))
                    {
                        return false;
                    }
                }
                return true;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        //
        //
        public bool DeselectAllRoles()
        {
            try
            {
                this.WaitForScreenToLoad();
                OpenQA.Selenium.Support.UI.SelectElement ele = new OpenQA.Selenium.Support.UI.SelectElement(EmployeeTypes);
                ele.DeselectAll();

                List<string> SelectedRoles = ele.AllSelectedOptions.ToListString();
                for (int i = 0; i < 5; i++)
                {
                    if (SelectedRoles.Count != 0)
                    {
                        ele.DeselectAll();

                    }
                    else return true;
                }
                return false;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        //
        public bool ValidateEmployeeDetails(Dictionary<string,string> employeedetails)
        {
            
            bool emplyeedetailsarevalid=false;
          if(
             employeedetails["IDCode"]== this.IDCode.FAGetValue()
             &&employeedetails["FirstName"]== this.FirstName.FAGetValue()
             &&employeedetails["LastName"]== this.LastName.FAGetValue() 
             &&employeedetails["HomeOffice"]== this.HomeOffice.FAGetSelectedItem() 
             &&employeedetails["Workgroup"]== this.All.IsSelected().ToString() 
             &&employeedetails["EmployeeID"]== this.EmployeeID.FAGetValue() 
             &&employeedetails["UserName"]== this.UserName.FAGetValue() 

             &&employeedetails["VendorType"]== this.VendorType.FAGetSelectedItem() 
             &&employeedetails["VendorInfoUserName"]== this.VendorInfoUserName.FAGetValue() 
             &&employeedetails["VendorInfoPassword"]== this.VendorInfoPassword.FAGetValue() 
             &&employeedetails["VendorInfoAccountNumber"]== this.VendorInfoAccountNumber.FAGetValue().ToString()
               && employeedetails["Role 1"] == this.EmployeeTypes.FAGetAllSelectedItems()[1].ToString()
               && employeedetails["Role 2"] == this.EmployeeTypes.FAGetAllSelectedItems()[0].ToString())
           
          {
                emplyeedetailsarevalid=true;
            }
            return emplyeedetailsarevalid;
        }
        public Dictionary<string, string> CreateNewEmployee(string[] EmployeeType = null, string HomeRegion = "QA Automation Region - DO NOT TOUCH", string HomeOffice = "QA Automation Office - DO NOT TOUCH")
        {
            this.WaitForScreenToLoad();
            Dictionary<string, string> EmployeeData = new Dictionary<string, string>();
            try
            {

                this.FirstName.FASetText("FN" + Guid.NewGuid().ToString().Substring(0, 4));
                this.LastName.FASetText("LN" + Guid.NewGuid().ToString().Substring(0, 4));
                if (EmployeeType != null)
                {
                    this.SelectRoles(EmployeeType);
                }
                this.HomeRegion.FASelectItem(HomeRegion);
                string[] AllOffices = this.HomeOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains(HomeOffice))
                    {
                        this.HomeOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        this.WaitForScreenToLoad();
                        break;
                    }
                }
                EmployeeData.Add("FirstName", this.FirstName.FAGetValue());
                EmployeeData.Add("LastName", this.LastName.FAGetValue());
                EmployeeData.Add("HomeOffice", this.HomeOffice.FAGetSelectedItem());
                int i = 1;
                foreach (string empType in EmployeeType)
                {

                    EmployeeData.Add("Role " + i, empType);
                    i++;
                }

                string UniqueID= Guid.NewGuid().ToString().GetHashCode().ToString("x"); 
                this.IDCode.FASetText(UniqueID);               
                this.Initials.FASetText(EmployeeData["FirstName"].Substring(0, 1) + EmployeeData["LastName"].Substring(0, 1));
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch
            {
                throw;
            }
            return EmployeeData;
        }
        public Dictionary<string, string> CreateNewEmployeewithFullData(string[] EmployeeType = null, string HomeRegion = "QA Automation Region - DO NOT TOUCH", string HomeOffice = "QA Automation Office - DO NOT TOUCH", string workGroup=null)
        {
            this.WaitForScreenToLoad();
            Dictionary<string, string> EmployeeData = new Dictionary<string, string>();
            try
            {
                this.IDCode.FASetText(Guid.NewGuid().ToString().Substring(1, 7));
                this.FirstName.FASetText("BatFN" + Guid.NewGuid().ToString().Substring(0, 4));
                this.LastName.FASetText("BatLN" + Guid.NewGuid().ToString().Substring(0, 4));
                this.Initials.FASetText("I");
                this.Suffix.FASetText("S");
                this.EmployeeID.FASetText(Guid.NewGuid().ToString().Substring(0, 4));
                this.UserName.FASetText("[" + this.FirstName.FAGetValue() + this.LastName.FAGetValue()+"]");
                if (workGroup != null)
                {
                    this.Selected.FAClick();
                    this.WaitForScreenToLoad();
                    this.AddRemove.FAClick();
                    Thread.Sleep(1000);
                    this.SwitchToDialogContentFrame();
                    FastDriver.SelectCustomaryWorkgroups.WorkGroupNameTable.PerformTableAction(2, workGroup, 1, TableAction.Click);
                    FastDriver.DialogBottomFrame.ClickDone();
                    this.WaitForScreenToLoad();
                }
                else { this.All.FAClick(); }
                
                if (EmployeeType != null)
                {
                    this.SelectRoles(EmployeeType);
                }
                this.HomeRegion.FASelectItem(HomeRegion);
                this.WaitForScreenToLoad();
                string[] AllOffices = this.HomeOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains(HomeOffice))
                    {
                        this.HomeOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        this.WaitForScreenToLoad();
                        break;
                    }
                }
                this.AddVender.FAClick();
                this.WaitForScreenToLoad();
                this.VendorType.FASelectItem("Data Tree");
                this.VendorInfoUserName.FASetText("Vendor name");
                this.VendorInfoPassword.FASetText("1234");
                this.VendorInfoAccountNumber.FASetText("55667788");

                EmployeeData.Add("IDCode", this.IDCode.FAGetValue());
                EmployeeData.Add("FirstName", this.FirstName.FAGetValue());
                EmployeeData.Add("LastName", this.LastName.FAGetValue());
                EmployeeData.Add("HomeOffice", this.HomeOffice.FAGetSelectedItem());
                EmployeeData.Add("Workgroup", this.All.IsSelected().ToString());
                EmployeeData.Add("EmployeeID", this.EmployeeID.FAGetValue());
                EmployeeData.Add("UserName", this.UserName.FAGetValue());

                EmployeeData.Add("VendorType", this.VendorType.FAGetSelectedItem());
                EmployeeData.Add("VendorInfoUserName", this.VendorInfoUserName.FAGetValue());
                EmployeeData.Add("VendorInfoPassword", this.VendorInfoPassword.FAGetValue());
                EmployeeData.Add("VendorInfoAccountNumber", this.VendorInfoAccountNumber.FAGetValue().ToString());
                int i = 1;
                foreach (string empType in EmployeeType)
                {

                    EmployeeData.Add("Role " + i, empType);
                    i++;
                }

                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch
            {
                throw;
            }
            return EmployeeData;
        }

        public Dictionary<string, string> EditExistingEmployee(string[] EmployeeType = null, string HomeRegion = "QA Automation Region - DO NOT TOUCH", string HomeOffice = "QA Automation Office - DO NOT TOUCH")
        {
            this.WaitForScreenToLoad();
            Dictionary<string, string> EmployeeData = new Dictionary<string, string>();
            try
            {
                this.FirstName.FASetText("BatFN" + Guid.NewGuid().ToString().Substring(0, 4));
                this.LastName.FASetText("BatLN" + Guid.NewGuid().ToString().Substring(0, 4));
                this.Initials.FASetText("I");
                this.Suffix.FASetText("S");
                this.EmployeeID.FASetText(Guid.NewGuid().ToString().Substring(0, 4));
                this.UserName.FASetText("[" + this.FirstName.FAGetValue() + this.LastName.FAGetValue() + "]");
                this.All.FAClick();
                if (EmployeeType != null)
                {
                    this.SelectRoles(EmployeeType);
                }
                this.HomeRegion.FASelectItem(HomeRegion);
                this.WaitForScreenToLoad();
                string[] AllOffices = this.HomeOffice.FAGetAllTextFromSelect().Split('|');
                foreach (string Office in AllOffices)
                {
                    if (Office.Contains(HomeOffice))
                    {
                        this.HomeOffice.FASelectItem(Office);
                        Thread.Sleep(5000);
                        this.WaitForScreenToLoad();
                        break;
                    }
                }
                this.WaitForScreenToLoad();
                this.VendorInfoUserName.FASetText("Vendor name");
                this.VendorInfoPassword.FASetText("1234");
                this.VendorInfoAccountNumber.FASetText("55667788");

                EmployeeData.Add("IDCode", this.IDCode.FAGetValue());
                EmployeeData.Add("FirstName", this.FirstName.FAGetValue());
                EmployeeData.Add("LastName", this.LastName.FAGetValue());
                EmployeeData.Add("HomeOffice", this.HomeOffice.FAGetSelectedItem());
                EmployeeData.Add("Workgroup", this.All.IsSelected().ToString());
                EmployeeData.Add("EmployeeID", this.EmployeeID.FAGetValue());
                EmployeeData.Add("UserName", this.UserName.FAGetValue());

                EmployeeData.Add("VendorType", this.VendorType.FAGetSelectedItem());
                EmployeeData.Add("VendorInfoUserName", this.VendorInfoUserName.FAGetValue());
                EmployeeData.Add("VendorInfoPassword", this.VendorInfoPassword.FAGetValue());
                EmployeeData.Add("VendorInfoAccountNumber", this.VendorInfoAccountNumber.FAGetValue().ToString());
                int i = 1;
                foreach (string empType in EmployeeType)
                {

                    EmployeeData.Add("Role " + i, empType);
                    i++;
                }

                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
            }
            catch
            {
                throw;
            }
            return EmployeeData;
        }

        public Dictionary<string, string> CreateDetailedEmployee(string firstName = "FN", string secondName = "LN", string homeRegion = "QA Automation Region - DO NOT TOUCH", 
            string homeOffice = "QA Automation Office - DO NOT TOUCH PR: STEST Off: 7878", bool save = true, params string[] employeeType)
        {
            WaitForScreenToLoad();
            Dictionary<string, string> EmployeeData = new Dictionary<string, string>();
            try
            {
                IDCode.FASetText(Guid.NewGuid().ToString().Substring(1, 7));
                FirstName.FASetText(firstName + Guid.NewGuid().ToString().Substring(0, 4));
                LastName.FASetText(secondName + Guid.NewGuid().ToString().Substring(0, 4));
                Initials.FASetText("I");
                Suffix.FASetText("S");
                EmployeeID.FASetText(Guid.NewGuid().ToString().Substring(0, 4));
                UserName.FASetText("[" + FirstName.FAGetValue() + LastName.FAGetValue() + "]");
                if (employeeType != null)
                {
                    foreach (var type in employeeType)
                    {
                        if (EmployeeTypes.Text.Contains(type))
                        {
                            IWebElement element = EmployeeTypes.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(j => j.Text.Contains(type));
                            FastDriver.WebDriver.WaitForActionToComplete(() =>
                            {
                                element.FAClick();
                                return element.Selected;
                            });
                        }
                    }
                }
                if (HomeRegion.Text.Contains(homeRegion))
                {
                    HomeRegion.FASelectItem(homeRegion);
                    WaitForScreenToLoad();
                }
                if (HomeOffice.Text.Contains(homeOffice))
                {
                    HomeOffice.FASelectItem(homeOffice);
                    Thread.Sleep(5000);
                    WaitForScreenToLoad();
                }
                AddVender.FAClick();
                WaitForScreenToLoad();
                VendorType.FASelectItem("Data Tree");
                VendorInfoUserName.FASetText("Vendor name");
                VendorInfoPassword.FASetText("1234");
                VendorInfoAccountNumber.FASetText("55667788");

                #region Save Data
                EmployeeData.Add("IDCode", IDCode.FAGetValue());
                EmployeeData.Add("FirstName", FirstName.FAGetValue());
                EmployeeData.Add("LastName", LastName.FAGetValue());
                EmployeeData.Add("HomeOffice", HomeOffice.FAGetSelectedItem());
                EmployeeData.Add("Workgroup", All.IsSelected().ToString());
                EmployeeData.Add("EmployeeID", EmployeeID.FAGetValue());
                EmployeeData.Add("UserName", UserName.FAGetValue());
                EmployeeData.Add("VendorType", VendorType.FAGetSelectedItem());
                EmployeeData.Add("VendorInfoUserName", VendorInfoUserName.FAGetValue());
                EmployeeData.Add("VendorInfoPassword", VendorInfoPassword.FAGetValue());
                EmployeeData.Add("VendorInfoAccountNumber", VendorInfoAccountNumber.FAGetValue().ToString());
                int i = 1;
                foreach (string empType in employeeType)
                {

                    EmployeeData.Add("Role " + i, empType);
                    i++;
                }
                #endregion

                if (save)
                {
                    FastDriver.BottomFrame.Done();
                    Thread.Sleep(5000);
                }
                
            }
            catch
            {
                throw;
            }
            return EmployeeData;
        }

    }
    public class SelectCustomaryWorkgroupsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dGridSelectWgs_3_lblWorkgroupName")]
        public IWebElement Ten99SFPUC0011 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSelectWgs_3_cboxSelect")]
        public IWebElement SelectWorkGrp { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSelectWgs_dGridSelectWgs")]
        public IWebElement WorkGroupsTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnCheckAll")]
        public IWebElement CheckAll { get; set; }

        #endregion

        #region Useful Methods
        public SelectCustomaryWorkgroupsDlg WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Select Workgroups", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(CheckAll);
            return this;
        }
        #endregion

    }
}
