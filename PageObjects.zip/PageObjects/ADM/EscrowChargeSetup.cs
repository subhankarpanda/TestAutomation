using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class EscrowChargeSetup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "rbtnFormTypeHUD")]
        public IWebElement HUDTypeHud { get; set; }

        [FindsBy(How = How.Id, Using = "ddlEscrowChrgProcessType")]
        public IWebElement Types { get; set; }

        #endregion

        public EscrowChargeSetup Open()
        {
            return FastDriver.LeftNavigation.Navigate<EscrowChargeSetup>("Home>System Maintenance>Escrow Charge Setup").WaitForScreenToLoad();
        }

        public EscrowChargeSetup WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(HUDTypeHud, 10);

            return this;
        }
    }
}
