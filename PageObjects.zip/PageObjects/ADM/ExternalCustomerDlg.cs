using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ExternalCustomerDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "gdEcInfo_0_flgExternalCustomer")]
		public IWebElement AgentFirst { get; set; }

		[FindsBy(How = How.Id, Using = "gdEcInfo_1_flgExternalCustomer")]
		public IWebElement CFT { get; set; }

		[FindsBy(How = How.Id, Using = "gdEcInfo_2_flgExternalCustomer")]
		public IWebElement FAMOS { get; set; }

		[FindsBy(How = How.Id, Using = "gdEcInfo_3_flgExternalCustomer")]
		public IWebElement FASTWEB { get; set; }

		[FindsBy(How = How.Id, Using = "gdEcInfo_4_flgExternalCustomer")]
		public IWebElement MyFastNCS { get; set; }

		[FindsBy(How = How.Id, Using = "gdEcInfo_gdEcInfo")]
		public IWebElement ExternalCustomerTable { get; set; }

		#endregion

        public ExternalCustomerDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(AgentFirst);
            return this;
        }

	}
}
