using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ExternalSystemResponseDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgEventSetup_0_chkSelEvent")]
		public IWebElement SelectExternalEvent1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgEventSetup_1_chkSelEvent")]
		public IWebElement SelectExternalEvent2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgEventSetup_2_chkSelEvent")]
		public IWebElement SelectExternalEvent3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgEventSetup_dgEventSetup")]
		public IWebElement ExternalResponseEventTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		#endregion

        #region Useful Methods
        public ExternalSystemResponseDlg WaitForScreenToLoad(IWebElement element = null, string windowName = "External System Response")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Done);
            return this;
        }
        #endregion

    }
}
