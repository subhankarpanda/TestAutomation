using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class FeeFilterReports : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdPrint")]
        public IWebElement Print { get; set; }

        [FindsBy(How = How.Id, Using = "dgridfeeReport")]
        public IWebElement Feetable { get; set; }

        [FindsBy(How = How.Id, Using = "cboFormType")]
        public IWebElement FormType { get; set; }

        [FindsBy(How = How.Id, Using = "activeOnly")]
        public IWebElement ActiveOnly { get; set; }

        #endregion

        public FeeFilterReports WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Feetable, 30);

            return this;
        }
    }
}
