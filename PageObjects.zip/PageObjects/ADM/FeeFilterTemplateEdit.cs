using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
	public class FeeFilterTemplateEdit : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "txtDescr")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorIntop { get; set; }

        [FindsBy(How = How.Id, Using = "dgridFeeTempSetUP_dgridFeeTempSetUP")]
        public IWebElement TemplateSelectionCriteriaTable { get; set; }

		#endregion

        public FeeFilterTemplateEdit WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Name, 20);
            return this;
        }

        public FeeFilterTemplateEdit CreateAFilter(string FilterCode ,string FilterDescription)
        {
            FastDriver.LeftNavigation.Navigate<FeeFilterTemplatesSummary>(@"Home>System Maintenance>Fee Setup>Fee Filter Templates");
            FastDriver.FeeFilterTemplatesSummary.WaitForScreenToLoad();
            
            if (FastDriver.FeeFilterTemplatesSummary.TemplateTable.FeeExistOnTable(FilterCode))
            {
                FastDriver.FeeFilterTemplatesSummary.WaitForScreenToLoad();
                FastDriver.FeeFilterTemplatesSummary.TemplateTable.PerformTableAction(1, FilterCode, 1, TableAction.Click);

                FastDriver.FeeFilterTemplatesSummary.Remove.FAClick();

                string DialogMessage = @"Remove selected Template?";
                string ActualMessage = FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
                Support.AreEqual(DialogMessage, ActualMessage);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FeeFilterTemplatesSummary.SwitchToContentFrame();

            }

            FastDriver.FeeFilterTemplatesSummary.New.FAClick();

            FastDriver.FeeFilterTemplateEdit.WaitForScreenToLoad();

            FastDriver.FeeFilterTemplateEdit.Name.FASetText(FilterCode);

            FastDriver.FeeFilterTemplateEdit.Description.FASetText(FilterDescription);

            FastDriver.FeeFilterTemplateEdit.Select.FAClick();

            FastDriver.WebDriver.WaitForWindowAndSwitch("Selection Criteria", true, 20);

            FastDriver.FeeSelectionCriteria.WaitForScreenToLoad();

            FastDriver.FeeSelectionCriteria.Title.FASetCheckbox(true);

            FastDriver.FeeSelectionCriteria.Escrow.FASetCheckbox(true);

            FastDriver.FeeSelectionCriteria.TransactionType.FASelectItem("Sale w/Mortgage");

            FastDriver.FeeSelectionCriteria.BusSegment.FASelectItem("Residential");

            FastDriver.FeeSelectionCriteria.Product.FASelectItem("All");

            FastDriver.FeeSelectionCriteria.ProgType.FASelectItem("All");

            FastDriver.FeeSelectionCriteria.PropType.FASelectItem("Single Family Residence");

            FastDriver.FeeSelectionCriteria.UnderWriter.FASelectItem("First American Title Insurance Company");

            FastDriver.FeeSelectionCriteria.ProgType.FASelectItem("All");

            FastDriver.FeeSelectionCriteria.SearchType.FASelectItem("All");

            Reports.TestStep = "Click on Done on Dialog.";

            FastDriver.FeeSelectionCriteria.SwitchToDialogBottomFrame();

            FastDriver.DialogBottomFrame.ClickDone();


            Reports.TestStep = "Click on Done on Main Window to reach Filter Template edit screen.";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            FastDriver.FeeFilterTemplateEdit.WaitForScreenToLoad();

            FastDriver.FeeFilterTemplateEdit.SwitchToBottomFrame();

            FastDriver.BottomFrame.Done();


            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            Reports.TestStep = "Verify that Template is created.";
            FastDriver.FeeFilterTemplatesSummary.SwitchToContentFrame();

            FastDriver.FeeFilterTemplatesSummary.TemplateTable.PerformTableAction(1, FilterCode, 1, TableAction.Click);
            return this;
        }

        public FeeFilterTemplateEdit CreateCustomFilter(string Name, string FilterDescription, FeeFilterTemplateParameters FilterParameters)
        {
            bool clickOnNew = true;
            //By default it will create a filter for All
            FastDriver.LeftNavigation.Navigate<FeeFilterTemplatesSummary>(@"Home>System Maintenance>Fee Setup>Fee Filter Templates");
            FastDriver.FeeFilterTemplatesSummary.WaitForScreenToLoad();


            //Verify if Fee Filter exists and then edit it...
            if (FastDriver.FeeFilterTemplatesSummary.TemplateTable.FeeExistOnTable(Name))
            {
                FastDriver.FeeFilterTemplatesSummary.WaitForScreenToLoad();
                FastDriver.FeeFilterTemplatesSummary.TemplateTable.PerformTableAction(1, Name, 1, TableAction.Click);

                FastDriver.FeeFilterTemplatesSummary.Edit.FAClick();
                clickOnNew = false;

            }

            //Create Fee Filter Template
            if(clickOnNew)
                FastDriver.FeeFilterTemplatesSummary.New.FAClick();

            FastDriver.FeeFilterTemplateEdit.WaitForScreenToLoad();
            if (clickOnNew)
                FastDriver.FeeFilterTemplateEdit.Name.FASetText(Name);

            FastDriver.FeeFilterTemplateEdit.Description.FASetText(FilterDescription);
            FastDriver.FeeFilterTemplateEdit.Select.FAClick();

            FastDriver.WebDriver.WaitForWindowAndSwitch("Selection Criteria", true, 20);
            FastDriver.FeeSelectionCriteria.WaitForScreenToLoad();
            if(!FilterParameters.SelectAll)
            {
                FastDriver.FeeSelectionCriteria.Title.FASetCheckbox(FilterParameters.Title);
                FastDriver.FeeSelectionCriteria.Escrow.FASetCheckbox(FilterParameters.Escrow);
                FastDriver.FeeSelectionCriteria.SubEscrow.FASetCheckbox(FilterParameters.SubEscrow);
            }
            FastDriver.FeeSelectionCriteria.SelectAll.FASetCheckbox(FilterParameters.SelectAll);
            FastDriver.FeeSelectionCriteria.TransactionType.FASelectItem(FilterParameters.TransactionType);
            FastDriver.FeeSelectionCriteria.BusSegment.FASelectItem(FilterParameters.BusinessSegment);
            FastDriver.FeeSelectionCriteria.Product.FASelectItem(FilterParameters.Product);
            FastDriver.FeeSelectionCriteria.ProgType.FASelectItem(FilterParameters.ProgramType);
            FastDriver.FeeSelectionCriteria.PropType.FASelectItem(FilterParameters.PropertyType);
            FastDriver.FeeSelectionCriteria.UnderWriter.FASelectItem(FilterParameters.UnderWriter);
            FastDriver.FeeSelectionCriteria.ProgType.FASelectItem(FilterParameters.ProgramType);
            FastDriver.FeeSelectionCriteria.SearchType.FASelectItem(FilterParameters.SearchType);

            //Click on Done on Dialog
            FastDriver.FeeSelectionCriteria.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();

            //Click on Done on Main Window to reach Filter Template edit screen
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.FeeFilterTemplateEdit.WaitForScreenToLoad();
            FastDriver.FeeFilterTemplateEdit.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            //Verify that Template is created
            FastDriver.FeeFilterTemplatesSummary.SwitchToContentFrame();
            FastDriver.FeeFilterTemplatesSummary.TemplateTable.PerformTableAction(1, Name, 1, TableAction.Click);
            return this;
        }

    }
}
