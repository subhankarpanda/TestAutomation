using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.ADM
{
	public class FeeFilterTemplateSummaryDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridFeeFilterSummary_dgridFeeFilterSummary")]
		public IWebElement FeeFilterTable { get; set; }

		#endregion

        public FeeFilterTemplateSummaryDlg WaitForScreenToLoad(string WindowName =  "Fee Templates", IWebElement element =  null)
        {
            //WebDriver.WaitForWindowAndSwitch(WindowName, true, 10);
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? FeeFilterTable);
            return this;
        }
	}
}
