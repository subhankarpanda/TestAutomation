using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class FeeFilterTemplatesSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkActiveonly")]
		public IWebElement Activeonly { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "cmdView")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "btnHistory")]
		public IWebElement ChangeHistory { get; set; }

        [FindsBy(How = How.Id, Using = "dgridFeeFilterSummary_dgridFeeFilterSummary")]
        public IWebElement TemplateTable { get; set; }

		#endregion

        public FeeFilterTemplatesSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New, 20);
            return this;
        }
	}
}
