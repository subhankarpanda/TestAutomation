using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.ObjectModel;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
    public class FeeList2 : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboFeeTypeCdID")]
        public IWebElement FeeType { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.LinkText, Using = "Endorsement (Edit) - L")]
        public IWebElement EndorsementL { get; set; }

        [FindsBy(How = How.LinkText, Using = "Endorsement (Edit) - O")]
        public IWebElement EndorsementO { get; set; }

        [FindsBy(How = How.LinkText, Using = "New Home Rate (Title Only)")]
        public IWebElement TOwner { get; set; }

        [FindsBy(How = How.LinkText, Using = "New Home Rate Eagle Lender Policy-1")]
        public IWebElement TLender { get; set; }

        [FindsBy(How = How.Id, Using = "dgFeeSummary_0_lblCode")]
        public IWebElement Code { get; set; }

        [FindsBy(How = How.LinkText, Using = "1064_Title_Lender_Policy")]
        public IWebElement Fee1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFeeSummary_dgFeeSummary")]
        public IWebElement FeeTable { get; set; }

        [FindsBy(How = How.Id, Using = "ActiveOnly")]
        public IWebElement ActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "cboFormType")]
        public IWebElement FeeFormType { get; set; }


        #endregion

        public FeeList2 WaitScreenToLoad(IWebElement element = null)
        {
            Thread.Sleep(6000);
            var wait = new OpenQA.Selenium.Support.UI.WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            var elementToWait = element ?? FeeTable;
            wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return elementToWait.IsVisible();
                }
                catch (StaleElementReferenceException) { return false; }
                catch (NoSuchElementException) { return false; }

            });

            return this;
        }

        public FeeList2 WaitForScreenToPostBack(IWebElement element = null)
        {
            Playback.Wait(5000);

            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FeeTable);

            return this;
        }

        public FeeList2 WaitFeeTableUpdate(IWebElement element = null)
        {
            var wait = new OpenQA.Selenium.Support.UI.WebDriverWait(WebDriver, TimeSpan.FromSeconds(15));
            var elementToWait = element ?? FeeTable;
            wait.Until(d =>
            {
                try
                {
                    return elementToWait.IsVisible() && (bool)(d as IJavaScriptExecutor).ExecuteScript("return jQuery.active == 0");
                }
                catch (StaleElementReferenceException) { return false; }
                catch (NoSuchElementException) { return false; }

            });
            return this;
        }

        public FeeList2 VerifyIfExistsAndCreateNewFee(string Description, string FeeCode, string FeeType)
        {
            Reports.TestStep = "Navigate to Fee Summary Screen and Verify if Fee " + Description + " exists";
            FastDriver.LeftNavigation.Navigate<FeeList2>("Home>System Maintenance>Fee Setup>Fee Summary");
            WaitScreenToLoad();

            if (CheckFeeCodeExistsOnFeeTable(FeeCode, FeeType, Description))
            {
                return this;
            }

            Reports.TestStep = "Create Fee in Admin - Select Values from drop down and enter values in text boxes";

            FastDriver.FeeSetup.CreateFeeWithDefaultValues(Description, FeeCode, FeeType);


            return this;
        }

        public FeeList2 VerifyIfExistsAndCreateNewFeeWithFilterName(string Description, string FeeCode, string FeeType, string FeeFilterName, string LoanEstimateDescription = null, ClosingDisclosureSection Section = ClosingDisclosureSection.B, string GLCode = null, bool SubjectToCalculation = false, bool SubjectToSaleTaxes = false)
        {
            Reports.TestStep = "Naviagte to Fee Summary Screen and Verify if Fee " + Description + " exists";
            FastDriver.LeftNavigation.Navigate<FeeList2>("Home>System Maintenance>Fee Setup>Fee Summary");
            WaitScreenToLoad();

            if (CheckFeeCodeExistsOnFeeTable(FeeCode, FeeType, Description))
            {
                return this;
            }

            Reports.TestStep = "Create Fee in Admin - Select Values from drop down and enter values in text boxes";

            FastDriver.FeeSetup.CreateFeeWithFeeFilterNameAndDefaultValues(Description: Description, FeeCode: FeeCode, FeeType: FeeType, FeeFilterName: FeeFilterName, LoanEstimateDescription: LoanEstimateDescription, Section: Section, GLCode: GLCode, SubjectToCalculation: SubjectToCalculation, SubjectToSaleTaxes: SubjectToSaleTaxes);


            return this;
        }

        public FeeList2 VerifyIfFeeExistsAndCreateNewOrEditCustomFee(FeeSetupParameters FeeSetup)
        {
            Reports.TestStep = "Navigate to Fee Summary Screen and Verify if Fee " + FeeSetup.Description + " exists";
            FastDriver.LeftNavigation.Navigate<FeeList2>("Home>System Maintenance>Fee Setup>Fee Summary");
            WaitScreenToLoad();
            bool EditExistingFee = CheckFeeCodeExistsOnFeeTable(FeeSetup.FeeCode, FeeSetup.FeeType, FeeSetup.Description);
            if (EditExistingFee)
            {
                WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(60));
                try
                {
                    FeeFormType.FASelectItemByIndex(0);
                }
                catch (StaleElementReferenceException)
                {
                    FeeFormType.FASelectItemByIndex(0);
                }
                Thread.Sleep(10000);
                this.WaitFeeTableUpdate();
                try
                {
                    this.FeeType.FASelectItem(FeeSetup.FeeType);
                }
                catch (StaleElementReferenceException)
                {
                    this.FeeType.FASelectItem(FeeSetup.FeeType);
                }
                Thread.Sleep(10000);
                this.WaitFeeTableUpdate();

                ReadOnlyCollection<IWebElement> TableCells = FeeTable.FindElements(By.CssSelector("td"));

                for (int CellCount = 0; CellCount < TableCells.Count; CellCount++)
                {
                    IWebElement TableCell = TableCells[CellCount];
                    if (TableCell.Text == FeeSetup.FeeCode && TableCells[CellCount + 1].Text == FeeSetup.Description)
                    {
                        TableCell.FAClick();
                        FastDriver.FeeList2.Edit.FAClick();
                        break;
                    }
                }               

                return this;
            }

            Reports.TestStep = "Create Fee in Admin - Select Values from drop down and enter values in text boxes";
            FastDriver.FeeSetup.CreateOrEditFeeWithFeeFilterNameAndCustomValues(FeeSetup: FeeSetup, EditExistingFee: EditExistingFee);

            return this;
        }

        //Goes through all FeeCode within the FeeTable and searches for a matching Fee Code
        public bool CheckFeeCodeExistsOnFeeTable(string FeeCode, string FeeType, string Description)
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            try
            {
                FeeFormType.FASelectItemByIndex(0);
            }
            catch (StaleElementReferenceException)
            {
                FeeFormType.FASelectItemByIndex(0);
            }
            Thread.Sleep(10000);
            //this.WaitCreation(FeeTable);
            this.WaitFeeTableUpdate();
            try
            {
                this.FeeType.FASelectItem(FeeType);
            }
            catch (StaleElementReferenceException)
            {
                this.FeeType.FASelectItem(FeeType);
            }
            Thread.Sleep(10000);
            //this.WaitCreation(FeeTable);
            this.WaitFeeTableUpdate();

            ReadOnlyCollection<IWebElement> TableCells = FeeTable.FindElements(By.CssSelector("td"));

            for (int CellCount = 0; CellCount < TableCells.Count; CellCount++)
            {
                IWebElement TableCell = TableCells[CellCount];
                if (TableCell.Text == FeeCode && TableCells[CellCount + 1].Text == Description)
                {
                    return true;
                }
            }
            return false;
        }

        public FeeList2 Open()
        {
            FastDriver.LeftNavigation.Navigate<FeeList2>("Home>System Maintenance>Fee Setup>Fee Summary");
            this.WaitScreenToLoad();
            return this;
        }

        public FeeList2 WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FeeTable);

            return this;
        }

        /// <summary>
        /// This function selects the fee based on the form type, fee type and clicks on the Edit button.
        /// </summary>
        /// <param name="formType">form type for the fee</param>
        /// <param name="feeType">Fee type for the fee.</param>
        /// <param name="feeName">Name of the fee which we want to select</param>
        public void SelectFeeandClickEdit(string formType, string feeType,string feeName)
        {
            Reports.TestStep = "Select the fee name and click on the edit button.";
            this.FeeFormType.FASelectItem(formType);
            this.WaitScreenToLoad();
            this.FeeType.FASelectItem(feeType);
            Support.SendKeys("{TAB}");
            this.WaitScreenToLoad();
            this.FeeTable.PerformTableAction(4, feeName, 4, TableAction.Click);
            this.Edit.FAClick();
            FastDriver.FeeSetup.WaitForScreenToLoad();
        }
    }
}
