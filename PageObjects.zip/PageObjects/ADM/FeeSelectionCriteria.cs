﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System;
using FASTSelenium.DataObjects.ADM;
using System.ComponentModel;

namespace FASTSelenium.PageObjects.ADM
{
    public class FeeSelectionCriteria : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "lstrans")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "chkTitle")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "chkEscrow")]
        public IWebElement Escrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubEscrow")]
        public IWebElement SubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkServiceType")]
        public IWebElement SelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "lstBusiness")]
        public IWebElement BusSegment { get; set; }

        [FindsBy(How = How.Id, Using = "lstProd")]
        public IWebElement Product { get; set; }

        [FindsBy(How = How.Id, Using = "lstProperty")]
        public IWebElement PropType { get; set; }

        [FindsBy(How = How.Id, Using = "lstProgram")]
        public IWebElement ProgType { get; set; }

        [FindsBy(How = How.Id, Using = "lstUW")]
        public IWebElement UnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "lstSearch")]
        public IWebElement SearchType { get; set; }


        [FindsBy(How = How.Id, Using = "btnAdd2")]
        public IWebElement AddRemoveBusinessSource { get; set; }

        [FindsBy(How = How.Id, Using = "btnCountry")]
        public IWebElement AddRemoveCountry { get; set; }

        [FindsBy(How = How.Id, Using = "btnState")]
        public IWebElement AddRemoveState { get; set; }

        [FindsBy(How = How.Id, Using = "btnCounty")]
        public IWebElement AddRemoveCounty { get; set; }

        [FindsBy(How = How.Id, Using = "btnCity")]
        public IWebElement AddRemoveCity { get; set; }


        #endregion

        public FeeSelectionCriteria WaitForScreenToLoad(string WindowName = "Fee Templates")
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(TransactionType, 20);
            return this;
        }

    }
}
