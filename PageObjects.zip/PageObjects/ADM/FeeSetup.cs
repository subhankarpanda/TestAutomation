using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
	public class FeeSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtObjectCd")]
		public IWebElement FeeCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "cboFeeTypeCdID")]
		public IWebElement FeeType { get; set; }

		[FindsBy(How = How.Id, Using = "chkDescEditFlag")]
		public IWebElement DescriptionEditable { get; set; }

		[FindsBy(How = How.Id, Using = "chkFACCCalc")]
		public IWebElement SubjectTocalculation { get; set; }

		[FindsBy(How = How.Id, Using = "cboGeotypeID")]
		public IWebElement Geographictype { get; set; }

		[FindsBy(How = How.Id, Using = "chkPremiumSalesTax")]
		public IWebElement SubjectToSalesTax { get; set; }

		[FindsBy(How = How.Id, Using = "lstStatus1")]
		public IWebElement FeeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "chkCompanyIncomeFeeFlag")]
		public IWebElement CompanyIncomeFee { get; set; }

		[FindsBy(How = How.Id, Using = "cboGLlookupID")]
		public IWebElement GLCode { get; set; }

		[FindsBy(How = How.Id, Using = "chkOfficeIncomeFeeFlag")]
		public IWebElement OfficeIncomeFee { get; set; }

		[FindsBy(How = How.Id, Using = "txtDefaultChargeAmt")]
		public IWebElement DefaultChargeAmt { get; set; }

		[FindsBy(How = How.Id, Using = "chkTitleOfficerFee")]
		public IWebElement TitleOfficerFee { get; set; }

		[FindsBy(How = How.Id, Using = "cboChargetoTypeCdID")]
		public IWebElement DefaultChargeto { get; set; }

		[FindsBy(How = How.Id, Using = "chkEscrowOfficerFee")]
		public IWebElement EscrowOfficerFee { get; set; }

		[FindsBy(How = How.Id, Using = "cboFeeDistribution")]
		public IWebElement FeeDistribution { get; set; }

		[FindsBy(How = How.Id, Using = "chkSalesRepFee")]
		public IWebElement SalesRepFee { get; set; }

		[FindsBy(How = How.Id, Using = "txtRecipientType")]
		public IWebElement RecipientType { get; set; }

		[FindsBy(How = How.Id, Using = "cboFeeOwningOfficeTypeCdID")]
		public IWebElement FeeOwnigOfficeType { get; set; }

		[FindsBy(How = How.Id, Using = "chkSplitDirectOff")]
		public IWebElement SplitWithFAOffice { get; set; }

		[FindsBy(How = How.Id, Using = "cboGfeHUDTypeCdID")]
		public IWebElement HudType { get; set; }

		[FindsBy(How = How.Id, Using = "chkTerritoryAllocation")]
		public IWebElement SubjectToStateAssignment { get; set; }

		[FindsBy(How = How.Id, Using = "cboGfeEntryTypeCdID")]
		public IWebElement GFEDefault { get; set; }

		[FindsBy(How = How.Id, Using = "chkGFEEntryEditable")]
		public IWebElement EditGFE { get; set; }

		[FindsBy(How = How.Id, Using = "chkGFELenderDirectedFlag")]
		public IWebElement LendSlctdProviderDef { get; set; }

		[FindsBy(How = How.Id, Using = "chkGfeLenderDirEditableFlag")]
		public IWebElement EditProvider { get; set; }

		[FindsBy(How = How.Id, Using = "chkGfeThirdPartyEditableFlag")]
		public IWebElement ThirdPartyPayee { get; set; }

		[FindsBy(How = How.Id, Using = "txtGfeThirdPartyNameDefault")]
		public IWebElement ThirdPartyPNameDefault { get; set; }

        [FindsBy(How = How.Id, Using = "chkRemittanceFee")]
        public IWebElement SubjectToRemittance { get; set; }

        [FindsBy(How = How.Id, Using = "chkTransactionCode")]
        public IWebElement TransactionCode { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDefaultPaymentMethod")]
		public IWebElement DefaultPaymentMethod { get; set; }

		[FindsBy(How = How.Id, Using = "txtBuyerCharge")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "txtSellerCharge")]
		public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBuyerSection")]
        public IWebElement BuyerSection { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerSection")]
        public IWebElement SellerSection { get; set; }

		[FindsBy(How = How.Id, Using = "chkHUDBuyerChargeFlag")]
		public IWebElement HUDBuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "chkHUDSellerChargeFlag")]
		public IWebElement HUDSellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddRemove")]
		public IWebElement AddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "chkGovernmentReportable")]
		public IWebElement GovtRep { get; set; }

		[FindsBy(How = How.Id, Using = "chkRateType")]
		public IWebElement RateType { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeTemplates")]
		public IWebElement FeeTemplateTable { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDefaultPaymentCategory")]
        public IWebElement DefaultPaymentCategory { get; set; }

        [FindsBy(How = How.Id, Using = "radPddValueForB")]
        public IWebElement PaymentDetailsSectionB { get; set; }

        [FindsBy(How = How.Id, Using = "chkLenderAffiliate")]
        public IWebElement LenderAffiliate { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanEstimatedDesc")]
        public IWebElement LoanEstimateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "radPddValueForC")]
        public IWebElement PaymentDetailsSectionC { get; set; }

        [FindsBy(How = How.Id, Using = "radPddValueForH")]
        public IWebElement PaymentDetailsSectionH { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerLine")]
        public IWebElement BuyerLine { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerLine")]
        public IWebElement SellerLine { get; set; }
        
        [FindsBy(How = How.Id, Using = "chkPromulgatedFee")]
        public IWebElement PromulgatedType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDefaultPaymentMethod")]
        public IWebElement HUDPaymentDetailsSection { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorIntop { get; set; }

        [FindsBy(How = How.Id, Using = "cboEndTypes")]
        public IWebElement TypeOfEndorsement { get; set; }

        [FindsBy(How = How.Id, Using = "chkAggregateBuyer")]
        public IWebElement AggregateBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "chkAggregateSeller")]
        public IWebElement AggregateSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ddlMISMOCategory")]
        public IWebElement MISMOCategory { get; set; }

        [FindsBy(How = How.Id, Using = "ddlMISMOType")]
        public IWebElement MISMOType { get; set; }

        [FindsBy(How = How.Id, Using = "FeeSetDetail")]
        public IWebElement PageContent { get; set; }
		#endregion
        
        public void WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Description);
        }
        
        public void CreateFee(string FeeDesc, string FeeType, bool DescEdit, bool thirdPartyPayee, string thirdPPayeeName, string bSection, string sSection) 
        {
            try
            {
                                
                FastDriver.FeeList2.New.FAClick();
                FastDriver.FeeSetup.SwitchToContentFrame();
                FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
                FastDriver.FeeSetup.HudType.FASelectItem("CD");
                FastDriver.FeeSetup.Description.FASetText(FeeDesc);
                FastDriver.FeeSetup.FeeCode.FASetText(Support.RandomString("ANANA"));
                FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
                Playback.Wait(2000);
                FastDriver.FeeSetup.DescriptionEditable.FASetCheckbox(DescEdit);
                FastDriver.FeeSetup.GLCode.FASelectItem("744 Abandon");
                FastDriver.FeeSetup.FeeDistribution.FASelectItem("Title");
                FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItem("Escrow Owning Office");

                if (thirdPartyPayee == true) 
                {
                    FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(thirdPartyPayee);
                    FastDriver.FeeSetup.ThirdPartyPNameDefault.FASetText(thirdPPayeeName);
                }

                if (thirdPartyPayee == false)
                {
                    FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(thirdPartyPayee);
                }
            
                FastDriver.FeeSetup.BuyerSection.FASelectItem(bSection);
                FastDriver.FeeSetup.SellerSection.FASelectItem(sSection);

                if (bSection == "B,C,H")
                    FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
                
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.SwitchToContentFrame();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        public void CreateEndrosement(string FeeDesc, string FeeType, bool DescEdit, bool thirdPartyPayee, string thirdPPayeeName, string bSection, string sSection, string EndorsementType, bool subjectedtosalestax)
        {
            try
            {

                FastDriver.FeeList2.New.FAClick();
                FastDriver.FeeSetup.SwitchToContentFrame();
                FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
                FastDriver.FeeSetup.HudType.FASelectItem("CD");
                FastDriver.FeeSetup.Description.FASetText(FeeDesc);
                FastDriver.FeeSetup.FeeCode.FASetText(Support.RandomString("ANANA"));
                FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
                Playback.Wait(2000);
                FastDriver.FeeSetup.DescriptionEditable.FASetCheckbox(DescEdit);
                FastDriver.FeeSetup.GLCode.FASelectItem("744 Abandon");
                FastDriver.FeeSetup.FeeDistribution.FASelectItem("Title");
                FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItem("Escrow Owning Office");

                if (thirdPartyPayee == true)
                {
                    FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(thirdPartyPayee);
                    FastDriver.FeeSetup.ThirdPartyPNameDefault.FASetText(thirdPPayeeName);
                }

                if (thirdPartyPayee == false)
                {
                    FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(thirdPartyPayee);
                }

                FastDriver.FeeSetup.BuyerSection.FASelectItem(bSection);
                FastDriver.FeeSetup.SellerSection.FASelectItem(sSection);
                FastDriver.FeeSetup.TypeOfEndorsement.FASelectItem(EndorsementType);
                FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(subjectedtosalestax);
                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.SwitchToContentFrame();

            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
        }

        public void CreateFeeWithDefaultValues(string Description, string FeeCode, string FeeType)
        {
            FastDriver.FeeList2.SwitchToContentFrame();
            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
            FastDriver.FeeSetup.HudType.FASelectItem("CD");
            FastDriver.FeeSetup.FeeCode.FASetText(FeeCode);
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            Thread.Sleep(1700);
            FastDriver.FeeSetup.Description.FASetText(Description);
            FastDriver.FeeSetup.LoanEstimateDescription.FASetText(Description);
            FastDriver.FeeSetup.Geographictype.FASelectItemBySendingKeys("");
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys("Active");
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys("116-02 Recording Fees - Non-Revenue");
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(true);
            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys("Title");
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys("Title Owning Office");
            FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys("Paid at Closing");
            FastDriver.FeeSetup.DefaultPaymentMethod.FASelectItemBySendingKeys("Fee");
            FastDriver.FeeSetup.BuyerSection.FASelectItemBySendingKeys("B,C,H");
            FastDriver.FeeSetup.SellerSection.FASelectItemBySendingKeys("B,C,H");
            FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
            FastDriver.FeeSetup.LenderAffiliate.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();
        
        }

        public void CreateFeeWithFeeFilterNameAndDefaultValues(string Description, string FeeCode, string FeeType, string FeeFilterName, string LoanEstimateDescription = null, ClosingDisclosureSection Section = ClosingDisclosureSection.B, string GLCode = null, bool SubjectToCalculation = false, bool SubjectToSaleTaxes = false)
        {
            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
            FastDriver.FeeSetup.HudType.FASelectItem("CD");
            FastDriver.FeeSetup.FeeCode.FASetText(FeeCode);
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            Thread.Sleep(1600);
            FastDriver.FeeSetup.Description.FASetText(Description);
            FastDriver.FeeSetup.LoanEstimateDescription.FASetText(Description ?? LoanEstimateDescription);
            FastDriver.FeeSetup.Geographictype.FASelectItemBySendingKeys("");
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys("Active");
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys(GLCode ?? "732 Assumption");
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(SubjectToSaleTaxes);
            FastDriver.FeeSetup.SubjectTocalculation.FASetCheckbox(SubjectToCalculation);
            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys("Title");
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys("Title Owning Office");
            FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys("Paid at Closing");
            FastDriver.FeeSetup.DefaultPaymentMethod.FASelectItemBySendingKeys("Fee");
            FastDriver.FeeSetup.BuyerSection.FASelectItemBySendingKeys("B,C,H");
            FastDriver.FeeSetup.SellerSection.FASelectItemBySendingKeys("B,C,H");

           switch( Section ){
               case ClosingDisclosureSection.B:
                   FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
                   break;
               case ClosingDisclosureSection.C:
                   FastDriver.FeeSetup.PaymentDetailsSectionC.FAClick();
                   break;
                case ClosingDisclosureSection.H:
                   FastDriver.FeeSetup.PaymentDetailsSectionH.FAClick();
                break; 
           }
            

            FastDriver.FeeSetup.AddRemove.FAClick();
            FastDriver.FeeFilterTemplateSummaryDlg.WaitForScreenToLoad();
            FastDriver.FeeFilterTemplateSummaryDlg.FeeFilterTable.PerformTableAction(2, FeeFilterName, 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();
        
        }

        public void CreateOrEditFeeWithFeeFilterNameAndCustomValues(FeeSetupParameters FeeSetup, bool EditExistingFee = false)
        {
            

            if (!EditExistingFee)
            {
                FastDriver.FeeList2.New.FAClick();
            }

            FastDriver.FeeSetup.WaitForScreenToLoad();

            if (!EditExistingFee)
            {
                FastDriver.FeeSetup.HudType.FASelectItem(FeeSetup.FormType);
            }

            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys(FeeSetup.FeeDistribution);

            if (!EditExistingFee)
            {
                FastDriver.FeeSetup.FeeCode.FASetText(FeeSetup.FeeCode);
            }

            FastDriver.FeeSetup.FeeType.FASelectItem(FeeSetup.FeeType);
            Thread.Sleep(1600);
            FastDriver.FeeSetup.Description.FASetText(FeeSetup.Description);
            FastDriver.FeeSetup.LoanEstimateDescription.FASetText(FeeSetup.Description ?? FeeSetup.LoanEstimateDescription);
            FastDriver.FeeSetup.Geographictype.FASelectItemBySendingKeys(FeeSetup.GeographicType);
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys(FeeSetup.FeeStatus);
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys(FeeSetup.GLCode);
            Thread.Sleep(1600);
            FastDriver.FeeSetup.DefaultChargeAmt.FASetText(FeeSetup.DefaultChargeAmount);
            FastDriver.FeeSetup.DefaultChargeto.FASelectItemBySendingKeys(FeeSetup.DefaultChargeTo);
            FastDriver.FeeSetup.RecipientType.FASetText(FeeSetup.RecipientType);
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys(FeeSetup.FeeOwningOfficeType);
            FastDriver.FeeSetup.BuyerSection.FASelectItemBySendingKeys(FeeSetup.BuyerSection);
            FastDriver.FeeSetup.SellerSection.FASelectItemBySendingKeys(FeeSetup.SellerSection);
            FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(FeeSetup.ThirdPartyPayee);
            Thread.Sleep(1600);
            if (FeeSetup.ThirdPartyPayee)
            {
                FastDriver.FeeSetup.ThirdPartyPNameDefault.FASetText(FeeSetup.ThirdPartyPayeeNameDefault);

            }
            FastDriver.FeeSetup.DescriptionEditable.FASetCheckbox(FeeSetup.DescriptionEditable);
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(FeeSetup.SubjectToSalesTax);
            FastDriver.FeeSetup.CompanyIncomeFee.FASetCheckbox(FeeSetup.CompanyIncomeFee);
            FastDriver.FeeSetup.OfficeIncomeFee.FASetCheckbox(FeeSetup.OfficeIncomeFee);
            FastDriver.FeeSetup.TitleOfficerFee.FASetCheckbox(FeeSetup.TitleOfficeFee);
            FastDriver.FeeSetup.EscrowOfficerFee.FASetCheckbox(FeeSetup.EscrowOfficeFee);
            FastDriver.FeeSetup.SalesRepFee.FASetCheckbox(FeeSetup.SalesRepFee);
            FastDriver.FeeSetup.SubjectTocalculation.FASetCheckbox(FeeSetup.SubjectToCalculation);
            FastDriver.FeeSetup.SplitWithFAOffice.FASetCheckbox(FeeSetup.SplitwithFAOffice);
            FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(FeeSetup.SubjectToStateAssignment);

            FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys(FeeSetup.DefaultPaymentCategory);
            FastDriver.FeeSetup.DefaultPaymentMethod.FASelectItemBySendingKeys(FeeSetup.Method);
            
            switch (FeeSetup.Section)
            {
                case ClosingDisclosureSection.B:
                    FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
                    FastDriver.FeeSetup.LenderAffiliate.FASetCheckbox(FeeSetup.LenderAffiliate);
                    break;
                case ClosingDisclosureSection.C:
                    FastDriver.FeeSetup.PaymentDetailsSectionC.FAClick();
                    break;
                case ClosingDisclosureSection.H:
                    FastDriver.FeeSetup.PaymentDetailsSectionH.FAClick();
                    break;
            }

            if(!FeeSetup.MISMOCategory.Equals(""))
            {
                FastDriver.FeeSetup.MISMOCategory.FASelectItemBySendingKeys(FeeSetup.MISMOCategory);
                FastDriver.FeeSetup.MISMOType.FASelectItemBySendingKeys(FeeSetup.MISMOType);
            }

            if(!FeeSetup.FeeFilterName.Equals(""))
            {
                FastDriver.FeeSetup.AddRemove.FAClick();
                FastDriver.FeeFilterTemplateSummaryDlg.WaitForScreenToLoad();
                try
                {
                    Reports.TestStep = "Adding filter " + FeeSetup.FeeFilterName + " to fee";
                    FastDriver.FeeFilterTemplateSummaryDlg.FeeFilterTable.PerformTableAction(2, FeeSetup.FeeFilterName, 1, TableAction.On);
                }
                catch(NoSuchElementException)
                {
                    Reports.StatusUpdate("Could not find " + FeeSetup.FeeFilterName + " on Fee Filter Templates table", false);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();

        }


        public void CreateAHUDFeeWithDefaultValues(string Description, string FeeCode, string FeeType, string FormType)
        {
            FastDriver.FeeList2.SwitchToContentFrame();
            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
            FastDriver.FeeSetup.HudType.FASelectItem(FormType);
            FastDriver.FeeSetup.FeeCode.FASetText(FeeCode);
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            Thread.Sleep(1500);
            if (FormType.ToUpper() == "LEGACY" || FeeType == "Transfer Tax - Deed")
            FastDriver.FeeSetup.Geographictype.FASelectItem("County");
            Thread.Sleep(1000);
            FastDriver.FeeSetup.Description.FASetText(Description);
            
            FastDriver.FeeSetup.Geographictype.FASelectItemBySendingKeys("");
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys("Active");
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys("116-02 Recording Fees - Non-Revenue");
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(true);
            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys("Title");
            Thread.Sleep(1500);
            if(FormType.ToUpper()!="LEGACY")
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys("Title Owning Office");
            //FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys("Paid at Closing");


            FastDriver.FeeSetup.HUDPaymentDetailsSection.FASelectItemBySendingKeys("FEE");
            FastDriver.FeeSetup.BuyerCharge.FASelectItemBySendingKeys("104");
            FastDriver.FeeSetup.SellerCharge.FASelectItemBySendingKeys("1044");
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();

        }

        public void CreateALegacyFeeWithDefaultValues(string Description, string FeeCode, string FeeType, string FormType)
        {
            FastDriver.FeeList2.SwitchToContentFrame();
            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
            FastDriver.FeeSetup.HudType.FASelectItem(FormType);
            FastDriver.FeeSetup.FeeCode.FASetText(FeeCode);
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            Thread.Sleep(1500);
          //  if (FormType.ToUpper() == "LEGACY" || FeeType == "Transfer Tax - Deed")
            //    FastDriver.FeeSetup.Geographictype.FASelectItem("County");
           // Thread.Sleep(1000);
            FastDriver.FeeSetup.Description.FASetText(Description);

            FastDriver.FeeSetup.Geographictype.FASelectItemBySendingKeys("");
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys("Active");
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys("116-02 Recording Fees - Non-Revenue");
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(true);
            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys("Title");
            Thread.Sleep(1500);
                FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys("Title Owning Office");
            //FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys("Paid at Closing");


            FastDriver.FeeSetup.HUDPaymentDetailsSection.FASelectItemBySendingKeys("FEE");
            FastDriver.FeeSetup.BuyerCharge.FASelectItemBySendingKeys("104");
            FastDriver.FeeSetup.SellerCharge.FASelectItemBySendingKeys("1044");
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();

        }

        public void CreateTaxFeeWithDefaultValues(string Description, string FeeCode, string FeeType ,string geotypeIndex)
        {
            FastDriver.FeeList2.SwitchToContentFrame();
            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
            FastDriver.FeeSetup.HudType.FASelectItem("CD");
            FastDriver.FeeSetup.FeeCode.FASetText(FeeCode);
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            Thread.Sleep(1600);
            FastDriver.FeeSetup.Description.FASetText(Description);
            FastDriver.FeeSetup.LoanEstimateDescription.FASetText(Description);
            FastDriver.FeeSetup.Geographictype.FASelectItemByIndex(Convert.ToInt32(geotypeIndex));
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys("Active");
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys("116-02 Recording Fees - Non-Revenue");
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(true);
            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys("Title");
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys("Title Owning Office");
            FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys("Paid at Closing");
            FastDriver.FeeSetup.DefaultPaymentMethod.FASelectItemBySendingKeys("Fee");
            FastDriver.FeeSetup.BuyerSection.FASelectItemBySendingKeys("B,C,H");
            FastDriver.FeeSetup.SellerSection.FASelectItemBySendingKeys("B,C,H");
            FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
            FastDriver.FeeSetup.LenderAffiliate.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();

        }

        public void CreateFeeWithDefaultChargeTo(string Description, string FeeCode, string FeeType,string DefaultChargeto ,string DefaultChargeAmount,bool subjecttocal , bool subjecttostateassignment)
        {
            FastDriver.FeeList2.SwitchToContentFrame();
            FastDriver.FeeList2.New.FAClick();
            FastDriver.FeeSetup.SwitchToContentFrame();
            FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
            string abc = ClosingDisclosureSupport.IMDFormType;
            if (ClosingDisclosureSupport.IMDFormType == "CD")
            {
                FastDriver.FeeSetup.HudType.FASelectItem("CD");
            }

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
            {
                FastDriver.FeeSetup.HudType.FASelectItem("HUD");
            }
            FastDriver.FeeSetup.FeeCode.FASetText(FeeCode);
            FastDriver.FeeSetup.FeeType.FASelectItem(FeeType);
            Thread.Sleep(2000);
            FastDriver.FeeSetup.Description.FASetText(Description);
            if (ClosingDisclosureSupport.IMDFormType == "CD")
            FastDriver.FeeSetup.LoanEstimateDescription.FASetText(Description);
            FastDriver.FeeSetup.Geographictype.FASelectItemBySendingKeys("");
            FastDriver.FeeSetup.FeeStatus.FASelectItemBySendingKeys("Active");
            FastDriver.FeeSetup.GLCode.FASelectItemBySendingKeys("116-02 Recording Fees - Non-Revenue");
            if(DefaultChargeto!="")
            FastDriver.FeeSetup.DefaultChargeto.FASelectItem(DefaultChargeto);
            if (DefaultChargeAmount != "")
            FastDriver.FeeSetup.DefaultChargeAmt.FASetText(DefaultChargeAmount);
            FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(true);
            FastDriver.FeeSetup.SubjectTocalculation.FASetCheckbox(subjecttocal);
            FastDriver.FeeSetup.SubjectToStateAssignment.FASetCheckbox(subjecttostateassignment);
            FastDriver.FeeSetup.FeeDistribution.FASelectItemBySendingKeys("Title");
            FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItemBySendingKeys("Title Owning Office");

            if (ClosingDisclosureSupport.IMDFormType == "CD")
            {
                FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItemBySendingKeys("Paid at Closing");
                FastDriver.FeeSetup.DefaultPaymentMethod.FASelectItemBySendingKeys("Fee");
                FastDriver.FeeSetup.BuyerSection.FASelectItemBySendingKeys("B,C,H");
                FastDriver.FeeSetup.SellerSection.FASelectItemBySendingKeys("B,C,H");
                FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
                FastDriver.FeeSetup.LenderAffiliate.FAClick();
            }

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
            {
                FastDriver.FeeSetup.HUDPaymentDetailsSection.FASelectItemBySendingKeys("FEE");
                FastDriver.FeeSetup.BuyerCharge.FASelectItemBySendingKeys("104");
                FastDriver.FeeSetup.SellerCharge.FASelectItemBySendingKeys("1044");
            }
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();

        }

        //Edd Filter
        public void AddFiltertoFee(string FormType, string FeeCode, string FeeType, string FilterName)
        {
            Reports.TestStep = "Edd Filter template to Fee.";
            FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);

            FastDriver.FeeList2.FeeFormType.FASelectItem(FormType);
            FastDriver.FeeList2.FeeType.FASelectItem(FeeType);
            Thread.Sleep(1600);
            FastDriver.FeeList2.WaitScreenToLoad();
            FastDriver.FeeList2.ActiveOnly.Click();
            Thread.Sleep(1000);
            FastDriver.FeeList2.FeeTable.PerformTableAction(3, FeeCode, 3, TableAction.Click);
            FastDriver.FeeList2.Edit.Click();

            FastDriver.FeeSetup.WaitForScreenToLoad();
            FastDriver.FeeSetup.AddRemove.FAClick();

            FastDriver.FeeFilterTemplateSummaryDlg.WaitForScreenToLoad();

            FastDriver.FeeFilterTemplateSummaryDlg.FeeFilterTable.PerformTableAction(2, FilterName, 1, TableAction.On);

            Reports.TestStep = "Click on Done on Dialog.";

            FastDriver.FeeFilterTemplateSummaryDlg.SwitchToDialogBottomFrame();

            FastDriver.DialogBottomFrame.ClickDone();


            Reports.TestStep = "Click on Done on Main Window to reach Filter Template edit screen.";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            FastDriver.FeeSetup.WaitForScreenToLoad();

            FastDriver.FeeSetup.SwitchToBottomFrame();

            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.SwitchToContentFrame();

        }

        public void CheckSubjectToCalculationFee(string feeName, string feetype, string template, bool subToCal) {

            Reports.TestStep = "FEE_SETUP: checking for the subject to calculation checkbox for " + feeName + "Fee.";
            FastDriver.LeftNavigation.Navigate<FeeList2>("Home>System Maintenance>Fee Setup>Fee Summary");
            FastDriver.FeeList2.WaitScreenToLoad();

            FastDriver.FeeList2.FeeFormType.FASelectItemBySendingKeys(AutoConfig.FormType);
            FastDriver.FeeList2.WaitFeeTableUpdate(FastDriver.FeeList2.FeeType);

            FastDriver.FeeList2.FeeType.FASelectItem(feetype);
            FastDriver.FeeList2.WaitFeeTableUpdate();

            FastDriver.FeeList2.FeeTable.PerformTableAction(4, feeName, 4, TableAction.Click);
            FastDriver.FeeList2.Edit.FAClick();

            FastDriver.FeeSetup.WaitForScreenToLoad();

            if(!FastDriver.FeeSetup.FeeTemplateTable.FAGetText().Contains(feeName)){
                Reports.TestStep = "Check for the filter set for the Fees.";
                FastDriver.FeeSetup.AddRemove.FAClick();
                FastDriver.FeeFilterTemplateSummaryDlg.WaitForScreenToLoad();
                FastDriver.FeeFilterTemplateSummaryDlg.FeeFilterTable.PerformTableAction(2, template, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.FeeSetup.WaitForScreenToLoad();
            }

            Reports.TestStep = "Edit fee so that we can pull in file.";
            FastDriver.FeeSetup.SubjectTocalculation.FASetCheckbox(subToCal);

            if(!subToCal)
                FastDriver.FeeSetup.DefaultChargeAmt.FASetText("24.00");

            Reports.TestStep = "Settings done";
            FastDriver.BottomFrame.Done();
            FastDriver.FeeList2.WaitScreenToLoad();

        }

        public FeeSetup Open() {
            FastDriver.LeftNavigation.Navigate<FeeSetup>("Home/System Maintenance/Fee Setup/Fee Summary");
            this.WaitForScreenToLoad();
            return this;
        }

        public FeeSetup CreateFee(FeesetupParameters_gfv createfee)
        {
            try
            {
                FastDriver.FeeList2.SwitchToContentFrame();
                FastDriver.FeeList2.New.FAClick();
                FastDriver.FeeSetup.SwitchToContentFrame();
                FastDriver.FeeSetup.WaitCreation(FastDriver.FeeSetup.HudType);
                FastDriver.FeeSetup.HudType.FASelectItem("CD");
                if (createfee.FeeDesc != null)
                    FastDriver.FeeSetup.Description.FASetText(createfee.FeeDesc);

                FastDriver.FeeSetup.FeeCode.FASetText(Support.RandomString("ANANAAN"));

                if (createfee.FeeType != null)
                    FastDriver.FeeSetup.FeeType.FASelectItem(createfee.FeeType);
                Playback.Wait(2000);

                FastDriver.FeeSetup.DescriptionEditable.FASetCheckbox(createfee.DescEdit);

                FastDriver.FeeSetup.LoanEstimateDescription.FASetText(createfee.LoanEstimatedesc);

                FastDriver.FeeSetup.GLCode.FASelectItem(createfee.GLCode);

                if (createfee.Geographictype != null)
                {
                    FastDriver.FeeSetup.Geographictype.FASelectItem(createfee.Geographictype);
                }

                if (createfee.DefaultChargeAmtfrom != null)
                {
                    FastDriver.FeeSetup.DefaultChargeAmt.FASetText(createfee.DefaultChargeAmtfrom);
                    if (createfee.DefaultChargeAmtTo != null)
                    {
                        FastDriver.FeeSetup.DefaultChargeto.FASelectItem(createfee.DefaultChargeAmtTo);
                    }
                }
                FastDriver.FeeSetup.FeeDistribution.FASelectItem(createfee.FeeDistribution);
                FastDriver.FeeSetup.FeeOwnigOfficeType.FASelectItem(createfee.FeeOwnigOfficeType);

                FastDriver.FeeSetup.SubjectToSalesTax.FASetCheckbox(createfee.SubjectToSalesTax);

                FastDriver.FeeSetup.SubjectTocalculation.FASetCheckbox(createfee.SubjectToCalculation);

                if (createfee.thirdPartyPayee == true)
                {
                    FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(createfee.thirdPartyPayee);
                    FastDriver.FeeSetup.ThirdPartyPNameDefault.FASetText(createfee.thirdPPayeeName);
                }

                if (createfee.thirdPartyPayee == false)
                {
                    FastDriver.FeeSetup.ThirdPartyPayee.FASetCheckbox(createfee.thirdPartyPayee);
                }


                FastDriver.FeeSetup.BuyerSection.FASelectItemBySendingKeys(createfee.bSection);
                FastDriver.FeeSetup.BuyerLine.FASetText(createfee.blineno);

                FastDriver.FeeSetup.SellerSection.FASelectItemBySendingKeys(createfee.sSection);
                FastDriver.FeeSetup.SellerLine.FASetText(createfee.slineno);

                if (createfee.bSection == "B,C,H" || createfee.bSection == "B" || createfee.sSection == "B,C,H" || createfee.sSection == "B")
                {
                    switch (createfee.section)
                    {
                        case ClosingDisclosureSection.B:
                            FastDriver.FeeSetup.PaymentDetailsSectionB.FAClick();
                            FastDriver.FeeSetup.LenderAffiliate.FASetCheckbox(createfee.LenderAffliate);
                            break;
                        case ClosingDisclosureSection.C:
                            FastDriver.FeeSetup.PaymentDetailsSectionC.FAClick();
                            break;
                        case ClosingDisclosureSection.H:
                            FastDriver.FeeSetup.PaymentDetailsSectionH.FAClick();
                            break;
                    }

                }

                FastDriver.FeeSetup.DefaultPaymentCategory.FASelectItem(createfee.DefaultPaymentCategory);

                if (createfee.DefaultPaymentMethod != null)
                {
                    FastDriver.FeeSetup.DefaultPaymentMethod.FASelectItem(createfee.DefaultPaymentMethod);
                    Keyboard.SendKeys(FAKeys.TabAway);
                }



                if (createfee.FeeFilterName != null)
                {
                    FastDriver.FeeSetup.AddRemove.FAClick();
                    FastDriver.FeeFilterTemplateSummaryDlg.WaitForScreenToLoad();
                    FastDriver.FeeFilterTemplateSummaryDlg.FeeFilterTable.PerformTableAction(2, createfee.FeeFilterName, 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }

                FastDriver.BottomFrame.Done();
                FastDriver.FeeList2.SwitchToContentFrame();
            }
            catch (Exception ex)
            {
                Support.Fail(ex.Message);
            }
            return this;
        }
    }
}
