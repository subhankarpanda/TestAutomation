using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class FormMaintenance : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtFileName")]
        public IWebElement FileName { get; set; }

        [FindsBy(How = How.Id, Using = "txtFormDesc")]
        public IWebElement FormDesc { get; set; }

        [FindsBy(How = How.Id, Using = "btnFile")]
        public IWebElement FileLocation { get; set; }

         [FindsBy(How = How.Id, Using = "uploadDocument")]
        public IWebElement FileUpload { get; set; }


        

        [FindsBy(How = How.Id, Using = "ucGMT_optAct")]
        public IWebElement StatusActive { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_optInAct")]
        public IWebElement StatusInactive { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_txtCmt")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_dgridRevHstry_0_lblRDate")]
        public IWebElement RevisedDate { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_dgridRevHstry_dgridRevHstry")]
        public IWebElement RevisedHistoryTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "11/06/2012 07:17:37 AM")]
        public IWebElement FormDescriptionUnique { get; set; }


        [FindsBy(How = How.Id, Using = "txtfrmEditFormDescr")]
        public IWebElement FormDescriptiontxt { get; set; }

        [FindsBy(How = How.Id, Using = "Form_0_txtHistComments")]
        public IWebElement FormCommenttxt { get; set; }

        [FindsBy(How = How.Id, Using = "btnFormDone")]
        public IWebElement FormButtonDone { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement FormDescriptionUniqueName { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_lblCrDt")]
        public IWebElement CreatedDate { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//html/body/li/font[@color='red']")]
        public IWebElement eMessage { get; set; }

        #endregion

        public FormMaintenance WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FileName);

            return this;
        }

        public FormMaintenance EnterFormMaintenanceData(string formName, bool status, string comments)
        {
            WaitForScreenToLoad(FileLocation);

            var fileLoc = Reports.DEPLOYDIR + @"\" + formName + ".doc";
            System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", fileLoc, true);
            FileLocation.FASetText(fileLoc, false); //File Location is disabled so clear will cause error
            StatusActive.FASetCheckbox(status);
            Comments.FASetText(comments);
            FormDesc.FASetText(formName);

            return this;
        }


        public FormMaintenance EnterFormUploadData(string formName, bool status, string comments)
        {
            WaitForScreenToLoad(FileUpload);

            var fileLoc = Reports.DEPLOYDIR + @"\" + formName + ".doc";
            System.IO.File.Copy(Reports.DEPLOYDIR + @"\GeneralForm.doc", fileLoc, true);
            FileLocation.FASetText(fileLoc, false); //File Location is disabled so clear will cause error
            StatusActive.FASetCheckbox(status);
            FormCommenttxt.FASetText(comments);
            //FormDesc.FASetText(formName);
           FormDescriptiontxt.FASetText(formName);
           FormButtonDone.FAClick(); 
            return this;
        }
    }
}
