using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using AutoIt;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class FormMaintenanceSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "DPUC0003FORM")]
        public IWebElement DPUC0003FORM { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFormSummary_dGridFormSummary")]
        public IWebElement FormSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement EditUpload { get; set; }

        [FindsBy(How = How.Id, Using = "btnDownload")]
        public IWebElement Download { get; set; }

        [FindsBy(How = How.Id, Using = "btnUndoCheckOut")]
        public IWebElement UndoCheckOut { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        //Added By Subhankar
        [FindsBy(How = How.Id, Using = "retfrmView")]
        public IWebElement View { get; set; }
        [FindsBy(How = How.Id, Using = "retfrmpoperties")]
        public IWebElement Properties { get; set; }
        [FindsBy(How = How.Id, Using = "retfrmcheckout")]
        public IWebElement Checkout { get; set; }
        [FindsBy(How = How.Id, Using = "retfrmcheckin")]
        public IWebElement Checkin { get; set; }
        [FindsBy(How = How.Id, Using = "retfrmUndocheckout")]
        public IWebElement UndoChkout { get; set; }
        [FindsBy(How = How.Id, Using = "retfrmDelete")]
        public IWebElement Deletebtn { get; set; }

        #endregion

        public FormMaintenanceSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FormSummaryTable);

            return this;
        }

        public FormMaintenanceSummary HandleOpenOrSave(string action = "Save", bool switchBackToFastWindow = true)
        {
            string WinDlg = "[CLASS:IEFrame]";

            if (AutoItX.WinExists(WinDlg) != 0)
            {
                AutoItX.WinActivate(WinDlg);
                if (action == "Save")
                    AutoItX.ControlSend("", "", "[CLASS:DirectUIHWND; INSTANCE:2]", "!s"); // Save
                else if(action == "Open")
                    AutoItX.ControlSend("", "", "[CLASS:DirectUIHWND; INSTANCE:2]", "!o"); // Open
                else
                    AutoItX.ControlSend("", "", "[CLASS:DirectUIHWND; INSTANCE:2]", "!c"); ; // Cancel

                Reports.UpdateDebugLog("AutoIt", "Alert", "Handle Open or Save popup", "", "", "", Reports.Result(true), "");
            }

            if (switchBackToFastWindow)
            {
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }

            return this;
        }
    }
}
