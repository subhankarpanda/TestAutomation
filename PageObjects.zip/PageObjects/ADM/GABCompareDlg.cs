using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class GABCompareDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "btnAddModContact")]
		public IWebElement AddModifyContact { get; set; }

        [FindsBy(How = How.Id, Using = "cboStatus")]
        public IWebElement Status { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "cboEntityType")]
        public IWebElement EntityType { get; set; }

        
		#endregion


        public GABCompareDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogLeftContentFrame();
            this.WaitCreation(element ?? AddModifyContact);
            return this;
        }
        //
        public GABCompareDlg WaitForLeftFrameToLoad(IWebElement element = null)
        {
            this.SwitchToDialogLeftContentFrame();
            this.WaitCreation(element ?? EntityType);
            return this;
        }
        //
        public GABCompareDlg WaitForRightFrameToLoad(IWebElement element = null)
        {
            this.SwitchToDialogRightContentFrame();
            this.WaitCreation(element ?? EntityType);
            return this;
        }

	}
}
