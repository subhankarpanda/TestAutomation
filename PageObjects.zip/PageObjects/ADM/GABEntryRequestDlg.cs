using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GABEntryRequestDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboBSType")]
		public IWebElement BuyerSellerType { get; set; }

		[FindsBy(How = How.Id, Using = "cboET")]
		public IWebElement EntityType { get; set; }

		[FindsBy(How = How.Id, Using = "cboGrade")]
		public IWebElement Grade { get; set; }

		[FindsBy(How = How.Id, Using = "txtIDCode")]
		public IWebElement IDCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtName1")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtName2")]
		public IWebElement Name2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtLocDesc")]
		public IWebElement LocDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtTaxIDNum")]
		public IWebElement TaxIDNumber { get; set; }

		[FindsBy(How = How.Id, Using = "cboTAT")]
		public IWebElement TitleAgentType { get; set; }

		[FindsBy(How = How.Id, Using = "txtBOComments")]
		public IWebElement BusOrgComments { get; set; }

		[FindsBy(How = How.Id, Using = "txtLicNum")]
		public IWebElement LicenseNumber { get; set; }

		[FindsBy(How = How.Id, Using = "txtGABEI")]
		public IWebElement EntryInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "ddlLicType")]
		public IWebElement LicenseType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_chkEmailStatus")]
		public IWebElement PhonesStatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_cmdAddPhoneType")]
		public IWebElement PhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_cmdDeletePhoneEntry")]
		public IWebElement PhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement BusinessPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_textNumber")]
		public IWebElement BusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_textExtension")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_textComments")]
		public IWebElement BusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement BusinessFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_textNumber")]
		public IWebElement BusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_textExtension")]
		public IWebElement BusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_textComments")]
		public IWebElement BusinessFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement EmailType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_2_textNumber")]
		public IWebElement EmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_2_textComments")]
		public IWebElement EmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement PagerType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_textNumber")]
		public IWebElement PagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_textExtension")]
		public IWebElement PagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_textComments")]
		public IWebElement PagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement CellularType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_textNumber")]
		public IWebElement CellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_textExtension")]
		public IWebElement CellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_textComments")]
		public IWebElement CellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement HomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_textNumber")]
		public IWebElement HomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_textExtension")]
		public IWebElement HomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_textComments")]
		public IWebElement HomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement HomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_textNumber")]
		public IWebElement HomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_textExtension")]
		public IWebElement HomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_textComments")]
		public IWebElement HomeFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textAddrLine1")]
		public IWebElement MailingAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textAddrLine2")]
		public IWebElement MailingAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textAddrLine3")]
		public IWebElement MailingAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textAddrLine4")]
		public IWebElement MailingAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textCity")]
		public IWebElement MailingAddressCity { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_comboState")]
		public IWebElement MailingAddressState { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textZip")]
		public IWebElement MailingAddressZip { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_textCounty")]
		public IWebElement MailingAddressCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ucMAD_comboCountry")]
		public IWebElement MailingAddressCountry { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine1")]
		public IWebElement BillingAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine2")]
		public IWebElement BillingAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine3")]
		public IWebElement BillingAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine4")]
		public IWebElement BillingAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textCity")]
		public IWebElement BillingAddressCity { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_comboState")]
		public IWebElement BillingAddressState { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textZip")]
		public IWebElement BillingAddressZip { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_textCounty")]
		public IWebElement BillingAddressCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ucBIAD_comboCountry")]
		public IWebElement BillingAddressCountry { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine1")]
		public IWebElement BusinessAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine2")]
		public IWebElement BusinessAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine3")]
		public IWebElement BusinessAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine4")]
		public IWebElement BusinessAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textCity")]
		public IWebElement BusinessAddressCity { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_comboState")]
		public IWebElement BusinessAddressState { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textZip")]
		public IWebElement BusinessAddressZip { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_textCounty")]
		public IWebElement BusinessAddressCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ucBUAD_comboCountry")]
		public IWebElement BusinessAddressCountry { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement ContactsAdd { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement ContactsRemove { get; set; }

		[FindsBy(How = How.Id, Using = "txtFN")]
		public IWebElement ContactsFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "txtLN")]
		public IWebElement ContactsLastName { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_chkEmailStatus")]
		public IWebElement ContactsStatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_cmdAddPhoneType")]
		public IWebElement ContactsPhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_cmdDeletePhoneEntry")]
		public IWebElement ContactsPhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_comboPhoneType")]
		public IWebElement ContactsPhonesBusinessPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_textNumber")]
		public IWebElement ContactsPhonesBusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_textExtension")]
		public IWebElement ContactsPhonesBusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_textComments")]
		public IWebElement ContactsPhonesBusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_comboPhoneType")]
		public IWebElement ContactsPhonesBusinessFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_textNumber")]
		public IWebElement ContactsPhonesBusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_textExtension")]
		public IWebElement ContactsPhonesBusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_textComments")]
		public IWebElement ContactsPhonesBusinessFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_2_comboPhoneType")]
		public IWebElement ContactsPhonesEmailType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_2_textNumber")]
		public IWebElement ContactsPhonesEmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_2_textComments")]
		public IWebElement ContactsPhonesEmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_comboPhoneType")]
		public IWebElement ContactsPhonesPagerType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_textNumber")]
		public IWebElement ContactsPhonesPagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_textExtension")]
		public IWebElement ContactsPhonesPagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_textComments")]
		public IWebElement ContactsPhonesPagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_comboPhoneType")]
		public IWebElement ContactsPhonesCellularType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_textNumber")]
		public IWebElement ContactsPhonesCellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_textExtension")]
		public IWebElement ContactsPhonesCellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_textComments")]
		public IWebElement ContactsPhonesCellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_comboPhoneType")]
		public IWebElement ContactsPhonesHomePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_textNumber")]
		public IWebElement ContactsPhonesHomePhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_textExtension")]
		public IWebElement ContactsPhonesHomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_textComments")]
		public IWebElement ContactsPhonesHomePhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_comboPhoneType")]
		public IWebElement ContactsPhonesHomeFaxType { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_textNumber")]
		public IWebElement ContactsPhonesHomeFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_textExtension")]
		public IWebElement ContactsPhonesHomeFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_textComments")]
		public IWebElement ContactsPhonesHomeFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_chkCopyBOAddr")]
		public IWebElement SameAsBusOrgMailingAddress { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine1")]
		public IWebElement AddressDetailAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine2")]
		public IWebElement AddressDetailAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine3")]
		public IWebElement AddressDetailAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine4")]
		public IWebElement AddressDetailAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textCity")]
		public IWebElement AddressDetailCity { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_comboState")]
		public IWebElement AddressDetailState { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textZip")]
		public IWebElement AddressDetailZip { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textCounty")]
		public IWebElement AddressDetailCounty { get; set; }

		[FindsBy(How = How.Id, Using = "ucCnctPhyAddr_comboCountry")]
		public IWebElement AddressDetailCountry { get; set; }

		#endregion

	}
}
