using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GABEntryRequestQueue : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "cboStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "cmdComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "dgridGABEntryRequestQueue")]
		public IWebElement GABEntryRequestTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "202150")]
		public IWebElement GABID { get; set; }

		[FindsBy(How = How.Id, Using = "dgridGABEntryRequestQueue_0_lblGABID")]
		public IWebElement GABID1 { get; set; }

		#endregion


        public GABEntryRequestQueue WaitForGABEntryRequestTableToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABEntryRequestTable);
            return this;
        }

        public GABEntryRequestQueue WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GABEntryRequestTable);
            return this;
        }

        public GABEntryRequestQueue Open()
        {
            FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>GAB Entry Request Queue");
            this.WaitForScreenToLoad();
            return this;
        }
    }
}
