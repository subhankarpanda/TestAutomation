using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GABMasterDetail : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlMasterContacts")]
		public IWebElement MasterContacts { get; set; }

		[FindsBy(How = How.Id, Using = "chkFurtherReview")]
		public IWebElement FurtherReview { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "btnViewGAB")]
		public IWebElement FASTGAB { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeactivate")]
		public IWebElement Deactivate { get; set; }

		[FindsBy(How = How.Id, Using = "btnMerge")]
		public IWebElement MergeContacts { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_0_radListItemIsMaster")]
		public IWebElement Master1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_0_chkRemoveListItemFromGroup")]
		public IWebElement Group1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_1_radListItemIsMaster")]
		public IWebElement Master2 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_1_chkRemoveListItemFromGroup")]
		public IWebElement Group3 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_1_btnIndicatorFlg")]
		public IWebElement ImportantIndicators { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_2_radListItemIsMaster")]
		public IWebElement Master4 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_0_chkRemoveListItemFromGroup")]
		public IWebElement Group4 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_3_radListItemIsMaster")]
		public IWebElement Master5 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties_1_chkRemoveListItemFromGroup")]
		public IWebElement Group5 { get; set; }

		[FindsBy(How = How.Id, Using = "grdChildParties")]
		public IWebElement Table { get; set; }

        #endregion

        public GABMasterDetail WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FASTGAB);
            return this;
        }
    }
}
