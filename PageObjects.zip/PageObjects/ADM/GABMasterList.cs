using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GABMasterList : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtNameFilter")]
		public IWebElement NameFilter { get; set; }

		[FindsBy(How = How.Id, Using = "chkIncludeItemsWithoutDupsFilter")]
		public IWebElement IncludeItethoutDupsFilter { get; set; }

		[FindsBy(How = How.Id, Using = "chkFurther")]
		public IWebElement Further { get; set; }

		[FindsBy(How = How.Id, Using = "lboxPartyTypes")]
		public IWebElement PartyTypes { get; set; }

		[FindsBy(How = How.Id, Using = "txtCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "txtCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "ddlMasterState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddress")]
		public IWebElement Address { get; set; }

		[FindsBy(How = How.Id, Using = "txtZipCode")]
		public IWebElement ZipCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstName")]
		public IWebElement FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "txtLastName")]
		public IWebElement LastName { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnFind")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelectAsMasterForGroup")]
		public IWebElement SelectAsMaster { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddToMaster")]
		public IWebElement AddToMaster { get; set; }

		[FindsBy(How = How.Id, Using = "btnMasterDetail")]
		public IWebElement MasterDetail { get; set; }

		[FindsBy(How = How.Id, Using = "grdMasterList")]
		public IWebElement Table { get; set; }

        #endregion


        public GABMasterList WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Find);
            return this;
        }
    }
}
