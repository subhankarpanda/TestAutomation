using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GABMergeContacts : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "grdNonMaster_1_chkGrdNonMaster")]
		public IWebElement GrdNonMaster { get; set; }

		[FindsBy(How = How.Id, Using = "grdMaster_1_chkGrdMaster")]
		public IWebElement GrdMaster { get; set; }

		[FindsBy(How = How.Id, Using = "btnADD")]
		public IWebElement ADD { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement REMOVE { get; set; }

		[FindsBy(How = How.Id, Using = "chkCopyAddress")]
		public IWebElement CopyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "chkCopyPhones")]
		public IWebElement CopyPhones { get; set; }

		[FindsBy(How = How.Id, Using = "btnUpdateGAB")]
		public IWebElement UpdateGAB { get; set; }

        #endregion

        public GABMergeContacts WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? ADD);
            return this;
        }
    }
}
