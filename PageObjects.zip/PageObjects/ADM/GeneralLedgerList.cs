using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GeneralLedgerList : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "gridGLSummary")]
		public IWebElement SummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "gridGLSummary_39_FAFLabel2")]
		public IWebElement GLNumber { get; set; }

      

		#endregion


        public void Wait()
        {
            throw new NotImplementedException();
        }
    }
}
