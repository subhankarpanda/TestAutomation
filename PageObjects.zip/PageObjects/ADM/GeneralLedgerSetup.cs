using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.ObjectModel;

namespace FASTSelenium.PageObjects.ADM
{
	public class GeneralLedgerSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtGLCode")]
		public IWebElement GLCode { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtDescr")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "FAFcmbStatusDescr")]
		public IWebElement StatusDescription { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtGLedger")]
		public IWebElement GeneralLedger { get; set; }

		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement DeactivateError { get; set; }

		[FindsBy(How = How.LinkText, Using = "ObjectCd: General Ledger code already exists.")]
		public IWebElement DispError { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement DispErrorID { get; set; }

        [FindsBy(How = How.Id, Using = "gridGLSummary")]
		public IWebElement GeneralLedgerTable { get; set; }
		#endregion


        public GeneralLedgerSetup CreateNewGeneralLedgerSetup(string Description, string GLCode = null, string Status = null, string GeneralLedger = null) {
            
            Reports.TestStep = "Navigate to General ledger List";
            FastDriver.LeftNavigation.Navigate<GeneralLedgerSetup>("Home>System Maintenance>General Ledger Setup");
            WaitScreenToLoad();
            Reports.TestStep = "Verify if General Ledger: "+Description+" exists";
            
            if(CheckGeneralLedgerExists(Description)){
                return this;
            }
            
            Reports.TestStep = "General Ledger Does not exist, Creating General Ledger";
            New.FAClick();
            FastDriver.GeneralLedgerSetup.SwitchToContentFrame();
            FastDriver.GeneralLedgerSetup.Description.FASetText(Description);
            FastDriver.GeneralLedgerSetup.GLCode.FASetText(GLCode == null ? Support.RandomString("ANANA") : GLCode);
            FastDriver.GeneralLedgerSetup.StatusDescription.FASelectItemBySendingKeys(Status == null ? "Active" : Status);
            FastDriver.GeneralLedgerSetup.GeneralLedger.FASetText(GeneralLedger == null ? "Endorsement" : GeneralLedger);
            FastDriver.BottomFrame.Done();
            return this;
        }

        public GeneralLedgerSetup WaitScreenToLoad(IWebElement element=null) {
            this.SwitchToContentFrame();
            this.WaitCreation(element??New);
            return this;
        }

        //Goes through all General Ledger within the GeneralLedger Table and searches for a matching Description
        public bool CheckGeneralLedgerExists(string LedgerDescription)
        {
            bool LedgerFound = false;
            int itemCount = 1;
            int LedgerDescriptionColumnIndex = 2;
            ReadOnlyCollection<IWebElement> TD_Elements = GeneralLedgerTable.FindElements(By.CssSelector("td"));
            foreach (IWebElement TD_Element in TD_Elements)
            {
                if (TD_Element.Text.Trim() == LedgerDescription && itemCount % LedgerDescriptionColumnIndex == 0)
                {
                    LedgerFound = true;
                    break;
                }
                ++itemCount;
            }
            return LedgerFound;

        }
	}
}
