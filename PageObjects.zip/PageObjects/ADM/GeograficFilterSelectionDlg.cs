using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class GeograficFilterSelectionDlg : PageObject
	{
        public string WindowTitle { get { return "Geographic Filter Selection"; } }

		#region WebElements

		[FindsBy(How = How.Id, Using = "btnState")]
		public IWebElement AddRemoveState { get; set; }

		[FindsBy(How = How.Id, Using = "btnCounty")]
		public IWebElement AddRemoveCounty { get; set; }

		[FindsBy(How = How.Id, Using = "btnCity")]
		public IWebElement AddRemoveCity { get; set; }

		[FindsBy(How = How.Id, Using = "dgridStates_0_lblStateName")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCounties_0_lblCountyName")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCities_0_lblCityName")]
		public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "chckSrvcAll")]
        public IWebElement ServiveTypeCheck { get; set; }
        
        [FindsBy(How = How.Id, Using = "chckTitle")]
        public IWebElement TitleServiveTypeCheck { get; set; }

        [FindsBy(How = How.Id, Using = "chckEscrow")]
        public IWebElement EscrowServiveTypeCheck { get; set; }

        [FindsBy(How = How.Id, Using = "chckSubEscrow")]
        public IWebElement SubEscrowServiveTypeCheck { get; set; }


        [FindsBy(How = How.Id, Using = "chkUnderWriter")]
        public IWebElement UnderwriterSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkOffice")]
        public IWebElement OwningOfcSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedOfficeIds")]
        public IWebElement OwningOffice { get; set; }

        [FindsBy(How = How.Id, Using = "chkProd")]
        public IWebElement ProductTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedProdIds")]
        public IWebElement Products { get; set; }

        [FindsBy(How = How.Id, Using = "chkProp")]
        public IWebElement PropertyTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedPropertyTypeIds")]
        public IWebElement PropertyType { get; set; }
        
        
        [FindsBy(How = How.Id, Using = "chkTrans")]
        public IWebElement TransactionTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkBusSeg")]
        public IWebElement BusinessSegmentSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkProg")]
        public IWebElement ProgramTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkSearch")]
        public IWebElement SearchTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement ClearState { get; set; }

        [FindsBy(How = How.Id, Using = "grdState_7_chkSelState")]
        public IWebElement AZState { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement SelectButton { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Done']")]
        public IWebElement DoneButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Cancel']")]
        public IWebElement CancelButton { get; set; }
		#endregion


       

        public GeograficFilterSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(WindowTitle, true, 15);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? AddRemoveState);

            return this;
        }

	}
}
