using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class IBABankSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdAddBank")]
		public IWebElement IBABanksNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemoveBank")]
		public IWebElement IBABanksRemove { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAbanks_0_rblDefaultBank")]
		public IWebElement SelectBank { get; set; }

		[FindsBy(How = How.Id, Using = "txtBankName")]
		public IWebElement BankName { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddress1")]
		public IWebElement Address1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtContact1")]
		public IWebElement Contact1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtPhone1")]
		public IWebElement Phone1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmail1")]
		public IWebElement Email1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddress2")]
		public IWebElement Address2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtContact2")]
		public IWebElement Contact2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtPhone2")]
		public IWebElement Phone2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmail2")]
		public IWebElement Email2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "txtZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Id, Using = "txtCutOff")]
		public IWebElement DailyCutOff { get; set; }

		[FindsBy(How = How.Id, Using = "rblAMPM_0")]
		public IWebElement AMRadio { get; set; }

		[FindsBy(How = How.Id, Using = "rblAMPM_1")]
		public IWebElement PMRadio { get; set; }

		[FindsBy(How = How.Id, Using = "comboTimeZone")]
		public IWebElement TimeZone { get; set; }

		[FindsBy(How = How.Id, Using = "txtRoutingNo")]
		public IWebElement ABARoutingNumber { get; set; }

		[FindsBy(How = How.Id, Using = "comboStatus")]
		public IWebElement IBABankStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddProduct")]
		public IWebElement IBAProductsNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemoveProduct")]
		public IWebElement IBAProductsRemove { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_0_txtProductCode")]
		public IWebElement IBACode { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_0_txtProductName")]
		public IWebElement IBAProductName { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_0_rblDefaultProduct")]
		public IWebElement IBADefaultProductType { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_0_txtProductDesc")]
		public IWebElement IBAProductDescription { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAbanks_dgIBAbanks")]
		public IWebElement SelectBankTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_1_txtProductCode")]
		public IWebElement IBACode2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_1_txtProductName")]
		public IWebElement IBAProductName2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_1_rblDefaultProduct")]
		public IWebElement IBADefaultProductType2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAProducts_1_txtProductDesc")]
		public IWebElement IBAProductDescription2 { get; set; }

		[FindsBy(How = How.LinkText, Using = " Code:")]
		public IWebElement CodeLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Product Name:")]
		public IWebElement ProductNameLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "SMUC0044-IBA Bank")]
		public IWebElement BankNamePane { get; set; }

		#endregion

        public IBABankSetup WaitForScreenToLoad(IWebElement element = null, int timeout = 30)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30); //on some slow environment this dialog stay open for a while need to handle it.

            this.SwitchToContentFrame();
            this.WaitCreation(element ?? IBABanksNew, timeout);
            return this;
        }
	}
}
