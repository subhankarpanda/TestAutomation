using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ImageSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_0_chkSelect")]
		public IWebElement SelectImage { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_0_cboRequired")]
		public IWebElement Required { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_dgridImageTrigger")]
		public IWebElement ImageSelectionTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_1_chkSelect")]
		public IWebElement SelectImage1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_2_chkSelect")]
		public IWebElement SelectImage2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_3_chkSelect")]
		public IWebElement SelectImage3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_4_chkSelect")]
		public IWebElement SelectImage4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_5_chkSelect")]
		public IWebElement SelectImage5 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_6_chkSelect")]
		public IWebElement SelectImage6 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_7_chkSelect")]
		public IWebElement SelectImage7 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_8_chkSelect")]
		public IWebElement SelectImage8 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_9_chkSelect")]
		public IWebElement SelectImage9 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_10_chkSelect")]
		public IWebElement SelectImage10 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_11_chkSelect")]
		public IWebElement SelectImage11 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_12_chkSelect")]
		public IWebElement SelectImage12 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_13_chkSelect")]
		public IWebElement SelectImage13 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_14_chkSelect")]
		public IWebElement SelectImage14 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_15_chkSelect")]
		public IWebElement SelectImage15 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_16_chkSelect")]
		public IWebElement SelectImage16 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_17_chkSelect")]
		public IWebElement SelectImage17 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_18_chkSelect")]
		public IWebElement SelectImage18 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_19_chkSelect")]
		public IWebElement SelectImage19 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_20_chkSelect")]
		public IWebElement SelectImage20 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_21_chkSelect")]
		public IWebElement SelectImage21 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_22_chkSelect")]
		public IWebElement SelectImage22 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_23_chkSelect")]
		public IWebElement SelectImage23 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_24_chkSelect")]
		public IWebElement SelectImage24 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridImageTrigger_25_chkSelect")]
		public IWebElement SelectImage25 { get; set; }

		#endregion

        #region Useful Methods
        public ImageSelectionDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(CheckAll);
            return this;
        }
        #endregion

    }
}
