using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ImageTriggerProcessEventSetupDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "dgEventSetup_dgEventSetup")]
		public IWebElement Table { get; set; }

		#endregion

        public ImageTriggerProcessEventSetupDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //this.WebDriver.WaitForWindowAndSwitch("Image Trigger Process Event Setup", timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Done);

            return this;
        }
	}
}
