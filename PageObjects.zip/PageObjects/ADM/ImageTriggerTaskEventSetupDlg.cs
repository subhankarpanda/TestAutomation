using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ImageTriggerTaskEventSetupDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgEventSetup_0_lblName")]
		public IWebElement Ten99 { get; set; }

		[FindsBy(How = How.Id, Using = "dgEventSetup_0_chkSelEvent")]
		public IWebElement Select1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgEventSetup_1_chkSelEvent")]
		public IWebElement Select2 { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "dgEventSetup_dgEventSetup")]
        public IWebElement ImageTriggerTable { get; set; }

		#endregion

        #region Useful Methods
        public ImageTriggerTaskEventSetupDlg WaitForScreenToLoad(string windowName = "Image Trigger Task Event Setup")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(Done);
            return this;
        }
        #endregion

    }
}
