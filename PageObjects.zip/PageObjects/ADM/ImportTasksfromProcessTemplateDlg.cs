using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ImportTasksfromProcessTemplateDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDetails")]
		public IWebElement Details { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "dgProcessTemplate_dgProcessTemplate")]
		public IWebElement TemplateTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgTaskTemplate_dgTaskTemplate")]
        public IWebElement TasksTable { get; set; }

		#endregion

        #region Useful Methods
        public ImportTasksfromProcessTemplateDlg WaitForScreenToLoad(string windowName = "Import Tasks from Process Template")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame(switchToFraPageWin:false);
            this.WaitCreation(TemplateTable);
            return this;
        }

        public ImportTasksfromProcessTemplateDlg WaitForTasksTableToLoad()
        {
            this.WaitCreation(TasksTable, timeoutSeconds: 10);
            return this;
        }
        #endregion

    }
}
