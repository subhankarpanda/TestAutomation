using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ImportantIndicatorsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "divIndicatorsText")]
		public IWebElement divIndicatorsText { get; set; }

        #endregion

        public ImportantIndicatorsDlg WaitForScreenToLoad()
        {

            this.SwitchToDialogContentFrame(switchToFraPageWin:false);
            this.WaitCreation(Done);
            return this;
        }
    }
}
