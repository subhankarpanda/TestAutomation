﻿using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class LicenseInfoChangeHistoryDlg : PageObject
    {
        #region
        [FindsBy(How = How.Id, Using = "dgridChangeHistory_dgridChangeHistory")]
        public IWebElement ChangeHistoryTable { get; set; }
        #endregion

        #region Methods
        public LicenseInfoChangeHistoryDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ChangeHistoryTable);
            return this;
        }

        public LicenseInfoChangeHistoryDlg VerifyChangeHistoryData(int rowindex, int columnindex, string verificationtext)
        {
            string changeHistory = ChangeHistoryTable.PerformTableAction(rowindex, columnindex, TableAction.GetText).Message.Clean();
            Support.AreEqual(changeHistory, verificationtext);
            return this;
        }
        #endregion
    }
}
