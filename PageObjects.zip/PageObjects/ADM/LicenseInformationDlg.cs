using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
	public class LicenseInformationDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtID")]
		public IWebElement ID { get; set; }

		[FindsBy(How = How.Id, Using = "chkNMLS")]
		public IWebElement NMLS { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "comboCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "comboStateLicenseType")]
		public IWebElement StateLicenseType { get; set; }

		[FindsBy(How = How.Id, Using = "comboCoLicenseType")]
		public IWebElement CoLicenseType { get; set; }

		#endregion
        public LicenseInformationDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? ID);

            return this;
        }

        public string CreateNMLS(string licID = null)
        {
            this.WaitForScreenToLoad();
            string licenseID = licID ?? Support.RandomNumber(10000000).ToString();
            this.ID.FASetText(licenseID);
            this.NMLS.FASetCheckbox(true);
            FastDriver.DialogBottomFrame.ClickDone();
            return  licenseID;
        }
        //
        public string CreateNewLicense(string State, string StateLicenseType,string County="", string CoLicenseType="", string id = null)
        {
            string ID = "";
            string RanNum = Guid.NewGuid().GetHashCode().ToString();
            try
            {
                for (int i = 0; i < 3; i++)
                {
                    this.WaitForScreenToLoad();
                    this.ID.FASetText(id ?? RanNum.ToString());
                    if (StateLicenseType == "NMLS")
                        this.NMLS.FASetCheckbox(true);
                    else
                    {

                        this.State.FASelectItem(State);
                        this.StateLicenseType.FASelectItem(StateLicenseType);
                        if (!string.IsNullOrEmpty(County))
                        {
                            this.County.FASelectItem(County);
                        }
                        if (!string.IsNullOrEmpty(CoLicenseType))
                        {
                            this.CoLicenseType.FASelectItem(CoLicenseType);
                        }
                    }
                    ID = this.ID.FAGetValue();
                    FastDriver.DialogBottomFrame.ClickDone();
                    if(FastDriver.DialogBottomFrame.btnDone.IsVisible())
                        FastDriver.DialogBottomFrame.ClickDone();
                    string Message = FastDriver.WebDriver.HandleDialogMessage();
                    if (Message.Contains("No dialog present"))
                    {
                        break;
                    }
                }
                return ID;
            }
            catch(Exception)
            {
                return ID;
            }


        }

        public string CreateLicense(string staTe, string LicenseType, string counTy = null, string coLicense = null)
        {
            WaitForScreenToLoad();
            string license = Support.RandomString("AZAZAZ");
            ID.FASetText(license);
            State.FASelectItem(staTe);
            StateLicenseType.FASelectItemBySendingKeys(LicenseType);
            County.FASelectItem(counTy);
            CoLicenseType.FASelectItem(coLicense);
            return license;
        }

        public string EditLicense(bool isNMLS, string licenseID = null, string state = null, string county = null, string licenseType = null, string coLicenseType = null)
        {
            WaitForScreenToLoad();
            string id = licenseID ?? Support.RandomNumber(10000000).ToString();
            ID.FASetText(id);
            NMLS.FASetCheckbox(isNMLS);
            if (!isNMLS)
            {
                State.FASelectItem(state);
                StateLicenseType.FASelectItemBySendingKeys(licenseType);
                County.FASelectItem(county);
                CoLicenseType.FASelectItem(coLicenseType);
            }

            return id;
        }

    }
	public class TabFrameBottomDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement CancelQ { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
