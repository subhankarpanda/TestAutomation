﻿using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class LicenseInformationStatusDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "btnDeactivate")]
        public IWebElement Activate { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeactivate")]
        public IWebElement DeActivate { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblCurrentStatus")]
        public IWebElement CurrentStatus { get; set; }
        #endregion

        #region
        public LicenseInformationStatusDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? CurrentStatus);
            return this;
        }

        public LicenseInformationStatusDlg ChangeStatus()
        {
            if (CurrentStatus.FAGetText() == "Inactive")
            {

                WaitForScreenToLoad(element: Activate);
                Activate.FAClick();
            }
            else
            {
                WaitForScreenToLoad(element: DeActivate);
                DeActivate.FAClick();
            }
            return this;
        }
        #endregion
    }
}
