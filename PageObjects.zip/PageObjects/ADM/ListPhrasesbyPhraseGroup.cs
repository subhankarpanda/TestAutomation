using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ListPhrasesbyPhraseGroup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "NameDescTypeTop MarginLeft MarginRight MarginBottom MarginFont NameFont SizeStatus")]
		public IWebElement ListPhrasesbyPhraseGroupPhraseGroupInformationTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "NameDescTypeTop MarginLeft MarginRight MarginBottom MarginFont NameFont SizeStatus")]
		public IWebElement ListPhrasesbyPhraseGroupPhraseGroupInformationTable1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "NameDescTop MarginLeft MarginRight MarginFont NameFont SizeEditableLink to Previous PhrasesKeep Lines TogetherStatus")]
		public IWebElement ListPhrasesbyPhraseGroupPhraseInformationTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "NameDescTop MarginLeft MarginRight MarginFont NameFont SizeEditableLink to Previous PhrasesKeep Lines TogetherStatus")]
		public IWebElement ListPhrasesbyPhraseGroupPhraseInformationTable1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Data Element NameData Element DescIndexReq (Y/N)FormatPictureCaseAlignment")]
		public IWebElement ListPhrasesbyPhraseGroupDataElementTable { get; set; }

		#endregion

	}
}
