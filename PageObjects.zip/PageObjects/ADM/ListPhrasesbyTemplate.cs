using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ListPhrasesbyTemplate : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//img[@src='../images/eagle.jpg']")]
		public IWebElement EagleImage { get; set; }

		#endregion

	}
}
