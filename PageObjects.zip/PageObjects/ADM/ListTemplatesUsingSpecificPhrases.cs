using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ListTemplatesUsingSpecificPhrases : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'eagle.jpg')]")]
		public IWebElement smsfastimageseaglejpg { get; set; }

		#endregion

        #region Useful Methods
        public ListTemplatesUsingSpecificPhrases WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("List Templates Using Specific Phrases");
            this.WaitCreation(smsfastimageseaglejpg);
            return this;
        }
        #endregion

    }
}
