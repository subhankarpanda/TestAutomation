using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ListTemplatesbyTemplateType : PageObject
	{
		#region WebElements

		//[FindsBy(How = How.LinkText, Using = "Template TypeTemplate Type DescrTemplate NameTemplate DescStatus")]

        [FindsBy(How = How.XPath, Using = "//div[@class='cCGridView']/table[@class='GVt']")]
		public IWebElement ListTemplatesbyTemplateTypeTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@src='../images/eagle.jpg']")]
        public IWebElement EagleImage { get; set; }

		#endregion

        public ListTemplatesbyTemplateType WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? EagleImage);
            return this;
        }
	}
}
