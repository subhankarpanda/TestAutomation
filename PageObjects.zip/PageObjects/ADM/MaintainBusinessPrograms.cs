using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class MaintainBusinessPrograms : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		#endregion

	}
}
