﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace FASTSelenium.PageObjects.ADM
{
    public class MaintainCorporateBusinessProgram : PageObject
    {
        #region IWebElements

        [FindsBy(How = How.Id, Using = "cmdAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "GridBusinessProgramName_GridBusinessProgramName")]
        public IWebElement BusinessProgramTable { get; set; }

        [FindsBy(How = How.Id, Using = "GridBusinessProgramName_0_txtFindNowBPName")]
        public IWebElement BusinessProgramName1 { get; set; }

        [FindsBy(How = How.Id, Using = "GridBusinessProgramName_0_lblFindNowBPName")]
        public IWebElement BusinessProgramNamePane1 { get; set; }

        #endregion

        public MaintainCorporateBusinessProgram WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Add);

            return this;
        }

        public void VerifyTableOrder()
        {
            List<string> sortedList = new List<string>();
            List<string> tempList = new List<string>();
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                sortedList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(1).FAGetText());
            }

            //Sorting the List
            sortedList.Sort();

            //System list
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                tempList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(1).FAGetText());
            }

            //Verify whether the elements are sorted
            for (int i = 0; i < sortedList.Count; i++)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(sortedList.ElementAt(i), tempList.ElementAt(i));
            }
            
        }

        public MaintainCorporateBusinessProgram AddBusProgram(string busProgramName)
        {
            Add.FAClick();
            Thread.Sleep(1000);
            AutoIt.AutoItX.Send(busProgramName);
            AutoIt.AutoItX.Send("^S");

            return this;
        }

    }
}
