using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ManageWorkQueueUsers : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtLoginName")]
		public IWebElement UserID { get; set; }

		[FindsBy(How = How.Id, Using = "btnSearch")]
		public IWebElement SearchNow { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstName")]
		public IWebElement FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "txtLastName")]
		public IWebElement LastName { get; set; }

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelOffice")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "WorkQUsersGrid_WorkQUsersGrid")]
		public IWebElement UserSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddRemove")]
		public IWebElement AddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "WorkQSummaryGrid_WorkQSummaryGrid")]
		public IWebElement QueueSummaryTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Select?")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.LinkText, Using = "Skip Allowed?")]
		public IWebElement SkipAllowed { get; set; }

		[FindsBy(How = How.LinkText, Using = "Work Queue Supervisor?")]
		public IWebElement WorkQueueSupervisor { get; set; }

		[FindsBy(How = How.LinkText, Using = "Default?")]
		public IWebElement Default { get; set; }

		[FindsBy(How = How.LinkText, Using = "Queue Name")]
		public IWebElement QueueName { get; set; }

		[FindsBy(How = How.LinkText, Using = "Owning Region")]
		public IWebElement OwningRegion { get; set; }

		[FindsBy(How = How.LinkText, Using = "Owning Office")]
		public IWebElement OwningOffice { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@parentfafcontrol='WorkQPanel']/tbody/tr/td/table")]
        public IWebElement AssignedQueuesTableHeader { get; set; }

        #endregion



        public ManageWorkQueueUsers WaitForScreenToLoad(IWebElement element = null)
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? UserID);
            }
            catch (Exception e)
            {
            this.SwitchToContentFrame();
                this.WaitCreation(element ?? UserID);
            }
            return this;
        }

        public ManageWorkQueueUsers SearchForUsers(string userID = null, string firstName = null, string lastName = null, string region = null, string offices = null)
        {
            WaitForScreenToLoad();
            UserID.FASetText(userID);
            FirstName.FASetText(firstName);
            LastName.FASetText(lastName);
            Region.FASelectItem(region);
            Office.FASelectItem(offices);
            SearchNow.FAClick();
            return this;
        }
    }
}
