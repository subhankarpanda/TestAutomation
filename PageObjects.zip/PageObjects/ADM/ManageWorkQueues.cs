using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ManageWorkQueues : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "FAFSelRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelOffice")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }
        

        //TODO: ADD FindsByAttribute
        public IWebElement NewWorkQ { get; set; }

		[FindsBy(How = How.Id, Using = "WorkQSummaryGrid_WorkQSummaryGrid")]
		public IWebElement WorkQSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddRemove")]
		public IWebElement AddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "WorkQUsersGrid_WorkQUsersGrid")]
		public IWebElement UsersTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnRefresh")]
		public IWebElement Refresh { get; set; }

		[FindsBy(How = How.LinkText, Using = "Queue Name")]
		public IWebElement QueueName { get; set; }

		[FindsBy(How = How.LinkText, Using = "Type")]
		public IWebElement Type { get; set; }

		[FindsBy(How = How.LinkText, Using = "Queue Info")]
		public IWebElement QueueInfo { get; set; }

		[FindsBy(How = How.LinkText, Using = "Queue Server")]
		public IWebElement QueueServer { get; set; }

		[FindsBy(How = How.LinkText, Using = "Queue Folder")]
		public IWebElement QueueFolder { get; set; }

		[FindsBy(How = How.LinkText, Using = "Status")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.LinkText, Using = "De-Activated")]
		public IWebElement De_Activated { get; set; }

		[FindsBy(How = How.LinkText, Using = "Select?")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.LinkText, Using = "Skip Allowed?")]
		public IWebElement SkipAllowed { get; set; }

		[FindsBy(How = How.LinkText, Using = "Work Queue Supervisor?")]
		public IWebElement WorkQueueSupervisor { get; set; }

		[FindsBy(How = How.LinkText, Using = "Default")]
		public IWebElement Default { get; set; }

		[FindsBy(How = How.LinkText, Using = "User Name")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.LinkText, Using = "User Region")]
		public IWebElement UserRegion { get; set; }

		[FindsBy(How = How.LinkText, Using = "User Home Office")]
		public IWebElement UserHomeOffice { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@parentfafcontrol='WQUsersPanel']/tbody/tr/td/table")]
        public IWebElement AssignedUsersTableHeader { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@parentfafcontrol='WorkQPanel']/tbody/tr/td/table")]
        public IWebElement WorkQueuesTableHeader { get; set; }

        #endregion

        public ManageWorkQueues WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? WorkQSummaryTable);
            return this;
        }
    }
}
