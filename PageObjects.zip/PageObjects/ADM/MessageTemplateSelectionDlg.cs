using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class MessageTemplateSelectionDlg : PageObject
    {
        public string WindowTitle { get { return "Message Template Selection"; } }

        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "txtTemplateName")]
        public IWebElement TemplateName { get; set; }

        [FindsBy(How = How.Id, Using = "txtDesc")]
        public IWebElement TemplateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "cboStatus")]
        public IWebElement TemplateStatus { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSearchResults")]
        public IWebElement SearchResults { get; set; }

        #endregion

        public MessageTemplateSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(WindowTitle, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? TemplateName);
            return this;
        }
        //
        public bool SelectMessageTemplate(string MessageTemplate)
        {
            FastDriver.MessageTemplateSelectionDlg.WaitForScreenToLoad();
            FastDriver.MessageTemplateSelectionDlg.FindNow.FAClick();
            if (FastDriver.MessageTemplateSelectionDlg.SearchResults.FAGetText().Contains(MessageTemplate))
            {
                FastDriver.MessageTemplateSelectionDlg.SearchResults.PerformTableAction(1, MessageTemplate, 1, TableAction.Click);
                FastDriver.MessageTemplateSelectionDlg.Select.FAClick();
                Thread.Sleep(3000);
                return true;
            }
            return false;

        }

    }
}
