using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class MortgageProductsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdMortProdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_0_drpdwnMorProd")]
		public IWebElement MortgageProduct1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_0_drpdwnLoanType")]
		public IWebElement LoanType1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_0_chkBoxActive")]
		public IWebElement Active1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_1_drpdwnMorProd")]
		public IWebElement MortgageProduct2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_1_drpdwnLoanType")]
		public IWebElement LoanType2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_1_chkBoxActive")]
		public IWebElement Active2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_2_drpdwnMorProd")]
		public IWebElement MortgageProduct3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_2_drpdwnLoanType")]
		public IWebElement LoanType3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_2_chkBoxActive")]
		public IWebElement Active3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_3_drpdwnMorProd")]
		public IWebElement MortgageProduct4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_3_drpdwnLoanType")]
		public IWebElement LoanType4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_3_chkBoxActive")]
		public IWebElement Active4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_4_drpdwnMorProd")]
		public IWebElement MortgageProduct5 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_4_drpdwnLoanType")]
		public IWebElement LoanType5 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridMortLoanType_4_chkBoxActive")]
		public IWebElement Active5 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridMortLoanType")]
        public IWebElement MortgageProductTable { get; set; }

		#endregion

        #region - Useful Methods
        public MortgageProductsDlg WaitForScreenToLoad(string windowName = "Mortgage Products")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(New, 5);
            return this;
        }

        #endregion
    }
}
