using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using SeleniumInternalHelpersSupportLibrary;
using AutoIt;
using System.Diagnostics;
using FASTSelenium.ImageRecognition;

namespace FASTSelenium.PageObjects.ADM
{
	public class NextGenDocumentPreparation : PageObject
	{
		#region WebElements

        // Control Main Tab in ADM 

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Dashboard']")]
		public IWebElement DashboardTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Templates']")]
        public IWebElement TemplatesTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Phrases']")]
        public IWebElement PhrasesTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Phrase Search']")]
        public IWebElement PhraseSearchTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Copy/Move Phrases']")]
        public IWebElement CopyMovePhraseTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Forms']")]
        public IWebElement FormsTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='admindashboardtabs']//a[text()='Reports']")]
        public IWebElement ReportsTab { get; set; }

        // Dashboar TAB control 
       
        //Table column 

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//a[text()='Revised By']")]
        public IWebElement RevisedByColumn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//th//a[text()='Created Date']")]
        public IWebElement CreatedDateColumn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//th//a[text()='Template Type']")]
        public IWebElement TemplateTypecolumn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//th//a[text()='Template Description']")]
        public IWebElement TemplateDescriptionColumn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//th//a[text()='Template Name']")]
        public IWebElement TemplateNameColumn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//th//a[text()='Region']")]
        public IWebElement RegionCoulmn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//div[@class ='SortImgBlock']")]
        public IWebElement SortRivsedBy { get; set; }


        [FindsBy(How = How.Id, Using = "LastUsedByUserName")]
        public IWebElement FormatUser { get; set; }

        [FindsBy(How = How.XPath, Using = "//tbody/tr/td/label[@id= 'Date']")]
        public IWebElement DateDash { get; set; }

        [FindsBy(How = How.Id, Using = "RegionID")]
        public IWebElement RegionTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id'Template_grid]'//div//a//span[@class='GridPageNumber']")]
        public IWebElement PaginNext { get; set; }

        [FindsBy(How = How.Id, Using = "Name")]
        public IWebElement Descrpdash { get; set; }

        [FindsBy(How = How.Id, Using = "Template_grid")]
        public IWebElement DashTable { get; set; }



        //Region(s) Drop-Donw list 

        [FindsBy(How = How.Id, Using = "ddcl-ddTemplateRegions1")]
        public IWebElement RegionDropdonw { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@value='196']")]
        public IWebElement RegionDocPrepNextGen { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@value='6210']")]
        public IWebElement RegionNationalTiCaliforniaDivision { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@value='0']")]
        public IWebElement AllRegionDash { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@value='12837']")]
        public IWebElement RegionDocGenDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']")]
        public IWebElement AllregionChecked { get; set; }



        [FindsBy(How = How.XPath, Using = "//div[@id='divPhraseMaint']/ul/li/a[text()='Create New PhraseGroup']")]
        public IWebElement CreateNewPhraseGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divPhraseMaint']/ul/li[2]/a[text()='Edit PhraseGroup']")]
        public IWebElement EditPhraseGroup { get; set; }

       [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatesList']//tbody")]
        public IWebElement TemplateTableDash { get; set; }

       [FindsBy(How = How.XPath, Using = "//div[@id='divTemplatePhrasesContent']//div[@id='tblheader']")]
       public IWebElement PhrasesTAbleContent { get; set; }

        [FindsBy(How = How.Id, Using = "btnRefreshSearchByDaysResult")]
        public IWebElement TemplateTableRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "noOfDays")]
        public IWebElement NumberOfDays { get; set; }

        [FindsBy(How = How.Id, Using = "spanManualPhrase")]
        public IWebElement ManuallyIconPhrase { get; set; }

        //Right Click Context elements
        [FindsBy(How = How.XPath, Using = "//ul[@id='TemplateContextMenu']/li[@class='copy']/a")]
        public IWebElement CopyTemplate { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul[@id='TemplateContextMenu']/li[@class='delete']/a")]
        public IWebElement DeleteTemplate { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#insert']")]
        public IWebElement PhrasesInsert { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#above']")]
        public IWebElement PhrasesAbovetContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#below']")]
        public IWebElement PhraseBelowContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#aboveAddPhrase']")]
        public IWebElement AbovePhraseContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#belowAddPhrase']")]
        public IWebElement BelowPhraseContext { get; set; }
       

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseListContextMenu']")]
        public IWebElement PhraseMenu { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#requirePhrase']")]
        public IWebElement PhrasesRequired { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#unrequirePhrase']")]
        public IWebElement UnRequire { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#movePhrase']")]
        public IWebElement MovePhrasescontext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul/li/a[@href='#PGroupProperties']")]
        public IWebElement PropertiesPhrase { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul/li/a[@href='#editPhrase']")]
        public IWebElement EditPhrase { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul/li/a[@href='#deletePhrase']")]
        public IWebElement RemovePhrase { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul/li/a[@href='#requirePhrase']")]
        public IWebElement RequiredPhrase { get; set; }


        // Templates tab > Template Search tab      

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplates']//a[text()='Template Search']")]
        public IWebElement TemplateSearchTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateSearch']//span[@class='ui-dropdownchecklist-text ddclTextBox200 lineHeight15']")]
        public IWebElement TemplateSearchRegions { get; set; }

        [FindsBy(How = How.Id, Using = "ddTemplTypes")]
        public IWebElement TemplateType { get; set; }

        [FindsBy(How = How.Id, Using = "spanRegion")]
        public IWebElement Region { get; set; }

        [FindsBy(How = How.XPath, Using = "//div//span[@id='spanRegion']//input[@type='checkbox'][@value='6210']")]
        public IWebElement NortRegDivi { get; set; }

        [FindsBy(How = How.XPath, Using = "//div//span[@id='spanRegion']//input[@type='checkbox'][@value='12837']")]
        public IWebElement NextGenReg { get; set; }

        [FindsBy(How = How.Id, Using = "ddcl-ddTemplateRegions-i0")]
        public IWebElement AllRegions { get; set; }

        [FindsBy(How = How.Id, Using = "txtTemplateName")]
        public IWebElement TemplateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ddTemplStatus")]
        public IWebElement TemplateStatus { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateSearch")]
        public IWebElement TemplateSearch { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateNewSearch")]
        public IWebElement TemplateNewSearch { get; set; }


        [FindsBy(How = How.Id, Using = "gridTemplateResultsInnerGrid")]
        public IWebElement TemplateResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "spanManualTemplate")]
        public IWebElement ManuallyCreatedIcon { get; set; }

        [FindsBy(How = How.Id, Using = "spanManualPhrase")]
        public IWebElement ManuallyCreatedIconPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "templateDescr")]
        public IWebElement TemplateDescr { get; set; }

        [FindsBy(How = How.Id, Using = "templateKeys")]
        public IWebElement TemplateKeys { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='TemplateContextMenu']//a[text()='View/Edit Template']")]
        public IWebElement ViewEditTemplate { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseContextMenu']//li/a[text()='Properties']")]
        public IWebElement EditPhrasetable { get; set; }

        [FindsBy(How = How.Id, Using = "gridTemplateResultsdivInnerGrid")]
        public IWebElement TemplateSearchResultTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='TemplateContextMenu']//li/a[@href='#EditTemplate']")]
        public IWebElement ViewEditTemplateTemplsearch { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='TemplateContextMenu']//li/a[@href='#CopyTemplate']")]
        public IWebElement CopyTemplateRes { get; set; }


        [FindsBy(How = How.Id, Using = "TemplateIDtext")]
        public IWebElement VersioningTemplate { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseIDtext")]
        public IWebElement PhrasePropId { get; set; } 

        // Create New Template tab
        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplates']//a[text()='Create New Template']")]
        public IWebElement CreateNewTemplateTab { get; set; }
        
        // Templates tab > Create New Template tab >  Properties tab
        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateEditTabs']//a[text()='Properties']")]
        public IWebElement PropertiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "templateName")]
        public IWebElement TemplateName { get; set; }

        [FindsBy(How = How.Id, Using = "FileRegionID")]
        public IWebElement TemplateRegion{ get; set; }

        [FindsBy(How = How.Id, Using = "PreviewFileNumber")]
        public IWebElement TemplatePreview { get; set; }

        [FindsBy(How = How.Id, Using = "Template_DocTypeCdID")]
        public IWebElement TemplateType_Properties { get; set; }

        [FindsBy(How = How.Id, Using = "templateDescr")]
        public IWebElement TemplateDescription_Properties { get; set; }

        [FindsBy(How = How.Id, Using = "chkUndrCnstrn")]
        public IWebElement UnderConstruction { get; set; }

        [FindsBy(How = How.Id, Using = "btnPreview")]
        public IWebElement SeachtemplateButton { get; set; }

        [FindsBy(How = How.Id, Using = "Template_FormatInformation_FontName")]
        public IWebElement Template_Information_FontName { get; set; }


        [FindsBy(How = How.Id, Using = "Template_FormatInformation_FontSize")]
        public IWebElement Template_Information_FontSize { get; set; }


        [FindsBy(How = How.Id, Using = "Template_FormatInformation_TopMargin")]
        public IWebElement Template_Information_TopMargin { get; set; }

        [FindsBy(How = How.Id, Using = "Template_FormatInformation_LeftMargin")]
        public IWebElement Template_Information_LeftMargin { get; set; }

        [FindsBy(How = How.Id, Using = "Template_FormatInformation_RightMargin")]
        public IWebElement Template_Information_RightMargin { get; set; }


        [FindsBy(How = How.Id, Using = "Template_FormatInformation_PageType")]
        public IWebElement Template_Information_PageType { get; set; }

         [FindsBy(How = How.Id, Using = "Template_0_txtHistComments")]
        public IWebElement Template_Comment { get; set; }


        //[FindsBy(How = How.Id, Using = "Template_FormatInformation_PageType")]
        //public IWebElement Template_Information_RightMargin { get; set; }

        


        [FindsBy(How = How.Id, Using = "Template_BoolNotificationCandidateYesNo")]
        public IWebElement NotificationCandidate { get; set; }

        [FindsBy(How = How.Id, Using = "rdTempStatInAct")]
        public IWebElement Inactive { get; set; }

        [FindsBy(How = How.Id, Using = "rdTempStatAct")]
        public IWebElement Active { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateSave")]
        public IWebElement Save { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateEditTabs']//button[@value='Save']")]
        public IWebElement SavePhrase { get; set; }

        [FindsBy(How = How.Id, Using = "btnTempEditor")]
        public IWebElement Editor { get; set; }

        [FindsBy(How = How.Id, Using = "hrefTemplatePhrases")]
        public IWebElement TemplatePhrases { get; set; }


        [FindsBy(How = How.Id, Using = "ui-id-6")]
        public IWebElement TemplateProperties { get; set; }



        //Template Properties > Phrases

        [FindsBy(How = How.Id, Using = "hrefTemplateNew")]
        public IWebElement CreateNewTemplate { get; set; }

        [FindsBy(How = How.Id, Using = "tblPhraseListcontent")]
        public IWebElement TemplatePhrasesTablelist { get; set; }


        [FindsBy(How = How.Id, Using = "ddlDocPrepFormNames")]
        public IWebElement TemplatePhrasesFormName { get; set; }


        [FindsBy(How = How.Id, Using = "btnSectionBrkDone")]
        public IWebElement TemplatePhrasesSectionBrkDone { get; set; }


        [FindsBy(How = How.Id, Using = "Phrase.PhraseID")]
        public IWebElement PropertiesPhrasesVerssioning { get; set; }

        
        
        
        
        // Templates phrases list context menu
        [FindsBy(How = How.Id, Using = "PhraseListContextMenu")]
        public IWebElement PhraseListContextMenu { get; set; }

        [FindsBy(How = How.Id, Using = "above")]
        public IWebElement AboveBelowPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "belowAddPhrase")]
        public IWebElement belowAddPhrase { get; set; }
       
        // Templates tab > Create New Template tab >  Filtering tab
        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateEditTabs']//a[text()='Filtering']")]
        public IWebElement FilteringTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='myTable']//table")]
        public IWebElement FilterTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='reqTempSelCriteriaID']")]
        public IWebElement RequiredFilter { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='divTemplateEditTabs']//a[text()='Properties']")]
        //public IWebElement Templates_PropertiesTab { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divFilterGrpGrids']//td//span[@class='addnewoptionsImg imgbtnBehavior addFilter']")]
        public IWebElement AddFilterGroup { get; set; }

        [FindsBy(How = How.Id, Using = "divTempSelCriteriaDialog")]
        public IWebElement FilterSelectionDlg { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[text()='Show All Filter Groups']")]
        public IWebElement ShowAllFitlers { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[text()='Hide All Filter Groups']")]
        public IWebElement HideAllFitlers { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tdCopy_2']")]
        public IWebElement CopyGroupFilter { get; set; }

        [FindsBy(How = How.Id, Using = "chckGrp_3")]
        public IWebElement CheckBoxFilterTemp { get; set; }



        [FindsBy(How = How.XPath, Using = "//td[@id='tdfg_2_7']/span[@id='span_Grp2_PRODUCTTYPECDID']")]
        public IWebElement SelectedProducts { get; set; }

      
        // Filter Selection Dlg

        [FindsBy(How = How.XPath, Using = "//span[@id='spanState']")]
        public IWebElement GeographicFilterState { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='spanCounty']")]
        public IWebElement GeographicFilterCounty { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='spanCity']")]
        public IWebElement GeographicFilterCity { get; set; }
        

        [FindsBy(How = How.Id, Using = "btnState")]
        public IWebElement StateAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "btnCounty")]
        public IWebElement CountyAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "btnCity")]
        public IWebElement CityAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "chckTitle")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "chckEscrow")]
        public IWebElement Escrow { get; set; }

        [FindsBy(How = How.Id, Using = "chckSubEscrow")]
        public IWebElement SubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedPropertyTypeIds")]
        public IWebElement PropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "chckSrvcAll")]
        public IWebElement ServiceTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkUnderWriter")]
        public IWebElement UnderwriterSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkOffice")]
        public IWebElement OwningOfcSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkProp")]
        public IWebElement PropertyTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkProd")]
        public IWebElement ProductTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkBusSeg")]
        public IWebElement BusinessSegmentSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkTrans")]
        public IWebElement TransactionTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkProg")]
        public IWebElement ProgramTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkSearch")]
        public IWebElement SearchTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedUnderwriterIds")]
        public IWebElement Underwriter { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedRegionIds")]
        public IWebElement SelectOwningRegion { get; set; }

        [FindsBy(How = How.Id, Using = "chkRegions")]
        public IWebElement OwningRegionSelectAll { get; set; }        

        [FindsBy(How = How.Id, Using = "SelectedOfficeIds")]
        public IWebElement OwningOffice { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedProdIds")]
        public IWebElement Products { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedBusSegIds")]
        public IWebElement BusinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedTransTypeIds")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedProgTypeIds")]
        public IWebElement ProgramType { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedSearchTypeIds")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "SelectedRoleTypeId")]
        public IWebElement RoleType { get; set; }


        [FindsBy(How = How.Id, Using = "BusCode")]
        public IWebElement NameIdCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindName")]
        public IWebElement FindName { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindCode")]
        public IWebElement FindCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindCode")]
        public IWebElement Search { get; set; }

        [FindsBy(How = How.Id, Using = "btnSearch")]
        public IWebElement Search1 { get; set; }


        

        [FindsBy(How = How.Id, Using = "SelectedBusIds")]
        public IWebElement BusinessParty { get; set; }

         [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement DeleteBusinessParty { get; set; }

        


        [FindsBy(How = How.XPath, Using = "//div/span[text()='Filter Selection']/ancestor::div[2]//button/span[text()='Cancel']")]
        public IWebElement FilterSelection_Cancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Filter Selection']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement FilterSelection_Done { get; set; }


         // Templates tab > Create New Template tab || Edit Template tab >  Phrases tab
        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateNew']//li/a[text()='Phrases']")]
        public IWebElement Templates_PhrasesTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateNew']//li/a[text()='Filtering']")]
        public IWebElement Templates_FilteringTab { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divTemplateNew']//li/a[text()='Properties']")]
        public IWebElement Templates_PropertiesTab { get; set; }


        [FindsBy(How = How.Id, Using = "tblPhraseListcontent")]
        public IWebElement Templates_PhrasesTable { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseListContextMenu")]
        public IWebElement PhraseContextMenu { get; set; }

        [FindsBy(How = How.Id, Using = "above")]
        public IWebElement PhraseContextMenuAboveBelow { get; set; }

        [FindsBy(How = How.Id, Using = "aboveAddPhrase")]
        public IWebElement PhraseContextMenuAbovePhrase { get; set; }

        [FindsBy(How = How.Id, Using = "belowAddPhrase")]
        public IWebElement PhraseContextMenuBelowPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "chckGrp_2")]
        public IWebElement FilterCheckGrp { get; set; }

        //Sushitha



        [FindsBy(How = How.Id, Using = "phraseCondTbl")]
        public IWebElement PhraseConditionTable { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseConditions")]
        public IWebElement ViewphraseConditionTable { get; set; }

        [FindsBy(How = How.Id, Using = "Span_Expand")]
        public IWebElement ExpandIcon { get; set; }

        [FindsBy(How = How.Id, Using = "span_Grp2_OWNINGREGN")]
        public IWebElement GrougTableOwningRegion { get; set; }

        [FindsBy(How = How.Id, Using = "span_Grp2_UNDERWRITER")]
        public IWebElement GrougTableunderwriter { get; set; }

         [FindsBy(How = How.Id, Using = "span_Grp2_PROGRAMTYPE")]
        public IWebElement GrougTableprogramtype { get; set; }

         [FindsBy(How = How.Id, Using = "phraseConditionList")]
         public IWebElement PhraseConditionListTable { get; set; }

         [FindsBy(How = How.Id, Using = "rdAND")]
         public IWebElement ViewphraseConditionAND { get; set; }

         [FindsBy(How = How.Id, Using = "rdOR")]
         public IWebElement ViewphraseConditionOR { get; set; }

        // Phrases tab > Copy/Move Phrases tab

        [FindsBy(How = How.Id, Using = "rbMove")]
        public IWebElement MovePhrases { get; set; }

        [FindsBy(How = How.Id, Using = "rbCopy")]
        public IWebElement CopyPhrases { get; set; }

        [FindsBy(How = How.Id, Using = "ddBlkPhrCpyFromRegion")]
        public IWebElement FirstFormRegion { get; set; }

        [FindsBy(How = How.Id, Using = "ddBBlkPhrCpyFromGroup")]
        public IWebElement FirstFormGroup { get; set; }

        [FindsBy(How = How.Id, Using = "txtBlkPhrCpyFromPhrase")]
        public IWebElement FirstFormPhrase { get; set; }
         // Added by Rishi

        [FindsBy(How = How.Id, Using = "btnCpyPhrCopy")]
        public IWebElement CopyPhrasesBtn { get; set; }

        [FindsBy(How = How.Id, Using = "gridBlkPhrCpyValidations")]
        public IWebElement CopyPhrasesValidatuionErrorDiv { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divBulkCopyPhrasesValidations']/table[@id='gridBlkPhrCpyValidations']//td/label")]
        public IWebElement CopyPhrasesValidationDivMsg { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/span.select[@id='ddBlkPhrCpyFromRegion']")]
        public IWebElement CopyMoveFirstFormRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/span/select[@id='ddBBlkPhrCpyFromGroup']")]
        public IWebElement CopyMoveFirstFormGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/div/input[@id='txtBlkPhrCpyFromPhrase']")]
        public IWebElement CopyMoveFirstFormPhraseCode { get; set; }
      
        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/div/input[@id='btnphraseSelect']")]
        public IWebElement CopyMoveFirstFormPhraseCodeSelect { get; set; }
       

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/input[@id='hdnBlkPhrCpyFromPhraseDescr']")]
        public IWebElement CopyMoveFirstFormPhraseDescription { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/span/select[@id='ddBlkPhrCpyToRegion']")]
        public IWebElement CopyMoveFirsToRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/span/select[@id='ddBlkPhrCpyToGroup']")]
        public IWebElement CopyMoveFirsToGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select a Phrase']/ancestor::div[2]//table[@id='gridPhraseSelection']//input[@id='chkselPhrases']")]
        public IWebElement CopyMoveSelectAPhrase { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select a Phrase']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement CopyMoveSelectAPhrase_Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select a Phrase']/ancestor::div[2]//button/span[text()='Cancel']")]
        public IWebElement CopyMoveSelectAPhrase_Cancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/input[@id='txtBlkPhrCpyToPhrase']")]
        public IWebElement CopyMoveFirsToPhraseName { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='gridBlkPhrCpy']//td/input[@id='txtBlkPhrCpyToPhraseDescr']")]
        public IWebElement CopyMoveFirsToPhraseDescrp { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseKeyword")]
        public IWebElement PhraseSearch_PhraseKeyword { get; set; }

        [FindsBy(How = How.Id, Using = "gridPhrasesInnerGrid")]
        public IWebElement PhraseGR_PhraseListTable { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseContextMenu")]
        public IWebElement PhraseGR_PhraseContextMenu { get; set; }

       

        [FindsBy(How = How.Id, Using = "Phrase_0_txtHistComments")]
        public IWebElement PhraseEditRvHisTab_commenttxt { get; set; }

        // Phrases Tab (Phrase Maintenance)
        [FindsBy(How = How.Id, Using = "divPhraseMaint")]
        public IWebElement PhraseMaintenace { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divPhraseMaint']/ul/li/a[text()='Phrase Search']")]
        public IWebElement PhraseSearch { get; set; }        

        [FindsBy(How = How.XPath, Using = "//div[@id='divPhraseMaint']/ul/li/a[text()='Phrase Properties']")]
        public IWebElement PhraseProperties { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divPhraseMaint']/ul/li/a[text()='Copy/Move Phrases']")]
        public IWebElement CopyMovePhrases { get; set; }

        // Phrases Tab > Phrase Search 
        [FindsBy(How = How.Id, Using = "ddcl-ddlPhraseTypes")]
        public IWebElement PhraseSearch_PhraseType { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddlPhraseTypes-ddw']/div")]
        public IWebElement PhraseSearch_PhraseTypeList { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@value='179']")]
        public IWebElement ExcrowFilterPhrase { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@value='180']")]
        public IWebElement MiscellaneousPhrase { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ddcl-listPanel2']//input[@type='checkbox'][@id='ddcl-ddlPhraseTypes-i0']")]
        public IWebElement SelectAllPrase { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseGroupDescr")]
        public IWebElement PhraseSearch_PhraseGroupDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseDescr")]
        public IWebElement PhraseSearch_PhraseDescription { get; set; }

        [FindsBy(How = How.Id, Using = "btnPGrpSearch")]
        public IWebElement PhraseSearch_Search { get; set; }

        [FindsBy(How = How.Id, Using = "gridPhraseResultsdivInnerGrid")]
        public IWebElement PhrasesResultTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseGroupPhraseCode")]
        public IWebElement PhraseSearch_PhraseGroupPhraseCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnPGrpNewSearch")]
        public IWebElement PhraseSearch_NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "gridPhraseResultsInnerGrid")]
        public IWebElement PhraseSearch_SearchResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseGroupContextMenu")]
        public IWebElement PhraseSearch_SearchResults_ContextMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseGroupContextMenu']/li/a[text()='Add Phrase']")]
        public IWebElement PhraseSearch_SearchResults_AddPhrase { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseGroupContextMenu']/li/a[text()='Properties']")]
        public IWebElement PhraseSearch_SearchResults_Properties { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseGroupContextMenu']/li/a[text()='Delete']")]
        public IWebElement PhraseSearch_SearchResults_Delete { get; set; }


        // Phrases Tab > Create New Phrases Tab > Properties  
        // Phrases Tab > Edit PhraseGroup --- same map
        [FindsBy(How = How.Id, Using = "ui-id-7")]
        public IWebElement CreateNewPhrases { get; set; }

        [FindsBy(How = How.Id, Using = "phGpTbPhGrpName")]
        public IWebElement GroupName { get; set; }

        [FindsBy(How = How.Id, Using = "phGpTbPhGrpDescr")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "btnPhrSave")]
        public IWebElement SaveButtom { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#gridHistoryInnerGrid, #gridHistory")]
        public IWebElement PhraseGroupRevisionTable { get; set; }

         [FindsBy(How = How.Id, Using = "Phrase_0_txtHistComments")]
        public IWebElement FirstComment { get; set; }

        

        [FindsBy(How = How.CssSelector, Using = "#gridPhrases table:first-child")]
        public IWebElement PhrasesHeaderTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseHeaderContextMenu']/li/a[text()='Add New Phrase']")]
        public IWebElement AddNewPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "Phrase_ObjectCd")]
        public IWebElement NamePhrasesProperties { get; set; }

        [FindsBy(How = How.Id, Using = "Phrase_Name")]
        public IWebElement DesPhrasesName { get; set; }

        [FindsBy(How = How.Id, Using = "btnPhraseEditor")]
        public IWebElement PhraseViewButtom{ get; set; }

        [FindsBy(How = How.Id, Using = "gridPhrasesdivInnerGrid")]
        public IWebElement PhrasesTable{ get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tdEdit_2']")]      
        public IWebElement SuggestedFilter { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tdDel_2']")]
        public IWebElement DeleteFilter { get; set; }



        [FindsBy(How = How.XPath, Using = "//table[@id='myTable']//tbody/tr/td/table/tbody/tr/td/td/div/table")]
        public IWebElement GroupFilter1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='myTable']//table/tbody/td[@class= 'tdfilterGroup'")]
        public IWebElement ValidateState { get; set; }


        [FindsBy(How = How.CssSelector, Using = "rootTable")]
        public IWebElement ScreenEditPhrases { get; set; }

        [FindsBy(How = How.CssSelector, Using = "closeButton")]
        public IWebElement CloseBottom { get; set; }

        [FindsBy(How = How.CssSelector, Using = "editorControlObject")]
        public IWebElement MenuBarcontrol { get; set; }

        [FindsBy(How = How.Id, Using = "phGpTbPhGrpType")]
        public IWebElement TypeSelect { get; set; }

        [FindsBy(How = How.Id, Using = "ui-id-2")]
        public IWebElement TemplateTab { get; set; }

        //Phrases Properties 

        [FindsBy(How = How.Id, Using = "btnSaveP")]
        public IWebElement SaveButtonPhraseProperties { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseListContextMenu']//li/a[@href='#editPhrase']")]
        public IWebElement PropertiesphraseContext { get; set; }

        [FindsBy(How = How.ClassName, Using = "PhraseHeader")]
        public IWebElement PhrasesTables { get; set; }




        //Forms Tab web elements     
        [FindsBy(How = How.Id, Using = "btnAddNewForm")]
        public IWebElement AddNewForm { get; set; }

        [FindsBy(How = How.Id, Using = "uploadDocument")]
        public IWebElement BrowseForm { get; set; }

        [FindsBy(How = How.Id, Using = "btnFormSearch")]
        public IWebElement SearchForm { get; set; }

        [FindsBy(How = How.Id, Using = "rdcheckedOutToStatus")]
        public IWebElement CheckedOutStatusForm { get; set; }

        [FindsBy(How = How.Id, Using = "CheckedOutStatus")]
        public IWebElement CheckedOutStatusAllForm { get; set; }

        [FindsBy(How = How.Id, Using = "retfrmcheckout")]
        public IWebElement Formcheckout { get; set; }

        [FindsBy(How = How.Id, Using = "txtCheckedOutTo")]
        public IWebElement CheckedOutToUser { get; set; }

        [FindsBy(How = How.Id, Using = "gridFormResults")]
        public IWebElement FormsTable { get; set; }

        [FindsBy(How = How.Id, Using = "ddFormStatus")]
        public IWebElement FormsStatus { get; set; }


        // added By RISHI        rdPhraseStatAct

        [FindsBy(How = How.Id, Using = "rdPhraseStatAct")]
        public IWebElement Status_Active { get; set; }

        [FindsBy(How = How.Id, Using = "chkUndrCnstrnPhrase")]
        public IWebElement UnderConstruction_Chkbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkIsEditable")]
        public IWebElement Editable_Chkbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkApplyToAllRegions")]
        public IWebElement AvailableToAllRegion_CheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement FAFErrorMessageList { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_FontName")]
        public IWebElement PhraseFont_Name { get; set; }       

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_FontSize")]
        public IWebElement PhraseFont_Size { get; set; }        

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_RightMargin")]
        public IWebElement PhraseMargin_Right { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_TopMargin")]
        public IWebElement PhraseMargin_Top { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_LeftMargin")]
        public IWebElement PhraseMargin_Left { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_JustifyTextRequired")]
        public IWebElement PhraseMarginMode_FullJustify { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_FormatInformation_KeepLinesTogether")]
        public IWebElement PhraseMarginMode_KeepLinesTog { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseFormatInfo_LinkPhrase")]
        public IWebElement PhraseMarginMode_LinkToPreviousePhrase { get; set; }

        [FindsBy(How = How.Id, Using = "ddcl-ddlPhraseRegions")]
        public IWebElement PhraseRegion { get; set; }


        [FindsBy(How = How.Id, Using = "btnPhrasePropertiesEditor")]
        public IWebElement PhraseViewDe { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[@id=ddcl-ddlPhraseRegions']/ancestor::div[1]//div[@id='ddcl-ddlPhraseRegions-i7']")]
        public IWebElement PhraseRegion_sandpoint { get; set; }


        [FindsBy(How = How.Id, Using = "gridPhraseResults")]
        public IWebElement PhrasesSearchResult { get; set; }


        [FindsBy(How = How.Id, Using = "PhraseGrpFormatInfo_FormatInformation_FontName")]
        public IWebElement PhraseGrpFont_Name { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseGrpFormatInfo_FormatInformation_FontSize")]
        public IWebElement PhraseGrpFont_Size { get; set; }


        [FindsBy(How = How.Id, Using = "PhraseGrpFormatInfo_FormatInformation_TopMargin")]
        public IWebElement PhraseGrpMargin_Top { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseGrpFormatInfo_FormatInformation_LeftMargin")]
        public IWebElement PhraseGrpMargin_Left { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseGrpFormatInfo_FormatInformation_RightMargin")]
        public IWebElement PhraseGrpMargin_Right { get; set; }


        [FindsBy(How = How.Id, Using = "gridHistory")]
        public IWebElement PhraseGrpRevisionTable { get; set; }

        [FindsBy(How = How.Id, Using = "rdPageStatInAct")]
        public IWebElement PhraseGrpeditstatus_Inactive { get; set; }

        [FindsBy(How = How.Id, Using = "rdPageStatAct")]
        public IWebElement PhraseGrpeditstatus_active { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseGrp_0_txtHistComments")]
        public IWebElement PhraseGrpeditRvHisTab_commenttxt { get; set; }

        [FindsBy(How = How.Id, Using = "divPhraseEdit")]
        public IWebElement PhrasePropertiestab { get; set; }


        [FindsBy(How = How.Id, Using = "rdPhraseStatInAct")]
        public IWebElement Status_InActive { get; set; }

        [FindsBy(How = How.Id, Using = "ddPhraseGroupStatus")]
        public IWebElement PhraseGrp_Status { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divPhraseRevisionHistory']//table[@id='gridHistory']")]
        public IWebElement PhraseRevisionTable { get; set; }
        // //ul[@id='PhraseGroupContextMenu']//li/a[@href='#DeletePhraseGroup'
        [FindsBy(How = How.XPath, Using = "//ul[@id='PhraseGroupContextMenu']//li/a[@href='#DeletePhraseGroup']")]
        public IWebElement phraseGrpsearchcontext_Delete { get; set; }

        #endregion

        #region Dynamic WebElements

        public static void MouseOver(IWebElement theElement)
        {
            Actions builder = new Actions(FastDriver.WebDriver);
            builder.MoveToElement(theElement).Build().Perform();
            
        }
      
        public void FAHoverByID(string elementID)
        {
            Actions Action = new Actions(FastDriver.WebDriver);
            IWebElement WebElement = FastDriver.WebDriver.FindElement(By.CssSelector("#" + elementID));
            Action.MoveToElement(WebElement).Perform();
        }

        //Added by Luis
        public IWebElement SelectRegionCheckbox(string regionID)
        {
            return  FastDriver.WebDriver.FindElement(By.CssSelector("#ddcl-ddTemplateRegions-ddw input[value='"+regionID+"']"));
        }

        
       
        
        
        public IWebElement AddNewPhrases() {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(5));
            return wait.Until<IWebElement>(d =>
            {
                return FastDriver.WebDriver.FindElement(By.CssSelector("#PhraseHeaderContextMenu li.addPhrase a"));
            });

        }

        #endregion


        #region Services

        public List<string> GetSelectedItemsTables()
        {
            FastDriver.StateSelectionDlg.WaitForScreenToLoad();
            int RowCount = FastDriver.StateSelectionDlg.table.GetRowCount();
            List<string> AllStates = new List<string>();
            int i = 1;
            var Checkbox = FastDriver.StateSelectionDlg.table.PerformTableAction(1, 1, TableAction.GetCell).Element.FindElements(By.XPath("//input[@type='checkbox']")); //.Element.FindElement(By.XPath("//span/input[@type='checkbox']"));
            foreach (var item in Checkbox)
            {
                if (item.Selected == true)
                {
                    AllStates.Add(FastDriver.StateSelectionDlg.table.PerformTableAction(i, 2, TableAction.GetText).Message);
                }
                i++;
            }
            AllStates.RemoveAt(0);
            return AllStates;
        }

        public NextGenDocumentPreparation WaitForScreenToLoad(IWebElement element = null)
        {   
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TemplateTableRefresh);
            return this;
        }

        public NextGenDocumentPreparation Open(IWebElement element = null)
        {
            FastDriver.LeftNavigation.Navigate<NextGenDocumentPreparation>("Home>System Maintenance>NextGen Document Preparation");
            return WaitForScreenToLoad(element);
        }

        public NextGenDocumentPreparation WaitForPhrasesTabToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? CreateNewPhrases);
            return this;
        }

        public NextGenDocumentPreparation SwitchToEditor()
       {
            this.WebDriver.SwitchTo().DefaultContent();
            this.WaitForFrameAndSwitch("fraEditor");
            return this;
        }
        
        public NextGenDocumentPreparation WaiForEditPhrases(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitForScreenToLoad (element ?? PhraseViewButtom);
            return this;
        }


        public void Regional_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateType)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            //#region Verify that if Template is present
            //Reports.TestStep = "Check if Template is present";
            //FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            //FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            ////FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));
            //FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);
            //FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            //var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            //var templateExists = templateTable.Contains(templateDescription);
            //#endregion

            //if (!templateExists)
            //{
            //#region Create new phrase group
            //Reports.TestStep = "Create new phrase group";
            //FastDriver.NextGenDocumentPreparation.Open();
            //FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
            //FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
            //FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);

            //var groupName = Support.RandomString(phraseGrp_Name);
            //FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);

            //var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));
            //FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

            //FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);
            //FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
            //FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
            //Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
            //#endregion

            //#region Add phrases
            //Reports.TestStep = "Add phrases";
            //FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
            //FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

            //var phraseName = Support.RandomString(phraseGrp_Name);
            //FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

            //var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));
            //FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

            //FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
            //FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
            //#endregion

            //#region Insert phrases
            //Reports.TestStep = "Insert phrases";
            //FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
            //FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
            //FastDriver.DocumentEditor.WaitForScreenToLoad();
            //this.InsertDataElement();

            //#endregion

            #region Create template

            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Create template
            Reports.TestStep = "Create a new template";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
            FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();

            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
            FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
            string templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));

            FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

            FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            #endregion

            #region Insert template
            Reports.TestStep = "Insert template";
            FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
            FastDriver.NextGenDocumentPreparation.Editor.FAClick();
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            Playback.Wait(2000); 
           // FastDriver.DocumentEditor.InsertRegionFormBelowAndSave(groupName + "/" + phraseName, phraseDescription);
            //FastDriver.DocumentEditor.InsertRegionFormBelowAndSave();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
            FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
            FastDriver.NextGenDocumentPreparation.Save.FAClick();
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
            #endregion

            #endregion
            //}
            //else
            //{
            //    Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            //}
        }








        public void Phrase_phraseGrp_Template_Final(string phraseGrp_Name, string phrase_Type, string templateName, string templateType)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            //#region Verify that if Template is present
            //Reports.TestStep = "Check if Template is present";
            //FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            //FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            ////FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));
            //FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);
            //FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            //var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            //var templateExists = templateTable.Contains(templateDescription);
            //#endregion

            //if (!templateExists)
            //{
                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);

                var groupName = Support.RandomString(phraseGrp_Name);
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);

                var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);
                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString(phraseGrp_Name);
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();

                #endregion

                #region Create template

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                string templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));

                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.InsertPhraseBelowAndSave(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                //FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad();
                #endregion

                #endregion
            //}
            //else
            //{
            //    Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            //}
        }


        public int GetImageCount(int rowindex, int columnindex)
        {
            int count = FastDriver.NextGenDocumentPreparation.Templates_PhrasesTable.PerformTableAction(rowindex, columnindex, TableAction.GetCell).Element.FindElements(By.TagName("IMG")).Count;
            return count;
        }








        public void Phrase_phraseGrp_Template(string phraseGrp_Name, string phrase_Type, string templateName, string templateDescription, string templateType)
        {
            #region Navigate to NextGen Document Preparation Screen
            Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
            FastDriver.NextGenDocumentPreparation.Open();
            #endregion

            #region Verify that if Template is present
            Reports.TestStep = "Check if Template is present";
            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateSearch);
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(templateType);
            //FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(templateDescription);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false);
            var templateTable = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetAttribute("textContent");
            var templateExists = templateTable.Contains(templateDescription);
            #endregion

            if (!templateExists)
            {
                #region Create new phrase group
                Reports.TestStep = "Create new phrase group";
                FastDriver.NextGenDocumentPreparation.Open();
                FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForPhrasesTabToLoad();
                FastDriver.NextGenDocumentPreparation.CreateNewPhraseGroup.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);

                var groupName = Support.RandomString(phraseGrp_Name);
                FastDriver.NextGenDocumentPreparation.GroupName.FASetText(groupName);

                var groupDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));
                FastDriver.NextGenDocumentPreparation.Description.FASetText(groupDescription);

                FastDriver.NextGenDocumentPreparation.TypeSelect.FASelectItem(phrase_Type);
                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.GroupName);
                Support.AreEqual(DateTime.UtcNow.ToPST().ToString("M/d/yyyy"), FastDriver.NextGenDocumentPreparation.PhraseGroupRevisionTable.PerformTableAction("Comments", "Created", "Revised Date", TableAction.GetText).Message);
                #endregion

                #region Add phrases
                Reports.TestStep = "Add phrases";
                FastDriver.NextGenDocumentPreparation.PhrasesHeaderTable.FARightClick();
                FastDriver.NextGenDocumentPreparation.AddNewPhrase.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);

                var phraseName = Support.RandomString(phraseGrp_Name);
                FastDriver.NextGenDocumentPreparation.NamePhrasesProperties.FASetText(phraseName);

                var phraseDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(17));
                FastDriver.NextGenDocumentPreparation.DesPhrasesName.FASetText(phraseDescription);

                FastDriver.NextGenDocumentPreparation.SaveButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.SaveButtom.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.NamePhrasesProperties);
                #endregion

                #region Insert phrases
                Reports.TestStep = "Insert phrases";
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.Highlight(3);
                FastDriver.NextGenDocumentPreparation.PhraseViewButtom.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                this.InsertDataElement();


               // FastDriver.DocumentEditor.InsertDataElementwithIDandIndex("BUNAME, SENAME", "?");



                #endregion

                #region Create template

                #region Navigate to NextGen Document Preparation Screen
                Reports.TestStep = "Navigate to NextGen Document Preparation Screen";
                FastDriver.NextGenDocumentPreparation.Open();
                #endregion

                #region Create template
                Reports.TestStep = "Create a new template";
                FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClickAction();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateDescription);
                FastDriver.NextGenDocumentPreparation.CreateNewTemplate.FAClickAction();

                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                templateName = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(4));
                FastDriver.NextGenDocumentPreparation.TemplateName.FASetText(templateName);
                templateDescription = "TEST--" + Support.RandomString(phraseGrp_Name.Substring(0, 2).Repeat(26));

                FastDriver.NextGenDocumentPreparation.TemplateDescription_Properties.FASetText("TEST-Template-" + Support.RandomString(templateDescription.Repeat(2)));

                FastDriver.NextGenDocumentPreparation.TemplateType_Properties.FASelectItem(templateType);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Saving.. please wait...", false);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                #endregion

                #region Insert template
                Reports.TestStep = "Insert template";
                FastDriver.NextGenDocumentPreparation.Editor.Highlight(3);
                FastDriver.NextGenDocumentPreparation.Editor.FAClick();
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.InsertPhraseBelowAndSave(groupName + "/" + phraseName, phraseDescription);
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(FastDriver.NextGenDocumentPreparation.TemplateName);
                FastDriver.NextGenDocumentPreparation.UnderConstruction.FASetCheckbox(false);
                FastDriver.NextGenDocumentPreparation.Save.FAClick();
                FastDriver.NextGenDocumentPreparation.WaitForScreenToLoad(); 
                #endregion

                #endregion
            }
            else
            {
                Reports.StatusUpdate("Template: " + templateDescription + " already exist", true);
            }
        }
                            
        private void InsertDataElement()
        {
            try
            {
                var currentLine = FastDriver.DocumentEditor.IRDocumentCurrentLine2;
                if (currentLine.DelayOnce(10).Visible() == false)
                    currentLine.DelayOnce(60);
                currentLine.FAClick();
                Keyboard.SendKeys(FAKeys.Enter);
                FastDriver.DocumentEditor.IRDocumentCurrentLine6.DelayOnce(3).ContextClick();
                FastDriver.DocumentEditor.IR_CM_InsertDataElement3.DelayOnce(3).FAClick();
                FastDriver.DocumentEditor.IRInsertSearch5.DoubleClick();
                Keyboard.SendKeys(FAKeys.Enter);
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItemBySendingKeys("Buyer");
                FastDriver.DataElementSelectionDlg.WaitCreation(FastDriver.DataElementSelectionDlg.SearchResult);
                FastDriver.DataElementSelectionDlg.GetSearchResult(0).FAClick();
                FastDriver.DataElementSelectionDlg.Select.FAClick();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();

                if (FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1850, 50).Visible())   // 1920 * 1280
                    FastDriver.DocumentEditor.IRSave.Offset(1850, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 240, 50).Visible())     // 1680 * 1050
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 240, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).Visible())     // 1600 * 1200
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).Visible())     // 1280 * 1024
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).FAClick();
                else
                    Support.Fail("'Save' was not found by ImageRecognition");


                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FAClick();
                FastDriver.DocumentEditor.Yes.FAClick();
                Playback.Wait(6000);

            }
            catch (Exception ex)
            {
                MasterTestClass.FailTest(MasterTestClass.GetExceptionInfo(ex));
            }
        }


        public void InsertPhraseCondition()
        {


            if (FastDriver.DocumentEditor.IRInsertPhrase7.DelayOnce(60).Visible())


            // if (FastDriver.DocumentEditor.IRInsertPhrase.DelayOnce(60).Offset(220, 130).Visible())

            // if (FastDriver.DocumentEditor.IRInsertPhrase2.DelayOnce(60).Offset(1850 - 320, 50).Visible())     // 1600 * 1200
            {
                //FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 190).ContextClick();
                //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 230).FAClick();
                //FastDriver.DocumentEditor.IRInsertSearch1st.Offset(568, 238).DoubleClick();

                FastDriver.DocumentEditor.IRInsertPhrase3.Offset(220, 130).ContextClick();

                FastDriver.DocumentEditor.IRInsertPhraseCondition.FAClick();



                //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(300, 50).FAClick();
                //FastDriver.DocumentEditor.IRInsertSearch1st.Offset(568, 238).DoubleClick();




            }
            else if (FastDriver.DocumentEditor.IRInsertPhrase6.Visible())
            {
                FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 190 + 720).ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseCondition.FAClick();

                //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 230 + 680).FAClick();
                //FastDriver.DocumentEditor.IRInsertSearch.Offset(560, 732).DoubleClick();
            }
            else
            {
                Support.Fail("'Phrase Condition' was not found by ImageRecognition");
            }

            //

            Reports.TestStep = "Add phrase condition";
            //Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"�\" for inserting phrase";
            FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
            //

            Reports.TestStep = "Add DataElement and Value. Click on Done ";
            //Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";


            Reports.TestStep = "Add Invalid data element.";
            FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
            FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "1A2B3C4");
            FastDriver.PhraseConditionsDlg.Done.FAClick();

            Reports.TestStep = "Phrase conditions data element not found.";
            Support.AreEqual("Data Element not found, please reenter.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
            FastDriver.PhraseConditionsDlg.Remove.FAClick();  

            Reports.TestStep = "Validate �Data Element required for operator and value.� Error Message";
            FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
            FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "", index: "1", _operator: "EQ", value: "Field");

            Reports.TestStep = "Data Element required for operator and value.";
            Support.AreEqual("Data Element required for operator and value.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
            FastDriver.PhraseConditionsDlg.Remove.FAClick();




            Reports.TestStep = "Make Index feild balnk.";
            FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
            FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "ALBADD1", index: "", _operator: "EQ", value: "Field");
            
            Reports.TestStep = "Index is required for this Data Element.";
            Support.AreEqual("Index is required for this Data Element.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
            FastDriver.PhraseConditionsDlg.Remove.FAClick();


            Reports.TestStep = "Validate �Field is required.� Error Message";
            FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
            FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "");

            Reports.TestStep = "Feild is Required.";
            Support.AreEqual("Feild is Required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());
            FastDriver.PhraseConditionsDlg.Remove.FAClick();

            

            
            Reports.TestStep = "Add Phrase Condition Buyer and operator as EB.";
            FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
            FastDriver.PhraseConditionsDlg.EnterCondition(5, dataElement: "BUFNAM", index: "1", _operator: "EB");
            Support.AreEqual("False", FastDriver.PhraseConditionsDlg.DataElmts1Value.IsEnabled().ToString(), "DataElmts1Value IsEnabled");
            FastDriver.PhraseConditionsDlg.Done.FAClick();

            Reports.TestStep = "Field is required.";
            Support.AreEqual("Field is required.", FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false).Clean());

            Reports.TestStep = "Enter Operator as NB and Verify the value.";
            FastDriver.PhraseConditionsDlg.EnterCondition(1, value: "value");
            FastDriver.PhraseConditionsDlg.EnterCondition(1, dataElement: "PI1CTY", _operator: "NB");

            Reports.TestStep = "Verify a value is not required if the selected operator is NB (not equal to blank).";
            Support.AreEqual("False", FastDriver.PhraseConditionsDlg.Value.IsEnabled().ToString(), "Value IsEnabled");

            Reports.TestStep = "Verify the conditions and Operator values.";
            Support.AreEqual("True", FastDriver.PhraseConditionsDlg.Operator.FAGetDropdownOptions().ToListString().Contains("NB").ToString(), "NB listed in Operator options");

            Reports.TestStep = "Add value field more than 35 characters.";
            FastDriver.PhraseConditionsDlg.EnterCondition(1, _operator: "EQ", value: "dsadhkiasjdklasjdlksjdflkjfkldjfdfuxczxczxcxzcxzczczczczczcz");

            Reports.TestStep = "Verify City (PI1CTY) data element is selected the Value should allow up to 30 chars.";
            Support.AreEqual("dsadhkiasjdklasjdlksjdflkjfkldjfdfuxczxczxcxzcxzczczczczczcz", FastDriver.PhraseConditionsDlg.Value.FAGetValue().Clean(), "Value");

            Reports.TestStep = "Click on Done button.";
            FastDriver.PhraseConditionsDlg.Done.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);

            Reports.TestStep = "Click on Phrase conditions.";

            if (FastDriver.DocumentEditor.IRInsertPhrase7.DelayOnce(60).Visible())


            // if (FastDriver.DocumentEditor.IRInsertPhrase.DelayOnce(60).Offset(220, 130).Visible())

            // if (FastDriver.DocumentEditor.IRInsertPhrase2.DelayOnce(60).Offset(1850 - 320, 50).Visible())     // 1600 * 1200
            {
                //FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 190).ContextClick();
                //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 230).FAClick();
                //FastDriver.DocumentEditor.IRInsertSearch1st.Offset(568, 238).DoubleClick();

                FastDriver.DocumentEditor.IRInsertPhrase3.Offset(220, 130).ContextClick();

                FastDriver.DocumentEditor.IRInsertPhraseCondition.FAClick();



                //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(300, 50).FAClick();
                //FastDriver.DocumentEditor.IRInsertSearch1st.Offset(568, 238).DoubleClick();




            }
            else if (FastDriver.DocumentEditor.IRInsertPhrase6.Visible())
            {
                FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 190 + 720).ContextClick();
                FastDriver.DocumentEditor.IRInsertPhraseCondition.FAClick();

                //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 230 + 680).FAClick();
                //FastDriver.DocumentEditor.IRInsertSearch.Offset(560, 732).DoubleClick();
            }
            else
            {
                Support.Fail("'Phrase Condition' was not found by ImageRecognition");
            }


            Reports.TestStep = "Add Phrase Condition.";
            FastDriver.PhraseConditionsDlg.WaitForScreenToLoad().Add.FAClick();
            FastDriver.PhraseConditionsDlg.EnterCondition(3, dataElement: "ALBADD1", index: "1", _operator: "EQ", value: "Field");
            FastDriver.PhraseConditionsDlg.Done.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.PhraseConditionsDlg.WindowTitle, false, 15);




            //FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            //FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
            //FastDriver.PhraseSelectDlg.Search.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            //FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            //FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
            //FastDriver.DialogBottomFrame.ClickDone();
            //FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            if (FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1800, 50).Visible())
                FastDriver.DocumentEditor.IRSave.Offset(1800, 50).FAClick();
            else if (FastDriver.DocumentEditor.IRSave.Offset(1570, 50).Visible())
                FastDriver.DocumentEditor.IRSave.Offset(1570, 50).FAClick();
            else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).Visible())     // 1600 * 1200
                FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).FAClick();
            else
                Support.Fail("'Save Button' was not found by ImageRecognition");
            FastDriver.DocumentEditor.WaitForScreenToLoad();
            FastDriver.DocumentEditor.Close.FAClick();
            FastDriver.DocumentEditor.WaitCreation(FastDriver.DocumentEditor.Yes);
            FastDriver.DocumentEditor.Yes.FAClick();
            Playback.Wait(6000);


        }

        // TODO: make this method returns collection of Group's sub-elements (CopyFilter, DeleteFilter, EditFilter, etc.) 
        public IWebElement GetGroupEditFilter(int group = 0)
        {
            this.SwitchToContentFrame();
            var filterGroups = WebDriver.FindElements(By.XPath("//div[@id='divTemplateFiltering']//span[@title='Edit Filter']"));
            if (filterGroups.Count > 0)
            {
                if (group == 0)
                    return filterGroups[filterGroups.Count - 1];
                else
                    return filterGroups[group - 1];
            }
            else
                return null;
        }

        public int SearchExistingTemplate(string temptype, string tempdesc)
        {

            FastDriver.NextGenDocumentPreparation.TemplatesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplateSearchTab.FAClick();
            FastDriver.NextGenDocumentPreparation.TemplateType.FASelectItem(temptype);
            FastDriver.NextGenDocumentPreparation.TemplateDescription.FASetText(tempdesc);
            FastDriver.NextGenDocumentPreparation.TemplateSearch.FAClick();
            Playback.Wait(5000);
            int table_rows = FastDriver.NextGenDocumentPreparation.TemplateResultsTable.GetRowCount();

            return table_rows;
        }

        public int SearchExistingPhraseGroup(string phrasetype, string phgrdesc)
        {

            FastDriver.NextGenDocumentPreparation.PhrasesTab.FAClick();
            FastDriver.NextGenDocumentPreparation.PhraseSearch.FAClick();
            FastDriver.NextGenDocumentPreparation.SelectPhraseType(phrasetype);
            FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseGroupDescription.FASetText(phgrdesc);
            FastDriver.NextGenDocumentPreparation.PhraseSearch_Search.FAClick();
            Playback.Wait(5000);
            int table_rows = FastDriver.NextGenDocumentPreparation.PhraseSearch_SearchResultsTable.GetRowCount();

            return table_rows;
        }

        #endregion


        public NextGenDocumentPreparation AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false, bool clickAccept = true)
        {
              string alertText = "";
              try
              {
                    WebDriver.WaitForAlertToExist(5);
                    var alert = WebDriver.SwitchTo().Alert();
                    alertText = alert.Text;
                    if(clickAccept)
                          alert.Accept();
                    else
                          alert.Dismiss();
                    if(SwitchToWindow)
                          WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
              }
              catch(Exception)
              {
                    alertText = "No Alert was Found";
              }
              finally
              {
                    if(CompareWith != null)
                    {
                          SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
                    }

              }
              return this;
        }


        // TODO: make this method selects more than 1 type. 
        //       use ";" as delimitor i.e. "Footer Phrases[FOOTER];Header Phrase[HEADER];Escrow Phrase[ESCROW]"
        public bool SelectPhraseType(string phraseType)
        {
            FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
            FastDriver.NextGenDocumentPreparation.WaitCreation(FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseTypeList);
            var allPhrases = PhraseSearch_PhraseTypeList.GetAttribute("textContent");

            if (PhraseSearch_PhraseTypeList.GetAttribute("textContent").ToLower().Contains(phraseType.ToLower()))
            {
                this.PhraseSearch_PhraseTypeList.FindElement(By.XPath("./div[label/text()='" + phraseType + "']/input")).FAClick() ;
                FastDriver.NextGenDocumentPreparation.PhraseSearch_PhraseType.FAClick();
                return true;
            }
            else
                return false;
        }

        //Added by Rafael
        public bool DocumentsTableTemplateExist(string TempName)
        {
            var phrasesAmount = TemplateTableDash.GetRowCount();
            for (int i = 1; i <= phrasesAmount; i++)
            {
                if (TemplateTableDash.PerformTableAction(i, 1, TableAction.GetText).Message.Contains(TempName))
                {
                    return true;
                }

            }

            throw new NoSuchElementException("Could not find Template " + TempName);
        }   


        //Added by Luis
        public void SelectMultipleRegions(string[] regionIDs)
        {

            for(int index = 0; index < regionIDs.Length; index++)
             FastDriver.WebDriver.FindElement(By.CssSelector("#ddcl-ddTemplateRegions-ddw input[value='" + regionIDs[index] + "']")).FASetCheckbox(true);
        }
    }

}
