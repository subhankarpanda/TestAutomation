using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class NotesEntryDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtNotes")]
        public IWebElement Notes { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        #endregion

        public NotesEntryDlg EnterNote(string note)
        {
            WaitForScreenToLoad();
            Notes.FASetText(note);
            return this;
        }

        public NotesEntryDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Notes", true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Notes);
            return this;
        }

        public bool IsNotesEntryDialogPresent()
        {
            try
            {
                WebDriver.SwitchTo().DefaultContent();
                this.SwitchToDialogContentFrame();
                return WebDriver.PageSource.Contains("Notes Entry");
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

    }
}
