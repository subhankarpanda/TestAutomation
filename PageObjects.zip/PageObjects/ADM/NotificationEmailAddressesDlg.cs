using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class NotificationEmailAddressesDlg : PageObject
	{
        public string WindowTitle { get { return "Email Address Recipients"; } }

		#region WebElements

		[FindsBy(How = How.Id, Using = "Name1")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "Email1")]
		public IWebElement Email1 { get; set; }

		[FindsBy(How = How.Id, Using = "Name2")]
		public IWebElement Name2 { get; set; }

		[FindsBy(How = How.Id, Using = "Email2")]
		public IWebElement Email2 { get; set; }

		[FindsBy(How = How.Id, Using = "Name3")]
		public IWebElement Name3 { get; set; }

		[FindsBy(How = How.Id, Using = "Email3")]
		public IWebElement Email3 { get; set; }

		[FindsBy(How = How.Id, Using = "Name4")]
		public IWebElement Name4 { get; set; }

		[FindsBy(How = How.Id, Using = "Email4")]
		public IWebElement Email4 { get; set; }

		[FindsBy(How = How.Id, Using = "Name5")]
		public IWebElement Name5 { get; set; }

		[FindsBy(How = How.Id, Using = "Email5")]
		public IWebElement Email5 { get; set; }

		[FindsBy(How = How.Id, Using = "Name6")]
		public IWebElement Name6 { get; set; }

		[FindsBy(How = How.Id, Using = "Email6")]
		public IWebElement Email6 { get; set; }

		[FindsBy(How = How.Id, Using = "Name7")]
		public IWebElement Name7 { get; set; }

		[FindsBy(How = How.Id, Using = "Email7")]
		public IWebElement Email7 { get; set; }

		[FindsBy(How = How.Id, Using = "Name8")]
		public IWebElement Name8 { get; set; }

		[FindsBy(How = How.Id, Using = "Email8")]
		public IWebElement Email8 { get; set; }

		[FindsBy(How = How.Id, Using = "Name9")]
		public IWebElement Name9 { get; set; }

		[FindsBy(How = How.Id, Using = "Email9")]
		public IWebElement Email9 { get; set; }

		[FindsBy(How = How.Id, Using = "Name10")]
		public IWebElement Name10 { get; set; }

		[FindsBy(How = How.Id, Using = "Email10")]
		public IWebElement Email10 { get; set; }

		//TODO: ADD FindsByAttribute
		[FindsBy(How = How.CssSelector, Using = "#PanelEmailAddress > table")]
		public IWebElement Table { get; set; }

		#endregion
		
		#region Services
        public void WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(WindowTitle, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Name1);
        }

		public int GetRowCount()
        {
            return this.Table.GetRowCount();
        }
		#endregion

	}
}
