using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class NotificationSetup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdDocLeft")]
        public IWebElement AddSender { get; set; }

        [FindsBy(How = How.Id, Using = "txtTestFile")]
        public IWebElement TestFile { get; set; }

        [FindsBy(How = How.Id, Using = "btnTestNotify")]
        public IWebElement TestNotify { get; set; }

        [FindsBy(How = How.Id, Using = "cboFBPRole")]
        public IWebElement FBPRole { get; set; }

        [FindsBy(How = How.Id, Using = "cboTaskStatus")]
        public IWebElement TaskStatus { get; set; }

        [FindsBy(How = How.Id, Using = "cboBuyerSellerType")]
        public IWebElement BuyerSellerType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDeliveryMethod")]
        public IWebElement DeliveryMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtSubjectLine")]
        public IWebElement SubjectLine { get; set; }

        [FindsBy(How = How.Id, Using = "btnInsertDataElement")]
        public IWebElement InsertDataElement { get; set; }

        [FindsBy(How = How.Id, Using = "txtMessageTemplate")]
        public IWebElement MessageTemplate { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "cboETitleOnbehalfof")]
        public IWebElement Sender { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "txtEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "radDocumentTypePdf")]
        public IWebElement FormatPDF { get; set; }

        [FindsBy(How = How.Id, Using = "radDocumentTypeWord")]
        public IWebElement FormatWord { get; set; }

        [FindsBy(How = How.Id, Using = "radIndividual")]
        public IWebElement AttachmentTypeIndividual { get; set; }

        [FindsBy(How = How.Id, Using = "radGroupAttachments")]
        public IWebElement AttachmentTypeGroup { get; set; }

        [FindsBy(How = How.Id, Using = "btnDocumentSequence")]
        public IWebElement Sequence { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddRemoveDocuments")]
        public IWebElement DocumentsAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "btnImageAddremove")]
        public IWebElement ImagesAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "lbAvailabeSender")]
        public IWebElement AvailabeSender { get; set; }

        [FindsBy(How = How.Id, Using = "lbSelectedSender")]
        public IWebElement SelectedSender { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFBPRole")]
        public IWebElement FileRoles { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEmailAdress")]
        public IWebElement TaskEmailAddresses { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        public IWebElement DesignatedSenderName { get; set; }

        [FindsBy(How = How.Id, Using = "txtEmailAddress")]
        public IWebElement DesignatedSenderEmailAddress { get; set; }

        [FindsBy(How = How.LinkText, Using = "Notification will be sent from the first")]
        public IWebElement SenderInfo { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[contains(text(),'Notification will be sent from the first')]")]
        public IWebElement SenderInfoTableCell { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDocRight")]
        public IWebElement LeftDirectionArrow { get; set; }

        [FindsBy(How = How.Id, Using = "cmdUp")]
        public IWebElement UpDirectionArrow { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDown")]
        public IWebElement DownDirectionArrow { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDocLeft")]
        public IWebElement RightDirectionArrow { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments")]
        public IWebElement DocumentsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocuments_0_lblDocument")]
        public IWebElement Documents_DocName { get; set; }

        [FindsBy(How = How.Id, Using = "dgImages")]
        public IWebElement ImageTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "Business Source Sales Rep 1")]
        public IWebElement BusinessSourceRep1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Business Source Sales Rep 2")]
        public IWebElement BusinessSourceRep2 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Title Assistant")]
        public IWebElement TitleAssistant { get; set; }

        [FindsBy(How = How.LinkText, Using = "Designated Sender")]
        public IWebElement DesignedSender { get; set; }

        [FindsBy(How = How.LinkText, Using = "Escrow Assistant")]
        public IWebElement EscrowAssistant { get; set; }

        [FindsBy(How = How.LinkText, Using = "Title Officer")]
        public IWebElement TitleOfficer { get; set; }

        [FindsBy(How = How.LinkText, Using = "Escrow Officer")]
        public IWebElement EscrowOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelectionCriteria")]
        public IWebElement SelectionCriteria { get; set; }

        [FindsBy(How = How.LinkText, Using = "Invoice")]
        public IWebElement InvoiceDocument { get; set; }

        [FindsBy(How = How.Id, Using = "cboTaskTemplates")]
        public IWebElement TaskName { get; set; }

        [FindsBy(How = How.Id, Using = "lblTaskTemplateName")]
        public IWebElement TaskName1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEntityName")]
        public IWebElement EntityName { get; set; }

        [FindsBy(How = How.LinkText, Using = "You are attempting to create a notificat")]
        public IWebElement ErrorMessage { get; set; }

        #endregion

        public NotificationSetup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FileRoles);
            return this;
        }

    }
    public class groupElementsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddEventCategory")]
        public IWebElement EventCategory { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1")]
        public IWebElement Table { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFObjectCd")]
        public IWebElement BusinessSourceL1 { get; set; }

        #endregion

        public groupElementsDlg WaitForScreenToLoad(string WindowTitle = "Select a Data Element", IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(WindowTitle, timeoutSeconds: 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? EventCategory);
            return this;
        }

    }
    public class AttachmentSequenceDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtPackage")]
        public IWebElement Package { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDocUp")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDocDown")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocs_dgDocs")]
        public IWebElement Table { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Tabledata { get; set; }

        #endregion

    }
}
