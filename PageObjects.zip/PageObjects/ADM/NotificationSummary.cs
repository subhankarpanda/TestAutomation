using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class NotificationSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "btnCopy")]
		public IWebElement Copy { get; set; }

		[FindsBy(How = How.Id, Using = "btnDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "btnView")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "btnChangeHistory")]
		public IWebElement ChangeHistory { get; set; }

		[FindsBy(How = How.Id, Using = "chkActiveOnly")]
		public IWebElement ActiveOnly { get; set; }

		[FindsBy(How = How.Id, Using = "btnCopyNotification")]
		public IWebElement CopyNotificationTo { get; set; }

		[FindsBy(How = How.Id, Using = "dgNotificationSummary")]
		public IWebElement NotificationSummaryTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Notification DetailsSender Info: Title AssistantMessage Template: CreatedForProActiveEnhTestSubject Line:  Attachment Type: IndividualDocument Format: PDFDocument(s): Image(s):")]
		public IWebElement NotificationDetailsTable { get; set; }

		[FindsBy(How = How.Id, Using = "lblTaskName1")]
		public IWebElement TaskName { get; set; }

		[FindsBy(How = How.Id, Using = "tblNotificationGrid")]
		public IWebElement NotificationDetails { get; set; }

		[FindsBy(How = How.Id, Using = "lblEntityName")]
		public IWebElement TaskName1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgNotificationSummary_0_lblTaskName")]
		public IWebElement TaskNameInTable { get; set; }

		#endregion

        public NotificationSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }

	}
}
