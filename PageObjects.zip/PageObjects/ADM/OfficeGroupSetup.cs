using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.ADM
{
    public class OfficeGroupSetup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.Id, Using = "dgridOffice_0_cbOfficeSelect")]
        public IWebElement Offices { get; set; }

        [FindsBy(How = How.Id, Using = "chkActiveOnly")]
        public IWebElement ActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "cmdViewChangeHistory")]
        public IWebElement ViewchangeHistory { get; set; }

        [FindsBy(How = How.Id, Using = "dgridOfficeGroup_1_txtOfficeGroupName")]
        public IWebElement OfficeGroupName { get; set; }

        [FindsBy(How = How.LinkText, Using = "*Fast Automation1")]
        public IWebElement FastAutomation1 { get; set; }

        //[FindsBy(How = How.Id, Using = "dgridOfficeGroup")]
        //Id keeps changing, change to xpath
        [FindsBy(How = How.XPath, Using = "//table[@id='dgridOfficeGroup' or @id='dgridOfficeGroup_dgridOfficeGroup']")]
        public IWebElement OfficeGroupTable { get; set; }

        //Changes on 10.6 release
        //[FindsBy(How = How.Id, Using = "dgridOffice_dgridOffice")]
        //[FindsBy(How = How.Id, Using = "dgridOffice")]

        //Id keeps changing, change to xpath
        [FindsBy(How = How.XPath, Using = "//table[@id='dgridOffice' or @id='dgridOffice_dgridOffice']")]
        public IWebElement OfficesTable { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Error { get; set; }

        [FindsBy(How = How.Id, Using = "dgridOffice_9_lblOfficeName")]
        public IWebElement OfficePane { get; set; }

        #endregion

        public OfficeGroupSetup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }
        //
        public OfficeGroupSetup Open()
        {
            FastDriver.LeftNavigation.Navigate<OfficeGroupSetup>(@"Home>System Maintenance>Office Group");
            Thread.Sleep(5000);
            this.WaitForScreenToLoad();
            return this;
        }
        public string CreateNewOfficeGroup(List<string> Offices)
        {
            string OfficeGroupName = "FPUC0013_OfficeGroup" + System.Guid.NewGuid().ToString().Substring(0, 8);
            this.WaitForScreenToLoad();
           if(!this.OfficeGroupTable.FAGetText().Contains(OfficeGroupName))
           {
               this.New.FAClick();
               this.OfficeGroupTable.PerformTableAction(1, " ", 1, TableAction.SetText, OfficeGroupName);
               foreach(string office in Offices)
               {
                   this.OfficesTable.PerformTableAction(2, office, 1, TableAction.On);
               }

           }
           FastDriver.BottomFrame.Save();
           return OfficeGroupName;
        }

    }
}
