using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class OfficeSelection : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "comboRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_dGridActiveOffices")]
		public IWebElement TableOffice { get; set; }

		[FindsBy(How = How.Id, Using = "dGridSelectedOffices_dGridSelectedOffices")]
		public IWebElement TableOfficeSelected { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_dGridActiveOffices")]
		public IWebElement TableOffice1 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_0_chkSelect")]
		public IWebElement OfficeName { get; set; }

		#endregion

        public OfficeSelection WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(TableOffice, 10);
            return this;
        }
	}
}
