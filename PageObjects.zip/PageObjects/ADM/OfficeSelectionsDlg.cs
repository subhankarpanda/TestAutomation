using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class OfficeSelectionsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "rdoOffice")]
		public IWebElement OfficeGroups { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "grdOffSel_0_chkSelOff")]
		public IWebElement OfficeCheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "grdOffSel_grdOffSel")]
		public IWebElement OfficeTable { get; set; }

		#endregion

        public OfficeSelectionsDlg WaitForScreenToLoad(string windowName = "Office Group/Office Selection")
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(OfficeTable, 10);
            return this;
        }

	}
}
