using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using FASTSelenium.DataObjects.ADM;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class OfficeSetupOffice : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_ddlPolicyIssuedBy")]
        public IWebElement PolicyIssuedBy { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tabOffice_OfficeSetup_Office1_txtOfficeCode, #tabOffice_OfficeSetup_Office1_lblOfficeCode")]
        public IWebElement OfficeCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtFederalTaxID")]
        public IWebElement FederalTaxID { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtName")]
        public IWebElement OfficeName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtOCName1")]
        public IWebElement OfficeCompanyName1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtComments")]
        public IWebElement OfficeComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtOCName2")]
        public IWebElement OfficeCompanyName2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdStatusReg")]
        public IWebElement OfficeViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtLogoFile1")]
        public IWebElement OfficeLogoFile1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtLogoFile2")]
        public IWebElement OfficeLogoFile2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtLogoFile3")]
        public IWebElement OfficeLogoFile3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtSysLogoFile")]
        public IWebElement OfficeSystemLogoFile { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboBusSegment")]
        public IWebElement BusinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_FAFCheckBox1")]
        public IWebElement Can_be_Inter_Regional_Production_office { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboFeeTransType")]
        public IWebElement FeeTransmittalType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_Fafcheckbox2")]
        public IWebElement Show_Promulgated_Rate_on_Fee_Entry { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboTmeZone")]
        public IWebElement TimeZone { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkFileNoteOrder")]
        public IWebElement SortFileNotesnewesttooldest { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_Fafcheckbox3")]
        public IWebElement DayLightSavingsTime { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_FAFCheckBox5")]
        public IWebElement DivisionProductionCenter { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_Fafcheckbox4")]
        public IWebElement NPSProductionOffice { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_Fafdropdownlist1")]
        public IWebElement StatisticalReportingOffice { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_Fafdropdownlist2")]
        public IWebElement ProductionSystem { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtDivision")]
        public IWebElement Division { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtLineOfBus")]
        public IWebElement LineOfBus { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtRecipientType")]
        public IWebElement RecipientType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtRecipientID")]
        public IWebElement RecipientID { get; set; }

        [FindsBy(How = How.Id, Using = "cmdHistory")]
        public IWebElement BusinessProgramHistory { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdSelectBP")]
        public IWebElement BusinessProgramAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdNewAdd")]
        public IWebElement BusinessProgramNew { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_cboAddressType")]
        public IWebElement Type { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtAddrLine1")]
        public IWebElement StreetLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtAddrLine2")]
        public IWebElement StreetLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtAddrLine3")]
        public IWebElement StreetLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtAddrLine4")]
        public IWebElement StreetLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtCity")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_cboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtZip")]
        public IWebElement Zip { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_txtCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhysicalAddressBook1_cboCountry")]
        public IWebElement Country { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_0_cboPhoneType")]
        public IWebElement BusinessPhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_0_txtPhone")]
        public IWebElement BusinessPhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_0_txtExtension")]
        public IWebElement BusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_0_txtComments")]
        public IWebElement BusinessPhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_1_cboPhoneType")]
        public IWebElement BusinessFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_1_txtPhone")]
        public IWebElement BusinessFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_1_txtExtension")]
        public IWebElement BusinessFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_1_txtComments")]
        public IWebElement BusinessFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_2_cboPhoneType")]
        public IWebElement EmailType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_2_txtPhone")]
        public IWebElement EmailNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_2_txtComments")]
        public IWebElement EmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_3_cboPhoneType")]
        public IWebElement PagerType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_3_txtPhone")]
        public IWebElement PagerNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_3_txtExtension")]
        public IWebElement PagerExtension { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_3_txtComments")]
        public IWebElement PagerComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_4_cboPhoneType")]
        public IWebElement CellularType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_4_txtPhone")]
        public IWebElement CellularNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_4_txtComments")]
        public IWebElement CellularComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_4_txtExtension")]
        public IWebElement CellularExtension { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_5_cboPhoneType")]
        public IWebElement GABEmailType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_5_txtPhone")]
        public IWebElement GABEmailNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_5_txtComments")]
        public IWebElement GABEmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdEscrowUP")]
        public IWebElement ProductionOfficeEscrowUp { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdEscrowDown")]
        public IWebElement ProductionOfficeEscrowDown { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdEscrowAddRem")]
        public IWebElement ProductionOfficeEscrowAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdTitleUp")]
        public IWebElement ProductionOfficeTitleUp { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdTitleDown")]
        public IWebElement ProductionOfficeTitleDown { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdTitleAddRem")]
        public IWebElement ProductionOfficeTitleAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtFNPrefix")]
        public IWebElement FileNumberSchemaPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboFNSep1")]
        public IWebElement FileNumberSchemaSeparator1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboFNSep2")]
        public IWebElement FileNumberSchemaSeparator2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtFNSuffix")]
        public IWebElement FileNumberSchemaSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_0_txtPrefix")]
        public IWebElement DocumentNumberSchemaInvoicePrefix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_0_txtBegNo")]
        public IWebElement DocumentNumberSchemaInvoiceBeginning { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_1_txtPrefix")]
        public IWebElement DocumentNumberSchemaReceiptPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_1_txtBegNo")]
        public IWebElement DocumentNumberSchemaReceiptBeginning { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_2_txtPrefix")]
        public IWebElement DocumentNumberSchemaIBA_Disbursement_Book_TransferPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_2_txtBegNo")]
        public IWebElement DocumentNumberSchemaIBA_Disbursement_Book_TransferBeginning { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_0_cboCustomer")]
        public IWebElement DocPreferenceInvoiceCopyToCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_0_cboFile")]
        public IWebElement DocPreferenceInvoiceCopyToFile { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_0_cboAccounting")]
        public IWebElement DocPreferenceInvoiceCopyToAccounting { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_0_txtOther")]
        public IWebElement DocPreferenceInvoiceCopyToOthertext { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_0_cboOther")]
        public IWebElement DocPreferenceInvoiceCopyToOthers { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_1_cboCustomer")]
        public IWebElement DocPreferenceReceiptCopyToCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_1_cboFile")]
        public IWebElement DocPreferenceReceiptCopyToFile { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_1_cboAccounting")]
        public IWebElement DocPreferenceReceiptCopyToAccounting { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_1_cboOther")]
        public IWebElement DocPreferenceReceiptCopyToOther { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocPref_1_txtOther")]
        public IWebElement DocPreferenceReceiptCopyToOthertext { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtDepRectNote")]
        public IWebElement DocPreferenceDepositReceiptNote { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtGLClientCode")]
        public IWebElement General_Ledger_AccountingClientCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtGLDivisionCode")]
        public IWebElement General_Ledger_AccountingDivisionCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkGLFeeTrans")]
        public IWebElement GeneralLedger_FeeTransfer { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtTrustRegCode")]
        public IWebElement TrustAccounting_TrustNet32Code1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtTrustOffPrefix")]
        public IWebElement TrustAccounting_TrustNet32Code2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtAcctFTPIP")]
        public IWebElement TrustAccounting_ftpServerAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtRemoteDir")]
        public IWebElement TrustAccounting_ftpRemoteDirectory { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtUserName")]
        public IWebElement TrustAccounting_ftpUserName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkGLInvoice")]
        public IWebElement GeneralLedger_Invoice { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtPassword")]
        public IWebElement TrustAccounting_ftpUserPassword { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cbxExtractCutoffHour")]
        public IWebElement TrustAccountingAutomaticExtractCutoffTimeinHour { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_FAFCheckBoxEmpOverdraft")]
        public IWebElement EmployeeOverdraftLimit { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cbxExtractCutoffMinute")]
        public IWebElement TrustAccountingAutomaticExtractCutoffTimeinMin { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cbxExtractCutoffAMPM")]
        public IWebElement TrustAccountingAutomaticExtractCutoffTimeinAMPM { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddContact")]
        public IWebElement AddContact { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtAutoExtractFailureContact")]
        public IWebElement Automatic_Extract_Failure_Email_alert { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtSiteID")]
        public IWebElement FASTSearchSiteID { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkDateDown")]
        public IWebElement DateDown { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkExtInvAct")]
        public IWebElement EstimatedInvoiceActivity { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtActivityDate")]
        public IWebElement ActivityDate1099s { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtStatCode")]
        public IWebElement FastStatCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_ddlCorpParent")]
        public IWebElement CorporateParent { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkExpOffice")]
        public IWebElement ExceptionOffice { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboTitleAgent")]
        public IWebElement TitleAgentType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkAcctSingPdt")]
        public IWebElement AccountServicingProduct { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkFISPOD")]
        public IWebElement FISPayOffDemand { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdFISServicer")]
        public IWebElement Servicers { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_FAFTextBox17")]
        public IWebElement OverDraftAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_FAFTextBox18")]
        public IWebElement OverDraftPassword { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkSigning")]
        public IWebElement SigningScreen { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Office']")]
        public IWebElement OfficeMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Bank Accounts']")]
        public IWebElement BankAccountsMenu { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Payee Assignments']")]
        public IWebElement PayeeAssignmentsMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Underwriters']")]
        public IWebElement UnderwritersMenu { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema")]
        public IWebElement DocumentNumberSchemaTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridDocNoSchema_5_lblNextNo")]
        public IWebElement ServiceFeeNextAvailableElement { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusinessUnitCd: Cannot add office. The Office ID Code already exists within this processing region.")]
        public IWebElement ErrorPane { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_lblOfficeCode")]
        public IWebElement OfficeCodePane { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridAddress_gridAddress")]
        public IWebElement TableAddress { get; set; }
        
        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdCopyAdd")]
        public IWebElement AddressCopy { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cmdDeleteAdd")]
        public IWebElement AddressRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_lblBusUnitID")]
        public IWebElement BUIDpane { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_lblFNNextNo")]
        public IWebElement AvailableFileNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridEscrow")]
        public IWebElement EscrowOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_gridTitle")]
        public IWebElement TitleOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkEPloicy")]
        public IWebElement eTitle { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkSymantecWire")]
        public IWebElement WireApprovalAuthentication { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkInfodex")]
        public IWebElement InfoLink { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_txtInfodexURL")]
        public IWebElement InfodexURL { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_FAFCheckBox6")]
        public IWebElement ANPolicyNumber { get; set; }

        [FindsBy(How = How.Id, Using = "Table7")]
        public IWebElement IntegratewithExternalSystems { get; set; }

        [FindsBy(How = How.LinkText, Using = "Business Unit: This office has been used as a default production office by one or more other offices.")]
        public IWebElement ErrorPane1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboOpenTimeHour")]
        public IWebElement OpenTimeHour { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboOpenTimeMinute")]
        public IWebElement OpenTimeMinute { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboOpenTimeAMPM")]
        public IWebElement OpenTimeAMPM { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboCloseTimeHour")]
        public IWebElement CloseTimeHour { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboCloseTimeMinute")]
        public IWebElement CloseTimeMinute { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_cboCloseTimeAMPM")]
        public IWebElement CloseTimeAMPM { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Error1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_ucLicenseInfo_btnViewChangeStatus")]
        public IWebElement LicenseInformationViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement LicenseInformationTable { get; set; }
        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_ucLicenseInfo_btnNew")]
        public IWebElement LicenseInformationNew { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkProjectFile")]
        public IWebElement ProjectFile { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_dgridBP_dgridBP")]
        public IWebElement BusinessProgramTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_cmdAddPhoneType")]
        public IWebElement PhonesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_cmdDeletePhone")]
        public IWebElement PhonesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_6_cboPhoneType")]
        public IWebElement SDNType { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_6_txtPhone")]
        public IWebElement SDNNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_6_txtComments")]
        public IWebElement SDNComment { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkLaunchFastSearchOnOpenOrder")]
        public IWebElement Launch_Fast_Search_on_Open_Order { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_chkDisableOffice")]
        public IWebElement Hidden { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Office1_PhoneDetails1_gridPhoneTypes_6_txtExtension")]
        public IWebElement txtExtension6 { get; set; }

        #endregion

        #region - Recursive Methods
        public OfficeSetupOffice WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? OfficeLogoFile2);
            return this;
        }

        public string[] GetFileNumberSchemaPrefixAndSuffix()
        {
            this.WaitForScreenToLoad();
            return new[] { this.FileNumberSchemaPrefix.FAGetValue(), this.FileNumberSchemaSuffix.FAGetValue() };
        }
        //
        public Dictionary<string, string> GetTitleProdOffices()
        {
            Dictionary<string, string> ProdOffices = new Dictionary<string, string>();
            this.WaitForScreenToLoad();
            for (int i = 2; i <= TitleOfficeTable.GetRowCount(); i++)
            {
                ProdOffices.Add("SeqNo" + this.TitleOfficeTable.PerformTableAction(i, 3, TableAction.GetText).Message, this.TitleOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message);
            }
            return ProdOffices;
        }
        //
        public Dictionary<string, string> GetEscrowProdOffices()
        {
            Dictionary<string, string> ProdOffices = new Dictionary<string, string>();
            this.WaitForScreenToLoad();
            for (int i = 2; i <= this.EscrowOfficeTable.GetRowCount(); i++)
            {
                ProdOffices.Add("SeqNo" + this.EscrowOfficeTable.PerformTableAction(i, 3, TableAction.GetText).Message, this.EscrowOfficeTable.PerformTableAction(i, 1, TableAction.GetText).Message);
            }
            return ProdOffices;
        }
        //
        public bool SetRequestPolicyNumCheckbox(bool Status)
        {
            ANPolicyNumber.FASetCheckbox(Status);
            if (ANPolicyNumber.IsSelected().Equals(Status))
                return true;
            else
                return false;
        }

        public void SetFileNumberSchemaPrefixAndSuffix(string Prefix, string Suffix)
        {
            this.WaitForScreenToLoad();
            this.FileNumberSchemaPrefix.FASetText(Prefix);
            this.FileNumberSchemaSuffix.FASetText(Suffix + FAKeys.Tab);
        }
        //
        public string GetDefaultBusinessSegment()
        {
            this.WaitForScreenToLoad();
            return this.BusinessSegment.FAGetSelectedItem().Trim();
        }
        //
        public string ChangeBusinessSegment(string BusinessSegment)
        {
            this.WaitForScreenToLoad();
            this.BusinessSegment.FASelectItem(BusinessSegment);
            return this.BusinessSegment.FAGetSelectedItem().Trim();
        }
        //
        public bool GetIsInterRegionalProdOffice()
        {
            this.WaitForScreenToLoad();
            return this.Can_be_Inter_Regional_Production_office.IsSelected();
        }
        //
        public List<LicenseInfoParameters> GetLicenseInfo(string ID = "")
        {
            this.WaitForScreenToLoad();

            List<LicenseInfoParameters> AllLicenses = new List<LicenseInfoParameters>();

            for (int i = 1; i <= LicenseInformationTable.GetRowCount(); i++)
            {
                LicenseInfoParameters LicenseInfo = new LicenseInfoParameters
                {
                    LicenseId = string.Empty,
                    LicenseState = string.Empty,
                    LicenseCounty = string.Empty,
                    LicenseType = string.Empty,
                    LicenseStatus = string.Empty,
                };
                LicenseInfo.LicenseId = LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                LicenseInfo.LicenseState = LicenseInformationTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                LicenseInfo.LicenseCounty = LicenseInformationTable.PerformTableAction(i, 3, TableAction.GetText).Message;
                LicenseInfo.LicenseType = LicenseInformationTable.PerformTableAction(i, 4, TableAction.GetText).Message;
                LicenseInfo.LicenseStatus = LicenseInformationTable.PerformTableAction(i, 5, TableAction.GetText).Message;
                if (!string.IsNullOrEmpty(ID))
                {
                    if (LicenseInfo.LicenseId.Equals(ID))
                    {
                        AllLicenses.Add(LicenseInfo);
                        break;
                    }
                }
                else
                {
                    AllLicenses.Add(LicenseInfo);
                }


            }

            return AllLicenses;
        }
        //

        //
        public LicenseInfoParameters CreateNewLicense(string State, string StateLicenseType, string County = "", string CoLicenseType = "")
        {
            try
            {
                this.WaitForScreenToLoad();
                LicenseInfoParameters LicenseInfo = new LicenseInfoParameters();
                this.LicenseInformationNew.FAClick();
                Thread.Sleep(2000);
                string ID = FastDriver.LicenseInformationDlg.CreateNewLicense(State, StateLicenseType, County, CoLicenseType);
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.LicenseInformationTable.GetRowCount(); i++)
                {
                    string Act_ID = this.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (Act_ID.Equals(ID))
                    {
                        LicenseInfo = GetLicenseInfo(ID)[0];
                        break;
                    }
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(4000);
                return LicenseInfo;
            }
            catch
            {
                throw;
            }

        }
        //
        public bool CreateNMLS()
        {
            try
            {
                this.WaitForScreenToLoad();
                this.LicenseInformationNew.FAClick();
                Thread.Sleep(2000);
                FastDriver.LicenseInformationDlg.WaitForScreenToLoad();
                Random RanNum = new Random(2351674);
                FastDriver.LicenseInformationDlg.ID.FASetText(RanNum.Next().ToString());
                string ID = FastDriver.LicenseInformationDlg.ID.FAGetText();
                FastDriver.LicenseInformationDlg.NMLS.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.LicenseInformationTable.GetRowCount(); i++)
                {
                    string Act_ID = this.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (Act_ID.Equals(ID))
                        return true;
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
        //
        public void SetIsInterRegionalProdOffice()
        {
            this.WaitForScreenToLoad();
            if (!Can_be_Inter_Regional_Production_office.IsSelected())
                Can_be_Inter_Regional_Production_office.FASetCheckbox(true);
        }
        //
        public Dictionary<string, string> GetAddressDetails(string AddressType)
        {

            this.SwitchToContentFrame();
            Reports.TestStep = "Get address details";
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            if (this.TableAddress.FAGetText().Contains(AddressType))
            {
                AllDetails.Add("Status", this.TableAddress.PerformTableAction("Type", AddressType, "Type", TableAction.Click).Status.ToString());
                Thread.Sleep(3000);
                AllDetails.Add("AddressType", Type.FAGetSelectedItem());
                AllDetails.Add("AddressLine1", this.StreetLine1.FAGetValue());
                AllDetails.Add("AddressLine2", StreetLine2.FAGetValue());
                AllDetails.Add("AddressLine3", StreetLine3.FAGetValue());
                AllDetails.Add("AddressLine4", StreetLine4.FAGetValue());
                AllDetails.Add("Country", Country.FAGetSelectedItem());
                AllDetails.Add("City", City.FAGetValue());
                AllDetails.Add("State", State.FAGetSelectedItem());
                AllDetails.Add("Zip", Zip.FAGetValue());
                AllDetails.Add("County", County.FAGetValue());
            }
            return AllDetails;
        }
        //
        public BusinessOrganizationParameters SetNewAddressDetails(BusinessOrganizationParameters busOrg)
        {

            this.SwitchToContentFrame();
            Reports.TestStep = "Set New Address";
            FastDriver.WebDriver.HandleDialogMessage();
            this.WaitForScreenToLoad();
            this.BusinessProgramNew.FAClick();
            this.Type.FASelectItem(busOrg.Addresstype);
            StreetLine1.FASetText(busOrg.AddressLine1);
            StreetLine2.FASetText(busOrg.AddressLine2);
            StreetLine3.FASetText(busOrg.AddressLine3);
            StreetLine4.FASetText(busOrg.AddressLine4);
            Country.FASelectItem(busOrg.Country);
            City.FASetText(busOrg.City);
            State.FASelectItem(busOrg.State);
            Zip.FASetText(busOrg.Zip);
            County.FASetText(busOrg.County);
            //this.ap.FAClick();
            return busOrg;
        }

        public string GetLicenseID(string state, string type)
        {
            for (int i = 1; i <= FastDriver.OfficeSetupOffice.LicenseInformationTable.GetRowCount(); i++)
            {
                if (FastDriver.OfficeSetupOffice.LicenseInformationTable.PerformTableAction(i, 2, TableAction.GetText).Message.Contains(state) &&
                    FastDriver.OfficeSetupOffice.LicenseInformationTable.PerformTableAction(i, 4, TableAction.GetText).Message.Contains(type))
                {
                    return FastDriver.OfficeSetupOffice.LicenseInformationTable.PerformTableAction(i, 1, TableAction.GetText).Message.Clean();
                }

            }

            return "ID Not Found.";
        }

        public void Handle_Launch_Fast_Search_on_Open_Order(bool Option= true)
        {
            try
            {
                //#region data setup
                //var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                //#endregion

                #region UI Iteration

                //Reports.TestStep = "Log in to AMD side of Testing Enviroment";
                //FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Home Regions and to the testing office";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();

                Reports.TestStep = "Select an Office";
                FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Office Code", "7878", "Office Code", TableAction.Click);
                FastDriver.OfficeSummary.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Set the Launch Fast Search on Open Order checkbox back to default as checked";
                if (!FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.IsSelected()) 
                FastDriver.OfficeSetupOffice.Launch_Fast_Search_on_Open_Order.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch
            {
                throw;
            }
        }

        #region Class Methods
        public void CreateNewOffice()
        {
            FastDriver.OfficeSummary.New.FAClick();

            Reports.TestStep = "Enter details to newly created office.";
            FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
            Random random = new Random();
            string OfficeCode1 = random.Next(999, 10000).ToString();
            FastDriver.OfficeSetupOffice.OfficeCode.FASetText(OfficeCode1);
            FastDriver.OfficeSetupOffice.FederalTaxID.FASetText("567891234");
            FastDriver.OfficeSetupOffice.OfficeName.FASetText("SRT Test Automation Office");
            FastDriver.OfficeSetupOffice.OfficeCompanyName1.FASetText("SRT DO Not Touch Automation Office");
            FastDriver.OfficeSetupOffice.OfficeComments.FASetText("Creating a new Office");
            FastDriver.OfficeSetupOffice.OfficeLogoFile1.FASetText("Test");
            FastDriver.OfficeSetupOffice.OfficeSystemLogoFile.FASetText("Automation Test");
            FastDriver.OfficeSetupOffice.BusinessSegment.FASelectItem("Commercial");
            FastDriver.OfficeSetupOffice.Can_be_Inter_Regional_Production_office.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Fee Transfer");
            FastDriver.OfficeSetupOffice.TimeZone.FASelectItem("Mountain Time");
            FastDriver.OfficeSetupOffice.DivisionProductionCenter.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.NPSProductionOffice.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.StatisticalReportingOffice.FASelectItem("Agency");
            FastDriver.OfficeSetupOffice.ProductionSystem.FASelectItem("FAST deployed");
            FastDriver.OfficeSetupOffice.FileNumberSchemaPrefix.FASetText("EWS");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator1.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator2.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSuffix.FASetText("ADC");
            FastDriver.OfficeSetupOffice.DocumentNumberSchemaInvoicePrefix.FASetText("100");
            FastDriver.OfficeSetupOffice.FastStatCode.FASetText("12345");
            FastDriver.OfficeSetupOffice.CorporateParent.FASelectItemBySendingKeys("First American (FA)");
            FastDriver.OfficeSetupOffice.UnderwritersMenu.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwritersNew.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwriterName1.FASelectItem("New Underwriter");
            FastDriver.OfficeSetupUnderwriters.PremiumPercentage.FASetText("10");
            FastDriver.OfficeSetupUnderwriters.UseAsDefaultUnderwriter.FASetCheckbox(true);

            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItemBySendingKeys("Automation Bank - Automation Testing");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("232345");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("SRT AUTOMATION BANK");
            FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Bank Name", "Automation Bank - Automation Testing", "Bank Name", TableAction.Click);

            FastDriver.BottomFrame.Done();

        }


        #endregion Class Methods
        #endregion

    }

    public class OfficeSetupBankAccounts : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_cmdNew")]
        public IWebElement BankAccountSummaryNew { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_DWLBankName")]
        public IWebElement BankAccountDetail_BankName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_cmdbrowse")]
        public IWebElement BankAccountDetail_Detail { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtAccountNo")]
        public IWebElement BankAccountDetailAccountNo1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtAccountNo1")]
        public IWebElement BankAccountDetailAccountNo2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_cmdviewChangestatus")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtAccountDec")]
        public IWebElement BankAccountDetail_AccountDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_chkDisburseAcct")]
        public IWebElement DisburseAcct { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_chkPrimaryDisburse")]
        public IWebElement PrimaryDisburse { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_chkBistroflag")]
        public IWebElement WirelinkInterfaceAccount { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_chkDepositAcct")]
        public IWebElement DepositAcct { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_chkPrimaryDeposit")]
        public IWebElement PrimaryDeposit { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_DWSignature")]
        public IWebElement CheckTemplate_SignatureLineReq { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_TxtchekAmmount")]
        public IWebElement OverCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtsignaturetext")]
        public IWebElement SignatureText1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtsignature2")]
        public IWebElement SignatureText2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtSign1")]
        public IWebElement SignaturefileforSign1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtSign2")]
        public IWebElement SignaturefileforSign2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtprefix")]
        public IWebElement AutoNumberCheckPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtbigNum")]
        public IWebElement AutoNumberCheckBeginningNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_chkTA")]
        public IWebElement AutoNumberCheckTA { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtdlprefix")]
        public IWebElement AutoNumberDepositlistPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_txtDLStartNum")]
        public IWebElement AutoNumberDepositBeginningNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_BankAccountGrid_BankAccountGrid")]
        public IWebElement BanksTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_lblstatus")]
        public IWebElement BankStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_lblcreatedon")]
        public IWebElement CreatedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_lblcreatedby")]
        public IWebElement CreatedBy { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_lblNextAvNum")]
        public IWebElement NextAvailableNumber { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Error1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_BankAcct1_BankAccountGrid_6_lblAccountNo")]
        public IWebElement AccountNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Office']")]
        public IWebElement OfficeMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Bank Accounts']")]
        public IWebElement BankAccountsMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Payee Assignments']")]
        public IWebElement PayeeAssignmentsMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@class='TabHorizontal_Header'][text()='Underwriters']")]
        public IWebElement UnderwritersMenu { get; set; }

        #endregion

        #region - Recursive Methods
        public OfficeSetupBankAccounts WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? BankAccountSummaryNew);
            return this;
        }

        #endregion
    }

    public class OfficeSetupPayeeAssignments : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "Office")]
        public IWebElement LinkOffice { get; set; }

        [FindsBy(How = How.LinkText, Using = "Bank Accounts")]
        public IWebElement LinkBankAccounts { get; set; }

        [FindsBy(How = How.LinkText, Using = "Payee Assignments")]
        public IWebElement LinkPayeeAssignments { get; set; }

        [FindsBy(How = How.LinkText, Using = "Underwriters")]
        public IWebElement LinkUnderwriters { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_cmdRemoveBusParty")]
        public IWebElement DefaultTransferTaxPayee_Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_txtGABcode")]
        public IWebElement DefaultTransferTaxPayee_GABCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_cmdFindName")]
        public IWebElement DefaultTransferTaxPayee_Find { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_txtName")]
        public IWebElement DefaultTransferTaxPayee_GABName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_comboAttention")]
        public IWebElement DefaultTransferTaxPayee_Attention { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_chkEdit")]
        public IWebElement DefaultTransferTaxPayee_EditName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_textName")]
        public IWebElement DefaultTransferTaxPayee_Name { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_textReference")]
        public IWebElement DefaultTransferTaxPayee_Reference { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_cmdRemoveBusParty")]
        public IWebElement DefaultRecordingFeesPayee_Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_txtGABcode")]
        public IWebElement DefaultRecordingFeesPayee_GABCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_cmdFindName")]
        public IWebElement DefaultRecordingFeesPayee_Find { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_txtName")]
        public IWebElement DefaultRecordingFeesPayee_GABName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_comboAttention")]
        public IWebElement DefaultRecordingFeesPayee_Attention { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_chkEdit")]
        public IWebElement DefaultRecordingFeesPayee_EditName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_textName")]
        public IWebElement DefaultRecordingFeesPayee_Name { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_textReference")]
        public IWebElement DefaultRecordingFeesPayee_Reference { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_labelIdcode")]
        public IWebElement TTPayeePane { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_labelName")]
        public IWebElement TransferTaxPayeeNamePane { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_labelIdcode")]
        public IWebElement RFPayeePane { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Error1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Office")]
        public IWebElement OfficeMenu { get; set; }

        [FindsBy(How = How.LinkText, Using = "Bank Accounts")]
        public IWebElement BankAccountsMenu { get; set; }

        [FindsBy(How = How.LinkText, Using = "Payee Assignments")]
        public IWebElement PayeeAssignmentsMenu { get; set; }

        [FindsBy(How = How.LinkText, Using = "Underwriters")]
        public IWebElement UnderwritersMenu { get; set; }

        #endregion

        #region - Recursive Methods
        public OfficeSetupPayeeAssignments WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LinkPayeeAssignments, 10);
            return this;
        }

        #endregion
    }

    public class OfficeSetupUnderwriters : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "Office")]
        public IWebElement LinkOffice { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_dgridUnderwriterSummary")]
        public IWebElement TableUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_btnNew")]
        public IWebElement UnderwritersNew { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_btnDelete")]
        public IWebElement UnderwritersRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_cboUWName")]
        public IWebElement UnderwriterName { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_cboUWNameNew")]
        public IWebElement UnderwriterName1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtSplitFeePct")]
        public IWebElement PremiumPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_chkUnderWriter")]
        public IWebElement UseAsDefaultUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_Button1")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_idPolicyNumType")]
        public IWebElement UseFASTFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_idPolicyRangeType")]
        public IWebElement UsePolicyNumberRange { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtPolicyPrefix1")]
        public IWebElement PolicyPrefix1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtPolicyNumStart1")]
        public IWebElement PolicyRangeFrom1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtPolicyNumEnd1")]
        public IWebElement PolicyRangeTo1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtPolicyPrefix2")]
        public IWebElement PolicyPrefix2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtPolicyNumStart2")]
        public IWebElement PolicyRangeFrom2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Underwriter1_txtPolicyNumEnd2")]
        public IWebElement PolicyRangeTo2 { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusinessUnitCd: Cannot add office. The Office ID Code already exists within this processing region.")]
        public IWebElement ErrorPane { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Error1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Office")]
        public IWebElement OfficeMenu { get; set; }

        [FindsBy(How = How.LinkText, Using = "Bank Accounts")]
        public IWebElement BankAccountsMenu { get; set; }

        [FindsBy(How = How.LinkText, Using = "Payee Assignments")]
        public IWebElement PayeeAssignmentsMenu { get; set; }

        [FindsBy(How = How.LinkText, Using = "Underwriters")]
        public IWebElement UnderwritersMenu { get; set; }

        #endregion

        public OfficeSetupUnderwriters WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? UnderwritersNew);
            return this;
        }

    }
}
