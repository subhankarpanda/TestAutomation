using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
	public class OfficeSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "comboStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "dgridOfficeListSummary")]
		public IWebElement OfficeSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdViewChangeStatus")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }
        
        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyComp_cmdRemoveBusParty")]
        public IWebElement PaymentsAssignmentsTab_Remove { get; set; }
        
        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_labelIdcode")]
        public IWebElement PaymentsAssignmentsTab_DefaultRecordingFeeIDCode { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_OfficeSetup_Payee1_abusPartyCompRecFees_labelName")]
        public IWebElement PaymentsAssignmentsTab_DefaultRecordingFeeName1 { get; set; }
        
        #endregion

        #region - Recursive Methods
        public OfficeSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }
        public OfficeSummary Open(string ProcRegion="STEST")
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>" + ProcRegion + ">Offices");
                this.WaitForScreenToLoad();
            }
            catch
            {
                Thread.Sleep(5000);
                FastDriver.LeftNavigation.Navigate<OfficeSummary>("Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>" + ProcRegion + ">Offices");
                this.WaitForScreenToLoad();
            }
            return this;
        }
        public string EditOffice(string BUID)
        {
            string OfficeName = "";
            if (this.OfficeSummaryTable.FAGetText().Contains(BUID))
            {
                OfficeName=this.OfficeSummaryTable.PerformTableAction("BUID", BUID, "Name", TableAction.GetText).Message;
                this.OfficeSummaryTable.PerformTableAction("BUID", BUID, "BUID", TableAction.Click);
                this.Edit.FAClick();
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
            }
            else
                Reports.StatusUpdate("Office having BUID "+BUID+" is not present",false);
            return OfficeName;
        }
        #endregion

    }
}
