﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
    public class OfiiceGroupOfficeSelectionDlg : PageObject
    {
        #region Web Elements
        [FindsBy(How = How.Id, Using = "rdoOfficeGroup")]
        public IWebElement OfficeGroups { get; set; }

        [FindsBy(How = How.Id, Using = "rdoOffice")]
        public IWebElement Office { get; set; }

        [FindsBy(How = How.Id, Using = "btnCheckAll")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdOffSel_grdOffSel")]
        public IWebElement OfficeAndGroupTable { get; set; }
        public IWebElement GetSelect(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("grdOffSel_" + index + "_chkSelOff"));
        }
        #endregion

        public OfiiceGroupOfficeSelectionDlg WaitForScreenToLoad(string windowName = "Office Group/Office Selection")
        {
            this.WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(OfficeAndGroupTable);

            return this;
        }
    }
}
