using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class OpenOrderDocumentCopies : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDocumentCopies_0_txtNoOfCopies")]
		public IWebElement DefaultCopies { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDocumentCopies")]
		public IWebElement DocumentNameTable { get; set; }

		#endregion

        #region 
        public OpenOrderDocumentCopies WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Edit);
            return this;
        }
        #endregion

    }
}
