using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class OrderListFormatDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboFormat")]
        public IWebElement Format { get; set; }

        [FindsBy(How = How.Id, Using = "cboLevel")]
        public IWebElement Level { get; set; }

        [FindsBy(How = How.Id, Using = "chkStart")]
        public IWebElement Start { get; set; }

        [FindsBy(How = How.Id, Using = "btnOk")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "cmdsave")]
        public IWebElement btnOK { get; set; }


        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        #endregion

        public OrderListFormatDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Format);

            return this;
        }

    }
}
