using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.ADM
{
	public class PendingRefreshSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlProcessType")]
		public IWebElement ProcType { get; set; }

		[FindsBy(How = How.Id, Using = "btnRefresh")]
		public IWebElement RefreshProcess { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProcessSmry_0_chkSelect")]
        public IWebElement ProcessSmrySelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessSmry_dgridProcessSmry")]
		public IWebElement SummaryTable { get; set; }

		#endregion

        public PendingRefreshSummary WaitForProcessCreation()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ProcessSmrySelect);
            return this;
        }

        public bool WaitForRefeshComplete(int timeout)
        {
            int count = 0;

            if (FastDriver.PendingRefreshSummary.ProcessSmrySelect.Displayed == false) // check if it's displayed for the first time, failed if it's not.
                return false;

            do
            {
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Pending Refresh Summary");
                FastDriver.AddressBookSearch.SwitchToContentFrame();
                try 
                {
                    if (FastDriver.PendingRefreshSummary.ProcessSmrySelect.Displayed == true)
                    {
                        Thread.Sleep(20000);
                        count = count + 20;
                    }
                }
                catch {
                    return true;
                }

            }
            while (count < timeout);

            return false;
        }

        public PendingRefreshSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryTable);
            return this;
        }

        public bool RefreshTemplate(string templateName)
        {
            bool ret = false;
            try
            {
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>("Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                    return FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(templateName);
                }, timeout: 45, idleInterval: 5);
                FastDriver.PendingRefreshSummary.WaitForScreenToLoad();
                FastDriver.PendingRefreshSummary.SummaryTable.PerformTableAction(2, templateName, 1, TableAction.On);
                FastDriver.PendingRefreshSummary.RefreshProcess.FAClick();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>("Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                    return !FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(templateName);
                }, timeout: 300, idleInterval: 20);
                ret = true;
            }
            catch (WebDriverTimeoutException)
            {
                ret = false;
            }

            return ret;
        }

        public PendingRefreshSummary Open()
        {
            return FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>("Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
        }

        public bool RefreshProcessTemplate(string templateName)
        {
            int retryAttempts = 0;
            bool ret = false;
            try
            {
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    this.Open();
                    if (!SummaryTable.Text.Contains(templateName))
                    {
                        retryAttempts++;
                        //return true if the process do not appear after 3 attempts
                        if (retryAttempts > 3)
                            return true;
                        //return false to retry action
                        return false;
                    }
                    else
                    {
                        this.WaitForScreenToLoad();
                        SummaryTable.PerformTableAction(2, templateName, 1, TableAction.On);
                        RefreshProcess.FAClick();
                        return true;
                    }
                }, timeout: 45, idleInterval: 5);

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    this.Open();
                    return !SummaryTable.Text.Contains(templateName);
                }, timeout: 600, idleInterval: 20);
                ret = true;
            }
            catch (WebDriverTimeoutException)
            {
                ret = false;
            }

            return ret;
        }
    }
}
