using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class PhraseConditionsDlg : PageObject
	{
        public string WindowTitle { get { return "Phrase Conditions"; } }

		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "optlCondition_0")]
		public IWebElement AND { get; set; }

		[FindsBy(How = How.Id, Using = "optlCondition_1")]
		public IWebElement OR { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_0_txtName")]
		public IWebElement DataElement { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_0_txtIndex")]
		public IWebElement Index { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_0_cmdDataElmt")]
		public IWebElement SelectDataElement { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_0_cboOperator")]
		public IWebElement Operator { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_0_txtValue")]
		public IWebElement Value { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_1_txtName")]
		public IWebElement DataElmts1Name { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_1_txtIndex")]
		public IWebElement DataElmts1Index { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_1_cmdDataElmt")]
		public IWebElement Index1Button { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_1_cboOperator")]
		public IWebElement DataEmts1Operator { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_1_txtValue")]
		public IWebElement DataElmts1Value { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_2_txtName")]
		public IWebElement DataElmts2Name { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_2_txtIndex")]
		public IWebElement DataElmts2Index { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_2_cmdDataElmt")]
		public IWebElement Index2Button { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_2_cboOperator")]
		public IWebElement DataEmts2Operator { get; set; }

		[FindsBy(How = How.Id, Using = "dgridDataElmts_2_txtValue")]
		public IWebElement DataElmts2Value { get; set; }


        public void ClickAutoOutline()
        {
            #region Workaround to click the Open button
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var OpenButton = new System.Drawing.Point(300, 35);
            Microsoft.VisualStudio.TestTools.UITesting.Mouse.Move(OpenButton);                                                                    // Move to numlist icon
            Microsoft.VisualStudio.TestTools.UITesting.Mouse.Click(OpenButton);                                                                    // click on numlist icon
		#endregion
        }

        public void ClickPropertyIcon()
        {
            #region Workaround to click the Open button
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var OpenButton = new System.Drawing.Point(240, 35);            
            Microsoft.VisualStudio.TestTools.UITesting.Mouse.Move(OpenButton);                                                                    // Move to prop icon
            Microsoft.VisualStudio.TestTools.UITesting.Mouse.Click(OpenButton);                                                                    // click on prop icon
            #endregion
        }
		#endregion

        public PhraseConditionsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(WindowTitle, true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Add);

            return this;
        }

        public PhraseConditionsDlg EnterCondition(int row, string dataElement = null, string index = null, string _operator = null, string value = null)
        {
            switch (row)
            {
                case 1:
                    WaitForScreenToLoad(DataElement);
                    DataElement.FASetText(dataElement);
                    Index.FASetText(index);
                    Operator.FASelectItem(_operator);
                    Value.FASetText(value);
                    break;
                case 2:
                    WaitForScreenToLoad(DataElmts1Name);
                    DataElmts1Name.FASetText(dataElement);
                    DataElmts1Index.FASetText(index);
                    DataEmts1Operator.FASelectItem(_operator);
                    DataElmts1Value.FASetText(value);
                    break;
                case 3:
                    WaitForScreenToLoad(DataElmts2Name);
                    DataElmts2Name.FASetText(dataElement);
                    DataElmts2Index.FASetText(index);
                    DataEmts2Operator.FASelectItem(_operator);
                    DataElmts2Value.FASetText(value);
                    break;
            }

            return this;
        }
	}
}
