using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class PhraseCopy : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCopy")]
		public IWebElement Copy { get; set; }

		[FindsBy(How = How.Id, Using = "chkAll")]
		public IWebElement CopyFromPhrases_All { get; set; }

		[FindsBy(How = How.Id, Using = "cboFrmGrp")]
		public IWebElement CopyFromPhrases_PhraseGroup { get; set; }

		[FindsBy(How = How.Id, Using = "cboToGrp")]
		public IWebElement CopyToPhrases_PhraseGroup { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_chkPhrse")]
		public IWebElement CopyFromPhrases_Select { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_txtFGNme")]
		public IWebElement CopyFromPhrases_GroupName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_txtPNme")]
		public IWebElement CopyFromPhrases_PhraseName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_txtTGNme")]
		public IWebElement CopyToPhrases_GroupName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_1_txtTGNme")]
		public IWebElement CopyToPhrases_GroupName1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_2_txtTGNme")]
		public IWebElement CopyToPhrases_GroupName2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_cmdSGrp")]
		public IWebElement CopyToPhrases_SelectGroup { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_1_cmdSGrp")]
		public IWebElement CopyToPhrases_SelectGroup1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_txtTPNme")]
		public IWebElement CopyToPhrases_PhraseName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPharses_0_txtTDescr")]
		public IWebElement CopyToPhrases_Description { get; set; }

		[FindsBy(How = How.LinkText, Using = "DUP")]
		public IWebElement CopyStatus_DUP { get; set; }

		[FindsBy(How = How.LinkText, Using = "OK")]
		public IWebElement CopyStatus_OK { get; set; }

		[FindsBy(How = How.LinkText, Using = "ERR")]
		public IWebElement CopyStatus_ERR { get; set; }

		#endregion

        public PhraseCopy Open()
        {
            FastDriver.LeftNavigation.Navigate<PhraseCopy>("Home>System Maintenance>Document Preparation>Phrase Copy");
            this.WaitForScreenToLoad();

            return this;
        }

        public PhraseCopy WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Copy);

            return this;
        }
	}
}
