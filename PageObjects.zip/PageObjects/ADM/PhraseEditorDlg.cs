using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Interactions;

namespace FASTSelenium.PageObjects.ADM
{
    public class PhraseEditorDlg : PageObject
    {
        public string WindowTitle { get { return "Editor"; } }

        #region WebElements

        //[FindsBy(How = How.LinkText, Using = "/smsfast/images/props.GIF")]
        [FindsBy(How = How.XPath, Using = "//img[contains(@src, 'props.GIF')]")]
        public IWebElement ShowPropertiesElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Find.GIF')]")]
        public IWebElement FindElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'AddItem.GIF')]")]
        public IWebElement InsertDataElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'instable.GIF')]")]
        public IWebElement InsertTableElement { get; set; }

        [FindsBy(How = How.Id, Using = "cboFontName")]
        public IWebElement FontName { get; set; }

        [FindsBy(How = How.Id, Using = "cboFontSize")]
        public IWebElement FontSize { get; set; }

        [FindsBy(How = How.Id, Using = "cboSymbols")]
        public IWebElement Symbols { get; set; }

        [FindsBy(How = How.Id, Using = "cboOutlineList")]
        public IWebElement OutlineList { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Spell.gif')]")]
        public IWebElement SpellCheck { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Cut.GIF')]")]
        public IWebElement Cut { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Copy.GIF')]")]
        public IWebElement Copy { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Paste.GIF')]")]
        public IWebElement Paste { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Undo.GIF')]")]
        public IWebElement Undo { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Redo.GIF')]")]
        public IWebElement Redo { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Find.GIF')]")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.LinkText, Using = "1BUSPFNAMa")]
        public IWebElement Text { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Bold.GIF')]")]
        public IWebElement Bold { get; set; }

        [FindsBy(How = How.Id, Using = "DECMD_BOLD")]
        public IWebElement BoldButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'Italic.GIF')]")]
        public IWebElement Italic { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'under.GIF')]")]
        public IWebElement Underline { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#DECMD_SETBACKCOLOR > img")]
        public IWebElement Highlight { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'DeIndent.GIF')]")]
        public IWebElement LeftIndent { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'inindent.GIF')]")]
        public IWebElement RightIndent { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'ico_break.gif')]")]
        public IWebElement PageBreak { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'ico_numlist.gif')]")]
        public IWebElement AutoOutline { get; set; }

        [FindsBy(How = How.Id, Using = "tbContentElement")]
        public IWebElement TextArea { get; set; }

        [FindsBy(How = How.XPath, Using = "//body/p")]
        public IWebElement TextEditorArea { get; set; }

        #endregion

        public PhraseEditorDlg WaitForScreenToLoad(IWebElement element = null, string windowName = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName ?? WindowTitle, true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FontName);

            return this;
        }

        public PhraseEditorDlg SwitchToTextEditorArea()
        {
            //WebDriver.WaitForWindowAndSwitch(windowName ?? WindowTitle, true, 30);
            this.SwitchToPhraseEditorContentFrame(switchToFraPageWin: true);

            this.WaitCreation(TextEditorArea);

            return this;
        }
    }
}
