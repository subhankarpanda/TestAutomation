using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
	public class PhraseGroupMaintenance : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

		[FindsBy(How = How.Id, Using = "txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement Descritption { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseDesc")]
        public IWebElement PhraseDescritption { get; set; }
        
		[FindsBy(How = How.Id, Using = "cboPhraseType")]
		public IWebElement PhraseType { get; set; }

		[FindsBy(How = How.Id, Using = "chkApp2All")]
		public IWebElement ApplytoallPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "txtCmt")]
		public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseComments")]
        public IWebElement PhraseComments { get; set; }
        
		[FindsBy(How = How.Id, Using = "ucGMT_cboName")]
		public IWebElement FontNameTYPE { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_cboSize")]
		public IWebElement FontSize { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtTop")]
		public IWebElement MarginTop { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtLeft")]
		public IWebElement MarginLeft { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtRght")]
		public IWebElement MarginRight { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_optAct")]
		public IWebElement Active { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_optInAct")]
		public IWebElement Inactive { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtCmt")]
		public IWebElement StatusChangeComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_cmdCopy")]
		public IWebElement Copy { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_cmdSave")]
		public IWebElement Save { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_cmdCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "lblName")]
		public IWebElement Namepane { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_dgridMaint_1_lblStatus")]
		public IWebElement PhraseStatus { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_lblCrBy")]
		public IWebElement Createdby { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_dgridMaint_dgridMaint")]
		public IWebElement PhrasesTable { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_dgridMaint_0_hdnCopyName")]
		public IWebElement Copyphrasename { get; set; }

		[FindsBy(How = How.Id, Using = "ucSrch_dgridMaint_0_hdnCopyDescr")]
		public IWebElement Copyphrasedescription { get; set; }

		[FindsBy(How = How.LinkText, Using = "Error[PhraseGrp]: Phrase Group Name already exists. Please enter a new Name.")]
		public IWebElement Duplicatephrasegrp { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_lblCrDt")]
		public IWebElement CreatedDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseName")]
        public IWebElement PhraseName { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_chkFullJtfy")]
        public IWebElement Formatting_FullJustify { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_chkKLTghr")]
        public IWebElement Formatting_KeepLinesTogether { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_chkLTPPhrase")]
        public IWebElement Formatting_LinkToPreviousPhrase { get; set; }

        public IWebElement GetPhrase(int index = 1)
        {
            return this.WebDriver.FindElement(By.Id("ucSrch_dgridMaint_" + index));
        }

		#endregion

        public PhraseGroupMaintenance WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Descritption);

            return this;
        }

        public void EnterGroupPhraseMaintenanceData(string name = null, string description = null, string phraseType = null, string comments = null, string fontNameType = null, string fontSize = null, string marginTop = null, string marginLeft = null, string marginRight = null, bool applyToAllPhrases = false)
        {
            if (name != null)
                this.Name.FASetText(name);
            if (description != null)
                this.Descritption.FASetText(description);
            if (phraseType != null)
                this.PhraseType.FASelectItem(phraseType);
            if (comments != null)
                this.Comments.FASetText(comments);
            if (fontNameType != null)
                this.FontNameTYPE.FASelectItem(fontNameType);
            if (fontSize != null)
                this.FontSize.FASelectItem(fontSize);
            if (marginTop != null)
                this.MarginTop.FASetText(marginTop);
            if (marginLeft != null)
                this.MarginLeft.FASetText(marginLeft);
            if (marginRight != null)
                this.MarginRight.FASetText(marginRight);
            this.ApplytoallPhrases.FASetCheckbox(applyToAllPhrases);
        }
        //
        public string CreateNewPhraseGroup(string PhraseType = "Escrow Phrase")
        {
            FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
            string PhraseGroup = Support.RandomString("AZAZ");
            string PhraseGroupDescription = "Phrase Group Description" + PhraseGroup;
            string Comments = PhraseGroupDescription;
            FastDriver.PhraseGroupMaintenance.EnterGroupPhraseMaintenanceData(PhraseGroup, PhraseGroupDescription, PhraseType, Comments, applyToAllPhrases: true);
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad(FastDriver.PhraseGroupMaintenance.Add);
            return PhraseGroup;
        }
	}
}
