using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class PhraseGroupMaintenanceSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "summry_dgridMaint_0")]
        public IWebElement SearchResult { get; set; }

        [FindsBy(How = How.Id, Using = "scrh_cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "scrh_cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "scrh_cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "scrh_cboGrpType")]
        public IWebElement PhraseGroupType { get; set; }

        [FindsBy(How = How.Id, Using = "scrh_cboGrpStatus")]
        public IWebElement PhraseGroupStatua { get; set; }

        [FindsBy(How = How.Id, Using = "scrh_txtDesc")]
        public IWebElement PhraseGroupDescription { get; set; }

        [FindsBy(How = How.Id, Using = "summry_cmdEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "summry_cmdDelete")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.Id, Using = "summry_dgridMaint_dgridMaint")]
        public IWebElement SearchresultSummarytable { get; set; }

        [FindsBy(How = How.LinkText, Using = "To be changed dynamically")]
        public IWebElement PhraseGroupName { get; set; }

        public IWebElement GetSearchResult(int index)
        {
            return this.WebDriver.FindElement(By.Id("summry_dgridMaint_" + index));
        }

        #endregion

        public PhraseGroupMaintenanceSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance");
            this.WaitForScreenToLoad();

            return this;
        }

        public PhraseGroupMaintenanceSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);

            return this;
        }

        public IWebElement SearchForPhraseGroup(string type, string description)
        {
            this.PhraseGroupType.FASelectItem(type);
            this.PhraseGroupDescription.FASetText(description);
            this.FindNow.FAClick();
            this.WaitCreation(this.SearchResult);
            this.SearchResult.FAClick();

            return this.SearchResult;
        }

        public void DeletePhraseGroup(string type, string description)
        {
            SearchForPhraseGroup(type, description);
            this.Delete.FAClick();
        }

        public void EditPhraseGroup(string type, string description)
        {
            this.PhraseGroupType.FASelectItem(type);
            this.PhraseGroupDescription.FASetText(description);
            this.FindNow.FAClick();
            this.WaitCreation(SearchResult);
            this.SearchresultSummarytable.PerformTableAction(2, description, 2, TableAction.Click);
            this.Edit.FAClick();
        }
    }
}
