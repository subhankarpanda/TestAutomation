using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class PhraseMaintenance : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdPhraseEditor")]
		public IWebElement PhraseEditor { get; set; }

		[FindsBy(How = How.Id, Using = "chkEditable")]
		public IWebElement Editable { get; set; }

		[FindsBy(How = How.Id, Using = "chkUnderConst")]
		public IWebElement UnderConstruction { get; set; }

		[FindsBy(How = How.Id, Using = "txtPhraseName")]
		public IWebElement PhraseName { get; set; }

		[FindsBy(How = How.Id, Using = "txtPhraseDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "txtPhraseComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_cboName")]
		public IWebElement Formatting_Name { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_cboSize")]
		public IWebElement Formatting_Size { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtTop")]
		public IWebElement Formatting_MarginTop { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtLeft")]
		public IWebElement Formatting_MarginLeft { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtRght")]
		public IWebElement Formatting_MarginRight { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_chkFullJtfy")]
		public IWebElement Formatting_FullJustify { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_chkKLTghr")]
		public IWebElement Formatting_KeepLinesTogether { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_chkLTPPhrase")]
		public IWebElement Formatting_LinkToPreviousPhrase { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_optAct")]
		public IWebElement Status_Active { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_optInAct")]
		public IWebElement Status_Inactive { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_txtCmt")]
		public IWebElement Status_StatusChangeComments { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_dgridRevHstry_0_lblRBy")]
		public IWebElement Revisedby { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_dgridRevHstry_0_lblCmnts")]
		public IWebElement Statuschangecomments { get; set; }

		[FindsBy(How = How.Id, Using = "ucGMT_dgridRevHstry_0_lblRDate")]
		public IWebElement RevisedDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "ucGMT_dgridRevHstry_dgridRevHstry")]
        public IWebElement RevisionHistoryTable { get; set; }

        public IWebElement GetPhrase(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("ucGMT_dgridRevHstry_" + index));
        }

		#endregion

        public PhraseMaintenance WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);

            return this;
        }

        public void EnterPhraseMaintenanceData(string phraseName = null, string description = null, string comments = null, bool formatting_fullJustify = true, bool formatting_keepLinesTogether = true, bool Formatting_LinkToPreviousPhrase = true, string formatting_Name = null, string formatting_Size = null, string formatting_MarginTop = null, string formatting_MarginLeft = null, string formatting_MarginRight = null, bool editable = true, bool underConstruction = false)
        {
            this.Editable.FASetCheckbox(editable);
            this.UnderConstruction.FASetCheckbox(underConstruction);
            if (phraseName != null)
                this.PhraseName.FASetText(phraseName);
            if (description != null)
                this.Description.FASetText(description);
            if (comments != null)
                this.Comments.FASetText(comments);
            if (formatting_Name != null)
                this.Formatting_Name.FASelectItem(formatting_Name);
            if (formatting_Size != null)
                this.Formatting_Size.FASelectItem(formatting_Size);
            this.Formatting_MarginTop.FASetText(formatting_MarginTop);
            this.Formatting_MarginLeft.FASetText(formatting_MarginLeft);
            this.Formatting_MarginRight.FASetText(formatting_MarginRight);
            this.Formatting_FullJustify.FASetCheckbox(formatting_fullJustify);
            this.Formatting_KeepLinesTogether.FASetCheckbox(formatting_keepLinesTogether);
            this.Formatting_LinkToPreviousPhrase.FASetCheckbox(Formatting_LinkToPreviousPhrase);
        }
        //
        public string CreateNewPhrase(string DataElementGroup, List<string> DataElements)
        {
            FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            string phraseName = Support.RandomString("ZAZA");
            string PhraseDesc = "Description for phrase" + phraseName;
            string Comments = PhraseDesc;
            try
            {
                FastDriver.PhraseMaintenance.EnterPhraseMaintenanceData(phraseName: phraseName, description: PhraseDesc, comments: Comments);
                FastDriver.BottomFrame.Save();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                FastDriver.PhraseMaintenance.PhraseEditor.FAClick();
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();
                FastDriver.DataElementSelectionDlg.DataElementGroup.FASelectItem(DataElementGroup);
                Thread.Sleep(5000);
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad(element: FastDriver.DataElementSelectionDlg.SearchResultsTable);
                foreach (string DataElement in DataElements)
                {
                    FastDriver.DataElementSelectionDlg.SearchResultsTable.PerformTableAction(1, DataElement, 1, TableAction.DoubleClick);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                Thread.Sleep(4000);
                Dictionary<string, int> DataElementCount = new Dictionary<string, int>();
                foreach (string DataElement in DataElements)
                {
                    int count = DataElements.Where(x => x.Equals(DataElement)).Count();
                    if (DataElementCount.ContainsKey(DataElement))
                        continue;
                    if (count > 1)
                        DataElementCount.Add(DataElement, count);
                }
                foreach (var DictionaryItem in DataElementCount)
                {
                    int c = 97;
                    for (int i = 1; i <= DictionaryItem.Value; i++)
                    {
                        FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                        Thread.Sleep(2000);
                        FastDriver.PhraseEditorDlg.Find.FAClick();
                        FastDriver.FindDlg.WaitForScreenToLoad();
                        FastDriver.FindDlg.TextToFind.FASetText(DictionaryItem.Key + Convert.ToChar(c));
                        FastDriver.FindDlg.FindNext.FAClick();
                        c++;
                        Thread.Sleep(2000);
                        FastDriver.FindDlg.Cancel.FAClick();
                        //
                        FastDriver.PhraseEditorDlg.WaitForScreenToLoad();
                        FastDriver.PhraseEditorDlg.ShowPropertiesElement.FAClick();
                        Thread.Sleep(3000);
                        //
                        FastDriver.DataElementsDlg.WaitForScreenToLoad();
                        FastDriver.DataElementsDlg.Index.FASetText(i.ToString());
                        FastDriver.DataElementsDlg.Ok.FAClick();
                        Thread.Sleep(2000);
                    }
                }
                FastDriver.DialogBottomFrame.ClickSave();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                Thread.Sleep(3000);
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad(element: FastDriver.PhraseEditorDlg.InsertDataElement);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
            }
            catch
            {
                throw;
            }
            return phraseName;
        }
	}
	public class PhraseMaintenancetitle : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "Error[PhraseGrp]: Phrase Name already exists. Please enter a new Name.")]
		public IWebElement DupPhrase { get; set; }

		#endregion

	}
}
