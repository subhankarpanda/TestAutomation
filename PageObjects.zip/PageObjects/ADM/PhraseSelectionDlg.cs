using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.ADM
{
    public class PhraseSelectDlg : PageObject
    {
        public string WindowTitle { get { return "Phrase Selection"; } }

        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdView")]
        public IWebElement ViewText { get; set; }

        [FindsBy(How = How.Id, Using = "cboSource")]
        public IWebElement Source { get; set; }

        [FindsBy(How = How.Id, Using = "txtSearchEntry")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseKeywordSearch")]
        public IWebElement Keyword { get; set; }


        [FindsBy(How = How.Id, Using = "cmdSrch")]
        public IWebElement Search { get; set; }

        [FindsBy(How = How.Id, Using = "cboPhraseType")]
        public IWebElement PhraseType { get; set; }

        [FindsBy(How = How.Id, Using = "cboPhraseGrp")]
        public IWebElement PhraseGroup { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhraseEntry")]
        public IWebElement PhraseName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTemplate_dgridTemplate")]
        public IWebElement ResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTemplate_0_lblName")]
        public IWebElement ResultsTableName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTemplate_0_lblID")]
        public IWebElement SearchResult { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }
        #endregion

        #region Services

        public PhraseSelectDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Phrase Selection");
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Description);

            return this;
        }

        public PhraseSelectDlg EnterPhraseInformation(string name, string description = null, string type = null, string group = null)
        {
            WaitForScreenToLoad(PhraseName);

            PhraseName.FASetText(name);
            Description.FASetText(description);
            PhraseType.FASelectItem(type);
            Playback.Wait(1000);
            PhraseGroup.FASelectItem(group);
            //anyone can add more interaction steps, just add optional patameters and default to null

            return this;
        }

        #endregion

    }
}
