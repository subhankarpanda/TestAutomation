using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class PreviousSessionsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSIMSession_dgridSIMSession")]
		public IWebElement SessionNameTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSIMSession_0_lblSessionName")]
		public IWebElement SessionName { get; set; }

		#endregion

        public PreviousSessionsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? SessionNameTable);
            return this;
        }

	}
}
