using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProblemListDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSelProb_0_chkSelProb")]
		public IWebElement SelectProblem1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_1_chkSelProb")]
		public IWebElement SelectProblem2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_2_chkSelProb")]
		public IWebElement SelectProblem3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_3_chkSelProb")]
		public IWebElement SelectProblem4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_4_chkSelProb")]
		public IWebElement SelectProblem5 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_5_chkSelProb")]
		public IWebElement SelectProblem6 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_6_chkSelProb")]
		public IWebElement SelectProblem7 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_7_chkSelProb")]
		public IWebElement SelectProblem8 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb")]
		public IWebElement ProblemTable { get; set; }

		#endregion


        public ProblemListDlg WaitForScreenToLoad(IWebElement element = null)
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                //this.SwitchToDialogContentFrame();
                this.WaitForFrameAndSwitchByFrameId(GetTopDialogFrameId());
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
                this.WaitCreation(element ?? ProblemTable);
            }
            catch (Exception e)
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                this.WaitForFrameAndSwitchByFrameId(GetTopDialogFrameId());
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
                this.WaitCreation(element ?? ProblemTable);
            }

            return this;
        }


        private static string GetTopDialogFrameId()
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                var elements = FastDriver.WebDriver.FindElements(By.XPath("//iframe[@class='dialog-iframe'][starts-with(@id, 'FAFDialog_')]"));
                return elements.LastOrDefault().GetAttribute("id");
            }
            catch (Exception)
            {
                return "";
            }
        }

	}
}
