using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProcessEventSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_0_chkSelEvent")]
		public IWebElement Actionrequired { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_1_chkSelEvent")]
		public IWebElement Actionrequiredtocompletesearch { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_2_chkSelEvent")]
		public IWebElement DateDown_New { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_3_chkSelEvent")]
		public IWebElement DateDown { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_4_chkSelEvent")]
		public IWebElement DocumentDeliveredbyTemplateID { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_5_chkSelEvent")]
		public IWebElement EscrowServiceAdded { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_6_chkSelEvent")]
		public IWebElement EscrowServiceRemoved { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_7_chkSelEvent")]
		public IWebElement ExternalSystemResponse { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_8_chkSelEvent")]
		public IWebElement FilecreatedwithOpenstatus { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_9_chkSelEvent")]
		public IWebElement FilecreatedwithPendingStatus { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_10_chkSelEvent")]
		public IWebElement FileStatusChangetoClosed { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_11_chkSelEvent")]
		public IWebElement FileStatuschangestoopen { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_12_chkSelEvent")]
		public IWebElement Final_AdjustedInvoice { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_13_chkSelEvent")]
		public IWebElement FirstFeeTransferIssued { get; set; }

        //Id changed from 14 to 16
        [FindsBy(How = How.Id, Using = "dgridProcessEvents_16_chkSelEvent")]
		public IWebElement FirstInvoiceFinalized { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_15_chkSelEvent")]
		public IWebElement HoldFunds_ActiveDisbursements { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_16_chkSelEvent")]
		public IWebElement HoldFunds_EscrowChargeProcess { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_17_chkSelEvent")]
		public IWebElement HomeOwnersAssociation { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_18_chkSelEvent")]
		public IWebElement HomeWarranty { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_19_chkSelEvent")]
		public IWebElement HUD_1ApprovalReceived { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_20_chkSelEvent")]
		public IWebElement HUD_1RevisionRequest { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_21_chkSelEvent")]
		public IWebElement ImageTrigger { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_22_chkSelEvent")]
		public IWebElement Insurance { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_23_chkSelEvent")]
		public IWebElement ModifiedHUD_1Received { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_24_chkSelEvent")]
		public IWebElement PayoffLender { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_25_chkSelEvent")]
		public IWebElement PestInspection { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_26_chkSelEvent")]
		public IWebElement RELPropAdded { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_27_chkSelEvent")]
		public IWebElement REPPropAdded { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_28_chkSelEvent")]
		public IWebElement ReviewFileProcess { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_29_chkSelEvent")]
		public IWebElement SDNOFAC { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_30_chkSelEvent")]
		public IWebElement Searchdocumentreturned { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_31_chkSelEvent")]
		public IWebElement SearchVendorAdded { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_32_chkSelEvent")]
		public IWebElement SecondOrderSourcedded { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_33_chkSelEvent")]
		public IWebElement SignatureSigningCreated { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_34_chkSelEvent")]
		public IWebElement SubsequentInvoiceFinalized { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_35_chkSelEvent")]
		public IWebElement Survey { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_36_chkSelEvent")]
		public IWebElement TitleServiceAdded { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_37_chkSelEvent")]
		public IWebElement TitleServiceRemoved { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_38_chkSelEvent")]
		public IWebElement Utility { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_39_chkSelEvent")]
		public IWebElement WireFailure { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_40_chkSelEvent")]
		public IWebElement WorkQueueTriggerName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProcessEvents_41_chkSelEvent")]
		public IWebElement WorkQueueTriggerName2 { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "grdProperty_0_chkSelProp")]
		public IWebElement grdProperty0SelProp { get; set; }

		[FindsBy(How = How.Id, Using = "grdProperty_1_chkSelProp")]
		public IWebElement grdProperty1SelProp { get; set; }
        
		[FindsBy(How = How.Id, Using = "dgridProcessEvents_dgridProcessEvents")]
		public IWebElement ProcessEventTable1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdProperty_grdProperty")]
		public IWebElement SelectPropertyTable { get; set; }

		#endregion

        #region Useful Methods
        public ProcessEventSelectionDlg WaitForScreenToLoad(string windowName = "Process Event Selection")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ProcessEventTable1);
            return this;
        }
        #endregion

	}
}
