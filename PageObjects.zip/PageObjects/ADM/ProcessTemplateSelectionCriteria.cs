﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class ProcessTemplateSelectionCriteria : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlRoleType")]
        public IWebElement RoleType { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "lstOrderSource")]
        public IWebElement OrderSource { get; set; }

        [FindsBy(How = How.Id, Using = "lstsecondOrderSource")]
        public IWebElement SecondOrderSource { get; set; }

        [FindsBy(How = How.Id, Using = "ddlService")]
        public IWebElement Service { get; set; }

        [FindsBy(How = How.Id, Using = "lstBusSeg")]
        public IWebElement BusinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "lstTransType")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "btnState")]
        public IWebElement AddRemoveState { get; set; }

        [FindsBy(How = How.Id, Using = "btnCounty")]
        public IWebElement AddRemoveCounty { get; set; }

        [FindsBy(How = How.Id, Using = "btnCity")]
        public IWebElement AddRemoveCity { get; set; }

        [FindsBy(How = How.Id, Using = "btnProgType")]
        public IWebElement AddRemoveProgramType { get; set; }
        #endregion

        public ProcessTemplateSelectionCriteria WaitForScreenToLoad()
        {
            WebDriver.SwitchTo().DefaultContent();
            this.SwitchToDialogContentFrame();
            this.WaitCreation(RoleType, 30);
            return this;
        }
    }
}
