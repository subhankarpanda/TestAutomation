using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProcessTemplateTasksDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridWorkflowTasks_dgridWorkflowTasks")]
		public IWebElement TaskTable { get; set; }

		#endregion

        public ProcessTemplateTasksDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? TaskTable);
            return this;
        }
	}
}
