using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProcessingRegionSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNewReg")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cboCountryReg")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "txtRegCode")]
		public IWebElement RegionCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtNameReg")]
		public IWebElement RegionName { get; set; }

		[FindsBy(How = How.Id, Using = "txtCommentsReg")]
		public IWebElement RegionComments { get; set; }

		[FindsBy(How = How.Id, Using = "cmdStatusReg")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "chkTestOnlyReg")]
		public IWebElement TestOnlyRegion { get; set; }

		[FindsBy(How = How.Id, Using = "chkEnableDupReg")]
		public IWebElement EnableDuplicateCheck { get; set; }

		[FindsBy(How = How.Id, Using = "txtSplashImage")]
		public IWebElement SplashImage { get; set; }

		[FindsBy(How = How.Id, Using = "chkIsAgentRegion")]
		public IWebElement AgentRegion { get; set; }

		[FindsBy(How = How.Id, Using = "chkTrialBalanceNoteFlag")]
		public IWebElement EnableTrialBalance { get; set; }

		[FindsBy(How = How.Id, Using = "chkUploadWordExcelFlag")]
		public IWebElement UploadWordExcel { get; set; }

		[FindsBy(How = How.Id, Using = "txtEscrowTitleReg")]
		public IWebElement EscrowTitleBeginingNo { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayQFE")]
		public IWebElement DisplayQfeQreFhpNfe { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddBST")]
		public IWebElement BusinessSourceTypesAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDeleteBST")]
		public IWebElement BusinessSourceTypesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "txtNameBST")]
		public IWebElement BusinessSourceTypesName { get; set; }

		[FindsBy(How = How.Id, Using = "cmdStatusBST")]
		public IWebElement BusinessSourceTypesViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayBuyer")]
		public IWebElement DisplayInBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplaySeller")]
		public IWebElement DisplayInSeller { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddEB")]
		public IWebElement EmployedByAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDeleteEB")]
		public IWebElement EmployedByRemove { get; set; }

		[FindsBy(How = How.Id, Using = "txtNameEB")]
		public IWebElement EmployedByName { get; set; }

		[FindsBy(How = How.Id, Using = "cmdStatusEB")]
		public IWebElement EmployedByViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddRU")]
		public IWebElement RegionalUnderWritterAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDeleteRU")]
		public IWebElement RegionalUnderWritterRemove { get; set; }

		[FindsBy(How = How.Id, Using = "txtCodeRU")]
		public IWebElement RegionalUnderWritterUnderWritterCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtNameRU")]
		public IWebElement RegionalUnderWritterUnderWritterName { get; set; }

		[FindsBy(How = How.Id, Using = "txtLogoFileRU")]
		public IWebElement RegionalUnderWritterLogoFile { get; set; }

		[FindsBy(How = How.Id, Using = "txtSealFileRU")]
		public IWebElement RegionalUnderWritterSealFile { get; set; }

		[FindsBy(How = How.Id, Using = "txtSignFileRU")]
		public IWebElement RegionalUnderWritterSignatureFile { get; set; }

		[FindsBy(How = How.Id, Using = "cmdStatusRU")]
		public IWebElement RegionalUnderWritterViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "lblStatusRU")]
		public IWebElement RegionalUnderWritterStatus { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNewAdd")]
		public IWebElement AddressesNew { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCopyAdd")]
		public IWebElement AddressesCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDeleteAdd")]
		public IWebElement AddressesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_cboAddressType")]
		public IWebElement AddressDetailAddressType { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtAddrLine1")]
		public IWebElement AddressDetailAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtAddrLine2")]
		public IWebElement AddressDetailAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtAddrLine3")]
		public IWebElement AddressDetailAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtAddrLine4")]
		public IWebElement AddressDetailAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtCity")]
		public IWebElement AddressDetailCity { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_cboState")]
		public IWebElement AddressDetailState { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtZip")]
		public IWebElement AddressDetailZip { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_txtCounty")]
		public IWebElement AddressDetailCounty { get; set; }

		[FindsBy(How = How.Id, Using = "PhysicalAddressBook1_cboCountry")]
		public IWebElement AddressDetailCountry { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_cmdAddPhoneType")]
		public IWebElement PhonesAdd { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_cmdDeletePhone")]
		public IWebElement PhonesRemove { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_0_cboPhoneType")]
		public IWebElement PhonesBusinessPhonePhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_0_txtPhone")]
		public IWebElement PhonesBusinessPhoneNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_0_txtExtension")]
		public IWebElement PhonesBusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_0_txtComments")]
		public IWebElement PhonesBusinessPhoneComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_1_cboPhoneType")]
		public IWebElement PhonesBusinessFaxPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_1_txtPhone")]
		public IWebElement PhonesBusinessFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_1_txtExtension")]
		public IWebElement PhonesBusinessFaxExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_1_txtComments")]
		public IWebElement PhonesBusinessFaxComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_2_cboPhoneType")]
		public IWebElement PhonesEmailPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_2_txtPhone")]
		public IWebElement PhonesEmailNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_2_txtComments")]
		public IWebElement PhonesEmailComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_3_cboPhoneType")]
		public IWebElement PhonesPagerPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_3_txtPhone")]
		public IWebElement PhonesPagerNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_3_txtExtension")]
		public IWebElement PhonesPagerExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_3_txtComments")]
		public IWebElement PhonesPagerComments { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_4_cboPhoneType")]
		public IWebElement PhonesCellularPhoneType { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_4_txtPhone")]
		public IWebElement PhonesCellularNumber { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_4_txtExtension")]
		public IWebElement PhonesCellularExtension { get; set; }

		[FindsBy(How = How.Id, Using = "PhoneDetails1_gridPhoneTypes_4_txtComments")]
		public IWebElement PhonesCellularComments { get; set; }

		[FindsBy(How = How.Id, Using = "lblCodeReg")]
		public IWebElement RegionCodePane { get; set; }

		[FindsBy(How = How.Id, Using = "lblCorporationReg")]
		public IWebElement CorporationPane { get; set; }

		[FindsBy(How = How.Id, Using = "gridRegionalRW")]
		public IWebElement TableUnderwriter { get; set; }

		[FindsBy(How = How.Id, Using = "gridAddress_gridAddress")]
		public IWebElement TableAddress { get; set; }

		[FindsBy(How = How.Id, Using = "lblNextAvlblReg")]
		public IWebElement NextAvailablePane { get; set; }

		[FindsBy(How = How.Id, Using = "gridEmployedBy")]
		public IWebElement TableEmployedBy { get; set; }

		[FindsBy(How = How.LinkText, Using = "Name: The Region Name is required.")]
		public IWebElement ErrorPane1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "BusinessUnitCd: Cannot create region. The region code already exists within the corporation.")]
		public IWebElement ErrorPane2 { get; set; }

		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement WarningPane { get; set; }

		[FindsBy(How = How.Id, Using = "chkDisplayQFE")]
		public IWebElement DisplayBustype { get; set; }

		[FindsBy(How = How.Id, Using = "gridEmployedBy")]
		public IWebElement EmployedByTable { get; set; }

		[FindsBy(How = How.Id, Using = "cboStateOfDomicile")]
		public IWebElement StateOfDomicile { get; set; }

		#endregion

        public ProcessingRegionSetup WaitForScreenToLoad(IWebElement element=null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);

            return this;
        }
	}
}
