using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProductListDlg : PageObject
	{
        #region WebElements

        [FindsBy(How = How.CssSelector, Using = "button[value=\"CheckAll\"]")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "ddlPrdctType")]
        public IWebElement ProductType { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@value='ClearAll']")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProducts_0_chkSelPrdct")]
		public IWebElement ProductSelect1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProducts_2_chkSelPrdct")]
		public IWebElement ProductSelect2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProducts_8_chkSelPrdct")]
        public IWebElement ProductSelect3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProducts_dgridProducts")]
		public IWebElement Table { get; set; }

		#endregion

        public ProductListDlg WaitScreenToLoad(string WindowName = "Product List") {
         //   WebDriver.WaitForWindowAndSwitch(WindowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Table);

            return this;
        }
        //
        public bool AddProduct(string ProductName)
        {
            FastDriver.ProductListDlg.WaitScreenToLoad();
            FastDriver.ProductListDlg.Table.PerformTableAction(@"#2", ProductName, "#1", TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();
            return true;
        }
    }
}
