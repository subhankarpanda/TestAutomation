using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProductSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "Owner Policies")]
		public IWebElement OwnerPolicies { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOwnerpolicies_dgridOwnerpolicies")]
		public IWebElement OwnerTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Lender Policies")]
		public IWebElement LenderPolicies { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_0_chkSelLender")]
		public IWebElement ShowListSelectLender { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_dgridLenderpolicies")]
		public IWebElement LenderTable { get; set; }

		[FindsBy(How = How.Id, Using = "abProductsetup_dgridLenderpolicies_0_chkDefaultLender")]
		public IWebElement DefaultLender { get; set; }

		[FindsBy(How = How.LinkText, Using = "Other Products")]
		public IWebElement OtherProducts { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_0_chkSelOther")]
		public IWebElement ShowListSelectOther { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_0_chkdefaultOther")]
		public IWebElement DefaultOther { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_dgridOtherpolicies")]
		public IWebElement OtherTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_cmdOwnerUp")]
		public IWebElement Up { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_cmdOwnerDown")]
		public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "tabProductsetup_cmdLenderUp")]
        public IWebElement LenderUp { get; set; }

        [FindsBy(How = How.Id, Using = "tabProductsetup_cmdLenderDown")]
        public IWebElement LenderDown { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOwnerpolicies_0_chkSelPrdct")]
		public IWebElement ShowListSelectowner { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOwnerpolicies_0_radioOwner")]
		public IWebElement DefaultRadio { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_0_chkSelLender")]
		public IWebElement Lender1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_1_chkSelLender")]
		public IWebElement Lender2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_2_chkSelLender")]
		public IWebElement Lender3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_3_chkSelLender")]
		public IWebElement Lender4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_4_chkSelLender")]
		public IWebElement Lender5 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_5_chkSelLender")]
		public IWebElement Lender6 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_6_chkSelLender")]
		public IWebElement Lender7 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_4_chkDefaultLender")]
		public IWebElement DefaultLenderPolicy5 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_3_chkDefaultLender")]
		public IWebElement DefaultLenderPolicy4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_2_chkDefaultLender")]
		public IWebElement DefaultLenderPolicy3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_1_chkDefaultLender")]
		public IWebElement DefaultLenderPolicy2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridLenderpolicies_0_chkDefaultLender")]
		public IWebElement DefaultLenderPolicy1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_0_chkdefaultOther")]
		public IWebElement DefaultOtherProduct1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_1_chkdefaultOther")]
		public IWebElement DefaultOtherProduct2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_2_chkdefaultOther")]
		public IWebElement DefaultOtherProduct3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_3_chkdefaultOther")]
		public IWebElement DefaultOtherProduct4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_4_chkdefaultOther")]
		public IWebElement DefaultOtherProduct5 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_4_chkdefaultOther")]
		public IWebElement DefaultOtherProduct6 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_1_chkSelOther")]
		public IWebElement OtherProduct2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_2_chkSelOther")]
		public IWebElement OtherProduct3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_3_chkSelOther")]
		public IWebElement OtherProduct4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_4_chkSelOther")]
		public IWebElement OtherProduct5 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_5_chkSelOther")]
		public IWebElement OtherProduct6 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_8_chkSelOther")]
		public IWebElement OtherProduct9 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOtherpolicies_8_chkdefaultOther")]
		public IWebElement DefaultOtherProduct9 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOwnerpolicies_1_radioOwner")]
		public IWebElement DefaultOwner2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabProductsetup_dgridOwnerpolicies_1_chkSelPrdct")]
		public IWebElement OwnerPolicy2 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Guarantees")]
        public IWebElement Guarantees { get; set; }

        [FindsBy(How = How.Id, Using = "tabProductsetup_dgridGuaranteepolicies_dgridGuaranteepolicies")]
        public IWebElement GuaranteesTable { get; set; }
       
      
		#endregion


        public ProductSetup WaitForScreenToLoad(IWebElement element = null)
        {
            try
            {
                
                Playback.Wait(5000);
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? OwnerTable);

            }
            catch (Exception e) // try again after wait for 1 second
            {
                Playback.Wait(1000);
                Report.UpdateLog(FastDriver.FileNotes.Table, "Failed to wait for table, second attemp", e.Message, e.InnerException.ToString(), () =>
                {
                    FastDriver.FileNotes.SwitchToContentFrame();
                    FastDriver.FileNotes.WaitCreation(element ?? OwnerTable);
                });
            }
            return this;
        }
        public ProductSetup Open()
        {
            FastDriver.LeftNavigation.Navigate<ProductSetup>("Home>System Maintenance>Products Setup");
            return WaitForScreenToLoad();
        }


        public bool GetCheckboxRadioButtonStatus(IWebElement TableName, int RowIndex, string SearchValue, int ActionCellIndex, string xPathBody)    
        {
            bool CheckBoxStatus = TableName.PerformTableAction(RowIndex, SearchValue, ActionCellIndex, TableAction.GetCell).Element.FindElement(By.XPath(xPathBody)).IsSelected();
            return CheckBoxStatus;
        }

        public bool GetCheckboxRadioButtonStatus(IWebElement TableName, int RowIndex, int columnIndex, string xPathBody)
        {
            bool CheckBoxStatus1 = TableName.PerformTableAction(RowIndex, columnIndex, TableAction.GetCell).Element.FindElement(By.XPath(xPathBody)).IsSelected();
            return CheckBoxStatus1;
        }
        


	}
}
