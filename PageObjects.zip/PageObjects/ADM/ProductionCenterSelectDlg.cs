using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProductionCenterSelectDlg : PageObject
	{
		#region WebElements

		//TODO: ADD FindsByAttribute
		public IWebElement ProductionCenter { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ProductionCenter1 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ProductionCenter2 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ProductionCenter3 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ProductionCenter4 { get; set; }

        [FindsBy(How = How.Id, Using = "idGVTableBody")]
        public IWebElement ProductionCenterTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		#endregion

        #region Useful Methods
        public ProductionCenterSelectDlg WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Select Production Centers", true, 20);
            this.SwitchToContentFrame();
            this.WaitCreation(ProductionCenterTable);
            return this;
        }
        #endregion

    }
}
