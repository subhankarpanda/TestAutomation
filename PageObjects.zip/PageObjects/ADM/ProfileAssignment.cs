using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProfileAssignment : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlProfile")]
		public IWebElement Profile { get; set; }

		[FindsBy(How = How.Id, Using = "dgRoles_0_lblRoleName")]
		public IWebElement QALoadTest { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_dgBus")]
		public IWebElement AssignedBU { get; set; }

		[FindsBy(How = How.LinkText, Using = "New File Entry")]
		public IWebElement NFERole { get; set; }

		[FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
		public IWebElement ExpandIcon { get; set; }

		[FindsBy(How = How.Id, Using = "dgBus_dgBus")]
		public IWebElement AssociatedBUTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgBus_dgBus")]
        public IWebElement AssignedBusinessUnitsTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgRoles_dgRoles")]
		public IWebElement AssociatedRolesTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnRoleAddRemove")]
		public IWebElement AddRemoveRoles { get; set; }

        #endregion


        public ProfileAssignment WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Profile);

            return this;
        }
	}
}
