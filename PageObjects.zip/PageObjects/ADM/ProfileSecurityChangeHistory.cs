using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProfileSecurityChangeHistory : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgProfHistoryEvents_dgProfHistoryEvents")]
		public IWebElement HistoryTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgProfHistoryEvents_5_lblEventDate")]
		public IWebElement EventDate { get; set; }

        #endregion

        public ProfileSecurityChangeHistory WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(HistoryTable);

            return this;
        }
	}
}
