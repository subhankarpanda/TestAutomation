using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProfileSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkActiveOnly")]
		public IWebElement ActiveOnly { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdUpdateProfile")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "ddlRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "dgProfiles_3_lblProfileName")]
		public IWebElement FastAutomation { get; set; }

		[FindsBy(How = How.Id, Using = "dgProfiles_8_txtProfileName")]
		public IWebElement ProfileName { get; set; }

		[FindsBy(How = How.Id, Using = "dgProfiles")]
		public IWebElement ProfilesTable { get; set; }

        #endregion

        public ProfileSetup WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ViewChangeStatus);

            return this;
        }

	}
}
