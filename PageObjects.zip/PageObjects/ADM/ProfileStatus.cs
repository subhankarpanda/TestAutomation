using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class ProfileStatus : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdActivate")]
        public IWebElement Activate { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDeactivate")]
        public IWebElement Deactivate { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        #endregion

        public ProfileStatus WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Comments);

            return this;
        }

    }
}
