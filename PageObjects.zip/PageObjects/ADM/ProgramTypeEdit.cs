using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProgramTypeEdit : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaxLiabilityAmt")]
		public IWebElement ProgramTypeLiabilityAmount { get; set; }

		[FindsBy(How = How.Id, Using = "cmdTranAddRemove")]
		public IWebElement AddRemoveTransaction { get; set; }

		[FindsBy(How = How.Id, Using = "cmdProdAddRemove")]
		public IWebElement AddRemoveProduct { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSearchTypeAddRemove")]
		public IWebElement AddRemoveSearchType { get; set; }

		[FindsBy(How = How.Id, Using = "cmdStateAddRemove")]
		public IWebElement AddRemoveState { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCountyAddRemove")]
		public IWebElement AddRemoveCounty { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProducts_0_rbProduct")]
		public IWebElement Product1RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProducts_1_rbProduct")]
		public IWebElement Product2RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSearchTypes_0_rbSearchType")]
		public IWebElement Search1RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSearchTypes_1_rbSearchType")]
		public IWebElement Search2RadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTranTypes")]
        public IWebElement TransactionTypesTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProducts")]
        public IWebElement ProductsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSearchTypes")]
        public IWebElement SearchTypesTable { get; set; }

       [FindsBy(How = How.Id, Using = "dgridStates")]
        public IWebElement StatesTable { get; set; }

        [FindsBy(How = How.Id, Using = "gdridCounties")]
        public IWebElement CountyTable { get; set; }
		#endregion

        #region Useful Methods
        public ProgramTypeEdit WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ProgramTypeLiabilityAmount);
            return this;
        }
        [Description(@"Default type for Transaction type , product etc is 'All'")]
        public bool CreateNewProgramType(string Name,string LiabilityAmount,string[] TransactionType=null,string[] Products=null,string[] SearchTypes=null,string[] States=null,string[] County=null)
        {
            try{
                this.WaitForScreenToLoad();
            this.Name.FASetText(Name);
            this.ProgramTypeLiabilityAmount.FASetText(LiabilityAmount);
            if (TransactionType!=null)
            {
                this.AddRemoveTransaction.FAClick();
                Thread.Sleep(3000);
                FastDriver.TransactionTypesDlg.WaitForScreenToLoad();
                FastDriver.TransactionTypesDlg.Clear.FAClick();
                Thread.Sleep(1000);
                foreach (string trnType in TransactionType)
                {
                    FastDriver.TransactionTypesDlg.Table.PerformTableAction("Transaction Types", trnType, "Sel", TableAction.On);
                    Thread.Sleep(500);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                this.WaitForScreenToLoad();
            }

            if (Products != null)
            {
                this.AddRemoveProduct.FAClick();
                FastDriver.ProductListDlg.WaitScreenToLoad();
                FastDriver.ProductListDlg.Clear.FAClick();
                Thread.Sleep(1000);
                foreach (string product in Products)
                {
                    FastDriver.ProductListDlg.Table.PerformTableAction("Product Name", product, "Sel", TableAction.On);
                    Thread.Sleep(500);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                this.WaitForScreenToLoad();
            }
                        if (SearchTypes != null)
            {
                this.AddRemoveSearchType.FAClick();
                FastDriver.SearchTypesDlg.WaitForScreenToLoad();
                FastDriver.SearchTypesDlg.Clear.FAClick();
                Thread.Sleep(1000);
                foreach (string searchType in SearchTypes)
                {
                    FastDriver.SearchTypesDlg.Table.PerformTableAction("Search Types", searchType, "Sel", TableAction.On);
                    Thread.Sleep(500);
                }
                FastDriver.DialogBottomFrame.ClickDone();
                this.WaitForScreenToLoad();
            }
            //
                                    if (States != null)
            {
                this.AddRemoveState.FAClick();
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                Thread.Sleep(1000);
                foreach (string state in States)
                {
                    FastDriver.StateSelectionDlg.table.PerformTableAction("State", state, "Select", TableAction.On);
                    Thread.Sleep(500);
                }
                FastDriver.StateSelectionDlg.Select.FAClick();
                this.WaitForScreenToLoad();

               if (County != null)
            {
                this.AddRemoveCounty.FAClick();
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                Thread.Sleep(1000);
                foreach (string county in County)
                {
                    FastDriver.CountySelectionDlg.Table.PerformTableAction("County", county, "Select", TableAction.On);
                    Thread.Sleep(500);
                }
                FastDriver.CountySelectionDlg.Select.FAClick();
                this.WaitForScreenToLoad();
            }

        }
            FastDriver.BottomFrame.Done();
            FastDriver.ProgramTypeSetup.WaitForScreenToLoad();
            if(FastDriver.ProgramTypeSetup.Table.FAGetText().Contains(Name))
                return true;
            else
                return false;

        }
            catch
            {
                throw;
            }
        }
        //
        public Dictionary<string, List<string>> GetDetailsOfProgramType(string ProgramTypeName)
        {
            Dictionary<string, List<string>> ProgramTypeDetails = new Dictionary<string, List<string>>();

            try
            {
                this.WaitForScreenToLoad();
                List<string> LiabilityAmount = new List<string>();
                List<string> TranTypes = new List<string>();
                List<string> ProdTypes = new List<string>();
                List<string> SearchTypes = new List<string>();
                List<string> States = new List<string>();
                List<string> County = new List<string>();
                LiabilityAmount.Add(ProgramTypeLiabilityAmount.FAGetValue());
                if(TransactionTypesTable.IsDisplayed())
                {
                    for(int i=1; i <= TransactionTypesTable.GetRowCount();i++)
                    TranTypes.Add(TransactionTypesTable.PerformTableAction(i,1,TableAction.GetText).Message);
                    
                }
                //
                if (this.ProductsTable.IsDisplayed())
                {
                    for (int i = 1; i <= ProductsTable.GetRowCount(); i++)
                        ProdTypes.Add(ProductsTable.PerformTableAction(i, 1, TableAction.GetText).Message);
                }
                //
                if (this.SearchTypesTable.IsDisplayed())
                {
                    for (int i = 1; i <= SearchTypesTable.GetRowCount(); i++)
                        SearchTypes.Add(SearchTypesTable.PerformTableAction(i, 1, TableAction.GetText).Message);
                }
                //
                if (this.StatesTable.IsDisplayed())
                {
                    for (int i = 1; i <= StatesTable.GetRowCount(); i++)
                        States.Add(StatesTable.PerformTableAction(i, 1, TableAction.GetText).Message);
                }
                //
                if (this.CountyTable.IsDisplayed())
                {
                    for (int i = 1; i <= CountyTable.GetRowCount(); i++)
                        County.Add(CountyTable.PerformTableAction(i, 1, TableAction.GetText).Message);
                }

                ProgramTypeDetails.Add("LiabilityAmount", LiabilityAmount);
                ProgramTypeDetails.Add("TransactionTypes", TranTypes);
                ProgramTypeDetails.Add("ProductTypes", ProdTypes);
                ProgramTypeDetails.Add("SearchTypes", SearchTypes);
                ProgramTypeDetails.Add("States", States);
                ProgramTypeDetails.Add("County", County);
                return ProgramTypeDetails;

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        

        #endregion
    }
}
