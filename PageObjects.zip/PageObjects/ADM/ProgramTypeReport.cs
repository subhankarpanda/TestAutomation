using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProgramTypeReport : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdPrint")]
		public IWebElement Print { get; set; }

        #endregion

        public ProgramTypeReport WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Print);
            return this;
        }
        public ProgramTypeReport Open()
        {
            FastDriver.LeftNavigation.Navigate<SpecialInstructionsSetup>("Home>System Maintenance>Program Setup>Utility Reports");
            this.WaitForScreenToLoad();
            return this;
        }

    }
}
