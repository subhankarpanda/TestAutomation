using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProgramTypeSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkActiveonly")]
		public IWebElement Activeonly { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdView")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPTSummary_dgridPTSummary")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPTDetail_dgridPTDetail")]
		public IWebElement SelectionTable { get; set; }

		#endregion
        public ProgramTypeSetup WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New);
            return this;
        }
        //
        public ProgramTypeSetup Open()
        {
            FastDriver.LeftNavigation.Navigate<SpecialInstructionsSetup>("Home>System Maintenance>Program Setup>Program Type");
            this.WaitForScreenToLoad();
            return this;
        }

        public bool GetNewProgramType(string ProgramTypeName, string LiabilityAmount, string[] TransactionType = null, string[] Products = null, string[] SearchTypes = null, string[] States = null, string[] County = null)
        {
            try
            {
                this.WaitForScreenToLoad();
                this.New.FAClick();
                bool Status = FastDriver.ProgramTypeEdit.CreateNewProgramType(ProgramTypeName, LiabilityAmount,TransactionType, Products, SearchTypes, States, County);
                if (Status)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        //
        public Dictionary<string, List<string>> GetDetailsofProgramType(string ProgramTypeName)
        {
            Dictionary<string, List<string>> ProgramTypeDetails = new Dictionary<string, List<string>>();
            try
            {
                if (Table.FAGetText().Contains(ProgramTypeName))
                {
                    this.Table.PerformTableAction("Program Name", ProgramTypeName, "Program Name", TableAction.Click);
                    this.WaitForScreenToLoad();
                    this.Edit.FAClick();
                    ProgramTypeDetails = FastDriver.ProgramTypeEdit.GetDetailsOfProgramType(ProgramTypeName);
                    return ProgramTypeDetails;
                }
                else
                    throw new Exception("ProgramType Unavailable");


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

	}
}
