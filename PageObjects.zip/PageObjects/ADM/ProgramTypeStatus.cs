using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ProgramTypeStatus : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdDeactivate")]
		public IWebElement Activate { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDeactivate")]
		public IWebElement Deactivate { get; set; }

		[FindsBy(How = How.Id, Using = "lblCurStatus")]
		public IWebElement CurrentStatus { get; set; }

		[FindsBy(How = How.Id, Using = "lblCreatedDate")]
		public IWebElement CreatedOn { get; set; }

		[FindsBy(How = How.Id, Using = "lblCreatedUname")]
		public IWebElement CreatedBy { get; set; }

		#endregion

	}
}
