using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class ProgramTypes : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdSelectBP")]
        public IWebElement AddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPgm_dgridPgm")]
        public IWebElement ProgramNameTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPgm_0_labelBPName")]
        public IWebElement ProgramNamePane { get; set; }

        #endregion

        public ProgramTypes WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(AddRemove, 10);
            return this;
        }
        //
        public ProgramTypes Open(string GABName1)
        {
            FastDriver.LeftNavigation.Navigate<ProgramTypes>("Home>System Maintenance>Address Book>" + GABName1 + ">Program Type");
            FastDriver.ProgramTypes.WaitForScreenToLoad();
            return this;
        }
    }
}
