﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
    public class PropertySelectionDlg : PageObject
    {
        #region Web Elements
        [FindsBy(How = How.Id, Using = "btnCheckAll")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdProperty_grdProperty")]
        public IWebElement PropertiesTable { get; set; }
        #endregion

        public PropertySelectionDlg WaitForScreenToLoad(string windowName = "Property Selection")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(PropertiesTable);

            return this;
        }
    }
}
