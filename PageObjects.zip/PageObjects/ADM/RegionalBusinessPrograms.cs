using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class RegionalBusinessPrograms : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdSelectBP")]
		public IWebElement AddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
        public IWebElement BusinessProgramTable { get; set; }

        #endregion

        public RegionalBusinessPrograms WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AddRemove);

            return this;
        }

        public void VerifyTableOrder()
        {
            List<string> sortedList = new List<string>();
            List<string> tempList = new List<string>();
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                sortedList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Sorting the List
            sortedList.Sort();

            //System list
            foreach (var row in BusinessProgramTable.FAFindElements(ByLocator.TagName, "tr"))
            {
                tempList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Verify whether the elements are sorted
            for (int i = 0; i < sortedList.Count; i++)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(sortedList.ElementAt(i), tempList.ElementAt(i));
            }

        }

    }
}
