﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;

namespace FASTSelenium.PageObjects.ADM
{
    public class RegionalBusinessProgramsSelectionDlg : PageObject
    {
        #region IWebElements

        [FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
        public IWebElement BusinessProgramTable { get; set; }

        #endregion

        public RegionalBusinessProgramsSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? BusinessProgramTable);

            return this;
        }

    }
}