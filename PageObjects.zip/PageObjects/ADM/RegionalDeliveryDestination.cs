using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class RegionalDeliveryDestination : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboProductionOffice")]
		public IWebElement ProductionOffice { get; set; }

		[FindsBy(How = How.Id, Using = "cboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "dgCounty")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "dgCounty_0_ChkSel")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "dgCounty_1_ChkSel")]
		public IWebElement Select1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgCounty_2_ChkSel")]
		public IWebElement Select2 { get; set; }

        #endregion

        public RegionalDeliveryDestination WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Table);
            return this;
        }

    }
}
