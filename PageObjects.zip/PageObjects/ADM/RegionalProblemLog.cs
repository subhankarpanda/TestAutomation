using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class RegionalProblemLog : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdSelectWG")]
		public IWebElement AddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProbLog")]
		public IWebElement ProblemLogTable { get; set; }

		#endregion

        public RegionalProblemLog WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AddRemove);

            return this;
        }

	}
}
