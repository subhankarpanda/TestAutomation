using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
    public class RegionalProcessEdit : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnExtCust")]
        public IWebElement ExternalCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProcessType")]
        public IWebElement ProcessType { get; set; }

        [FindsBy(How = How.Id, Using = "txtProcessName")]
        public IWebElement ProcessName { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProcessOwner")]
        public IWebElement ProcessOwner { get; set; }

        [FindsBy(How = How.Id, Using = "txtDescription")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateSelect")]
        public IWebElement ProcessTemplateSelectionCriteriaSelect { get; set; }

        [FindsBy(How = How.Id, Using = "btnProcessEvent")]
        public IWebElement ProcessEventSelectionCriteriaAddRemove { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDirectingStatus1")]
        public IWebElement DirectingStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSuccProcessType1")]
        public IWebElement SuccProcessType { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDirectingStatus2")]
        public IWebElement DirectingStatus1 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSuccProcessType2")]
        public IWebElement SuccProcessType1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnImport")]
        public IWebElement Import { get; set; }

        [FindsBy(How = How.Id, Using = "btnUp")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "btnDown")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_ddlDueType")]
        public IWebElement DueType { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_1_ddlDueType")]
        public IWebElement DueType2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_2_ddlDueType")]
        public IWebElement DueType3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_3_ddlDueType")]
        public IWebElement DueType4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_4_ddlDueType")]
        public IWebElement DueType5 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_5_ddlDueType")]
        public IWebElement DueType6 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_txtDueDays")]
        public IWebElement DueDays { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_txtDueHrs")]
        public IWebElement DueHrs { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_txtDueMin")]
        public IWebElement DueMin { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_txtWarnDays")]
        public IWebElement WarnDays { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_txtWarnHrs")]
        public IWebElement WarnHrs { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_0_txtWarnMin")]
        public IWebElement WarnMin { get; set; }

        [FindsBy(How = How.Id, Using = "chkInactive")]
        public IWebElement Inactive { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselectOfficeRole")]
        public IWebElement TaskOffice { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselPredAction_I")]
        public IWebElement Directingstatus { get; set; }

        [FindsBy(How = How.Id, Using = "idPredToolbarI")]
        public IWebElement ViewEditSuccessors { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselPredAction")]
        public IWebElement Directingstatus1 { get; set; }

        [FindsBy(How = How.Id, Using = "idPredToolbar")]
        public IWebElement ViewEditSuccessors1 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselPredAction_II")]
        public IWebElement Directingstatus2 { get; set; }

        [FindsBy(How = How.Id, Using = "idPredToolbarII")]
        public IWebElement ViewEditSuccessors2 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTiggerStatus")]
        public IWebElement TiggerStatus { get; set; }

        [FindsBy(How = How.Id, Using = "btnTiggerStatus")]
        public IWebElement ViewEditTasks { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselTaskEventAction")]
        public IWebElement TaskEventAction { get; set; }

        [FindsBy(How = How.Id, Using = "idTriggerEventToolbar")]
        public IWebElement TaskEventSetup { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselTaskEventAction_I")]
        public IWebElement TaskEventAction2 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselTriggerEvent_I")]
        public IWebElement SelTaskEvent2 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselTriggerEvent_I")]
        public IWebElement TaskEventSetup2 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselFileEventStatus")]
        public IWebElement WhenStatusis { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselFileEvent")]
        public IWebElement FileEvent { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateSelect")]
        public IWebElement SelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgProcessEvent")]
        public IWebElement ProcessEventTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgTemplateTask_dgTemplateTask")]
        public IWebElement TaskTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblPakageDescr_I")]
        public IWebElement VerifyPathCreated { get; set; }

        [FindsBy(How = How.Id, Using = "btnProdOff")]
        public IWebElement ProdCentreEllipse { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselTriggerEvent")]
        public IWebElement SelTaskEvent { get; set; }

        [FindsBy(How = How.Id, Using = "btnWrkgrpSel")]
        public IWebElement WorkGrpEllipse { get; set; }

        [FindsBy(How = How.Id, Using = "idGVTableBody")]
        public IWebElement WorkGrpTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblSearchCriteria")]
        public IWebElement ExpandSelCriteria { get; set; }

        [FindsBy(How = How.Id, Using = "chkPriorityProcess")]
        public IWebElement PriorityProcess { get; set; }

        [FindsBy(How = How.Id, Using = "idFileEventToolbar")]
        public IWebElement FileEventSetup { get; set; }

        [FindsBy(How = How.Id, Using = "dgProcessEvent_0_btnProcess")]
        public IWebElement ProcessEventSelEllipse { get; set; }

        [FindsBy(How = How.Id, Using = "dgProcessEvent_0_btnProcess")]
        public IWebElement ImageTriggerSetup { get; set; }

        [FindsBy(How = How.Id, Using = "dgProcessEvent_2_btnProcess")]
        public IWebElement WorkQueueTriggerSetup { get; set; }

        [FindsBy(How = How.Id, Using = "idTriggerEventToolbar_I")]
        public IWebElement TaskEventSetupext { get; set; }

        #endregion

        public RegionalProcessEdit WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ProcessTemplateSelectionCriteriaSelect);
            return this;
        }

        public RegionalProcessEdit ProcessTemplateTaskTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(TaskTable);
            TaskTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value);
            return this;
        }

        public Dictionary<string, string> CreateNewProcess(ProcessParameters ProcParams, string DueTypeForFirstTask = "", string WarnMin = "", string DueMin = "",bool PublicTask=false)
        {
            Dictionary<string, string> ProcDetails = new Dictionary<string, string>();
            try
            {
                FastDriver.TaskTemplateSelection.Open();
                if (ProcParams.Tasks == null)
                {
                    ProcParams.Tasks = new string[2];
                    for (int i = 0; i < ProcParams.Tasks.Length; i++)
                    {
                        ProcParams.Tasks[i] = FastDriver.TaskTemplateSelection.CreateNewTask();
                    }
                }

                else
                {
                    for (int i = 0; i < ProcParams.Tasks.Length; i++)
                    {
                        if (!FastDriver.TaskTemplateSelection.CheckIfTaskExists(ProcParams.Tasks[i]))
                            FastDriver.TaskTemplateSelection.CreateNewTask(ProcParams.Tasks[i]);
                    }
                }
                FastDriver.RegionalProcessSummary.Open();
                //
                Reports.TestStep = "Enter process Name";
                if (string.IsNullOrEmpty(ProcParams.ProcessName))
                    ProcParams.ProcessName = "Process_New_" + Guid.NewGuid().GetHashCode();

                //
                Reports.TestStep = "Remove process if already exists";
                if (FastDriver.RegionalProcessSummary.ProcessSummaryTable.Text.Contains(ProcParams.ProcessName))
                {
                    FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction("Process Name", ProcParams.ProcessName, "Process Name", TableAction.Click);
                    FastDriver.RegionalProcessSummary.Remove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                }
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.SwitchToContentFrame();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(ProcParams.ProcessType);
                //
                this.ProcessName.FASetText(ProcParams.ProcessName);
                this.PriorityProcess.FASetCheckbox(true);
                this.Description.FASetText("!!!!!!This is QA automation template. DO NOT TOUCH!!!!!");
                //   Support.AreEqual("1486", this.ProcessOwner.FAGetValue());

                Reports.TestStep = "create the process template selection criteria";
                this.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem(ProcParams.TranType);
                FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
                Thread.Sleep(4000);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                Thread.Sleep(2000);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", ProcParams.State, "Select", TableAction.On);
                //FastDriver.StateSelectionDlg.grdState8SelState.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();

                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
                Thread.Sleep(4000);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                Thread.Sleep(2000);
                FastDriver.CountySelectionDlg.Table.PerformTableAction("#2", ProcParams.County.ToUpper(), "#1", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                Thread.Sleep(4000);
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                this.WaitForScreenToLoad();
                this.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction("Process Events", ProcParams.ProcessEvent, "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Add a newly created task to new process";
                this.WaitForScreenToLoad();
                this.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                for (int i = 0; i < ProcParams.Tasks.Length; i++)
                {
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 2, TableAction.On);
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    if (PublicTask)
                    {
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 5, TableAction.SelectItem, "Yes");
                    }
                    ProcDetails.Add("Task" + i, ProcParams.Tasks[i]);
                }
                FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                this.SwitchToContentFrame();
                this.Inactive.FASetCheckbox(false);


                if (!string.IsNullOrEmpty(DueTypeForFirstTask))
                {
                    Reports.TestStep = "Set duetype, due min for the 1st task";
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.DueType.FASelectItem(DueTypeForFirstTask);
                    if (!string.IsNullOrEmpty(WarnMin))
                        FastDriver.RegionalProcessEdit.WarnMin.FASetText(WarnMin);
                    if (!string.IsNullOrEmpty(DueMin))
                        FastDriver.RegionalProcessEdit.DueMin.FASetText(DueMin);
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "ACtivate the process";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select a process and click Edit button";
                FastDriver.RegionalProcessSummary.SwitchToContentFrame();
                FastDriver.RegionalProcessSummary.SelectProcessFromSummaryTable(1, ProcParams.ProcessName, 1, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.SwitchToContentFrame();
                FastDriver.StatusEdit.Activate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>(@"Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                FastDriver.PendingRefreshSummary.WaitForScreenToLoad();
                Reports.TestStep = "Select a process and click on Refresh button.";
                if (FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(ProcParams.ProcessName))
                {
                    FastDriver.PendingRefreshSummary.SummaryTable.PerformTableAction("#2", ProcParams.ProcessName, "#1", TableAction.On);
                    FastDriver.PendingRefreshSummary.RefreshProcess.FAClick();
                    Thread.Sleep(5000);
                    FastDriver.PendingRefreshSummary.RefreshTemplate(ProcParams.ProcessName);
                }
                ProcDetails.Add("ProcessName", ProcParams.ProcessName);

                return ProcDetails;
            }
            catch
            {
                throw;
            }
        }
        //
        public Dictionary<string, string> CreateNewProcess(ProcessParameters ProcParams,TaskTemplateParameters TaskParams)
        {
            Dictionary<string, string> ProcDetails = new Dictionary<string, string>();
            try
            {
                FastDriver.TaskTemplateSelection.Open();
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction("Task Category", TaskParams.TaskCategory, "Task Category", TableAction.Click);
                FastDriver.TaskTemplateSelection.WaitCreation(FastDriver.TaskTemplateSelection.TasksForTable);
                if (ProcParams.Tasks == null)
                {
                    ProcParams.Tasks = new string[2];
                    for (int i = 0; i < ProcParams.Tasks.Length; i++)
                    {
                        ProcParams.Tasks[i] = FastDriver.TaskTemplateSelection.CreateNewTask();
                    }
                }

                else
                {
                    for (int i = 0; i < ProcParams.Tasks.Length; i++)
                    {
                        if (!FastDriver.TaskTemplateSelection.CheckIfTaskExists(ProcParams.Tasks[i]))
                            FastDriver.TaskTemplateSelection.CreateNewTask(ProcParams.Tasks[i]);
                    }
                }
                FastDriver.RegionalProcessSummary.Open();
                //
                Reports.TestStep = "Enter process Name";
                if (string.IsNullOrEmpty(ProcParams.ProcessName))
                    ProcParams.ProcessName = "Process_New_" + Guid.NewGuid().GetHashCode();

                //
                Reports.TestStep = "Remove process if already exists";
                if (FastDriver.RegionalProcessSummary.ProcessSummaryTable.Text.Contains(ProcParams.ProcessName))
                {
                    FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction("Process Name", ProcParams.ProcessName, "Process Name", TableAction.Click);
                    FastDriver.RegionalProcessSummary.Remove.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                    FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                }
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.SwitchToContentFrame();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem(ProcParams.ProcessType);
                //
                this.ProcessName.FASetText(ProcParams.ProcessName);
                this.PriorityProcess.FASetCheckbox(true);
                this.Description.FASetText("!!!!!!This is QA automation template. DO NOT TOUCH!!!!!");
                //   Support.AreEqual("1486", this.ProcessOwner.FAGetValue());

                Reports.TestStep = "create the process template selection criteria";
                this.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem(ProcParams.TranType);
                FastDriver.SelectionCriteriaDlg.AddRemoveState.FAClick();
                Thread.Sleep(4000);
                FastDriver.StateSelectionDlg.WaitForScreenToLoad();
                FastDriver.StateSelectionDlg.Clear.FAClick();
                Thread.Sleep(2000);
                FastDriver.StateSelectionDlg.table.PerformTableAction("State", ProcParams.State, "Select", TableAction.On);
                //FastDriver.StateSelectionDlg.grdState8SelState.FAClick();
                FastDriver.StateSelectionDlg.Select.FAClick();

                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.AddRemoveCounty.FAClick();
                Thread.Sleep(4000);
                FastDriver.CountySelectionDlg.WaitForScreenToLoad();
                FastDriver.CountySelectionDlg.Clear.FAClick();
                Thread.Sleep(2000);
                FastDriver.CountySelectionDlg.Table.PerformTableAction("#2", ProcParams.County.ToUpper(), "#1", TableAction.On);
                FastDriver.CountySelectionDlg.Select.FAClick();
                Thread.Sleep(4000);
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.Done.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                this.WaitForScreenToLoad();
                this.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction("Process Events", ProcParams.ProcessEvent, "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Add a newly created task to new process";
                this.WaitForScreenToLoad();
                this.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TaskCategoryTable.PerformTableAction("Task Category", TaskParams.TaskCategory, "Task Category", TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.WaitCreation(FastDriver.TaskTemplateSelectionDlg.TasksForTable);
                for (int i = 0; i < ProcParams.Tasks.Length; i++)
                {
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 2, TableAction.On);
                    FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                    if (TaskParams.PublicTask)
                    {
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 5, TableAction.SelectItem, "Yes");
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 4, TableAction.SetText, ProcParams.Tasks[i]);
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 7, TableAction.SelectItem, "Both");
                        FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, ProcParams.Tasks[i], 2, TableAction.On);
                    }
                    ProcDetails.Add("Task" + i, ProcParams.Tasks[i]);
                }
                FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                Reports.TestStep = "Click on Ok button.";
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                this.SwitchToContentFrame();
                this.Inactive.FASetCheckbox(false);


                if (!string.IsNullOrEmpty(TaskParams.DueTypeForFirstTask))
                {
                    Reports.TestStep = "Set duetype, due min for the 1st task";
                    FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                    FastDriver.RegionalProcessEdit.DueType.FASelectItem(TaskParams.DueTypeForFirstTask);
                    if (!string.IsNullOrEmpty(TaskParams.WarnMin))
                        FastDriver.RegionalProcessEdit.WarnMin.FASetText(TaskParams.WarnMin);
                    if (!string.IsNullOrEmpty(TaskParams.DueMin))
                        FastDriver.RegionalProcessEdit.DueMin.FASetText(TaskParams.DueMin);
                }
                FastDriver.BottomFrame.Done();
                Thread.Sleep(7000);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "ACtivate the process";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();

                Reports.TestStep = "Select a process and click Edit button";
                FastDriver.RegionalProcessSummary.SwitchToContentFrame();
                FastDriver.RegionalProcessSummary.SelectProcessFromSummaryTable(1, ProcParams.ProcessName, 1, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.SwitchToContentFrame();
                FastDriver.StatusEdit.Activate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.LeftNavigation.Navigate<PendingRefreshSummary>(@"Home>System Maintenance>Process Setup>Pending Refresh Summary").WaitForScreenToLoad();
                FastDriver.PendingRefreshSummary.WaitForScreenToLoad();
                Reports.TestStep = "Select a process and click on Refresh button.";
                if (FastDriver.PendingRefreshSummary.SummaryTable.Text.Contains(ProcParams.ProcessName))
                {
                    FastDriver.PendingRefreshSummary.SummaryTable.PerformTableAction("#2", ProcParams.ProcessName, "#1", TableAction.On);
                    FastDriver.PendingRefreshSummary.RefreshProcess.FAClick();
                    Thread.Sleep(5000);
                    FastDriver.PendingRefreshSummary.RefreshTemplate(ProcParams.ProcessName);
                }
                ProcDetails.Add("ProcessName", ProcParams.ProcessName);

                return ProcDetails;
            }
            catch
            {
                throw;
            }
        }
        public void Expand(IWebElement button)
        {
            if (button.GetAttribute("class") == "cButtonExpandFalse")
                button.FAClick();
        }

        public RegionalProcessEdit SetWorkGroup(string workGroup)
        {
            this.WorkGrpEllipse.FAClick();
            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
            FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(workGroup);
            FastDriver.WorkgroupSelectionDlg.Select.FAClick();
            FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
            FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, workGroup, 1, TableAction.On);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            this.WaitForScreenToLoad();

            return this;
        }
    }
    public class ProcessEventSelection : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridProcessEvents_7_chkSelEvent")]
        public IWebElement SelProcessEvent1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProcessEvents_15_chkSelEvent")]
        public IWebElement SelProcessEvent2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProcessEvents_dgridProcessEvents")]
        public IWebElement ProcessEventTable { get; set; }

        #endregion



    }
    public class WorkgroupSelectDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnViewMore")]
        public IWebElement ViewMore { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelGrp { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelGrp2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelGrp3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelGrp4 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelGrp5 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelGrp6 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "div#panelSelectProperty table#idGVTableBody")]
        public IWebElement WorkgroupTable { get; set; }

        #endregion

        #region Useful Methods
        public WorkgroupSelectDlg WaitForScreenToLoad(string windowName = "Select Work Groups")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ViewMore);
            return this;
        }
        #endregion

    }
    public class ChangeHistoryDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridTemplateEvents_0_lblEvent")]
        public IWebElement TemplateCreated { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTemplateEvents_0_lblEvent")]
        public IWebElement StatusTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgridNotificationEvents_dgridNotificationEvents, #dgridTemplateEvents_dgridTemplateEvents")]
        public IWebElement NotificationChangeHistTable { get; set; }

        #endregion

        public ChangeHistoryDlg WaitForScreenToLoad(string windowName = "Change History", IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 30);
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(NotificationChangeHistTable);
            return this;
        }
    }
    public class FieldChangedTaskEventSetup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.LinkText, Using = "Account Servicing CandidateTitle Report Effective Date")]
        public IWebElement FieldName { get; set; }

        [FindsBy(How = How.LinkText, Using = "NBEQGTLTLEGEEB")]
        public IWebElement Operator { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Value { get; set; }

        #endregion

    }
    public class SelectProductionCentersWebpageDialogDlg : PageObject
    {
        #region WebElements

        //TODO: ADD FindsByAttribute
        public IWebElement Select1 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Select2 { get; set; }

        [FindsBy(How = How.Id, Using = "idGVTableBody")]
        public IWebElement SelectProductionCentersTable { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Select3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Select4 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Select5 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Select6 { get; set; }

        [FindsBy(How = How.LinkText, Using = "1002-Escrow Training Office Two")]
        public IWebElement Ten02EscroainingOfficeTwo { get; set; }

        #endregion

        #region Useful Methods
        public SelectProductionCentersWebpageDialogDlg WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Select Production Centers", timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(SelectProductionCentersTable);
            return this;
        }
        #endregion
    }
}
