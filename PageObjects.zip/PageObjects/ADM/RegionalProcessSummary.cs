using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class RegionalProcessSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkActiveOnly")]
        public IWebElement ActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "btnViewChngStatus")]
        public IWebElement ViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "btnChngHistry")]
        public IWebElement ChangeHistory { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProcessType")]
        public IWebElement ProcessType { get; set; }

        [FindsBy(How = How.Id, Using = "ddlselOfficeGroups")]
        public IWebElement OfficeGroups { get; set; }

        [FindsBy(How = How.Id, Using = "ddlseloffice")]
        public IWebElement office { get; set; }

        [FindsBy(How = How.LinkText, Using = "AUTO_DONOTTOUCH_File Created")]
        public IWebElement PName { get; set; }

        [FindsBy(How = How.LinkText, Using = "Selection Type")]
        public IWebElement SelectionType { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProcessSmry_dgridProcessSmry")]
        public IWebElement ProcessSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProcessDetails_dgridProcessDetails")]
        public IWebElement ProcessDetailsTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "AXE002-TEMPLATE002")]
        public IWebElement PName1 { get; set; }

        #endregion

        public RegionalProcessSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ProcessSummaryTable);
            return this;
        }

        public RegionalProcessSummary WaitForProcessDetailsTableToLoad()
        {
            this.WaitCreation(ProcessDetailsTable);
            return this;
        }

        public RegionalProcessSummary SelectProcessFromSummaryTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ProcessSummaryTable);
            ProcessSummaryTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value);
            return this;
        }
        //
        public RegionalProcessSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Home>System Maintenance>Process Setup>Regional Process Summary");
            this.WaitForScreenToLoad();
            this.WaitCreation(ProcessSummaryTable);
            return this;
        }
        //
        public bool CheckAvailabilityOfProcess(string ProcessName, string ProcessType)
        {
            this.ProcessType.FASelectItem(ProcessType);
            Thread.Sleep(10000);
            int RowCount = FastDriver.RegionalProcessSummary.ProcessSummaryTable.GetRowCount();

            for (int i = 1; i <= RowCount; i++)
            {
                string ProcessNameADM = FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(i, 1, TableAction.GetText).Message;
                if (ProcessNameADM.Equals(ProcessName))
                {
                    return true;
                }

            }
            return false;
        }
        //
        public void EditProcess(string ProcessName)
        {
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary");
            this.WaitForScreenToLoad();
            this.SelectProcessFromSummaryTable(1, ProcessName, 1, TableAction.Click);
            this.Edit.FAClick();
            FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
        }
        //
        public bool CheckIfFreshProcess(string ProcessName)
        {

            Reports.TestStep = "CHeck the process";
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>(@"Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
            if (FastDriver.RegionalProcessSummary.ProcessSummaryTable.Text.Contains(ProcessName))
            {
                Reports.TestStep = "Select a process and validate creation time";
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.SelectProcessFromSummaryTable(1, ProcessName, 1, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.SwitchToContentFrame();
                DateTime CreatedOn = Convert.ToDateTime(FastDriver.StatusEdit.CreatedOn.FAGetText().Trim());
                if ((DateTime.Now - CreatedOn).TotalMinutes < 60)
                    return true;
                else return false;

            }
            return false;
        }
    }
}
