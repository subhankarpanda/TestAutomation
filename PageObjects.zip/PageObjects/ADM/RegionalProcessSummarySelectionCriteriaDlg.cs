using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectionCriteriaDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlRoleType")]
		public IWebElement RoleType { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlService, #lstService")]
		public IWebElement Service { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlProd, #lstProd")]
		public IWebElement Prod { get; set; }

		[FindsBy(How = How.Id, Using = "btnPropType")]
		public IWebElement AddRemoveProperty { get; set; }

		[FindsBy(How = How.Id, Using = "btnGrpOff")]
		public IWebElement AddRemoveOffGrp { get; set; }

		[FindsBy(How = How.Id, Using = "btnProgType")]
		public IWebElement AddRemovePrgType { get; set; }

		[FindsBy(How = How.Id, Using = "btnSearchType")]
		public IWebElement AddRemoveSearchType { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "lstBusSeg")]
		public IWebElement BusSegment { get; set; }

		[FindsBy(How = How.Id, Using = "lstTransType")]
		public IWebElement TranType { get; set; }

		[FindsBy(How = How.Id, Using = "btnBusOrgs")]
		public IWebElement AddRemoveBusOrg { get; set; }

		[FindsBy(How = How.Id, Using = "grdBusOrgs")]
		public IWebElement BusOrgTable { get; set; }

		[FindsBy(How = How.Id, Using = "lstAddlRole")]
		public IWebElement AddlRole { get; set; }

		[FindsBy(How = How.Id, Using = "grdPropType")]
		public IWebElement PropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "grdGroupOrOff")]
		public IWebElement OfficeGroup_Office { get; set; }

		[FindsBy(How = How.Id, Using = "grdPgmType")]
		public IWebElement ProgramType { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchType")]
		public IWebElement SearchType { get; set; }

		[FindsBy(How = How.Id, Using = "btnState")]
		public IWebElement AddRemoveState { get; set; }

		[FindsBy(How = How.Id, Using = "grdState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "btnCounty")]
		public IWebElement AddRemoveCounty { get; set; }

		[FindsBy(How = How.Id, Using = "grdCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "btnCity")]
		public IWebElement AddRemoveCity { get; set; }

		[FindsBy(How = How.Id, Using = "grdCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.LinkText, Using = "Residential")]
		public IWebElement BusSegmentResidential { get; set; }

		[FindsBy(How = How.LinkText, Using = "Commercial")]
		public IWebElement BusSegmentCommercial { get; set; }

		[FindsBy(How = How.Id, Using = "lstOrderSource")]
		public IWebElement OrderSource { get; set; }

		[FindsBy(How = How.Id, Using = "lstsecondOrderSource")]
		public IWebElement SecondOrderSource { get; set; }

		#endregion

        #region PO Methods
        public SelectionCriteriaDlg WaitForScreenToLoad(string windowName = "Selection Criteria")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(AddRemoveBusOrg);
            return this;
        }

        public SelectionCriteriaDlg SelectBusinessSegment(string busSegment = "Residential")
        {
            try
            {
                BusSegment.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.Text.Contains(busSegment) && i.Displayed).FAClick();
            }
            catch (Exception)
            {
                Reports.StatusUpdate(String.Format("Unable to find Business Segment: {0}", busSegment), false);
            }

            return this;
        }

        public SelectionCriteriaDlg SelectTransType(string transType = "Residential")
        {
            try
            {
                TranType.FAFindElements(ByLocator.TagName, "option").FirstOrDefault(i => i.Text == transType && i.Displayed).FAClick();
            }
            catch (Exception)
            {
                Reports.StatusUpdate(String.Format("Unable to find Business Segment: {0}", transType), false);
            }

            return this;
        }

        #endregion

    }
}
