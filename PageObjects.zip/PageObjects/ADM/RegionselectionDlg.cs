using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class RegionselectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdChkAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemoveAll")]
		public IWebElement ClearAll { get; set; }

		[FindsBy(How = How.Id, Using = "dgridRegions_1_chkSel")]
		public IWebElement Region1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridRegions_2_chkSel")]
		public IWebElement Region2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridRegions")]
		public IWebElement RegionsTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement btnDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement btnCancel { get; set; }

        #endregion

        public RegionselectionDlg WaitForScreenToLoad(string windowName = "Region Selection -- Webpage Dialog")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(RegionsTable);
            return this;
        }
    }
}
