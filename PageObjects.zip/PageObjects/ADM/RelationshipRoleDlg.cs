﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System;
using FASTSelenium.DataObjects.ADM;
using System.ComponentModel;

namespace FASTSelenium.PageObjects.ADM
{
    public class RelationshipRoleDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "dgridRelationshipRoles")]
        public IWebElement RelationshipRolesTable { get; set; }
        #endregion

        public RelationshipRoleDlg WaitForScreenToLoad() {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(RelationshipRolesTable);
            return this;
        }

        /// <summary>
        /// This method add the roles to a Business Organization/Contact Relationship
        /// </summary>
        /// <param name="roles">Leave it null for adding all roles to the relationship</param>
        public void AddRoles(string[] roles = null, bool withPrimary = false)
        {
            if (roles == null)
            {
                roles = new string[] {
                            "Attorney Paralegal",
                            "Loan Officer",
                            "Loan Processor",
                            "Transaction Coordinator"
                };
            }

            foreach (var role in roles)
            {
                RelationshipRolesTable.PerformTableAction(2, role, 1, TableAction.On);

                if (withPrimary && !string.Equals("Loan Officer", role.ToString()))
                {
                    RelationshipRolesTable.PerformTableAction(2, role, 3, TableAction.On);
                }
            }
        }
    }
}
