using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class RoleBusinessUnitAssignment : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnRoleAddRemove")]
        public IWebElement AddRemoveRoles { get; set; }

        [FindsBy(How = How.Id, Using = "btnBUAddRemove")]
        public IWebElement AddRemoveBusinessUnits { get; set; }

        [FindsBy(How = How.Id, Using = "dgRoles_dgRoles")]
        public IWebElement AssignedRoles { get; set; }

        [FindsBy(How = How.Id, Using = "dgRoles_0_lblRoleName")]
        public IWebElement QALoadTest { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement ExpandIcon { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement ExpandIcon1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgBus_dgBus")]
        public IWebElement BusinessUnits { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement ExpandIconITAll { get; set; }

        #endregion

        public RoleBusinessUnitAssignment WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AddRemoveBusinessUnits);
            return this;
        }
    }
}
