using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class RoleChangeHistory : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgRoleHistoryEvents_dgRoleHistoryEvents")]
		public IWebElement HistoryTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgRoleHistoryEvents_2_lblEventDate")]
		public IWebElement EventDate { get; set; }

		[FindsBy(How = How.Id, Using = "dgRoleHistoryEvents_1_lblEventDetail")]
		public IWebElement RemovedActivityRight { get; set; }

		[FindsBy(How = How.Id, Using = "dgRoleHistoryEvents_2_lblEventDetail")]
        public IWebElement AddedActivityRight { get; set; }

        #endregion

        public RoleChangeHistory WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(HistoryTable, 10);
            return this;
        }

    }
}
