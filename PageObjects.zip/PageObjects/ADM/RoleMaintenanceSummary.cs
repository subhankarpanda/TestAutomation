using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class RoleMaintenanceSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "btnChangeHistory")]
		public IWebElement ChangeHistory { get; set; }

		[FindsBy(How = How.Id, Using = "dgRoleSummary_dgRoleSummary")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.LinkText, Using = "CorpTestRole")]
		public IWebElement RoleName { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='QA Load Test Regional Role - CD']")]
        public IWebElement QALoadTestRegionalRole { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='QA Load Test Regional Role - HUD']")]
        public IWebElement QALoadTestRegionalRoleHUD { get; set; }

        #endregion

        public RoleMaintenanceSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Table, 10);
            return this;
        }

        public RoleMaintenanceSummary Open() {
            return FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>("Home>System Maintenance>Security Maintenance>Role Maintenance").WaitForScreenToLoad();
        }

        public bool VerifyRoleExists(string RoleName)
        {
            this.Open();
            var Descriptions = FastDriver.RoleMaintenanceSummary.Table.FindElements(By.CssSelector("tr td:first-child"));
            foreach (IWebElement Description in Descriptions) {
                if (Description.FAGetText() == RoleName)
                    return true;
            }
            return false;
        }

	}
}
