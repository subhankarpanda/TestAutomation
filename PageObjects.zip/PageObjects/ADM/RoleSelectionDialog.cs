﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System;
using FASTSelenium.DataObjects.ADM;
using System.ComponentModel;

namespace FASTSelenium.PageObjects.ADM
{
    public class RoleSelectionDialog : PageObject
    {

        #region WebElements

        [FindsBy(How = How.Id, Using = "dgRoles")]
        public IWebElement RolesTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement DoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgRoles_0_chkSel")]
        public IWebElement Role { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images2/collapse.gif")]
        public IWebElement ExpandIcon { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement OfficeRole1 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement OfficeRole2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement RegionRole1 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement RegionRole2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRoles_0_chkSel")]
        public IWebElement RoleCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "dgRoles_0_labelRoleName")]
        public IWebElement RoleName { get; set; }

        #endregion

        public RoleSelectionDialog WaitForScreenToLoad(IWebElement element = null)
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Role Selection");
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? RolesTable);
            return this;
        }

        public bool IsRoleSelectEnabled(IWebElement cell)
        {
            IWebElement selectElement = cell.FindElement(By.XPath("//input"));

            return selectElement.IsEnabled();
        }

        //public RoleSelectionDialog DeselectRole(string roleName)
        //{
        //    this.SwitchToWindow("Role Selection");
        //    WebDriver.SwitchTo().Frame("fraPageWin");
        //    this.WaitCreation(RolesTable);
        //    RolesTable.PerformTableAction(3, roleName, 1, TableAction.Off);
        //    
        //    return this;
        //}

            //public RoleSelectionDialog SelectRole(string roleName)
            //{
            //    this.SwitchToWindow("Role Selection");
            //    WebDriver.SwitchTo().Frame("fraPageWin");
            //    this.WaitCreation(RolesTable);
            //    RolesTable.PerformTableAction(3, roleName, 1, TableAction.On);
            //    
            //    return this;
            //}

            //public RoleSelectionDialog ClickDone()
            //{
            //    this.SwitchToWindow("Role Selection");
            //    WebDriver.SwitchTo().Frame("fraViewBottom");
            //    this.WaitCreation(DoneButton);
            //    DoneButton.Click();
            //     //TODO-Jorge: Verify this
            //    this.SwitchToWindow("FAST v9.0"); 
            //    
            //    return this;
            //}
    }
}