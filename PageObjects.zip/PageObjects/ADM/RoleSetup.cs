using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
	public class RoleSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDeActivate")]
		public IWebElement Deactivate { get; set; }

		[FindsBy(How = How.Id, Using = "txtRoleName")]
		public IWebElement RoleName { get; set; }

		[FindsBy(How = How.Id, Using = "rbtnCorporate")]
		public IWebElement Corporate { get; set; }

		[FindsBy(How = How.Id, Using = "rbtnRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "rbtnOffice")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelectRegion")]
		public IWebElement SelectRegions { get; set; }

		[FindsBy(How = How.Id, Using = "ddlActivityGroup")]
		public IWebElement ActivityGroup { get; set; }

		[FindsBy(How = How.Id, Using = "dgAvailableActivityrights_dgAvailableActivityrights")]
		public IWebElement AvailableRightsTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgSelectedActivityrights_dgSelectedActivityrights")]
        public IWebElement SelectedRightsTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.LinkText, Using = "Add New Role: A role with the name SMUC0048_WithoutRights already exists")]
		public IWebElement Error { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Workflow Priority Flag Activity']")]
        public IWebElement WorkFlowPriorityFlag { get; set; }

		#endregion

        public RoleSetup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SelectedRightsTable);
            return this;
        }
        //
        public bool AddActivityRightToTheRole(string RoleName, string ActivityRight, string RoleGroup)
        {
            try
            {
                IWebElement elemnt = null; ;
                bool isActivityRightPresent = true;
                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Click on the required office and click edit button.";
                FastDriver.LeftNavigation.Navigate<RoleMaintenanceSummary>(@"Home>System Maintenance>Security Maintenance>Role Maintenance").WaitForScreenToLoad();
                FastDriver.RoleMaintenanceSummary.Table.PerformTableAction("Role Name", RoleName, "Role Name", TableAction.Click);
                FastDriver.RoleMaintenanceSummary.Edit.FAClick();

                Reports.TestStep = "Validate that activity right is present in region level and add the Activity right.";
                FastDriver.RoleSetup.WaitForScreenToLoad();
                try
                {
                    elemnt = FastDriver.RoleSetup.SelectedRightsTable.FindElements(By.TagName("span")).FirstOrDefault(p => p.Text.Clean() == ActivityRight);
                }
                catch (Exception)
                {
                    isActivityRightPresent = false;
                }

                if (elemnt == null || !isActivityRightPresent)
                {
                    FastDriver.RoleSetup.Region.FASetCheckbox(true);
                    FastDriver.RoleSetup.ActivityGroup.FASelectItemBySendingKeys(RoleGroup);
                    FastDriver.RoleSetup.AvailableRightsTable.PerformTableAction("Activity", ActivityRight, "Select", TableAction.On);
                    FastDriver.RoleSetup.Add.FAClick();

                    Reports.TestStep = "Click on Save.";
                    FastDriver.BottomFrame.Save();

                    Reports.TestStep = "Track changes while Create Group Setup.";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Track Change History", timeoutSeconds: 15);
                    FastDriver.TrackChangeHistoryDialog.SwitchToDialogContentFrame();
                    FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
                    FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
                    return true;

                }
                else
                {
                    Reports.StatusUpdate("Activity right is already added", true);
                    return true;
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Activity right cannot be added " + ex.Message, false);
                return false;
            }
        }

        public void CreateRole(RoleSetupParameters parameters)
        {

            FastDriver.RoleMaintenanceSummary.Open();
            FastDriver.RoleMaintenanceSummary.New.FAClick();
            this.WaitForScreenToLoad();

            this.RoleName.FASetText(parameters.RoleName);
            switch (parameters.SecurityLevel)
            {
                case RoleSecurityLevel.Region:
                    Region.FAClick();
                    break;
                case RoleSecurityLevel.Corporate:
                    Corporate.FAClick();
                    break;
                case RoleSecurityLevel.Office:
                    Office.FAClick();
                    break;
            }

            ActivityGroup.FASelectItem(parameters.ActivityGroup);
            
            foreach (string AvailableActivityRight in parameters.AvailableActivityRights)
            {
                AvailableRightsTable.PerformTableAction(2, AvailableActivityRight, 1, TableAction.On);
            }

            Add.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.TrackChangeHistoryDialog.WaitForScreenToLoad();
            FastDriver.TrackChangeHistoryDialog.TrackNo.FASetText("123");
            FastDriver.TrackChangeHistoryDialog.DoneButton.FAClick();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.RoleMaintenanceSummary.WaitForScreenToLoad();

        }
	}
}
