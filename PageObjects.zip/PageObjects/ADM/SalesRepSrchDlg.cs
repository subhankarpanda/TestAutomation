﻿#region SRT-ServReq
//Team                  :  ServReq-Team2 (Production Support)
//Iteration             :  r09
//UserStory             :  User Story 837583
//TestCase              :  864455
//Appended By/ Created By: Shobhit
using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class SalesRepSrchDlg : PageObject
    {

        #region WebElements
        [FindsBy(How = How.Id, Using = "fraSalesRep")]
        public IWebElement SalesRepSearchTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstName")]
        public IWebElement SalesRepFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtLastName")]
        public IWebElement SalesRepLastName { get; set; }

        [FindsBy(How = How.Id, Using = "BtnFind")]
        public IWebElement SalesRepFindBtn { get; set; }

        [FindsBy(How = How.Id, Using = "BtnNew")]
        public IWebElement SalesRepNewSrchBtn { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSalesRepSummary")]
        public IWebElement SalesRepSrchResultsTable { get; set; }
        

        #endregion

        public SalesRepSrchDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? SalesRepFirstName);
            return this;
        }
    }
}
#endregion