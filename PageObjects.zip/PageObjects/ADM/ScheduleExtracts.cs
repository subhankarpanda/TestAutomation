using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ScheduleExtracts : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "fafScheduleDateAndTime")]
		public IWebElement ScheduleDateAndTime { get; set; }

		[FindsBy(How = How.Id, Using = "faftxtEmailList")]
		public IWebElement EmailList { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnComplete")]
		public IWebElement Complete { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "fafGrdActiveExtracs")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "fafGrdActiveExtracs_0_lblTaskName")]
		public IWebElement Status { get; set; }

        #endregion

        public ScheduleExtracts WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Add);
            return this;
        }
    }
}
