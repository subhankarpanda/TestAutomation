using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SearchTypesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClearAll")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSearchType_0_chkSelSearchType")]
		public IWebElement dgridSearce0SelSearchType { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSearchType_1_chkSelSearchType")]
		public IWebElement dgridSearce1SelSearchType { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSearchType_dgridSearchType")]
		public IWebElement Table { get; set; }

		#endregion

        public SearchTypesDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Table);
            return this;
        }

	}
}
