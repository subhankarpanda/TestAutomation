﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class SecurityMaintenanceNavigationSubPane : PageObject
    {
        [FindsBy(How = How.CssSelector, Using = "li[title='Employee Security']>a")]
        public IWebElement EmployeeSecurity { get; set; }

        //public EmployeeSecutiry LoadEmployeeSecurityScreen()
        //{
        //    this.SwitchToLeftNavigationPane();
        //    EmployeeSecurity.Click();
        //    return FastDriver.GetPage<EmployeeSecutiry>();
        //}
    }
}
