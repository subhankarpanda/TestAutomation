using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SecurityOfficeGroupChangeHistory : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "divGridBody")]
		public IWebElement divGridBody { get; set; }

		[FindsBy(How = How.LinkText, Using = "Office Group Change History ")]
		public IWebElement OfficeGroupChangeHistory { get; set; }

		[FindsBy(How = How.Id, Using = "dgOfficeGroupHistoryEvents_dgOfficeGroupHistoryEvents")]
		public IWebElement OfficeGroupChangeHistoryTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgOfficeGroupHistoryEvents_1_lblTicketNum")]
		public IWebElement TicketNo { get; set; }

		[FindsBy(How = How.Id, Using = "dgOfficeGroupHistoryEvents_0_lblUserName")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.Id, Using = "dgOfficeGroupHistoryEvents_1_lblComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "dgOfficeGroupHistoryEvents_1_lblEventDetail")]
		public IWebElement EventDetail { get; set; }

		[FindsBy(How = How.Id, Using = "dgOfficeGroupHistoryEvents_1_lblEventDate")]
		public IWebElement EventDate { get; set; }

        #endregion

        #region Useful Methods
        public SecurityOfficeGroupChangeHistory WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? OfficeGroupChangeHistoryTable);
            return this;
        }
        #endregion

    }
}
