using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SecurityOfficeGroupSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkActiveOnly")]
		public IWebElement ActiveOnly { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Delete { get; set; }

		[FindsBy(How = How.Id, Using = "cmdViewChangeHistory")]
		public IWebElement ViewchangeHistory { get; set; }

		[FindsBy(How = How.Id, Using = "dgridOffice_0_cbOfficeSelect")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "dgridOfficeGroup_1_txtOfficeGroupName")]
		public IWebElement OfficeGroupName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridOfficeGroup")]
        public IWebElement OfficeGroupTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridOffice")]
		public IWebElement OfficesTable { get; set; }

		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement Error { get; set; }

        #endregion

        #region Useful Methods
        public SecurityOfficeGroupSetup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? OfficesTable);
            return this;
        }
        #endregion

    }
}
