using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectBusinessProgramsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSelBP_0_chkSelBP")]
		public IWebElement BusinessProgramNames { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
		public IWebElement BusinessProgrammeTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
		public IWebElement BusinessProgramTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_0_chkSelBP")]
		public IWebElement dgridSelBP0SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_1_chkSelBP")]
		public IWebElement dgridSelBP1SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_2_chkSelBP")]
		public IWebElement dgridSelBP2SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_3_chkSelBP")]
		public IWebElement dgridSelBP3SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_4_chkSelBP")]
		public IWebElement dgridSelBP4SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_5_chkSelBP")]
		public IWebElement dgridSelBP5SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_6_chkSelBP")]
		public IWebElement dgridSelBP6SelBP { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_7_chkSelBP")]
		public IWebElement dgridSelBP7SelBP { get; set; }

		#endregion

	}
}
