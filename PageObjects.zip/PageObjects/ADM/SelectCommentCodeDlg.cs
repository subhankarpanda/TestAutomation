﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class SelectCommentCodeDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridTTCommentCode_dgridTTCommentCode")]
        public IWebElement CommentCodeTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkCommentCodeRequired")]
        public IWebElement CommentCodeCheckbox { get; set; }

        #endregion

        #region Methods

        public SelectCommentCodeDlg WaitForScreenToLoad(string windowName = "Select Comment Code")
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(CommentCodeTable);
            return this;
        }
        #endregion
    }
}
