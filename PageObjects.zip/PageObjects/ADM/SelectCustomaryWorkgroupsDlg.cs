using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectCustomaryWorkgroups : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "dGridSelectWgs_0_cboxSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "dGridSelectWgs_dGridSelectWgs")]
		public IWebElement WorkGroupNameTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelCustWG_3_labelWorkGPName")]
		public IWebElement WorkGroups { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelCustWG_3_chkSelWG")]
		public IWebElement Ten99SFPUC0011 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelCustWG_dgridSelCustWG")]
		public IWebElement WorkgroupsTable { get; set; }

		#endregion

        #region Useful Methods
        public SelectCustomaryWorkgroups WaitForScreenToLoad(string windowName = "Select Workgroups")
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(WorkgroupsTable, 10);
            return this;
        }
        #endregion
    }
}
