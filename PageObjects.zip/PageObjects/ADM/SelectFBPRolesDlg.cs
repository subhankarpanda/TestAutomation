using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectFBPRolesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "SelectAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.LinkText, Using = "Clear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_0_chkSelInst")]
		public IWebElement AssociatedParty { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_1_chkSelInst")]
		public IWebElement AssumptionLender { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_2_chkSelInst")]
		public IWebElement Attorney_Co_Counsel { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_3_chkSelInst")]
		public IWebElement Attorney_Local { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_4_chkSelInst")]
		public IWebElement Attorney_Primary { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_5_chkSelInst")]
		public IWebElement BrokerDisbursementPayee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_6_chkSelInst")]
		public IWebElement BusinessSource { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_9_chkSelInst")]
		public IWebElement Buyer { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_8_chkSelInst")]
		public IWebElement BuyersAttorney { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_9_chkSelInst")]
		public IWebElement BuyersBroker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_10_chkSelInst")]
		public IWebElement BuyersRealEstateAgent { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_11_chkSelInst")]
		public IWebElement DirectedBy { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_12_chkSelInst")]
		public IWebElement EscrowAssistant { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_13_chkSelInst")]
		public IWebElement EscrowOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_14_chkSelInst")]
		public IWebElement HazardInsuranceUnderwriter { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_15_chkSelInst")]
		public IWebElement HoldFunds_Entry { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_16_chkSelInst")]
		public IWebElement HOA_ManagementCompany { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_17_chkSelInst")]
		public IWebElement HomeWarranty { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_18_chkSelInst")]
		public IWebElement HomeownerAssociation { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_19_chkSelInst")]
		public IWebElement InspectionandRepair { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_20_chkSelInst")]
		public IWebElement InsuranceAgent { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_32_chkSelInst")]
		public IWebElement InvoiceToParty { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_22_chkSelInst")]
		public IWebElement Lender_3rdPartyPayee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_23_chkSelInst")]
		public IWebElement LendersAttorney { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_24_chkSelInst")]
		public IWebElement Lender_MobileBanker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_25_chkSelInst")]
		public IWebElement Lender_MortgageCentre { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_26_chkSelInst")]
		public IWebElement Lender_OriginatingBranch { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_27_chkSelInst")]
		public IWebElement Lender_SigningLocation { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_28_chkSelInst")]
		public IWebElement Lessor { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_29_chkSelInst")]
		public IWebElement Misc_Guarantor_Covenantor { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_30_chkSelInst")]
		public IWebElement Misc_LenderAssignment { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_31_chkSelInst")]
		public IWebElement Misc_LenderPolicy { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_32_chkSelInst")]
		public IWebElement Misc_Non_TitledBorrower { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_33_chkSelInst")]
		public IWebElement MortgageBroker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_34_chkSelInst")]
		public IWebElement MortgageBroker_3rdPartyPayee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_35_chkSelInst")]
		public IWebElement NewLender { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_36_chkSelInst")]
		public IWebElement NewLoan1Lender { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_37_chkSelInst")]
		public IWebElement NewLoan1MortgageBroker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_38_chkSelInst")]
		public IWebElement NewLoan2Lender { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_39_chkSelInst")]
		public IWebElement NewLoan2MortgageBroker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_40_chkSelInst")]
		public IWebElement OtherRealEstateAgent { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_41_chkSelInst")]
		public IWebElement OtherRealEstateBroker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_42_chkSelInst")]
		public IWebElement OutsideEscrowCompany { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_43_chkSelInst")]
		public IWebElement OutsideTitleCompany { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_44_chkSelInst")]
		public IWebElement PayoffLender { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_45_chkSelInst")]
		public IWebElement RecordingCharges3rdPartyPayee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_46_chkSelInst")]
		public IWebElement SalesRep { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_47_chkSelInst")]
		public IWebElement SearchVendor { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_67_chkSelInst")]
		public IWebElement Seller { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_49_chkSelInst")]
		public IWebElement SellersAttorney { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_50_chkSelInst")]
		public IWebElement SellersBroker { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_51_chkSelInst")]
		public IWebElement SellersRealEstateAgent { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_52_chkSelInst")]
		public IWebElement SplitEntity { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_53_chkSelInst")]
		public IWebElement Survey { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_54_chkSelInst")]
		public IWebElement TitleAssistant { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_55_chkSelInst")]
		public IWebElement TitleOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_56_chkSelInst")]
		public IWebElement Trustee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_57_chkSelInst")]
		public IWebElement UtilityCompany { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelFBPRoles_dgridSelFBPRoles")]
		public IWebElement Table { get; set; }

		#endregion

        public SelectFBPRolesDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Table);
            return this;
        }

        public void WaitForScreenToLoadAndSwitch(string windowName = "File Role Recipients", IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? this.Table);
        }

        
	}
}
