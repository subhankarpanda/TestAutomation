using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectInstructionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "CheckAll")]
		public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@value='ClearAll'][@type='button']")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_0_chkSelInst")]
		public IWebElement Select1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_1_chkSelInst")]
		public IWebElement Select2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_dgridSelInstructions")]
		public IWebElement InstructionTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_0_chkSelInst")]
		public IWebElement Instruction0 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_1_chkSelInst")]
		public IWebElement Instruction1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_2_chkSelInst")]
		public IWebElement Instruction2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_3_chkSelInst")]
		public IWebElement Instruction3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_4_chkSelInst")]
		public IWebElement Instruction4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_5_chkSelInst")]
		public IWebElement Instruction5 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_6_chkSelInst")]
		public IWebElement Instruction6 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_7_chkSelInst")]
		public IWebElement Instruction7 { get; set; }

		#endregion

        #region Useful Methods
        public SelectInstructionDlg WaitForScreenLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? InstructionTable);
            return this;
        }
        #endregion

    }
}
