using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectOfficeDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
		public IWebElement OfficeTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		#endregion

        public SelectOfficeDlg WaitForScreenToLoad(IWebElement element = null)
        {
            try
            {
                //this.SwitchToContentFrame();
                this.WaitForFrameAndSwitchByFrameId(GetTopDialogFrameId());
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
                this.WaitCreation(element ?? Clear);
            }
            catch (Exception e)
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                this.WaitForFrameAndSwitchByFrameId(GetTopDialogFrameId());
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }

            return this;
        }

        public bool AllItemSelected()
        {
            foreach (var checkbox in OfficeTable.FindElements(By.TagName("input")).Where(i => i.FAGetAttribute("id").Contains("_chkSelBP") && i.Displayed))
            {
                if (!checkbox.Selected)
                {
                    return false;
                }
            }

            return true;
        }

        public bool AllItemNotSelected()
        {
            foreach (var checkbox in OfficeTable.FindElements(By.TagName("input")).Where(i => i.FAGetAttribute("id").Contains("_chkSelBP") && i.Displayed))
            {
                if (checkbox.Selected)
                {
                    return false;
                }
            }

            return true;
        }

        public string ToggleOffice(bool selectBusName = true)
        {
            for (int i = 1; i < OfficeTable.GetRowCount(); i++)
            {
                if (selectBusName)
                {
                    if (!OfficeTable.PerformTableAction(i, 1, TableAction.GetElementFromTableCell, "input").Element.Selected)
                    {
                        OfficeTable.PerformTableAction(i, 1, TableAction.On);
                        return OfficeTable.PerformTableAction(i, 2, TableAction.GetElementFromTableCell, "span").Element.FAGetText().Clean();
                    }
                }
                else
                {
                    if (OfficeTable.PerformTableAction(i, 1, TableAction.GetElementFromTableCell, "input").Element.Selected)
                    {
                        OfficeTable.PerformTableAction(i, 1, TableAction.Off);
                        return OfficeTable.PerformTableAction(i, 2, TableAction.GetElementFromTableCell, "span").Element.FAGetText().Clean();
                    }
                }
            }
            return "";
        }

        private static string GetTopDialogFrameId()
        {
            try
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                var elements = FastDriver.WebDriver.FindElements(By.XPath("//iframe[@class='dialog-iframe'][starts-with(@id, 'FAFDialog_')]"));
                return elements.LastOrDefault().GetAttribute("id");
            }
            catch (Exception)
            {
                return "";
            }
        }

	}
}
