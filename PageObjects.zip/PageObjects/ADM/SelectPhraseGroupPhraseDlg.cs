using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SelectPhraseGroupPhraseDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnPrev")]
		public IWebElement Previous { get; set; }

		[FindsBy(How = How.Id, Using = "btnNext")]
		public IWebElement Next { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnFinished")]
		public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSrch")]
        public IWebElement SearchButton { get; set; }

		[FindsBy(How = How.LinkText, Using = "RegressionBR PGP4")]
		public IWebElement PhraseGroup { get; set; }

		[FindsBy(How = How.LinkText, Using = "New created phrase1")]
		public IWebElement Phrase { get; set; }

        [FindsBy(How = How.Id, Using = "divGridBody")]
        public IWebElement PhraseGroupTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPhrases_dgridPhrases")]
        public IWebElement PhraseGroupTable2 { get; set; }
		#endregion
        public SelectPhraseGroupPhraseDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Select Phrase Group");
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Done);

            return this;
        }
	}
}
