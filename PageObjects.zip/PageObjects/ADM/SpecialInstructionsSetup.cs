using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.ADM
{
	public class LeftFrame : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//a[contains(@class,'cTVa')]")]
		public IWebElement SpecialInstructionsSetup { get; set; }

        [FindsBy(How = How.LinkText, Using = "System Maintenance")]
        public IWebElement SystemMaintenance { get; set; }

        [FindsBy(How = How.LinkText, Using = "Business Program Setup")]
        public IWebElement BusinessProgramSetup { get; set; }

        [FindsBy(How = How.LinkText, Using = "Maintain Corporate Business Programs")]
        public IWebElement MaintainCorporateBusinessPrograms { get; set; }

        [FindsBy(How = How.LinkText, Using = "Maintain Regional Business Programs")]
        public IWebElement MaintainRegionalBusinessPrograms { get; set; }

        [FindsBy(How = How.LinkText, Using = "Assign Office Business Programs")]
        public IWebElement AssignOfficeBusinessPrograms { get; set; }

        //[FindsBy(How = How.XPath, Using = "//a[contains(@class,'cTVa') and text()='Special Instructions Setup']")]
        //public IWebElement SpecialInstructionsSetup1 { get; set; }
        //[FindsBy(How = How.XPath, Using = "//a[contains(@class, 'cTVa') and contains(text(),'Special Instructions Setup')]")]
        //public IWebElement SpecialInstructionsSetup2 { get; set; }
        //[FindsBy(How = How.CssSelector, Using = "//a[contains(@class, 'cTVa') and contains(text(),'Special Instructions Setup')]")]
        //public IWebElement SpecialInstructionsSetup2 { get; set; }

        #endregion

        public LeftFrame WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(element ?? SystemMaintenance);

            return this;
        }

    }
	public class SpecialInstructionsSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInstructions_0_chkSearchInstruction")]
		public IWebElement searchInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInstructions_0_chkFileProcessing")]
		public IWebElement FileProcessingInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInstructions_0_txtInstName")]
		public IWebElement SpecialInstructions { get; set; }

         //Release 10.7: This is weird! This ID keeps on changing everytime. Look for both ID's.
        [FindsBy(How = How.Id, Using = "dgridInstructions")]
        [FindsBy(How = How.Id, Using = "dgridInstructions_dgridInstructions")]
        public IWebElement SpecialInstructionsTable { get; set; }

        // Release 10.6
        ////[FindsBy(How = How.Id, Using = "dgridInstructions_dgridInstructions")]
        ////public IWebElement SpecialInstructionsTable { get; set; }

        // Release 10.5
        //[FindsBy(How = How.Id, Using = "dgridInstructions")]
        //public IWebElement SpecialInstructionsTable { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement SpecialInstructionCell { get; set; }

		#endregion
        public SpecialInstructionsSetup WaitForScreenToLoad(IWebElement element=null)
        {
            
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Add);
            return this;
        }
        //
        public SpecialInstructionsSetup Open()
        {

            try
            {
                string EntirePathOfLink = "Home>System Maintenance>Special Instructions Setup";
                string LinkText = EntirePathOfLink.Substring(EntirePathOfLink.LastIndexOf('>') + 1);
                IWebElement ParentLink = null;
                FastDriver.LeftNavigation.Navigate<HomePage>(EntirePathOfLink);
                FastDriver.LeftNavigation.SwitchToLeftNavigationPane();
                IWebElement ParentDiv = FastDriver.WebDriver.FindElement(By.Id("divBody"));
                    List<IWebElement> All = ParentDiv.FindElements(By.LinkText(LinkText)).GetAllVisible();
                    ParentLink = ParentDiv.FindElement(By.TagName("li"));
                    if (ParentLink.Text.Contains(LinkText))
                   ParentLink.FAClick(); 
                this.WaitForScreenToLoad();
                return this;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Failed" + ex.Message, false);
                throw;
            }
        }
        //public SpecialInstructionsSetup Open()
        //{
        //    FastDriver.LeftNavigation.Navigate<SpecialInstructionsSetup>("Home>System Maintenance>Special Instructions Setup");
        //    FastDriver.LeftFrame.SwitchToLeftNavigationPane();
        //    FastDriver.LeftFrame.SpecialInstructionsSetup.FAClick();
        //    this.WaitForScreenToLoad();
        //    return this;
        //}

        public bool AddNewInstruction(string Instruction, bool isSearchInstr=true,bool isFileProcInstr=true)
        {
            try
            {
                this.WaitForScreenToLoad();
                this.Add.FAClick();
                Thread.Sleep(3000);
                this.WaitForScreenToLoad();
                int NewRow = SpecialInstructionsTable.GetRowCount()-1;
                IWebElement NewInstruction = SpecialInstructionsTable.FindElement(By.Id("dgridInstructions_" + NewRow + "_txtInstName"));
                IWebElement chkFP = SpecialInstructionsTable.FindElement(By.Id("dgridInstructions_" + NewRow + "_chkFileProcessing"));
                IWebElement chkSearchInstr = SpecialInstructionsTable.FindElement(By.Id("dgridInstructions_" + NewRow + "_chkSearchInstruction"));
                NewInstruction.FASetText(Instruction);
                if (isSearchInstr)
                    chkSearchInstr.FASetCheckbox(true);
                if (isFileProcInstr)
                    chkFP.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                Thread.Sleep(3000);
                this.WaitForScreenToLoad();
                if (SpecialInstructionsTable.FAGetText().Contains(Instruction))
                    return true;
                else
                    return false;
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }


	}
}
