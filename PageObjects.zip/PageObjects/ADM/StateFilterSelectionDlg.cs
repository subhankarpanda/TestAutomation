using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class StateFilterSelectionDlg : PageObject
	{
        public string WindowTitle { get { return "State Filter Selection"; } }

		#region WebElements

		[FindsBy(How = How.Id, Using = "btnState")]
		public IWebElement AddRemoveState { get; set; }

		#endregion

        public StateFilterSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(WindowTitle, true, 15);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? AddRemoveState);

            return this;
        }

	}
}
