﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.ADM
{
    public class StateLocalInformation : PageObject
    {
        #region Common WebElements
        [FindsBy(How = How.Id, Using = "cmdApply")]
        public IWebElement TaxMaintenanceApply { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement TaxMaintenanceRemove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement TaxMaintenanceNew { get; set; }

        [FindsBy(How = How.Id, Using = "cboTaxType")]
        public IWebElement TaxType { get; set; }

        [FindsBy(How = How.Id, Using = "txtEffDate")]
        public IWebElement TaxMaintenanceEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "rdoRate")]
        public IWebElement RatePercent { get; set; }

        [FindsBy(How = How.Id, Using = "rdoDollar")]
        public IWebElement DollarAmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtValue")]
        public IWebElement Value { get; set; }

        [FindsBy(How = How.Id, Using = "txtPercent")]
        public IWebElement Per { get; set; }

        [FindsBy(How = How.Id, Using = "cboTaxCompute")]
        public IWebElement TaxComputeBasis { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTaxes")]
        public IWebElement TaxesTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtFIPSCode")]
        public IWebElement FIPSCode { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseType_chkActiveOnly")]
        public IWebElement LicenseTypeActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseType_cmdViewChangeStatusLicenseType")]
        public IWebElement LicenseViewChangeStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseType_cmdAddLicenseType")]
        public IWebElement LicenseNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseType_dgridLicenseTypes")]
        public IWebElement LicenseListTable { get; set; }

        [FindsBy(How = How.Id, Using = "tdTaxName")]
        public IWebElement TaxStateLocalName { get; set; }
        #endregion

        #region State Information WebElements
        [FindsBy(How = How.Id, Using = "dgridLocal_dgridLocal")]
        public IWebElement StateListTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkGovtReport")]
        public IWebElement GovtReportable { get; set; }

        [FindsBy(How = How.Id, Using = "chkRateType")]
        public IWebElement RateType { get; set; }

        [FindsBy(How = How.Id, Using = "chkTranCode")]
        public IWebElement TransactionCode { get; set; }

        [FindsBy(How = How.Id, Using = "chkEndorse")]
        public IWebElement ItemizePoliciesEndorsements { get; set; }

        [FindsBy(How = How.Id, Using = "chkOrigin")]
        public IWebElement ItemizeLoanOriginationCharges { get; set; }
        #endregion

        #region Local Information WebElements
        [FindsBy(How = How.Id, Using = "cmdLocalApply")]
        public IWebElement LocalApply { get; set; }

        [FindsBy(How = How.Id, Using = "cmdLocalNew")]
        public IWebElement LocalNew { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        public IWebElement CountyName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLocal_dgridLocal")]
        public IWebElement CountyListTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkAvailable")]
        public IWebElement FastSearchAvailableIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "lboxLegalDesc")]
        public IWebElement LegalDescriptions { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLocal_dgridLocal")] // CityListTable and CountyListTable have the same ID. To avoid confusion with table name, created web element entry, with different name.
        public IWebElement CityListTable { get; set; }
        #endregion

        #region Useful Methods
        public StateLocalInformation WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? StateListTable);
            return this;
        }
        #endregion


    }
}
