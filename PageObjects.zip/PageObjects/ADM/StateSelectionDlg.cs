using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class StateSelectionDlg : PageObject
    {
        public string WindowTitle { get { return "State Selection"; } }

        #region WebElements

        [FindsBy(How = How.Id, Using = "btnCheckAll")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdState_0_chkSelState")]
        public IWebElement grdState0SelState { get; set; }

        [FindsBy(How = How.Id, Using = "grdState_5_chkSelState")]
        public IWebElement grdState5SelState { get; set; }

        [FindsBy(How = How.Id, Using = "grdState_8_chkSelState")]
        public IWebElement grdState8SelState { get; set; }

        [FindsBy(How = How.Name, Using = "grdState_grdState")]
        public IWebElement table { get; set; }

        [FindsBy(How = How.Id, Using = "grdState_5_chkSelState")]
        public IWebElement StateSelect { get; set; }

        #endregion

        #region Services
        public StateSelectionDlg WaitForScreenToLoad(IWebElement element = null, bool provinceSelection = false)
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(provinceSelection ? "Province Selection" : WindowTitle, true, 15);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Clear);
            return this;
        }
        #endregion

    }
}
