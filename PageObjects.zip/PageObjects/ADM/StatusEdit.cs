using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.ADM
{
	public class StatusEdit : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdDeactivate")]
		public IWebElement Deactivate { get; set; }

		[FindsBy(How = How.Id, Using = "textComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrStatus")]
		public IWebElement Inactive { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@accesskey='A']")]
		public IWebElement Activate { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrStatus")]
		public IWebElement Active { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrDate")]
		public IWebElement StatusChangedDate { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrLoggedOnUname")]
		public IWebElement StatusChangedBy { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement ErrorMessage { get; set; }

		[FindsBy(How = How.Id, Using = "laCurrLoggOnUname")]
		public IWebElement StatusChangedBy1 { get; set; }

        [FindsBy(How = How.Id, Using = "labelCreatedDate")]
        public IWebElement CreatedOn { get; set; }

        [FindsBy(How = How.Id, Using = "labelCreatedUname")]
        public IWebElement CreatedOnBy { get; set; }

        [FindsBy(How = How.Id, Using = "labelDeactivatedDate")]
        public IWebElement DeactivatedOn { get; set; }

        [FindsBy(How = How.Id, Using = "labelDeactivatedUname")]
        public IWebElement DeactivatedOnBy { get; set; }

        [FindsBy(How = How.Id, Using = "labelLastActivatedDate")]
        public IWebElement LastActivatedOn { get; set; }

        [FindsBy(How = How.Id, Using = "labelLastActivatedUname")]
        public IWebElement LastActivatedOnBy { get; set; }

        #endregion
        public StatusEdit WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Comments);

            return this;
        }

        public StatusEdit WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Active);
            return this;
        }

        public void ChangeStatus(bool activate) {
            if (activate)
            {
                Activate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad(Deactivate);
            }
            else
            {
                Deactivate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true);
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad(Activate);
            }
        }

        public string GetStatus() {
            return Active.FAGetText();
        }

        public Dictionary<string, string> GetCreatedOn() {
            Dictionary<string, string> createdOn = new Dictionary<string, string>();
            createdOn.Add("dateTime", CreatedOn.FAGetText());
            createdOn.Add("by", CreatedOnBy.FAGetText());

            return createdOn;
        }

        public Dictionary<string, string> GetDeactivatedOn(bool formatDate = true) {
            Dictionary<string, string> deactivatedOn = new Dictionary<string, string>();
            deactivatedOn.Add("dateTime", DeactivatedOn.FAGetText());
            deactivatedOn.Add("by", DeactivatedOnBy.FAGetText());

            return deactivatedOn;
        }

        public Dictionary<string, string> GetLastActivatedOn() {
            Dictionary<string, string> lastActivated = new Dictionary<string, string>();
            lastActivated.Add("dateTime", LastActivatedOn.FAGetText());
            lastActivated.Add("by", LastActivatedOnBy.FAGetText());

            return lastActivated;
        }
    }
}
