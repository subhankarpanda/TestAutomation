using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class SuccessorSetupDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.CssSelector, Using = "td#divPackageGridView table#idGVTableBody tr:nth-child(1) td:nth-child(1) input")]
		public IWebElement PathName { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divPackageGridView table#idGVTableBody tr:nth-child(1) td:nth-child(2) select")]
		public IWebElement PathType { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(1) td:nth-child(1) select")]
		public IWebElement Task1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(1) td:nth-child(2) select")]
		public IWebElement Status1 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement InheritFlag { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(2) td:nth-child(1) select")]
		public IWebElement Task2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(2) td:nth-child(2) select")]
		public IWebElement Status2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(3) td:nth-child(1) select")]
		public IWebElement Task3 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(3) td:nth-child(2) select")]
		public IWebElement Status3 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(4) td:nth-child(1) select")]
		public IWebElement Task4 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#divTaskGridView table#idGVTableBody tr:nth-child(4) td:nth-child(2) select")]
		public IWebElement Status4 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Task5 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Status5 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Task6 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Status6 { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddTask")]
		public IWebElement AddTask { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddPackage")]
		public IWebElement AddPath { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemovePackage")]
		public IWebElement Remove { get; set; }

		//TODO: ADD FindsByAttribute
        //table#fraTest td#divTaskGridView #idGVTableBody
        [FindsBy(How = How.CssSelector, Using = "td#divProcessGridView table#idGVTableBody tr:nth-child(1) td:nth-child(1) select")]
        public IWebElement TaskSuccProcessType { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddProcess")]
		public IWebElement AddProcess { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemoveTask")]
		public IWebElement RemoveTask { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement PathName2 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement PathType2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divPackageGridView #idGVTableBody")]
        public IWebElement SuccessorPathDetailsTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divTaskGridView #idGVTableBody")]
        public IWebElement TaskDetailsTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table#fraTest td#divTaskGridView #idGVTableBody")]
        public IWebElement TaskTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divProcessGridView #idGVTableBody")]
        public IWebElement ProcessTypeTable { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement TaskSuccProcessType2 { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemoveProcess")]
		public IWebElement RemoveProcess { get; set; }

		#endregion

        #region Useful methods
        public SuccessorSetupDlg WaitForScreenToLoad(IWebElement element = null)
        { 
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? Done);
            return this;
        }

        #endregion
    }
}
