﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class SystemMaintenanceNavigation : PageObject
    {
        [FindsBy(How = How.CssSelector, Using = "li[title='Address Book']>a")]
        public IWebElement AddressBook { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='GAB Entry Request Queue']>a")]
        public IWebElement GABEntryRequestQueue { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Business Unit']>a")]
        public IWebElement BusinessUnit { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Document Preparation']>a")]
        public IWebElement DocumentPreparation { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Security Maintenance']>a")]
        public IWebElement SecurityMaintenance { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Employee Setup']>a")]
        public IWebElement EmployeeSetup { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Printer Configuration']>a")]
        public IWebElement PrinterConfiguration { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Threshold Amount Setup']>a")]
        public IWebElement ThresholdAmountSetup { get; set; }

        public AddressBookSearch LoadAddressBook()
        {
            this.SwitchToLeftNavigationPane();
            AddressBook.Click();
            
            return FastDriver.GetPage<AddressBookSearch>();
        }

        public ThresholdAmountSetup LoadThresholdAmountSetup()
        {
            this.SwitchToLeftNavigationPane();
            ThresholdAmountSetup.Click();
            this.WaitCreation(ThresholdAmountSetup);
            ThresholdAmountSetup.Click();
            
            return FastDriver.GetPage<ThresholdAmountSetup>();
        }

        public SecurityMaintenanceNavigationSubPane LoadSecurityMaintenanceSubPane()
        {
            this.SwitchToLeftNavigationPane();
            SecurityMaintenance.Click();
            
            return FastDriver.GetPage<SecurityMaintenanceNavigationSubPane>();
        }
    }
}