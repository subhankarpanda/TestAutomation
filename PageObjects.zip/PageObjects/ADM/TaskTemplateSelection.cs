using System;
using System.Threading;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects.ADM;
using System.Linq;

namespace FASTSelenium.PageObjects.ADM
{
    public class TaskTemplateSelection : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgSummaryGrid")]
        public IWebElement Categories { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnNotification")]
        public IWebElement Notification { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_chkSelect")]
        public IWebElement SelectTask { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement FriendlyTaskName { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Public { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement myFirstAmSelect { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_12_txtTaskName")]
        public IWebElement TaskName { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_3_txtCustSeqNum")]
        public IWebElement myFirstAmNumber { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_dgTasks")]
        public IWebElement TasksForTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblTaskName")]
        public IWebElement AUTOProActiveElement { get; set; }

        [FindsBy(How = How.LinkText, Using = "TaskName1")]
        public IWebElement TaskName1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "TaskName10")]
        public IWebElement TaskName10 { get; set; }

        [FindsBy(How = How.LinkText, Using = "TaskName11")]
        public IWebElement TaskName11 { get; set; }

        [FindsBy(How = How.LinkText, Using = "TaskName12")]
        public IWebElement TaskName12 { get; set; }

        [FindsBy(How = How.LinkText, Using = "TaskName13")]
        public IWebElement TaskName13 { get; set; }

        [FindsBy(How = How.LinkText, Using = "AUTO_ProActiveTask_DONOTTOUCH_Task1")]
        public IWebElement TasksFor { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_14_lblTaskName")]
        public IWebElement TaskElement { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement NotificationElement { get; set; }

        #endregion

        #region Useful Methods
        public TaskTemplateSelection WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }

        public TaskTemplateSelection WaitForTasksForTableToRefresh()
        {
            this.WaitCreation(TasksForTable);
            return this;
        }
        //
        public TaskTemplateSelection Open()
        {
            FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();
            return this;
        }
        //
        public bool CheckIfTaskExists(string TaskName)
        {
            this.WaitForScreenToLoad();
            if (FastDriver.TaskTemplateSelection.TasksForTable.FAGetText().Contains(TaskName))
            {
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction("Task Name", TaskName, "Task Name", TableAction.Click);
                return true;
            }
            return false;
        }

        public string CreateNewTask(string TaskName = "")
        {
            this.WaitForScreenToLoad();
            if (string.IsNullOrEmpty(TaskName))
                TaskName = "Task_No_" + Guid.NewGuid().GetHashCode();
            Reports.TestStep = "Create new task.";
            int RowCount = FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount();
            FastDriver.TaskTemplateSelection.New.FAClick();
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                return RowCount < FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(); //continue when new row is added
            }, timeout: 30, idleInterval: 1);
            FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
            FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(RowCount + 1, 3, TableAction.SetText, TaskName);
            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            Thread.Sleep(5000);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            return TaskName;
        }

        public void CreateNewTask(WorkflowProcessTask task, bool publicTask = false, bool addCommentCodes = false)
        {
            WaitForScreenToLoad();

            Reports.TestStep = "Create new task.";
            int rowCount = FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount();
            FastDriver.TaskTemplateSelection.New.FAClick();
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                return rowCount < FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(); //continue when new row is added
            }, timeout: 30, idleInterval: 1);
            FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(rowCount + 1, 3, TableAction.SetText, task.Name);

            if (publicTask)
            {
                Reports.TestStep = "Set task as public.";
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(rowCount + 1, 5, TableAction.SelectItem, "Yes");
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(rowCount + 1, 4, TableAction.SetText, task.Name);
            }

            if (addCommentCodes)
            {
                Reports.TestStep = "Add comment codes.";
                FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(rowCount + 1, 9, TableAction.Click);
                FastDriver.CommentCodeDlg.WaitForScreenToLoad();
                FastDriver.CommentCodeDlg.CommentCodeTable.PerformTableAction(2, task.CommentCodes.First().Code, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad(FastDriver.TaskTemplateSelection.TasksForTable);
            }

            FastDriver.BottomFrame.Save();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
        }

        #endregion
    }
}
