using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
	public class TaskTemplateSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgTasks_30_chkSelect")]
		public IWebElement SelTask30 { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_31_chkSelect")]
		public IWebElement SelTask31 { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_32_chkSelect")]
		public IWebElement SelTask32 { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelecTasks")]
		public IWebElement SelectTasks { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelectTasks")]
        public IWebElement SelectTasksIIS { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_33_chkSelect")]
		public IWebElement SelTask33 { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_34_chkSelect")]
		public IWebElement SelTask34 { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_dgTasks")]
		public IWebElement TaskTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnRmv")]
        public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddMisc")]
		public IWebElement AddMisc { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_0_chkSelect")]
		public IWebElement SelTask1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_1_chkSelect")]
		public IWebElement SelTask2 { get; set; }

		[FindsBy(How = How.LinkText, Using = "TaskName1")]
		public IWebElement TaskName1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "TaskName10")]
		public IWebElement TaskName10 { get; set; }

		[FindsBy(How = How.LinkText, Using = "TaskName11")]
		public IWebElement TaskName11 { get; set; }

		[FindsBy(How = How.LinkText, Using = "TaskName12")]
		public IWebElement TaskName12 { get; set; }

		[FindsBy(How = How.LinkText, Using = "TaskName13")]
		public IWebElement TaskName13 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Title")]
		public IWebElement Title { get; set; }

		[FindsBy(How = How.LinkText, Using = "ADEC-ITI-BILL-FULL-SP")]
		public IWebElement TaskName14 { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.LinkText, Using = "PSG_AUTO_Task1")]
		public IWebElement PSGTask { get; set; }

		[FindsBy(How = How.Id, Using = "btnNew1")]
		public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnChkAll")]
        public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "dgTasks_dgTasks")]
		public IWebElement TasksForTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgSmry")]
        public IWebElement CategoriesTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelectTasks")]
        public IWebElement SelectTask { get; set; }

        [FindsBy(How = How.Id, Using = "dgSummaryGrid")]
        public IWebElement TaskCategoryTable { get; set; }

        #endregion

        #region Useful Methods
        public TaskTemplateSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? TasksForTable);
            return this;
        }

        public void OverrideTask(int columnToSearchIndex, string searchValue = "PSG_AUTO_Task1", string friendlyTaskName = null, bool isPublic = false, bool clickOnSelectTask = false)
        {
            WaitForScreenToLoad();

            TasksForTable.PerformTableAction(columnToSearchIndex, searchValue, 2, TableAction.On);
            TasksForTable.PerformTableAction(3, searchValue, 5, TableAction.SelectItem, isPublic ? "Yes" : "No");

            if (friendlyTaskName != null)
                TasksForTable.PerformTableAction(3, searchValue, 4, TableAction.SetText, friendlyTaskName);

            TasksForTable.PerformTableAction(3, searchValue, 4, TableAction.Click);

            if (clickOnSelectTask)
                SelectTasks.FAClick();
        }

        public void AddNewTask(string taskName,  bool isPublic = false, string friendlyTaskName = null, string myFirstAm = null, bool selectTask = false)
        {
            WaitForScreenToLoad();
            int rowCount;
            
            New.FAClick();
            rowCount = TasksForTable.GetRowCount();
            

            TasksForTable.PerformTableAction(rowCount, 3, TableAction.SetText, taskName);
            TasksForTable.PerformTableAction(rowCount, 5, TableAction.SelectItem, isPublic ? "Yes" : "No");

            if (isPublic)
            {
                if (friendlyTaskName == null)
                    friendlyTaskName = taskName;

                TasksForTable.PerformTableAction(rowCount, 4, TableAction.SetText, friendlyTaskName);
                
                if (myFirstAm != null)
                    TasksForTable.PerformTableAction(rowCount, 7, TableAction.SelectItem, myFirstAm);
            }

            TasksForTable.PerformTableAction(rowCount, 2, TableAction.On);

            if (selectTask)
                SelectTasks.FAClick();
        }
        //
        public void AddMiscTask(string taskName, bool isPublic = false, string friendlyTaskName = null, string myFirstAm = null, bool selectTask = false)
        {
            WaitForScreenToLoad();
            this.AddMisc.FAClick();
            FastDriver.AddNewMiscellaneousTaskDlg.WaitForScreenToLoad();
            FastDriver.AddNewMiscellaneousTaskDlg.Name.FASetText(taskName);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment please...", false);
        }
        //
        public void AddExistingTask(TaskTemplateParameters TaskParams)
        {
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();

            IWebElement Categories;
            if(FastDriver.TaskTemplateSelectionDlg.TaskCategoryTable.IsDisplayed())
                Categories = FastDriver.TaskTemplateSelectionDlg.TaskCategoryTable;
            else
                Categories = FastDriver.TaskTemplateSelectionDlg.CategoriesTable;
            Categories.PerformTableAction("Task Category", TaskParams.TaskCategory, "Task Category", TableAction.Click);
            FastDriver.TaskTemplateSelectionDlg.WaitCreation(FastDriver.TaskTemplateSelectionDlg.TasksForTable);
            FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 2, TableAction.On);
            FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
            if (TaskParams.PublicTask)
            {
                int Cols=FastDriver.TaskTemplateSelectionDlg.TasksForTable.GetColumnCount();
                if (Cols > 5)
                {
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 5, TableAction.SelectItem, "Yes");
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 4, TableAction.SetText, TaskParams.TaskName);
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 7, TableAction.SelectItem, "Both");
                    FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, TaskParams.TaskName, 2, TableAction.On);
                }
            }
            if (FastDriver.TaskTemplateSelectionDlg.SelectTasks.IsDisplayed())
            FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
            else
            FastDriver.TaskTemplateSelectionDlg.SelectTasksIIS.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
        }

        #endregion

    }
}
