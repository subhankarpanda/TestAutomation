using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.ADM
{
    public class TemplateFilterSelectionDlg : PageObject
    {
        public string WindowTitle { get { return "Filter Selection"; } }

        #region WebElements

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "chkAccountSer")]
        public IWebElement AccountServicingCandidate { get; set; }

        [FindsBy(How = How.Id, Using = "chkServiceType")]
        public IWebElement ServiceTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkTitle")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "chkEscrow")]
        public IWebElement Escrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubEscrow")]
        public IWebElement SubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkUndrWriter")]
        public IWebElement UnderWriterSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "lstUndrWriter")]
        public IWebElement UndrWriter { get; set; }

        [FindsBy(How = How.Id, Using = "chkOwningOfc")]
        public IWebElement OwningOfficeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "lstOwningOfc")]
        public IWebElement OwningOffice { get; set; }

        [FindsBy(How = How.Id, Using = "chkPropType")]
        public IWebElement PropertyTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkProductType")]
        public IWebElement ProductTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "lstPropType")]
        public IWebElement PropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "lstProductType")]
        public IWebElement ProductType { get; set; }

        [FindsBy(How = How.Id, Using = "chkBusSegmnt")]
        public IWebElement BusinessSegmentSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkTransType")]
        public IWebElement TrassactionTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "lstBusSegmnt")]
        public IWebElement BussinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "lstTransType")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "chkProgram")]
        public IWebElement ProgrammeTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkSearch")]
        public IWebElement SearchTypeSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "lstProgram")]
        public IWebElement ProgramType { get; set; }

        [FindsBy(How = How.LinkText, Using = "DocPrepTest")]
        public IWebElement ProgramTypeDocPrepTest { get; set; }

        [FindsBy(How = How.Id, Using = "lstSearch")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement DeleteBusinessParty { get; set; }

        [FindsBy(How = How.Id, Using = "cboRoleType")]
        public IWebElement RoleType { get; set; }

        [FindsBy(How = How.Id, Using = "txtDocName")]
        public IWebElement NameIDCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindName")]
        public IWebElement FindName { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindCode")]
        public IWebElement FindCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnSearch")]
        public IWebElement Search { get; set; }

        [FindsBy(How = How.Id, Using = "lstBusParty")] //"23192   -23192   -Lender"
        public IWebElement BusinessPartyParty { get; set; }

        [FindsBy(How = How.Id, Using = "lstOwningRgn")]
        public IWebElement OwningRegion { get; set; }

        [FindsBy(How = How.Id, Using = "chkOwningRgn")]
        public IWebElement OwningRegionSelectAll { get; set; }

        #endregion

        public TemplateFilterSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Title);

            return this;
        }

        public TemplateFilterSelectionDlg EnterTemplateFilteringInformation(
            bool? title = null, bool? escrow = null, bool? subescrow = null,
            bool? underwriterAll = null, string underWriter = null,
            bool? owningRegionAll = null, string owningRegion = null,
            bool? owningOfficeAll = null, string owningOffice = null,
            bool? propertyTypeAll = null, string propertyType = null,
            bool? productTypeAll = null, string productType = null,
            bool? businessSegmentAll = null, string businessSegment = null,
            bool? transTypeAll = null, string transType = null,
            bool? programTypeAll = null, string programType = null,
            bool? searchTypeAll = null, string searchType = null,
            string roleType = null, string nameIdCode = null, bool findCode = false, bool findName = false,
            string businessParty = null)
        {
            WaitForScreenToLoad(Title);

            Title.FASetCheckbox(title);
            Escrow.FASetCheckbox(escrow);
            SubEscrow.FASetCheckbox(subescrow);

            UnderWriterSelectAll.FASetCheckbox(underwriterAll);
            UndrWriter.FASelectItem(underWriter);

            OwningRegionSelectAll.FASetCheckbox(owningRegionAll);
            OwningRegion.FASelectItem(owningRegion);

            OwningOfficeSelectAll.FASetCheckbox(owningOfficeAll);
            OwningOffice.FASelectItem(owningOffice);

            PropertyTypeSelectAll.FASetCheckbox(propertyTypeAll);
            PropertyType.FASelectItem(propertyType);

            ProductTypeSelectAll.FASetCheckbox(productTypeAll);
            ProductType.FASelectItem(productType);

            //BussinessSegment.FASetCheckbox(businessSegmentAll);
            BussinessSegment.FASelectItem(businessSegment);

            TrassactionTypeSelectAll.FASetCheckbox(transTypeAll);
            TransactionType.FASelectItem(transType);

            ProgrammeTypeSelectAll.FASetCheckbox(programTypeAll);
            ProgramType.FASelectItem(programType);

            SearchTypeSelectAll.FASetCheckbox(searchTypeAll);
            SearchType.FASelectItem(searchType);

            RoleType.FASelectItem(roleType);
            NameIDCode.FASetText(nameIdCode);
            if (findName) FindName.FAClick();
            if (findCode) FindCode.FAClick();

            BusinessPartyParty.FASelectItem(businessParty);
            
            //you can add more UI interaction, just add optional patameters which default to null

            return this;
        }

        public TemplateFilterSelectionDlg EnterTemplateFilteringInformationByDefaultAlltheFields()
        {
           
            WaitForScreenToLoad(Title);
            ServiceTypeSelectAll.FASetCheckbox(true);
            UnderWriterSelectAll.FASetCheckbox(true);
            OwningOfficeSelectAll.FASetCheckbox(true);
            PropertyTypeSelectAll.FASetCheckbox(true);
            ProductTypeSelectAll.FASetCheckbox(true);
            TrassactionTypeSelectAll.FASetCheckbox(true);
            BusinessSegmentSelectAll.FASetCheckbox(true);
            ProgrammeTypeSelectAll.FASetCheckbox(true);
            SearchTypeSelectAll.FASetCheckbox(true);

            //you can add more UI interaction, just add optional patameters which default to null

            return this;
        }

        public TemplateFilterSelectionDlg AddStateSelection()
        {
            Reports.TestStep = "Select Geographic Filter for Template.";
            FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad(FastDriver.TemplateFilterSelectionDlg.Select);
            FastDriver.TemplateFilterSelectionDlg.Select.FAClick();

            Reports.TestStep = "Click on AddRemove button for State selection.";
            FastDriver.GeograficFilterSelectionDlg.WaitForScreenToLoad(FastDriver.GeograficFilterSelectionDlg.AddRemoveState);
            FastDriver.GeograficFilterSelectionDlg.AddRemoveState.FAClick();

            Reports.TestStep = "Add a 'CA' state";
            FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.CheckAll);
            FastDriver.StateSelectionDlg.Clear.FAClick();
            FastDriver.StateSelectionDlg.WaitForScreenToLoad(FastDriver.StateSelectionDlg.CheckAll);
            FastDriver.StateSelectionDlg.grdState8SelState.FASetCheckbox(true);
            Playback.Wait(1000);
            FastDriver.StateSelectionDlg.Select.FAClick();
            Playback.Wait(1000);
            FastDriver.DialogBottomFrame.ClickDone();
            return this;
        }
    }
}
