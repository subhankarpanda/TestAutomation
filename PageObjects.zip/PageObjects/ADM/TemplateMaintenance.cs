using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.ADM
{
    public class TemplateMaintenanceInformation : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Information']")]
        public IWebElement linkInformation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Phrases']")]
        public IWebElement linkPhrases { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Formatting']")]
        public IWebElement linkFormatting { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Validation']")]
        public IWebElement linkValidation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Filtering']")]
        public IWebElement linkFiltering { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtName")]
        public IWebElement InformationTemplateName { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_comboRegion")]
        public IWebElement InformationSelectTestFileRegion { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtFileName")]
        public IWebElement InformationTestFileName { get; set; }

        [FindsBy(How = How.Id, Using = "btnPre")]
        public IWebElement InformationView { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtDesc")]
        public IWebElement InformationDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_chkSgnr")]
        public IWebElement InformationSignatureHighlightAllowed { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_lblTTyp")]
        public IWebElement TemplateNamePane { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_chkUnCon")]
        public IWebElement InformationUnderConstruction { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_chkNotificationCandidateYesNo")]
        public IWebElement InformationNotificationAttachmentCandidate { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtCmt")]
        public IWebElement InformationComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_cboName")]
        public IWebElement InformationFontNameType { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_cboSize")]
        public IWebElement InformationFontSize { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_txtTop")]
        public IWebElement InformationMarginTop { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_txtLeft")]
        public IWebElement InformationMarginLeft { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_txtRght")]
        public IWebElement InformationMarginRight { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_optAct")]
        public IWebElement InformationActive { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_optInAct")]
        public IWebElement InformationInactive { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_txtCmt")]
        public IWebElement InformationRevisionHistoryComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_dgridRevHstry_dgridRevHstry")]
        public IWebElement InformationRevisionHistory { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_dgridRevHstry_0_lblRDate")]
        public IWebElement RevisionHistoryRevisedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_dgridRevHstry_0_lblSts")]
        public IWebElement StatusPanRevised { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement Save { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cboTTyp")]
        public IWebElement TemplateType { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_lblSysID")]
        public IWebElement TemplateID { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtFileName")]
        public IWebElement InformationViewText { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_ucTMT_txtCmt")]
        public IWebElement StatusChangeComments { get; set; }
        
        [FindsBy(How = How.Id, Using = "migratedImg")]
        public IWebElement MigratedToNextGenIcon { get; set; }
        #endregion

        public TemplateMaintenanceInformation WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? InformationTemplateName);

            return this;
        }

        public TemplateMaintenanceInformation EnterTemplateInformation(string name = null, string description = null, string comments = null, string fontNameType = null, string fontSize = null, string marginTop = null,
            string marginLeft = null, string marginRight = null, bool? underConstruction = null, bool? inactive = null, bool? active = null, bool? signatureHighlightAllowed = null, bool? notificationAttachmentCandidate = null, string statusChangeComments = null)
        {
            WaitForScreenToLoad(InformationTemplateName);

            InformationUnderConstruction.FASetCheckbox(underConstruction);
            InformationInactive.FASetCheckbox(inactive);
            InformationActive.FASetCheckbox(active);
            StatusChangeComments.FASetText(statusChangeComments);

            InformationTemplateName.FASetText(name);
            InformationDescription.FASetText(description);
            InformationComments.FASetText(comments);

            InformationFontNameType.FASelectItem(fontNameType);
            InformationFontSize.FASelectItem(fontSize);

            InformationMarginTop.FASetText(marginTop);
            InformationMarginLeft.FASetText(marginLeft);
            InformationMarginRight.FASetText(marginRight);

            InformationSignatureHighlightAllowed.FASetCheckbox(signatureHighlightAllowed);
            InformationNotificationAttachmentCandidate.FASetCheckbox(notificationAttachmentCandidate);

            return this;
        }

        public TemplateMaintenancePhrase ClickOnPhraseTab()
        {
            this.SwitchToContentFrame();
            linkPhrases.FAClick();

            return FastDriver.GetPage<TemplateMaintenancePhrase>();
        }

        public TemplateMaintenancePhrase ClickPhrasesTab()
        {
            this.SwitchToContentFrame();
            linkPhrases.FAClick();

            return FastDriver.TemplateMaintenancePhrase;
        }

        public TemplateMaintenanceFormating ClickFormattingTab()
        {
            this.SwitchToContentFrame();
            linkFormatting.FAClick();

            return FastDriver.TemplateMaintenanceFormating;
        }

        public TemplateMaintenanceValidation ClickValidationTab()
        {
            this.SwitchToContentFrame();
            linkValidation.FAClick();

            return FastDriver.TemplateMaintenanceValidation;
        }

        public TemplateMaintenanceFiltering ClickFilteringTab()
        {
            this.SwitchToContentFrame();
            linkFiltering.FAClick();

            return FastDriver.TemplateMaintenanceFiltering;
        }
        //
        public Dictionary<string, string> CreateNewDocumentTemplate(string DataElementGroup, List<string> DataElements, string PhraseType = "Escrow Phrase", string TemplateType = "Escrow Instruction")
        {
            Dictionary<string, string> TemplateDetails = new Dictionary<string, string>();
            try
            {
                Reports.TestStep = "Navigate to Phrase Maintenance and create Phrase";
                FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>("Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();
                FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
                string PhraseGroupName = FastDriver.PhraseGroupMaintenance.CreateNewPhraseGroup();
                //
                FastDriver.PhraseGroupMaintenance.Add.FAClick();
                FastDriver.PhraseMaintenance.WaitForScreenToLoad();
                string PhraseName = FastDriver.PhraseMaintenance.CreateNewPhrase(DataElementGroup, DataElements);
                //
                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.TemplateMaintenanceSummary.Open();
                Reports.TestStep = "Select Template Type and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(TemplateType);
                FastDriver.TemplateMaintenanceSummary.New.FAClick();
                TemplateDetails["TemplateName"] = Support.RandomString("ANANATEST");
                TemplateDetails["TemplateDescription"] = "Template for " + TemplateDetails["TemplateName"];
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkInformation);
                FastDriver.TemplateMaintenanceInformation.linkInformation.FAClick();
                FastDriver.TemplateMaintenanceInformation.EnterTemplateInformation(TemplateDetails["TemplateName"], TemplateDetails["TemplateDescription"], "Comments for Template - " + TemplateDetails["TemplateName"], underConstruction: false);
                Reports.TestStep = "Add Phrases to the Template";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                string FullPhraseName = PhraseGroupName + @"/" + PhraseName;
                FastDriver.PhraseSelectDlg.PhraseName.FASetText(FullPhraseName);
                FastDriver.DialogBottomFrame.ClickDone();
                Reports.TestStep = "Click on Formatting tab and enter required data";
                FastDriver.TemplateMaintenancePhrase.WaitForScreenToLoad();
                FastDriver.TemplateMaintenanceInformation.linkFormatting.FAClick();
                FastDriver.TemplateMaintenanceFormating.EnterFormattingInformation(clickMiddlePages: true, clickFirstPage: true, marginTop: "0.5", marginBtm: "0.5");
                //Reports.TestStep = "Add filters to the template.";
                //FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad(FastDriver.TemplateMaintenanceInformation.linkFiltering);
                //FastDriver.TemplateMaintenanceInformation.linkFiltering.FAClick();
                //FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad(FastDriver.TemplateMaintenanceFiltering.FilteringAdd);
                //FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                //FastDriver.TemplateFilterSelectionDlg.AddStateSelection();
                //FastDriver.TemplateFilterSelectionDlg.EnterTemplateFilteringInformationByDefaultAlltheFields();
                //Reports.TestStep = "Click on Done in Dialog Box.";
                //FastDriver.DialogBottomFrame.ClickDone();
                //FastDriver.WebDriver.WaitForWindowAndSwitch(FastDriver.TemplateFilterSelectionDlg.WindowTitle, false, 15);
                Reports.TestStep = "Click on BottomFrame Save button to Create the template";
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.BottomFrame.Done();
            }
            catch
            {
                throw;
            }
            return TemplateDetails;
        }
    
    }

    public class TemplateMaintenancePhrase : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Information']")]
        public IWebElement linkInformation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Phrases']")]
        public IWebElement linkPhrases { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Formatting']")]
        public IWebElement linkFormatting { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Validation']")]
        public IWebElement linkValidation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Filtering']")]
        public IWebElement linkFiltering { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdAdd")]
        public IWebElement PhrasesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdEdit")]
        public IWebElement PhrasesEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdDelete")]
        public IWebElement PhrasesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdUp")]
        public IWebElement PhrasesUp { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdDown")]
        public IWebElement PhrasesDown { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdPMarker")]
        public IWebElement PhrasesPhraseMarker { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridPhr_0_chkReq")]
        public IWebElement PhrasesRequired { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridPhr_1_lblDescr")]
        public IWebElement DocumentAdded { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridPhr_0_cmdCond")]
        public IWebElement PhrasesConditions { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridPhr")]
        public IWebElement PhrasesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridPhr")]
        public IWebElement PhraseTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridPhr_1_cmdCond")]
        public IWebElement PhrasesConditions1 { get; set; }
              

        //[FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Phrases']")]
        //public IWebElement linkPhrases { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Formatting']")]
        //public IWebElement linkFormatting { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Validation']")]
        //public IWebElement linkValidation { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Filtering']")]
        //public IWebElement linkFiltering { get; set; }

        #endregion

        public TemplateMaintenancePhrase WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? PhrasesAdd);

            return this;
        }

        public PhraseSelectDlg OpenPhraseSelectDialog()
        {
            WaitForScreenToLoad(PhrasesAdd);
            PhrasesAdd.FAClick();

            return FastDriver.PhraseSelectDlg;
        }

        public TemplateMaintenanceFormating ClickOnFormatingTab()
        {
            this.SwitchToContentFrame();
            linkFormatting.FAClick();

            return FastDriver.GetPage<TemplateMaintenanceFormating>();
        }

        public TemplateMaintenancePhrase ClickPhrasesTab()
        {
            this.SwitchToContentFrame();
            linkPhrases.FAClick();

            return FastDriver.TemplateMaintenancePhrase;
        }

        public TemplateMaintenanceFormating ClickFormattingTab()
        {
            this.SwitchToContentFrame();
            linkFormatting.FAClick();

            return FastDriver.TemplateMaintenanceFormating;
        }

        public TemplateMaintenanceValidation ClickValidationTab()
        {
            this.SwitchToContentFrame();
            linkValidation.FAClick();

            return FastDriver.TemplateMaintenanceValidation;
        }

        public TemplateMaintenanceFiltering ClickFilteringTab()
        {
            this.SwitchToContentFrame();
            linkFiltering.FAClick();

            return FastDriver.TemplateMaintenanceFiltering;
        }
      
      

    }

    public class TemplateMaintenanceFormating : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Information']")]
        public IWebElement linkInformation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Phrases']")]
        public IWebElement linkPhrases { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Formatting']")]
        public IWebElement linkFormatting { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Validation']")]
        public IWebElement linkValidation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Filtering']")]
        public IWebElement linkFiltering { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridTFrmt_0_lblPgId")]
        public IWebElement FirstPage { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cboHPhr")]
        public IWebElement FormattingHeaderPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cboFPhr")]
        public IWebElement FormattingFooterPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cboCFr")]
        public IWebElement FormattingContinueFrom { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cboCon")]
        public IWebElement FormattingContinueOn { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtTMgn")]
        public IWebElement FormattingMarginTop { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridTFrmt_1_lblPgId")]
        public IWebElement MiddlePages { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridTFrmt_2_lblPgId")]
        public IWebElement PageBeforeLast { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridTFrmt_3_lblPgId")]
        public IWebElement LastPage { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_txtBMgn")]
        public IWebElement FormattingMarginBottom { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridTFrmt")]
        public IWebElement FormatSummaryTable { get; set; }

        #endregion

        public TemplateMaintenanceFormating WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FirstPage);

            return this;
        }

        public TemplateMaintenanceFormating EnterFormattingInformation(bool clickMiddlePages = false, bool clickFirstPage = false, bool clickPageBeforeLast = false, bool clickLastPage = false, string marginTop = null, string marginBtm = null, string headerPhrase = null, string footerPhrase = null, string continueFrom = null, string continueOn = null)
        {
            WaitForScreenToLoad(MiddlePages);

            if (clickMiddlePages) MiddlePages.FAClick();
            if (clickFirstPage) FirstPage.FAClick();
            if (clickPageBeforeLast) PageBeforeLast.FAClick();
            if (clickLastPage) LastPage.FAClick();

            FormattingHeaderPhrase.FASelectItem(headerPhrase);
            FormattingFooterPhrase.FASelectItem(footerPhrase);
            FormattingContinueFrom.FASelectItem(continueFrom);
            FormattingContinueOn.FASelectItem(continueOn);

            FormattingMarginTop.FASetText(marginTop);
            FormattingMarginBottom.FASetText(marginBtm);

            // add more interaction based on new params

            return this;
        }

        public TemplateMaintenanceValidation ClickOnValidationTab()
        {
            this.SwitchToContentFrame();
            linkValidation.FAClick();

            return FastDriver.GetPage<TemplateMaintenanceValidation>();
        }

        public TemplateMaintenanceFiltering ClickFilteringTab()
        {
            this.SwitchToContentFrame();
            linkFiltering.FAClick();

            return FastDriver.TemplateMaintenanceFiltering;
        }

        public TemplateMaintenancePhrase ClickPhrasesTab()
        {
            this.SwitchToContentFrame();
            linkPhrases.FAClick();

            return FastDriver.TemplateMaintenancePhrase;
        }
   
    }

    public class TemplateMaintenanceValidation : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Information']")]
        public IWebElement linkInformation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Phrases']")]
        public IWebElement linkPhrases { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Formatting']")]
        public IWebElement linkFormatting { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Validation']")]
        public IWebElement linkValidation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Filtering']")]
        public IWebElement linkFiltering { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_btnSelect")]
        public IWebElement ValidationSelect { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_chkProductType")]
        public IWebElement ValidationSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_lstProductType")]//ALTA Equity Loan
        public IWebElement ValidationProductType { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_labelState")]
        public IWebElement State { get; set; }

        #endregion

        public TemplateMaintenanceValidation WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? ValidationSelect);

            return this;
        }

        public TemplateMaintenanceFiltering ClickOnFilteringTab()
        {
            this.SwitchToContentFrame();
            linkFiltering.FAClick();

            return FastDriver.TemplateMaintenanceFiltering;
        }
           

    }

    public class TemplateMaintenanceFiltering : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Information']")]
        public IWebElement linkInformation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Phrases']")]
        public IWebElement linkPhrases { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Formatting']")]
        public IWebElement linkFormatting { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Validation']")]
        public IWebElement linkValidation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabTMPL_FAFTabListContainer']/a[text() = 'Filtering']")]
        public IWebElement linkFiltering { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdCopy_Filter")]
        public IWebElement FilteringCopy { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdAdd_Filter")]
        public IWebElement FilteringAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdEdit_Filter")]
        public IWebElement FilteringEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_cmdDelete_Filter")]
        public IWebElement FilteringRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tabTMPL_dgridResults")]
        public IWebElement TemplateFilter { get; set; }

        #endregion

        public TemplateMaintenanceFormating ClickOnFormatingTab()
        {
            this.SwitchToContentFrame();
            linkFormatting.FAClick();

            return FastDriver.GetPage<TemplateMaintenanceFormating>();
        }

        public TemplateMaintenancePhrase ClickPhrasesTab()
        {
            this.SwitchToContentFrame();
            linkPhrases.FAClick();

            return FastDriver.TemplateMaintenancePhrase;
        }

        public TemplateMaintenanceFormating ClickFormattingTab()
        {
            this.SwitchToContentFrame();
            linkFormatting.FAClick();

            return FastDriver.GetPage<TemplateMaintenanceFormating>();
        }

        public TemplateMaintenanceValidation ClickValidationTab()
        {
            this.SwitchToContentFrame();
            linkValidation.FAClick();

            return FastDriver.GetPage<TemplateMaintenanceValidation>();
        }

        public TemplateMaintenanceFiltering WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FilteringAdd);

            return this;
        }
    }
}
