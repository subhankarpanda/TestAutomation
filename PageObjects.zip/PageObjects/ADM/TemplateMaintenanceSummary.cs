using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class TemplateMaintenanceSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "srch_cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cmdFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cmdNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cboGrpType")]
		public IWebElement TemplateType { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cboGrpStatus")]
		public IWebElement TemplateStatus { get; set; }

		[FindsBy(How = How.Id, Using = "srch_txtDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cboCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "srch_cboCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "rslt_cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "rslt_cmdCopy")]
		public IWebElement Copy { get; set; }

		[FindsBy(How = How.Id, Using = "rslt_cmdSave")]
		public IWebElement Save { get; set; }

		[FindsBy(How = How.Id, Using = "rslt_cmdCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "rslt_dgridMaint_dgridMaint")]
		public IWebElement Results { get; set; }

		[FindsBy(How = How.Id, Using = "rslt_dgridMaint_0_hdnCopyName")]
		public IWebElement CopyName { get; set; }

		[FindsBy(How = How.LinkText, Using = "0 Template For DP0007e BAT")]
		public IWebElement TemplateName { get; set; }

        [FindsBy(How = How.Id, Using = "rslt_dgridMaint_1_lblStatus")]
        public IWebElement Status { get; set; }

		#endregion
        public TemplateMaintenanceSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
            return this;
        }
        //
        public TemplateMaintenanceSummary SearchResultsTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "")
        {
            WaitForScreenToLoad(Results);
            Results.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value);
            return this;
        }

        public TemplateMaintenanceSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);

            return this;
        }
    

        public TemplateMaintenanceSummary WaitForResultsTableToLoad()
        {
            WaitForScreenToLoad(Results);
            return this;
        }
	}
}
