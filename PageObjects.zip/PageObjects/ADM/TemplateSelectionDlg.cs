using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
    public class TemplateSelectionDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "selSource")]
        public IWebElement Source { get; set; }

        [FindsBy(How = How.Id, Using = "templateList")]
        public IWebElement TemplateType { get; set; }

        [FindsBy(How = How.Id, Using = "dgridTemplate_dgridTemplate")]
        public IWebElement TemplateTable { get; set; }

         [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        

        #endregion


        #region Services

        public TemplateSelectionDlg WaitForScreenToLoad()
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            wait.Until(d =>
            {
                FastDriver.WebDriver.SwitchTo().DefaultContent();
                this.SwitchToDialogContentFrame();
                return Source.Exists();
            });
            return this;
        }

        
        #endregion



    }



}