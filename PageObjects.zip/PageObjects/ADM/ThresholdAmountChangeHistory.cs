﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Diagnostics;

namespace FASTSelenium.PageObjects.ADM
{
    public class ThresholdAmountChangeHistory : PageObject
    {
        [FindsBy(How = How.Id, Using = "txtTrckNo")]
        public IWebElement TrackNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtUserNotes")]
        public IWebElement UserNotes { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement CancelButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement OkButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountHistoryEvents_0")]
        public IWebElement AmountHistoryFirstRow { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountHistoryEvents_dgAmountHistoryEvents")]
        public IWebElement AmountHistoryTable { get; set; }

        //public string GetAmountHistoryFirstRowText()
        //{
        //    this.SwitchToContentFrame();
        //    string firstRowText = AmountHistoryTable.PerformTableAction(2, @"FASTTS\FASTQA07", 1, TableAction.GetText).OperationResult;
        //    return firstRowText;
        //}
    }
}
