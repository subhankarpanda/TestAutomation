﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.ADM
{
    public class ThresholdAmountSetup : PageObject
    {

        #region WebElements

        [FindsBy(How = How.Id, Using = "dgAmountSetup")]
        public IWebElement ThresholdAmountSetupTable { get; set; } // Threshold Amount Setup Table

        [FindsBy(How = How.Id, Using = "btnChangeHistory")]
        public IWebElement ChangeHistoryButton { get; set; } // Change History Button

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement DoneButton { get; set; } // Done button 

        [FindsBy(How = How.Id)]
        public IWebElement tblEventSummary { get; set; } // Change History Table 

        [FindsBy(How = How.Id, Using = "dgAmountSetup_0_txtThresholdAmount")]
        public IWebElement ResidentialAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_1_txtThresholdAmount")]
        public IWebElement CommercialAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_2_txtThresholdAmount")]
        public IWebElement NewHomeSubdivisionAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_3_txtThresholdAmount")]
        public IWebElement NewHomeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_4_txtThresholdAmount")]
        public IWebElement SubdivisionAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_5_txtThresholdAmount")]
        public IWebElement DefaultAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_6_txtThresholdAmount")]
        public IWebElement TimeShareAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_7_txtThresholdAmount")]
        public IWebElement DefaultResidentialAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgAmountSetup_8_txtThresholdAmount")]
        public IWebElement DefaultCommercialAmount { get; set; }

        #endregion

        public ThresholdAmountSetup Open(IWebElement elementToWaitFor = null)
        {
            FastDriver.LeftNavigation.Navigate<HomePage>(@"Home>System Maintenance>Threshold Amount Setup").WaitForHomeScreen();
            FastDriver.LeftFrame.SwitchToLeftNavigationPane();
            FastDriver.WebDriver.FindElement(By.ClassName("cTVa")).FAClick();
            this.WaitForScreenToLoad(elementToWaitFor);

            return this;
        }

        public ThresholdAmountSetup WaitForScreenToLoad(IWebElement elememt = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(elememt ?? ResidentialAmount);

            return this;
        }

        //public ThresholdAmountSetup UpdateThresholdAmounts(ThresholdAmountsParameters amounts)
        //{
        //    this.SwitchToContentFrame();

        //    ThresholdAmountSetupTable.PerformTableAction(1, "Residential", 2, TableAction.SendKeys, amounts.Residential);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Commercial", 2, TableAction.SendKeys, amounts.Commercial);
        //    ThresholdAmountSetupTable.PerformTableAction(1, @"New Home/Subdivision", 2, TableAction.SendKeys, amounts.NewHomeSubdivision);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "New Home", 2, TableAction.SendKeys, amounts.NewHome);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Subdivision", 2, TableAction.SendKeys, amounts.Subdivision);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Default", 2, TableAction.SendKeys, amounts.Default);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Time Share", 2, TableAction.SendKeys, amounts.TimeShare);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Default-Residential", 2, TableAction.SendKeys, amounts.DefaultResidential);
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Default-Commercial", 2, TableAction.SendKeys, amounts.DefaultCommercial);


        //    return this;
        //}

        public void SetThresholdAmounts(ThresholdAmountsParameters amounts)
        {
            try
            {
                this.SwitchToContentFrame();
                ResidentialAmount.FASetText(amounts.Residential);
                CommercialAmount.FASetText(amounts.Commercial);
                NewHomeSubdivisionAmount.FASetText(amounts.NewHomeSubdivision);
                NewHomeAmount.FASetText(amounts.NewHome);
                SubdivisionAmount.FASetText(amounts.Subdivision);
                DefaultAmount.FASetText(amounts.Default);
                TimeShareAmount.FASetText(amounts.TimeShare);
                DefaultResidentialAmount.FASetText(amounts.DefaultResidential);
                DefaultCommercialAmount.FASetText(amounts.DefaultCommercial);
            }
            catch (Exception e)
            {
                throw new Exception("Failure in Threshold Amount Setup Screen.", e);
            }
        }

        public void VerifyThresholdAmounts(ThresholdAmountsParameters amounts)
        {
            try
            {
                this.SwitchToContentFrame();
                Support.AreEqual(amounts.Residential, ResidentialAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.Commercial, CommercialAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.NewHomeSubdivision, NewHomeSubdivisionAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.NewHome, NewHomeAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.Subdivision, SubdivisionAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.Default, DefaultAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.TimeShare, TimeShareAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.DefaultResidential, DefaultResidentialAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
                Support.AreEqual(amounts.DefaultCommercial, DefaultCommercialAmount.FAGetValue().ToString().Trim(), bIgnoreCase: true);
            }
            catch (Exception e)
            {
                throw new Exception("Failure in Threshold Amount Setup Screen.", e);
            }
        }


        //public ThresholdAmountsParameters GetThresholdAmounts()
        //{
        //    this.SwitchToContentFrame();
        //    var amounts = new ThresholdAmountsParameters();

        //    amounts.Residential = ThresholdAmountSetupTable.PerformTableAction(1, "Residential", 2, TableAction.GetValue).OperationResult;
        //    amounts.Commercial = ThresholdAmountSetupTable.PerformTableAction(1, "Commercial", 2, TableAction.GetValue).OperationResult;
        //    amounts.NewHomeSubdivision = ThresholdAmountSetupTable.PerformTableAction(1, @"New Home/Subdivision", 2, TableAction.GetValue).OperationResult;
        //    amounts.NewHome = ThresholdAmountSetupTable.PerformTableAction(1, "New Home", 2, TableAction.GetValue).OperationResult;
        //    amounts.Subdivision = ThresholdAmountSetupTable.PerformTableAction(1, "Subdivision", 2, TableAction.GetValue).OperationResult;
        //    amounts.Default = ThresholdAmountSetupTable.PerformTableAction(1, "Default", 2, TableAction.GetValue).OperationResult;
        //    amounts.TimeShare = ThresholdAmountSetupTable.PerformTableAction(1, "Time Share", 2, TableAction.GetValue).OperationResult;
        //    amounts.DefaultResidential = ThresholdAmountSetupTable.PerformTableAction(1, "Default-Residential", 2, TableAction.GetValue).OperationResult;
        //    amounts.DefaultCommercial = ThresholdAmountSetupTable.PerformTableAction(1, "Default-Commercial", 2, TableAction.GetValue).OperationResult;


        //    return amounts;
        //}

        //public ThresholdAmountSetup ClickDoneButton()
        //{
        //    this.SwitchToBottomFrame();
        //    DoneButton.Click();

        //    return this;
        //}

        //public ThresholdAmountSetup ClickResidentialAmountRow()
        //{
        //    this.SwitchToContentFrame();
        //    ThresholdAmountSetupTable.PerformTableAction(1, "Residential", 1, TableAction.Click);

        //    return this;
        //}

        //public ThresholdAmountChangeHistory ClickViewChangeHistory()
        //{
        //    this.SwitchToContentFrame();
        //    ChangeHistoryButton.Click();

        //    return SUTDriver.GetPage<ThresholdAmountChangeHistory>();
        //}
    }

    public class ChangeHistory : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgAmountHistoryEvents")]
        public IWebElement ChangeHistoryTable { get; set; }

        #endregion

        public ChangeHistory WaitForScreenToLoad(IWebElement elememt = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(elememt ?? ChangeHistoryTable);

            return this;
        }
    }

}
