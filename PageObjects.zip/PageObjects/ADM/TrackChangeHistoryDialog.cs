﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System;

namespace FASTSelenium.PageObjects.ADM
{
    public class TrackChangeHistoryDialog : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtTrckNo")]
        public IWebElement TrackNo { get; set; }

        [FindsBy(How = How.Id, Using = "txtUserNotes")]
        public IWebElement UserNotes { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement DoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblEventTime")]
        public IWebElement EventDate { get; set; }

        [FindsBy(How = How.Id, Using = "lblUserName")]
        public IWebElement UserName { get; set; }

        #endregion

        public TrackChangeHistoryDialog WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Track Change History");
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? DoneButton);
            return this;
        }

        public bool IsPresent()
        {
            try{
                FastDriver.WebDriver.SwitchToWindow("Track Change History");
                return true;
            }catch (Exception){
                return false;
            }
        
        }

        public bool IsTrackChangeHistoryDlgVisible()
        {
            try
            {
                WebDriver.SwitchTo().DefaultContent();
                //this.SwitchToDialogContentFrame();
                //this.SwitchToContentFrame();
                return WebDriver.PageSource.Contains("Track Change History");
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        //public TrackChangeHistoryDialog UpdateChanges(FASTSelenium.DataObjects.ADM.TrackChangesDialogParameters changes)
        //{
        //    WebDriver.SwitchToWindow("Track Change History");
        //    this.SwitchToDialogContentFrame();
        //    TrackNo.SendKeys(changes.TrackNo);
        //    UserNotes.SendKeys(changes.UserNotes);
        //    return this;
        //}
    }
}