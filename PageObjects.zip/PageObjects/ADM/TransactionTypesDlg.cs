using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class TransactionTypesDlg : PageObject
	{
        #region WebElements

        [FindsBy(How = How.CssSelector, Using = "button[value=\"CheckAll\"]")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@value='ClearAll']")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridTransaction_0_chkSelTransaction")]
		public IWebElement TransactionSelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgridTransaction_dgridTransaction")]
		public IWebElement Table { get; set; }

		#endregion

        #region Useful Methods
        public TransactionTypesDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Table);
            return this;
        }
        #endregion

    }
}
