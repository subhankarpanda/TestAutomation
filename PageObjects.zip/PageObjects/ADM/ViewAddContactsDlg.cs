using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
    public class ViewAddContactsDlg : PageObject
	{
		#region WebElements - GAB Request Contacts

        [FindsBy(How = How.Id, Using = "dgridBusinessContacts_dgridBusinessContacts")]
		public IWebElement GABRequestContactsTable { get; set; }

		#endregion


        public ViewAddContactsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContactLeftContentFrame();
            this.WaitCreation(element ?? GABRequestContactsTable);
            return this;
        }

        public ViewAddContactsDlg WaitForScreenToLoadRightPane(IWebElement element = null)
        {
            this.SwitchToDialogContactRightContentFrame();
            this.WaitCreation(element ?? GABRequestContactsTable);
            return this;
        }
	}
}
