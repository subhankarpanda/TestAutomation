using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class ViewChangeStatus : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdDeactivate")]
		public IWebElement Deactivate { get; set; }

		[FindsBy(How = How.Id, Using = "textComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrStatus")]
		public IWebElement Inactive { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDeactivate")]
		public IWebElement Activate { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrStatus")]
		public IWebElement Active { get; set; }

		[FindsBy(How = How.Id, Using = "labelCurrDate")]
		public IWebElement StatusChangedDate { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement StatusChangedBy { get; set; }

		#endregion

        public ViewChangeStatus WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Deactivate);
            return this;
        }

	}
}
