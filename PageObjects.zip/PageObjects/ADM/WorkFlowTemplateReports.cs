﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using FASTSelenium.DataObjects.ADM;


namespace FASTSelenium.PageObjects.ADM
{
    public class WorkFlowTemplateReports : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "dGridWorkFlow")]
        public IWebElement UtilityReportTable { get; set; }

        #endregion

        #region Services
        public WorkFlowTemplateReports WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(UtilityReportTable);
            return this;
        }

        public WorkFlowTemplateReports Open()
        {
            FastDriver.LeftNavigation.Navigate<WorkFlowTemplateReports>("Home>System Maintenance>Process Setup>Utility Reports");
            this.WaitForScreenToLoad();
            return this;
        }
        #endregion
    }
}
