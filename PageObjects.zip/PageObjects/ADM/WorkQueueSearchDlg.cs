using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class WorkQueueSearchDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnFind")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelRegion")]
		public IWebElement FAFSelRegion { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelOffice")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "btnRefresh")]
		public IWebElement Refresh { get; set; }

		[FindsBy(How = How.Id, Using = "WQueuesGrid_0_fafUSelected")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "UWQueuesGrid_UWQueuesGrid")]
		public IWebElement UnasgQueue { get; set; }

		[FindsBy(How = How.Id, Using = "WQueuesGrid_WQueuesGrid")]
		public IWebElement AsgQueue { get; set; }

		[FindsBy(How = How.LinkText, Using = "Select?")]
		public IWebElement SelectColumn { get; set; }

		[FindsBy(How = How.LinkText, Using = "Skip Allowed?")]
		public IWebElement SkipAllowed { get; set; }

		[FindsBy(How = How.LinkText, Using = "Work Queue Supervisor?")]
		public IWebElement WorkQueueSupervisor { get; set; }

		[FindsBy(How = How.LinkText, Using = "User Name")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.LinkText, Using = "Region")]
		public IWebElement UserRegion { get; set; }

		[FindsBy(How = How.LinkText, Using = "Office")]
		public IWebElement UserHomeOffice { get; set; }

		[FindsBy(How = How.LinkText, Using = "Default?")]
		public IWebElement Default { get; set; }

		[FindsBy(How = How.LinkText, Using = "Queue Name")]
		public IWebElement QueueName { get; set; }

		[FindsBy(How = How.LinkText, Using = "Region")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.LinkText, Using = "Office")]
		public IWebElement Office1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@name='WQueuesGrid_WQueuesGrid']/tbody/tr/td/table")]
        public IWebElement AssignedQueuesHeader { get; set; }

        #endregion

        public WorkQueueSearchDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FAFSelRegion);
            return this;
        }
    }
}
