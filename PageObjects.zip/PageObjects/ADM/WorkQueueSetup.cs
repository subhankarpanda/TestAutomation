using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class WorkQueueSetup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtQueueName")]
		public IWebElement QueueName { get; set; }

		[FindsBy(How = How.Id, Using = "selStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "chkManualQueue")]
		public IWebElement ManualFTPQueue { get; set; }

		[FindsBy(How = How.Id, Using = "txtFtpServerName")]
		public IWebElement ServerIPAddress { get; set; }

		[FindsBy(How = How.Id, Using = "txtFtpDirectory")]
		public IWebElement Directory { get; set; }

		[FindsBy(How = How.Id, Using = "txtFtpUserName")]
		public IWebElement FtpUserName { get; set; }

		[FindsBy(How = How.Id, Using = "txtFtpPassword")]
		public IWebElement FtpPassword { get; set; }

		[FindsBy(How = How.Id, Using = "chkFaxQueue")]
		public IWebElement FaxQueue { get; set; }

		[FindsBy(How = How.Id, Using = "txtFaxNumber")]
		public IWebElement FaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "txtRFaxNumber")]
		public IWebElement CorporateFaxNumber { get; set; }

		[FindsBy(How = How.Id, Using = "chkEmailQueue")]
		public IWebElement EmailQueue { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmailAcct")]
		public IWebElement EmailAccount { get; set; }

		[FindsBy(How = How.Id, Using = "txtPassword")]
		public IWebElement Password { get; set; }

		[FindsBy(How = How.Id, Using = "chkWebsiteQueue")]
		public IWebElement WebsiteQueue { get; set; }

		[FindsBy(How = How.Id, Using = "txtURL")]
		public IWebElement URL { get; set; }

		[FindsBy(How = How.Id, Using = "chkWebServiceQueue")]
		public IWebElement WebServiceQueue { get; set; }

		[FindsBy(How = How.Id, Using = "txtWebService")]
		public IWebElement WebServiceName { get; set; }

		[FindsBy(How = How.Id, Using = "selXmlViewer")]
		public IWebElement XmlViewerName { get; set; }

		[FindsBy(How = How.Id, Using = "selQueueServer")]
		public IWebElement QueueServer { get; set; }

		[FindsBy(How = How.Id, Using = "chkSkipQueueMsg")]
		public IWebElement Allowskipqueuemessage { get; set; }

		[FindsBy(How = How.Id, Using = "txtQueueFolder")]
		public IWebElement QueueFolderName { get; set; }

		[FindsBy(How = How.Id, Using = "chkLoadBalanceFlg")]
		public IWebElement AutomaticLoadBalance { get; set; }

		[FindsBy(How = How.Id, Using = "txtDaysToRetain")]
		public IWebElement NumberOfDaysToRetainDeleted { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDetails")]
		public IWebElement WorkQueueTriggerNamesButton { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.LinkText, Using = "Error: An invalid Email Password was entered")]
		public IWebElement InvalidPwdMsg { get; set; }

		[FindsBy(How = How.LinkText, Using = "Error: An invalid Email Address was entered")]
		public IWebElement InvalidEmailMsg { get; set; }

		[FindsBy(How = How.LinkText, Using = "Error: An invalid Web Service Name was entered")]
		public IWebElement InvalidWebServName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridWorkQNames_0_WorkQueueName")]
		public IWebElement ImgTriggerName { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        #endregion


        public WorkQueueSetup WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? QueueName);
            return this;
        }
    }
}
