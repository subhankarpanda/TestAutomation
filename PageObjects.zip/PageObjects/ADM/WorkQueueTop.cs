using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class WorkQueueTop : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboQList")]
		public IWebElement SelectQueue { get; set; }

		[FindsBy(How = How.LinkText, Using = "Msgs: 1 ")]
		public IWebElement Msgs { get; set; }

		[FindsBy(How = How.LinkText, Using = "Skp: 0 ")]
		public IWebElement Skp { get; set; }

		[FindsBy(How = How.LinkText, Using = "Unpd: 1 ")]
		public IWebElement Unpd { get; set; }

		[FindsBy(How = How.LinkText, Using = "Upload")]
		public IWebElement Upload { get; set; }

		[FindsBy(How = How.LinkText, Using = "Del")]
		public IWebElement Delete { get; set; }

		[FindsBy(How = How.LinkText, Using = "Attach")]
		public IWebElement Attach { get; set; }

		[FindsBy(How = How.LinkText, Using = "Move")]
		public IWebElement Move { get; set; }

		[FindsBy(How = How.LinkText, Using = "Next")]
		public IWebElement Next { get; set; }

		[FindsBy(How = How.LinkText, Using = "Skip")]
		public IWebElement Skip { get; set; }

		#endregion

	}
}
