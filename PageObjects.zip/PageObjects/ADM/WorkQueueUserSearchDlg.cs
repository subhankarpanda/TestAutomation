using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class WorkQueueUserSearchDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnFind")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelRegion")]
		public IWebElement FAFSelRegion { get; set; }

		[FindsBy(How = How.Id, Using = "FAFSelOffice")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "btnRefresh")]
		public IWebElement Refresh { get; set; }

		[FindsBy(How = How.Id, Using = "WQUUsersGrid_0_fafUSelected")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "WQUUsersGrid_WQUUsersGrid")]
		public IWebElement UnassignedUsers { get; set; }

		[FindsBy(How = How.Id, Using = "WQUsersGrid_WQUsersGrid")]
		public IWebElement AssignedUsersTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Select?")]
		public IWebElement SelectCol { get; set; }

		[FindsBy(How = How.LinkText, Using = "Skip Allowed?")]
		public IWebElement SkipAllowed { get; set; }

		[FindsBy(How = How.LinkText, Using = "Work Queue Supervisor?")]
		public IWebElement WorkQueueSupervisor { get; set; }

		[FindsBy(How = How.LinkText, Using = "User Name")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.LinkText, Using = "Region")]
		public IWebElement UserRegion { get; set; }

		[FindsBy(How = How.LinkText, Using = "Office")]
		public IWebElement UserHomeOffice { get; set; }

		[FindsBy(How = How.Id, Using = "WQUsersGrid_0_fafSelected")]
		public IWebElement SelectAssignedUser { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@name='WQUsersGrid_WQUsersGrid']/tbody/tr/td/table")]
        public IWebElement WQUserSearchTableHeader { get; set; }

        #endregion

        public WorkQueueUserSearchDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? AssignedUsersTable);
            return this;
        }
    }
}
