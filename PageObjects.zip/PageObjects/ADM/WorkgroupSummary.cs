using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.ADM
{
	public class WorkgroupSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkActiveonly")]
		public IWebElement Activeonly { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "cmdView")]
		public IWebElement ViewChangeStatus { get; set; }

		[FindsBy(How = How.LinkText, Using = "-CPUC0001-WG1")]
		public IWebElement WorkGroupNameElement { get; set; }

		[FindsBy(How = How.Id, Using = "dgridWgSummary_361_txtWgName")]
		public IWebElement WorkGroupName { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement Errormessage { get; set; }

		[FindsBy(How = How.Id, Using = "dgridWgSummary_dgridWgSummary")]
		public IWebElement WorkgroupsTable { get; set; }

		#endregion

        #region Useful Methods
        public WorkgroupSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Add);
            return this;
        }
        #endregion
    }
}
