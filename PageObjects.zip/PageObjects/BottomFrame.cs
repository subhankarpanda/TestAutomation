﻿using System;
using System.Threading;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects
{
    public class BottomFrame : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement btnDelete { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement btnNew { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement btnCancel { get; set; }

        [FindsBy(How = How.Id, Using = "divAutoSave")]
        public IWebElement btnAutoSave { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement btnSave { get; set; }

        [FindsBy(How = How.Id, Using = "btnReset")]
        public IWebElement btnReset { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement btnDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement btnApply { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divStatusbar']/table")]
        public IWebElement StatusBar { get; set; }


        #endregion

        public Dictionary<string,string> GetCurrentInfo()
        {
            this.WebDriver.SwitchTo().DefaultContent();
            //this.WebDriver.SwitchTo().Frame("fraStatus");
            this.WaitCreation(StatusBar);

            Dictionary<string, string> currentInfo = new Dictionary<string, string>();
            var currInfo = this.StatusBar.FindElements(By.XPath(".//td"));
            try
            {
                currentInfo.Add("Date", currInfo[0].Text.Trim());
                currentInfo.Add("Server", currInfo[1].Text.Trim());
                currentInfo.Add("User", currInfo[2].Text.Trim());
                currentInfo.Add("Region", currInfo[3].Text.Trim());
                currentInfo.Add("Office", currInfo[4].Text.Trim());
            }
            catch { } 

            return currentInfo;
        }

        public BottomFrame Delete()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnDelete);
            btnDelete.FAClick();
            return this;
        }

        public BottomFrame New()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnNew);
            btnNew.FAClick();
            return this;
        }

        public BottomFrame Cancel()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnCancel);
            btnCancel.FAClick();
            return this;
        }

        public BottomFrame AutoSave()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnAutoSave);
            btnAutoSave.FAClick();
            btnAutoSave.FireEvent("onclick");
            return this;
        }

        public BottomFrame Reset()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnReset);
            btnReset.FAClick();
            return this;
        }

        public BottomFrame Done()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnDone);
            btnDone.FAClick();
            return this;
        }

        public BottomFrame Apply()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnApply);
            btnApply.FAClick();
            return this;
        }

        public BottomFrame Save()
        {
            this.SwitchToBottomFrame();
            this.WaitCreation(btnSave);
            btnSave.FAClick();
            return this;
        }
    }

    public class DialogBottomFrame : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement btnSave { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement btnCancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement btnDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnYes")]
        public IWebElement btnYes { get; set; }

        [FindsBy(How = How.Id, Using = "btnNo")]
        public IWebElement btnNo { get; set; }
        
        #endregion

        public DialogBottomFrame ClickCancel()
        {
            this.SwitchToDialogBottomFrame();
            this.WaitCreation(btnCancel);
            btnCancel.FAClick();
            return this;
        }

        public DialogBottomFrame ClickDone()
        {
            this.SwitchToDialogBottomFrame();
            this.WaitCreation(btnDone);
            btnDone.FAClick();
            return this;
        }
        
        public DialogBottomFrame ClickSave()
        {
            this.SwitchToDialogBottomFrame();
            this.WaitCreation(btnSave);
            btnSave.FAClick();
            return this;
        }

        public DialogBottomFrame ClickYes()
        {
            this.SwitchToDialogBottomFrame();
            this.WaitCreation(btnYes);
            btnYes.FAClick();
            return this;
        }
        
        public DialogBottomFrame ClickNo()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(btnNo);
            btnNo.FAClick();
            return this;
        }
        
    }
}
