using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;


namespace FASTSelenium.PageObjects
{
    public class BottomLinks : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "Up")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.LinkText, Using = "Down")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.LinkText, Using = "AutoHide")]
        public IWebElement AutoHide { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divToolbar']")]
        public IWebElement SplitMFT { get; set; }

        [FindsBy(How = How.LinkText, Using = "Pop-Up WorkQ")]
        public IWebElement PopUpWorkQ { get; set; }

        [FindsBy(How = How.LinkText, Using = "AutoHide MFT")]
        public IWebElement AutoHideMFT { get; set; }

        [FindsBy(How = How.LinkText, Using = "Hide MFT")]
        public IWebElement HideMFT { get; set; }

        #endregion


        public void ClickOnBottomLinkElements()
        {
            System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> SplitMFT = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
            SplitMFT[2].FAClick();
        }

        public void ValidateSplitMFTButtonNonExistence()
        {
            System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements1 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
            int count = 0;
            foreach (IWebElement BL in BottomLinkElements1)
            {
                if (BL.Text.ToString().Trim() == "Split MFT")
                {
                    count = count + 1;
                    // Reports.StatusUpdate("Split MFT should not appear in Bottom Link", false);
                }
            }
            if (count > 0)
            {
                Reports.StatusUpdate("Split MFT should not appear in Bottom Link.", false);
            }
            else
            {
                Reports.StatusUpdate("Split MFT does not appear in Bottom Link as expected.", true);
            }
        }

        public void ValidateSplitMFTButtonExistence()
        {
            System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> BottomLinkElements1 = FastDriver.BottomLinks.SplitMFT.FindElements(By.TagName("SPAN"));
            int count = 0;
            foreach (IWebElement BL in BottomLinkElements1)
            {
                if (BL.Text.ToString().Trim() == "Split MFT")
                {
                    count = count + 1;
                    //Reports.StatusUpdate("Split MFT appears in Bottom Link", true);
                }
            }
            if (count > 0)
            {
                Reports.StatusUpdate("Split MFT appears in Bottom Link as expected.", true);
            }
            else
            {
                Reports.StatusUpdate("Split MFT does not appear in Bottom Link as expected.", false);
            }
        }
    }
}
