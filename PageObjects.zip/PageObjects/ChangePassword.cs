using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
	public class ChangePassword : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtUserName")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.Id, Using = "txtOldPassword")]
		public IWebElement OldPassword { get; set; }

		[FindsBy(How = How.Id, Using = "txtNewPassword")]
		public IWebElement NewPassword { get; set; }

		[FindsBy(How = How.Id, Using = "txtNewPasswordV")]
		public IWebElement CNewPassword { get; set; }

		[FindsBy(How = How.Id, Using = "btnChangePassword")]
		public IWebElement btnChangePassword { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "lblErrorMessage")]
		public IWebElement Errormsg { get; set; }

		#endregion

	}
}
