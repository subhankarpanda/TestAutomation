﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects
{
    public class Delivery : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliverGUI")]
        public IWebElement DeliverGUI { get; set; }

        #endregion

        #region Methods
        public Delivery Perform(FADeliveryMethod method)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Method);
            Method.FASelectItemBySendingKeys(GetDeliveryMethod(method));
            Playback.Wait(500);
            if (Deliver.IsVisible())
            {
                Deliver.FAClick();
            }
            else
            {
                DeliverGUI.FAClick();
            }

            return this;
        }

        private string GetDeliveryMethod(FADeliveryMethod method)
        {
            string methodStr = "";
            switch(method)
            {
                case FADeliveryMethod.Print:
                    methodStr = "print";
                    break;
                case FADeliveryMethod.Fax:
                    methodStr = "fax";
                    break;
                case FADeliveryMethod.Email:
                    methodStr = "email";
                    break;
                case FADeliveryMethod.Preview:
                    methodStr = "preview";
                    break;
                case FADeliveryMethod.ImageDoc:
                    methodStr = "imagedoc";
                    break;
                case FADeliveryMethod.AgentFirst:
                    methodStr = "agentfirst";
                    break;
                case FADeliveryMethod.PDC:
                    methodStr = "pdc";
                    break;
                case FADeliveryMethod.RTM:
                    methodStr = "real";
                    break;
                case FADeliveryMethod.LADOTCOM:
                    methodStr = "la.com";
                    break;
                case FADeliveryMethod.LVIS:
                    methodStr = "lvis";
                    break;
                case FADeliveryMethod.WINTRACK:
                    methodStr = "wintrack";
                    break;
                case FADeliveryMethod.FASTWeb:
                    methodStr = "fastweb";
                    break;
                default:
                    throw new ArgumentException(string.Format("Delivery method '{0}' does not exist.", method.ToString()));
            }
            return methodStr;
        }

        public string GetDeliveryWindowTitle(FADeliveryMethod method)
        {
            string windowTitle = "";
            switch (method)
            {
                case FADeliveryMethod.Print:
                    windowTitle = "Print Delivery";
                    break;
                case FADeliveryMethod.Fax:
                    windowTitle = "Fax Delivery";
                    break;
                case FADeliveryMethod.Email:
                    windowTitle = "Email Delivery";
                    break;
                case FADeliveryMethod.Preview:
                    windowTitle = "Print Preview";
                    break;
                case FADeliveryMethod.ImageDoc:
                    windowTitle = "Imagedoc Delivery";
                    break;
                case FADeliveryMethod.AgentFirst:
                    windowTitle = "AgentFirst Delivery";
                    break;
                case FADeliveryMethod.PDC:
                    windowTitle = "PDC Delivery";
                    break;
                case FADeliveryMethod.RTM:
                    windowTitle = "Real Time Mail Delivery";
                    break;
                case FADeliveryMethod.LADOTCOM:
                    windowTitle = "LA.COM Delivery";
                    break;
                case FADeliveryMethod.LVIS:
                    windowTitle = "LVIS Delivery";
                    break;
                case FADeliveryMethod.WINTRACK:
                    windowTitle = "Wintrack Delivery";
                    break;
                case FADeliveryMethod.FASTWeb:
                    windowTitle = "FastWeb Delivery";
                    break;
                default:
                    throw new ArgumentException(string.Format("Delivery method '{0}' does not exist.", method.ToString()));
            }
            return windowTitle;
        }
        #endregion
    }
}
