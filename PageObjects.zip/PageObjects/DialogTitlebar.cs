﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects
{
    public class DialogTitleBar : PageObject
    {
        #region Titlebar Buttons
        
        public IWebElement Close
        {
            get
            {
                 return WebDriver.FindElements(By.XPath("//button[contains(@class, 'ui-dialog-titlebar-close')]")).GetAllVisible().First();
            }
        }

        
        public IWebElement Minimize
        {
            get { return WebDriver.FindElements(By.XPath("//a[contains(@class, 'ui-dialog-titlebar-minimize')]")).GetAllVisible().First(); }
        }

        public IWebElement Maximize
        {
            get { return WebDriver.FindElements(By.XPath("//a[contains(@class, 'ui-dialog-titlebar-maximize')]")).GetAllVisible().First(); }
        }

        
        public IWebElement Collapse
        {
            get { return WebDriver.FindElements(By.XPath("//a[contains(@class, 'ui-dialog-titlebar-collapse')]")).GetAllVisible().First(); }
        }

        
        public IWebElement Restore
        {
            get { return WebDriver.FindElements(By.XPath("//a[contains(@class, 'ui-dialog-titlebar-restore')]")).GetAllVisible().First(); }
        }

        #endregion

        #region Methods
        public DialogTitleBar WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? Close);
            return this;
        }
        #endregion
    }
}
