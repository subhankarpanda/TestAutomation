﻿using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.Common;

namespace FASTSelenium.PageObjects
{
    public class FastErrorMessageList : PageObject
    {
        #region WebElement
        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }
        #endregion

        #region Useful Method
        public string GetErrorMsgText()
        {
            return ErrorMessage.FAGetText().Clean();
        }
        #endregion
    }
}
