﻿using OpenQA.Selenium;
using FASTSelenium.Common;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects
{
    public class HomePage : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "imgSplash")]
        public IWebElement SplashImage { get; set; }

        [FindsBy(How = How.LinkText, Using = "FAST Online Help")]
        public IWebElement OnlineHelp { get; set; }

        [FindsBy(How = How.LinkText, Using = "What's New")]
        public IWebElement WhatsNew { get; set; }

        [FindsBy(How = How.Id, Using = "idVersion")]
        public IWebElement VersionNumber { get; set; }

        #endregion

        public HomePage WaitForHomeScreen(bool reportBuildNumber = false)
        {
            Playback.Wait(1000); //Sometimes, it's not able to locate the splashImage without this wait time.
            this.SwitchToContentFrame();
            try
            {
                this.WaitCreation(SplashImage, continueOnFailure: true);
                if (reportBuildNumber)
                    Reports.StatusUpdate("FAST Build #" + VersionNumber.FAGetText().Clean(), true);
            }
            catch (WebDriverException)
            {
                this.SwitchToContentFrame();
                Reports.StatusUpdate("Wait for Splash Image, second try.", true);
                this.WaitCreation(SplashImage, continueOnFailure: true);
                if (reportBuildNumber)
                    Reports.StatusUpdate("FAST Build #" + VersionNumber.FAGetText().Clean(), true);
            }
            catch (Exception)
            {
                //Continue
            }
            return this;
        }
    }
}
