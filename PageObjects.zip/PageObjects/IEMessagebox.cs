using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
	public class IEMessage : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Name, Using = "OK")]
		public IWebElement OK { get; set; }

		[FindsBy(How = How.Name, Using = "Cancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Name, Using = "Reserved File Number ")]
		public IWebElement ReservedFileNumber33338 { get; set; }

		[FindsBy(How = How.Name, Using = "Yes")]
		public IWebElement Yes { get; set; }

		[FindsBy(How = How.Name, Using = "No")]
		public IWebElement No { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement StaticText { get; set; }

		#endregion

	}
	public class IEMessageDocument : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "spnMessage")]
		public IWebElement MessageText { get; set; }

		[FindsBy(How = How.Id, Using = "btnYes")]
		public IWebElement Yes { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement No { get; set; }

		#endregion

	}
}
