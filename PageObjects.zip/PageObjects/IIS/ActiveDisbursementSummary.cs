using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class ActiveDisbursementSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0")]
        public IWebElement Disbursement { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_dgDisbSmry")]
        public IWebElement Disbursements { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblAmt")]
        public IWebElement DisbursementsAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_1_lblAmt")]
        public IWebElement DisbursementsAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblShortPayeeName")]
        public IWebElement Disbursementspayeename { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_1_lblShortPayeeName")]
        public IWebElement Disbursementspayeename1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnTrack")]
        public IWebElement Track { get; set; }

        [FindsBy(How = How.Id, Using = "btnTrialBalanceNote")]
        public IWebElement Note { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrint")]
        public IWebElement Print { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrintAll")]
        public IWebElement PrintAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnManual")]
        public IWebElement Manual { get; set; }

        [FindsBy(How = How.Id, Using = "btnWire")]
        public IWebElement Wire { get; set; }

        [FindsBy(How = How.Id, Using = "btnWireAll")]
        public IWebElement WireAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnDisburseAll")]
        public IWebElement DisburseAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnSplit")]
        public IWebElement Split { get; set; }

        [FindsBy(How = How.Id, Using = "btnVoid")]
        public IWebElement Void { get; set; }

        [FindsBy(How = How.Id, Using = "btnFeeTrns")]
        public IWebElement FeeTransfer { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblAmt")]
        public IWebElement FeeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_1_lblAmt")]
        public IWebElement CheckAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_2_lblAmt")]
        public IWebElement CheckAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetDisbAmnt")]
        public IWebElement NetDisbursementAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_3_lblAmt")]
        public IWebElement WireAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_1_lblAmt")]
        public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblAmt")]
        public IWebElement ThirdrdpartyBrokerCheckamt1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblAmt")]
        public IWebElement ThirdrdpartyBrokerCheckamt2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblAmt")]
        public IWebElement ThirdrdpartyBrokerCheckamt3 { get; set; }

        [FindsBy(How = How.Id, Using = "chkSFTrans")]
        public IWebElement TransferAllServiceFees { get; set; }

        [FindsBy(How = How.Id, Using = "grdServiceFee")]
        public IWebElement ServiceFeeTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbAvalbe")]
        public IWebElement TotalFundsAvailable { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbExcsShort")]
        public IWebElement ExcessFunds { get; set; }

        [FindsBy(How = How.Id, Using = "lblPendgAmnt")]
        public IWebElement PendingFunds { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeldAmnt")]
        public IWebElement HeldFunds { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_0_lblDoc")]
        public IWebElement FeeTransferDocumentCode { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#pnlDisbSum table:first-child table.cFrame td.cFrameBody table")]
        public IWebElement ActiveDisbSummaryTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#pnlDisbSum table:first-child table.cFrame td.cFrameBody table tr:last-child table")]
        public IWebElement ActiveDisbSumQuantityTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_1_Img1")]
        public IWebElement ApprovalStatus { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Issued']")]
        public IWebElement Issued { get; set; }

        #endregion

        public ActiveDisbursementSummary Open(IWebElement elementToWaitFor = null)
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>("Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
            this.WaitForScreenToLoad(elementToWaitFor);

            return this;
        }

        public ActiveDisbursementSummary WaitForScreenToLoad(IWebElement elememt = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(elememt ?? Disbursements);

            return this;
        }

        public string DisburseCheckActiveDisbursementSummary(string PayeeName, bool VerifyNoteButton = true)
        {
            Reports.TestStep = "Navigate to Active Disbursement screen and verify.";

            FastDriver.LeftNavigation.Navigate<ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary").WaitForScreenToLoad();
            Support.AreEqual("Check", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#1", "Pending", "#3", TableAction.GetText).Message);
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("#1", "Pending", "#3", TableAction.Click);

            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Replace("\n", "").Replace(" ", "").Trim().Contains("9,000.00" + PayeeName.Replace("\n", "").Replace(" ", "").Trim()).ToString());

            if (VerifyNoteButton)
            {
                Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Note.Enabled.ToString());
            }

            Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Edit.Enabled.ToString());
            Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Print.Enabled.ToString());
            Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Manual.Enabled.ToString());
            Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Split.Enabled.ToString());

            Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.PrintAll.Enabled.ToString());
            Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.Wire.Enabled.ToString());
            Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.WireAll.Enabled.ToString());
            Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.DisburseAll.Enabled.ToString());
            Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.Void.Enabled.ToString());
            Support.AreEqual(false.ToString(), FastDriver.ActiveDisbursementSummary.FeeTransfer.Enabled.ToString());

            FastDriver.ActiveDisbursementSummary.Print.FAClick();

            //----------------
            Reports.TestStep = "Click on Deliver.";
            FastDriver.PrintChecks.SwitchToContentFrame();
            FastDriver.PrintChecks.Deliver.FAClick();


            if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
            {
                Support.Fail("Printer is not configured");
            }
            Reports.TestStep = "Print the checks.";

            FastDriver.PrintDlg.WaitForScreenToLoad();
            FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();

            WebDriver.SwitchToWindow(Support.FASTWindowName);

            FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
            FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
            FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);

            FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

            FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

            Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
            FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();

            FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);


            Reports.TestStep = "Click on Done in ADS screen.";
            FastDriver.PrintChecks.SwitchToContentFrame();
            FastDriver.BottomFrame.Done();

            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
            return FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 5, TableAction.GetText).Message;
        }
                
        public string DisburseCheck(string Amount,string PayeeName="")
        {
            
            //
            FastDriver.ActiveDisbursementSummary.Open();
            Reports.TestStep = "Disburse check";
            if (string.IsNullOrEmpty(PayeeName))
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", Amount, "Status", TableAction.Click);
            else
            {
                if (PayeeName.Length > 40)
                    PayeeName = PayeeName.Substring(40);
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", Amount, "Payee", TableAction.Click, PayeeName);
            }
            //
            FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();       
            FastDriver.ActiveDisbursementSummary.Print.FAClick();
            //
            Reports.TestStep = "Click on Deliver.";
            FastDriver.PrintChecks.SwitchToContentFrame();
            FastDriver.PrintChecks.Deliver.FAClick();
            //
            if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
            {
                Support.Fail("Printer is not configured");
            }
            Reports.TestStep = "Print the checks.";
            FastDriver.PrintDlg.WaitForScreenToLoad();
            FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            WebDriver.SwitchToWindow(Support.FASTWindowName);
            //
            Reports.TestStep = "Handle Password or Overdraft Confirmation Dialog.";

            if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
            {
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            else
            { // Password Confirmation
                FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
            }
            Thread.Sleep(1000);
            //
            HandleHangingDelivery("Print", 200);
            //
            Reports.TestStep = "Click on Done in ADS screen.";
            FastDriver.PrintChecks.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
            //
            FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
            return FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 5, TableAction.GetText).Message;
        }
        
        public string IssueManualCheck(string Amount, string PayeeName = "")
        {
            
            try
            {
                FastDriver.ActiveDisbursementSummary.Open();
                Reports.TestStep = "Issue manual check";
                if (string.IsNullOrEmpty(PayeeName))
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", Amount, "Status", TableAction.Click, "Pending");
                else
                    FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", Amount, "Payee", TableAction.Click, PayeeName);


                FastDriver.ActiveDisbursementSummary.SwitchToContentFrame();
                //  Support.AreEqual(true.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.Text.Replace("\n", "").Replace(" ", "").Trim().Contains("9,000.00" + PayeeName.Replace("\n", "").Replace(" ", "").Trim()).ToString());

                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.IssueManualCheck.CheckNo.FASetText(Support.RandomString("NNNNNNNN"));

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Handle Password or Overdraft Confirmation Dialog.";

                if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent())
                {
                    FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                }
                else
                { // Password Confirmation
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword(AutoConfig.CheckPrintingPassword);
                    Thread.Sleep(7000);
                }

                Reports.TestStep = "Enter Manual Reason and Click on OK.";
                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText(@"Manual Reason for Check.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                return FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 1, TableAction.GetText).Message;
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Unable to issue manual check " + ex.Message, false);
                return "Fail";
            }
        }

        public bool isAlertPresent()
        {

            try
            {
                WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }
               
        private bool HandleHangingDelivery(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }
        
        public void VoidDisbursement(string Amount, string PayeeName="")
        {
                FastDriver.ActiveDisbursementSummary.Open();
                if (string.IsNullOrEmpty(PayeeName))
                    Disbursements.PerformTableAction("Amount", Amount, "Status", TableAction.Click);
                else
                    Disbursements.PerformTableAction("Amount", Amount, "Payee", TableAction.Click, PayeeName);
                Void.FAClick();
                FastDriver.VoidDlg.WaitForScreenToLoad();
                FastDriver.VoidDlg.VoidReason.FASetText("Void Disbursement");
                FastDriver.VoidDlg.ClickOk();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false, 10);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();


        }

        public bool CheckIfDisbursementExists(string Amount, string PayeeName="")
        {
            try
            {

                string result = "Fail";
                FastDriver.ActiveDisbursementSummary.Open();
                if (string.IsNullOrEmpty(PayeeName))
                    result = Disbursements.PerformTableAction("Amount", Amount, "Status", TableAction.Click).Status.ToString();
                else
                {
                    if (PayeeName.Length > 40)
                        PayeeName = PayeeName.Substring(40);
                    result = Disbursements.PerformTableAction("Amount", Amount, "Payee", TableAction.Click, PayeeName).Status.ToString();
                }
                if (result.Equals("Success"))
                    return true;
                else
                    return false;
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Exception " + ex.Message, false);
                return false;
            }
        }
        
        public bool CheckOutOfBalanceIndicator(string Amount)
        {
            try
            {
                IWebElement cell = null;
                FastDriver.ActiveDisbursementSummary.Open();
                cell = Disbursements.PerformTableAction("Amount", Amount, "Amount", TableAction.GetCell).Element;
                string Color = cell.FindElement(By.XPath("//span[text()='" + Amount + "']")).FAGetAttribute("style");
                return Color.Contains(@"color: rgb(255, 20, 147)");
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception " + ex.Message, false);
                return false;
            }
        }
    }

}
