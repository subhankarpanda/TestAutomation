using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;

namespace FASTSelenium.PageObjects.IIS
{
    public class AdHocDocuments : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_srchRslts_TC_tpSrch")]
        public IWebElement SearchResultsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_srchRslts_TC_Info")]
        public IWebElement InfoTab { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_Info_UcInf_txtEffDat")]
        public IWebElement InfoEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_Info_UcInf_txtExcp")]
        public IWebElement InfoExceptionsField { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_Info_UcInf_txtReq")]
        public IWebElement InfoRequirementsField { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cboSource")]
        public IWebElement Source { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cboTempType")]
        public IWebElement TemplateType { get; set; }

        [FindsBy(How = How.Id, Using = "srch_txtDesc")]
        public IWebElement TemplateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cboCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "srch_cboCity")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_tpSrch_btnCrtEdt")]
        public IWebElement CreateEdit { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_tpSrch_btnSave")]
        public IWebElement CreateSave { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_tpSrch_grdSrchResults_grdSrchResults")]
        public IWebElement SearchResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "srchRslts_TC_tpSrch_grdSrchResults_0")]
        public IWebElement SearchResults1stRow { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SearchResultsName { get; set; }

        #endregion

        public AdHocDocuments SearchDocument(string source = null, string templateType = null, string templateDescription = null, string state = null)
        {
            WaitForScreenToLoad(Source);
            Source.FASelectItem(source);
            TemplateType.FASelectItem(templateType);
            TemplateDescription.FASetText(templateDescription);
            State.FASelectItem(state);
            FindNow.FAClick();

            this.WaitCreation(SearchResultsTable);

            return this;
        }

        public AdHocDocuments WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Source);
            return this;
        }

        public AdHocDocuments WaitForResultsToLoad()
        {
            this.WaitCreation(SearchResults1stRow);
            return this;
        }

        public void AddDocument(string source, string templatetype, string templatedescription, string state)
        {
            Reports.TestStep = "Add a " + templatetype + " document.";
            WaitForScreenToLoad();
            Source.FASelectItem(source);
            TemplateType.FASelectItemBySendingKeys(templatetype);
            TemplateDescription.FASetText(templatedescription);
            State.FASelectItem(state);
            FindNow.FAClick();
            this.WaitCreation(SearchResultsTable);
            SearchResultsTable.PerformTableAction("Description", templatedescription, "Description", TableAction.Click);
            CreateSave.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            Playback.Wait(5000);
        }

        public void CreateandEditDocument(string source, string templatetype, string templatedescription, string state)
        {
            Reports.TestStep = "Add a " + templatetype + " document.";
            WaitForScreenToLoad();
            Source.FASelectItem(source);
            TemplateType.FASelectItemBySendingKeys(templatetype);
            TemplateDescription.FASetText(templatedescription);
            State.FASelectItem(state);
            FindNow.FAClick();
            this.WaitCreation(SearchResultsTable);
            SearchResultsTable.PerformTableAction("Description", templatedescription, "Description", TableAction.Click);
            CreateEdit.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            Playback.Wait(5000);
        }

        public AdHocDocuments CreateSaveDoc(string source, string templatetype, string templatedescription, string state)
        {
            WaitForScreenToLoad().SearchDocument(source, templatetype, templatedescription, state).WaitForResultsToLoad();
            SearchResultsTable.PerformTableAction(2, templatedescription, 2, TableAction.Click);
            CreateSave.FAClick();
            Playback.Wait(5000);
            return this;
        }

        public AdHocDocuments SelectMutipleDocuments(string templateName)
        {

            this.SwitchToContentFrame();
            List<IWebElement> docments = FastDriver.AdHocDocuments.SearchResultsTable.FindElements(By.TagName("tr")).ToList();
            for (int i = 1; i <= docments.Count - 1; i++)
            {
                if (docments[i].FindElements(By.TagName("td"))[1].Text.ToString() == templateName)
                {
                    Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

                    docments[i].FAClick();
                    docments[i + 1].FAClick();
                    Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

                    break;
                }
            }

            return this;
        }
    }
}
