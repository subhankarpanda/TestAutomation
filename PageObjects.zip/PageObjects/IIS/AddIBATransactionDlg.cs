using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AddIBATransactionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "optTransaction_2")]
		public IWebElement CloseIBA { get; set; }

		[FindsBy(How = How.Id, Using = "optTransaction_0")]
		public IWebElement AdditionalDeposit { get; set; }

		[FindsBy(How = How.Id, Using = "optTransaction_1")]
		public IWebElement PartialWithdrawal { get; set; }

		#endregion

        public AddIBATransactionDlg WaitForScreenToLoad(string windowName = "Add IBA Transaction")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(CloseIBA, 20);

            return this;
        }
	}
}
