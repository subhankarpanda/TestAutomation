using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AddOTCFees : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridOTCSummary_0_chkSel")]
		public IWebElement CheckBoxSelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgridOTCSummary")]
		public IWebElement FeeTable { get; set; }

		#endregion

        public AddOTCFees WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(FeeTable);

            return this;
        }
	}
}
