using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AddRTMPackageAddressesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtAddress1")]
		public IWebElement Address1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtAddress2")]
		public IWebElement Address2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "dgAddRTMaddressees_0_txtPhone")]
		public IWebElement Phone { get; set; }

		#endregion

        public AddRTMPackageAddressesDlg WaitForScreenToLoad()
        {

            try
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            }
            catch (Exception)
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_1_iframe");
            }

            try
            {
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }
            catch { }

            this.WaitCreation(New ?? Remove);
            return this;
        }

        public void ADDRTMPackageAddress()
        {
            FastDriver.AddRTMPackageAddressesDlg.WaitForScreenToLoad();
            FastDriver.AddRTMPackageAddressesDlg.New.FAClick();
            FastDriver.AddRTMPackageAddressesDlg.WaitForScreenToLoad();
            FastDriver.AddRTMPackageAddressesDlg.Name.FASetText("DPUC009");
            FastDriver.AddRTMPackageAddressesDlg.Address1.FASetText("Bat27");
            FastDriver.AddRTMPackageAddressesDlg.Address2.FASetText("DPUC009Bat27");
            FastDriver.AddRTMPackageAddressesDlg.City.FASetText("ALAMEDA");
            FastDriver.AddRTMPackageAddressesDlg.Zip.FASetText("97020");
            FastDriver.AddRTMPackageAddressesDlg.State.FASelectItem("CA");
            FastDriver.DialogBottomFrame.ClickDone();
        }
	}
}
