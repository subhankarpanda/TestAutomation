using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class AddSimultaneousProduct : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlTitleProduct")]
        public IWebElement TitleProduct { get; set; }

        [FindsBy(How = How.Id, Using = "ddlRateTypes")]
        public IWebElement RateType { get; set; }

        [FindsBy(How = How.XPath, Using = "//td/b[contains(text(),'Rate Type:')]")]
        public IWebElement RateTypeLabel { get; set; }

        #endregion

        public AddSimultaneousProduct WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(TitleProduct);
            return this;
        }
        
    }
}
