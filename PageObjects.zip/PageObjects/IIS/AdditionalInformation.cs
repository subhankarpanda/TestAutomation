using System;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Diagnostics;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class BuyerSellerAdditionalInformation : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboLanguagePreferenceId")]
        public IWebElement LanguagePreference { get; set; }

        [FindsBy(How = How.Id, Using = "txtLangPrefOther")]
        public IWebElement LanguagePrefOther { get; set; }

        
        #endregion

        public BuyerSellerAdditionalInformation WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? LanguagePreference);
            return this;
        }

   }

}
