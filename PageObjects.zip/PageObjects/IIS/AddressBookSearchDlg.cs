using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class AddressBookSearchDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "comboOfficeStatus")]
        public IWebElement Display { get; set; }

        [FindsBy(How = How.Id, Using = "txtEnterPriceNum")]
        public IWebElement EnterpriseNo { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewGABEntry")]
        public IWebElement NewGAB { get; set; }

        [FindsBy(How = How.Id, Using = "cmdModifyGABEntry")]
        public IWebElement ModifyGAB { get; set; }

        [FindsBy(How = How.Id, Using = "cmdClearSearchFlds")]
        public IWebElement Clear { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFind")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "cmdViewContact")]
        public IWebElement ViewContact { get; set; }

        [FindsBy(How = How.Id, Using = "comboTypetable")]
        public IWebElement EntityType { get; set; }

        [FindsBy(How = How.Id, Using = "textEntityName")]
        public IWebElement EntityName { get; set; }

        [FindsBy(How = How.Id, Using = "textEntityID")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "textCiy")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "textCounty")]
        public IWebElement County { get; set; }

        [FindsBy(How = How.Id, Using = "comboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "textContfirstName")]
        public IWebElement ContactFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "textLastName")]
        public IWebElement LastName { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressType_0")]
        public IWebElement UseMailingAddress { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressType_1")]
        public IWebElement UseBusinessAddress { get; set; }

        [FindsBy(How = How.Id, Using = "cmdGABDetails")]
        public IWebElement GABDetails { get; set; }

        [FindsBy(How = How.Id, Using = "dgGAB_0_oGAB")]
        public IWebElement SearchResultsRadio { get; set; }

        [FindsBy(How = How.Id, Using = "dgGAB")]
        public IWebElement SearchResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dGridContactDetails")]
        public IWebElement BusOrgContactsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgGAB_dgGAB")]
        public IWebElement SearchResultsTableHeader { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_1")]
        public IWebElement FileaddressBookRadio { get; set; }

        [FindsBy(How = How.Id, Using = "Table2")]
        public IWebElement FileaddressBookTable { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults_0_optFABSelect")]
        public IWebElement FileaddressBookResultsRadio { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_0")]
        public IWebElement GlobalAddressBookRadio { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults")]
        public IWebElement FileAddressBookSearchResultTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "eEnabled (Blue)")]
        public IWebElement eEnabled { get; set; }

        [FindsBy(How = How.Id, Using = "rblOfficeAddressBook_0")]
        public IWebElement rbOfficeinPayeesearch { get; set; }

        [FindsBy(How = How.Id, Using = "rblOfficeAddressBook_1")]
        public IWebElement rbFileProductionOfficesinPS { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices")]
        public IWebElement TableinpayeeSearch { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_1")]
        public IWebElement FileAddBook { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults_5_chkFABSelect")]
        public IWebElement FABSelect { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_1")]
        public IWebElement FileaddressBookRadio_1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults_0_chkFABSelect")]
        public IWebElement FileAddressSelect { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_0_chkSelect")]
        public IWebElement PayeeSearchSelect { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults_0_optFABSelect")]
        public IWebElement FileaddressBookResultsRadio1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgGAB_0_lID")]
        public IWebElement SearchresultIDcode { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_0")]
        public IWebElement GABCell { get; set; }

        [FindsBy(How = How.LinkText, Using = "File Address Book")]
        public IWebElement FABCell { get; set; }

        [FindsBy(How = How.LinkText, Using = "Office")]
        public IWebElement OfficeCell { get; set; }

        [FindsBy(How = How.LinkText, Using = "File Production Offices")]
        public IWebElement FPOCell { get; set; }

        [FindsBy(How = How.Id, Using = "comboRegion")]
        public IWebElement Region { get; set; }

        [FindsBy(How = How.Id, Using = "labelRecordCount")]
        public IWebElement RecordCount { get; set; }

        [FindsBy(How = How.Id, Using = "labelFabResultCount")]
        public IWebElement TotalRecords { get; set; }

        #endregion

        public AddressBookSearchDlg WaitForScreenToLoad(string windowName = "Payee Search", IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Find);

            return this;
        }

        public AddressBookSearchDlg WaitForDialogToLoad(IWebElement Element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Element ?? Find);

            return this;
        }

        public AddressBookSearchDlg WaitForDialogToLoad_0(IWebElement Element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Element ?? Find);

            return this;
        }

        public AddressBookSearchDlg FindContact(string EntiType = null, string City = null, string EntityName = null, string IDCode = null, string County = null, string State = null, string Contact1stName = null, string LastName = null)
        {
            if (EntityType == null && City == null && EntityType == null && IDCode == null && County == null && State == null && Contact1stName == null && LastName == null)
            {
                throw new ArgumentNullException("Please provide a search criteria to search the Address Book");
            }

            WaitForScreenToLoad(element: EntityType);
            EntityType.FASelectItem(EntiType);
            this.City.FASetText(City);
            this.EntityName.FASetText(EntityName);
            this.IDCode.FASetText(IDCode);
            this.County.FASetText(County);
            this.State.FASelectItem(State);
            ContactFirstName.FASetText(Contact1stName);
            this.LastName.FASetText(LastName);
            Find.FAClick();
            return this;
        }

        public void FindAndSelectContact(string EntiType = null, string City = null, string EntityName = null, string IDCode = null, string County = null, string State = null, string Contact1stName = null, string LastName = null,bool ClickDone=true)
        {
            Reports.TestStep = "Set an exchange company id from Global address book";
            //this.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
            this.FindContact(EntiType, City, EntityName, IDCode, County, State, Contact1stName, LastName);
            this.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 20);
            //this.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.SearchResultsRadio.Click();
            if (ClickDone)
            {
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
        }

        public void SearchAndSelect(string idCode)
        {
            WaitForScreenToLoad(element: IDCode);
            FindContact(IDCode: idCode);
            WaitForResultsToLoad();
            SearchResultsTable.PerformTableAction(7, idCode, 1, TableAction.On);
        }

        public void Search(string entityType, string idCode = null, string EntityName = null, string City = null, string County = null, string State = null, string ContactFirstName = null, string LastName = null) {
            WaitForScreenToLoad(element: EntityType);
            this.EntityType.FASelectItem(entityType);
            this.EntityName.FASetText(EntityName);
            this.IDCode.FASetText(idCode);
            this.City.FASetText(City);
            this.County.FASetText(County);
            this.State.FASelectItem(State);
            this.ContactFirstName.FASetText(ContactFirstName);
            this.LastName.FASetText(LastName);
            Find.FAClick();
            WaitForResultsToLoad();
        }

        public AddressBookSearchDlg WaitForResultsToLoad()
        {
            FastDriver.WebDriver.HandleDialogMessage();
            this.WaitForScreenToLoad(element: Find);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.WaitForScreenToLoad(element: Find);
            return this;
        }

        public void ValidateName(string p1, string p2, string p3)
        {
            Reports.TestStep = "Validate whether the Adhoc GAB is Displayed in File Addr Book";
            WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Search", timeoutSeconds: 20);
            this.SwitchToDialogContentFrame();

            Support.AreEqual(p2 + " " + p3, FileAddressBookSearchResultTable.PerformTableAction("Role", p1, "Name", TableAction.GetText).Message);
        }
        public void NewGabRequest(string EntityType="Corporate",string City="Santa Ana",string State="CA",string Zip="92707" )
        {
            this.WaitForDialogToLoad();
            this.IDCode.FASetText(@"Test");
            this.Find.FAClick();
            Thread.Sleep(4000);
            Reports.TestStep = "Click on New GAB button.";
            this.NewGAB.FAClick();
            Reports.TestStep = "Open dlg and Creates a New GAB Request.";
            FastDriver.GABEntryRequestDlg.WaitForScreenToLoad();
            Thread.Sleep(3000);
            FastDriver.GABEntryRequestDlg.WaitCreation(FastDriver.GABEntryRequestDlg.EntityType,true);
            //if (string.IsNullOrEmpty(City) && string.IsNullOrEmpty(State) && string.IsNullOrEmpty(Zip))
            //    FastDriver.GABEntryRequestDlg.NewGabRequestWithDefaultData(EntityType);
            //else
                FastDriver.GABEntryRequestDlg.NewGabRequest(City:City,State: State,Zip: Zip,EntityType:EntityType);

        }

        public void ValidationOFeEnabled()
        {
            Support.AreEqual("eEnabled (Blue)", FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", "New Lender", "#2", TableAction.GetCell).Element.FindElement(By.TagName("IMG")).FAGetAttribute("title").ToString(), bIgnoreCase: true);

        }
    }
}
