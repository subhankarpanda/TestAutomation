using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;


namespace FASTSelenium.PageObjects.IIS
{
    public class AdjustmentMisc : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement miscellaneousAdjustmentTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement description { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tdsc")]
        public IWebElement description1 { get; set; }

        //[FindsBy(How = How.Id, Using = "CG_dcs_2_tdsc")]
        //public IWebElement micdescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbd")]
        public IWebElement BuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsr")]
        public IWebElement SellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tdsc")]
        public IWebElement description2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tbc")]
        public IWebElement BuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tbd")]
        public IWebElement BuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tsc")]
        public IWebElement SellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tsr")]
        public IWebElement SellerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tdsc")]
        public IWebElement description3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tbc")]
        public IWebElement BuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tbd")]
        public IWebElement BuyerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tsc")]
        public IWebElement SellerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tsr")]
        public IWebElement SellerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tdsc")]
        public IWebElement description4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tbc")]
        public IWebElement BuyerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tbd")]
        public IWebElement BuyerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tsc")]
        public IWebElement SellerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tsr")]
        public IWebElement SellerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tdsc")]
        public IWebElement description5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tbc")]
        public IWebElement BuyerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tbd")]
        public IWebElement BuyerCredit5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tsc")]
        public IWebElement SellerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tsr")]
        public IWebElement SellerCredit5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tdsc")]
        public IWebElement description6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tbc")]
        public IWebElement BuyerCharge6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tbd")]
        public IWebElement BuyerCredit6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tsc")]
        public IWebElement SellerCharge6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tsr")]
        public IWebElement SellerCredit6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tdsc")]
        public IWebElement description7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tbc")]
        public IWebElement BuyerCharge7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tbd")]
        public IWebElement BuyerCredit7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tsc")]
        public IWebElement SellerCharge7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tsr")]
        public IWebElement SellerCredit7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tdsc")]
        public IWebElement description8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tbc")]
        public IWebElement BuyerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tbd")]
        public IWebElement BuyerCredit8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tsc")]
        public IWebElement SellerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tsr")]
        public IWebElement SellerCredit8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tdsc")]
        public IWebElement description9 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tbc")]
        public IWebElement BuyerCharge9 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tbd")]
        public IWebElement BuyerCredit9 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tsc")]
        public IWebElement SellerCharge9 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tsr")]
        public IWebElement SellerCredit9 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_9_tdsc")]
        public IWebElement description10 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_9_tbc")]
        public IWebElement BuyerCharge10 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_9_tbd")]
        public IWebElement BuyerCredit10 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_9_tsc")]
        public IWebElement SellerCharge10 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_9_tsr")]
        public IWebElement SellerCredit10 { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerTotal")]
        public IWebElement BuyerTotal { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerTotal")]
        public IWebElement SellerTotal { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tsr")]
        public IWebElement SellerCredit1 { get; set; }

        #endregion

        public AdjustmentMisc Open()
        {
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Charge Processes>Adjustments>Miscellaneous");
            this.WaitForScreenToLoad();

            return this;
        }
        public AdjustmentMisc WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? miscellaneousAdjustmentTable);

            return this;
        }
        
        public AdjustmentMisc AddMiscCharges(string description, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(miscellaneousAdjustmentTable);

            if (description != string.Empty)
            {
                miscellaneousAdjustmentTable.PerformTableAction(miscellaneousAdjustmentTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, description).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (buyerCharge.HasValue)
            {
                miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);

            }
            if (buyerCredit.HasValue)
            {
                miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);

            }
            if (sellerCharge.HasValue)
            {
                miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);

            }
            if (sellerCredit.HasValue)
            {
                miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);

            }
            return this;
        }

        public AdjustmentMisc UpdateMiscCharges(string description, string updateDesc = null, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(miscellaneousAdjustmentTable, 10);

            IWebElement inputElement;
            if (updateDesc != null)
            {
                inputElement = miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Description", TableAction.SetText, updateDesc).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                description = updateDesc;
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbc") && input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }           
            if (buyerCredit.HasValue)
            {
                inputElement = miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbd") && input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }           
            if (sellerCharge.HasValue)
            {
                inputElement = miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsc") && input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = miscellaneousAdjustmentTable.PerformTableAction("Description", description, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsr") && input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }            
            return this;
        }

        public AdjustmentMisc AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            return this;
        }

        public AdjustmentMisc UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;

        }


        /* Originals add and update charges kept for references
        
         * public AdjustmentMisc addMiscChargesO(string description, double? BuyerCharge, double? BuyerCredit = null, double? SellerCharge = null, double? SellerCredit = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(miscellaneousAdjustmentTable, 10);
            string tableId = miscellaneousAdjustmentTable.GetAttribute("id");
            var rows = miscellaneousAdjustmentTable.FindElements(By.TagName("tr")).Where(tr => tr.GetAttribute("id").Contains(tableId));

            IWebElement row = miscellaneousAdjustmentTable.FindElement(By.Id(string.Format("{0}_{1}", tableId, rows.Count() - 1)));

            if (row == null)
                throw new NoSuchElementException(string.Format("Could not find an input field with description '{0}'", description));

            IWebElement inputElement;
            if (description != string.Empty)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tdsc") && input.Displayed);
                inputElement.FASetText(description);
                Keyboard.SendKeys(FAKeys.TabAway);
            }

            if (BuyerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbc") && input.Displayed);
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(BuyerCharge.ToString());
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (BuyerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbd") && input.Displayed);
                inputElement.FASetText(BuyerCredit.ToString());
            }
            if (SellerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsc") && input.Displayed);
                inputElement.FASetText(SellerCharge.ToString());
            }
            if (SellerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsr") && input.Displayed);
                inputElement.FASetText(SellerCredit.ToString());
            }
           return this;
        }
         * 
         * 
        public AdjustmentMisc updateMiscChargesO(string description, string updateDesc, double? buyerCharge, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(miscellaneousAdjustmentTable, 10);
            var rows = miscellaneousAdjustmentTable.FindElements(By.TagName("tr"));

            IWebElement row = null;
            foreach (var tempRow in rows)
            {
                IWebElement descriptionInput = tempRow.FindElements(By.TagName("input")).FirstOrDefault(i => i.GetAttribute("id").Contains("_tdsc") && i.Displayed);
                try
                {
                    if (descriptionInput.GetAttribute("value").Trim().Contains(description))
                    {
                        row = tempRow;
                        break;
                    }
                }
                catch (NullReferenceException)
                {
                    continue;
                }
            }

            if (row == null)
                throw new NoSuchElementException(string.Format("Could not find an input field with description '{0}'", description));

            IWebElement inputElement;
            if (updateDesc != "")
            {
                if (description.Contains(description))
                {
                    inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tdsc") && input.Displayed);
                    inputElement.FASetText(updateDesc.ToString());
                }
            }
            if (buyerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbc") && input.Displayed);
                inputElement.FASetText(buyerCharge.ToString());
            }
            if (buyerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbd") && input.Displayed);
                inputElement.FASetText(buyerCredit.ToString());
            }
            if (sellerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsc") && input.Displayed);
                inputElement.FASetText(sellerCharge.ToString());
            }
            if (sellerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsr") && input.Displayed);
                inputElement.FASetText(sellerCredit.ToString());
            }


            return this;
        }
         */

    }
}
