using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class AdjustmentOffset : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement offsetAdjustmentTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement description { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tdsc")]
        public IWebElement description1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tdsc")]
        public IWebElement description2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tdsc")]
        public IWebElement description3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tdsc")]
        public IWebElement description4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tdsc")]
        public IWebElement description5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tdsc")]
        public IWebElement description6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tdsc")]
        public IWebElement description7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tdsc")]
        public IWebElement description8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbd")]
        public IWebElement BuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tbd")]
        public IWebElement BuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tbd")]
        public IWebElement BuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tbd")]
        public IWebElement BuyerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tbd")]
        public IWebElement BuyerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_5_tbd")]
        public IWebElement BuyerCredit5 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_6_tbd")]
        public IWebElement BuyerCredit6 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_7_tbd")]
        public IWebElement BuyerCredit7 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_8_tbd")]
        public IWebElement BuyerCredit8 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_9_tbd")]
        public IWebElement BuyerCredit9 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tsc")]
        public IWebElement SellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tsc")]
        public IWebElement SellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tsc")]
        public IWebElement SellerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tsc")]
        public IWebElement SellerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsr")]
        public IWebElement SellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tsr")]
        public IWebElement SellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tsr")]
        public IWebElement SellerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_3_tsr")]
        public IWebElement SellerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tsr")]
        public IWebElement SellerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_4_tbc")]
        public IWebElement AppraisalFee_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_2_tbc")]
        public IWebElement AssignTenantSecurityDeposit_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tbc")]
        public IWebElement AssignTenantSecurityLeaseRent_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerTotal")]
        public IWebElement BuyerTotal { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerTotal")]
        public IWebElement SellerTotal { get; set; }

        #endregion

        public AdjustmentOffset Open()
        {
            FastDriver.LeftNavigation.Navigate<AdjustmentOffset>("Home>Order Entry>Escrow Charge Processes>Adjustments>Off-Set");
            this.WaitForScreenToLoad();

            return this;
        }
        public AdjustmentOffset WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? offsetAdjustmentTable);

            return this;
        }

        public AdjustmentOffset AddOffsetCharges(string description, double? BuyerCharge = null, double? BuyerCredit = null, double? SellerCharge = null, double? SellerCredit = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(offsetAdjustmentTable, 10);

            if (description != string.Empty)
            {
                offsetAdjustmentTable.PerformTableAction(offsetAdjustmentTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, description).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (BuyerCharge.HasValue)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Buyer Charge", TableAction.SetText, BuyerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (BuyerCredit.HasValue)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Buyer Credit", TableAction.SetText, BuyerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (SellerCharge.HasValue)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Seller Charge", TableAction.SetText, SellerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (SellerCredit.HasValue)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Seller Credit", TableAction.SetText, SellerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            return this;
        }



        public AdjustmentOffset UpdateOffsetCharges(string description, string updateDesc = null, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(offsetAdjustmentTable, 10);

            if (updateDesc != null)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Description", TableAction.SetText, updateDesc).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                description = updateDesc;
                Keyboard.SendKeys(FAKeys.TabAway);

            }
            if (buyerCharge.HasValue)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }

            if (buyerCredit.HasValue)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (sellerCharge.HasValue && updateDesc == null)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (sellerCredit.HasValue && updateDesc == null)
            {
                offsetAdjustmentTable.PerformTableAction("Description", description, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }

            return this;
        }

        public AdjustmentOffset AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            return this;
        }


        public AdjustmentOffset AddChargeRefinance(IWebElement chargesTable, string chargeDescription, double? BorrowerCharge = null, double? BorrowerCredit = null,double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Charge", TableAction.SetText, BorrowerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Credit", TableAction.SetText, BorrowerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            return this;
        }



        public AdjustmentOffset UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;

        }

        public void EnterSalePriceofAnyPersonalPropertyIncludedinSale()
        {
          Reports.TestStep = "Enter the Buyer change and seler credit in Offset screen.";
          FastDriver.AdjustmentOffset.Open();
          FastDriver.AdjustmentOffset.AddCharge(FastDriver.AdjustmentOffset.offsetAdjustmentTable, "Sale Price of Any Personal Property Included in Sale", 100.99, null, null, 100.99, null);
        }
    }
}
