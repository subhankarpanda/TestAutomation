using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AgentNetCredentialsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "AgentNet Credentials ")]
		public IWebElement AgentNetCredentialsLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "User Name: ")]
		public IWebElement UserNameLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Password: ")]
		public IWebElement PasswordLabel { get; set; }

		[FindsBy(How = How.Id, Using = "txtUserName")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.Id, Using = "txtUserPassword")]
		public IWebElement UserPassword { get; set; }

		[FindsBy(How = How.Id, Using = "btnSubmit")]
		public IWebElement Submit { get; set; }

        #endregion

        public AgentNetCredentialsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Submit);

            return this;
        }

        public bool IsAgentNetCredentialsDialogPresent()
        {
            try
            {
                WebDriver.SwitchTo().DefaultContent();
                //this.SwitchToDialogContentFrame();
                return WebDriver.PageSource.Contains("AgentNet Credentials");
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }
    }
}
