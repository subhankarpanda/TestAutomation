using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AssignChargestoHUD1LineNumbers : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//tr/td[contains(text(),'Additional Amounts Owed by the Borrower (104+)')]")]
		public IWebElement AdditionaleBorrower104 { get; set; }

		[FindsBy(How = How.LinkText, Using = "HUD Line #")]
		public IWebElement HUDLine104 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Description")]
		public IWebElement Description104 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Charge Process")]
		public IWebElement ChargeProcess104 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddAmtBorrw_0_txtHUDLn4")]
		public IWebElement ChargeProcess104textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddAmtBorrw_1_txtHUDLn4")]
		public IWebElement ChargeProcess105textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddAmtBorrw_0_lblDesc4")]
		public IWebElement ChargeProcess105Row1Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddAmtBorrw_0_lblChrgPr4")]
		public IWebElement ChargeProcess105Row1chargeprocess { get; set; }

		[FindsBy(How = How.LinkText, Using = "Items Payable in Connection with Loan 808")]
		public IWebElement ItemsPayabnwithLoan808 { get; set; }

		[FindsBy(How = How.LinkText, Using = "HUD Line #")]
		public IWebElement HUDLine808 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Description")]
		public IWebElement Description808 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Charge Process")]
		public IWebElement ChargeProcess808 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridConLon_0_txtHUDLn1")]
		public IWebElement ChargeProcess808textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridConLon_0_lblDesc1")]
		public IWebElement ChargeProcess808Row1Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgridConLon_0_lblChrgPr1")]
		public IWebElement ChargeProcess808Row1chargeprocess { get; set; }

		[FindsBy(How = How.LinkText, Using = "Items Required By Lender to be Paid in Advance 904 ")]
		public IWebElement ItemsRequiinAdvance904 { get; set; }

		[FindsBy(How = How.LinkText, Using = "HUD Line #")]
		public IWebElement HUDLine904 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Description")]
		public IWebElement Description904 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Charge Process")]
		public IWebElement ChargeProcess904 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_0_txtHUDLn2")]
		public IWebElement ChargeProcess904textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_1_txtHUDLn2")]
		public IWebElement Row2ChargeProcess904textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_2_txtHUDLn2")]
		public IWebElement Row3ChargeProcess904textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_3_txtHUDLn2")]
		public IWebElement Row4ChargeProcess904textbox { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_0_lblDesc2")]
		public IWebElement Row1Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_1_lblDesc2")]
		public IWebElement Row2Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_2_lblDesc2")]
		public IWebElement Row3Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_3_lblDesc2")]
		public IWebElement Row4Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPaidAdv_0_lblChrgPr2")]
		public IWebElement ChargeProcess904Row1chargeprocess { get; set; }

		[FindsBy(How = How.LinkText, Using = "Additional Settlement Charges 1303 ")]
		public IWebElement AdditionaltCharges1303 { get; set; }

		[FindsBy(How = How.LinkText, Using = "HUD Line #")]
		public IWebElement HUDLine1303 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Description")]
		public IWebElement Description1303 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Charge Process")]
		public IWebElement ChargeProcess1303 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAdvChrg_0_txtHUDLn3")]
		public IWebElement ChargeProcess1303textbox { get; set; }

		[FindsBy(How = How.Id, Using = "grp404td")]
		public IWebElement Expand404Section { get; set; }

		[FindsBy(How = How.Id, Using = "dgridAddAmtSell")]
		public IWebElement FourZeroFourSectionTable { get; set; }

		[FindsBy(How = How.Id, Using = "grp104td")]
		public IWebElement Expand104Section { get; set; }

        [FindsBy(How = How.Id, Using = "grp204td")]
        public IWebElement Expand204Section { get; set; }

        [FindsBy(How = How.Id, Using = "grp506td")]
        public IWebElement Expand506Section { get; set; }

        [FindsBy(How = How.Id, Using = "grp704td")]
        public IWebElement Expand704Section { get; set; }

		[FindsBy(How = How.Id, Using = "grp1303td")]
		public IWebElement Expand1303Section { get; set; }

        [FindsBy(How = How.Id, Using = "grp808td")]
        public IWebElement Expand808Section { get; set; }

        [FindsBy(How = How.Id, Using = "grp904td")]
        public IWebElement Expand904Section { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAddAmtBorrwer")]
        public IWebElement Section204PlusTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAddAmtBorrw")]
        public IWebElement Section104PlusTable { get; set; }


        #endregion

        public AssignChargestoHUD1LineNumbers Open()
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>Escrow Closing>Assign Charges to HUD-1 Line Numbers");
            this.WaitForScreenToLoad();

            return this;
        }

        public AssignChargestoHUD1LineNumbers WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AdditionaleBorrower104);
            return this;
        }
	}
}
