using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class AssignFeetoPropertyStates : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkSpltFeeBwProperties")]
        public IWebElement AssignState { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees")]
        public IWebElement AssignTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridFees_dgridFees")]
        public IWebElement FeeTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_2_textSplitPercentage")]
        public IWebElement SplitPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_1_lblSplitPercentage")]
        public IWebElement FirstSplitPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_2_lblSplitPercentage")]
        public IWebElement SecondSplitPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_3_lblSplitPercentage")]
        public IWebElement ThirdSplitPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_2_textSplitAmt")]
        public IWebElement SplitAmt { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProperties_0_radPropSelection")]
        public IWebElement State1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProperties_1_radPropSelection")]
        public IWebElement State2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProperties_2_radPropSelection")]
        public IWebElement State3 { get; set; }
		

        [FindsBy(How = How.Id, Using = "dGridProperties")]
        public IWebElement PropertyTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_3_textSplitPercentage")]
        public IWebElement SplitPercentage1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_1_labelStreetAddr")]
        public IWebElement FirstState { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_2_labelStreetAddr")]
        public IWebElement SecondState { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_3_labelStreetAddr")]
        public IWebElement ThirdState { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_1_lblSplitAmt")]
        public IWebElement FirstSplitAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_2_lblSplitAmt")]
        public IWebElement SecondSplitAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPropertyFees_3_lblSplitAmt")]
        public IWebElement ThirdSplitAmount { get; set; }
        #endregion

        public AssignFeetoPropertyStates WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AssignState);
            return this;
        }

        /// <summary>
        /// This function splits the fee amount between two states by percentage or by amount.
        /// </summary>
        /// <param name="feeName">Name of fee which we want to split.</param>
        /// <param name="stateName">Name of the state with which we want to split the fee.</param>
        /// <param name="assignPer">Percentage of assignment.</param>
        /// <param name="assignAmount">assignment in dollar amount.</param>
        public void AssignFeeBetweenStates(string feeName,string stateName, string assignPer=null,string assignAmount=null)
        {
            string assignStateDolAmnt = string.Empty;
            string parentStateDolAmnt = string.Empty;
            string primaryState=string.Empty;

            Reports.TestStep = "Select the " + feeName + " from the Fees Table.";
            this.FeeTable.PerformTableAction(1, feeName, 1, TableAction.Click);
            FastDriver.WebDriver.HandleDialogMessage();
            this.WaitForScreenToLoad();
            primaryState=this.PropertyTable.PerformTableAction(2,2,TableAction.GetText).Message.Trim();

            Reports.TestStep = "Click on the Assign Fee Between States check box.";
            if (!this.AssignState.IsSelected())
            {
                this.AssignState.FASetCheckbox(true);
                this.WaitForScreenToLoad();
            }
            parentStateDolAmnt = this.FeeTable.PerformTableAction(1, feeName, 3, TableAction.GetText).Message.Trim();

            if(!string.IsNullOrWhiteSpace(assignPer))
            {
                assignPer = (assignPer.Contains("#")) ? "0.00" : assignPer;
                Reports.TestStep = "Splitting the fee amount between states by percentage.";
                this.AssignTable.PerformTableAction(2,stateName,2, TableAction.Click);
                this.AssignTable.PerformTableAction(2,stateName, 3, TableAction.SetText, assignPer + FAKeys.Tab);
                this.AssignTable.PerformTableAction(2, primaryState, 1, TableAction.Click);

                Reports.TestStep = "Calculating the assign $ amount based on the assign %.";
                assignStateDolAmnt = string.Format("{0:0.00}", (Convert.ToDouble(parentStateDolAmnt) * Convert.ToDouble(assignPer))/100);
                parentStateDolAmnt = string.Format("{0:0.00}", Convert.ToDouble(parentStateDolAmnt) - Convert.ToDouble(assignStateDolAmnt));

                Reports.TestStep = "Verifying the assign $ amount for the states.";
                Support.AreEqual(assignStateDolAmnt, this.AssignTable.PerformTableAction(2, stateName, 4, TableAction.GetText).Message.Trim(), "Verification of assign $ amount for assigned state.");
                Support.AreEqual(parentStateDolAmnt, this.AssignTable.PerformTableAction(2, primaryState, 4, TableAction.GetText).Message.Trim(), "Verification of assign $ amount for Parent state.");
            }
            if(!string.IsNullOrWhiteSpace(assignAmount))
            {
                assignAmount = (assignAmount.Contains("#")) ? "0.00" : assignAmount;
                Reports.TestStep = "Splitting the fee amount between states by amount.";
                this.AssignTable.PerformTableAction(2, stateName, 2, TableAction.Click);
                this.AssignTable.PerformTableAction(2, stateName, 4, TableAction.SetText, assignAmount + FAKeys.Tab);
                this.AssignTable.PerformTableAction(2, primaryState, 1, TableAction.Click);

                Reports.TestStep = "Calculating the assign $ amount based on the amount entered.";
                parentStateDolAmnt = string.Format("{0:0.00}",Convert.ToDouble(parentStateDolAmnt) - Convert.ToDouble(assignAmount));

                Reports.TestStep = "Verifying the assign $ amount for the states.";
                Support.AreEqual("0.0000", this.AssignTable.PerformTableAction(2, stateName, 3, TableAction.GetText).Message.Trim(), "Verification of assign % amount for assigned state.");
                Support.AreEqual(parentStateDolAmnt, this.AssignTable.PerformTableAction(2, primaryState, 4, TableAction.GetText).Message.Trim(), "Verification of assign $ amount for Parent state.");
            }
        }

        /// <summary>
        /// This function verifies the assign $ and % default value for the mentioned state before performing the assignment.
        /// </summary>
        /// <param name="feeName">Name of the fee. </param>
        /// <param name="stateName">Name of the state.</param>
        public void VerifyDefaultValuesforStateBeforAssign(string feeName,string stateName)
        {
            Reports.TestStep = "Select the " + feeName + " from the Fees Table.";
            this.FeeTable.PerformTableAction(1, feeName, 1, TableAction.Click);
            this.WaitForScreenToLoad();

            Reports.TestStep = "Click on the Assign Fee Between States check box.";
            if (!this.AssignState.IsSelected())
            {
                this.AssignState.FASetCheckbox(true);
                this.WaitForScreenToLoad();
            }

            Reports.TestStep = "Verifying the Assign $ and %  values for state before performing the assignment";
            Support.AreEqual("0.0000", this.AssignTable.PerformTableAction(2, stateName, 3, TableAction.GetText).Message.Trim(), "Assign% for the state should be zero.");
            Support.AreEqual("0.00", this.AssignTable.PerformTableAction(2, stateName, 4, TableAction.GetText).Message.Trim(), "Assign$ for the state should be zero.");
        }
    }
}
