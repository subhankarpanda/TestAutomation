using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
using System.Windows.Input;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;

namespace FASTSelenium.PageObjects.IIS
{
    public class AssocDocSeqDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtPackage")]
        public IWebElement PackageIDName { get; set; }

        [FindsBy(How = How.Id, Using = "btnDocRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDocUp")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDocDown")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocs_0_lbType")]
        public IWebElement LenderPolicy { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocs_6_lbName")]
        public IWebElement ClosingLetterListingAgent { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocs_0_lbSeq")]
        public IWebElement Sequence0 { get; set; }

        [FindsBy(How = How.Id, Using = "dgDocs_dgDocs")]
        public IWebElement DocumentTable { get; set; }
        #endregion

        public AssocDocSeqDlg WaitForScreenToLoad()
        {

            try
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            }
            catch (Exception)
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_1_iframe");
            }

            try
            {
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }
            catch { }

            this.WaitCreation(Remove ?? PackageIDName);
            return this;
        }

        public AssocDocSeqDlg SelectAllDocuments()
        {
            this.SwitchToDialogContentFrame();
            var docs = DocumentTable.FindElements(By.XPath(".//tr")).GetAllVisible();

            Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

            Playback.Wait(500); // need this
            for (int i = 0; i < docs.Count; i++)
            {
                docs[i].FAClick(); // click on row to select
            }

            Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

            return this;
        }
    }
}
