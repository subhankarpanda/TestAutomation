using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class AssociateDocs : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement DeliverMethod { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliverGUI")]
		public IWebElement DeliverButton { get; set; }

		[FindsBy(How = How.Id, Using = "TC_AD_DRA_btnModify")]
		public IWebElement Modify { get; set; }

		[FindsBy(How = How.Id, Using = "TC_AD_DRA_btnAddRemove")]
		public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tblAssocDoc")]
        public IWebElement PackageTable { get; set; }

        [FindsBy(How = How.Name, Using = "TC_AD_DRA_dgDocs_dgDocs")]
        public IWebElement AssociatedDocsTable { get; set; }

        [FindsBy(How = How.Name, Using = "TC_AD_DRA_dgAssocDoc_dgAssocDoc")]
        public IWebElement PackageTable1 { get; set; }


        
		#endregion

        public AssociateDocs WaitForScreenToLoad()
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            wait.Until(d =>
            {
                this.SwitchToContentFrame();
                return Modify.Exists();
            });
            return this;
        }

	}
}
