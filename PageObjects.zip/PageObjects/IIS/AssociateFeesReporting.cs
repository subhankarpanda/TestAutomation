using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class AssociateFeesReporting : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtFileRateType")]
        public IWebElement FileRateType { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLoanPolicy_0_chkSelectLender")]
        public IWebElement SelectLender { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_0_labelPolicyFees")]
        public IWebElement NewHomeRateTitleOnly { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_1_labelPolicyFees")]
        public IWebElement NewHomeRateLenderPolicy_1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_0_labelFeeAmount")]
        public IWebElement FeeAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_1_labelFeeAmount")]
        public IWebElement FeeAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLoanPolicy_0_labelLoanSeqNumber")]
        public IWebElement LoanNumber { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLoanPolicy_0_labelLenderName")]
        public IWebElement LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLoanPolicy_0_labelLiabilityAmount")]
        public IWebElement LiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_0_labelEndorsement")]
        public IWebElement Endorsement1Edit_L { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_1_labelEndorsement")]
        public IWebElement Endorsement1Edit_O { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_0_chkAssociateEndorsement")]
        public IWebElement Endorsement1Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_1_chkAssociateEndorsement")]
        public IWebElement Endorsement2Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_0_labelEndorsementFeeAmount")]
        public IWebElement EndorsementFeeAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_1_labelEndorsementFeeAmount")]
        public IWebElement EndorsementFeeAmount2 { get; set; }


        [FindsBy(How = How.Id, Using = "dgridPolicyFees_0_labelRateType")]
        public IWebElement FeeRate1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_0_cmdSelectRateType")]
        public IWebElement Ellipse1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_1_labelRateType")]
        public IWebElement FeeRate2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_1_cmdSelectRateType")]
        public IWebElement Ellipse2 { get; set; }

        [FindsBy(How = How.LinkText, Using = "1")]
        public IWebElement LoanNum { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_0_cmdEndorseRateType")]
        public IWebElement EndorseEllipse1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_1_cmdEndorseRateType")]
        public IWebElement EndorseEllipse2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_dgridPolicyFees")]
        public IWebElement PolicyFeesTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridLoanPolicy_dgridLoanPolicy")]
        public IWebElement AssociateLoanPolicyTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAssociaEndorsementFees_dgridAssociaEndorsementFees")]
        public IWebElement EndorsementFeesTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_1_chkSimlutaneous")]
        public IWebElement Simlutaneous1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPolicyFees_0_cmdSelectTransCode")]
        public IWebElement SelectTransaction { get; set; }

        [FindsBy(How = How.Id, Using = "dgRateTypes")]
        public IWebElement SelectRateTypesDialogueTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgRateTypes_0_labelDescription")]
        public IWebElement RateTypesDialogLableDescription1 { get; set; }
        
        [FindsBy(How = How.Id, Using = "dgRateTypes_1_labelDescription")]
        public IWebElement RateTypesDialogLableDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRateTypes_2_labelDescription")]
        public IWebElement RateTypesDialogLableDescription3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRateTypes_0")]
        public IWebElement EndorseRateTypesDialogLableDescription1 { get; set; }


        #endregion

        public AssociateFeesReporting WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? PolicyFeesTable);
            return this;
        }

        public AssociateFeesReporting WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PolicyFeesTable, 10);
            return this;
        }
    }
    public class RateTypeSelectDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgRateTypes_1_labelDescription")]
        public IWebElement BasicRateType { get; set; }

        #endregion

    }
}
