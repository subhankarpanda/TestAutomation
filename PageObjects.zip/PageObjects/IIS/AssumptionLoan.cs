using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using FASTWCFHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class AssumptionLoanDetails : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tPT")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_cmdCheckDetails")]
        public IWebElement DetailsCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_txtGABcode")]
        public IWebElement DetailsGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_cmdFindName")]
        public IWebElement DetailsFind { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_txtName")]
        public IWebElement DetailsName { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_chkEditContactInfo")]
        public IWebElement DetailsEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textBusPhone")]
        public IWebElement DetailsBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textBusFax")]
        public IWebElement DetailsBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textCellPhone")]
        public IWebElement DetailsCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textPager")]
        public IWebElement DetailsPager { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textEmailAddress")]
        public IWebElement DetailsEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_chkWeeklyEmailStatus")]
        public IWebElement DetailsEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_comboAttention")]
        public IWebElement DetailsAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_chkEdit")]
        public IWebElement DetailsEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textName")]
        public IWebElement DetailsNameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_textReference")]
        public IWebElement DetailsReference { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_ddlLT")]
        public IWebElement DetailsLoanType { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtUPB")]
        public IWebElement UnpaidPricincipalBalance { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtIP")]
        public IWebElement InterestPaidto { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtNP")]
        public IWebElement NextPaymentDue { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtND")]
        public IWebElement NotedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtOA")]
        public IWebElement OriginalNoteAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtPA")]
        public IWebElement PaymentAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_ddlPT")]
        public IWebElement PaymentType { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_ddlPP")]
        public IWebElement PaymentPer { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtMD")]
        public IWebElement MaturityDate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_chkLC")]
        public IWebElement LateCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_optLP")]
        public IWebElement LateChargeopt1 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtLP")]
        public IWebElement LateChargePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtLA")]
        public IWebElement LateChargeAfterDays { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_optLCA")]
        public IWebElement LateChargeopt2 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtLCA")]
        public IWebElement LateChargeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_txtLL")]
        public IWebElement LenderPolicyLiability { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_labelName")]
        public IWebElement GABcodeName { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_labelName2")]
        public IWebElement GABcodeName1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblTCq")]
        public IWebElement CheqAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblUP")]
        public IWebElement UnPrincBalPane { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_tab")]
        public IWebElement RecordingTab { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLD_ALD_bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        #endregion

        public AssumptionLoanDetails Open()
        {
            FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan");
            this.WaitForScreenToLoad();

            return this;
        }

        public AssumptionLoanDetails WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(DetailsGABcode);
            return this;
        }

        public AssumptionLoanDetails FillDetailsForm(string detailsGABcode, string unpaidPricincipalBalance, string interestPaidto, string nextPaymentDue, string notedDate, string originalNoteAmount)
        {
            this.SwitchToContentFrame();
            DetailsGABcode.FASetText(detailsGABcode);
            DetailsFind.FAClick();
            this.WaitForValue(GABcodeLabel, detailsGABcode);
            UnpaidPricincipalBalance.FASetText(unpaidPricincipalBalance);
            InterestPaidto.FASetText(interestPaidto);
            NextPaymentDue.FASetText(nextPaymentDue);
            NotedDate.FASetText(notedDate);
            OriginalNoteAmount.FASetText(originalNoteAmount);

            return this;
        }

        public AssumptionLoanCharges ClickChargesTab()
        {
            this.SwitchToContentFrame();
            ChargesTab.FAClick();
            return FastDriver.GetPage<AssumptionLoanCharges>();
        }

        public AssumptionLoanDetails FindGABCode(string GABCode, bool WaitForGabCodeLabel = true)
        {
            this.SwitchToContentFrame();
            DetailsGABcode.FASetText(GABCode);
            DetailsFind.FAClick();
            if(WaitForGabCodeLabel)
            {
                Playback.Wait(500);
                this.WaitForValue(GABcodeLabel, GABCode);
            }
                
            return this;
        }
        

    }

    public class AssumptionLoanCharges : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cmdPC")]
        public IWebElement PayCharges { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tPT")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_btnPayment")]
        public IWebElement UnpaidPrincLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs")]
        public IWebElement UnpaidPrincipalLoanChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs_0_tdsc")]
        public IWebElement UnpaidPrincLoanChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs")]
        public IWebElement UnpaidPrincLoanChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs_0_tbc")]
        public IWebElement UnpaidPrincLoanBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs_0_tbd")]
        public IWebElement UnpaidPrincLoanBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs_0_tsc")]
        public IWebElement UnpaidPrincLoanSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_dcs_0_tsr")]
        public IWebElement UnpaidPrincLoanSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_btnPayment")]
        public IWebElement InterestProrationPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_cboInterestType")]
        public IWebElement InterestProrationInterestType { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_rdoPerDiem")]
        public IWebElement InterestProrationPerDiem { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_txtPerDiem")]
        public IWebElement InterestProrationPerDiemAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_txtFromDate")]
        public IWebElement InterestProrationFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_chkInclusiveFrom")]
        public IWebElement InterestProrationInclusiveFrom { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_cboBasisDays")]
        public IWebElement InterestProrationBasedonDays { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_rdoPercentRate")]
        public IWebElement InterestProrationPercentRate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_txtPercentRate")]
        public IWebElement InterestProrationPercentRatevalue { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_txtToDate")]
        public IWebElement InterestProrationToDate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_chkInclusiveTo")]
        public IWebElement InterestProrationInclusiveTo { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_chkCreditSeller")]
        public IWebElement InterestProrationCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_CGrid_dcs_0_tdsc")]
        public IWebElement InterestProrationChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_CGrid_dcs_0_tbc")]
        public IWebElement InterestProrationBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_CGrid_dcs_0_tbd")]
        public IWebElement InterestProrationBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_CGrid_dcs_0_tsc")]
        public IWebElement InterestProrationSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_CGrid_dcs_0_tsr")]
        public IWebElement InterestProrationSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_IP_CGrid_dcs")]
        public IWebElement InterestProrationTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_btnPayment")]
        public IWebElement AssumpLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cg_btnPayment")]
        public IWebElement UnpaidPrincipalLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_0_tdsc")]
        public IWebElement AssumpLoanChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_0_tbc")]
        public IWebElement AssumpLoanChargesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_1_tbc")]
        public IWebElement AssumpLoanChargesBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_2_tbc")]
        public IWebElement AssumpLoanChargesBuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_3_tbc")]
        public IWebElement AssumpLoanChargesBuyerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_4_tbc")]
        public IWebElement AssumpLoanChargesBuyerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_0_tbd")]
        public IWebElement AssumpLoanChargesBuyerCredit0 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_1_tbd")]
        public IWebElement AssumpLoanChargesBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_2_tbd")]
        public IWebElement AssumpLoanChargesBuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_3_tbd")]
        public IWebElement AssumpLoanChargesBuyerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_4_tbd")]
        public IWebElement AssumpLoanChargesBuyerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_0_tsc")]
        public IWebElement AssumpLoanChargesSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_0_tsr")]
        public IWebElement AssumpLoanChargesSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_1_tsr")]
        public IWebElement AssumpLoanChargesSellerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_2_tsr")]
        public IWebElement AssumpLoanChargesSellerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_3_tsr")]
        public IWebElement AssumpLoanChargesSellerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_4_tsr")]
        public IWebElement AssumpLoanChargesSellerCredit5 { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs_0_tga")]
        public IWebElement AssumpLoanChargesLoanEstimate1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblUP")]
        public IWebElement UnPrincBalPane { get; set; }

        [FindsBy(How = How.Id, Using = "lblTCg")]
        public IWebElement TotChgPane { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOC")]
        public IWebElement TotPocPane { get; set; }

        [FindsBy(How = How.Id, Using = "lblTP")]
        public IWebElement TotPrincChgs { get; set; }

        [FindsBy(How = How.Id, Using = "lblTCq")]
        public IWebElement CheqAmt { get; set; }

        [FindsBy(How = How.Id, Using = "idLCI")]
        public IWebElement CheqImage { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_dcs")]
        public IWebElement AssumptionLoanChargesTable { get; set; }
      
        [FindsBy(How = How.Id, Using = "tAL_tLC_ALC_cgs_tdHeading")]
        public IWebElement AssumptionLoanChargesHeader { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessageList { get; set; }
        
        #endregion

        public AssumptionLoanCharges WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AssumpLoanChargesPaymentDetails);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            return this;
        }

  
        public AssumptionLoanCharges FillChargesForm(string unpaidPrincLoanSellerCharge, string unpaidPrincLoanSellerCredit)
        {
            this.SwitchToContentFrame();
            UnpaidPrincLoanSellerCharge.FASetText(unpaidPrincLoanSellerCharge);
            // For CD region this charge is disabled
            if (ClosingDisclosureSupport.IMDFormType == "HUD")
            UnpaidPrincLoanSellerCredit.FASetText(unpaidPrincLoanSellerCredit);

            return this;
        }

        public AssumptionLoanCharges UpdateAssumptionLoanChargesTable(string description, string updateDesc = null, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimateUnrounded = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(AssumptionLoanChargesTable, 10);
            var rows = AssumptionLoanChargesTable.FindElements(By.TagName("tr"));

            IWebElement row = null;
            foreach (var tempRow in rows)
            {
                IWebElement descriptionInput = tempRow.FindElements(By.TagName("input")).FirstOrDefault(i => i.GetAttribute("id").Contains("_tdsc") && i.Displayed);
                try
                {
                    if (descriptionInput.GetAttribute("value").Trim().Contains(description))
                    {
                        row = tempRow;
                        break;
                    }
                }
                catch (NullReferenceException)
                {
                    continue;
                }
            }

            if (row == null)
                throw new NoSuchElementException(string.Format("Could not find an input field with description '{0}'", description));

            IWebElement inputElement;
            if (updateDesc != null)
            {
                if (description.Contains(description))
                {
                    inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tdsc") && input.Displayed);
                    inputElement.FASetText(updateDesc.ToString());
                    inputElement.FireEvent("onkeyup");
                    inputElement.FireEvent("onkeydown");
                    inputElement.FireEvent("onchange");
                    inputElement.FireEvent("onblur");
                    inputElement.Click();
                }
            }
            if (buyerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbc") && input.Displayed);
                inputElement.FASetText(buyerCharge.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
                inputElement.Click();
            }
            if (buyerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbd") && input.Displayed);
                inputElement.FASetText(buyerCredit.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
                inputElement.Click();
            }
            if (sellerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsc") && input.Displayed);
                inputElement.FASetText(sellerCharge.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
                inputElement.Click();
            }
            if (sellerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsr") && input.Displayed);
                inputElement.FASetText(sellerCredit.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
                inputElement.Click();
            }
            if (loanEstimateUnrounded.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tga") && input.Displayed);
                inputElement.FASetText(loanEstimateUnrounded.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
                inputElement.Click();
            }


            return this;
        }

        public AssumptionLoanParties clickPartiesTab()
        {
            this.SwitchToContentFrame();
            PartiesTab.FAClick();

            return FastDriver.GetPage<AssumptionLoanParties>();
        }

        public void AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

        }


        public void AddChargeRefinance(IWebElement chargesTable, string chargeDescription, double? BorrowerCharge = null, double? BorrowerCredit = null,  double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Charge", TableAction.SetText, BorrowerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Credit", TableAction.SetText, BorrowerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

           
            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

        }


        public void UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

        }

        public AssumptionLoanCharges ALProrationDetails(string GabCode, ALProration ProData)
        {
            FastDriver.AssumptionLoanDetails.Open();
            FastDriver.AssumptionLoanDetails.FindGABCode(GabCode);
            FastDriver.AssumptionLoanDetails.ClickChargesTab();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.AssumptionLoanCharges.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText(ProData.FromDate);
            FastDriver.AssumptionLoanCharges.InterestProrationInclusiveFrom.FASetCheckbox(ProData.fromInclusive);
            FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText(ProData.ToDate);
            FastDriver.AssumptionLoanCharges.InterestProrationInclusiveTo.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.AssumptionLoanCharges.InterestProrationInclusiveTo.FASetCheckbox(ProData.toInclusive);
            FastDriver.BottomFrame.Done();


            return this;
        }

        public AssumptionLoanCharges ALProrationDetailsMsection(string GabCode, ALProration ProData)
        {
            FastDriver.AssumptionLoanDetails.Open();
            FastDriver.AssumptionLoanDetails.FindGABCode(GabCode);
            FastDriver.AssumptionLoanDetails.ClickChargesTab();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.AssumptionLoanCharges.InterestProrationCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.AssumptionLoanCharges.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.AssumptionLoanCharges.InterestProrationPerDiemAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.AssumptionLoanCharges.InterestProrationFromDate.FASetText(ProData.FromDate);
            FastDriver.AssumptionLoanCharges.InterestProrationInclusiveFrom.FASetCheckbox(ProData.fromInclusive);
            FastDriver.AssumptionLoanCharges.InterestProrationToDate.FASetText(ProData.ToDate);
            FastDriver.AssumptionLoanCharges.InterestProrationInclusiveTo.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
            FastDriver.AssumptionLoanCharges.InterestProrationBuyerCharge.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.AssumptionLoanCharges.InterestProrationBuyerCredit.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.AssumptionLoanCharges.InterestProrationSellerCharge.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.AssumptionLoanCharges.InterestProrationSellerCredit.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();


            return this;
        }


        public void VerifyOReditChargeDescription(string ChargeDesciption, String editorverify)
        {
            FastDriver.AssumptionLoanDetails.Open();
            FastDriver.AssumptionLoanDetails.ClickChargesTab();
            FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

            if (editorverify.ToUpper() == "VERIFY")
                Support.AreEqual(ChargeDesciption, FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAGetValue());
            if (editorverify.ToUpper() == "EDIT")
            {
                FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FAClick();
                FastDriver.AssumptionLoanCharges.InterestProrationChargeDescription.FASetText(ChargeDesciption, false, true);
            }
        }

    }

    public class ALProration
    {
        public string Description = "Assumption Loan Interest Proration";
        public string prorationType = "NONE";
        public bool CreditSeller;
        public bool DayofClosePaidbySeller;
        public decimal ProrationAmount;
        public string FromDate;
        public bool fromInclusive;
        public bool fromProrateDate;
        public string BasedOn;
        public string Per;
        public string ToDate;
        public bool toInclusive;
        public bool toProrateDate;
        public decimal ProrationBuyerCharge;
        public decimal ProrationBuyerCredit;
        public decimal ProrationSellerCharge;
        public decimal ProrationSellerCredit;
        public decimal ProrationUtilityLE;
    }

    public class AssumptionLoanParties : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tPT")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_btnTR")]
        public IWebElement TrustMortgagorRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_txtTM")]
        public IWebElement TrustMortgagor { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_btnOB")]
        public IWebElement Beneficiary_MortgageeRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_txtOB")]
        public IWebElement Beneficiary_Mortgagee { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_btnAB")]
        public IWebElement AssigneeBeneficiary_MortgageeRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_txtAB")]
        public IWebElement AssigneeBeneficiary_Mortgagee { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_txtGABcode")]
        public IWebElement TrusteeBPGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_cmdFindName")]
        public IWebElement TrusteeFind { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_txtName")]
        public IWebElement TrusteeBusinessPartyName { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_chkEditContactInfo")]
        public IWebElement TrusteeEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textBusPhone")]
        public IWebElement TrusteeBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textBusFax")]
        public IWebElement TrusteeBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textCellPhone")]
        public IWebElement TrusteeCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textPager")]
        public IWebElement TrusteePager { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textEmailAddress")]
        public IWebElement TrusteeEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_chkWeeklyEmailStatus")]
        public IWebElement TrusteeEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_comboAttention")]
        public IWebElement TrusteeAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_chkEdit")]
        public IWebElement TrusteeEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textName")]
        public IWebElement TrusteeEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_textReference")]
        public IWebElement TrusteeReference { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_tab")]
        public IWebElement RecordingTab { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tPT_ALP_TBP_labelIdcode")]
        public IWebElement TrusteeGABcodeLabel { get; set; }

        #endregion

        public AssumptionLoanParties WaitForScreeToLoan()
        {
            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d => {
                try {
                    this.SwitchToContentFrame();
                    return TrusteeBPGABcode.Displayed;
                }catch(NoSuchElementException){
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }
            });
            return this;
        }

        public AssumptionLoanParties FindGABCode(string GABCode)
        {
            this.SwitchToContentFrame();
            TrusteeBPGABcode.FASetText(GABCode);
            TrusteeFind.FAClick();

            return this;
        }

        public AssumptionLoanRecording clickRecordingTab()
        {
            this.SwitchToContentFrame();
            RecordingTab.FAClick();

            return FastDriver.GetPage<AssumptionLoanRecording>();
        }

    }

    public class AssumptionLoanRecording : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tPT")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tAL_tAR")]
        public IWebElement Recording { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_ALR_txtTrustDeedDate")]
        public IWebElement TrustDeedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_ALR_txtRecordingDate")]
        public IWebElement RecordingDate { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_ALR_txtInstrument")]
        public IWebElement Instrument { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_ALR_txtBook")]
        public IWebElement Book { get; set; }

        [FindsBy(How = How.Id, Using = "tAL_tAR_ALR_txtPage")]
        public IWebElement Page { get; set; }

        #endregion

        public AssumptionLoanRecording WaitForScreeToLoan()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            this.WaitCreation(TrustDeedDate);
            return this;
        }

    }
}
