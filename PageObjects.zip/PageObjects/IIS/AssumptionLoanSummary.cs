using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AssumptionLoanSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDel")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "grdLoanSumry")]
		public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblTitleCnt")]
        public IWebElement TotalNoOfRecords { get; set; }
        #endregion

        #region Useful Methods
        public AssumptionLoanSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);
            return this;
        }

        public AssumptionLoanSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan");
            this.WaitForScreenToLoad();

            return this;
        }


        #endregion


        public void Deleteallinstances()
        {
            FastDriver.LeftNavigation.Navigate<AssumptionLoanSummary>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
            int rc= this.SummaryTable.GetRowCount();
            for (int i = 1; rc > 1; i++)
            {
                this.WaitForScreenToLoad();
                this.SummaryTable.PerformTableAction(1,i.ToString(), 1, TableAction.Click);
                this.Remove.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                this.WaitForScreenToLoad();
                rc--;

            }
        }
    }
}
