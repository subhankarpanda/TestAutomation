using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class AttachMessage : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileNo")]
		public IWebElement FileNo { get; set; }

		[FindsBy(How = How.Id, Using = "cboDocumentType")]
		public IWebElement DocumentType { get; set; }

		[FindsBy(How = How.Id, Using = "cboDocumentName")]
		public IWebElement DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "txtDocumentName")]
        public IWebElement MisDocumentName { get; set; }

		[FindsBy(How = How.Id, Using = "cboWQTriggerNames")]
		public IWebElement WQTriggerNames { get; set; }

		[FindsBy(How = How.Id, Using = "txtPageNumbers")]
		public IWebElement PageNumbersRange { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "btnSave")]
		public IWebElement Save { get; set; }

		[FindsBy(How = How.Id, Using = "btnOK")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "cboSDN")]
        public IWebElement SDNSearchHitName { get; set; }

        [FindsBy(How = How.Id, Using = "lblSDN")]
        public IWebElement SDNSearchHitLabel { get; set; }        

		#endregion

        public AttachMessage WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("AttachMessage", true, 20);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? Region);
            return this;
        }

	}
}
