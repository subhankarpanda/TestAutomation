using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class AttorneyDetail : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement AttorneyBuyerSeller_LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName2")]
        public IWebElement AttorneyBuyerSeller_LenderName1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Check Details")]
		public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdFindName")]
		public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtName")]
		public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "acg_dcs_1_tdsc")]
        public IWebElement ChargeDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "acg_dcs_1_tbc")]
        public IWebElement BuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "acg_dcs_1_tsc")]
        public IWebElement SellerCharge1 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement BusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textBusFax")]
        public IWebElement BusFax { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_chkWeeklyEmailStatus")]
		public IWebElement WeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_comboAttention")]
		public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_ddlBusOrgStateLicense")]
        public IWebElement BusOrgStateLicense { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_ddlBusContactStateLicense")]
        public IWebElement BusContactStateLicense { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_chkEdit")]
		public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textName")]
        public IWebElement NameEdit { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_comboSalesRep1")]
		public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep2")]
		public IWebElement SalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "comboType")]
		public IWebElement Type { get; set; }

		[FindsBy(How = How.Id, Using = "acg_btnPayment")]
		public IWebElement PaymentDetails { get; set; }

		[FindsBy(How = How.Id, Using = "acg_dcs_0_tdsc")]
		public IWebElement ChargeDescription { get; set; }

		[FindsBy(How = How.Id, Using = "acg_dcs_0_tbc")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "acg_dcs_0_tsc")]
		public IWebElement SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "labelTotalCharges")]
		public IWebElement TotalCharges { get; set; }

		[FindsBy(How = How.Id, Using = "labelNetCheckAmount")]
		public IWebElement NetcheckAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "BusOrgID: Business Party required")]
		public IWebElement BusinessPartyRequired { get; set; }

		[FindsBy(How = How.Id, Using = "labelEarnestMoney")]
		public IWebElement EarnestMoney { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#idCheckIssuedIcon img")]
		public IWebElement Issuedcheckimage { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src=\"../images/ico_write.gif\"]")]
		public IWebElement PencilImage { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
		public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "acg_dcs_0_tga")]
		public IWebElement LoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "acg_dcs")]
		public IWebElement SellerAttorneyChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorList { get; set; }
        
		#endregion

        public AttorneyDetail Open(bool isBuyer = true)
        {
            FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Attorney - " + (isBuyer ? "Buyer":"Seller"));
            this.WaitForScreenToLoad();

            return this;
        }

        public AttorneyDetail AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                chargeElement.SendKeys(FAKeys.Tab);
                Playback.Wait(250);
            }
            return this;

        }

        public AttorneyDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public AttorneyDetail WaitForScreenToLoad() {

            WebDriverWait Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(120));

            Wait.Until(d =>
                {
                    try
                    {
                        this.SwitchToContentFrame();
                        return GABcode.IsDisplayed();
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                    catch (StaleElementReferenceException) {
                        return false;
                    }
                });
            return this;

        }

        public void FindGABcode(string gabcode, bool waitForGabCodeLabel = true)
        {
            this.GABcode.FASetText(gabcode);
            this.Find.FAClick();
            if (waitForGabCodeLabel)
            {
                Playback.Wait(500);
                //this.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("#bpB_labelIdcode:contains('" + gabcode + "')")));
                this.WaitForValue(this.GABcodeLabel, gabcode);
            }
            
        }

        public AttorneyDetail AttorneyHSectionCharges(string GabCode = "HUDATASTL1", bool secondInstance = false,bool IsBuyer=true)
        {

            this.Open(IsBuyer);

            if (secondInstance == true)
                FastDriver.BottomFrame.New();

            FastDriver.AttorneyDetail.FindGABcode(GabCode,false);
            FastDriver.AttorneyDetail.ChargeDescription.FASetText("Attorney Charges 1");
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.AttorneyDetail.BuyerCharge.FASetText("345.67");
            FastDriver.AttorneyDetail.SellerCharge.FASetText("789.98");
            FastDriver.AttorneyDetail.LoanEstimate.FASetText("399.99");
            Keyboard.SendKeys(FAKeys.TabAway);

            FastDriver.AttorneyDetail.ChargeDescription1.FASetText("Attorney Charges 2");
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.AttorneyDetail.BuyerCharge1.FASetText("123.67");
            FastDriver.AttorneyDetail.SellerCharge1.FASetText("456.98");
            

            return this;
        }

	}
}
