using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class AttorneySummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridAttorneySummary")]
		public IWebElement SummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		#endregion

        public AttorneySummary WaitForScreenToLoad()
        {

            WebDriverWait Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(120));

            Wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return SummaryTable.IsDisplayed();
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }
            });
            return this;

        }
	}
}
