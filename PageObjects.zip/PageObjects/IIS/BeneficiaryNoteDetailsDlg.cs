﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class BeneficiaryNoteDetailsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgFileDetails_0_optID")]
        public IWebElement CheckBox0 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFileDetails_1_optID")]
        public IWebElement Checkbox1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFileDetails_2_optID")]
        public IWebElement Checkbox2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFileDetails_3_optID")]
        public IWebElement Checkbox3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFileDetails_4_optID")]
        public IWebElement Checkbox4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFileDetails_5_optID")]
        public IWebElement Checkbox5 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFileDetails")]
        public IWebElement DetailsTable { get; set; }


        #endregion

        public BeneficiaryNoteDetailsDlg WaitForScreenToLoad(string windowName = "Note Details")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(DetailsTable);
            return this;
        }

    }
}