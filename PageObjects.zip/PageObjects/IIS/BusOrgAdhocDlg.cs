using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class BusOrgAdhocDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "comboTypetable")]
		public IWebElement EntityType { get; set; }

		[FindsBy(How = How.Id, Using = "txtName1")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtName2")]
		public IWebElement Name2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine1")]
		public IWebElement AddrLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine2")]
		public IWebElement AddrLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine3")]
		public IWebElement AddrLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine4")]
		public IWebElement AddrLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "txtCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "txtZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Id, Using = "txtCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "txtBusPhone")]
		public IWebElement BusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "txtBusFax")]
		public IWebElement BusinessFax { get; set; }

		[FindsBy(How = How.Id, Using = "txtCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "txtPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmail")]
		public IWebElement Email { get; set; }

		#endregion

        #region services

        public BusOrgAdhocDlg WaitForScreenToLoad(string windowName = "Address Book Business Organization Ad Hoc")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(EntityType);

            return this;
        }

        /// <summary>
        /// Set data for All the fields
        /// </summary>
        /// <param name="adhocparam"></param>
        public void SetAll(BusOrgAdhocDlgParameters adhocparam)
        {
            try
            {
                Reports.TestStep = "Set data for All the fields";
                EntityType.FASelectItem(adhocparam.EntityType);
                Name1.FASetText(adhocparam.Name1);
                Name2.FASetText(adhocparam.Name2);

                Country.FASelectItem(adhocparam.Country);
                FastDriver.BusOrgAdhocDlg.WaitCreation(AddrLine1, true);
                Country.FireEvent("onchange");
                FastDriver.BusOrgAdhocDlg.WaitCreation(AddrLine1, true);

                AddrLine1.FASetText(adhocparam.AddrLine1);
                AddrLine2.FASetText(adhocparam.AddrLine2);
                AddrLine3.FASetText(adhocparam.AddrLine3);
                AddrLine4.FASetText(adhocparam.AddrLine4);

                if (City.Enabled)
                {
                    City.FASetText(adhocparam.City);
                    State.FASelectItem(adhocparam.State);
                    Zip.FASetText(adhocparam.Zip);
                    County.FASetText(adhocparam.County);
                }

                BusinessPhone.FASetText(adhocparam.BusPhone);
                BusinessFax.FASetText(adhocparam.BusFax);
                CellPhone.FASetText(adhocparam.CellPhone);
                Pager.FASetText(adhocparam.Pager);
                Email.FASetText(adhocparam.Email);
            }
            catch(Exception e)
            {
                throw new Exception("Failure in AdhocDlg Screen.", e);
            }
        }

        /// <summary>
        /// Verify data in All the fields
        /// </summary>
        /// <param name="adhocparam"></param>
        public void VerifyAll(BusOrgAdhocDlgParameters adhocparam)
        {
            Reports.TestStep = "Verify data in All the fields";
            Support.AreEqual(adhocparam.EntityType, EntityType.FAGetSelectedItem());
            Support.AreEqual(adhocparam.Name1, Name1.FAGetValue());
            Support.AreEqual(adhocparam.Name2, Name2.FAGetValue());

            Support.AreEqual(adhocparam.AddrLine1, AddrLine1.FAGetValue());
            Support.AreEqual(adhocparam.AddrLine2, AddrLine2.FAGetValue());
            Support.AreEqual(adhocparam.AddrLine3, AddrLine3.FAGetValue());
            Support.AreEqual(adhocparam.AddrLine4, AddrLine4.FAGetValue());

            if (City.Enabled)
            {
                Support.AreEqual(adhocparam.City, City.FAGetValue());
                Support.AreEqual(adhocparam.State, State.FAGetSelectedItem());
                Support.AreEqual(adhocparam.Zip, Zip.FAGetValue());
            }

            Support.AreEqual(adhocparam.County, County.FAGetValue());
            Support.AreEqual(adhocparam.Country, Country.FAGetSelectedItem());

            Support.AreEqual(adhocparam.BusPhone, BusinessPhone.FAGetValue());
            Support.AreEqual(adhocparam.BusFax, BusinessFax.FAGetValue());
            Support.AreEqual(adhocparam.CellPhone, CellPhone.FAGetValue());
            Support.AreEqual(adhocparam.Pager, Pager.FAGetValue());
            Support.AreEqual(adhocparam.Email, Email.FAGetValue());
        }

        /// <summary>
        /// Fetch the Values from the Adhoc Dialog Screen
        /// </summary>
        public BusOrgAdhocDlgParameters GetAdhocDetails
        {
            get
            {
                BusOrgAdhocDlgParameters readUIValue = new BusOrgAdhocDlgParameters();
                readUIValue.EntityType = EntityType.FAGetSelectedItem();
                readUIValue.Name1 = Name1.FAGetValue();
                readUIValue.Name2 = Name2.FAGetValue();

                readUIValue.AddrLine1 = AddrLine1.FAGetValue();
                readUIValue.AddrLine2 = AddrLine2.FAGetValue();
                readUIValue.AddrLine3 = AddrLine3.FAGetValue();
                readUIValue.AddrLine4 = AddrLine4.FAGetValue();

                readUIValue.City = City.FAGetValue();
                readUIValue.State = State.FAGetSelectedItem();
                readUIValue.Zip = Zip.FAGetValue();

                readUIValue.County = County.FAGetValue();
                readUIValue.Country = Country.FAGetSelectedItem();

                readUIValue.BusPhone = BusinessPhone.FAGetValue();
                readUIValue.BusFax = BusinessFax.FAGetValue();
                readUIValue.CellPhone = CellPhone.FAGetValue();
                readUIValue.Pager = Pager.FAGetValue();
                readUIValue.Email = Email.FAGetValue();

                return readUIValue;
            }
        }

        /// <summary>
        /// Verify all the Error Warning Messages in Usecase FMUC0070
        /// </summary>
        /// <param name="optionindex"></param>
        public void VerifyErrorWarningMessages(BusOrgAdhocDlgParameters adhocparam)
        {
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();

                //No EntityType
                Reports.TestStep = "ErrorWarning when No Entity Type";
                EntityType.FASelectItemByIndex(0);

                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenNoEntity, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                EntityType.FASelectItem(adhocparam.EntityType);

                //No name
                Reports.TestStep = "ErrorWarning when No Name";
                Name1.FASetText("");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenNoName, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                Name1.FASetText(adhocparam.Name1);

                //Phoneno less than 10 digits
                Reports.TestStep = "ErrorWarning when Business Phone no is less than 10 chars";
                BusinessPhone.FASetText("111111111");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenInvalidData, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                BusinessPhone.FASetText(adhocparam.BusPhone);

                Reports.TestStep = "ErrorWarning when Business Fax no is less than 10 chars";
                BusinessFax.FASetText("111111111");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenInvalidData, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                BusinessFax.FASetText(adhocparam.BusPhone);

                Reports.TestStep = "ErrorWarning when Cell Phone no is less than 10 chars";
                CellPhone.FASetText("111111111");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenInvalidData, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                CellPhone.FASetText(adhocparam.BusPhone);

                Reports.TestStep = "ErrorWarning when Pager no is less than 10 chars";
                Pager.FASetText("111111111");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenInvalidData, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                Pager.FASetText(adhocparam.BusPhone);

                //standard email naming conventions
                Reports.TestStep = "ErrorWarning when Email is not as per standard email naming convention";
                Email.FASetText("TestEmailStandard");
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual(EWFmuc0070.EWWhenInvalidData, FastDriver.WebDriver.HandleDialogMessage(false), "Verify the Message displayed");
                FastDriver.WebDriver.HandleDialogMessage(true, false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("Address Book Business Organization Ad Hoc", true, 20);
                FastDriver.BusOrgAdhocDlg.SwitchToDialogContentFrame();
                Email.FASetText(adhocparam.Email);

                FastDriver.DialogBottomFrame.ClickCancel();
            }
            catch(Exception e)
            {

            }
        }

        /// <summary>
        /// Verify the Default Entitytype
        /// </summary>
        /// <param name="ExpectedEntityType"></param>
        public void VerifyEntityType(string ExpectedEntityType)
        {
            if (null == ExpectedEntityType)
            {
                return;
            }
            Support.AreEqual(ExpectedEntityType, EntityType.FAGetSelectedItem(), "Verify the Default Entity Type is as per the Parent Page");
        }

        /// <summary>
        /// Workaround for the N Issue where the Country is not displayed when not equal to USA or CANADA
        /// </summary>
        /// <param name="Adhoc"></param>
        public void WorkAroundForNIssue(BusOrgAdhocDlgParameters Adhoc)
        {
            Reports.TestStep = "Workaround for the N Issue where the Country is not displayed when not equal to USA or CANADA";
            Country.FASelectItem(Adhoc.Country);
            FastDriver.BusOrgAdhocDlg.WaitCreation(AddrLine1, true);
            Country.FireEvent("onchange");
            FastDriver.BusOrgAdhocDlg.WaitCreation(AddrLine1, true);
        }

        #endregion Services
    }
}
