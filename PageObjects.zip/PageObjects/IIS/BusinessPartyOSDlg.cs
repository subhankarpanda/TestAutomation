using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileSideBusinessPartyOrganizationSetUpDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboBuyerSellerType")]
        public IWebElement BuyerSellerType { get; set; }

        [FindsBy(How = How.Id, Using = "dgridAddress_dgridAddress")]
        public IWebElement AddressesTable { get; set; }

        [FindsBy(How = How.Id, Using = "cboEntityType")]
        public IWebElement EntityType { get; set; }

        #endregion

        public FileSideBusinessPartyOrganizationSetUpDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? EntityType);

            return this;
        }
        public FileSideBusinessPartyOrganizationSetUpDlg WaitForDialogToLoad(IWebElement Element = null, string WinName = "")
        {
            Element = Element ?? EntityType;
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                try
                {
                    //  WebDriver.WaitForWindowAndSwitch(WinName, timeoutSeconds: 120);
                    this.SwitchToDialogContentFrame();
                    return Element.Displayed;
                }
                catch (NoSuchWindowException)
                {
                    return false;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }

            });
            return this;
        }

    }
}
