using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class BusinessProgramsHistoryDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridBusinessProgramHistory_dgridBusinessProgramHistory")]
		public IWebElement BusinessProgramsHistory { get; set; }

		#endregion

        public BusinessProgramsHistoryDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(BusinessProgramsHistory);

            return this;
        }
	}
}
