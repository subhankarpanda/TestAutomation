using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;

namespace FASTSelenium.PageObjects.IIS
{
	public class BuyerSellerEntitySignatures : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "Faftextbox1")]
		public IWebElement NameofEntity { get; set; }

		[FindsBy(How = How.Id, Using = "cboMainEntityState")]
		public IWebElement StateOfIncorp { get; set; }

		[FindsBy(How = How.Id, Using = "cboMainEntitytype")]
		public IWebElement Entitytype { get; set; }

		[FindsBy(How = How.Id, Using = "btnMainEntityApply")]
		public IWebElement ApplyAuthorized { get; set; }

		[FindsBy(How = How.Id, Using = "btnMainEntityNew")]
		public IWebElement NewAuthorized { get; set; }

		[FindsBy(How = How.Id, Using = "btnMainEntityDelete")]
		public IWebElement RemoveAuthorized { get; set; }

		[FindsBy(How = How.Id, Using = "btnByEntityApply")]
		public IWebElement ApplyNameofEntity { get; set; }

		[FindsBy(How = How.Id, Using = "btnByEntityNew")]
		public IWebElement NewNameofEntity { get; set; }

		[FindsBy(How = How.Id, Using = "btnByEntityDelete")]
		public IWebElement DeleteNameofEntity { get; set; }

		[FindsBy(How = How.Id, Using = "btnMiddleFocus")]
		public IWebElement MiddleFocus { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtByEName")]
		public IWebElement ByNameOfEntity { get; set; }

		[FindsBy(How = How.Id, Using = "cboByEntityState")]
		public IWebElement ByStateOfIncorp { get; set; }

		[FindsBy(How = How.Id, Using = "cboByEntityType")]
		public IWebElement ByEntityType { get; set; }

		[FindsBy(How = How.Id, Using = "FAFTxtByContactName")]
		public IWebElement ByContactName { get; set; }

		[FindsBy(How = How.Id, Using = "btnByAuthSign")]
		public IWebElement NewAuthorizedSignature { get; set; }

		[FindsBy(How = How.Id, Using = "btnByEntityAuthSignDelete")]
		public IWebElement DeleteAuthorizedSignature { get; set; }

		[FindsBy(How = How.Id, Using = "btnBelowFocus")]
		public IWebElement BelowFocus { get; set; }

		[FindsBy(How = How.Id, Using = "gridMainEntityAuthSign_0_FAFtxtMEName")]
		public IWebElement AuthorizedSignatureNameOne { get; set; }

		[FindsBy(How = How.Id, Using = "gridMainEntityAuthSign_0_FAFTxtMECorpTitle")]
		public IWebElement AuthorizedSignatureCorpTitleOne { get; set; }

		[FindsBy(How = How.Id, Using = "gridByAuthSigners_0_ftxtByAuthName")]
		public IWebElement ByEntityAuthorizedSignatureName { get; set; }

		[FindsBy(How = How.Id, Using = "gridByAuthSigners_0_ftxtAuthCorpTitle")]
		public IWebElement ByEntityAuthorizedSignatureCorpTitle { get; set; }

        [FindsBy(How = How.Id, Using = "btnViewSignature")]
        public IWebElement ViewEditSignature { get; set; }
		#endregion


        #region Services
        public BuyerSellerEntitySignatures WaitForScreenToLoad(IWebElement elem = null)
        {
            this.SwitchToContentFrame();
            if (elem == null)
                this.WaitCreation(this.NameofEntity);
            else
                this.WaitCreation(elem);
            return this;
        }


        public void AddNewByEntityDetails(string byentName,string state,string entType,string ContctName)
        {
            this.NewNameofEntity.FAClick();
            this.WaitForScreenToLoad();
            this.ByNameOfEntity.FASetText(byentName);
            this.ByStateOfIncorp.FASelectItem(state);
            this.ByEntityType.FASelectItem(entType);
            this.ByContactName.FASetText(ContctName);
            this.ApplyNameofEntity.FAClick();
            this.WaitForScreenToLoad();
        }
        
        #endregion


	}
}
