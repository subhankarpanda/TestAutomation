﻿using System;
using System.Threading;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class BuyerSellerSetup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "imgGlobalFlag")]
        public IWebElement GlobalFlag { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtSSNI")]
        public IWebElement txtSSN { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_btnViewEditSSNTIN")]
        public IWebElement btnViewEdit { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_btnViewEditSSNTIN")]
        public IWebElement btnViewEditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdditionalInfo")]
        public IWebElement btnAdditionalInfo { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSearch")]
        public IWebElement cmdSearch { get; set; }

        [FindsBy(How = How.Id, Using = "btnExchangeCompany")]
        public IWebElement btnExchangeCompany { get; set; }

        [FindsBy(How = How.Id, Using = "btnFullVesting")]
        public IWebElement btnFullVesting { get; set; }

        [FindsBy(How = How.Id, Using = "btnAKA")]
        public IWebElement btnAKA { get; set; }

        [FindsBy(How = How.Id, Using = "btnSpouse1AKA")]
        public IWebElement btnSpouse1AKA { get; set; }

        [FindsBy(How = How.Id, Using = "btnSpouse2AKA")]
        public IWebElement btnSpouse2AKA { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewBuyer")]
        public IWebElement btnNew { get; set; }

        [FindsBy(How = How.Id, Using = "BuyerTypes")]
        public IWebElement BuyerTypes { get; set; }

        [FindsBy(How = How.Id, Using = "EmployedBys")]
        public IWebElement EmployedBy { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtFirstNameI")]
        public IWebElement IndividualFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtMiddleNameI")]
        public IWebElement IndividualMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtLastNameI")]
        public IWebElement IndividualLastName { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtSuffixI")]
        public IWebElement IndividualSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_cbo1099sClassification")]
        public IWebElement IndividualsClassification { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_cBntExp1")]
        public IWebElement IndividualAuthorizeddrop { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtTrusteeName")]
        public IWebElement IndividualAuthorizedName { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_btnApply")]
        public IWebElement IndividualApply { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_btnDelete")]
        public IWebElement RemoveAuthorizedSignature { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_txtTrusteeName")]
        public IWebElement IndividualAuthorizedSignatureName { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_cboTrusteeType")]
        public IWebElement IndividualTrusteeType { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_txtShortNameE")]
        public IWebElement BusinessEntityShortname { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_cboMarital")]
        public IWebElement MaritalStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_Vesting")]
        public IWebElement Vesting { get; set; }

        [FindsBy(How = How.Id, Using = "ctl00_txtAddnlVesting")]
        public IWebElement AdditionalVesting { get; set; }

        [FindsBy(How = How.Id, Using = "txtSalutation")]
        public IWebElement Salutation { get; set; }

        [FindsBy(How = How.Id, Using = "txtMiscRef1")]
        public IWebElement MiscRef1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMiscRef2")]
        public IWebElement MiscRef2 { get; set; }

        [FindsBy(How = How.Id, Using = "RadCurrentSetToProperty")]
        public IWebElement CurrentSetToProperty { get; set; }

        [FindsBy(How = How.Id, Using = "RadCurrentSetToOther")]
        public IWebElement CurrentSetToOther { get; set; }

        [FindsBy(How = How.Id, Using = "Text1")]
        public IWebElement CurrentStreet1 { get; set; }

        [FindsBy(How = How.Id, Using = "Text2")]
        public IWebElement CurrentStreet2 { get; set; }

        [FindsBy(How = How.Id, Using = "Text3")]
        public IWebElement CurrentStreet3 { get; set; }

        [FindsBy(How = How.Id, Using = "Text4")]
        public IWebElement CurrentStreet4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCurCity")]
        public IWebElement CurrentCity { get; set; }

        [FindsBy(How = How.Id, Using = "cboCurrState")]
        public IWebElement CurrentState { get; set; }

        [FindsBy(How = How.Id, Using = "txtCurZip")]
        public IWebElement CurrentZip { get; set; }

        [FindsBy(How = How.Id, Using = "txtCurCounty")]
        public IWebElement CurrentCounty { get; set; }

        [FindsBy(How = How.Id, Using = "cboCurrCountry")]
        public IWebElement CurrentCountry { get; set; }

        #region Forward Address
        [FindsBy(How = How.Id, Using = "RadForwardingSetToProperty")]
        public IWebElement ForwardngSetToProperty { get; set; }

        [FindsBy(How = How.Id, Using = "RadForwardingSetToCurrent")]
        public IWebElement ForwardingSetToCurrent { get; set; }

        [FindsBy(How = How.Id, Using = "RadForwardingSetToOther")]
        public IWebElement ForwardingSetToOther { get; set; }

        [FindsBy(How = How.Id, Using = "FAFTextBox1")]
        public IWebElement ForwardingStreet1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFTextBox2")]
        public IWebElement ForwardingStreet2 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFTextBox3")]
        public IWebElement ForwardingStreet3 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFTextBox4")]
        public IWebElement ForwardingStreet4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtfwdCity")]
        public IWebElement ForwardingCity { get; set; }

        [FindsBy(How = How.Id, Using = "cboForwardingState")]
        public IWebElement ForwardingState { get; set; }

        [FindsBy(How = How.Id, Using = "txtFwdZip")]
        public IWebElement ForwardingZip { get; set; }

        [FindsBy(How = How.Id, Using = "txtFwdCounty")]
        public IWebElement ForwardingCounty { get; set; }

        [FindsBy(How = How.Id, Using = "cboFwdCountry")]
        public IWebElement ForwardingCountry { get; set; }

        #endregion

        [FindsBy(How = How.Id, Using = "CurrentPhones_btnDeletePhoneEntry")]
        public IWebElement RemoveCurrPhoneNo { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_PhoneType")]
        public IWebElement CurrentPhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_1_PhoneType")]
        public IWebElement CurrentPhoneType1 { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_2_PhoneType")]
        public IWebElement CurrentPhoneType2PagrOrEmail { get; set; } //Page List box    

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_3_PhoneType")]
        public IWebElement CurrentPhoneType3Cellular { get; set; } //Page List box    

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_4_PhoneType")]
        public IWebElement CurrentPhoneType4BusFaxOrPager { get; set; } //Bus Fax   

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_5_PhoneType")]
        public IWebElement CurrentPhoneType5HomeFaxOrHomePhon { get; set; } //Home Fax   

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_PhoneType")]
        public IWebElement CurrentPhoneType6EmailOrPagrOrHomFax { get; set; } //Home Fax   

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_7_PhoneType")]
        public IWebElement CurrentPhoneType7 { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtNumber")]
        public IWebElement CurrentPhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_chkNotification")]
        public IWebElement CurrentPhoneNotification { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_chkNotification")]
        public IWebElement CurrentPhoneNotification6 { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtExtension")]
        public IWebElement CurrentExtension { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtComments")]
        public IWebElement CurrentPhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_2_txtExtension")]
        public IWebElement CurrentPagerExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_btnDeletePhoneEntry")]
        public IWebElement RemoveForwardingPhoneNO { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_PhoneType")]
        public IWebElement ForwardingPhoneType { get; set; }
        //
        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_1_PhoneType")]
        public IWebElement ForwardingPhoneType1 { get; set; }
        //btnSpouse1AKA
        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_2_PhoneType")]
        public IWebElement ForwardingPhoneType2 { get; set; }
        //
        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_3_PhoneType")]
        public IWebElement ForwardingPhoneType3 { get; set; }
        //
        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_4_PhoneType")]
        public IWebElement ForwardingPhoneType4 { get; set; }
        //
        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_5_PhoneType")]
        public IWebElement ForwardingPhoneType5 { get; set; }
        //
        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_6_PhoneType")]
        public IWebElement ForwardingPhoneType6 { get; set; }


        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_txtNumber")]
        public IWebElement ForwardingPhoneNum { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_txtExtension")]
        public IWebElement ForwardingExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_txtComments")]
        public IWebElement ForwardingComments { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_GridPhoneTypes")]
        public IWebElement CurrentPhonesTable { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_GridPhoneTypes")]
        public IWebElement ForwardingPhonesTable { get; set; }

        #region Husband Wife
        //Husband and Wife
        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtFirstNameI")]
        public IWebElement Husband1FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtMiddleNameI")]
        public IWebElement Husband1MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtLastNameI")]
        public IWebElement HusbandLastName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtLastNameI")]
        public IWebElement Husband2LastName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtSuffixI")]
        public IWebElement Husband1suffix { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_txtFirstNameI")]
        public IWebElement HusbandSpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_txtMiddleNameI")]
        public IWebElement HusbandSpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_txtLastNameI")]
        public IWebElement HusbandSpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_txtSuffixI")]
        public IWebElement HusbandSpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtSSNI")]
        public IWebElement HusbandSpous1SSN { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_txtSSNI")]
        public IWebElement HusbandSpouse2SSN { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_cBntExp1")]
        public IWebElement HusbandAuthorizeddrop { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_txtTrusteeName")]
        public IWebElement HusbandAuthorizedSignatureName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_cboTrusteeType")]
        public IWebElement Husbandspouse1TrusteeType { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_FAFCBSpouseLoanApplicantFlag")]
        public IWebElement Spouse1LoanApplicant { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_FAFCBSpouseLoanApplicantFlag")]
        public IWebElement Spouse2LoanApplicant { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_btnViewEditSSNTIN")]
        public IWebElement btnHusSpos1SsnVieEdt { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_btnViewEditSSNTIN")]
        public IWebElement btnHusSpos2SsnVieEdt { get; set; }


        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_btnApply")]
        public IWebElement HusbandApply { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_cBntExp1")]
        public IWebElement AuthorizedSignatureHusSpouse2Drop { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_txtTrusteeName")]
        public IWebElement Husbandspouse2TrusteeName { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_cboTrusteeType")]
        public IWebElement Husbandspouse2TrusteeType { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_btnApply")]
        public IWebElement HusbandSpouse2Apply { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_gridAuthSignatures_gridAuthSignatures")]
        public IWebElement HusSps1AuthSignTable { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_gridAuthSignatures_gridAuthSignatures")]
        public IWebElement HusSps2AuthSignTable { get; set; }


        #endregion

        [FindsBy(How = How.Id, Using = "_ctl0_txtEntityName")]
        public IWebElement BusinessEntityName { get; set; }

        #region Trustee
        [FindsBy(How = How.Id, Using = "TrustAscx_txtShortNameT")]
        public IWebElement TrusteeShortName { get; set; }

        [FindsBy(How = How.Id, Using = "FAFCBLoanApplicant")]
        public IWebElement TrusteeLoanApplicant { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtDated")]
        public IWebElement TrustDated { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtNumber")]
        public IWebElement TrustNumber { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_RadSSN")]
        public IWebElement TrustSSN { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_RadTIN")]
        public IWebElement TrustTIN { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtLastName1099s")]
        public IWebElement TrustLastNameFor1099SReporting { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_btnNew")]
        public IWebElement TrustNew { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtTrusteeName")]
        public IWebElement TrustAuthorizedName { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_btnApply")]
        public IWebElement TrustApply { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtTaxIDNum")]
        public IWebElement TrustSSNtext { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_cboTrusteeType")]
        public IWebElement TrustAuthorizedType { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtTrusteeTitle")]
        public IWebElement TrustTitle { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtTrust")]
        public IWebElement TrusteeName { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_gridAuthSignatures_gridAuthSignatures")]
        public IWebElement TrustAuthSignTabl { get; set; }


        #endregion

        [FindsBy(How = How.Id, Using = "TrustAscx_txtTrust")]
        public IWebElement Buyer1099s { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_cboGeoInc2")]
        public IWebElement StateofIncorp { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_cboEntitytype2")]
        public IWebElement EntityType { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_txtTaxPayerId")]
        public IWebElement BusinessEntitySSN { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_RadSSN")]
        public IWebElement BusinessEntySsnRadButtn { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_RadTIN")]
        public IWebElement BusinessEntyTinRadButtn { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_btnViewEditSSNTIN")]
        public IWebElement BusinessEntityViewEdit { get; set; }

        [FindsBy(How = How.Id, Using = "btnSignatures")]
        public IWebElement Signatures { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_cbo1099sClassification")]
        public IWebElement Buyer1099sClassification { get; set; }

        //Previously commented
        /////////////////////
        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtNumber")]
        public IWebElement CurrentPhoneOneTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtExtension")]
        public IWebElement CurrentPhoneOneExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_1_txtNumber")]
        public IWebElement CurrentPhoneTwoTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_1_txtExtension")]
        public IWebElement CurrentPhoneTwoExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_2_txtNumber")]
        public IWebElement CurrentPhoneThreeTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_2_txtExtension")]
        public IWebElement CurrentPhoneThreeExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_3_txtNumber")]
        public IWebElement CurrentPhoneFourTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_3_txtExtension")]
        public IWebElement CurrentPhoneFourExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_4_txtNumber")]
        public IWebElement CurrentPhoneFiveTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_4_txtExtension")]
        public IWebElement CurrentPhoneFiveExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_5_txtNumber")]
        public IWebElement CurrentPhoneSixTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_5_txtExtension")]
        public IWebElement CurrentPhoneSixExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_txtNumber")]
        public IWebElement CurrentPhoneSevenTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_txtExtension")]
        public IWebElement CurrentPhoneSevenExtnTxt { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_7_txtNumber")]
        public IWebElement CurrentPhoneEightTxt { get; set; }


        //Previously commented
        /////////////////////


        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_1_PhoneType")]
        public IWebElement CurrentPhoneType2 { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_cbo1099sClassification")]
        public IWebElement TrustSSNtype { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_cbo1099sClassification")]
        public IWebElement BusinessSSNType { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_cbo1099sClassification")]
        public IWebElement HusbandwifeSSNType { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse1_cbo1099sClassification")]
        public IWebElement HusbandSpouse1099sClassification1 { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_cbo1099sClassification")]
        public IWebElement HusbandSpouse1099sClassification2 { get; set; }

        [FindsBy(How = How.Id, Using = "HusbandAndWifePage_Spouse2_cbo1099sClassification")]
        public IWebElement HusbandwifeSSNType2 { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_txtNumber")]
        public IWebElement CurrentPhoneNumber6 { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_7_txtNumber")]
        public IWebElement CurrentPhoneNumber7 { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_PhoneType")]
        public IWebElement CurrentPhoneType6 { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement BuyerSellerError { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_chkNotification")]
        public IWebElement EmailNotification { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0$comboAttention")]
        public IWebElement BusComboAttention { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_chkEdit")]
        public IWebElement BusEditName { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_txtAttentionName")]
        public IWebElement BusAttentionName { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_chkEditAttentionContactInfo")]
        public IWebElement BusContactEdit { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_textContactBusPhone")]
        public IWebElement BusContactBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_txtContactExtnPhone")]
        public IWebElement BusContactExtnPhone { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_textContactBusFax")]
        public IWebElement BusContactBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_textContactCellPhone")]
        public IWebElement BusContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_textContactPager")]
        public IWebElement BusContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_textContactEmailAddress")]
        public IWebElement BusContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_chkContactWeeklyEmailStatus")]
        public IWebElement BusContactWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_comboAttention")]
        public IWebElement TrustComboAttention { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_chkEdit")]
        public IWebElement TrustEditName { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_txtAttentionName")]
        public IWebElement TrustAttentionName { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_chkEditAttentionContactInfo")]
        public IWebElement TrustContactEdit { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_textContactBusPhone")]
        public IWebElement TrustContactBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_txtContactExtnPhone")]
        public IWebElement TrustContactExtnPhone { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_textContactBusFax")]
        public IWebElement TrustContactBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_textContactCellPhone")]
        public IWebElement TrustContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_textContactPager")]
        public IWebElement TrustContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_textContactEmailAddress")]
        public IWebElement TrustContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "TrustAscx_ctrlAttentionContact_chkContactWeeklyEmailStatus")]
        public IWebElement TrustContactWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "IndividualControl_FAFCBSpouseLoanApplicantFlag")]
        public IWebElement LoanApplicant { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtNumber")]
        public IWebElement CurrentHome { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtExtension")]
        public IWebElement CurrentHomeExtn { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_0_txtComments")]
        public IWebElement CurrentHomeComments { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_1_txtNumber")]
        public IWebElement CurrentBus { get; set; }


        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_1_txtComments")]
        public IWebElement CurrentBusComments { get; set; }


        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_2_txtComments")]
        public IWebElement CurrentPagerComments { get; set; }


        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_3_txtComments")]
        public IWebElement CurrentCellularComments { get; set; }

        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_4_txtComments")]
        public IWebElement CurrentBusFaxComments { get; set; }



        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_5_txtComments")]
        public IWebElement CurrentHomeFaxComments { get; set; }


        [FindsBy(How = How.Id, Using = "CurrentPhones_GridPhoneTypes_6_txtComments")]
        public IWebElement CurrentEmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_txtNumber")]
        public IWebElement ForwardHome { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_txtExtension")]
        public IWebElement ForwardHomeExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_0_txtComments")]
        public IWebElement ForwardHomeComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_1_txtNumber")]
        public IWebElement ForwardBus { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_1_txtExtension")]
        public IWebElement ForwardBusExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_1_txtComments")]
        public IWebElement ForwardBusComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_2_txtNumber")]
        public IWebElement ForwardPager { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_2_txtExtension")]
        public IWebElement ForwardPagerExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_2_txtComments")]
        public IWebElement ForwardPagerComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_3_txtNumber")]
        public IWebElement ForwardCellular { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_3_txtExtension")]
        public IWebElement ForwardCellularExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_3_txtComments")]
        public IWebElement ForwardCellularComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_4_txtNumber")]
        public IWebElement ForwardBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_4_txtExtension")]
        public IWebElement ForwardBusFaxExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_4_txtComments")]
        public IWebElement ForwardBusFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_5_txtNumber")]
        public IWebElement ForwardHomeFax { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_5_txtExtension")]
        public IWebElement ForwardHomeFaxExtn { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_5_txtComments")]
        public IWebElement ForwardHomeFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_6_txtNumber")]
        public IWebElement ForwardEmail { get; set; }

        [FindsBy(How = How.Id, Using = "ForwardingPhones_GridPhoneTypes_6_txtComments")]
        public IWebElement ForwardEmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "btnViewSignature")]
        public IWebElement ViewEditSignature { get; set; }

        [FindsBy(How = How.Id, Using = "_ctl0_ctrlAttentionContact_labelContactName")]
        public IWebElement ContactName { get; set; }

        #endregion

        public BuyerSellerSetup Open(bool isBuyer = true)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>" + (isBuyer ? "Buyers" : "Sellers"));
            this.WaitForScreenToLoad();

            return this;
        }

        #region Services
        public void Expand(IWebElement icon)
        {
            if (icon.GetAttribute("class").Contains("cButtonExpandFalse"))
            {
                icon.FAClick();
                Playback.Wait(1000);
            }
        }

        public void SelctPhonListEntrVal(string HoPhLstVal, string HoTxtWrongVal, string ErrVal, string HoTxtCorrctVal, string PhValInFormat)
        {

            this.CurrentPhoneType.FASelectItemBySendingKeys(HoPhLstVal);
            Playback.Wait(1500);
            this.CurrentPhoneNumber.FASetText(HoTxtWrongVal + FAKeys.Tab);
            Playback.Wait(1500);
            Support.AreEqual(ErrVal, FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FAGetValue());
            this.CurrentPhoneNumber.FASetText(HoTxtCorrctVal + FAKeys.Tab);
            Playback.Wait(1500);
            Support.AreEqual(PhValInFormat, FastDriver.BuyerSellerSetup.CurrentPhoneNumber.FAGetValue());
            if (!((HoPhLstVal.Equals("E-Mail") || HoPhLstVal.Equals("CF Notification"))))
            {
                this.CurrentExtension.FASetText(HoTxtCorrctVal + FAKeys.Tab);
                Playback.Wait(1500);
                Support.AreEqual(HoTxtCorrctVal, FastDriver.BuyerSellerSetup.CurrentExtension.FAGetValue());
            }

        }

        public string IsRadButtnSelectd(string ElemName)
        {
            switch (ElemName)
            {
                case "CurrentSetToProperty":
                    return this.CurrentSetToProperty.IsSelected().ToString();

                case "ForwardngSetToProperty":
                    return this.ForwardngSetToProperty.IsSelected().ToString();

                case "ForwardingSetToOther":
                    return this.ForwardingSetToOther.IsSelected().ToString();

            }
            return "";

        }

        public BuyerSellerSetup SetCurrPhones(BuyerParameters buyr)
        {
            this.CurrentPhoneNumber.FASetText(buyr.CurrentPhoneNumber);
            this.CurrentBus.FASetText(buyr.CurrentPhoneTwo);
            this.CurrentPhoneThreeTxt.FASetText(buyr.CurrentPhoneThree);
            this.CurrentPhoneFourTxt.FASetText(buyr.CurrentPhoneFour);
            this.CurrentPhoneFiveTxt.FASetText(buyr.CurrentPhoneFive);
            this.CurrentPhoneSixTxt.FASetText(buyr.CurrentPhoneSix);
            this.CurrentPhoneSevenTxt.FASetText(buyr.CurrentPhoneSeven + FAKeys.Tab);

            return this;
        }

        public BuyerSellerSetup SetCurrPhonesExtns(BuyerParameters buyr)
        {
            this.WaitForScreenToLoad();
            this.CurrentExtension.FASetText(buyr.CurrentPhExtn);
            if (buyr.CurrentPhTwoExtn.ToLower().Equals("true"))
            {
                this.EmailNotification.FASetCheckbox(true);
            }
            else
            {
                this.CurrentPhoneTwoExtnTxt.FASetText(buyr.CurrentPhTwoExtn);
            }
            IWebElement EmailNotificationBusinessEntity = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "CurrentPhones_GridPhoneTypes_2_chkNotification");
            if (buyr.CurrentPhThreeExtn.ToLower().Equals("true"))
            {
                EmailNotificationBusinessEntity.FASetCheckbox(true);
            }
            else if (buyr.CurrentPhThreeExtn.ToLower().Equals("false"))
                EmailNotificationBusinessEntity.FASetCheckbox(false);

            else
                this.CurrentPhoneThreeExtnTxt.FASetText(buyr.CurrentPhThreeExtn);
            this.CurrentPhoneFourExtnTxt.FASetText(buyr.CurrentPhFourExtn);
            this.CurrentPhoneFiveExtnTxt.FASetText(buyr.CurrentPhFiveExtn);
            this.CurrentPhoneSixExtnTxt.FASetText(buyr.CurrentPhSixExtn);
            if (buyr.CurrentPhSevenExtn.ToLower().Equals("true"))
            {
                if (!this.EmailNotification.IsSelected())
                    this.EmailNotification.FASetCheckbox(true);
            }
            else
                this.CurrentPhoneSevenExtnTxt.FASetText(buyr.CurrentPhSevenExtn);
            return this;
        }

        public void ClearBusEntyShortName()
        {
            Report.UpdateLog(this.BusinessEntityShortname, "Clear Text", " Text", "", () =>
            {
                BusinessEntityShortname.Click();
                BusinessEntityShortname.Clear();
                BusinessEntityShortname.SendKeys(FAKeys.Tab);
            });
        }

        public void ClearTrusteeShortNam()
        {
            Report.UpdateLog(this.BusinessEntityShortname, "Clear Text", " Text", "", () =>
            {
                TrusteeShortName.Click();
                TrusteeShortName.Clear();
                TrusteeShortName.SendKeys(FAKeys.Tab);
            });
        }

        /// <summary>
        /// This Service clicks Trustree Tin Radio button.
        /// </summary>
        public BuyerSellerSetup Trust_Tin()
        {
            TrustTIN.FAClick();
            Playback.Wait(2000);
            return this;
        }

        /// <summary>
        /// This Service clicks Trustree Tin Radio button.
        /// </summary>
        public BuyerSellerSetup Trust_Ssn()
        {
            TrustSSN.FAClick();
            Playback.Wait(2000);
            return this;
        }

        public BuyerSellerSetup TrustSsn_TabOut()
        {
            TrustSSNtext.Click();
            TrustSSNtext.SendKeys(FAKeys.Tab);
            Playback.Wait(1000);
            return this;
        }

        public BuyerSellerSetup BusEntyShrtNam_TabOut()
        {
            BusinessEntityShortname.Click();
            BusinessEntityShortname.SendKeys(FAKeys.Tab);
            Playback.Wait(1000);
            return this;
        }

        public BuyerSellerSetup BusEntySsn_TabOut()
        {
            BusinessEntitySSN.Click();
            BusinessEntitySSN.SendKeys(FAKeys.Tab);
            Playback.Wait(1000);
            return this;
        }

        public BuyerSellerSetup TrusteeShortName_TabOut()
        {
            TrusteeShortName.Click();
            TrusteeShortName.SendKeys(FAKeys.Tab);
            Playback.Wait(1000);
            return this;
        }

        /// <summary>
        /// This Service clicks Trustree Auth Signature New  button.
        /// </summary>
        public BuyerSellerSetup Trust_AuthSignNew()
        {
            this.TrustNew.FAClick();
            Playback.Wait(2000);
            return this;
        }

        public Dictionary<string, string> GetBusEntByrDtls
        {
            get
            {
                this.WaitForScreenToLoad();
                Dictionary<string, string> ByrDetails = new Dictionary<string, string>();
                ByrDetails.Add("BusinessEntityShortname", this.BusinessEntityShortname.FAGetValue());
                ByrDetails.Add("StateofIncorp", this.StateofIncorp.FAGetSelectedItem());
                ByrDetails.Add("EntityType", this.EntityType.FAGetSelectedItem());
                this.BusinessEntityViewEdit.FAClick();
                Playback.Wait(2000);
                ByrDetails.Add("BusinessEntitySSN", this.BusinessEntitySSN.FAGetValue());
                if (this.TrusteeLoanApplicant.Exists())
                    ByrDetails.Add("LoanApplicant", this.TrusteeLoanApplicant.FAGetAttribute("status"));
                return ByrDetails;
            }
        }

        /// <summary>
        /// This Service clicks Bus Entity SSn radio button.
        /// </summary>
        public BuyerSellerSetup BusEnty_Ssn()
        {
            this.BusinessEntySsnRadButtn.FAClick();
            Playback.Wait(2000);
            return this;
        }

        /// <summary>
        /// This Service clicks Bus Entity SSn radio button.
        /// </summary>
        public BuyerSellerSetup BusEnty_Tin()
        {
            this.BusinessEntyTinRadButtn.FAClick();
            Playback.Wait(2000);
            return this;
        }

        public Dictionary<string, string> GetTrstestByrDtls(bool RetrievAuthSigns = true)
        {
            Dictionary<string, string> ByrDetails = new Dictionary<string, string>();
            ByrDetails.Add("BuyerTypes", this.RetrieveBuyerType());
            ByrDetails.Add("TrusteeName", this.TrusteeName.FAGetValue().Trim());
            ByrDetails.Add("TrusteeShortName", this.TrusteeShortName.FAGetValue().Trim());
            ByrDetails.Add("TrustDated", this.TrustDated.FAGetValue().Trim());
            ByrDetails.Add("TrustNumber", this.TrustNumber.FAGetValue().Trim());
            if (this.TrusteeLoanApplicant.Exists())
                ByrDetails.Add("LoanApplicant", this.TrusteeLoanApplicant.FAGetAttribute("status"));
            if (RetrievAuthSigns)
            {
                ByrDetails.Add("TrustAuthorizedName", this.GetTrustAuthSigTablData(1, 1));
                ByrDetails.Add("TrustAuthorizedType", this.GetTrustAuthSigTablData(1, 2));
                ByrDetails.Add("TrustTitle", this.GetTrustAuthSigTablData(1, 3));
            }
            ByrDetails.Add("Tin", this.TrustSSN.FAGetValue().Trim());
            ByrDetails.Add("Ssn", this.TrustTIN.FAGetValue().Trim());
            this.Trust_Ssn_ViewEdit();
            Playback.Wait(3000);
            ByrDetails.Add("TrustSSNtext", this.TrustSSNtext.FAGetValue().Trim());
            return ByrDetails;

        }

        public string GetTrustAuthSigTablData(int rowindex, int columnindex)
        {
            OperationResult opresult = TrustAuthSignTabl.PerformTableAction(rowindex, columnindex, TableAction.GetText);
            return opresult.Message;
        }

        /// <summary>
        /// This Service clicks Husband Authorized dropdown.
        /// </summary>
        public BuyerSellerSetup Husband_Authzdrop()
        {
            try
            {
                if (HusbandAuthorizeddrop.IsVisible())
                {
                    HusbandAuthorizeddrop.FAClick();
                    Playback.Wait(3000);
                    return this;
                }
                return this;
            }
            catch (Exception)
            {
                return this;
            }
        }

        /// <summary>
        /// This Service clicks Husband Authorized dropdown.
        /// </summary>
        public BuyerSellerSetup HusbSpouse2_Autzdrop()
        {
            try
            {
                if (AuthorizedSignatureHusSpouse2Drop.IsVisible())
                {
                    AuthorizedSignatureHusSpouse2Drop.FAClick();
                    Playback.Wait(5000);
                    return this;
                }
                return this;
            }
            catch (Exception)
            {
                return this;
            }
        }

        public Dictionary<string, string> GetIndivByrDtls
        {
            get
            {
                Dictionary<string, string> ByrDetails = new Dictionary<string, string>();
                ByrDetails.Add("BuyerType", this.BuyerTypes.FAGetSelectedItem().Trim());
                ByrDetails.Add("Indi First Name", this.IndividualFirstName.FAGetValue().Trim());
                ByrDetails.Add("Indi Middle Name", this.IndividualMiddleName.FAGetValue().Trim());
                ByrDetails.Add("Indi Last Name", this.IndividualLastName.FAGetValue().Trim());
                ByrDetails.Add("Indi Sufix", this.IndividualSuffix.FAGetValue().Trim());
                this.btnViewEdit.FAClick();
                ByrDetails.Add("Indi Ssn", this.txtSSN.FAGetValue().Trim());
                if (this.LoanApplicant.Exists())
                    ByrDetails.Add("LoanApplicant", this.LoanApplicant.FAGetAttribute("status"));

                return ByrDetails;
            }
        }

        ///<summary>
        ///Constructs Husband and Wife buyers details as a single string.
        ///<!summary>
        public string[] FormtHusWfDtlsAsStr()
        {
            string[] AllDetails = new string[2];

            string hSellerFirstName = this.Husband1FirstName.FAGetValue().Trim();
            string wSellerFirstName = this.HusbandSpouseFirstName.FAGetValue().Trim();
            string wSellerMiddleName = this.HusbandSpouseMiddleName.FAGetValue().Trim();
            string HusLastName = this.Husband2LastName.FAGetValue().Trim();
            string hSeller = hSellerFirstName + " " + HusLastName;
            string wSeller = wSellerFirstName + " " + wSellerMiddleName + " " + HusLastName;

            //
            string hwsuffix = this.HusbandSpouseSuffix.FAGetValue().Trim();
            string hwMaritalStatus = this.MaritalStatus.FAGetSelectedItem().Trim();
            string hwNameRelation = hSeller + " and " + wSeller + ", " + hwsuffix + ", " + hwMaritalStatus;
            AllDetails[0] = hwNameRelation;

            string hwvesting = this.Vesting.FAGetSelectedItem().Trim();
            string hwAdditionalVesting = this.AdditionalVesting.FAGetValue().Trim();
            string hwCompleteVesting = hSeller + " and " + wSeller + ", " + hwsuffix + ", " + hwMaritalStatus;
            string CompleteVesting = hwCompleteVesting + " " + hwvesting + ", " + hwAdditionalVesting;
            AllDetails[1] = CompleteVesting;
            return AllDetails;
        }

        public string RetrieveBuyerType()
        {
            return this.BuyerTypes.FAGetSelectedItem();
        }

        public Dictionary<string, string> GetHusWfDtlsAuthSign(bool GetAuthSignDtls = true)
        {
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            AllDetails.Add("BuyerType", this.BuyerTypes.FAGetSelectedItem());
            AllDetails.Add("Husband1FirstName", this.Husband1FirstName.FAGetValue().Trim());
            AllDetails.Add("Husband2LastName", this.Husband2LastName.FAGetValue().Trim());
            AllDetails.Add("HusbandSpouseFirstName", this.HusbandSpouseFirstName.FAGetValue().Trim());
            AllDetails.Add("HusbandSpouseMiddleName", this.HusbandSpouseMiddleName.FAGetValue().Trim());
            AllDetails.Add("HusbandSpouseLastName", this.HusbandSpouseLastName.FAGetValue().Trim());
            AllDetails.Add("HusbandSpouseSuffix", this.HusbandSpouseSuffix.FAGetValue().Trim());
            if (this.Spouse1LoanApplicant.Exists())
            {
                AllDetails.Add("HusbandLoanApplicant", this.Spouse1LoanApplicant.FAGetAttribute("status"));
                AllDetails.Add("SpouseLoanApplicant", this.Spouse2LoanApplicant.FAGetAttribute("status"));
            }
            //HusbandSpouseSSN
            if (this.btnHusSpos1SsnVieEdt.Enabled)
            {
                this.btnHusSpos1SsnVieEdt.FAClick();
                Playback.Wait(3000);
            }
            AllDetails.Add("HusbandSpous1SSN", this.HusbandSpous1SSN.FAGetValue().Trim());

            if (this.btnHusSpos2SsnVieEdt.Enabled)
            {
                this.btnHusSpos2SsnVieEdt.FAClick();
                Playback.Wait(3000);
            }
            AllDetails.Add("HusbandSpouse2SSN", this.HusbandSpouse2SSN.FAGetValue().Trim());

            //Authorized section husband
            if (GetAuthSignDtls)
            {
                if (this.HusbandAuthorizeddrop.IsVisible())
                {
                    this.HusbandAuthorizeddrop.FAClick();
                    Playback.Wait(3000);
                }
                AllDetails.Add("Hus Authz Sign Name", GetHusTableData(1, 1).Trim());
                AllDetails.Add("HusbSpouse 1 Truste Type", GetHusTableData(1, 2).Trim());
                AllDetails.Add("HusbSpouse 2 AuthSign Nam", this.GetWifTableData(1, 1).Trim());
                AllDetails.Add("HusbSpouse 2 AuthSign Type", this.GetWifTableData(1, 2).Trim());
            }
            return AllDetails;

        }

        public string GetHusTableData(int rowindex, int columnindex)
        {
            OperationResult opresult = HusSps1AuthSignTable.PerformTableAction(rowindex, columnindex, TableAction.GetText);
            return opresult.Message;
        }

        public string GetWifTableData(int rowindex, int columnindex)
        {
            OperationResult opresult = HusSps2AuthSignTable.PerformTableAction(rowindex, columnindex, TableAction.GetText);
            return opresult.Message;
        }

        public Dictionary<string, string> GetIndiviVestgNdSalutio
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Marital Status", MaritalStatus.FAGetSelectedItem());
                AllDetails.Add("Vesting", Vesting.FAGetSelectedItem());
                AllDetails.Add("Addl Vesting", AdditionalVesting.FAGetValue());
                AllDetails.Add("Salutation", Salutation.FAGetValue().Trim());
                AllDetails.Add("Misc Ref 1", MiscRef1.FAGetValue().Trim());
                AllDetails.Add("Misc Ref 2", MiscRef2.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetTrustEstVestSalut
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Salutation", this.Salutation.FAGetValue().Trim());
                AllDetails.Add("Misc Ref 1", this.MiscRef1.FAGetValue().Trim());
                AllDetails.Add("Misc Ref 2", this.MiscRef2.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetCurrAddrDtls
        {
            get
            {
                FastDriver.BuyerSellerSetup.WaitCreation(this.CurrentStreet1);
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Curr Addr Street 1", CurrentStreet1.FAGetValue().Trim());
                AllDetails.Add("Curr Addr Street 2", CurrentStreet2.FAGetValue().Trim());
                AllDetails.Add("Curr Addr Street 3", CurrentStreet3.FAGetValue().Trim());
                AllDetails.Add("Curr Addr Street 4", CurrentStreet4.FAGetValue().Trim());
                AllDetails.Add("Curr Addr City", CurrentCity.FAGetValue().Trim());
                AllDetails.Add("Curr Addr State", CurrentState.FAGetValue().Trim());
                AllDetails.Add("Curr Addr County", CurrentCounty.FAGetValue().Trim());
                AllDetails.Add("Curr Addr Country", CurrentCountry.FAGetValue().Trim());
                AllDetails.Add("Curr Addr Zip", CurrentZip.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetCurAddrEnabld
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Curr Addr Street 1", this.CurrentStreet1.IsEnabled().ToString());
                AllDetails.Add("Curr Addr Street 2", this.CurrentStreet2.IsEnabled().ToString());
                AllDetails.Add("Curr Addr Street 3", this.CurrentStreet3.IsEnabled().ToString());
                AllDetails.Add("Curr Addr Street 4", this.CurrentStreet4.IsEnabled().ToString());
                AllDetails.Add("Curr Addr City", CurrentCity.IsEnabled().ToString());
                AllDetails.Add("Curr Addr State", CurrentState.IsEnabled().ToString());
                AllDetails.Add("Curr Addr County", CurrentCounty.IsEnabled().ToString());
                AllDetails.Add("Curr Addr Country", CurrentCountry.IsEnabled().ToString());
                AllDetails.Add("Curr Addr Zip", CurrentZip.IsEnabled().ToString());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetForwdAdrDtls
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Forward Addr Street 1", ForwardingStreet1.FAGetValue().Trim());
                AllDetails.Add("Forward Addr Street 2", ForwardingStreet2.FAGetValue().Trim());
                AllDetails.Add("Forward Addr Street 3", ForwardingStreet3.FAGetValue().Trim());
                AllDetails.Add("Forward Addr Street 4", ForwardingStreet4.FAGetValue().Trim());
                AllDetails.Add("Forward Addr City", ForwardingCity.FAGetValue().Trim());
                AllDetails.Add("Forward Addr State", ForwardingState.FAGetValue().Trim());
                AllDetails.Add("Forward Addr Country", ForwardingCountry.FAGetValue().Trim());
                AllDetails.Add("Forward Addr County", ForwardingCounty.FAGetValue().Trim());
                AllDetails.Add("Forward Addr Zip", ForwardingZip.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetForwdAddrEnabld
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Forward Addr SetToProperty", ForwardngSetToProperty.IsEnabled().ToString());
                AllDetails.Add("Forward Addr SetToCurrent", ForwardingSetToCurrent.IsEnabled().ToString());
                AllDetails.Add("Forward Addr SetToOther", ForwardingSetToOther.IsEnabled().ToString());
                AllDetails.Add("Forward Addr Street 1", this.ForwardingStreet1.IsEnabled().ToString());
                AllDetails.Add("Forward Addr Street 2", this.ForwardingStreet2.IsEnabled().ToString());
                AllDetails.Add("Forward Addr Street 3", this.ForwardingStreet3.IsEnabled().ToString());
                AllDetails.Add("Forward Addr Street 4", this.ForwardingStreet4.IsEnabled().ToString());
                AllDetails.Add("Forward Addr City", ForwardingCity.IsEnabled().ToString());
                AllDetails.Add("Forward Addr State", ForwardingState.IsEnabled().ToString());
                AllDetails.Add("Forward Addr County", ForwardingCounty.IsEnabled().ToString());
                AllDetails.Add("Forward Addr Country", ForwardingCountry.IsEnabled().ToString());
                AllDetails.Add("Forward Addr Zip", ForwardingZip.IsEnabled().ToString());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetCurrPhDtls()
        {
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            AllDetails.Add("CurrentPhoneNum", this.CurrentPhoneOneTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentHomePhoneNumExtn", this.CurrentPhoneOneExtnTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneTwo", this.CurrentPhoneTwoTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneTwoExtn", this.CurrentPhoneTwoExtnTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneThree", this.CurrentPhoneThreeTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneThreeExtn", this.CurrentPhoneThreeExtnTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneFour", this.CurrentPhoneFourTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneFourExtn", this.CurrentPhoneFourExtnTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneFive", this.CurrentPhoneFiveTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneFiveExtn", this.CurrentPhoneFiveExtnTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneSix", this.CurrentPhoneSixTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneSixExtn", this.CurrentPhoneSixExtnTxt.FAGetValue().Trim());
            AllDetails.Add("CurrentPhoneSeven", this.CurrentPhoneSevenTxt.FAGetValue().Trim());
            return AllDetails;

        }
        //
        public Dictionary<string, string[]> GetCurrentPhoneDetails()
        {
            this.WaitForScreenToLoad();
            Dictionary<string, string[]> PhoneDetails = new Dictionary<string, string[]>();
            PhoneDetails.Add(this.CurrentPhoneType.FAGetSelectedItem(), new[] { this.CurrentPhoneOneTxt.FAGetValue().Trim(), this.CurrentPhoneOneExtnTxt.FAGetValue().Trim() });
            PhoneDetails.Add(this.CurrentPhoneType1.FAGetSelectedItem(), new[] { this.CurrentPhoneTwoTxt.FAGetValue().Trim(), this.CurrentPhoneTwoExtnTxt.FAGetValue().Trim() });
            PhoneDetails.Add(this.CurrentPhoneType2PagrOrEmail.FAGetSelectedItem(), new[] { this.CurrentPhoneThreeTxt.FAGetValue().Trim(), "" });
            PhoneDetails.Add(this.CurrentPhoneType3Cellular.FAGetSelectedItem(), new[] { this.CurrentPhoneFourTxt.FAGetValue().Trim(), this.CurrentPhoneFourExtnTxt.FAGetValue().Trim() });
            PhoneDetails.Add(this.CurrentPhoneType4BusFaxOrPager.FAGetSelectedItem(), new[] { this.CurrentPhoneFiveTxt.FAGetValue().Trim(), this.CurrentPhoneFiveExtnTxt.FAGetValue().Trim() });
            PhoneDetails.Add(this.CurrentPhoneType5HomeFaxOrHomePhon.FAGetSelectedItem(), new[] { this.CurrentPhoneSixTxt.FAGetValue().Trim(), this.CurrentPhoneSixExtnTxt.FAGetValue().Trim() });
            PhoneDetails.Add(this.CurrentPhoneType6.FAGetSelectedItem(), new[] { this.CurrentPhoneSevenTxt.FAGetValue().Trim(), this.CurrentPhoneSevenExtnTxt.Exists() ? this.CurrentPhoneSevenExtnTxt.FAGetValue().Trim():"" });
            
            return PhoneDetails;
        }
        //
        public Dictionary<string, string[]> GetForwardingPhoneDetails()
        {
            Dictionary<string, string[]> PhoneDetails = new Dictionary<string, string[]>();
            PhoneDetails.Add(this.ForwardingPhoneType.FAGetSelectedItem(), new[] { this.ForwardBus.FAGetValue().Trim(), this.ForwardBusExtn.FAGetValue().Trim() });
            PhoneDetails.Add(this.ForwardingPhoneType1.FAGetSelectedItem(), new[] { this.ForwardBusFax.FAGetValue().Trim(), this.ForwardBusFaxExtn.FAGetValue().Trim() });
            PhoneDetails.Add(this.ForwardingPhoneType2.FAGetSelectedItem(), new[] { this.ForwardEmail.FAGetValue().Trim(), "" });
            PhoneDetails.Add(this.ForwardingPhoneType3.FAGetSelectedItem(), new[] { this.ForwardCellular.FAGetValue().Trim(), this.ForwardCellularExtn.FAGetValue().Trim() });
            PhoneDetails.Add(this.ForwardingPhoneType4.FAGetSelectedItem(), new[] { this.ForwardPager.FAGetValue().Trim(), this.ForwardPagerExtn.Exists() ? this.ForwardPagerExtn.FAGetValue().Trim():"" });
            PhoneDetails.Add(this.ForwardingPhoneType5.FAGetSelectedItem(), new[] { this.ForwardHome.FAGetValue().Trim(), this.ForwardHomeExtn.FAGetValue().Trim() });
            PhoneDetails.Add(this.ForwardingPhoneType6.FAGetSelectedItem(), new[] { this.ForwardHomeFax.FAGetValue().Trim(), this.ForwardHomeFaxExtn.Exists() ? this.ForwardHomeFaxExtn.FAGetValue().Trim():"" });
            
            return PhoneDetails;
        }

        public Dictionary<string, string> GetForwdPhDtls
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Forwarding PhoneNum", ForwardingPhoneNum.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public BuyerSellerSetup WaitForHusbandSpouseFirstNameToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(HusbandSpouseFirstName);
            return this;
        }

        public BuyerSellerSetup WaitForShortNameToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(TrusteeShortName);
            return this;
        }

        public BuyerSellerSetup WaitForBusinessEntityShortnameToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(BusinessEntityShortname);
            return this;
        }

        public BuyerSellerSetup WaitForScreenToLoad(IWebElement elem = null)
        {
            //Wait for the whole page to Load
            this.SwitchToContentFrame();
            this.WaitCreation(elem ?? BuyerTypes);
            //

            //this.SwitchToContentFrame();
            //if (elem == null)
            //    this.WaitCreation(cmdSearch);
            //else
            //    this.WaitCreation(elem);
            return this;
        }

        public BuyerSellerSetup CurrAddrSetToProp()
        {
            this.SwitchToContentFrame();
            CurrentSetToProperty.FAClick();
            Playback.Wait(4000);
            return this;
        }

        public BuyerSellerSetup CurrAddrSetToOthr()
        {
            this.SwitchToContentFrame();
            CurrentSetToOther.FAClick();
            Playback.Wait(4000);
            return this;
        }

        public BuyerSellerSetup ForwdAddrSetToPropty()
        {
            this.SwitchToContentFrame();
            ForwardngSetToProperty.FAClick();
            Playback.Wait(4000);
            return this;
        }

        public BuyerSellerSetup ForwdAddrSetToOthr()
        {
            this.SwitchToContentFrame();
            ForwardingSetToOther.FAClick();
            Playback.Wait(4000);
            return this;
        }

        public BuyerSellerSetup ForwdAddrSetToCurr()
        {
            this.SwitchToContentFrame();
            this.ForwardingSetToCurrent.FAClick();
            Playback.Wait(4000);
            return this;
        }

        public BuyerSellerSetup ViewEdit()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(btnViewEdit);
            btnViewEdit.FAClick();
            Playback.Wait(4000);
            return this;
        }

        public BuyerSellerSetup BuyerDetails(BuyerParameters buyer)
        {
            this.SwitchToContentFrame();
            // add more fields as we go?

            #region Individual Buyer Details
            if (buyer.BuyerType != null)
            {
                this.BuyerTypes.FASelectItemBySendingKeys(buyer.BuyerType);
                Playback.Wait(5000);
            }
            this.EmployedBy.FASelectItem(buyer.EmployedBy);
            this.IndividualFirstName.FASetText(buyer.First);
            this.IndividualMiddleName.FASetText(buyer.Middle);
            this.IndividualLastName.FASetText(buyer.Last);
            this.IndividualSuffix.FASetText(buyer.Suffix);
            if (buyer.SSN != null)
            {
                this.ViewEdit();
                this.txtSSN.FASetText(buyer.SSN);
            }

            //Authorized
            if (buyer.IndivdAuthorzdNam != null)
            {
                IndividualAuthorizeddrop.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(this.IndividualAuthorizedName);
                this.IndividualAuthorizedName.FASetText(buyer.IndivdAuthorzdNam);
                this.IndividualApply.FAClick();
                Playback.Wait(3000);
            }


            #endregion

            #region Trustree buyer
            this.TrusteeShortName.FASetText(buyer.TrusteeShortNameTwo);
            if (buyer.TrusteeShortNameTwo != null)
                this.TrustDated.FAClick(); //To trigger tabout
            this.TrustDated.FASetText(buyer.TrustDated);
            this.TrustNumber.FASetText(buyer.TrustNumber);

            if (buyer.TrustSsnText != null)
            {
                if (buyer.TrustTin == true)
                {
                    this.TrustTIN.FAClick();
                }
                else
                {
                    this.TrustSSN.FAClick();
                }
                this.Trust_Ssn_ViewEdit();
                Playback.Wait(3000);
                this.TrustSSNtext.FASetText(buyer.TrustSsnText);
            }

            if (buyer.TrustAuthorizedName != null)
            {
                this.TrustNew.FAClick();
                Playback.Wait(4000);
                this.TrustAuthorizedName.FASetText(buyer.TrustAuthorizedName);
                this.TrustAuthorizedType.FASelectItem(buyer.TrustAuthorizedType);
                this.TrustTitle.FASetText(buyer.TrustTitle);
                this.TrustApply.FAClick();
                Playback.Wait(4000);
            }
            #endregion

            #region Husband Wife
            //Hus Wife details
            this.Husband1FirstName.FASetText(buyer.Husband1FirstName);
            this.Husband2LastName.FASetText(buyer.Husband2LastName);
            this.Husband1MiddleName.FASetText(buyer.Husband1MiddleName);
            this.Husband1suffix.FASetText(buyer.HusbandSuffix);
            this.HusbandSpous1SSN.FASetText(buyer.HusbandSpouse1SSN);

            this.HusbandSpouseFirstName.FASetText(buyer.HusbandSpouseFirstName);
            this.HusbandSpouseMiddleName.FASetText(buyer.HusbandSpouseMiddleName);
            this.HusbandSpouseLastName.FASetText(buyer.HusbandSpouseLastName);
            this.HusbandSpouseSuffix.FASetText(buyer.HusbandSpouseSuffix);
            this.HusbandSpouse2SSN.FASetText(buyer.HusbandSpouse2SSN);

            //Hus Authorized
            if (buyer.HusbAuthzSigNam != null)
            {
                this.Husband_Authzdrop();
                Playback.Wait(3000);
                this.HusbandAuthorizedSignatureName.FASetText(buyer.HusbAuthzSigNam);
                this.Husbandspouse1TrusteeType.FASelectItem(buyer.HusbSpus1TrstType);
                this.HusbandApply.FAClick();
                Playback.Wait(3000);
            }

            if (buyer.HusSpous2TrusteNam != null)
            {
                this.Husbandspouse2TrusteeName.FASetText(buyer.HusSpous2TrusteNam);
                this.Husbandspouse2TrusteeType.FASelectItem(buyer.HusSpous2TrusteTyp);
                this.HusbandSpouse2Apply.FAClick();
                Playback.Wait(3000);
            }

            //Hus wife SSns
            if (buyer.HusbandSpouse1SSN != null)
            {
                this.btnHusSpos1SsnVieEdt.FAClick();
                Playback.Wait(3000);
                this.HusbandSpous1SSN.FASetText(buyer.HusbandSpouse1SSN);
            }

            if (buyer.HusbandSpouse2SSN != null)
            {
                this.btnHusSpos2SsnVieEdt.FAClick();
                Playback.Wait(3000);
                this.HusbandSpouse2SSN.FASetText(buyer.HusbandSpouse2SSN);
            }
            #endregion

            #region Business Entity
            this.BusinessEntityShortname.FASetText(buyer.BusinessEntityShortname);
            if (buyer.BusinessEntitySsn != null)
            {
                if (buyer.BusinessTin == true)
                {
                    this.BusinessEntyTinRadButtn.FAClick();
                }
                else
                {
                    this.BusinessEntySsnRadButtn.FAClick();
                }
                this.BusinessEntityViewEdit.FAClick();
                Playback.Wait(2000);
            }
            this.BusinessEntitySSN.FASetText(buyer.BusinessEntitySsn);
            this.StateofIncorp.FASelectItem(buyer.StateofIncorp);
            this.EntityType.FASelectItem(buyer.EntityType);
            #endregion

            // Vesting Information
            this.MaritalStatus.FASelectItem(buyer.MaritalStatus);
            this.Vesting.FASelectItem(buyer.Vesting);
            this.AdditionalVesting.FASetText(buyer.AdditionalVesting);

            // Salutation and miscellaneous Reference
            this.Salutation.FASetText(buyer.Salutation);
            this.MiscRef1.FASetText(buyer.MiscReference1);
            this.MiscRef2.FASetText(buyer.MiscReference2);

            // Current Address
            if (buyer.CurrentSetToOthr)
            {
                this.CurrentSetToOther.FAClick();
            }
            CurrentCountry.FASelectItemBySendingKeys(buyer.CurrentCountry);
            Thread.Sleep(3000);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad(this.CurrentStreet1);
            CurrentStreet1.FASetText(buyer.CurrentStreet1);
            CurrentStreet2.FASetText(buyer.CurrentStreet2);
            CurrentStreet3.FASetText(buyer.CurrentStreet3);
            CurrentCity.FASetText(buyer.CurrentCity);
            CurrentState.FASelectItem(buyer.CurrentState);
            CurrentZip.FASetText(buyer.CurrentZip);
            CurrentCountry.FASelectItemBySendingKeys(buyer.CurrentCountry);
            if (buyer.ForwardSetToOthr)
            {
                this.ForwardingSetToOther.FAClick();
            }

            //Forwarding Address
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            ForwardingStreet1.FASetText(buyer.ForwardStreet1);
            ForwardingStreet2.FASetText(buyer.ForwardStreet2);
            ForwardingStreet3.FASetText(buyer.ForwardStreet3);
            ForwardingCity.FASetText(buyer.ForwardCity);
            ForwardingCounty.FASetText(buyer.ForwardCounty);
            ForwardingState.FASelectItem(buyer.ForwardState);
            ForwardingZip.FASetText(buyer.ForwardZip);

            // Current Phones
            this.CurrentPhoneNumber.FASetText(buyer.CurrentPhoneNumber);

            // Forwarding Phones
            this.ForwardingPhoneNum.FASetText(buyer.ForwardingPhoneNum);

            //

            return this;
        }

        public void Trust_Ssn_ViewEdit()
        {
            this.btnViewEditSeller.FAClick();
            Playback.Wait(2000);
        }

        public string ChangeInstanceType(int DialgCount = 0, string InstanceType = "Individual", bool ShouldClickOk = true)
        {

            string Message = "";
            string MessageTwo = "";
            this.WaitCreation(BuyerTypes);
            this.BuyerTypes.FASelectItemBySendingKeys(InstanceType);
            Playback.Wait(2000);
            Message = FastDriver.WebDriver.HandleDialogMessage(true, ShouldClickOk, 10, true).Clean();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

            if (!ShouldClickOk)
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

            this.WaitForScreenToLoad();

            return Message;

            //if (!(FastDriver.WebDriver.WaitForAlertToExist(5)))
            //{ //wait for an alert to be present
            //    Playback.Wait(2000);
            //}
            //if (DialgCount == 1)
            //{
            //    Message = FastDriver.WebDriver.HandleDialogMessage(true, ShouldClickOk, 10);
            //    Playback.Wait(60000);                
            //    this.WaitForScreenToLoad();
            //    return Message;
            //}
            //if (DialgCount == 2)
            //{
            //    Message = FastDriver.WebDriver.HandleDialogMessage(false, ShouldClickOk);
            //    Playback.Wait(5000);
            //    MessageTwo = "#" + FastDriver.WebDriver.HandleDialogMessage(true, ShouldClickOk, 5);
            //    Playback.Wait(60000);
            //    this.WaitForScreenToLoad();
            //    return Message + MessageTwo;
            //}

            //else
            //{
            //    Playback.Wait(60000);
            //    this.WaitForScreenToLoad();
            //    return "";
            //}

        }

        public BuyerSellerSetup ClickButton(IWebElement button)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(button);
            button.FAClick();

            return this;
        }

        public BuyerSellerSetup AddtlInfo()
        {
            return ClickButton(this.btnAdditionalInfo);
        }

        public BuyerSellerSetup Search()
        {
            return ClickButton(this.cmdSearch);
        }

        public BuyerSellerSetup Exchange_Company()
        {
            return ClickButton(this.btnExchangeCompany);
        }

        public BuyerSellerSetup Full_Vesting()
        {
            return ClickButton(this.btnFullVesting);
        }

        public BuyerSellerSetup AKA()
        {
            return ClickButton(this.btnAKA);
        }

        public BuyerSellerSetup Spouse1_Aka()
        {
            return ClickButton(this.btnSpouse1AKA);
        }

        public BuyerSellerSetup New()
        {
            return ClickButton(this.btnNew);
        }

        public void SetIndividual(BuyerParameters individual)
        {
            this.IndividualFirstName.FASetText(individual.First, continueOnFailure: true);
            this.IndividualMiddleName.FASetText(individual.Middle, continueOnFailure: true);
            this.IndividualLastName.FASetText(individual.Last, continueOnFailure: true);
            this.txtSSN.FASetText(individual.SSN, continueOnFailure: true);
            this.CurrentSetToProperty.FASetCheckbox(individual.CurrentSetToProperty);
            Playback.Wait(5000); // Screen get reloaded
            this.WaitCreation(LoanApplicant);
            this.LoanApplicant.FASetCheckbox(individual.LoanApplicant);
        }

        public void SetHusbandAndWife(BuyerParameters spouses)
        {
            this.Husband1FirstName.FASetText(spouses.HusbandFirstName, continueOnFailure: true);
            this.HusbandLastName.FASetText(spouses.HusbandLastName, continueOnFailure: true);
            this.HusbandSpouseFirstName.FASetText(spouses.HusbandSpouseFirstName, continueOnFailure: true);
            this.HusbandSpouseLastName.FASetText(spouses.HusbandSpouseLastName, continueOnFailure: true);
            this.HusbandSpous1SSN.FASetText(spouses.HusbandSpouse1SSN, continueOnFailure: true);
            this.HusbandSpouse2SSN.FASetText(spouses.HusbandSpouse2SSN, continueOnFailure: true);
            this.CurrentSetToProperty.FASetCheckbox(spouses.CurrentSetToProperty);
            this.Spouse1LoanApplicant.FASetCheckbox(spouses.Spouse1LoanApplicant);
            this.Spouse2LoanApplicant.FASetCheckbox(spouses.Spouse2LoanApplicant);
        }

        public void SetTrustEstate(BuyerParameters trust_estate)
        {
            this.TrusteeShortName.FASetText(trust_estate.TrusteeName, continueOnFailure: true);
            this.TrusteeLoanApplicant.FASetCheckbox(trust_estate.LoanApplicant);
        }

        public void SetBusinessEntity(BuyerParameters businessEntity)
        {
            this.BusinessEntityName.FASetText(businessEntity.BusinessEntityShortname, continueOnFailure: true);
            this.TrusteeLoanApplicant.FASetCheckbox(businessEntity.LoanApplicant);
        }

        #endregion
    }

    public class BuyerSellerSummary : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement btnNew { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement btnEdit { get; set; }

        [FindsBy(How = How.Id, Using = "btnClear")]
        public IWebElement btnClear { get; set; }

        [FindsBy(How = How.Id, Using = "gridBuyerSellerSummary")]
        public IWebElement tblBuyerSellerSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_Borrower")]
        public IWebElement FundsDueLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_BuyerFundsDue")]
        public IWebElement FundsDueAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_Borrower")]
        public IWebElement BuyerFundsDueLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_BuyerFundsDue")]
        public IWebElement BuyerFundsDueAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table/tbody/tr/td/b[text()='Seller's Funds Due:']")]
        public IWebElement SellerFundsDueLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_SellerFundsDue")]
        public IWebElement SellerFundsDueAmount { get; set; }

        public IWebElement GetBuyerSeller(int index = 0)
        {
            return WebDriver.FindElement(By.Id("gridBuyerSellerSummary_" + index));
        }

        #endregion

        public BuyerSellerSummary Open(bool isBuyer = true)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>" + (isBuyer ? "Buyers" : "Sellers"));
            this.WaitForScreenToLoad();

            return this;
        }

        public void Open(bool isBuyer, int index)
        {
            FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>("Home>Order Entry>" + (isBuyer ? "Buyers" : "Sellers"));
            this.WaitForScreenToLoad();
            this.GetBuyerSeller(index - 1).FAClick();
            this.btnEdit.FAClick();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
        }

        public BuyerSellerSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? tblBuyerSellerSummaryTable);
            return this;
        }

        public void VerifyMultplColValues(int RowNum, Dictionary<int, string> DictionaryObj)
        {
            int RowNumber = RowNum + 1;
            this.SwitchToContentFrame();
            this.WaitCreation(tblBuyerSellerSummaryTable);
            if (DictionaryObj.Count == 0)
            {
                throw new Exception("Dictionary does not have Keys. Please add Key and Value");
            }

            foreach (var ColNum in DictionaryObj.Keys)
                if (tblBuyerSellerSummaryTable.FindElements(By.XPath("//tr[" + RowNumber + "]/td[" + ColNum + "]//child::*[contains(*,'" + DictionaryObj[ColNum].ToString() + "')]")).Count > 0)
                {
                    Reports.UpdateDebugLog("Verify Text in Buyer Summary Table", "", "Text in Table", "TEXT", DictionaryObj[ColNum], "", Reports.Result(true), "");
                }
                else
                {
                    Reports.UpdateDebugLog("Verify Text in Buyer Summary Table", "", "Text in Table", "TEXT", DictionaryObj[ColNum], "", Reports.Result(false), "");
                }
        }

        public BuyerSellerSummary BuyerSellerSummaryTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int StartingRowNum = 1)
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(tblBuyerSellerSummaryTable);
                tblBuyerSellerSummaryTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

                return this;
            }
            catch (StaleElementReferenceException) //Try again if get stale element reference exception
            {
                this.SwitchToContentFrame();
                this.WaitCreation(tblBuyerSellerSummaryTable);
                tblBuyerSellerSummaryTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

                return this;
            }

        }

        public BuyerSellerSummary New()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(btnNew);
            btnNew.FAClick();

            return this;
        }

        public BuyerSellerSummary Edit()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(btnEdit);
            btnEdit.FAClick();

            return this;
        }

        public BuyerSellerSummary ClickClear(bool clickDefaultButton = true)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(btnClear, 5);
            btnClear.FAClick();

            return this;
        }

        public BuyerSellerSummary WaitForBuyerSellerSummaryTableLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(tblBuyerSellerSummaryTable, 5);
            return this;
        }

        public BuyerSellerSetup EditBuyerSeller(string BuyerSellerType)
        {

            this.WaitForBuyerSellerSummaryTableLoad();
            this.BuyerSellerSummaryTable(4, BuyerSellerType, 4, TableAction.Click);
            Edit();

            return FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

        }


    }

    public class BuyerVesting : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnRefreshShort")]
        public IWebElement RefreshShort { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement CheckSpellingNameRelations { get; set; }

        [FindsBy(How = How.Id, Using = "textNames")]
        public IWebElement Names { get; set; }

        [FindsBy(How = How.Id, Using = "btnCpyTitleVerst")]
        public IWebElement CopyTitleVesting { get; set; }

        [FindsBy(How = How.Id, Using = "btnRefreshFull")]
        public IWebElement RefreshFull { get; set; }

        [FindsBy(How = How.Id, Using = "Button2")]
        public IWebElement CheckSpellingCompVest { get; set; }

        [FindsBy(How = How.Id, Using = "textCompVest")]
        public IWebElement CompleteVesting { get; set; }

        #endregion


        /// <summary>
        /// This Service clicks on the CopyTitleVesting button of Vesting.
        /// </summary>
        public BuyerVesting ClickCopyTitlVestg()
        {
            CopyTitleVesting.FAClick();
            this.WaitCreation(this.RefreshFull);
            return this;
        }



        /// <summary>
        /// This Service clicks on the Refresh button of Complete Vesting.
        /// </summary>
        public BuyerVesting ClickRefreshFull()
        {
            RefreshFull.FAClick();
            Playback.Wait(5000);
            return this;
        }



        /// <summary>
        /// This Service clicks on the Refresh button of Names&Relationships.
        /// </summary>
        public BuyerVesting ClickRefreshShort()
        {
            RefreshShort.FAClick();
            Playback.Wait(8000);
            return this;
        }

        /// <summary>
        ///Gets data from Buyer Vesting
        /// </summary>			
        public string[] GetAllFieldsValues()
        {
            string[] TempArr = new string[2];
            TempArr[0] = Names.FAGetValue().Trim();
            TempArr[1] = CompleteVesting.FAGetValue().Trim();
            return TempArr;
        }

        /// <summary>
        ///Sets data from Buyer Vesting
        /// </summary>			
        public BuyerVesting FillFields(BuyerVestingParameters TestData)
        {
            Names.FASetText(TestData.Names);
            CompleteVesting.FASetText(TestData.CompleteVesting);
            return this;
        }

        public BuyerVesting WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? RefreshShort);
            return this;
        }

    }

    public class ExchangeCompany : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement GABName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement NameLabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement NameLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
        public IWebElement BusPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement textName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboSalesRep1")]
        public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboSalesRep2")]
        public IWebElement SalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GABIdCodeLabel { get; set; }


        #endregion

        public void WaitForScrenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode);
        }

        public ExchangeCompany FindGAB(string gabcode = null, string gabname = null)
        {
            WaitForScrenToLoad();
            GABcode.FASetText(gabcode);
            GABName.FASetText(gabname);
            Find.FAClick();
            return this;
        }

        /// <summary>
        /// This function get the contact details available at exchange company information section .
        /// </summary>
        /// <returns></returns>
        public FASTSelenium.DataObjects.ADM.PhoneParameters GetExchangeCompanyDtl()
        {
            Reports.TestStep = "Get the contact details from the exchange company information section.";
            FASTSelenium.DataObjects.ADM.PhoneParameters contactData = new FASTSelenium.DataObjects.ADM.PhoneParameters
            {
                BusinessPhoneNumber = FastDriver.ExchangeCompany.BusPhone.FAGetValue(),
                BusinessPhoneExtn = FastDriver.ExchangeCompany.BusPhoneExt.FAGetValue(),
                BusinessFaxNumber = FastDriver.ExchangeCompany.BusFax.FAGetValue(),
                CellularNumber = FastDriver.ExchangeCompany.CellPhone.FAGetValue(),
                PagerNumber = FastDriver.ExchangeCompany.Pager.FAGetValue(),
                Email = FastDriver.ExchangeCompany.EmailAddress.FAGetValue()
            };
            return contactData;
        }

        // <summary>
        /// This function update contact details available at exchange company information section .
        /// </summary>
        /// <returns></returns>
        public void UpdateExchangeCompanyDtl(FASTSelenium.DataObjects.ADM.PhoneParameters contactData)
        {
            Reports.TestStep = "Update the contact details from the exchange company information section.";
            FastDriver.ExchangeCompany.BusPhone.FASetText(contactData.BusinessPhoneNumber);
            FastDriver.ExchangeCompany.BusPhoneExt.FASetText(contactData.BusinessPhoneExtn);
            FastDriver.ExchangeCompany.BusFax.FASetText(contactData.BusinessFaxNumber);
            FastDriver.ExchangeCompany.CellPhone.FASetText(contactData.CellularNumber);
            FastDriver.ExchangeCompany.Pager.FASetText(contactData.PagerNumber);
            FastDriver.ExchangeCompany.EmailAddress.FASetText(contactData.Email);
        }

        /// <summary>
        /// Compares the actual and expected contact details.
        /// </summary>
        /// <param name="exptdDetail">Data object of expected contact details</param>
        /// <param name="actDetail">Data object of actual contact details.</param>
        public void VerifyContactDetail(FASTSelenium.DataObjects.ADM.PhoneParameters exptdDetail, FASTSelenium.DataObjects.ADM.PhoneParameters actDetail)
        {
            Reports.TestStep = "Verify whether the contact details are as per Expectation.";
            Support.AreEqual(exptdDetail.BusinessPhoneNumber, actDetail.BusinessPhoneNumber, "Verfication of Business Phone Number.");
            Support.AreEqual(exptdDetail.BusinessPhoneExtn, actDetail.BusinessPhoneExtn, "Verifiation of Business Phone extention.");
            Support.AreEqual(exptdDetail.BusinessFaxNumber, actDetail.BusinessFaxNumber, "Verification of the Business Fax Number");
            Support.AreEqual(exptdDetail.CellularNumber, actDetail.CellularNumber, "Verification of the Cellular Number");
            Support.AreEqual(exptdDetail.PagerNumber, actDetail.PagerNumber, "Verification of the Pager.");
            Support.AreEqual(exptdDetail.Email, actDetail.Email, "Verification of the Email.");
        }

        public void ClickFind()
        {
            this.Find.FAClick();
        }
    }

    public class AKANames : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement AKANew { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement AKARemove { get; set; }

        [FindsBy(How = How.Id, Using = "FAFAKAGrid")]
        public IWebElement AKATable { get; set; }

        [FindsBy(How = How.Id, Using = "FAFAKAGrid_0_FAFtxtAKA")]
        public IWebElement AKA { get; set; }

        [FindsBy(How = How.Id, Using = "FAFAKAGrid_1_FAFtxtAKA")]
        public IWebElement AKA1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFAKAGrid_0_FAFChkSigning")]
        public IWebElement UsedatSigning { get; set; }

        [FindsBy(How = How.Id, Using = "FAFAKAGrid_1_FAFChkSigning")]
        public IWebElement UsedatSigning1 { get; set; }

        #endregion

        public AKANames WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AKANew);
            return this;
        }

        #region Services
        /// <summary>
        /// Clicks on AKANew button
        /// </summary>        
        public AKANames Aka_New()
        {
            AKANew.FAClick();
            this.WaitForScreenToLoad();
            return this;
        }

        /// <summary>
        /// Fills details on AKANew button
        /// </summary>        
        public AKANames SetDetails(AkaParameters AkaNameVals, int NewRowCount = 1, bool ClickNewButton = true)
        {
            FastDriver.AKANames.SwitchToContentFrame();

            if (ClickNewButton)
            {
                FastDriver.AKANames.Aka_New();
                Playback.Wait(1500);
            }

            AKA.FASetText(AkaNameVals.Aka);
            if (AkaNameVals.UsedAtSigning)
            {
                if (!UsedatSigning.Selected)
                {
                    UsedatSigning.FAClick();
                }
            }
            else
            {
                if (UsedatSigning.Selected)
                {
                    UsedatSigning.FAClick();
                }
            }

            //Second row
            if (NewRowCount == 2)
            {
                if (ClickNewButton)
                {
                    FastDriver.AKANames.Aka_New();
                    Playback.Wait(1500);
                }
                this.AKA1.FASetText(AkaNameVals.AkaTwo);
                if (AkaNameVals.UsedAtSigningTwo)
                {
                    if (!UsedatSigning1.Selected)
                    {
                        UsedatSigning1.FAClick();
                    }
                }
                else
                {
                    if (UsedatSigning1.Selected)
                    {
                        UsedatSigning1.FAClick();
                    }
                }
            }

            FastDriver.BottomFrame.Done();
            return this;
        }

        /// <summary>
        /// Returns data from Aka page
        /// </summary>  
        public Dictionary<string, string> GetDetails
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("AKA", AKA.FAGetValue().Trim());
                AllDetails.Add("UsedatSigning", UsedatSigning.FAGetAttribute("Checked").ToString());
                return AllDetails;
            }
        }









        #endregion
    }

}
