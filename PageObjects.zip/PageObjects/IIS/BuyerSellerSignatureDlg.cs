﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class BuyerSellerSignatureDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "cboFontName")]
        public IWebElement FontName { get; set; }
        #endregion

        #region Services
        public BuyerSellerSignatureDlg WaitForScreenToLoad(IWebElement element = null, string windowName = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
            Thread.Sleep(4000);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FontName);
            return this;
        }

        public void UpdateSignature(string updtdSign)
        {
            this.WaitForScreenToLoad();
            IWebElement frame = WebDriver.FindElement(By.TagName("iframe"));
            WebDriver.SwitchTo().Frame(frame);
            IWebElement edtrelement = WebDriver.FindElement(By.TagName("body"));
            edtrelement.Clear();
            edtrelement.FASetText(updtdSign);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please", false, 10);
        }

        public string GetSignatureFormat()
        {
            this.WaitForScreenToLoad();
            IWebElement frame = WebDriver.FindElement(By.TagName("iframe"));
            WebDriver.SwitchTo().Frame(frame);
            IWebElement edtrelement = WebDriver.FindElement(By.TagName("body"));
            return edtrelement.FAGetText();;
        }
        #endregion
    }
}
