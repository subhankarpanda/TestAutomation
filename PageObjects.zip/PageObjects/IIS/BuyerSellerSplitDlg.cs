﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class BuyerSellerSplitDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlChargeTo")]
		public IWebElement ApplyPercentageTo { get; set; }

        [FindsBy(How = How.Id, Using = "txtSplitPercntg")]
		public IWebElement SplitPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblOwnerPolicy")]
		public IWebElement PolicyType { get; set; }
        
         [FindsBy(How = How.Id, Using = "lblPolicyName")]
		public IWebElement PolicyName { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalCharge")]
		public IWebElement TotalAMount { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
		public IWebElement BuyerCharge { get; set; }
        
        [FindsBy(How = How.Id, Using = "txtSellerCharge")]
		public IWebElement SellerCharge { get; set; }
        #endregion

        public BuyerSellerSplitDlg WaitForScreenToLoad(string windowName = "Buyer Seller Split")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 120);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ApplyPercentageTo, 120);

            return this;
        }

        public BuyerSellerSplitDlg VerifyBuyerSellerSplitDialog(string FeeDesc, string ApplyPercentageTo, string SplitPercentage, string DisclosedOwnerPremium) {
            
            FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
            Support.AreEqual(true.ToString(), PolicyType.Displayed.ToString());
            Support.AreEqual(true.ToString(), PolicyName.Displayed.ToString());
            Support.AreEqual(true.ToString(), TotalAMount.Displayed.ToString());
            Support.AreEqual(true.ToString(), this.ApplyPercentageTo.Displayed.ToString());
            Support.AreEqual(true.ToString(), this.SplitPercentage.Displayed.ToString());
            Support.AreEqual(true.ToString(), BuyerCharge.Displayed.ToString());
            Support.AreEqual(true.ToString(), SellerCharge.Displayed.ToString());

            Support.AreEqual("Owner", PolicyType.Text.Trim());
            Support.AreEqual(FeeDesc, PolicyName.Text.Trim());
            Support.AreEqual(DisclosedOwnerPremium, TotalAMount.Text.Trim());
            Support.AreEqual(SplitPercentage, this.SplitPercentage.FAGetValue().Trim());

            double  SplitPerCentage = Convert.ToDouble(SplitPercentage);
            if (ApplyPercentageTo == "Seller"){
                if ( SplitPerCentage != 0.00)
                {
                    double Sellerdollaramt = Convert.ToDouble(DisclosedOwnerPremium) * SplitPerCentage / 100;
                    double BuyerDollaramount = (Convert.ToDouble(DisclosedOwnerPremium) - Sellerdollaramt);
                    Support.AreEqual(BuyerDollaramount.ToString().FormatAsMoney(),BuyerCharge.FAGetValue().Trim());
                    Support.AreEqual(Sellerdollaramt.ToString().FormatAsMoney(),SellerCharge.FAGetValue().Trim());

                }
                else
                {
                    double BuyerDollaramount = Convert.ToDouble(BuyerCharge.FAGetValue());
                    double Sellerdollaramt = (Convert.ToDouble(DisclosedOwnerPremium) - BuyerDollaramount);
                    Support.AreEqual(BuyerDollaramount.ToString().FormatAsMoney(),BuyerCharge.FAGetValue().Trim());
                    Support.AreEqual(Sellerdollaramt.ToString().FormatAsMoney(),SellerCharge.FAGetValue().Trim());

                }
            }
            else
            {
                if (SplitPerCentage  != 0.00)
                {
                    double BuyerDollaramount = Convert.ToDouble(DisclosedOwnerPremium) * SplitPerCentage / 100;
                    double Sellerdollaramt = (Convert.ToDouble(DisclosedOwnerPremium) - BuyerDollaramount);
                    Support.AreEqual(BuyerDollaramount.ToString().FormatAsMoney(),BuyerCharge.FAGetValue().Trim());
                    Support.AreEqual(Sellerdollaramt.ToString().FormatAsMoney(),SellerCharge.FAGetValue().Trim());

                }
                else
                {
                    double BuyerDollaramount = Convert.ToDouble(BuyerCharge.FAGetValue());
                    double Sellerdollaramt = (Convert.ToDouble(DisclosedOwnerPremium) - BuyerDollaramount);
                    Support.AreEqual(BuyerDollaramount.ToString().FormatAsMoney(),BuyerCharge.FAGetValue().Trim());
                    Support.AreEqual(Sellerdollaramt.ToString().FormatAsMoney(),SellerCharge.FAGetValue().Trim());

                }

            }
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            return this;
        }

        public BuyerSellerSplitDlg EnterSplitPercentage(string SplitPercentage) {
            WaitForScreenToLoad();
            this.SplitPercentage.FASetText(SplitPercentage);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            return this;
        }

        public BuyerSellerSplitDlg VerifyFieldsinBuyerSellerSplitDialogwhenFeeisCalculatedfromFACCandSplitbypercentage() {
            WaitForScreenToLoad();
            Support.AreEqual(false.ToString(),BuyerCharge.Enabled.ToString());
            Support.AreEqual(false.ToString(),SellerCharge.Enabled.ToString());
            Support.AreEqual(false.ToString(),SplitPercentage.Enabled.ToString());
            Support.AreEqual(false.ToString(), ApplyPercentageTo.Enabled.ToString());
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            return this;
            
        }
    }
    
}
