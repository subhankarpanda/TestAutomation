using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Windows.Input;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Diagnostics;

namespace FASTSelenium.PageObjects
{
	public class CD : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "tblProjectedPayment")]
		public IWebElement ProjectedPaymentTable { get; set; }

		[FindsBy(How = How.Name, Using = "tbl-transSummary-Calculation")]
		public IWebElement SummaryOftransactionCalculationTable { get; set; }

		[FindsBy(How = How.Id, Using = "imgLoanTerm")]
		public IWebElement LoanTermPlusIcon { get; set; }

		[FindsBy(How = How.Id, Using = "rdoMinimumMaximum")]
		public IWebElement MinMaxRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "txtMinimum")]
		public IWebElement MinimumAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaximum")]
		public IWebElement MaximumAmount { get; set; }

		[FindsBy(How = How.Id, Using = "rdoOnlyInterest")]
		public IWebElement OnlyInterestRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "txtPopInterest")]
		public IWebElement OnlyInterestTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "btnPrincipalInterestCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnPrincipalInterestDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnBorrowerInfoDone")]
		public IWebElement BorrowerDone { get; set; }

		[FindsBy(How = How.Id, Using = "btnSellerInfoDone")]
		public IWebElement SellerDone { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoFAId0")]
		public IWebElement BorrowerForwardingAddress { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoFAId0")]
		public IWebElement SellerForwardingAddress { get; set; }

		[FindsBy(How = How.Id, Using = "lblDisplayDescription_71058116_0")]
		public IWebElement LoanDescription { get; set; }

		[FindsBy(How = How.Id, Using = "lblLoanTerm")]
		public IWebElement LoanTermYearMonth { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange0")]
		public IWebElement YearRangeFirstColumnHeader { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange1")]
		public IWebElement YearRangeSecondColumnHeader { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange2")]
		public IWebElement YearRangeThirdColumnHeader { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange3")]
		public IWebElement YearRangeFourthColumnHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Final Payment")]
		public IWebElement YearRangeFinalPaymentColumnHeader { get; set; }

		[FindsBy(How = How.Id, Using = "YearRange2")]
		public IWebElement YearRangeThirdColumnHeader1 { get; set; }

		[FindsBy(How = How.Id, Using = "YearRange3")]
		public IWebElement YearRangeFourthColumnHeader1 { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleProjectedPayments")]
		public IWebElement ProjectedPaymentHeader { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleLoanTerms")]
		public IWebElement LoanTermHeader { get; set; }

		[FindsBy(How = How.Id, Using = "divImgYearRange")]
		public IWebElement ProjectedPaymentPlusIcon { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement PrincipalandInterestLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Mortagage Insurance")]
		public IWebElement MortgageInsuranceLabel { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement EstimateEscrowLabel { get; set; }

		[FindsBy(How = How.Id, Using = "divImgPI0")]
		public IWebElement PrincipalInterestFirstColumnplusIcon { get; set; }

		[FindsBy(How = How.Id, Using = "divImgPI1")]
		public IWebElement PrincipalInterestSecondColumnplusIcon { get; set; }

		[FindsBy(How = How.Id, Using = "divImgPI2")]
		public IWebElement PrincipalInterestThirdColumnplusIcon { get; set; }

		[FindsBy(How = How.Id, Using = "divImgPI3")]
		public IWebElement PrincipalInterestFourthColumnplusIcon { get; set; }

		[FindsBy(How = How.Id, Using = "Dummy")]
		public IWebElement ProjectedPaymentPrincipalAmountFirstColumn { get; set; }

		[FindsBy(How = How.Id, Using = "Dummy")]
		public IWebElement ProjectedPaymentPrincipalAmountSecondColumn { get; set; }

		[FindsBy(How = How.Id, Using = "Dummy")]
		public IWebElement ProjectedPaymentPrincipalAmountThirdColumn { get; set; }

		[FindsBy(How = How.Id, Using = "Dummy")]
		public IWebElement ProjectedPaymentPrincipalAmountFourthColumn { get; set; }

		[FindsBy(How = How.Id, Using = "txtPrincipalInterest")]
		public IWebElement ProjectedPaymentPrincipalAmountColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine20")]
		public IWebElement ProjectedPaymentOnlyInterestkeywordFirstColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine21")]
		public IWebElement ProjectedPaymentOnlyInterestkeywordSecondColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine22")]
		public IWebElement ProjectedPaymentOnlyInterestkeywordThirdColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine23")]
		public IWebElement ProjectedPaymentOnlyInterestkeywordFourthColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine10")]
		public IWebElement ProjectedPaymentOnlyInterestAmountFirstColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine11")]
		public IWebElement ProjectedPaymentOnlyInterestAmountSecondColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine12")]
		public IWebElement ProjectedPaymentOnlyInterestAmountThirdColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine13")]
		public IWebElement ProjectedPaymentOnlyInterestAmountFourthColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine10")]
		public IWebElement PricipalandInterestamountFirstColumnMIN { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine11")]
		public IWebElement PricipalandInterestamountSecondColumnMIN { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine12")]
		public IWebElement PricipalandInterestamountThirdColumnMIN { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine13")]
		public IWebElement PricipalandInterestamountFourthColumnMIN { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine20")]
		public IWebElement PricipalandInterestamountFirstColumnMAX { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine21")]
		public IWebElement PricipalandInterestamountSecondColumnMAX { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine22")]
		public IWebElement PricipalandInterestamountThirdColumnMAX { get; set; }

		[FindsBy(How = How.Id, Using = "lblPILine23")]
		public IWebElement PricipalandInterestamountFourthColumnMAX { get; set; }

		[FindsBy(How = How.Id, Using = "lblEstTotMonPay0")]
		public IWebElement EstTotalMonthlypayFirstColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblEstTotMonPay1")]
		public IWebElement EstTotalMonthlypaySecondColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblEstTotMonPay2")]
		public IWebElement EstTotalMonthlypayThirdColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblEstTotMonPay3")]
		public IWebElement EstTotalMonthlypayFourthColumn { get; set; }

		[FindsBy(How = How.Id, Using = "lblLoanTerm")]
		public IWebElement EstTotalFinalPayment { get; set; }

		[FindsBy(How = How.Id, Using = "txtMortInsAmt0")]
		public IWebElement MortgageInsFirstColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtMortInsAmt1")]
		public IWebElement MortgageInsSecondColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtMortInsAmt2")]
		public IWebElement MortgageInsThirdColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtMortInsAmt3")]
		public IWebElement MortgageInsFourthColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtLoanTermYear")]
		public IWebElement MortgageInsFinalPaymentColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "tdMI0")]
		public IWebElement MortgageInsFirstColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "tdMI1")]
		public IWebElement MortgageInsSecondColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "tdMI2")]
		public IWebElement MortgageInsThirdColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "tdMI3")]
		public IWebElement MortgageInsFourthColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "tdMI4")]
		public IWebElement MortgageInsFinalPaymentColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "txtEstEscAmt0")]
		public IWebElement EstEscrowFirstColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtEstEscAmt1")]
		public IWebElement EstEscrowSecondColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtEstEscAmt2")]
		public IWebElement EstEscrowThirdColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtEstEscAmt3")]
		public IWebElement EstEscrowFourthColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtLoanTermYear")]
		public IWebElement EstEscrowsFinalPaymentColumnAmount { get; set; }

		[FindsBy(How = How.Id, Using = "headerEstEscr0")]
		public IWebElement EstEscrowFirstColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "headerEstEscr1")]
		public IWebElement EstEscrowSecondColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "headerEstEscr2")]
		public IWebElement EstEscrowThirdColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "headerEstEscr3")]
		public IWebElement EstEscrowFourthColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "headerEstEscr4")]
		public IWebElement EstEscrowFinalPaymentColumnplusSign { get; set; }

		[FindsBy(How = How.Id, Using = "lblPIMinAmt3")]
		public IWebElement PricipalandInterestamountFinalPayment { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement EstimateTaxesInsuranceAssessmentLabel { get; set; }

		[FindsBy(How = How.Id, Using = "txtETIAmt")]
		public IWebElement EstTaxesInsuranceAssessmentAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Taxes")]
		public IWebElement PropertyTaxesLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Homeowner's Insurance")]
		public IWebElement HomeOwnerInsuranceLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Other:")]
		public IWebElement OtherHomeOwnerAssociationLabel { get; set; }

		[FindsBy(How = How.Id, Using = "txtPPEstimateOther")]
		public IWebElement OthersTextBox { get; set; }

        [FindsBy(How = How.Id, Using = "txtPOPupEstimateOther")]
        public IWebElement txtPOPupEstimateOther { get; set; }

        [FindsBy(How = How.Id, Using = "EstimateIncludesID_2984")]
        public IWebElement EstimateIncludesCondominiumAssociationDues { get; set; }

        [FindsBy(How = How.Id, Using = "EstimateIncludesID_2992")]
        public IWebElement EstimateIncludesOther { get; set; }

        [FindsBy(How = How.Id, Using = "ShowOnFormID_2992")]
        public IWebElement ShowOnFormOther { get; set; }

        [FindsBy(How = How.Id, Using = "InEscrowID_2992")]
        public IWebElement InEscrowOther { get; set; }

        [FindsBy(How = How.Id, Using = "InEscrowID_2984")]
        public IWebElement InEscrowCondominiumAssociationDues { get; set; }

        [FindsBy(How = How.Id, Using = "ShowOnFormID_2984")]
        public IWebElement ShowOnFormCondominiumAssociationDues { get; set; }

        [FindsBy(How = How.Id, Using = "txtPPEstimateOtherInEscrow")]
        public IWebElement ThisEstomateIncludesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "lblPPEstimateIncludesOtherInEscrowID")]
        public IWebElement InEscrowDescription { get; set; }

		[FindsBy(How = How.LinkText, Using = "This estimate includes")]
		public IWebElement ThisEstimatesIncludesLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "In escrow?")]
		public IWebElement InEscrowLabel { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIsPropertyTaxInEscrow")]
		public IWebElement PropertyTaxesDropDown { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIsHomeOwnerInsuranceInEscrow")]
		public IWebElement HomeOwnerassociationDropDown { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIsOtherInEscrow")]
		public IWebElement OthersDropDown { get; set; }

		[FindsBy(How = How.Id, Using = "LoanTerm_BalloonPayment")]
		public IWebElement BalloonPaymentLabel { get; set; }

		[FindsBy(How = How.Id, Using = "ddlBalloonpayment")]
		public IWebElement BalloonPaymentDropDown { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleLoanCosts")]
		public IWebElement LoanCosts { get; set; }

		[FindsBy(How = How.Id, Using = "tblLoanCostSubSection_B")]
		public IWebElement ServicesBorrowerDidnotShopFor { get; set; }

		[FindsBy(How = How.Id, Using = "tblLoanCostSubSection_C")]
		public IWebElement ServicesBorrowerDidShopFor { get; set; }

		[FindsBy(How = How.Id, Using = "tblOtherCostSubSection_H")]
		public IWebElement OthercostsH { get; set; }

		[FindsBy(How = How.Id, Using = "lblDispHideLoanEstimate")]
		public IWebElement DisplayLoaEstimatecolumnsLabel { get; set; }

		[FindsBy(How = How.Id, Using = "chkDispHideLoanEstimate")]
		public IWebElement DisplayLoaEstimateColumns { get; set; }

		[FindsBy(How = How.Id, Using = "tblLoanCostSubSection_A")]
		public IWebElement OriginationCharges { get; set; }

		[FindsBy(How = How.Id, Using = "lblPIMaxAmt0")]
		public IWebElement Minlabel { get; set; }

		[FindsBy(How = How.Id, Using = "lblPIMinAmt0")]
		public IWebElement Maxlabel { get; set; }

		[FindsBy(How = How.Id, Using = "txtBeginYear0")]
		public IWebElement YearRangeFirstLowerBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtEndYear0")]
		public IWebElement YearRangeFirstUpperBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtBeginYear1")]
		public IWebElement YearRangeSecondLowerBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtEndYear1")]
		public IWebElement YearRangeSecondUpperBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtBeginYear2")]
		public IWebElement YearRangeThirdLowerBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtEndYear2")]
		public IWebElement YearRangeThirdUpperBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtBeginYear3")]
		public IWebElement YearRangeFourthLowerBound { get; set; }

		[FindsBy(How = How.Id, Using = "txtEndYear3")]
		public IWebElement YearRangeFourthUpperBound { get; set; }

		[FindsBy(How = How.Id, Using = "btnSave")]
		public IWebElement CDSave { get; set; }

        //[FindsBy(How = How.Id, Using = "thYearRange0")]
        //public IWebElement YearRangeFirstColumnHeader { get; set; }

        //[FindsBy(How = How.Id, Using = "thYearRange1")]
        //public IWebElement YearRangeSecondColumnHeader { get; set; }

        //[FindsBy(How = How.Id, Using = "thYearRange2")]
        //public IWebElement YearRangeThirdColumnHeader { get; set; }

        //[FindsBy(How = How.Id, Using = "thYearRange3")]
        //public IWebElement YearRangeFourthColumnHeader { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange")]
		public IWebElement row1cell1 { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange0")]
		public IWebElement row1cell2 { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange1")]
		public IWebElement row1cell3 { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange2")]
		public IWebElement row1cell4 { get; set; }

		[FindsBy(How = How.Id, Using = "thYearRange3")]
		public IWebElement row1cell5 { get; set; }

        //[FindsBy(How = How.Id, Using = "txtPPEstimateOther")]
        //public IWebElement OthersTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "imgOthersInEscrow")]
		public IWebElement Otherplusicon { get; set; }

		[FindsBy(How = How.Id, Using = "ddlPPOther")]
		public IWebElement Otherdropdownlist { get; set; }

		[FindsBy(How = How.Id, Using = "btnPPOtherDone")]
		public IWebElement DoneinOtherpopup { get; set; }

		[FindsBy(How = How.Id, Using = "chkPropTaxes")]
		public IWebElement PropertyTaxesChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "chkHOIns")]
		public IWebElement HomeownerChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "chkProjectedPaymentOthers")]
		public IWebElement OthersChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIsPropertyTaxInEscrow")]
		public IWebElement InEsrwProTaxDropdownEmpty { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIsHomeOwnerInsuranceInEscrow")]
		public IWebElement HomeOwnerInsInErwDropdwnEmpty { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIsOtherInEscrow")]
		public IWebElement OtherInEscrowDropdwnEmpty { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleLoanDisclosures")]
		public IWebElement LoanDisclosureHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrow Account For now, your loan")]
		public IWebElement EscrowAccountHeader { get; set; }

		[FindsBy(How = How.Id, Using = "chkHasEscrowAccount")]
		public IWebElement WillHaveEscrowAccountChkBox { get; set; }

		[FindsBy(How = How.LinkText, Using = "Will have an escrow account(also called")]
		public IWebElement WillHaveEscrowAccountHeaderDesc { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrow ")]
		public IWebElement EscrowTableHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrowed Property Costs over Year")]
		public IWebElement EscrowedPropertyCostsOverYear1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Non-Escrowed Property Costs over Y")]
		public IWebElement NonEscrowedPropertyCostsOverYear1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Initial Escrow Payment")]
		public IWebElement InitialEscrowPaymentLabel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Monthly Escrow Payment")]
		public IWebElement MonthlyEscrowedPaymentLabel { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement EscrowedPropertyCostsOverYear1SpanR1C2editable { get; set; }

		[FindsBy(How = How.Id, Using = "spnDollarForEscrow")]
		public IWebElement EscrowedPropertyCostsOverYear1SpanR1C2editable1 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement EscrowedPropertyCostsOverYear1SpanR1C2 { get; set; }

		[FindsBy(How = How.Id, Using = "spnNonEscrowedProertyOverYear1Amount")]
		public IWebElement NonEscrowedPropertyCostsOverYear1SpanR2C2 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement InitialEscrowPaymentSpanR3C2 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement MonthlyEscrowedPaymentSpanR4C2 { get; set; }

		[FindsBy(How = How.Id, Using = "spnDollarForMonthlyEscrow")]
		public IWebElement MonthlyEscrowedPaymentSpanR4C2editable { get; set; }

		[FindsBy(How = How.Id, Using = "spnDollarForInitialEscrow")]
		public IWebElement InitialEscrowPaymentSpanR3C2editable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Estimated total amount over year 1 for your escrowed property costs:")]
		public IWebElement EscrowTableSpanR1C3 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAreaEscrowedProertyOverYear1Editable")]
		public IWebElement EscrowTableSpanR1C3editable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Estimated total amount over year 1 for your non-escrowed property costs: ")]
		public IWebElement EscrowTableSpanR2C3 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAreaNonEscrowedProertyOverYear1Editable")]
		public IWebElement EscrowTableSpanR2C3editable { get; set; }

		[FindsBy(How = How.LinkText, Using = "You may have other property costs.")]
		public IWebElement EscrowTableSpanR2C3bottomtext { get; set; }

		[FindsBy(How = How.LinkText, Using = "A cushion for the escrow account you p")]
		public IWebElement EscrowTableSpanR3C3 { get; set; }

		[FindsBy(How = How.LinkText, Using = "The amount included in your total mont")]
		public IWebElement EscrowTableSpanR4C3 { get; set; }

		[FindsBy(How = How.Id, Using = "chkNoEscrowAccount")]
		public IWebElement WillNotHaveEscrowAccountChkBox { get; set; }

		[FindsBy(How = How.LinkText, Using = "pNoEscrowAccount")]
		public IWebElement WillNotHaveEscrowAccountHeaderDesc { get; set; }

		[FindsBy(How = How.Id, Using = "chkEscrowAccntDeclined")]
		public IWebElement YouDeclinedChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "chkNoOfferbyLender")]
		public IWebElement YourLenderDoesNotOfferOneChkBox { get; set; }

		[FindsBy(How = How.LinkText, Using = "In the future, Your property costs may")]
		public IWebElement YourLenderDoesNotOfferOneText { get; set; }

		[FindsBy(How = How.LinkText, Using = "No Escrow")]
		public IWebElement NoEscrowTableHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrowed Property Costs over Year 1")]
		public IWebElement EscrowedPropertyCostsOverYear1NoEscrow { get; set; }

		[FindsBy(How = How.LinkText, Using = "Estimated Property Costs over Year")]
		public IWebElement EstimatedPropertyCostsOverYear1NoEscrow { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrow Waiver Fee")]
		public IWebElement EscrowWaiverFee { get; set; }

		[FindsBy(How = How.Id, Using = "spnEstimatedPropertyCostPerYear")]
		public IWebElement NoEscrowPaneR1C2 { get; set; }

		[FindsBy(How = How.Id, Using = "spnEscrowWaverFeeTxtbox")]
		public IWebElement NoEscrowPaneR2C2 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Estimated total amount over year 1. You must pay these costs directly, possibly  in one or two large payments a year.")]
		public IWebElement NoEscrowTextR1C3 { get; set; }

		[FindsBy(How = How.LinkText, Using = "In the future, Your property costs ma")]
		public IWebElement InTheFutureLabel { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleOtherCosts")]
		public IWebElement OtherCostsHeader { get; set; }

		[FindsBy(How = How.Id, Using = "spBorrowerPaid")]
		public IWebElement InitialEscrowPaymentBuyerTotal { get; set; }

		[FindsBy(How = How.Id, Using = "spBorrowerPaid")]
		public IWebElement TaxesandOtherGovernmentFees_Aggregate_Amount { get; set; }

		[FindsBy(How = How.Id, Using = "imgLoanPurpose")]
		public IWebElement FilePurposeIcon { get; set; }

		[FindsBy(How = How.Id, Using = "ddlLoanPurpose")]
		public IWebElement FilePurposecombobox { get; set; }

		[FindsBy(How = How.Id, Using = "btnLoanPurposeDone")]
		public IWebElement FilePurposeDone { get; set; }

		[FindsBy(How = How.Id, Using = "chkDispHideLoanEstimate")]
		public IWebElement DisplayLoanEstimatecolumnsChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "lblCalCashToCloseDescr")]
		public IWebElement CalculatingCashToCloseStatement { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleCalCashToClose")]
		public IWebElement CalculatingCashToCloseHeader { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement CalculatingCashToCloseR1C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Loan Estimate")]
		public IWebElement CalculatingCashToCloseR1C2 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Final")]
		public IWebElement CalculatingCashToCloseR1C3 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Did this change?")]
		public IWebElement CalculatingCashToCloseR1C4 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Unrounded Loan Estimate")]
		public IWebElement CalculatingCashToCloseR1C5 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Total Closing Costs (J)")]
		public IWebElement CalculatingCashToCloseR2C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Closing Costs Paid Before Closing")]
		public IWebElement CalculatingCashToCloseR3C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Closing Costs Financed (Paid from your Loan Amount)")]
		public IWebElement CalculatingCashToCloseR4C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Down Payment/Funds from Borrower")]
		public IWebElement CalculatingCashToCloseR5C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Deposit")]
		public IWebElement CalculatingCashToCloseR6C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Funds for Borrower")]
		public IWebElement CalculatingCashToCloseR7C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Seller Credits")]
		public IWebElement CalculatingCashToCloseR8C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Adjustments and Other Credits")]
		public IWebElement CalculatingCashToCloseR9C1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Cash to Close")]
		public IWebElement CalculatingCashToCloseR10C1 { get; set; }

        //[FindsBy(How = How.LinkText, Using = "Cash to Close")]
        //public IWebElement CalculatingCashToCloseR10C1 { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCFFinalAmount")]
		public IWebElement CalculatingCashToCloseR4C3_Final { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCFLEAmount")]
		public IWebElement CalculatingCashToCloseR4C2_LoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCFULEAmount")]
		public IWebElement CalculatingCashToCloseR4C5_UnroundLoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCFYN")]
		public IWebElement CalculatingCashToCloseR4C4_Ans { get; set; }

		[FindsBy(How = How.LinkText, Using = "You Included the Closing Costs in the Lo")]
		public IWebElement CalculatingCashToCloseR4C4_Statement { get; set; }

		[FindsBy(How = How.Id, Using = "imgCCFChanged")]
		public IWebElement CalculatingCashToCloseR4C4_Icon { get; set; }

		[FindsBy(How = How.LinkText, Using = "/SMSFast/SMSMvc/Areas/MVCUtils/Images/broken_Link....")]
		public IWebElement CalculatingCashToCloseR4C3_brokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "imgLoanProduct")]
		public IWebElement Product_Icon { get; set; }

		[FindsBy(How = How.Id, Using = "ddlLoanProduct")]
		public IWebElement Product_combobox { get; set; }

		[FindsBy(How = How.Id, Using = "txtLoanProduct")]
		public IWebElement Product_desc { get; set; }

		[FindsBy(How = How.Id, Using = "btnLoanProductDone")]
		public IWebElement Product_Done { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleLoanTerms")]
		public IWebElement LoanTerm_Header { get; set; }

		[FindsBy(How = How.Id, Using = "spnLoantermsInterestRate")]
		public IWebElement LoanTerm_InterestRate { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleAdjustablePayment")]
		public IWebElement APAIR_Header { get; set; }

		[FindsBy(How = How.LinkText, Using = "Adjustable Interest Rate (AIR) Table")]
		public IWebElement AIR_Header { get; set; }

		[FindsBy(How = How.Id, Using = "chkAirtbl")]
		public IWebElement AIR_IncludeAIRcheckbox { get; set; }

		[FindsBy(How = How.LinkText, Using = "Include Adjustable Interest Rate (AIR) T")]
		public IWebElement AIR_IncludeAIRcheckbox_label { get; set; }

		[FindsBy(How = How.Id, Using = "spneditable")]
		public IWebElement Index_margin { get; set; }

		[FindsBy(How = How.Id, Using = "spnIM1")]
		public IWebElement Index_Span { get; set; }

		[FindsBy(How = How.Id, Using = "spnplus")]
		public IWebElement Index_margin_plus { get; set; }

		[FindsBy(How = How.Id, Using = "spnIM2")]
		public IWebElement Margin_Span { get; set; }

		[FindsBy(How = How.Id, Using = "lblIniIntrestRate")]
		public IWebElement Initial_Interest_rate_label { get; set; }

		[FindsBy(How = How.Id, Using = "spnIIR")]
		public IWebElement Initial_Interest_rate_Span { get; set; }

		[FindsBy(How = How.Id, Using = "lblmaxmin")]
		public IWebElement MinMax_IntrestRatelabel { get; set; }

		[FindsBy(How = How.Id, Using = "spnMaxMin")]
		public IWebElement MinMax_IntrestRate_Span { get; set; }

		[FindsBy(How = How.LinkText, Using = "Change Frequency")]
		public IWebElement ChangeFrequency_label { get; set; }

		[FindsBy(How = How.Id, Using = "lblFirstChange")]
		public IWebElement ChangeFrequency_FirstChange_label { get; set; }

		[FindsBy(How = How.Id, Using = "lblSubChange")]
		public IWebElement ChangeFrequency_SubsequentChanges_label { get; set; }

		[FindsBy(How = How.Id, Using = "spnchngFreFstChanges")]
		public IWebElement ChangeFrequency_FirstChange_Span { get; set; }

		[FindsBy(How = How.Id, Using = "spnchngFreSubChanges")]
		public IWebElement ChangeFrequency_SubsequentChanges_Span { get; set; }

		[FindsBy(How = How.LinkText, Using = "Limits On Interest Rate Changes")]
		public IWebElement LimitsOnIntrestRateChanges_label { get; set; }

		[FindsBy(How = How.Id, Using = "lbllimChange")]
		public IWebElement LimitsOnIntrestRateChanges_FirstChange_label { get; set; }

		[FindsBy(How = How.Id, Using = "lbllimSubChange")]
		public IWebElement LimitsOnIntrestRateChanges_SubsequentChanges_label { get; set; }

		[FindsBy(How = How.Id, Using = "spnLimFstChanges")]
		public IWebElement LimitsOnIntrestRateChanges_FirstChange_Span { get; set; }

		[FindsBy(How = How.Id, Using = "spnLimSubChanges")]
		public IWebElement LimitsOnIntrestRateChanges_SubsequentChanges_Span { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleLoanCalc")]
		public IWebElement LoanCalculationHeader { get; set; }

		[FindsBy(How = How.Id, Using = "txtTotalofPayments")]
		public IWebElement TotalofPayments { get; set; }

		[FindsBy(How = How.Id, Using = "txtFinanceCharge")]
		public IWebElement FinanceCharge { get; set; }

		[FindsBy(How = How.Id, Using = "txtAmountFinanced")]
		public IWebElement AmountFinanced { get; set; }

		[FindsBy(How = How.Id, Using = "txtAnnualPercentageRate")]
		public IWebElement AnnualPercentageRate { get; set; }

		[FindsBy(How = How.Id, Using = "txtTotalInterestPercentage")]
		public IWebElement TotalInterestPercentage { get; set; }

		[FindsBy(How = How.Name, Using = "OK")]
		public IWebElement OkButtonForDialog { get; set; }

        //[FindsBy(How = How.Name, Using = "OK")]
        //public IWebElement OkButtonForDialog { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleSummOfTrans")]
		public IWebElement Summary_Of_Trans { get; set; }

		[FindsBy(How = How.Id, Using = "spnSCULEAmount")]
		public IWebElement SellerCreditUnroundedLoanEstimate { get; set; }

		[FindsBy(How = How.Id, Using = "spnAOCFinalAmount")]
		public IWebElement AdjustmentsCreditFinalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "sectionL_amt5")]
		public IWebElement SellerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "imgLoanPurpose")]
		public IWebElement Brokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "spnSCComments")]
		public IWebElement SeeSelleCreditsinSectionL { get; set; }

		[FindsBy(How = How.Id, Using = "imgSCChanged")]
		public IWebElement SeeSelleCreditsPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "tdCCCDefaultComment")]
		public IWebElement SeeSelleCreditsPopupCell { get; set; }

		[FindsBy(How = How.Id, Using = "tdCCCDefaultComment")]
		public IWebElement SeeDPPopupCell { get; set; }

		[FindsBy(How = How.Id, Using = "imgDPChanged")]
		public IWebElement DownPaymentPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "imgFBChanged")]
		public IWebElement FundsforBorrowerPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2971")]
		public IWebElement CalculatingCashToCloseSellercreditdefault_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2973")]
		public IWebElement CalculatingCashToClosePopupSellerCredits_other_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2673")]
		public IWebElement CalculatingCashToCloseSellerCreditsPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseCancel")]
		public IWebElement CalculatingCashToClosePopupSellerCredits_Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseDone")]
		public IWebElement CalculatingCashToClosePopupSellerCredits_Done { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2961")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerdefault_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2973")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerother_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseCancel")]
		public IWebElement CalculatingCashToClosePopupDPFundsfromborrower_Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseDone")]
		public IWebElement CalculatingCashToClosePopupDPFundsfromborrower_Done { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2670")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2969")]
		public IWebElement CalculatingCashToCloseFundsforborrowerdefault_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2973")]
		public IWebElement CalculatingCashToCloseFundsforborrowerother_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseCancel")]
		public IWebElement CalculatingCashToClosePopupFundsforborrower_Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseDone")]
		public IWebElement CalculatingCashToClosePopupFundsforborrower_Done { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2672")]
		public IWebElement CalculatingCashToCloseFundsforborrowerPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkDP")]
		public IWebElement DownPaymentfundsfromBorrowerBrokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkFB")]
		public IWebElement fundsforBorrowerBrokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkFB")]
		public IWebElement fundstoBorrowerBrokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkSC")]
		public IWebElement SellerCreditsBrokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitleAdjustablePayment")]
		public IWebElement APandAIRsection { get; set; }

		[FindsBy(How = How.Id, Using = "chkAptbl")]
		public IWebElement APtablecheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "InterestOnlyPayments")]
		public IWebElement Interestonlypaymentsdes { get; set; }

		[FindsBy(How = How.Id, Using = "OptionalPayments")]
		public IWebElement Optionalpaymentsdes { get; set; }

		[FindsBy(How = How.Id, Using = "StepPayments")]
		public IWebElement Steppaymentsdes { get; set; }

		[FindsBy(How = How.Id, Using = "SeasonalPayments")]
		public IWebElement Seasonalpaymentsdes { get; set; }

		[FindsBy(How = How.Id, Using = "spnIntPayment")]
		public IWebElement InterestonlyPaymentvaluespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnOptPayments")]
		public IWebElement OptionalPaymentvaluespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnStepPayments")]
		public IWebElement StepPaymentvaluespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnSeasonalPayments")]
		public IWebElement SeasonalPaymentvaluespan { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIntPayment")]
		public IWebElement Interestonlypaymentsselect { get; set; }

		[FindsBy(How = How.Id, Using = "ddlOptPayments")]
		public IWebElement Optionalpaymentsselect { get; set; }

		[FindsBy(How = How.Id, Using = "ddlStepPayments")]
		public IWebElement Steppaymentsselect { get; set; }

		[FindsBy(How = How.Id, Using = "ddlSeasonalPayments")]
		public IWebElement Seasonalpaymentsselect { get; set; }

		[FindsBy(How = How.Id, Using = "imgddlIntPayment")]
		public IWebElement IOPaymentPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "imgddlOptPayments")]
		public IWebElement OptionalPaymentPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "imgddlStepPayments")]
		public IWebElement StepPaymentPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "imgddlSeasonalPayments")]
		public IWebElement SeasonalPaymentPopupimage { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId1")]
		public IWebElement PSRadiobutton1 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId2")]
		public IWebElement PSRadiobutton2 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId3")]
		public IWebElement PSRadiobutton3 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId4")]
		public IWebElement PSRadiobutton4 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId5")]
		public IWebElement PSRadiobutton5 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId6")]
		public IWebElement PSRadiobutton6 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId7")]
		public IWebElement PSRadiobutton7 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId8")]
		public IWebElement PSRadiobuttonblank { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId1")]
		public IWebElement POption1editablespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId2")]
		public IWebElement PPOption2editablespan1 { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId3")]
		public IWebElement POption2editablespan2 { get; set; }

		[FindsBy(How = How.Id, Using = "ddlTest")]
		public IWebElement Poption3monthselect1 { get; set; }

		[FindsBy(How = How.Id, Using = "ddlTest2")]
		public IWebElement Poption3monthselect2 { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId6")]
		public IWebElement POption4editablespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId7")]
		public IWebElement POption5editablespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId8")]
		public IWebElement POption6editablespan { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId9")]
		public IWebElement POption7editablespan { get; set; }

		[FindsBy(How = How.Id, Using = "txtEighthOption")]
		public IWebElement POption8editabletextbox { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdjustableInterestCancel")]
		public IWebElement PCancelbutton { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdjustableInterestDone")]
		public IWebElement PDonebutton { get; set; }

        //[FindsBy(How = How.Id, Using = "imgddlOptPayments")]
        //public IWebElement OptionalPaymentPopupimage { get; set; }

        //[FindsBy(How = How.Id, Using = "imgddlStepPayments")]
        //public IWebElement StepPaymentPopupimage { get; set; }

        //[FindsBy(How = How.Id, Using = "imgddlSeasonalPayments")]
        //public IWebElement SeasonalPaymentPopupimage { get; set; }

        //[FindsBy(How = How.Id, Using = "optCCC2961")]
        //public IWebElement CalculatingCashToCloseDPFundsfromborrowerdefault_radiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2961")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerIncreaseinsectionK_1stradiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2962")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerIncreaseinsectionL_2ndradiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2963")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerIncreaseinsectionKandL_3rdradiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2964")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerdecreaseinsectionK_4thradiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2965")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerdecreaseinsectionL_5thradiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2966")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerdecreaseinsectionKandL_6thradiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2967")]
		public IWebElement CalculatingCashToCloseDPFundsfromborrowerchangeinsectionKandL_7thradiobutton { get; set; }

        //[FindsBy(How = How.Id, Using = "optCCC2973")]
        //public IWebElement CalculatingCashToCloseDPFundsfromborrowerother_radiobutton { get; set; }

        //[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseCancel")]
        //public IWebElement CalculatingCashToClosePopupDPFundsfromborrower_Cancel { get; set; }

        //[FindsBy(How = How.Id, Using = "btnCalculateCashToCloseDone")]
        //public IWebElement CalculatingCashToClosePopupDPFundsfromborrower_Done { get; set; }

        //[FindsBy(How = How.Id, Using = "txtCCCOther2670")]
        //public IWebElement CalculatingCashToCloseDPFundsfromborrowerPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPBCFinalAmount")]
		public IWebElement ClosingCost_PaidBefore_Final { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPBCLEAmount")]
		public IWebElement ClosingCost_PaidBefore_LE { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPBCULEAmount")]
		public IWebElement ClosingCost_PaidBefore_ULE { get; set; }

		[FindsBy(How = How.Id, Using = "spnDFinalAmount")]
		public IWebElement DepositR6C3_Final { get; set; }

		[FindsBy(How = How.Id, Using = "spnDLEAmount")]
		public IWebElement DepositR6C2_LoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnDULEAmount")]
		public IWebElement DepositR6C5_UnroundLoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnDYN")]
		public IWebElement DepositR6C4_Ans { get; set; }

		[FindsBy(How = How.LinkText, Using = "tdDComments")]
		public IWebElement DepositR5C3_Statement { get; set; }

		[FindsBy(How = How.Id, Using = "sectionL_amt1")]
		public IWebElement LOneDeposite { get; set; }

		[FindsBy(How = How.Id, Using = "imgDChanged")]
		public IWebElement DepositR6C3_Icon { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkD")]
		public IWebElement DepositR6C2_brokenlink { get; set; }

		[FindsBy(How = How.LinkText, Using = "See Deposit Section L.")]
		public IWebElement DepositR6C4_Statement1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "You decreased this payment.")]
		public IWebElement DepositR6C4_Statement2 { get; set; }

		[FindsBy(How = How.LinkText, Using = "You increased this payment.")]
		public IWebElement DepositR6C4_Statement3 { get; set; }

		[FindsBy(How = How.Id, Using = "spnDComments")]
		public IWebElement DepositR6C4_Statement4 { get; set; }

		[FindsBy(How = How.LinkText, Using = "See Deposit in Section L.")]
		public IWebElement DepositR6C4_Statement5 { get; set; }

		[FindsBy(How = How.Id, Using = "spnDPFinalAmount")]
		public IWebElement DPFBR5C3_Final { get; set; }

		[FindsBy(How = How.Id, Using = "spnDPLEAmount")]
		public IWebElement DPFBR5C2_LoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnDPULEAmount")]
		public IWebElement DPFBR5C5_UnroundLoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnDPYN")]
		public IWebElement DPFBR5C4_Ans { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPFinalAmount")]
		public IWebElement CCPBCR3C3_Final { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPLEAmount")]
		public IWebElement CCPBCR3C2_LoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPULEAmount")]
		public IWebElement CCPBCR3C5_UnroundLoanEst { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPBCYN")]
		public IWebElement CCPBCR3C4_Ans { get; set; }

		[FindsBy(How = How.LinkText, Using = "You paid these Closing Costs before closing.")]
		public IWebElement CCPBCR3C4_Statement1 { get; set; }

		[FindsBy(How = How.Id, Using = "imgCCPChanged")]
		public IWebElement CCPBCR3C4_Icon { get; set; }

		[FindsBy(How = How.LinkText, Using = "/SMSFast/SMSMvc/Areas/MVCUtils/Images/broken_Link....")]
		public IWebElement DPFFBR5C2_brokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "tabDelivery")]
		public IWebElement DeliveryOptions { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement cboMethod { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "chkEstimated")]
		public IWebElement Estimated { get; set; }

		[FindsBy(How = How.Id, Using = "chkFinal")]
		public IWebElement Final { get; set; }

		[FindsBy(How = How.Id, Using = "chkAmended")]
		public IWebElement Amended { get; set; }

		[FindsBy(How = How.Id, Using = "chkRevised")]
		public IWebElement Revised { get; set; }

		[FindsBy(How = How.Id, Using = "chkCombined")]
		public IWebElement Combined { get; set; }

		[FindsBy(How = How.Id, Using = "selComCopies")]
		public IWebElement selComCopies { get; set; }

		[FindsBy(How = How.Id, Using = "chkCombinedSign")]
		public IWebElement CombinedSign { get; set; }

		[FindsBy(How = How.Id, Using = "chkBuyeronly")]
		public IWebElement Buyeronly { get; set; }

		[FindsBy(How = How.Id, Using = "selBuyerCopies")]
		public IWebElement selBuyerCopies { get; set; }

		[FindsBy(How = How.Id, Using = "chkBuyerSign")]
		public IWebElement BuyerSign { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelleronly")]
		public IWebElement Selleronly { get; set; }

		[FindsBy(How = How.Id, Using = "selSellerCopies")]
		public IWebElement selSellerCopies { get; set; }

		[FindsBy(How = How.Id, Using = "chkSellerSign")]
		public IWebElement SellerSign { get; set; }

		[FindsBy(How = How.Id, Using = "chkEOSign")]
		public IWebElement EOSign { get; set; }

		[FindsBy(How = How.Id, Using = "chk1100")]
		public IWebElement Section1100 { get; set; }

		[FindsBy(How = How.Id, Using = "tblCalculatingCashToClose")]
		public IWebElement altable { get; set; }

        //[FindsBy(How = How.Id, Using = "sectionL_amt1")]
        //public IWebElement LOneDeposite { get; set; }

		[FindsBy(How = How.Id, Using = "sectionL_amt2")]
		public IWebElement LTwoDeposite { get; set; }

		[FindsBy(How = How.Id, Using = "sectionL_amt3")]
		public IWebElement LThreeDeposite { get; set; }

		[FindsBy(How = How.Id, Using = "sectionL_amt4")]
		public IWebElement LFourDeposite { get; set; }

		[FindsBy(How = How.Id, Using = "sectionK_amt1")]
		public IWebElement KOneSPP { get; set; }

		[FindsBy(How = How.Id, Using = "sectionK_amt2")]
		public IWebElement KTwoSPAPP { get; set; }

		[FindsBy(How = How.Id, Using = "sectionK_amt4")]
		public IWebElement KFourBT { get; set; }

        //[FindsBy(How = How.LinkText, Using = "Final")]
        //public IWebElement CalculatingCashToCloseR1C3 { get; set; }

		[FindsBy(How = How.Id, Using = "spnLAFinalAmount")]
		public IWebElement LAFinalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnLALEAmount")]
		public IWebElement LALEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnLAULEAmount")]
		public IWebElement LAULEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnLAYN")]
		public IWebElement LoanAmt_Ans { get; set; }

		[FindsBy(How = How.Id, Using = "InterestRate")]
		public IWebElement LTInterestRate { get; set; }

		[FindsBy(How = How.Id, Using = "MonthlyPrincipalInterest")]
		public IWebElement LTPrincipleAndInterest { get; set; }

		[FindsBy(How = How.Id, Using = "25841")]
		public IWebElement LTLAClause1 { get; set; }

		[FindsBy(How = How.Id, Using = "25842")]
		public IWebElement LTLAClause2 { get; set; }

		[FindsBy(How = How.Id, Using = "25851")]
		public IWebElement LTIRClause1 { get; set; }

		[FindsBy(How = How.Id, Using = "25852")]
		public IWebElement LTIRClause2 { get; set; }

		[FindsBy(How = How.Id, Using = "25853")]
		public IWebElement LTIRClause3 { get; set; }

		[FindsBy(How = How.Id, Using = "25861")]
		public IWebElement LTPIClause1 { get; set; }

		[FindsBy(How = How.Id, Using = "25862")]
		public IWebElement LTPIClause2 { get; set; }

		[FindsBy(How = How.Id, Using = "25863")]
		public IWebElement LTPIClause3 { get; set; }

		[FindsBy(How = How.Id, Using = "25864")]
		public IWebElement LTPIClause4 { get; set; }

		[FindsBy(How = How.Id, Using = "25871")]
		public IWebElement LTPrepaymentPenalty { get; set; }

		[FindsBy(How = How.Id, Using = "LoanAmount")]
		public IWebElement LTLoanAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "This amount decreased.")]
		public IWebElement ATLoanAmount_Statement1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "This amount increased.")]
		public IWebElement ATLoanAmount_Statement2 { get; set; }

		[FindsBy(How = How.Id, Using = "imgLAChanged")]
		public IWebElement ATLoanAmountPlusIcon { get; set; }

		[FindsBy(How = How.Id, Using = "spnAOCLEAmount")]
		public IWebElement AOCLEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnAOCFinalAmount")]
		public IWebElement AOCFinalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnAOCULEAmount")]
		public IWebElement AOCULEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnAOCYN")]
		public IWebElement AOCYesNo { get; set; }

		[FindsBy(How = How.LinkText, Using = "Closing Disclosure")]
		public IWebElement CDSpan { get; set; }

		[FindsBy(How = How.Id, Using = "spnTCCLEAmount")]
		public IWebElement TCCLEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBLEAmount")]
		public IWebElement FFBLEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnSCLEAmount")]
		public IWebElement SellerCreditsLEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnTCCFinalAmount")]
		public IWebElement TCCFinalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBFinalAmount")]
		public IWebElement FFBFinalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnSCFinalAmount")]
		public IWebElement SCFinalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnTCCULEAmount")]
		public IWebElement TCCLEUNAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnTCCYN")]
		public IWebElement TCCAltTbleYesNo { get; set; }

		[FindsBy(How = How.Id, Using = "spBorrowerPaid")]
		public IWebElement TotalClosingCostsJBorrowerPaid { get; set; }

		[FindsBy(How = How.Id, Using = "spnTPPLEAmount")]
		public IWebElement TPPLEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnTPPFinalAmount")]
		public IWebElement TPPFAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnTPPULEAmount")]
		public IWebElement TPPULEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnTPPYN")]
		public IWebElement TPPYesNo { get; set; }

		[FindsBy(How = How.Id, Using = "lblSecTitlePayoffsandPayments")]
		public IWebElement PayoffsAndPaymentsExpnd { get; set; }

		[FindsBy(How = How.Id, Using = "ChargeDescr_0")]
		public IWebElement PPChargeDescription1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Enter value")]
		public IWebElement PPChargeDescription2 { get; set; }

		[FindsBy(How = How.Id, Using = "Amt_0")]
		public IWebElement PPChargeDescriptionAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "BlankRecordDynamic_2")]
		public IWebElement PPChargeDescriptionAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "PayoffsandPaymentsTotalAmount")]
		public IWebElement PPTotalAmount { get; set; }

		[FindsBy(How = How.Id, Using = "imgTPPChanged")]
		public IWebElement PayOffsPayments_Icon { get; set; }

		[FindsBy(How = How.LinkText, Using = "See Payoffs and Payments (K)")]
		public IWebElement PayOffsPayments_Statement1 { get; set; }

		[FindsBy(How = How.Id, Using = "chkFromBorrower")]
		public IWebElement CashToCloseFromBorrwChk { get; set; }

		[FindsBy(How = How.Id, Using = "chkToBorrower")]
		public IWebElement CashToCloseToBorrwChk { get; set; }

		[FindsBy(How = How.Id, Using = "chkFromBorrowerClosingCost")]
		public IWebElement CTCFromChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "chkToBorrowerClosingCost")]
		public IWebElement CTCToChkBox { get; set; }

		[FindsBy(How = How.Id, Using = "CashToCloseDetail")]
		public IWebElement CashToCloseFromToChkBoxDetails { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId1")]
		public IWebElement InterestOnlyPaymentId1 { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdjustableInterestDone")]
		public IWebElement InterestOnlyPaymentsDone { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId2")]
		public IWebElement InterestOnlyPaymentsrd2 { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId2")]
		public IWebElement InterestOnlyPaymentId2 { get; set; }

		[FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId3")]
		public IWebElement InterestOnlyPaymentId3 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId3")]
		public IWebElement InterestOnlyPaymentsrd3 { get; set; }

        //[FindsBy(How = How.Id, Using = "ddlTest")]
        //public IWebElement Poption3monthselect1 { get; set; }

        //[FindsBy(How = How.Id, Using = "ddlTest2")]
        //public IWebElement Poption3monthselect2 { get; set; }

		[FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId8")]
		public IWebElement InterestOnlyPaymentsrd8 { get; set; }

		[FindsBy(How = How.Id, Using = "txtEighthOption")]
		public IWebElement InterestOnlyPaymentsEighthtextbox { get; set; }

		[FindsBy(How = How.Id, Using = "spanLenderUpdate")]
		public IWebElement LenderUpdate { get; set; }

		[FindsBy(How = How.Id, Using = "spanOtherUpdate")]
		public IWebElement OtherCDDataUpdate { get; set; }

		[FindsBy(How = How.Id, Using = "lblPendingCount")]
		public IWebElement PendingCount { get; set; }

		[FindsBy(How = How.Id, Using = "lblLoanPurpose")]
		public IWebElement LIPurpose { get; set; }

		[FindsBy(How = How.Id, Using = "lblLoanProduct1")]
		public IWebElement LIProduct1 { get; set; }

		[FindsBy(How = How.Id, Using = "chkConventional")]
		public IWebElement LILoanTypeConventional { get; set; }

		[FindsBy(How = How.Id, Using = "chkFHA")]
		public IWebElement LILoanTypeFHA { get; set; }

		[FindsBy(How = How.Id, Using = "chkVA")]
		public IWebElement LILoanTypeVA { get; set; }

		[FindsBy(How = How.Id, Using = "chkOthers")]
		public IWebElement LILoanTypeOthers { get; set; }

		[FindsBy(How = How.Id, Using = "lblLoanId")]
		public IWebElement LILoanIDNo { get; set; }

		[FindsBy(How = How.Id, Using = "lblMIC")]
		public IWebElement LIMICNo { get; set; }

		[FindsBy(How = How.Id, Using = "img_3010")]
		public IWebElement LoanTermsUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3011")]
		public IWebElement ProjectedPaymentsUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3072")]
		public IWebElement LoanDisclosuresUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3074")]
		public IWebElement LoanCalculationUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3076")]
		public IWebElement OtherDisclosuresUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3077")]
		public IWebElement ContactInformationUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3007")]
		public IWebElement ClosingInfoUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3009")]
		public IWebElement LoanInfoUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3014")]
		public IWebElement SectionAUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3015")]
		public IWebElement SectionBUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3016")]
		public IWebElement SectionCUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3061")]
		public IWebElement SectionFUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3062")]
		public IWebElement SectionGUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3063")]
		public IWebElement SectionHUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3065")]
		public IWebElement SectionJUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3068")]
		public IWebElement SectionKUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3069")]
		public IWebElement SectionLUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3070")]
		public IWebElement SectionMUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3071")]
		public IWebElement SectionNUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3073")]
		public IWebElement APTableUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3074")]
		public IWebElement AIRTableUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3000")]
		public IWebElement APAIRSectionUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3067")]
		public IWebElement SummariesofTansSectionUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3013")]
		public IWebElement LoanCostsSectionUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3018")]
		public IWebElement OtherCostsSectionUpdatesIcon { get; set; }

		[FindsBy(How = How.Id, Using = "img_3060")]
		public IWebElement SectionEUpdatesIcon { get; set; }

		[FindsBy(How = How.LinkText, Using = "/SMSFast/SMSMvc/Areas/MVCUtils/Images/broken_Link....")]
		public IWebElement TotalPayoffsAndPayments_brokenlink { get; set; }

		[FindsBy(How = How.LinkText, Using = "$0 From To Borrower")]
		public IWebElement CashToCloseTotalLoanEstimate { get; set; }

		[FindsBy(How = How.LinkText, Using = "$0 From To Borrower")]
		public IWebElement CashToCloseTotalFinal { get; set; }

		[FindsBy(How = How.LinkText, Using = "Closing Costs Financed (Paid from your Loan Amount)")]
		public IWebElement CashToCloseTotalDidThisChg { get; set; }

		[FindsBy(How = How.LinkText, Using = "See Total Other Costs (I)")]
		public IWebElement TotalClosingCosts_Statement1 { get; set; }

		[FindsBy(How = How.LinkText, Using = "See Total Loan Cost (D) and Total Other Costs (I)")]
		public IWebElement TotalClosingCosts_Statement2 { get; set; }

		[FindsBy(How = How.LinkText, Using = "Increase exceeds legal limits by $50.00. See Lender Credits on page 2 for credit of excess amount.")]
		public IWebElement TotalClosingCosts_Statement3 { get; set; }

		[FindsBy(How = How.LinkText, Using = "See Total Loan Costs (D)")]
		public IWebElement TotalClosingCosts_Statement4 { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkTPP")]
		public IWebElement TotalPayoffsPaymentsBrokenLink { get; set; }

		[FindsBy(How = How.Id, Using = "spnTCCComments")]
		public IWebElement TCCComments { get; set; }

		[FindsBy(How = How.Id, Using = "imgAIRPopUp")]
		public IWebElement AIRPopUpIcon { get; set; }

		[FindsBy(How = How.Id, Using = "imgddlMonthlyPayments")]
		public IWebElement APMonthlyPaymentsPopUpIcon { get; set; }

		[FindsBy(How = How.LinkText, Using = "See details in Sections K and L.")]
		public IWebElement AdjOthCredits_Statement1 { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkAOC")]
		public IWebElement AandOC_brokenlink { get; set; }

		[FindsBy(How = How.Id, Using = "imgSettlementAgent")]
		public IWebElement SettlementAgentIMG { get; set; }

		[FindsBy(How = How.Id, Using = "spnLAComments")]
		public IWebElement LAComments { get; set; }

		[FindsBy(How = How.Id, Using = "tdLAComments")]
		public IWebElement AltLAComments { get; set; }

		[FindsBy(How = How.Id, Using = "sectionK_amt3")]
		public IWebElement KThreeSPAPP { get; set; }

		[FindsBy(How = How.Id, Using = "imgTCCOverRide")]
		public IWebElement TCCOverRideIcon { get; set; }

		[FindsBy(How = How.Id, Using = "txtUnroundedLoanEstimate")]
		public IWebElement TCCLEUnroundedTxt { get; set; }

		[FindsBy(How = How.Id, Using = "txtLoanEstimate")]
		public IWebElement TCCLETxt { get; set; }

		[FindsBy(How = How.Id, Using = "chkOverrideLoanEstimate")]
		public IWebElement OverrideLEAmtsChk { get; set; }

		[FindsBy(How = How.Id, Using = "btnOverideCancel")]
		public IWebElement OverrideCancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnOverrideDone")]
		public IWebElement OverrideDone { get; set; }

		[FindsBy(How = How.Id, Using = "btnCloseOverridePopup")]
		public IWebElement OverrideExit { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBULEAmount")]
		public IWebElement FundsForBorrLEUnrounded { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBYN")]
		public IWebElement FFBYN { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkTCC")]
		public IWebElement TotalClosingCostsOverrideBrokenLink { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2668")]
		public IWebElement CCTCOverride_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "imgTCCChanged")]
		public IWebElement TCCStatementIcon { get; set; }

		[FindsBy(How = How.Id, Using = "optCCC2955")]
		public IWebElement rbTotalLoanCostsD { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBULEAmount")]
		public IWebElement FFBULEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBYN")]
		public IWebElement FFBYesNo { get; set; }

		[FindsBy(How = How.Id, Using = "spnFBComments")]
		public IWebElement FFBStatement { get; set; }

		[FindsBy(How = How.Id, Using = "spnDPComments")]
		public IWebElement DPFFBStatement { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCFComments")]
		public IWebElement CCFStatement { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2611")]
		public IWebElement CalculatingCashToCloseCCFPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "spnAOCComments")]
		public IWebElement AdjCrdStatement { get; set; }

		[FindsBy(How = How.Id, Using = "imgAOCChanged")]
		public IWebElement AdjCrdIcon { get; set; }

		[FindsBy(How = How.Id, Using = "spnSCYN")]
		public IWebElement SCYesNo { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkTCC")]
		public IWebElement OverrideBrokenImage { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2674")]
		public IWebElement AdjandOtherCreditsPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "spnCCPComments")]
		public IWebElement CCPBCStatement { get; set; }

		[FindsBy(How = How.Id, Using = "txtCCCOther2671")]
		public IWebElement CCToCDepositPopup_other_textbox { get; set; }

		[FindsBy(How = How.Id, Using = "brokenLinkLA")]
		public IWebElement LoanAmountBrokenLink { get; set; }

		[FindsBy(How = How.Id, Using = "spnTPPComments")]
		public IWebElement TPandPStatement { get; set; }

		[FindsBy(How = How.Id, Using = "spnCToCLEAmount")]
		public IWebElement CashToCloseLoanEst { get; set; }

        [FindsBy(How = How.Id, Using = "lblFinalPayment3")]
        public IWebElement BalloonPaymentHeader { get; set; }
		#endregion

	}
}
