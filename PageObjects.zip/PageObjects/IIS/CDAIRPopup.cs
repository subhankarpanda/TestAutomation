using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDAIRPopup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "spnIndexMargin")]
		public IWebElement IndexMarginlbl { get; set; }

		[FindsBy(How = How.Id, Using = "txtOther")]
		public IWebElement ManualEntryTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "txtMargin")]
		public IWebElement MarginTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "spnIIRateValue")]
		public IWebElement IntialInterestRateValue { get; set; }

		[FindsBy(How = How.Id, Using = "txtMinimumInterest")]
		public IWebElement MinimumInterestTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaximumInterest")]
		public IWebElement MaximumInterestTextBox { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstChange")]
		public IWebElement FirstChangeChngFrequency { get; set; }

		[FindsBy(How = How.Id, Using = "txtEvery")]
		public IWebElement SubsequentChangeTxtOne { get; set; }

		[FindsBy(How = How.Id, Using = "txtForNMonth")]
		public IWebElement SubsequentChangeTxtTwo { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirst")]
		public IWebElement LIRCFirstChange { get; set; }

		[FindsBy(How = How.Id, Using = "txtSubsequent")]
		public IWebElement LIRCSubsequentChange { get; set; }

		[FindsBy(How = How.Id, Using = "btnAIRPopUpDone")]
		public IWebElement AIRPopupDone { get; set; }

		[FindsBy(How = How.Id, Using = "btnAIRPopUpCancel")]
		public IWebElement AIRPopupCancel { get; set; }

		[FindsBy(How = How.Id, Using = "ddlIndexDescription")]
		public IWebElement IndexDescriptionDropDown { get; set; }

		[FindsBy(How = How.Id, Using = "txtIARFirst")]
		public IWebElement IRATextboxOne { get; set; }

		[FindsBy(How = How.Id, Using = "txtIARSecond")]
		public IWebElement IRATextboxTwo { get; set; }

		#endregion

	}
}
