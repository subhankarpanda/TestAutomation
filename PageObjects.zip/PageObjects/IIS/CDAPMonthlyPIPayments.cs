using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDAPMonthlyPIPayments : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnMonthlyPaymentDone")]
		public IWebElement APMonthlyPaymentDone { get; set; }

		[FindsBy(How = How.Id, Using = "btnMonthlyPaymentCancel")]
		public IWebElement APMonthlyPaymentCancel { get; set; }

		[FindsBy(How = How.Id, Using = "rdoFirstChargeAmount1")]
		public IWebElement FirstChangeAmountRbOne { get; set; }

		[FindsBy(How = How.Id, Using = "rdoFirstChargeAmount2")]
		public IWebElement FirstChangeAmountRbTwo { get; set; }

		[FindsBy(How = How.Id, Using = "rdoSubsequentChange1")]
		public IWebElement SubsequentChangeAmountRbOne { get; set; }

		[FindsBy(How = How.Id, Using = "rdoSubsequentChange2")]
		public IWebElement SubsequentChangeAmountRbTwo { get; set; }

		[FindsBy(How = How.Id, Using = "rdoSubsequentChange3")]
		public IWebElement SubsequentChangeAmountRbThree { get; set; }

		[FindsBy(How = How.Id, Using = "rdoMaximumPayment1")]
		public IWebElement MaximumPaymentRbOne { get; set; }

		[FindsBy(How = How.Id, Using = "rdoMaximumPayment2")]
		public IWebElement MaximumPaymentRbTwo { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstChargeAmount1")]
		public IWebElement FirstChangeAmtTxtOne { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstChargeAmount2")]
		public IWebElement FirstChangeAmtTxtTwo { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstChargeAmount3")]
		public IWebElement FirstChangeAmtTxtThree { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstChargeAmount4")]
		public IWebElement FirstChangeAmtTxtFour { get; set; }

		[FindsBy(How = How.Id, Using = "txtFirstChargeAmount5")]
		public IWebElement FirstChangeAmtTxtFive { get; set; }

		[FindsBy(How = How.Id, Using = "txtSubsequentChange1")]
		public IWebElement SubsequentChangeOne { get; set; }

		[FindsBy(How = How.Id, Using = "txtSubsequentChange2")]
		public IWebElement SubsequentChangeTwo { get; set; }

		[FindsBy(How = How.Id, Using = "txtSubsequentChange3")]
		public IWebElement SubsequentChangeThree { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaximumPayment1")]
		public IWebElement MaximumPaymentOne { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaximumPayment2")]
		public IWebElement MaximumPaymentTwo { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaximumPayment3")]
		public IWebElement MaximumPaymentThree { get; set; }

		[FindsBy(How = How.Id, Using = "txtMaximumPayment4")]
		public IWebElement MaximumPaymentFour { get; set; }

		#endregion

	}
}
