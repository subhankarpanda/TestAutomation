using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDBorrowerInfo : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "tblBorrowerDetails")]
		public IWebElement BorrowerTable { get; set; }

		[FindsBy(How = How.Id, Using = "LoanApplicant0")]
		public IWebElement Borrower1LoanApplicant { get; set; }

		[FindsBy(How = How.Id, Using = "Name_1")]
		public IWebElement Borrower1Name { get; set; }

		[FindsBy(How = How.Id, Using = "tblborrowerCAddress_1")]
		public IWebElement Borrower1CATable { get; set; }

		[FindsBy(How = How.Id, Using = "tblborrowerFAddress_1")]
		public IWebElement Borrower1FATable { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoCAId0")]
		public IWebElement Borrower1CurrentAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoFAId0")]
		public IWebElement Borrower1ForwardingAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "LoanApplicant1")]
		public IWebElement Borrower2LoanApplicant { get; set; }

		[FindsBy(How = How.Id, Using = "Name_2")]
		public IWebElement Borrower2Name { get; set; }

		[FindsBy(How = How.Id, Using = "tblborrowerCAddress_2")]
		public IWebElement Borrower2CATable { get; set; }

		[FindsBy(How = How.Id, Using = "tblborrowerFAddress_2")]
		public IWebElement Borrower2FATable { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoCAId1")]
		public IWebElement Borrower2CurrentAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoFAId1")]
		public IWebElement Borrower2ForwardingAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "LoanApplicant2")]
		public IWebElement Borrower3LoanApplicant { get; set; }

		[FindsBy(How = How.Id, Using = "Name_3")]
		public IWebElement Borrower3Name { get; set; }

		[FindsBy(How = How.Id, Using = "tblborrowerCAddress_3")]
		public IWebElement Borrower3CATable { get; set; }

		[FindsBy(How = How.Id, Using = "tblborrowerFAddress_3")]
		public IWebElement Borrower3FATable { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoCAId2")]
		public IWebElement Borrower3CurrentAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "BorrowerInfoFAId2")]
		public IWebElement Borrower3ForwardingAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "btnBorrowerInfoDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnBorrowerInfoCancel")]
		public IWebElement Cancel { get; set; }

		#endregion

	}
}
