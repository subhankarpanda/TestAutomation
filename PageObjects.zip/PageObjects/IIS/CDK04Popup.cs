using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDK04Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "K4Heading1")]
		public IWebElement K04BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "K4Heading2")]
		public IWebElement K04BuyerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubSeqNo")]
		public IWebElement K04SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "K4Desc")]
		public IWebElement K04Description { get; set; }

		[FindsBy(How = How.Id, Using = "K4TotalAmt")]
		public IWebElement K04Amt { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubSeqNo1")]
		public IWebElement K04SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Desc1")]
		public IWebElement K04ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubTotalAmt1")]
		public IWebElement K04TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt11")]
		public IWebElement K04BuyerCharge1 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt21")]
		public IWebElement K04BuyerCredit1 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubSeqNo2")]
		public IWebElement K04SeqNo2 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Desc2")]
		public IWebElement K04ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubTotalAmt2")]
		public IWebElement K04TotalChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt12")]
		public IWebElement K04BuyerCharge2 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt22")]
		public IWebElement K04BuyerCredit2 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubSeqNo3")]
		public IWebElement K04SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Desc3")]
		public IWebElement K04ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubTotalAmt3")]
		public IWebElement K04TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt13")]
		public IWebElement K04BuyerCharge3 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt23")]
		public IWebElement K04BuyerCredit3 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubSeqNo4")]
		public IWebElement K04SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Desc4")]
		public IWebElement K04ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_SubTotalAmt4")]
		public IWebElement K04TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt14")]
		public IWebElement K04BuyerCharge4 { get; set; }

		[FindsBy(How = How.Id, Using = "K4SubCharge_Amt24")]
		public IWebElement K04BuyerCredit4 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
