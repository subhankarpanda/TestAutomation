using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDL03Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "L3Heading1")]
		public IWebElement L03Label { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubSeqNo")]
		public IWebElement L03SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "L3Desc")]
		public IWebElement L03Description { get; set; }

		[FindsBy(How = How.Id, Using = "L3TotalAmt")]
		public IWebElement L03Amt { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubSeqNo1")]
		public IWebElement L03SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Desc1")]
		public IWebElement L03ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubTotalAmt1")]
		public IWebElement L03TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Desc2")]
		public IWebElement L03ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Amt12")]
		public IWebElement L03ChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubSeqNo3")]
		public IWebElement L03SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Desc3")]
		public IWebElement L03ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Amt13")]
		public IWebElement L03ChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubTotalAmt3")]
		public IWebElement L03TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubSeqNo4")]
		public IWebElement L03SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Desc4")]
		public IWebElement L03ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Amt14")]
		public IWebElement L03ChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubTotalAmt4")]
		public IWebElement L03TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubSeqNo5")]
		public IWebElement L03SeqNo5 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Desc5")]
		public IWebElement L03ChargeDesc5 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Amt15")]
		public IWebElement L03ChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_SubTotalAmt5")]
		public IWebElement L03TotalChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Desc6")]
		public IWebElement L03ChargeDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc7")]
        public IWebElement L03ChargeDesc7 { get; set; }

		[FindsBy(How = How.Id, Using = "L3SubCharge_Amt16")]
		public IWebElement L03ChargeAmt6 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt17")]
        public IWebElement L03ChargeAmt7 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
