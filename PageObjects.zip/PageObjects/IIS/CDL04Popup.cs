using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDL04Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "L4Heading1")]
		public IWebElement L04Label { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubSeqNo")]
		public IWebElement L04SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "L4Desc")]
		public IWebElement L04Description { get; set; }

		[FindsBy(How = How.Id, Using = "L4TotalAmt")]
		public IWebElement L04Amt { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubSeqNo1")]
		public IWebElement L04SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Desc1")]
		public IWebElement L04ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Amt11")]
		public IWebElement L04ChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubTotalAmt1")]
		public IWebElement L04TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Desc2")]
		public IWebElement L04ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Amt12")]
		public IWebElement L04ChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubSeqNo3")]
		public IWebElement L04SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Desc3")]
		public IWebElement L04ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Amt13")]
		public IWebElement L04ChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubTotalAmt3")]
		public IWebElement L04TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubSeqNo4")]
		public IWebElement L04SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Desc4")]
		public IWebElement L04ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Amt14")]
		public IWebElement L04ChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubTotalAmt4")]
		public IWebElement L04TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubSeqNo5")]
		public IWebElement L04SeqNo5 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Desc5")]
		public IWebElement L04ChargeDesc5 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Amt15")]
		public IWebElement L04ChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_SubTotalAmt5")]
		public IWebElement L04TotalChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Desc6")]
		public IWebElement L04ChargeDesc6 { get; set; }

		[FindsBy(How = How.Id, Using = "L4SubCharge_Amt16")]
		public IWebElement L04ChargeAmt6 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
