using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDL06Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "L1Heading1")]
		public IWebElement L06Label { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubSeqNo")]
		public IWebElement L06SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "L1Desc")]
		public IWebElement L06Description { get; set; }

		[FindsBy(How = How.Id, Using = "L1TotalAmt")]
		public IWebElement L06Amt { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubSeqNo1")]
		public IWebElement L06SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc1")]
		public IWebElement L06ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt11")]
		public IWebElement L06ChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubTotalAmt1")]
		public IWebElement L06TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc2")]
		public IWebElement L06ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt12")]
		public IWebElement L06ChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubSeqNo3")]
		public IWebElement L06SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc3")]
		public IWebElement L06ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt13")]
		public IWebElement L06ChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubTotalAmt3")]
		public IWebElement L06TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubSeqNo4")]
		public IWebElement L06SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc4")]
		public IWebElement L06ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt14")]
		public IWebElement L06ChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubTotalAmt4")]
		public IWebElement L06TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubSeqNo5")]
		public IWebElement L06SeqNo5 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc5")]
		public IWebElement L06ChargeDesc5 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt15")]
		public IWebElement L06ChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_SubTotalAmt5")]
		public IWebElement L06TotalChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc6")]
		public IWebElement L06ChargeDesc6 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt16")]
		public IWebElement L06ChargeAmt6 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc7")]
		public IWebElement L06ChargeDesc7 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt17")]
		public IWebElement L06ChargeAmt7 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Desc8")]
		public IWebElement L06ChargeDesc8 { get; set; }

		[FindsBy(How = How.Id, Using = "L1SubCharge_Amt18")]
		public IWebElement L06ChargeAmt8 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
