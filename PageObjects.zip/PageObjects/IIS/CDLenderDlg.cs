﻿using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;


namespace FASTSelenium.PageObjects.IIS
{
    public class CDLenderDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtCdLenderName")]
        public IWebElement CdLenderName { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderAddress")]
        public IWebElement CdLenderAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderAddrLine1")]
        public IWebElement CdLenderAddrLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderAddrLine2")]
        public IWebElement CdLenderAddrLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderAddrLine3")]
        public IWebElement CdLenderAddrLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderAddrLine4")]
        public IWebElement CdLenderAddrLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderCity")]
        public IWebElement CdLenderCity { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderState")]
        public IWebElement CdLenderState { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderZip")]
        public IWebElement CdLenderZip { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderNMLSID")]
        public IWebElement CdLenderNMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderSTLicenseID")]
        public IWebElement CdLenderSTLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContact")]
        public IWebElement CdLenderContact { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContFirstName")]
        public IWebElement CdLenderContFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContLastName")]
        public IWebElement CdLenderContLastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContactNMLSID")]
        public IWebElement CdLenderContactNMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContactSTLicenseID")]
        public IWebElement CdLenderContactSTLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderEmail")]
        public IWebElement CdLenderEmail { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderPhone")]
        public IWebElement CdLenderPhone { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderPhoneExtension")]
        public IWebElement CdLenderPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDLenderRefresh")]
        public IWebElement CDLenderRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDLenderCancel")]
        public IWebElement CDLenderCancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDLenderDone")]
        public IWebElement CDLenderDone { get; set; }

        #endregion

        public CDLenderDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Lender", true, 15);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? CdLenderName);

            return this;
        }

        public CDLenderDlg WaitForDialogToLoad(IWebElement element = null)
        {
            this.WaitCreation(element ?? CDLenderDone);
            return this;
        }

    }
}
