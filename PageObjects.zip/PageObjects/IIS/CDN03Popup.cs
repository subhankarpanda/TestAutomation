using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDN03Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "N3Heading1")]
		public IWebElement N03Label { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubSeqNo")]
		public IWebElement N03SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "N3Desc")]
		public IWebElement N03Description { get; set; }

		[FindsBy(How = How.Id, Using = "N3TotalAmt")]
		public IWebElement N03Amt { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubSeqNo1")]
		public IWebElement N03SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Desc1")]
		public IWebElement N03ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt1")]
		public IWebElement N03TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Desc2")]
		public IWebElement N03ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Amt12")]
		public IWebElement N03ChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubSeqNo3")]
		public IWebElement N03SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Desc3")]
		public IWebElement N03ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Amt13")]
		public IWebElement N03ChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt3")]
		public IWebElement N03TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubSeqNo4")]
		public IWebElement N03SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Desc4")]
		public IWebElement N03ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Amt14")]
		public IWebElement N03ChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt4")]
		public IWebElement N03TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubSeqNo5")]
		public IWebElement N03SeqNo5 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Desc5")]
		public IWebElement N03ChargeDesc5 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Amt15")]
		public IWebElement N03ChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt5")]
		public IWebElement N03TotalChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Desc6")]
        public IWebElement N03ChargeDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc7")]
        public IWebElement N03ChargeDesc7 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_SubSeqNo4")]
        public IWebElement N03ChargeSubDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_SubSeqNo6")]
        public IWebElement N03ChargeSubDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt6")]
        public IWebElement N03ChargeSubAmt6 { get; set; }

		[FindsBy(How = How.Id, Using = "N3SubCharge_Amt16")]
		public IWebElement N03ChargeAmt6 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt17")]
        public IWebElement N03ChargeAmt17 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
