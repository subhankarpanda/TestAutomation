using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDN04Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "N4Heading1")]
		public IWebElement N04SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "N4Heading2")]
		public IWebElement N04SellerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubSeqNo")]
		public IWebElement N04SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "N4Desc")]
		public IWebElement N04Description { get; set; }

		[FindsBy(How = How.Id, Using = "N4TotalAmt")]
		public IWebElement N04Amt { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubCharge_Desc1")]
		public IWebElement N04ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubCharge_Amt11")]
		public IWebElement N04SellerCharge1 { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubCharge_Amt21")]
		public IWebElement N04SellerCredit1 { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubCharge_Desc2")]
		public IWebElement N04ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubCharge_Amt12")]
		public IWebElement N04SellerCharge2 { get; set; }

		[FindsBy(How = How.Id, Using = "N4SubCharge_Amt22")]
		public IWebElement N04SellerCredit2 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
