using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDN05Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "N5Heading1")]
		public IWebElement N05SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "N5Heading2")]
		public IWebElement N05SellerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubSeqNo")]
		public IWebElement N05SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "N5Desc")]
		public IWebElement N05Description { get; set; }

		[FindsBy(How = How.Id, Using = "N5TotalAmt")]
		public IWebElement N05Amt { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubCharge_Desc1")]
		public IWebElement N05ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubCharge_Amt11")]
		public IWebElement N05SellerCharge1 { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubCharge_Amt21")]
		public IWebElement N05SellerCredit1 { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubCharge_Desc2")]
		public IWebElement N05ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubCharge_Amt12")]
		public IWebElement N05SellerCharge2 { get; set; }

		[FindsBy(How = How.Id, Using = "N5SubCharge_Amt22")]
		public IWebElement N05SellerCredit2 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
