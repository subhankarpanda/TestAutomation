using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDN06Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "N6Heading1")]
		public IWebElement N06Label { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubSeqNo")]
		public IWebElement N06SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "N6Desc")]
		public IWebElement N06Description { get; set; }

		[FindsBy(How = How.Id, Using = "N6TotalAmt")]
		public IWebElement N06Amt { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubSeqNo1")]
		public IWebElement N06SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc1")]
		public IWebElement N06ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt11")]
		public IWebElement N06ChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubTotalAmt1")]
		public IWebElement N06TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc2")]
		public IWebElement N06ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt12")]
		public IWebElement N06ChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubSeqNo3")]
		public IWebElement N06SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc3")]
		public IWebElement N06ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt13")]
		public IWebElement N06ChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubTotalAmt3")]
		public IWebElement N06TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubSeqNo4")]
		public IWebElement N06SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc4")]
		public IWebElement N06ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt14")]
		public IWebElement N06ChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubTotalAmt4")]
		public IWebElement N06TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubSeqNo5")]
		public IWebElement N06SeqNo5 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc5")]
		public IWebElement N06ChargeDesc5 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt15")]
		public IWebElement N06ChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_SubTotalAmt5")]
		public IWebElement N06TotalChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc6")]
		public IWebElement N06ChargeDesc6 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt16")]
		public IWebElement N06ChargeAmt6 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Desc7")]
		public IWebElement N06ChargeDesc7 { get; set; }

		[FindsBy(How = How.Id, Using = "N6SubCharge_Amt17")]
		public IWebElement N06ChargeAmt7 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
