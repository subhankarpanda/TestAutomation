using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDN10Popup : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "N10Heading1")]
		public IWebElement N10Label { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubSeqNo")]
		public IWebElement N10SeqNo { get; set; }

		[FindsBy(How = How.Id, Using = "N10Desc")]
		public IWebElement N10Description { get; set; }

		[FindsBy(How = How.Id, Using = "N10TotalAmt")]
		public IWebElement N10Amt { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubSeqNo1")]
		public IWebElement N10SeqNo1 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Desc1")]
		public IWebElement N10ChargeDesc1 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Amt11")]
		public IWebElement N10ChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubTotalAmt1")]
		public IWebElement N10TotalChargeAmt1 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Desc2")]
		public IWebElement N10ChargeDesc2 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Amt12")]
		public IWebElement N10ChargeAmt2 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubSeqNo3")]
		public IWebElement N10SeqNo3 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Desc3")]
		public IWebElement N10ChargeDesc3 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Amt13")]
		public IWebElement N10ChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubTotalAmt3")]
		public IWebElement N10TotalChargeAmt3 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubSeqNo4")]
		public IWebElement N10SeqNo4 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Desc4")]
		public IWebElement N10ChargeDesc4 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Amt14")]
		public IWebElement N10ChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubTotalAmt4")]
		public IWebElement N10TotalChargeAmt4 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubSeqNo5")]
		public IWebElement N10SeqNo5 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Desc5")]
		public IWebElement N10ChargeDesc5 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Amt15")]
		public IWebElement N10ChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_SubTotalAmt5")]
		public IWebElement N10TotalChargeAmt5 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Desc6")]
		public IWebElement N10ChargeDesc6 { get; set; }

		[FindsBy(How = How.Id, Using = "N10SubCharge_Amt16")]
		public IWebElement N10ChargeAmt6 { get; set; }

		[FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
		public IWebElement Done { get; set; }

		#endregion

	}
}
