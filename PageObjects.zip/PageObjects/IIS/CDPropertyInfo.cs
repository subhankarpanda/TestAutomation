using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDPropertyInfo : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "spnHeader")]
		public IWebElement PopupLabel { get; set; }

		[FindsBy(How = How.Id, Using = "td_Property_1")]
		public IWebElement FirstPropertyNo { get; set; }

		[FindsBy(How = How.Id, Using = "divPropertyDetails_11")]
		public IWebElement FirstProperty { get; set; }

		[FindsBy(How = How.Id, Using = "divPropertyDetails_12")]
		public IWebElement FirstPropertyAL1 { get; set; }

		[FindsBy(How = How.Id, Using = "divPropertyDetails_13")]
		public IWebElement FirstPropertyAL2 { get; set; }

		[FindsBy(How = How.Id, Using = "td_Property_2")]
		public IWebElement SecondPropertyNo { get; set; }

		[FindsBy(How = How.Id, Using = "divPropertyDetails_21")]
		public IWebElement SecondProperty { get; set; }

		[FindsBy(How = How.Id, Using = "divPropertyDetails_22")]
		public IWebElement SecondPropertyAL1 { get; set; }

		[FindsBy(How = How.Id, Using = "btnPropertyOk")]
		public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine1")]
        public IWebElement Street1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine2")]
        public IWebElement Street2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine3")]
        public IWebElement Street3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine4")]
        public IWebElement Street4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtCity")]
        public IWebElement City { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_cboState")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtZip")]
        public IWebElement Zip { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_btnNewAdd")]
        public IWebElement GeneralNew { get; set; }
     
		#endregion

	}
}
