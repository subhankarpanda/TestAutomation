using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDSellerInfo : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "tblSellerDetails")]
		public IWebElement SellerTable { get; set; }

		[FindsBy(How = How.Id, Using = "Name_1")]
		public IWebElement Seller1Name { get; set; }

		[FindsBy(How = How.Id, Using = "tblsellerCAddress_1")]
		public IWebElement Seller1CATable { get; set; }

		[FindsBy(How = How.Id, Using = "tblsellerFAddress_1")]
		public IWebElement Seller1FATable { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoCAId0")]
		public IWebElement Seller1CurrentAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoFAId0")]
		public IWebElement Seller1ForwardingAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "Name_2")]
		public IWebElement Seller2Name { get; set; }

		[FindsBy(How = How.Id, Using = "tblsellerCAddress_2")]
		public IWebElement Seller2CATable { get; set; }

		[FindsBy(How = How.Id, Using = "tblsellerFAddress_2")]
		public IWebElement Seller2FATable { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoCAId1")]
		public IWebElement Seller2CurrentAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoFAId1")]
		public IWebElement Seller2ForwardingAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "Name_3")]
		public IWebElement Seller3Name { get; set; }

		[FindsBy(How = How.Id, Using = "tblsellerCAddress_3")]
		public IWebElement Seller3CATable { get; set; }

		[FindsBy(How = How.Id, Using = "tblsellerFAddress_3")]
		public IWebElement Seller3FATable { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoCAId2")]
		public IWebElement Seller3CurrentAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "SellerInfoFAId2")]
		public IWebElement Seller3ForwardingAddrRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "btnSellerInfoDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnSellerInfoCancel")]
		public IWebElement Cancel { get; set; }

		#endregion

	}
}
