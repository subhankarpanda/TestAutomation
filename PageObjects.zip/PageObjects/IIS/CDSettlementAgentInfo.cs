using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects
{
    public class CDSettlementAgentInfo : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "SettlementAgentId0")]
		public IWebElement SettlementAgent1RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "SettlementAgentId1")]
		public IWebElement SettlementAgent2RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "SettlementAgentId2")]
		public IWebElement SettlementAgent3RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "SettlementAgentId3")]
		public IWebElement SettlementAgent4RadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "tblSettlmentAgnt")]
		public IWebElement SettlementAgentTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnSettlementAgentDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnSettlementAgentCancel")]
		public IWebElement Cancel { get; set; }

		#endregion

	}
}
