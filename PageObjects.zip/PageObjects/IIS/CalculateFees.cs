using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
    public class CalculateFees : PageObject
    {
        #region WebElements



        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_0_btnLink")]
        public IWebElement AddLink { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tCF_tL1_ucTr_pnlTrans > table")]
        public IWebElement TransactionInfoTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tCF_tL2_ucRf_pnlRecords > table")]
        public IWebElement RecordingInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_dtEffective")]
        public IWebElement TransactionInformationRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_btnAddTitleProd")]
        public IWebElement TitleFeesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_btnRemoveTitleProd")]
        public IWebElement TitleFeesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_ddlTitlePrdcts1")]
        public IWebElement TitleFeesTitlePolicy { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_ddlRateTypes")]
        public IWebElement TitleFeesRateTypes { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_btnAddEnd")]
        public IWebElement EndorsementsAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_btnRemoveEnd")]
        public IWebElement EndorsementsRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_txtSplitPercntg")]
        public IWebElement SummarySplitPercentage3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_ddlTitlePrdcts2")]
        public IWebElement EndorsementsTitlePolicy { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_NoTitlePolicyEffectiveDate")]
        public IWebElement EndorsementsRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_grdEnd_0_btnEnd")]
        public IWebElement AddRemoveEndorsement1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_grdEnd_1_btnEnd")]
        public IWebElement AddRemoveEndorsement2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_btnAddRec")]
        public IWebElement RecordingFeesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_btnRemoveRec")]
        public IWebElement RecordingFeesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_ddlRecords")]
        public IWebElement RecordingFeesRecordingDocument { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_txtPages")]
        public IWebElement RecordingFeesPages { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_txtCAmnt")]
        public IWebElement RecordingFeesConsiderationAmount { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnNext")]
        public IWebElement Next { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_chkIsOTC")]
        public IWebElement SummaryOTC { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary")]
        public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_ddlChargeTo")]
        public IWebElement SummaryChargeTo { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_ddlChargeTo")]
        public IWebElement SummaryChargeTo2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_ddlChargeTo")]
        public IWebElement SummaryChargeTo3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_ddlOverride")]
        public IWebElement SummaryOverrideReason3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_txtAmnt")]
        public IWebElement SummaryOverrideAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_ddlOverride")]
        public IWebElement SummaryOverrideReason { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtAmnt")]
        public IWebElement SummaryOverrideAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtSplitPercntg")]
        public IWebElement SummarySplitPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_txtSplitPercntg")]
        public IWebElement SummarySplitPercentage2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtSpliAmnt")]
        public IWebElement SummarySplitAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_txtSpliAmnt")]
        public IWebElement SummarySplitAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_txtSpliAmnt")]
        public IWebElement SummarySplitAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtBuyerCharge")]
        public IWebElement SummaryBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtSellerCharge")]
        public IWebElement SummarySellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_lblTotalCharge")]
        public IWebElement SummaryTotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSTf_grTitlePrdcts_0_chkSimul")]
        public IWebElement TitleFeesSimultaneous { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL2_ucRf_grdRecords")]
        public IWebElement RecordingFeesAnswersTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL2_ucRf1_grdRecords")]
        public IWebElement RecordingFeesSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL2_ucRf_pnlRecords")]
        public IWebElement RecordingDocumentsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_lblFaccRate")]
        public IWebElement CalculatedRate { get; set; }

        //[FindsBy(How = How.Id, Using = "tCF_tL2_ucRf1_grdRecords_0_RFC_332_0")]
        [FindsBy(How = How.XPath, Using = "//table[@id='tCF_tL2_ucRf_grdRecords']/tbody//tr//td/table/tbody/tr[1]/td[2]/select")]
        public IWebElement Answer1 { get; set; }

        //[FindsBy(How = How.Id, Using = "tCF_tL2_ucRf1_grdRecords_0_RFC_555_0")]
        [FindsBy(How = How.XPath, Using = "//table[@id='tCF_tL2_ucRf_grdRecords']/tbody//tr//td/table/tbody/tr[2]/td[2]/input")]
        public IWebElement Answer2 { get; set; }

        //[FindsBy(How = How.Id, Using = "tCF_tL2_ucRf1_grdRecords_0_RFC_146_0")]
        [FindsBy(How = How.XPath, Using = "//table[@id='tCF_tL2_ucRf_grdRecords']/tbody//tr//td/table/tbody/tr[3]/td[2]/input")]
        public IWebElement Answer3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts")]
        public IWebElement TitleFeesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_3_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription4 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_3_ddlChargeTo")]
        public IWebElement SummaryChargeTo4 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_4_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription5 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_4_ddlChargeTo")]
        public IWebElement SummaryChargeTo5 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_4_ddlOverride")]
        public IWebElement SummaryOverrideReason5 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_4_txtAmnt")]
        public IWebElement SummaryOverrideAmount5 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_5_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription6 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_5_ddlChargeTo")]
        public IWebElement SummaryChargeTo6 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_6_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription7 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_6_ddlChargeTo")]
        public IWebElement SummaryChargeTo7 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_7_ddlFastFees")]
        public IWebElement SummaryFastFeeDescription8 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_7_ddlChargeTo")]
        public IWebElement SummaryChargeTo8 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtFACCDesc")]
        public IWebElement Fee1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_txtFACCDesc")]
        public IWebElement Fee2 { get; set; }

        [FindsBy(How = How.LinkText, Using = "DEED - Recording Fee")]
        public IWebElement Fee3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_txtFACCDesc")]
        public IWebElement Fee4 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_ddlOverride")]
        public IWebElement SummaryOverrideReason1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_txtAmnt")]
        public IWebElement SummaryOverrideAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL2_ucEnd1_grdEnd_0_E0_379")]
        public IWebElement EnterPriorAnswer { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_0_txtFACCDesc")]
        public IWebElement AssignmentofMortgage { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL2_ucEnd1_grdEnd_0_E0_313")]
        public IWebElement BasePremiumAmt { get; set; }

        [FindsBy(How = How.LinkText, Using = "Transaction Information")]
        public IWebElement FeeSection { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_ddlOverride")]
        public IWebElement SummaryOverrideReason2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_1_txtAmnt")]
        public IWebElement SummaryOverrideAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_grdEnd")]
        public IWebElement EndorsementTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_3_ddlOverride")]
        public IWebElement SummaryOverrideReason4 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_3_txtAmnt")]
        public IWebElement SummaryOverrideAmount4 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_grdRecords")]
        public IWebElement RecordingTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "lblFACCException")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSTr_dtEffective")]
        public IWebElement SummaryTransactionRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSEnd_grdEnd")]
        public IWebElement SummaryEndorsementsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSTr_txtAssociatedFileNum")]
        public IWebElement SummaryAssociatedFileNo { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSTr_txtAssociatedFileNum")]
        public IWebElement AssociatedFileNo { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_dtEffective")]
        public IWebElement TitleProductAndEndorsementRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_0_btnEnd")]
        public IWebElement AddEndorsementsButton_Product1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_2_btnEnd")]
        public IWebElement AddEndorsementsButton_Product2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_0_btnProd")]
        public IWebElement AddProduct2Button { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_1_btnProd")]
        public IWebElement AddProduct3Button { get; set; }        

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_btnAddEndorsement")]
        public IWebElement AddEndorsementWOProductBtn { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTf_grTitlePrdcts")]
        public IWebElement TitleProductAndEndrsmntTable { get; set; }
        #endregion

        #region Dynamic WebElements

        public IWebElement RecordingFeesDocument(int index)
        {
            if (!this.WaitCreation(FastDriver.WebDriver.FindElement(By.Id("tCF_tL1_ucRf_grdRecords_" + index)), continueOnFailure: true))
                throw new ElementNotVisibleException();
            return WebDriver.FindElement(By.Id("tCF_tL1_ucRf_grdRecords_" + index));
        }

        public IWebElement GetSummaryFeeDescription(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("tCF_tCS_ucCSFs_grCalcSummary_" + index + "_ddlFastFees"));
        }
        
        public IWebElement GetSummaryFeeChargeTo(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("tCF_tCS_ucCSFs_grCalcSummary_" + index + "_ddlChargeTo"));
        }
        
        public IWebElement GetSummaryFeeOverrideReason(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("tCF_tCS_ucCSFs_grCalcSummary_" + index + "_ddlOverride"));
        }
        
        public IWebElement GetSummaryFeeOverrideAmount(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("tCF_tCS_ucCSFs_grCalcSummary_" + index + "_txtAmnt"));
        }

        #endregion

        public CalculateFees WaitForScreenToLoad(IWebElement e = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(e ?? SummaryFastFeeDescription);

            return this;
        }

        #region WAIT FOR RATE EFFECTIVE DATE TO LOAD
        public CalculateFees WaitForRateEffectiveDateToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(TitleProductAndEndorsementRateEffectiveDate);
            return this;
        }
        #endregion
        #region SELECT TITLE POLICY
        public void SelectTitlePolicy(string Date, string TitlePolicy, string RateType)
        {
            if (Date != "")
                SelectRateEffectiveDate(Date);
            SelectTitleProduct(TitlePolicy);
            SelectRateType(RateType);
            PerformAddTitleProducts();
            FastDriver.CalculateFees.SwitchToContentFrame();
        }
        #endregion
        #region SELECT RATE EFFECTIVE DATE
        public void SelectRateEffectiveDate(string Date)
        {
            this.SwitchToContentFrame();
            WaitForRateEffectiveDateToLoad();
            TitleProductAndEndorsementRateEffectiveDate.Click();
            TitleProductAndEndorsementRateEffectiveDate.SendKeys(Date);
        }
        #endregion
        #region SELECT TITLE PRODUCT
        public void SelectTitleProduct(string TitlePolicy)
        {
            TitleFeesTitlePolicy.FASelectItemBySendingKeys(TitlePolicy);
        }
        #endregion
        #region SELECT RATE TYPE
        public void SelectRateType(string RateType)
        {
            TitleFeesRateTypes.FASelectItemBySendingKeys(RateType);
        }
        #endregion
        #region PERFORM ADD TITLE PRODUCT
        public void PerformAddTitleProducts()
        {
            TitleFeesAdd.FAClick();
        }
        #endregion
        #region PERFORM ADD ENDORSEMENT
        public void PerformAddEndorsement(List<string> Endorsment)
        {
            this.SwitchToContentFrame();
            AddEndorsementsButton_Product1.Click();//FAClick is not working...
            WebDriver.WaitForWindowAndSwitch("FACC Endorsements", true, 30);
            FastDriver.FACCEndorsementsDlg.SwitchToDialogContentFrame();
            FastDriver.FACCEndorsementsDlg.WaitCreation(FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable);
            foreach (string element in Endorsment)
            {
                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction("#2", element, "#1", TableAction.On);//ON instead of CLICK...
                FastDriver.FACCEndorsementsDlg.SwitchToDialogContentFrame();
            }
            FastDriver.DialogBottomFrame.ClickDone();
        }
        #endregion
        #region PERFORM ADD PRODUCT
        public void PerformAddProduct(string TitlePolicy, string Ratetype)
        {
            this.SwitchToContentFrame();
            AddProduct2Button.Click();
            Playback.Wait(5000);//Timeout Exception is frequently occuring 
            WebDriver.WaitForWindowAndSwitch("Title Policy Dialog");
            FastDriver.FACCProductsDlg.SwitchToDialogContentFrame();
            //FastDriver.FACCProductsDlg.WaitElementDisplayed(FastDriver.FACCProductsDlg.TitleProductDropDown, 20);
            //FastDriver.FACCProductsDlg.WaitCreation(FastDriver.FACCProductsDlg.TitleProductDropDown);
            WaitForDropdown(FastDriver.FACCProductsDlg.TitleProductDropDown);
            FastDriver.FACCProductsDlg.TitleProductDropDown.FASelectItemBySendingKeys(TitlePolicy);
            //FastDriver.FACCProductsDlg.WaitElementDisplayed(FastDriver.FACCProductsDlg.RateTypesDropDown, 20);
            WaitForDropdown(FastDriver.FACCProductsDlg.RateTypesDropDown);
            FastDriver.FACCProductsDlg.RateTypesDropDown.FASelectItemBySendingKeys(Ratetype);
            FastDriver.DialogBottomFrame.ClickDone();
            Reports.TestStep = "Product Dialog: Clicked Done";
        }
        #endregion

        public void WaitForDropdown(IWebElement DropDown)
        {
            this.WaitCreation(DropDown);
        }

        public CalculateFees waitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? RecordingFeesAdd);

            return this;
        }

        public void WaitForScreenToLoad()
        {
            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return (RecordingFeesRecordingDocument.Exists() && RecordingFeesRecordingDocument.Enabled) || (TitleFeesTitlePolicy.Exists() && TitleFeesTitlePolicy.Displayed && TitleFeesTitlePolicy.Enabled);
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
            });
        }

        public CalculateFees SelectRecordingFees(string RecordingDoc, string pages, string ConsiderationAmount)
        {
            waitForScreenToLoad();
            this.RecordingFeesRecordingDocument.FASelectItem(RecordingDoc);
            this.RecordingFeesPages.FASetText(pages + FAKeys.Tab);
            this.RecordingFeesConsiderationAmount.FASetText(ConsiderationAmount + FAKeys.Tab);
            this.RecordingFeesAdd.FAClick();
            return this;
        }

        public CalculateFees EnterRecordingFees(string recordingFee, string pages, string considerationAmt = null)
        {
            waitForScreenToLoad();
            RecordingFeesRecordingDocument.FASelectItem(recordingFee);
            RecordingFeesPages.FASetText(pages);
            RecordingFeesConsiderationAmount.FASetText(considerationAmt);
            RecordingFeesAdd.FAClick();
            Next.FAClick();
            waitForScreenToLoad(Answer1);
            Next.FAClick();
            WaitForCalculationSummaryScreenToLoad();
            return this;
        }

        public CalculateFees EnterCalculationSummaryData(string selIndex, string chargeTo, string overrideReason, string buyerCharge, string sellerCharge)
        {
            waitForScreenToLoad(SummaryTable);
            SummaryTable.PerformTableAction(2, 4, TableAction.SelectItemByIndex, selIndex);
            SummaryTable.PerformTableAction(2, 5, TableAction.SelectItem, chargeTo);
            SummaryTable.PerformTableAction(2, 6, TableAction.SelectItem, overrideReason);
            SummaryTable.PerformTableAction(2, 10, TableAction.SetText, buyerCharge);
            SummaryTable.PerformTableAction(2, 11, TableAction.SetText, sellerCharge);
            return this;
        }

        public void SelectTitleAndEndorsement(string titleProduct = "", string rateType = "")
        {
            this.WaitForScreenToLoad();

            if (titleProduct == "")
                this.TitleFeesTitlePolicy.FASelectItemByIndex(1);
            else
                this.TitleFeesTitlePolicy.FASelectItem(titleProduct);

            if (rateType == "")
                this.TitleFeesRateTypes.FASelectItemByIndex(0);
            else
                this.TitleFeesRateTypes.FASelectItem(rateType);

            this.TitleFeesAdd.FAClick();
        }

        public void AddSimultaneousProducts(int row = 2, string titleProduct = "", string rateType = "")
        {
            this.TitleFeesTable.PerformTableAction(row, 8, TableAction.Click);
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Title Policy Dialog", true, 20);
            FastDriver.AddSimultaneousProduct.WaitForScreenToLoad();

            if (titleProduct == "")
                FastDriver.AddSimultaneousProduct.TitleProduct.FASelectItemByIndex(1);
            else
                FastDriver.AddSimultaneousProduct.TitleProduct.FASelectItem(titleProduct);

            System.Threading.Thread.Sleep(5000);
            FastDriver.AddSimultaneousProduct.RateTypeLabel.FAClick(); //Click to trigger event

            if (rateType == "")
                FastDriver.AddSimultaneousProduct.RateType.FASelectItemByIndex(1);
            else
                FastDriver.AddSimultaneousProduct.RateType.FASelectItem(rateType);

            FastDriver.DialogBottomFrame.ClickDone();
        }

        public void AddEndorsementWOProduct(string EndorsementName = "")
        {
            this.WaitForScreenToLoad();
            this.AddEndorsementWOProductBtn.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("FACC Endorsements Dialog", true, 20);
            FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();

            if (EndorsementName == "")
                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(1, 1, TableAction.On);
            else
                FastDriver.FACCEndorsementsDlg.FACCEndorsementsTable.PerformTableAction(2, EndorsementName, 1, TableAction.On);

            FastDriver.DialogBottomFrame.ClickDone();
        }

        public void RemoveTitleFee(int row = 2)
        {
            this.WaitForScreenToLoad();
            this.TitleFeesTable.PerformTableAction(row, 2, TableAction.On);
            this.TitleFeesRemove.FAClick();
        }

        public void RemoveRecordingFee(int row = 2)
        {
            this.WaitForScreenToLoad();
            this.RecordingTable.PerformTableAction(2, 2, TableAction.On);
            this.RecordingFeesRemove.FAClick();
        }

        public void EditSummaryFee(int index, string description, string chargeTo, string overrideReason, string overrideAmount)
        {
            this.GetSummaryFeeDescription(index).FASelectItem(description);
            this.GetSummaryFeeChargeTo(index).FASelectItem(chargeTo);
            this.GetSummaryFeeOverrideReason(index).FASelectItem(overrideReason);
            this.GetSummaryFeeOverrideAmount(index).FASetText(overrideAmount);
        }

        public string[] SelectFeeFromSummaryTable(int row = 2, string chargeTo = "Buyer", string OverrideReason = "", string OverrideAmount = "100.00", bool titleFee = true, string splitPercent = "")
        {
            string[] returnedFee = new string[2];

            this.SwitchToContentFrame();
            this.WaitCreation(SummaryFastFeeDescription);
            this.SummaryTable.PerformTableAction(row, 4, TableAction.SelectItemByIndex, "1");
            this.SummaryTable.PerformTableAction(row, 5, TableAction.SelectItem, chargeTo);
            returnedFee[0] = this.SummaryTable.PerformTableAction(row, 4, TableAction.GetSelectedItem).Message.Clean();
            returnedFee[1] = this.SummaryTable.PerformTableAction(row, 3, TableAction.GetText).Message.Clean();

            if (OverrideReason != "")
            {
                this.SummaryTable.PerformTableAction(row, 6, TableAction.SelectItem, OverrideReason);
                this.SummaryTable.PerformTableAction(row, 7, TableAction.SetText, OverrideAmount + FAKeys.Tab);
                returnedFee[1] = OverrideAmount;
            }

            if (splitPercent != "")
            {
                this.SummaryTable.PerformTableAction(row, 8, TableAction.SetText, splitPercent + FAKeys.Tab);
            }

            return returnedFee;
        }

        public string[] SelectFeeFromSummaryTable(int row = 2, string feeDescription = "", string chargeTo = "")
        {
            string[] returnedFee = new string[2];

            this.SwitchToContentFrame();
            this.WaitCreation(SummaryFastFeeDescription);

            if (feeDescription == "")
                this.SummaryTable.PerformTableAction(row, 4, TableAction.SelectItemByIndex, "1");
            else
                this.SummaryTable.PerformTableAction(row, 4, TableAction.SelectItem, feeDescription);

            if (chargeTo == "")
                this.SummaryTable.PerformTableAction(row, 5, TableAction.SelectItemByIndex, "1");
            else
                this.SummaryTable.PerformTableAction(row, 5, TableAction.SelectItem, chargeTo);

            returnedFee[0] = this.SummaryTable.PerformTableAction(row, 4, TableAction.GetSelectedItem).Message.Clean();
            returnedFee[1] = this.SummaryTable.PerformTableAction(row, 3, TableAction.GetText).Message.Clean();

            return returnedFee;
        }
        //
        public string[] ModifyFeeDetailsFromSummaryTable(int row = 2, string chargeTo = "Buyer", string OverrideReason = "", string OverrideAmount = "100.00", string splitPercent = "")
        {
            string[] returnedFee = new string[2];
            this.SwitchToContentFrame();
            this.SummaryTable.PerformTableAction(row, 5, TableAction.SelectItem, chargeTo);
            returnedFee[1] = this.SummaryTable.PerformTableAction(row, 3, TableAction.GetText).Message.Clean();

            if (OverrideReason != "")
            {
                this.SummaryTable.PerformTableAction(row, 6, TableAction.SelectItem, OverrideReason);
                IWebElement Element = this.SummaryTable.PerformTableAction(row, 7, TableAction.GetCell).Element.FindElement(By.TagName("Input"));
                Element.Clear();
                //to handle pop up which appears when invoiced fees is modified
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                this.SwitchToContentFrame();
                Element.SendKeys(OverrideAmount);
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                this.SwitchToContentFrame();
                //to handle pop up which appears when invoiced fees is modified
                //if (!FastDriver.WebDriver.HandleDialogMessage(true, true).Clean().Equals("No dialog present"))
                //{
                //    this.SwitchToContentFrame();
                //    Element.SendKeys(OverrideAmount);
                //    FastDriver.WebDriver.HandleDialogMessage(true, true);
                //}
                returnedFee[1] = OverrideAmount;
            }

            if (splitPercent != "")
            {
                IWebElement Elemnt = this.SummaryTable.PerformTableAction(row, 8, TableAction.GetCell).Element.FindElement(By.TagName("Input"));
                Elemnt.FADoubleClick();
                Elemnt.FASetText(splitPercent);
              //  this.SummaryTable.PerformTableAction(row, 8, TableAction.SetTextByCellIndex, splitPercent);
                Playback.Wait(3000);
            }

            return returnedFee;

        }
        // Created this method so as to select fees based on its type
        public string[] SelectFeeFromSummaryTableBasedOnFeeType(int row = 2, string FeeType = "", string FeeDesc = "", string chargeTo = "", string OverrideReason = "", string OverrideAmount = "", string splitPercent = "")
        {
            string[] returnedFee = new string[2];

            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(SummaryFastFeeDescription);
                SelectViewMore(this.SummaryTable.PerformTableAction(row, 4, TableAction.GetCell).Element);
               // this.SummaryTable.PerformTableAction(row, 4, TableAction.SelectItemBySendkeys, "+");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Add Fee Dialog");
                FastDriver.FileFeesDlg.SwitchToDialogContentFrame();

                if (FeeType == "")
                    FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItemBySendingKeys("All");
                else
                    FastDriver.FileFeesDlg.lstSearchFeeTypes.FASelectItem(FeeType);
                if (FeeDesc != "")
                    FastDriver.FileFeesDlg.SearchFeeDesc.FASetText(FeeDesc);
                FastDriver.FileFeesDlg.FindNow.FAClick();
                Playback.Wait(2000);
                FastDriver.FileFeesDlg.WaitCreation(FastDriver.FileFeesDlg.FeesTable,true);
                FastDriver.FileFeesDlg.FeesTable.PerformTableAction(1, 1, TableAction.On);
                returnedFee[0] = FastDriver.FileFeesDlg.FeesTable.PerformTableAction(1, 2, TableAction.GetText).Message.Clean();
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
                //Hack: handle this error message ReferenceError:'m_SelectedfastFee' is undefined when runs script
                FastDriver.WebDriver.HandleDialogMessage(true,true,10,true);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                this.SwitchToContentFrame();
                this.SummaryTable.PerformTableAction(row, 4, TableAction.SelectItem, returnedFee[0]);
                //IWebElement ele=this.SummaryTable.PerformTableAction(row, 5, TableAction.GetCell, chargeTo).Element.FindElement(By.TagName("select"));
                //ele.FASelectItem("Buyer", true);
                //    string Message = FastDriver.WebDriver.HandleDialogMessage();
                //    if (Message.Clean().Equals("Please Select an override reason."))
                //    {                //if fees is not coming from FACC, we have to provide override reason 
                //        this.SwitchToContentFrame();
                //        this.SummaryTable.PerformTableAction(row, 6, TableAction.SelectItemByIndex,"2");
                //        this.SummaryTable.PerformTableAction(row, 7, TableAction.SetText, "0.00");
                //        this.SummaryTable.PerformTableAction(row, 5, TableAction.GetCell, chargeTo);
                //    }  

                if (OverrideReason != "")
                {
                    this.SummaryTable.PerformTableAction(row, 6, TableAction.SelectItem, OverrideReason);
                    this.SummaryTable.PerformTableAction(row, 7, TableAction.SetText, string.IsNullOrEmpty(OverrideAmount) ? "0.00" : OverrideAmount + FAKeys.Tab);
                    returnedFee[1] = OverrideAmount;
                }

                if (splitPercent != "")
                {
                    this.SummaryTable.PerformTableAction(row, 8, TableAction.SetText, splitPercent + FAKeys.Tab);
                }
                this.SummaryTable.PerformTableAction(row, 5, TableAction.SelectItem, chargeTo);
                returnedFee[1] = this.SummaryTable.PerformTableAction(row, 3, TableAction.GetText).Message.Clean();
                return returnedFee;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return returnedFee;
            }
        }

        public void ClickNext()
        {
            this.SwitchToContentFrame();
            this.Next.FAClick();
        }

        #region SELECT FAST FEE DESC AND CHARGE TO
        public void SelectFASTFeeDescAndChargeTo(string FeeDesc_TLP, string FeeDesc_TOP, string EndorsementDesc, string LenderChargeTo, string OwnerChargeTo, string EndoChargeTo)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryFastFeeDescription);

            if (FeeDesc_TLP != "")
            {
                SummaryFastFeeDescription.FASelectItemBySendingKeys(FeeDesc_TLP);
                SummaryChargeTo.FASelectItemBySendingKeys(LenderChargeTo);
            }
            if (FeeDesc_TOP != "")
            {
                SummaryFastFeeDescription2.FASelectItemBySendingKeys(FeeDesc_TOP);
                SummaryChargeTo2.FASelectItemBySendingKeys(OwnerChargeTo);
            }
            if (EndorsementDesc != "")
            {
                SummaryFastFeeDescription3.FASelectItemBySendingKeys(EndorsementDesc);
                SummaryChargeTo3.FASelectItemBySendingKeys(EndoChargeTo);
            }
        }
        #endregion

        public void WaitForCalculationSummaryScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryFastFeeDescription);
        }

        public CalculateFees SelectViewMore(IWebElement CellContainerElement) {
            CellContainerElement.FindElement(By.TagName("select")).FASelectItemBySendingKeys(0, lastFirst: true);
         
            return this;
        }
    }
}
