using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class ChangeFileStatusDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlFileStatus")]
        public IWebElement FileStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFeeDt")]
        public IWebElement FeeDate { get; set; }

        #endregion

        public ChangeFileStatusDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(FileStatus);
            return this;
        }

        public void ConfirmStatus(string status = "Open")
        {
            WaitForScreenToLoad();
            FileStatus.FASelectItem(status);
            FastDriver.DialogBottomFrame.ClickDone();
            WebDriver.SwitchToWindow(Support.FASTWindowName);
        }
    }
}
