using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.ObjectModel;
using OpenQA.Selenium.Interactions;
using System.Reflection;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class ChangeOwningOfficeRemoveServiceType : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkTitleService")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "chkEscrowService")]
        public IWebElement Escrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubEscrowService")]
        public IWebElement SubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "cbEscrowOO")]
        public IWebElement EscrowOwningOffice { get; set; }

        [FindsBy(How = How.Id, Using = "cbTitleOO")]
        public IWebElement TitleOwningOffice { get; set; }

        [FindsBy(How = How.LinkText, Using = "Service File: Current Available Funds is not $0.00. You cannot change the Escrow Owning Office or remove Escrow Service Type.")]
        public IWebElement ServiceError { get; set; }

        [FindsBy(How = How.LinkText, Using = "Service File: You cannot Change the Owning Office or Remove a service type when the file contains invoices in statuses Estimated, Estimated Adjusted, Final and Final Adjusted.")]
        public IWebElement InvoiceError { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement FeeError { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Ten99SError { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Ten99SError1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//body/span[@id='__FAFErrorMessageList']/ul/li")]
        public IWebElement ErrorMessagePane { get; set; }

        [FindsBy(How = How.Id, Using = "btnYes")]
        public IWebElement YesAssignWFTasks { get; set; }

        [FindsBy(How = How.Id, Using = "spnMessage")]
        public IWebElement changeofficemessage { get; set; }

        [FindsBy(How = How.Id, Using = "btnNo")]
        public IWebElement NoAssignWFTasks { get; set; }

        [FindsBy(How = How.Id, Using = "spnMessage")]
        public IWebElement Message { get; set; }

        #endregion

        public ChangeOwningOfficeRemoveServiceType WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Title);

            return this;
        }

        public ChangeOwningOfficeRemoveServiceType EscrowOwningOfficeSetSelected(string OptionToSelect)
        {
            EscrowOwningOffice.FireEvent(OptionToSelect);
            IWebElement newerasd = EscrowOwningOffice as IWebElement;

            var yiy = ((IJavaScriptExecutor)FastDriver.WebDriver).ExecuteScript("return arguments[0].fireEvent('onchange',document.createEventObject())", EscrowOwningOffice);

            foreach (System.Reflection.PropertyInfo propertyInfo in this.GetType().GetProperties())
            {
                object asd = propertyInfo.GetValue(this, null);
                try
                {
                    if (asd == EscrowOwningOffice)
                    {

                        var FindsByAttributeDataArray = propertyInfo.GetCustomAttributes(typeof(FindsByAttribute), true);
                        if (FindsByAttributeDataArray.Length > 0)
                        {
                            var findsByObject = (FindsByAttribute)FindsByAttributeDataArray[0];
                            Type thisType = typeof(By);
                            MethodInfo theMethod = thisType.GetMethod(findsByObject.How.ToString());
                            By asdasdasd = (By)theMethod.Invoke(this, new Object[] { findsByObject.Using });
                            IWebElement newer = FastDriver.WebDriver.FindElement(asdasdasd);
                            var yiya = ((IJavaScriptExecutor)FastDriver.WebDriver).ExecuteScript("return arguments[0].fireEvent('onchange',document.createEventObject())", newer);

                        }
                    }
                }
                catch (Exception)
                {
                }

            }

            return this;
        }
        public static object Execute(string script)
        {
            return ((IJavaScriptExecutor)FastDriver.WebDriver).ExecuteScript(script);
        }

        public bool IsAssignEscrowTasksDialogPresent()
        {
            try
            {
                WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
                return WebDriver.PageSource.Contains("Workflow Tasks");
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        public static string ChangeOwningOfficeRemovemessage;
    public ChangeOwningOfficeRemoveServiceType AssignEscrowTasksWindow()
        {
            Playback.Wait(5000);                                                                            //static wait
            WebDriver.SwitchTo().DefaultContent();
            this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            ChangeOwningOfficeRemovemessage = changeofficemessage.FAGetText();
            YesAssignWFTasks.FAClick();
            return this;
        }

    public string HandlingWarningmsg(string VerifyMessage, string Yes_No)
    {
        WebDriver.SwitchTo().DefaultContent();
        this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
        string ActualMessage = Message.FAGetText().ToString();
        if (Yes_No == "Yes")
        {
            YesAssignWFTasks.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true);
        }
        else { NoAssignWFTasks.FAClick(); }

        return ActualMessage;

    }
    }
}
