using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class CheckDetailsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtDesc")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "txtChkVoucherInfo")]
        public IWebElement VoucherInfo { get; set; }

        #endregion

        public CheckDetailsDlg WaitForScreenToLoad(string windowName = "Check Detail", IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Description);

            return this;
        }

    }
}
