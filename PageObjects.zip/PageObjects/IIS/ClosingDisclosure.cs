using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Windows.Input;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Diagnostics;
using FASTWCFHelpers;
using System.Xml;
using OpenQA.Selenium.Interactions;
namespace FASTSelenium.PageObjects
{
    public class ClosingDisclosure : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "divPrincipalInterestTypePopUp")]
        public IWebElement PrincipalInterestTypePopUp { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanProductDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "txtPIInterestOnlyTermYearsCount")]
        public IWebElement LoanTerm_PI_InterestOnly_Year { get; set; }

        [FindsBy(How = How.Id, Using = "tblCategoryTotal")]
        public IWebElement GoodFaith0and10TotalTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblCategoryTotal")]
        public IWebElement GoodFaith0and10Total { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_F")]
        public IWebElement OtherCostsSectionFTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkAcceptPayments")]
        public IWebElement AcceptPayments { get; set; }

        [FindsBy(How = How.Id, Using = "lblAddInfoAbtThisLoanTitle")]
        public IWebElement AdditionalonAboutThisLoan { get; set; }

        [FindsBy(How = How.Id, Using = "chkAllowAssumtion")]
        public IWebElement AllowAssumption { get; set; }

        [FindsBy(How = How.LinkText, Using = "Appraisal")]
        public IWebElement Appraisal { get; set; }

        [FindsBy(How = How.LinkText, Using = "are scheduled to make monthly payments t")]
        public IWebElement areschedulonthlypaymentst { get; set; }

        [FindsBy(How = How.Id, Using = "lblSettlementAgent")]
        public IWebElement SettlementAgentValue { get; set; }

        [FindsBy(How = How.LinkText, Using = "Assumption")]
        public IWebElement Assumption { get; set; }

        [FindsBy(How = How.LinkText, Using = "Assumption If you sell or transfer thi")]
        public IWebElement Assumptionllortransferthi { get; set; }

        [FindsBy(How = How.Id, Using = "lblBorrowerNameTitle")]
        public IWebElement Borrower { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement CDDone { get; set; }

        [FindsBy(How = How.Id, Using = "rblId_688")]
        public IWebElement RbNewLoanLender { get; set; }

        [FindsBy(How = How.Id, Using = "rblId_670")]
        public IWebElement RbNewMortgageBroker { get; set; }

        [FindsBy(How = How.Id, Using = "rblId_0")]
        public IWebElement RbNone { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrepaidInterestDone")]
        public IWebElement PrepaidInterestDone { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusOrgID: Lender or Mortgage Broker Business Party is required on New Loan 1 ")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "lblBorrowerName")]
        public IWebElement BorrowerName { get; set; }

        [FindsBy(How = How.Id, Using = "lblClosingDtTitle")]
        public IWebElement ClosingDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabClosingDisclosure")]
        public IWebElement tabClosingDisclosure { get; set; }

        [FindsBy(How = How.Id, Using = "lblClosingDisclosureTitle")]
        public IWebElement ClosingDisclosureTitle { get; set; }

        [FindsBy(How = How.Id, Using = "divSubSecClosingDisclosure")]
        public IWebElement ClosingInformation { get; set; }

        [FindsBy(How = How.LinkText, Using = "Contract Details")]
        public IWebElement ContractDetails { get; set; }

        [FindsBy(How = How.Id, Using = "lblConventionalTitle")]
        public IWebElement Conventional { get; set; }

        [FindsBy(How = How.Id, Using = "lblDtIssuedTitle")]
        public IWebElement DateIssued { get; set; }

        [FindsBy(How = How.LinkText, Using = "Demand Feature")]
        public IWebElement DemandFeature { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbursementDtTitle")]
        public IWebElement DisbursementDate { get; set; }

        [FindsBy(How = How.LinkText, Using = "does not accept any partial payments.")]
        public IWebElement doesnotaccpartialpayments { get; set; }

        [FindsBy(How = How.LinkText, Using = "does not have a demand feature.")]
        public IWebElement doesnothaveademandfeature { get; set; }

        [FindsBy(How = How.LinkText, Using = "do not have a negative amortization feat")]
        public IWebElement donothaveamortizationfeat { get; set; }

        [FindsBy(How = How.Id, Using = "chkDontAllowAssumption")]
        public IWebElement DontAllowAssumption { get; set; }

        [FindsBy(How = How.Id, Using = "lblFHATitle")]
        public IWebElement FHA { get; set; }

        [FindsBy(How = How.Id, Using = "lblFileNumTitle")]
        public IWebElement File { get; set; }

        [FindsBy(How = How.Id, Using = "lblFileNum")]
        public IWebElement FIleNumberValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblFixedRate")]
        public IWebElement FixedRate { get; set; }

        [FindsBy(How = How.LinkText, Using = "has a demand feature, which permits your")]
        public IWebElement hasademandhichpermitsyour { get; set; }

        [FindsBy(How = How.Id, Using = "chkHasDemandFeature")]
        public IWebElement HasDemandFeature { get; set; }

        [FindsBy(How = How.Id, Using = "chkHasNoDemandFeature")]
        public IWebElement HasNoDemandFeature { get; set; }

        [FindsBy(How = How.Id, Using = "chkHasScheduledPayments")]
        public IWebElement HasScheduledPayments { get; set; }

        [FindsBy(How = How.Id, Using = "chkHoldinSeparateAccount")]
        public IWebElement HoldinSeparateAccount { get; set; }

        [FindsBy(How = How.LinkText, Using = "If the property was appraised for your l")]
        public IWebElement Ifthepropepraisedforyourl { get; set; }

        [FindsBy(How = How.LinkText, Using = "If this loan is sold, your new lender ma")]
        public IWebElement Ifthisloanyournewlenderma { get; set; }

        [FindsBy(How = How.LinkText, Using = "If you borrow more than this property is")]
        public IWebElement Ifyouborronthispropertyis { get; set; }

        [FindsBy(How = How.LinkText, Using = "If your lender forecloses on this proper")]
        public IWebElement Ifyourlendsesonthisproper { get; set; }

        [FindsBy(How = How.LinkText, Using = "If your payment is more than 15 days lat")]
        public IWebElement Ifyourpaymrethan15dayslat { get; set; }

        [FindsBy(How = How.LinkText, Using = "If you sell or transfer this property to")]
        public IWebElement Ifyousellorthispropertyto { get; set; }

        [FindsBy(How = How.LinkText, Using = "Late Payment")]
        public IWebElement LatePayment { get; set; }

        [FindsBy(How = How.Id, Using = "lblBorrowerAddr")]
        public IWebElement lblBorrowerAddr { get; set; }

        [FindsBy(How = How.Id, Using = "lblBorrowerCSZ")]
        public IWebElement lblBorrowerCSZ { get; set; }

        [FindsBy(How = How.Id, Using = "lblClosingDt")]
        public IWebElement lblClosingDt { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbursementDt")]
        public IWebElement lblDisbursementDt { get; set; }

        [FindsBy(How = How.Id, Using = "lblDtIssued")]
        public IWebElement lblDtIssued { get; set; }

        [FindsBy(How = How.Id, Using = "lblLenderName")]
        public IWebElement lblLenderName { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.Id, Using = "lblLenderName2")]
        public IWebElement lblLenderName1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddr")]
        public IWebElement lblPropertyAddr { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyCSZ")]
        public IWebElement lblPropertyCSZ { get; set; }

        [FindsBy(How = How.Id, Using = "tblSellerDetails")]
        public IWebElement TableSeller1Name { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerAddr")]
        public IWebElement lblSellerAddr { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerAddrTitle")]
        public IWebElement lblSellerAddrTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerCSZ")]
        public IWebElement lblSellerCSZ { get; set; }

        [FindsBy(How = How.Id, Using = "LenderName")]
        public IWebElement Lender { get; set; }

        [FindsBy(How = How.Id, Using = "tblSubSecClosingDisclosure")]
        public IWebElement ClosingInfomrationTable { get; set; }

        [FindsBy(How = How.Id, Using = "divPropertyImg")]
        public IWebElement PropertyImg { get; set; }

        [FindsBy(How = How.Id, Using = "btnPropertyOk")]
        public IWebElement PropertyOk { get; set; }

        [FindsBy(How = How.Id, Using = "imgLenderDetails")]
        public IWebElement LenderPlus { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderName")]
        public IWebElement LenderName { get; set; }

        //[FindsBy(How = How.Id, Using = "txtCdLenderAddrLine1")]
        [FindsBy(How = How.Id, Using = "lblContInfoLenderAddress1")]
        public IWebElement LenderAddressLine1 { get; set; }

        //[FindsBy(How = How.Id, Using = "txtCdLenderAddrLine2")]
        [FindsBy(How = How.Id, Using = "lblContInfoLenderAddress2")]
        public IWebElement LenderAddressLine2 { get; set; }

        //[FindsBy(How = How.Id, Using = "txtCdLenderAddrLine3")]
        [FindsBy(How = How.Id, Using = "lblContInfoLenderAddress3")]
        public IWebElement LenderAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderAddrLine4")]
        public IWebElement LenderAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderCity")]
        public IWebElement LenderCity { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderState")]
        public IWebElement LenderState { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderZip")]
        public IWebElement LenderZip { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderNMLSID")]
        public IWebElement LenderNMLSId { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderSTLicenseID")]
        public IWebElement LenderLicenseId { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContFirstName")]
        public IWebElement LenderContactFirstName{ get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContLastName")]
        public IWebElement LenderContactLastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContactNMLSID")]
        public IWebElement LenderContactNMLSId { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderContactSTLicenseID")]
        public IWebElement LenderContactLicenseId { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderEmail")]
        public IWebElement LenderEmail { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderPhone")]
        public IWebElement LenderPhone { get; set; }

        [FindsBy(How = How.Id, Using = "txtCdLenderPhoneExtension")]
        public IWebElement LenderPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDLenderRefresh")]
        public IWebElement LenderRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDLenderDone")]
        public IWebElement LenderCDDone { get; set; }

        

        [FindsBy(How = How.Id, Using = "btnReset")]
        public IWebElement LenderCancel{ get; set; }

        [FindsBy(How = How.Id, Using = "btnLenderOk")]
        public IWebElement LenderDone { get; set; }

        [FindsBy(How = How.LinkText, Using = "Liability after Foreclosure")]
        public IWebElement LiabilityafterForeclosure { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanCalc")]
        public IWebElement LoanCalculations { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleOtherCosts")]
        public IWebElement Othercosts { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_E")]
        public IWebElement OCSectionETable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_E02Plus_E")]
        public IWebElement OCSectionEplusTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_H")]
        public IWebElement SectionHTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tblOtherCostSubSection_E tr:nth-child(2) td:nth-child(8) img")]
        public IWebElement OCSectionE_LEbrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_I")]
        public IWebElement OCSectionITable { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_G")]
        public IWebElement tblOtherCostSubSection_G { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanDisclosures")]
        public IWebElement LoanDisclosures { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_1")]
        public IWebElement SectionK_Expand { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_2")]
        public IWebElement SectionK_Expand_2 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_3")]
        public IWebElement SectionK_Expand_3 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_4")]
        public IWebElement SectionK_Expand_5 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_11")]
        public IWebElement SectionK_Expand_4 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeK4")]
        public IWebElement K04Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_N9")]
        public IWebElement N09Collapse { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_N11")]
        public IWebElement N11Collapse { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_L1")]
        public IWebElement L06Expand { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_N6")]
        public IWebElement SectionN06_gtr_icon { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrepaidInterestDone")]
        public IWebElement PrepaidDone { get; set; }

        [FindsBy(How = How.Id, Using = "imgPrepaidInterest")]
        public IWebElement PrepaidPlus { get; set; }

        [FindsBy(How = How.Id, Using = "lblPurchaseTitle")]
        public IWebElement Purposetitle { get; set; }

        [FindsBy(How = How.Id, Using = "imgLoanPurpose")]
        public IWebElement PurposePlus { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanPurpose")]
        public IWebElement PurposeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "divSubSecLoanInfo")]
        public IWebElement LoanInformation { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanTermTitle")]
        public IWebElement LoanTerm { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanTerm")]
        public IWebElement LoanTermValue { get; set; }

        [FindsBy(How = How.Id, Using = "imgLoanTerm")]
        public IWebElement LoanTermPlus { get; set; }

        [FindsBy(How = How.Id, Using = "divPopUpLoanTerm")]
        public IWebElement LoanTermPopup { get; set; }

        [FindsBy(How = How.Id, Using = "rdoLoanTermYearMonth")]
        public IWebElement LoanTermYearMonthRdobtn { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanTermYear")]
        public IWebElement LoanTermYearTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanTermYearMonth")]
        public IWebElement LoanTermMonthdropdown { get; set; }

        [FindsBy(How = How.Id, Using = "rdoLoanTermMonth")]
        public IWebElement LoanTermMonthRdobtn { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanTermMonth")]
        public IWebElement LoanTermMonthTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "rdoLoanTermOther")]
        public IWebElement LoanTermOtherRdobtn { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanTermOther")]
        public IWebElement LoanTermOtherTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanTermDone")]
        public IWebElement LoanTermDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanTermCancel")]
        public IWebElement LoanTermCancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanProductTitle")]
        public IWebElement ProductTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanProduct")]
        public IWebElement ProductVal { get; set; }

        [FindsBy(How = How.LinkText, Using = "closeLoan Product � Product: Adjustable")]
        public IWebElement closeLoanPoductAdjustable { get; set; }

        [FindsBy(How = How.Id, Using = "imgLoanProduct")]
        public IWebElement imgLoanProduct { get; set; }

        [FindsBy(How = How.LinkText, Using = "Product:")]
        public IWebElement Product { get; set; }

        [FindsBy(How = How.LinkText, Using = "Description:")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.LinkText, Using = "Loan Product")]
        public IWebElement LoanProduct { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanProduct")]
        public IWebElement LoanProductTypeCDID { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanProduct")]
        public IWebElement LoanProducttxt { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanProductCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanProductDone")]
        public IWebElement btnLoanProductDone { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanIdTitle")]
        public IWebElement LoanID { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanId")]
        public IWebElement LoanIDValue { get; set; }

        [FindsBy(How = How.LinkText, Using = "loanid")]
        public IWebElement loanid { get; set; }

        [FindsBy(How = How.Id, Using = "lblMICTitle")]
        public IWebElement MIC { get; set; }

        [FindsBy(How = How.Id, Using = "lblMIC")]
        public IWebElement MICValue { get; set; }

        [FindsBy(How = How.LinkText, Using = "micnum")]
        public IWebElement micnum { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanTypeTitle")]
        public IWebElement LoanTypePane { get; set; }

        [FindsBy(How = How.Id, Using = "chkConventional")]
        public IWebElement LoanTypeConventional { get; set; }

        [FindsBy(How = How.Id, Using = "chkFHA")]
        public IWebElement LoanTypeFHA { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanType")]
        public IWebElement LoanTypeOthersValue { get; set; }

        [FindsBy(How = How.Id, Using = "chkOthers")]
        public IWebElement LoanTypeOthers { get; set; }

        [FindsBy(How = How.Id, Using = "chkVA")]
        public IWebElement LoanTypeVA { get; set; }

        [FindsBy(How = How.Id, Using = "imgLoanType")]
        public IWebElement LoanTypePlus { get; set; }

        [FindsBy(How = How.Id, Using = "chkLoanTypeConventional")]
        public IWebElement LoanTypeConventionalEdit { get; set; }

        [FindsBy(How = How.Id, Using = "chkLoanTypeFHA")]
        public IWebElement LoanTypeFHAEdit { get; set; }

        [FindsBy(How = How.Id, Using = "chkLoanTypeVA")]
        public IWebElement LoanTypeVAEdit { get; set; }

        [FindsBy(How = How.Id, Using = "chkLoanTypeOthers")]
        public IWebElement LoanTypeOthersEdit { get; set; }

        [FindsBy(How = How.Id, Using = "txtOthersDesc")]
        public IWebElement LoanTypeOthersName { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanTypeDone")]
        public IWebElement LoantypeDone { get; set; }

        [FindsBy(How = How.Id, Using = "imgPopUpLoanIdDetails")]
        public IWebElement imgPopUpLoanIdDetails { get; set; }

        [FindsBy(How = How.Id, Using = "imgPopUpMicNumDetails")]
        public IWebElement imgPopUpMicNumDetails { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement mayacceptphatarelessthant { get; set; }

        [FindsBy(How = How.LinkText, Using = "may have monthly payments that do not pa")]
        public IWebElement mayhavemonentsthatdonotpa { get; set; }

        [FindsBy(How = How.Id, Using = "chkMayHaveScheduledPayments")]
        public IWebElement MayHaveScheduledPayments { get; set; }

        [FindsBy(How = How.LinkText, Using = "may hold them in a separate account unti")]
        public IWebElement mayholdtherateaccountunti { get; set; }

        [FindsBy(How = How.Id, Using = "lblMIC")]
        public IWebElement MICValue1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Negative Amortization(Increase in Loan A")]
        public IWebElement NegativeAmIncreaseinLoanA { get; set; }

        [FindsBy(How = How.Id, Using = "chkNoNegativeAmortization")]
        public IWebElement NoNegativeAmortization { get; set; }

        [FindsBy(How = How.Id, Using = "chkNoPartialPayments")]
        public IWebElement NoPartialPayments { get; set; }

        [FindsBy(How = How.Id, Using = "chkNotProtectedbyStateLaw")]
        public IWebElement NotProtectedbyStateLaw { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleOtherDiscc")]
        public IWebElement OtherDisclosures { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleContInfo")]
        public IWebElement ContactInformation { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleConfirmRecpt")]
        public IWebElement ConfirmReceipt { get; set; }

        [FindsBy(How = How.LinkText, Using = "Partial Payments(Increase in Loan Amount")]
        public IWebElement PartialPayaseinLoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblFixedRateTitle")]
        public IWebElement FixedRateTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddrTitle")]
        public IWebElement Property { get; set; }

        [FindsBy(How = How.Id, Using = "chkProtectedbyStateLaw")]
        public IWebElement ProtectedbyStateLaw { get; set; }

        [FindsBy(How = How.Id, Using = "lblPurchase")]
        public IWebElement Purchase { get; set; }

        [FindsBy(How = How.Id, Using = "lblPurchaseTitle")]
        public IWebElement lblPurposeTitle { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanPurposeDone")]
        public IWebElement PurposeDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanPurposeCancel")]
        public IWebElement PurposeCancel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanPurpose")]
        public IWebElement LoanPurposeTypeCDID { get; set; }

        [FindsBy(How = How.Id, Using = "imgLoanPurpose")]
        public IWebElement impLoanPurpose { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanPurpose")]
        public IWebElement txtLoanPurpose { get; set; }

        [FindsBy(How = How.LinkText, Using = "�")]
        public IWebElement Close { get; set; }

        [FindsBy(How = How.LinkText, Using = "close")]
        public IWebElement CloseIcon { get; set; }

        [FindsBy(How = How.LinkText, Using = "Refinance")]
        public IWebElement Refinance { get; set; }

        [FindsBy(How = How.LinkText, Using = "Refinancing this loan will depend on you")]
        public IWebElement Refinancinwilldependonyou { get; set; }

        [FindsBy(How = How.Id, Using = "lblSalePriceTitle")]
        public IWebElement SalePrice { get; set; }

        [FindsBy(How = How.Id, Using = "lblSalePrice")]
        public IWebElement SalePriceValue { get; set; }

        [FindsBy(How = How.LinkText, Using = "Security Interest")]
        public IWebElement SecurityInterest { get; set; }

        [FindsBy(How = How.LinkText, Using = "See your note and security instrument fo")]
        public IWebElement Seeyournotityinstrumentfo { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerNameTitle")]
        public IWebElement Seller { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerName")]
        public IWebElement SellerName { get; set; }

        [FindsBy(How = How.Id, Using = "lblSettlementAgentTitle")]
        public IWebElement SettlementAgent { get; set; }

        [FindsBy(How = How.LinkText, Using = "state law does not protect you from liab")]
        public IWebElement statelawdotectyoufromliab { get; set; }

        [FindsBy(How = How.LinkText, Using = "state law may protect you from liability")]
        public IWebElement statelawmaoufromliability { get; set; }

        [FindsBy(How = How.LinkText, Using = "Tax Deductions")]
        public IWebElement TaxDeductions { get; set; }

        [FindsBy(How = How.Id, Using = "divSubSecTransInfo")]
        public IWebElement TransactionInformation { get; set; }

        [FindsBy(How = How.Id, Using = "lblVATitle")]
        public IWebElement VA { get; set; }

        [FindsBy(How = How.LinkText, Using = "will not allow assumption of this loan o")]
        public IWebElement willnotalltionofthisloano { get; set; }

        [FindsBy(How = How.LinkText, Using = "You are granting a security interest in")]
        public IWebElement Youaregranurityinterestin { get; set; }

        [FindsBy(How = How.LinkText, Using = "You may lose this property if you do not")]
        public IWebElement Youmaylosepertyifyoudonot { get; set; }

        [FindsBy(How = How.LinkText, Using = "Your lender")]
        public IWebElement Yourlender { get; set; }

        [FindsBy(How = How.LinkText, Using = "Your Loan")]
        public IWebElement YourLoan { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCalCashToClose")]
        public IWebElement CalculatingCashtoClose { get; set; }

        [FindsBy(How = How.Id, Using = "spnCToCLEAmount")]
        public IWebElement CashtoCloseLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "tblCalculatingCashToClose")]
        public IWebElement CalculatingCashtoCloseTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tblOtherDisclosures")]
        public IWebElement tblOtherDisclosures { get; set; }

        [FindsBy(How = How.Id, Using = "tblAssumption")]
        public IWebElement tblAssumption { get; set; }

        [FindsBy(How = How.Id, Using = "tblDemandFeature")]
        public IWebElement tblDemandFeature { get; set; }

        [FindsBy(How = How.Id, Using = "tblLatePayment")]
        public IWebElement tblLatePayment { get; set; }

        [FindsBy(How = How.Id, Using = "tblNegativeAmortization")]
        public IWebElement tblNegativeAmortization { get; set; }

        [FindsBy(How = How.Id, Using = "tblPartialPayments")]
        public IWebElement tblPartialPayments { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanDisclosures")]
        public IWebElement tblLoanDisclosures { get; set; }

        [FindsBy(How = How.LinkText, Using = "Total of Payments. Total you will have pa")]
        public IWebElement TotalofPayalyouwillhavepa { get; set; }

        [FindsBy(How = How.Id, Using = "txtTotalofPayments")]
        public IWebElement TotalofPayments { get; set; }

        [FindsBy(How = How.LinkText, Using = "Finance Charge. The dollar amount the loa")]
        public IWebElement FinanceChalaramounttheloa { get; set; }

        [FindsBy(How = How.Id, Using = "txtFinanceCharge")]
        public IWebElement FinanceCharge { get; set; }

        [FindsBy(How = How.LinkText, Using = "Amount Financed. The loan amount availabl")]
        public IWebElement AmountFinanamountavailabl { get; set; }

        [FindsBy(How = How.LinkText, Using = "Total Interest Percentage (TIP). The tota")]
        public IWebElement TotalInterageTIPThetota { get; set; }

        [FindsBy(How = How.LinkText, Using = "?Questions? If you have questions about")]
        public IWebElement Questionsequestionsabout { get; set; }

        [FindsBy(How = How.Id, Using = "txtAmountFinanced")]
        public IWebElement AmountFinanced { get; set; }

        [FindsBy(How = How.Id, Using = "txtAnnualPercentageRate")]
        public IWebElement AnnualPercentageRate { get; set; }

        [FindsBy(How = How.Id, Using = "txtTotalInterestPercentage")]
        public IWebElement TotalInterestPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "imgLPAdd")]
        public IWebElement SMSFastSMSgesicon_breakAg { get; set; }

        [FindsBy(How = How.Id, Using = "sLatePaymentDays")]
        public IWebElement sLatePaymentDays { get; set; }

        [FindsBy(How = How.Id, Using = "sLatePaymentPercentORDollar")]
        public IWebElement sLatePaymentPercentORDollar { get; set; }

        [FindsBy(How = How.Id, Using = "sPercentofChargedesc")]
        public IWebElement sPercentofChargedesc { get; set; }

        [FindsBy(How = How.LinkText, Using = "closeLate Payment Details Number of d")]
        public IWebElement LatePaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "sNoOfDays")]
        public IWebElement Numberofdays { get; set; }

        [FindsBy(How = How.Id, Using = "txtNumberOfDays")]
        public IWebElement NumberOfDays { get; set; }

        [FindsBy(How = How.Id, Using = "sLatePaymentFee")]
        public IWebElement LatePaymentFee { get; set; }

        [FindsBy(How = How.Id, Using = "chkLatePaymentDollar")]
        public IWebElement LatePaymentDollar { get; set; }

        [FindsBy(How = How.Id, Using = "txtLatePaymentFeeDollar")]
        public IWebElement LatePaymentFeeDollar { get; set; }

        [FindsBy(How = How.Id, Using = "chkLatePaymentPercent")]
        public IWebElement LatePaymentPercent { get; set; }

        [FindsBy(How = How.Id, Using = "txtLatePaymentFeePercent")]
        public IWebElement LatePaymentFeePercent { get; set; }

        [FindsBy(How = How.Id, Using = "btnFTCancel")]
        public IWebElement CancelQ { get; set; }

        [FindsBy(How = How.Id, Using = "btnFTDone")]
        public IWebElement btnFTDone { get; set; }

        [FindsBy(How = How.Id, Using = "imgSeller")]
        public IWebElement SellerPlus { get; set; }

        [FindsBy(How = How.Id, Using = "imgSettlementAgent")]
        public IWebElement SettlementAgentPlus { get; set; }

        [FindsBy(How = How.Id, Using = "SecondarySettlementAgentID1")]
        public IWebElement SecondSettlementAgent { get; set; }

        [FindsBy(How = How.Id, Using = "divMicNum")]
        public IWebElement MICDisplay { get; set; }

        [FindsBy(How = How.Id, Using = "divLoanId")]
        public IWebElement LoanIdDisplay { get; set; }

        [FindsBy(How = How.Id, Using = "imgMicNumDetails")]
        public IWebElement MICCodePlus { get; set; }

        [FindsBy(How = How.Id, Using = "imgLoanIdDetails")]
        public IWebElement LoanIdPlus { get; set; }

        [FindsBy(How = How.Id, Using = "imgBorrower")]
        public IWebElement BorrowerPlus { get; set; }

        [FindsBy(How = How.Id, Using = "imgProperty")]
        public IWebElement PropertyPlus { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanTerms")]
        public IWebElement Section2_LoanTerms { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanTermsQuestion")]
        public IWebElement Section2_LoanTerms_subheading1 { get; set; }

        [FindsBy(How = How.ClassName, Using = "question")]
        public IWebElement section2_LoanTerms_subheading1Cell { get; set; }

        [FindsBy(How = How.LinkText, Using = "Can this amount increase after closing? ")]
        public IWebElement Section2_LoanTerms_subheading1Cell { get; set; }

        [FindsBy(How = How.Id, Using = "LoanTerm_LoanAmount")]
        public IWebElement Section2_LoanTerms_LoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "LoanTerm_InterestRate")]
        public IWebElement Section2_LoanTerms_InterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "InterestRate")]
        public IWebElement LoanTerms_InterestRateAmount { get; set; }

        [FindsBy(How = How.Id, Using = "LoanTerm_MonthlyPrincipalInterest")]
        public IWebElement Section2_LoanTerms_MonthlyPrincipal { get; set; }

        [FindsBy(How = How.Id, Using = "LoanTerm_PrepaymentPenalty")]
        public IWebElement Section2_LoanTerms_PrepaymentPenalty { get; set; }

        [FindsBy(How = How.Id, Using = "LoanTerm_BalloonPayment")]
        public IWebElement Section2_LoanTerms_BalloonPayment { get; set; }

        [FindsBy(How = How.LinkText, Using = "Does the loan have these features?")]
        public IWebElement Section2_LoanTerms_subheading2Cell { get; set; }

        [FindsBy(How = How.ClassName, Using = "Divfeaturesquestion2")]
        public IWebElement section2_LoanTerms_subheading2Cell { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanAnount")]
        public IWebElement Section2_LoanTerms_LoanAmountDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "ddlInterestRate")]
        public IWebElement Section2_LoanTerms_InterestRateDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestRateClauses")]
        public IWebElement LoanTerms_InterestRateClause { get; set; }

        [FindsBy(How = How.Id, Using = "spnPrincipleandInterestClauses")]
        public IWebElement LoanTerms_PrincipalAndInterestClause { get; set; }

        [FindsBy(How = How.Id, Using = "spnPrepaymentPenaltyClauses")]
        public IWebElement LoanTerms_PrepaymentPenaltyClause { get; set; }

        [FindsBy(How = How.Id, Using = "ddlMonthlyPrincipalInterest")]
        public IWebElement Section2_LoanTerms_MonthlyPrincipalDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "ddlPrepaymentPenalty")]
        public IWebElement Section2_LoanTerms_PrepaymentPenaltyDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBalloonpayment")]
        public IWebElement Section2_LoanTerms_BalloonPaymentDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleProjectedPayments")]
        public IWebElement Section3_ProjectedPayments { get; set; }

        [FindsBy(How = How.Id, Using = "divImgYearRange")]
        public IWebElement Section3_ProjectedPaymentPlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine10")]
        public IWebElement Section3_PrincipalInterest1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine11")]
        public IWebElement Section3_PrincipalInterest2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine12")]
        public IWebElement Section3_PrincipalInterest3Min { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine22")]
        public IWebElement Section3_PrincipalInterest3Max { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine13")]
        public IWebElement Section3_PrincipalInterest4Min { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine23")]
        public IWebElement Section3_PrincipalInterest4Max { get; set; }

        [FindsBy(How = How.Id, Using = "txtMortInsAmt0")]
        public IWebElement Section3_MortgageInsurance { get; set; }

        [FindsBy(How = How.Id, Using = "txtEstEscAmt0")]
        public IWebElement Section3_EstimatedEscrow { get; set; }


        [FindsBy(How = How.Id, Using = "txtEstEscAmt0")]
        public IWebElement Section3_EstimatedTaxesInsuranceAssessments { get; set; }

        [FindsBy(How = How.Id, Using = "chkPropTaxes")]
        public IWebElement Section3_PropertyTax { get; set; }

        [FindsBy(How = How.Id, Using = "ddlIsPropertyTaxInEscrow")]
        public IWebElement Section3_PropertyTaxInEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkHOIns")]
        public IWebElement Section3_HomeownersInsurance { get; set; }

        [FindsBy(How = How.Id, Using = "ddlIsHomeOwnerInsuranceInEscrow")]
        public IWebElement Section3_HomeownersInsuranceInEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "imgOthersInEscrow")]
        public IWebElement Section3_OthersInEscrowPlus { get; set; }

         [FindsBy(How = How.Id, Using = "EstimateIncludesID_2992")]
        public IWebElement Section3_EstimateIncludesID_2992 { get; set; }

        [FindsBy(How = How.Id, Using = "InEscrowID_2992")]
        public IWebElement Section3_InEscrowID_2992 { get; set; }

        [FindsBy(How = How.Id, Using = "txtPOPupEstimateOther")]
        public IWebElement txtPOPupEstimateOther { get; set; }

        [FindsBy(How = How.Id, Using = "tblPPOtherPOPUp")]
        public IWebElement Section3_InEscrowOtherPopUpTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnPPOtherDone")]
        public IWebElement Section3_OtherpopupDone { get; set; }

        [FindsBy(How = How.Id, Using = "spnCashToClose")]
        public IWebElement Section4_CostsatClosing_CashtoCloseStemenetSpan { get; set; }

        [FindsBy(How = How.Id, Using = "ClosingCostsLabel")]
        public IWebElement Section4_CostsatClosing_ClosingCostsLable { get; set; }

        [FindsBy(How = How.Id, Using = "ClosingCostsTotal")]
        public IWebElement Section4_CostsatClosing_ClosingCostsAmount { get; set; }

        [FindsBy(How = How.Id, Using = "CashToCloseTotal")]
        public IWebElement Section4_CashtoCloseAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ClosingCostsDetail")]
        public IWebElement Section4_CostsatClosing_ClosingCostsStatementCell { get; set; }

        [FindsBy(How = How.Id, Using = "spnCostAtClosingText1")]
        public IWebElement Section4_CostsatClosing_ClosingCostsStatement1 { get; set; }

        [FindsBy(How = How.Id, Using = "spnCostAtClosingText2")]
        public IWebElement Section4_CostsatClosing_ClosingCostsStatement2 { get; set; }

        [FindsBy(How = How.Id, Using = "spnCostAtClosingText3")]
        public IWebElement Section4_CostsatClosing_ClosingCostsStatement3 { get; set; }

        [FindsBy(How = How.Id, Using = "spnCostAtClosingText4")]
        public IWebElement Section4_CostsatClosing_ClosingCostsStatement4 { get; set; }

        [FindsBy(How = How.Id, Using = "spnLoanCosts")]
        public IWebElement Section4_CostsatClosing_ClosingCostsAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "spnOtherCosts")]
        public IWebElement Section4_CostsatClosing_ClosingCostsAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "spnLenderCredits")]
        public IWebElement Section4_CostsatClosing_ClosingCostsAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCostsAtClosing")]
        public IWebElement CostsatClosing { get; set; }

        [FindsBy(How = How.LinkText, Using = "Cash to Close")]
        public IWebElement CashtoClose { get; set; }

        [FindsBy(How = How.LinkText, Using = "$14,272.35")]
        public IWebElement CashtoCloseAmount { get; set; }

        [FindsBy(How = How.Id, Using = "CashToCloseDetail")]
        public IWebElement CashtoCloseStatement { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleSummOfTrans")]
        public IWebElement Summary_Of_Trans { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeM4")]
        public IWebElement SOTAssumptionLoan1CreditsPlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeM5")]
        public IWebElement SOTAssumptionLoan2CreditsPlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeM6")]
        public IWebElement SOTNewLoan2CreditsPlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "M6Desc")]
        public IWebElement M6Desc { get; set; }

        [FindsBy(How = How.Id, Using = "M6SubCharge_Desc1")]
        public IWebElement M6SubCharge_Desc1 { get; set; }

        [FindsBy(How = How.Id, Using = "M6SubCharge_Desc2")]
        public IWebElement M6SubCharge_Desc2 { get; set; }

        [FindsBy(How = How.Id, Using = "M6TotalAmt")]
        public IWebElement M6TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "M6SubCharge_Amt11")]
        public IWebElement M6SubCharge_Amt11 { get; set; }

        [FindsBy(How = How.Id, Using = "M6SubCharge_Amt12")]
        public IWebElement M6SubCharge_Amt12 { get; set; }


        [FindsBy(How = How.Id, Using = "divImgGroupChargeM7")]
        public IWebElement M07_PlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "M7Desc")]
        public IWebElement M7Desc { get; set; }

        [FindsBy(How = How.Id, Using = "M7SubCharge_Desc1")]
        public IWebElement M7SubCharge_Desc1 { get; set; }

        [FindsBy(How = How.Id, Using = "M7SubCharge_Desc2")]
        public IWebElement M7SubCharge_Desc2 { get; set; }

        [FindsBy(How = How.Id, Using = "M7TotalAmt")]
        public IWebElement M7TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "M7SubCharge_Amt11")]
        public IWebElement M7SubCharge_Amt11 { get; set; }

        [FindsBy(How = How.Id, Using = "M7SubCharge_Amt12")]
        public IWebElement M7SubCharge_Amt12 { get; set; }

        //[FindsBy(How = How.LinkText, Using = "N. Due from Seller at Closing")]
        [FindsBy(How = How.Id, Using = "SectionNHeader")]
        public IWebElement SectionN_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo1")]
        public IWebElement SectionN01_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc1")]
        public IWebElement SectionN01_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt1")]
        public IWebElement SectionN01_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo3")]
        public IWebElement SectionN03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc3")]
        public IWebElement SectionN03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt3")]
        public IWebElement SectionN03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo8")]
        public IWebElement SectionN08_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc8")]
        public IWebElement SectionN08_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt8")]
        public IWebElement SectionN08_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo4")]
        public IWebElement SectionN04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc4")]
        public IWebElement SectionN04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt4")]
        public IWebElement SectionN04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo5")]
        public IWebElement SectionN05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc5")]
        public IWebElement SectionN05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt5")]
        public IWebElement SectionN05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo19")]
        public IWebElement SectionN19_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCalCashToClose")]
        public IWebElement CalculatingCashToCloseHeader { get; set; }

        [FindsBy(How = How.Id, Using = "spntxtmonthly")]
        public IWebElement Section2_LoanTerms_MonthlySpan { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanTermsInterestType")]
        public IWebElement Section2_LoanTerms_MonthlyDropDown { get; set; }

        [FindsBy(How = How.Id, Using = "txtInterestType")]
        public IWebElement Section2_LoanTerms_OtherEditBox { get; set; }

        [FindsBy(How = How.Id, Using = "btnInterestTypeDone")]
        public IWebElement Section2_LoanTerms_MonthlyPopupDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnInterestTypeCancel")]
        public IWebElement Section2_LoanTerms_MonthlyPopupCancel { get; set; }

        [FindsBy(How = How.Id, Using = "LoanAmount")]
        public IWebElement Section2_LoanTerms_LoanAmountValue { get; set; }

        [FindsBy(How = How.Id, Using = "spnLoantermsInterestRate")]
        public IWebElement Section2_LoanTerms_InterestRateValue { get; set; }

        [FindsBy(How = How.Id, Using = "spnMonthlyPrincipalInterest")]
        public IWebElement Section2_LoanTerms_MonthlyPrincipalValue { get; set; }

        [FindsBy(How = How.Id, Using = "imgddlIntPayments")]
        public IWebElement Section2_LoanTerms_MonthlyPlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleAdjustablePayment")]
        public IWebElement Sec9_APnAIRtable_SectionHeading { get; set; }

        [FindsBy(How = How.Id, Using = "imgddlMonthlyPayments")]
        public IWebElement imgddlMonthlyPayments { get; set; }

        [FindsBy(How = How.Id, Using = "chkAptbl")]
        public IWebElement Sec9_APnAIRtable_APTableChkBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkAirtbl")]
        public IWebElement Sec9_APnAIRtable_AIRTableChkBox { get; set; }
        
        [FindsBy(How = How.Id, Using = "spnIM2")]
        public IWebElement Sec9_AIRTable_DisplayIndexMargin { get; set; }

        [FindsBy(How = How.Id, Using = "spnIM2")]
        public IWebElement Sec9_AIRTable_DisplayInterestRateAdj { get; set; }

        [FindsBy(How = How.Id, Using = "spnIIR")]
        public IWebElement Sec9_AIRTable_DisplayInitialIR { get; set; }

        [FindsBy(How = How.Id, Using = "spnMaxMin")]
        public IWebElement Sec9_AIRTable_DisplayMaxMinIR { get; set; }

        [FindsBy(How = How.Id, Using = "spnchngFreFstChanges")]
        public IWebElement Sec9_AIRTable_DisplayFreqFirstChange { get; set; }

        [FindsBy(How = How.Id, Using = "spnchngFreSubChanges")]
        public IWebElement Sec9_AIRTable_DisplayFreqSubChange { get; set; }
        
        [FindsBy(How = How.Id, Using = "spnLimFstChanges")]
        public IWebElement Sec9_AIRTable_DisplayLimitsFirstChange { get; set; }

        [FindsBy(How = How.Id, Using = "spnLimSubChanges")]
        public IWebElement Sec9_AIRTable_DisplayLimitsSubChange { get; set; }

        [FindsBy(How = How.Id, Using = "imgAIRPopUp")]
        public IWebElement Sec9_AIRTable_ImagePlus { get; set; }

        [FindsBy(How = How.Id, Using = "ddlIndexDescription")]
        public IWebElement Sec9_AIRTable_IndexDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtIARFirst")]
        public IWebElement Sec9_AIRTable_txtIARFirst { get; set; }

        [FindsBy(How = How.Id, Using = "txtOther")]
        public IWebElement Sec9_AIRTable_txtIndex { get; set; }

        [FindsBy(How = How.Id, Using = "txtMargin")]
        public IWebElement Sec9_AIRTable_txtMargin { get; set; }

        [FindsBy(How = How.Id, Using = "txtMinimum")]
        public IWebElement Section3_txtMinimum { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximum")]
        public IWebElement Section3_txtMaximum { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrincipalInterestDone")]
        public IWebElement Section3_btnPrincipalInterestDone { get; set; }

        [FindsBy(How = How.Id, Using = "spnIIRateValue")]
        public IWebElement spnIIRateValue { get; set; }

        [FindsBy(How = How.Id, Using = "txtMinimumInterest")]
        public IWebElement Sec9_AIRTable_txtMinimumInterest { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximumInterest")]
        public IWebElement Sec9_AIRTable_txtMaximumInterest { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstChange")]
        public IWebElement Sec9_AIRTable_txtFirstChange { get; set; }

        [FindsBy(How = How.Id, Using = "txtEvery")]
        public IWebElement Sec9_AIRTable_txtEvery { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirst")]
        public IWebElement Sec9_AIRTable_LimitsFirstChange { get; set; }

        [FindsBy(How = How.Id, Using = "txtSubsequent")]
        public IWebElement Sec9_AIRTable_LimitsSubChange { get; set; }

        [FindsBy(How = How.Id, Using = "btnAIRPopUpDone")]
        public IWebElement Sec9_AIRTable_btnAIRPopUpDone { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId1")]
        public IWebElement rbInterestOnlyPaymentId1 { get; set; }

        [FindsBy(How = How.Id, Using = "tblAdjustablePayment")]
        public IWebElement Sec9_APnAIRtable_APTable { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APTableHeading { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APInterestOnlyLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlIntPayment")]
        public IWebElement Sec9_APnAIRtable_APInterestOnlyDrpDwn { get; set; }

        [FindsBy(How = How.Id, Using = "spnIntPayment")]
        public IWebElement Sec9_APnAIRtable_APspnIntPayment { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APInterestOnlySchedule { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APInterestOnlySchedulePlus { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APOptionalPaymentsLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOptPayments")]
        public IWebElement Sec9_APnAIRtable_APOptionalPaymentsDrpDwn { get; set; }

        [FindsBy(How = How.Id, Using = "spnOptPayments")]
        public IWebElement Sec9_APnAIRtable_APspnOptPayments { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APOptionalPaymentsSchedule { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APOptionalPaymentsSchedulePlus { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APStepPaymentsLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlStepPayments")]
        public IWebElement Sec9_APnAIRtable_APStepPaymentsDrpDwn { get; set; }

        [FindsBy(How = How.Id, Using = "spnStepPayments")]
        public IWebElement Sec9_APnAIRtable_APspnStepPayments { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APStepPaymentsSchedule { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APStepPaymentsSchedulePlus { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APSeasonalPaymentsLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSeasonalPayments")]
        public IWebElement Sec9_APnAIRtable_APSeasonalPaymentsDrpDwn { get; set; }

        [FindsBy(How = How.Id, Using = "spnSeasonalPayments")]
        public IWebElement Sec9_APnAIRtable_APspnSeasonalPayments { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APSeasonalPaymentsSchedule { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APSeasonalPaymentsSchedulePlus { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APMonthlyPrincipalLabel { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APFirstChangeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "spnFirstChangeAmount")]
        public IWebElement Sec9_APnAIRtable_APFirstChangeValue { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APSubsequentChangesLabel { get; set; }

        [FindsBy(How = How.Id, Using = "spnSubSequentChanges")]
        public IWebElement Sec9_APnAIRtable_APSubsequentChangesValue { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Sec9_APnAIRtable_APMaximumPaymentLabel { get; set; }

        [FindsBy(How = How.Id, Using = "spBorrowerPaid")]
        public IWebElement TaxesandOtherGovernmentFees_Aggregate_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "spBorrowerPaid")]
        public IWebElement Prepaids_Aggregate_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "spnMaximumAmount")]
        public IWebElement Sec9_APnAIRtable_APMaximumPaymentValue { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstChargeAmount1")]
        public IWebElement Sec9_APnAIRtable_txtFirstChargeAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstChargeAmount2")]
        public IWebElement Sec9_APnAIRtable_txtFirstChargeAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstChargeAmount3")]
        public IWebElement Sec9_APnAIRtable_txtFirstChargeAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstChargeAmount4")]
        public IWebElement Sec9_APnAIRtable_txtFirstChargeAmount4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtFirstChargeAmount5")]
        public IWebElement Sec9_APnAIRtable_txtFirstChargeAmount5 { get; set; }

        [FindsBy(How = How.Id, Using = "txtSubsequentChange1")]
        public IWebElement Sec9_APnAIRtable_txtSubsequentChange1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtSubsequentChange2")]
        public IWebElement Sec9_APnAIRtable_txtSubsequentChange2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtSubsequentChange3")]
        public IWebElement Sec9_APnAIRtable_txtSubsequentChange3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximumPayment1")]
        public IWebElement Sec9_APnAIRtable_txtMaximumPayment1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximumPayment2")]
        public IWebElement Sec9_APnAIRtable_txtMaximumPayment2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximumPayment3")]
        public IWebElement Sec9_APnAIRtable_txtMaximumPayment3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximumPayment4")]
        public IWebElement Sec9_APnAIRtable_txtMaximumPayment4 { get; set; }

        [FindsBy(How = How.Id, Using = "btnMonthlyPaymentDone")]
        public IWebElement Sec9_APnAIRtable_btnMonthlyPaymentDone { get; set; }

        [FindsBy(How = How.Id, Using = "chkHasEscrowAccount")]
        public IWebElement EscrowAccount_check { get; set; }

        [FindsBy(How = How.Id, Using = "spnNonEscrowedPropertyOverYear1Amount")]
        public IWebElement NonEscrowedPropertyOverYear1Amount { get; set; }

        [FindsBy(How = How.Name, Using = "txtAreaEscrowedPropertyOverYear1Editable")]
        public IWebElement EstimatedEscrowedPropertyOverYear1Editable { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaNonEscrowedPropertyOverYear1Editable")]
        public IWebElement EscrowedProertyOverYear1Editable { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaNonEscrowedProertyOverYear1Editable")]
        public IWebElement NonEscrowedProertyOverYear1Editable { get; set; }

        [FindsBy(How = How.Id, Using = "spnNonEscrowedProertyOverYear1Amount")]
        public IWebElement NonEscrowedProertyOverYear1Amount { get; set; }

        [FindsBy(How = How.Id, Using = "spanEscrowedPropertyCostsForYearMonthly")]
        public IWebElement spanEscrowedPropertyCostsForYearMonthly { get; set; }

        [FindsBy(How = How.Id, Using = "spnDollarForMonthlyEscrow")]
        public IWebElement spnDollarForMonthlyEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCalCashToClose")]
        public IWebElement CalculateCashToClose { get; set; }

        [FindsBy(How = How.Id, Using = "imgTCCOverRide")]
        public IWebElement CCTotalClosingCostsJ_ImgPlus { get; set; }

        [FindsBy(How = How.Id, Using = "chkOverrideLoanEstimate")]
        public IWebElement CCTotalClosingCostsJ_OverrideCheck { get; set; }

        [FindsBy(How = How.Id, Using = "txtUnroundedLoanEstimate")]
        public IWebElement CCTotalClosingCostsJ_newLEUnroundedAmt { get; set; }

        [FindsBy(How = How.Id, Using = "spnTCCComments")]
        public IWebElement CCC_spnTCCComments { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanEstimate")]
        public IWebElement CCTotalClosingCostsJ_newLEAmt { get; set; }

        [FindsBy(How = How.Id, Using = "btnOverrideDone")]
        public IWebElement CCTotalClosingCostsJ_btnOverrideDone { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCFFinalAmount")]
        public IWebElement CCFFinalAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCFLEAmount")]
        public IWebElement CCFLoanEstimateAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnTCCULEAmount")]
        public IWebElement CCC_spnTCCULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCPLEAmount")]
        public IWebElement CCC_spnCCPLEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCPComments")]
        public IWebElement CCC_spnCCPComments { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCPULEAmount")]
        public IWebElement CCC_spnCCPULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCFComments")]
        public IWebElement CCC_spnCCFComments { get; set; }

        [FindsBy(How = How.Id, Using = "spnCCFULEAmount")]
        public IWebElement CCC_spnCCFULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnDLEAmount")]
        public IWebElement CCC_spnDLEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnDComments")]
        public IWebElement CCC_spnDComments { get; set; }

        [FindsBy(How = How.Id, Using = "spnFBComments")]
        public IWebElement CCC_spnFBComments { get; set; }

        [FindsBy(How = How.Id, Using = "spnSCComments")]
        public IWebElement CCC_spnSCComments { get; set; }

        [FindsBy(How = How.Id, Using = "spnDPULEAmount")]
        public IWebElement CCC_spnDPULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnDULEAmount")]
        public IWebElement CCC_spnDULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnFBLEAmount")]
        public IWebElement CCC_spnFBLEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnFBULEAmount")]
        public IWebElement CCC_spnFBULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnSCLEAmount")]
        public IWebElement CCC_spnSCLEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnSCULEAmount")]
        public IWebElement CCC_spnSCULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnAOCLEAmount")]
        public IWebElement CCC_spnAOCLEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnAOCComments")]
        public IWebElement CCC_spnAOCComments { get; set; }

        [FindsBy(How = How.Id, Using = "spnAOCULEAmount")]
        public IWebElement CCC_spnAOCULEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "imgCCFChanged")]
        public IWebElement CCFChangedplusIcon { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#optCCC2973")]
        public IWebElement selectOtherRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtCCCOther2668")]
        public IWebElement OtherComment { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#btnCalculateCashToCloseDone")]
        public IWebElement btnCalculateCashToCloseDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnBorrowerInfoDone")]
        public IWebElement BorrowerDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnSellerInfoDone")]
        public IWebElement SellerDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtCCCOther2611")]
        public IWebElement CCCOther2611 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN3")]
        public IWebElement N03Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN4")]
        public IWebElement N04Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN5")]
        public IWebElement N05Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN6")]
        public IWebElement N06Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN7")]
        public IWebElement N07Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeL3")]
        public IWebElement L03Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN10")]
        public IWebElement N10Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeN9")]
        public IWebElement N9Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeL4")]
        public IWebElement L04Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeL1")]
        public IWebElement L06Plus { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo6")]
        public IWebElement SectionN06_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc6")]
        public IWebElement SectionN06_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt6")]
        public IWebElement SectionN06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo7")]
        public IWebElement SectionN07_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc7")]
        public IWebElement SectionN07_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt7")]
        public IWebElement SectionN07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo9")]
        public IWebElement SectionN09_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc9")]
        public IWebElement SectionN09_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt9")]
        public IWebElement SectionN09_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo10")]
        public IWebElement SectionN10_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc10")]
        public IWebElement SectionN10_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt10")]
        public IWebElement SectionN10_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo11")]
        public IWebElement SectionN11_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc11")]
        public IWebElement SectionN11_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt11")]
        public IWebElement SectionN11_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo12")]
        public IWebElement SectionN12_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc12")]
        public IWebElement SectionN12_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt12")]
        public IWebElement SectionN12_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo13")]
        public IWebElement SectionN13_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc13")]
        public IWebElement SectionN13_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt13")]
        public IWebElement SectionN13_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_N12")]
        public IWebElement SectionN12_ExpndButton { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_N13")]
        public IWebElement SectionN13_ExpndButton { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo14")]
        public IWebElement SectionN13a_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc14")]
        public IWebElement SectionN13a_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt14")]
        public IWebElement SectionN13a_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt14")]
        public IWebElement SectionNsub13a_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo15")]
        public IWebElement SectionNSupN02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc15")]
        public IWebElement SectionNSupN02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt15")]
        public IWebElement SectionNSupN02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt15")]
        public IWebElement SectionNSupSubN02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo16")]
        public IWebElement SectionNSupN03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc16")]
        public IWebElement SectionNSupN03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt16")]
        public IWebElement SectionNSupN03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt16")]
        public IWebElement SectionNSupSubN03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo17")]
        public IWebElement SectionNSupN04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc17")]
        public IWebElement SectionNSupN04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt17")]
        public IWebElement SectionNSupN04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt17")]
        public IWebElement SectionNSupSubN04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo18")]
        public IWebElement SectionNSupN05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc18")]
        public IWebElement SectionNSupN05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt18")]
        public IWebElement SectionNSupN05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt18")]
        public IWebElement SectionNSupSubN05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo19")]
        public IWebElement SectionNSupN06_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc19")]
        public IWebElement SectionNSupN06_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt19")]
        public IWebElement SectionNSupN06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt19")]
        public IWebElement SectionNSupSubN06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo20")]
        public IWebElement SectionNSupN07_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc20")]
        public IWebElement SectionNSupN07_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt20")]
        public IWebElement SectionNSupN07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt20")]
        public IWebElement SectionNSupSubN07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo21")]
        public IWebElement SectionNSupN08_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc21")]
        public IWebElement SectionNSupN08_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt21")]
        public IWebElement SectionNSupN08_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt21")]
        public IWebElement SectionNSupSubN08_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo24")]
        public IWebElement SectionNSupN11_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc24")]
        public IWebElement SectionNSupN11_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt24")]
        public IWebElement SectionNSupN11_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt24")]
        public IWebElement SectionNSupSubN11_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo25")]
        public IWebElement SectionNSupN12_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc25")]
        public IWebElement SectionNSupN12_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt25")]
        public IWebElement SectionNSupN12_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt25")]
        public IWebElement SectionNSupSubN12_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo27")]
        public IWebElement SectionNSupN14_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc27")]
        public IWebElement SectionNSupN14_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt27")]
        public IWebElement SectionNSupN14_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt27")]
        public IWebElement SectionNSupSubN14_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo28")]
        public IWebElement SectionNSupN15_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_desc28")]
        public IWebElement SectionNSupN15_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_amt28")]
        public IWebElement SectionNSupN15_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_subAmt28")]
        public IWebElement SectionNSupSubN15_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "tabVariance")]
        public IWebElement VarianceTab { get; set; }

        [FindsBy(How = How.Id, Using = "tblTenPerVariance")]
        public IWebElement GoodFaithAnalisys10Table { get; set; }

        [FindsBy(How = How.Id, Using = "tblZeroPerVariance")]
        public IWebElement GoodFaithAnalisys0Table { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanCosts")]
        public IWebElement LoanCosts { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayDescription_71062112_0")]
        public IWebElement ApplicationFee { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_71062112_0")]
        public IWebElement ApplicationFee_Unrounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_71062112_0")]
        public IWebElement ApplicationFee_Rounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayDescription_71062110_0")]
        public IWebElement CreditReport { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_71062110_0")]
        public IWebElement CreditReport_Unrounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_71062110_0")]
        public IWebElement CreditReport_Rounded { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc6")]
        public IWebElement SectionK04_A { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayDescription_71062111_0")]
        public IWebElement FloodCertification { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_71062111_0")]
        public IWebElement FloodCertification_Unrounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_71062111_0")]
        public IWebElement FloodCertification_Rounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayDescription_71062113_0")]
        public IWebElement AdhocCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_71062113_0")]
        public IWebElement AdhocCharge_Unrounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_71062113_0")]
        public IWebElement AdhocCharge_Rounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_71062108_0")]
        public IWebElement LoanAmountPoints_Unrounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_71062108_0")]
        public IWebElement LoanAmountPoints_Rounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayDescription_71062109_0")]
        public IWebElement AppraisalFee { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_71062109_0")]
        public IWebElement AppraisalFee_Unrounded { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_71062109_0")]
        public IWebElement AppraisalFee_Rounded { get; set; }

        [FindsBy(How = How.Id, Using = "chkDispHideLoanEstimate")]
        public IWebElement DisplayLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "SectionLTotal")]
        public IWebElement SectionL_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "SectionLHeader")]
        public IWebElement SectionL_Header { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo1")]
        public IWebElement SectionL01_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_desc1")]
        public IWebElement SectionL01_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_amt1")]
        public IWebElement SectionL01_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo1")]
        public IWebElement SectionK01_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc1")]
        public IWebElement SectionK01_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt1")]
        public IWebElement SectionK01_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo2")]
        public IWebElement SectionK02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc2")]
        public IWebElement SectionK02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt2")]
        public IWebElement SectionK02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo3")]
        public IWebElement SectionK03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc3")]
        public IWebElement SectionK03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt3")]
        public IWebElement SectionK03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo1")]
        public IWebElement SectionM01_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc1")]
        public IWebElement SectionM01_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt1")]
        public IWebElement SectionM01_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo2")]
        public IWebElement SectionM02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc2")]
        public IWebElement SectionM02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt2")]
        public IWebElement SectionM02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo16")]
        public IWebElement SectionM16_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo2")]
        public IWebElement SectionL02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_desc2")]
        public IWebElement SectionL02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_amt2")]
        public IWebElement SectionL02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo3")]
        public IWebElement SectionL03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_desc3")]
        public IWebElement SectionL03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_amt3")]
        public IWebElement SectionL03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo5")]
        public IWebElement SectionL05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_desc5")]
        public IWebElement SectionL05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_amt5")]
        public IWebElement SectionL05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionN_seqNo14")]
        public IWebElement SectionKHeader_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "SectionKHeader")]
        public IWebElement SectionKHeader_Label { get; set; }

        [FindsBy(How = How.Id, Using = "SectionKTotal")]
        public IWebElement SectionKHeader_Amt { get; set; }
        [FindsBy(How = How.Id, Using = "SectionMTotal")]
        public IWebElement SectionMHeader_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo4")]
        public IWebElement SectionK07a_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc4")]
        public IWebElement SectionK07a_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt4")]
        public IWebElement SectionK07a_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo5")]
        public IWebElement SectionK07b_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc5")]
        public IWebElement SectionK07b_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt5")]
        public IWebElement SectionK07b_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo5")]
        public IWebElement SectionKSupK02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc5")]
        public IWebElement SectionKSupK02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt5")]
        public IWebElement SectionKSupK02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo6")]
        public IWebElement SectionKSupK03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc6")]
        public IWebElement SectionKSupK03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt6")]
        public IWebElement SectionKSupK03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-Adjustments_K")]
        public IWebElement transSummaryAdjustments_K { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo5")]
        public IWebElement SectionK04a_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc5")]
        public IWebElement SectionK04a_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt5")]
        public IWebElement SectionK04a_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_subAmt5")]
        public IWebElement SectionK04a_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo6")]
        public IWebElement SectionK04SupL02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc6")]
        public IWebElement SectionK04SupL02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt6")]
        public IWebElement SectionK04SupL02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_subAmt6")]
        public IWebElement SectionK04SupL02_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo7")]
        public IWebElement SectionK04SupL03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc7")]
        public IWebElement SectionK04SupL03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt7")]
        public IWebElement SectionK04SupL03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_subAmt7")]
        public IWebElement SectionK04SupL03_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo8")]
        public IWebElement SectionK04SupL04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc8")]
        public IWebElement SectionK04SupL04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt8")]
        public IWebElement SectionK04SupL04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_subAmt8")]
        public IWebElement SectionK04SupL04_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo9")]
        public IWebElement SectionK04SupL05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc9")]
        public IWebElement SectionK04SupL05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt9")]
        public IWebElement SectionK04SupL05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_subAmt9")]
        public IWebElement SectionK04SupL05_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo10")]
        public IWebElement SectionK04SupL06_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc10")]
        public IWebElement SectionK04SupL06_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt10")]
        public IWebElement SectionK04SupL06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo11")]
        public IWebElement SectionK04SupL07_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc11")]
        public IWebElement SectionK04SupL07_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt11")]
        public IWebElement SectionK04SupL07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo12")]
        public IWebElement SectionK04SupL08_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc12")]
        public IWebElement SectionK04SupL08_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt12")]
        public IWebElement SectionK04SupL08_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo18")]
        public IWebElement SectionK04Sup12_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc18")]
        public IWebElement SectionK04SupL12_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt18")]
        public IWebElement SectionK04SupL12_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
        public IWebElement K04PopupClose { get; set; }

        [FindsBy(How = How.Id, Using = "tblsummarysecPopUp")]
        public IWebElement LPopupTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblsummarysecPopUp")]
        public IWebElement CDPopupTable { get; set; }

        [FindsBy(How = How.Id, Using = "K4Desc")]
        public IWebElement k04PopupDesc { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc1")]
        public IWebElement N4SectionPopCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc2")]
        public IWebElement N4SectionPopCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc3")]
        public IWebElement N4SectionPopCharge3 { get; set; }


        [FindsBy(How = How.Id, Using = "N7SubCharge_Desc1")]
        public IWebElement NSectionPopCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "N7SubCharge_Desc2")]
        public IWebElement NSectionPopCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "N7SubCharge_Desc3")]
        public IWebElement NSectionPopCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "K4Heading1")]
        public IWebElement K04BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubSeqNo")]
        public IWebElement K04SubSecNo { get; set; }

        [FindsBy(How = How.Id, Using = "K4TotalAmt")]
        public IWebElement K04TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_SubSeqNo1")]
        public IWebElement K04SCSubSeqNo1 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_SubSeqNo3")]
        public IWebElement K04SCSubSeqNo2 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Desc1")]
        public IWebElement K04SubCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Desc2")]
        public IWebElement K04SubCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Desc3")]
        public IWebElement K04SubCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Desc4")]
        public IWebElement K04SubCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_SubTotalAmt1")]
        public IWebElement K04SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_SubTotalAmt3")]
        public IWebElement K04SubTotalAmt2 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Amt11")]
        public IWebElement K04SubChargeAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Amt12")]
        public IWebElement K04SubChargeAmt2 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Amt13")]
        public IWebElement K04SubChargeAmt3 { get; set; }

        [FindsBy(How = How.Id, Using = "K4SubCharge_Amt14")]
        public IWebElement K04SubChargeAmt4 { get; set; }

        [FindsBy(How = How.Id, Using = "tblsummarysecPopUp")]
        public IWebElement L04PopupTable { get; set; }

        [FindsBy(How = How.Id, Using = "L4Desc")]
        public IWebElement L04PopupDesc { get; set; }

        [FindsBy(How = How.Id, Using = "L1Desc")]
        public IWebElement L06PopupDesc { get; set; }

        [FindsBy(How = How.LinkText, Using = "x")]
        public IWebElement L04PopupClose { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeK4")]
        public IWebElement GroupChargeK4 { get; set; }

        [FindsBy(How = How.Id, Using = "L2Desc")]
        public IWebElement L07PopupDesc { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeL1")]
        public IWebElement GroupChargeL1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
        public IWebElement PopUpDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnSummaryChargePopUpDone")]
        public IWebElement L07PopUpClose { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeL2")]
        public IWebElement L07Plus { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_K")]
        public IWebElement SectionK { get; set; }
        [FindsBy(How = How.Id, Using = "tbl_transSummary_DueItemsK")]
        public IWebElement SectionK_dueItems_Table { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_L")]
        public IWebElement SectionL { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_M")]
        public IWebElement SectionM { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_N")]
        public IWebElement SectionN { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_seqNo4")]
        public IWebElement SectionK04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_desc4")]
        public IWebElement SectionK04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_amt4")]
        public IWebElement SectionK04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo1")]
        public IWebElement SectionK05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc1")]
        public IWebElement SectionK05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt1")]
        public IWebElement SectionK05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo2")]
        public IWebElement SectionK06_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc2")]
        public IWebElement SectionK06_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt2")]
        public IWebElement SectionK06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_seqNo3")]
        public IWebElement SectionK07_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_desc3")]
        public IWebElement SectionK07_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionK_Adjustments_amt3")]
        public IWebElement SectionK07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo4")]
        public IWebElement SectionL04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_desc4")]
        public IWebElement SectionL04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_amt4")]
        public IWebElement SectionL04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo3")]
        public IWebElement SectionL07a_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc3")]
        public IWebElement SectionL07a_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt3")]
        public IWebElement SectionL07a_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_subAmt3")]
        public IWebElement SectionL07a_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo4")]
        public IWebElement SectionL07SupL02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc4")]
        public IWebElement SectionL07SupL02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt4")]
        public IWebElement SectionL07SupL02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_subAmt4")]
        public IWebElement SectionL07SupL02_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo5")]
        public IWebElement SectionL07SupL03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc5")]
        public IWebElement SectionL07SupL03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt5")]
        public IWebElement SectionL07SupL03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_subAmt5")]
        public IWebElement SectionL07SupL03_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo6")]
        public IWebElement SectionL07SupL04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc6")]
        public IWebElement SectionL07SupL04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt6")]
        public IWebElement SectionL07SupL04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_subAmt6")]
        public IWebElement SectionL07SupL04_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo7")]
        public IWebElement SectionL07SupL05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc7")]
        public IWebElement SectionL07SupL05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt7")]
        public IWebElement SectionL07SupL05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_subAmt7")]
        public IWebElement SectionL07SupL05_SubAmt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo5")]
        public IWebElement SectionL11a_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc5")]
        public IWebElement SectionL11a_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt5")]
        public IWebElement SectionL11a_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo6")]
        public IWebElement SectionLSupL02_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc6")]
        public IWebElement SectionLSupL02_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt6")]
        public IWebElement SectionLSupL02_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo7")]
        public IWebElement SectionLSupL03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc7")]
        public IWebElement SectionLSupL03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt7")]
        public IWebElement SectionLSupL03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "Name_1")]
        public IWebElement BorrowerPopupName1 { get; set; }

        [FindsBy(How = How.Id, Using = "Name_2")]
        public IWebElement BorrowerPopupName2 { get; set; }

        [FindsBy(How = How.Id, Using = "divBorrowerDetails")]
        public IWebElement BorrowerDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tblBorrowerDetails")]
        public IWebElement BorrowerDetailsTable { get; set; }
        

        [FindsBy(How = How.Id, Using = "LoanApplicant0")]
        public IWebElement Spouse1 { get; set; }

        [FindsBy(How = How.Id, Using = "SpouseLoanApplicant0")]
        public IWebElement Spouse2 { get; set; }

        [FindsBy(How = How.Id, Using = "LoanApplicant1")]
        public IWebElement Byer2Spouse1 { get; set; }

        [FindsBy(How = How.Id, Using = "SpouseLoanApplicant1")]
        public IWebElement Byer2Spouse2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitlePayoffsandPayments")]
        public IWebElement Section_Payoffs { get; set; }

        [FindsBy(How = How.LinkText, Using = "Payoff Loan Charges")]
        public IWebElement Section_PayoffsChargeDescription { get; set; }

        [FindsBy(How = How.LinkText, Using = "To")]
        public IWebElement Section_Payoffs_To_Label { get; set; }

        [FindsBy(How = How.LinkText, Using = "Amount")]
        public IWebElement Section_Payoffs_Amount_Label { get; set; }

        [FindsBy(How = How.LinkText, Using = "TOTAL PAYOFFS AND PAYMENTS")]
        public IWebElement Section_Payoffs_TotalSum_Label { get; set; }

        [FindsBy(How = How.Id, Using = "PayoffsandPaymentsTotalAmount")]
        public IWebElement Section_Payoffs_TotalSum_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddnewPayoffsandPaymentsCharge")]
        public IWebElement Section_Payoffs_plusIcon { get; set; }

        [FindsBy(How = How.LinkText, Using = "See attached page for additional information")]
        public IWebElement Section_Payoffs_Supplement_pageRefrence { get; set; }

        [FindsBy(How = How.Id, Using = "PayoffsandPaymentsTotalAmountSuppl")]
        public IWebElement Section_Payoffs_Supplement_TotalSum_Amount { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Section_Payoffs_SequenceNumber { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddLoanAmountClauses")]
        public IWebElement LoanTerm_LoanAmount_plusIcon { get; set; }
        
        [FindsBy(How = How.Id, Using = "ddlLACanGo")]
        public IWebElement LoanTerm_LoanAmount_CanGo_DrpDwn { get; set; }

        [FindsBy(How = How.Id, Using = "strLACanIncrease")]
        public IWebElement CanIncreaseIncreasesPane { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLACanIncrease")]
        public IWebElement LoanTerm_LoanAmount_CanInc_DrpDwn { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaxLoadBalanceAmount")]
        public IWebElement LoanTerm_LoanAmount_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "txtNegAmortizationLimitYears")]
        public IWebElement LoanTerm_LoanAmount_year { get; set; }

        [FindsBy(How = How.CssSelector, Using = "ul#SortableBulletPoints")]
        public IWebElement LoanTerm_PlusPanel { get; set; }

        [FindsBy(How = How.CssSelector, Using = "ul#SortableBulletPoints > li:first-child > input")]
        public IWebElement LoanTerm_PlusPanel_checkbox1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "ul#SortableBulletPoints > li:nth-child(2) > input")]
        public IWebElement LoanTerm_PlusPanel_checkbox2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "ul#SortableBulletPoints > li:nth-child(3) > input")]
        public IWebElement LoanTerm_PlusPanel_checkbox3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li/input[@type='checkbox']")]
        public IWebElement LoanTerm_LoanAmount_check { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[1]/input[@type='checkbox']")]
        public IWebElement LoanTerm_IR_CheckBox1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/input[@type='checkbox']")]
        public IWebElement LoanTerm_IR_CheckBox2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[3]/input[@type='checkbox']")]
        public IWebElement LoanTerm_IR_CheckBox3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[1]/input[@type='checkbox']")]
        public IWebElement LoanTerm_PI_CheckBox1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/input[@type='checkbox']")]
        public IWebElement LoanTerm_PI_CheckBox2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[3]/input[@type='checkbox']")]
        public IWebElement LoanTerm_PI_CheckBox3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[4]/input[@type='checkbox']")]
        public IWebElement LoanTerm_PI_CheckBox4 { get; set; }

        [FindsBy(How = How.Id, Using = "chkNoEscrowAccount")]
        public IWebElement WillNotHaveEscrowAccountChkBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkEscrowAccntDeclined")]
        public IWebElement YouDeclinedChkBox { get; set; }

        [FindsBy(How = How.Id, Using = "spnEstimatedPropertyCostPerYear")]
        public IWebElement spnEstimatedPropertyCostPerYear { get; set; }

        [FindsBy(How = How.Id, Using = "spnEscrowWaverFeeTxtbox")]
        public IWebElement spnEscrowWaverFeeTxtbox { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanTermClauseCancel")]
        public IWebElement LoanTerm_LoanAmount_CancelBtn { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanTermClauseDone")]
        public IWebElement LoanTerm_LoanAmount_DoneBtn { get; set; }

        [FindsBy(How = How.Id, Using = "25841")]
        public IWebElement LoanTerm_LoanAmount_Clause1 { get; set; }

        [FindsBy(How = How.Id, Using = "25842")]
        public IWebElement LoanTerm_LoanAmount_Clause2 { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddInterestRateClauses")]
        public IWebElement LoanTerm_InterestRate_plusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "txtIRAdjustEveryYear")]
        public IWebElement LoanTerm_IR_Adjust_Year { get; set; }

        [FindsBy(How = How.Id, Using = "txtIRFirstRateChangeYears")]
        public IWebElement LoanTerm_IR_FirstRate_Year { get; set; }

        [FindsBy(How = How.Id, Using = "txtIRCeilingRatePercent")]
        public IWebElement LoanTerm_IR_CeilingRate { get; set; }

        [FindsBy(How = How.Id, Using = "txtCRPEffectiveYearCount")]
        public IWebElement LoanTerm_IR_Effective_Year { get; set; }

        [FindsBy(How = How.Id, Using = "25851")]
        public IWebElement LoanTerm_IR_Clause1 { get; set; }

        [FindsBy(How = How.Id, Using = "25852")]
        public IWebElement LoanTerm_IR_Clause2 { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddPrincipalandInterestClauses")]
        public IWebElement LoanTerm_PI_plusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "txtPIAdjustFreqYearCount")]
        public IWebElement LoanTerm_PI_Adjust_Year { get; set; }

        [FindsBy(How = How.Id, Using = "txtPIFirstPIPayChangeYearCount")]
        public IWebElement LoanTerm_PI_FirstRate_Year { get; set; }

        [FindsBy(How = How.Id, Using = "txtPIPayMaxAmount")]
        public IWebElement LoanTerm_PI_MaxAmmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtPIPayMaxAmountYearCount")]
        public IWebElement LoanTerm_PI_Effective_Year { get; set; }

        [FindsBy(How = How.Id, Using = "25861")]
        public IWebElement LoanTerm_PI_Clause1 { get; set; }

        [FindsBy(How = How.Id, Using = "25862")]
        public IWebElement LoanTerm_PI_Clause2 { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddPrepaymentPenaltyClauses")]
        public IWebElement LoanTerm_PP_plusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "txtPPExpirationYearsCount")]
        public IWebElement LoanTerm_PP_Expiration_Year { get; set; }

        [FindsBy(How = How.Id, Using = "txtPPMaxLifeAmount")]
        public IWebElement LoanTerm_PP_MaxAmmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='dvLoanTermClauses']/div/ul/li[1]/input[@type='checkbox']")]
        public IWebElement LoanTerm_PP_Clause1 { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddBaloonPaymentClauses")]
        public IWebElement LoanTerm_BP_plusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPMaturityPeriodCount")]
        public IWebElement LoanTerm_BP_Expiration_Year { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPAmount")]
        public IWebElement LoanTerm_BP_MaxAmmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='dvLoanTermClauses']/div/ul/li[1]/input[@type='checkbox']")]
        public IWebElement LoanTerm_BP_Clause1 { get; set; }

        [FindsBy(How = How.Id, Using = "addNewRow")]
        public IWebElement OptionalClausePlusIcon { get; set; }

        [FindsBy(How = How.LinkText, Using = "Enter value")]
        public IWebElement Customclause { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement CustomclauseNew { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement CustomClauseDlg { get; set; }

        [FindsBy(How = How.Id, Using = "spnLoanAmountClauses")]
        public IWebElement CustomClauseSpan { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement ClauseCheckedDlg { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMsg { get; set; }

        [FindsBy(How = How.Id, Using = "spSellerPaid")]
        public IWebElement DTotalSellerPaid { get; set; }

        [FindsBy(How = How.Id, Using = "spPBOValue")]
        public IWebElement DTotalOtherPaid { get; set; }


        [FindsBy(How = How.Id, Using = "lblDisplayDiscountPointPercent")]
        public IWebElement Percentdisplay { get; set; }

        [FindsBy(How = How.Id, Using = "tblGoodFaithVarianceSection")]
        public IWebElement GoodFaithAnalysisTableHeader { get; set; }

        [FindsBy(How = How.Id, Using = "tblGoodFaithVarianceSection")]
        public IWebElement GoodFaithAnalysisZeroPercentTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='collapsible-section-expanded']/div[@id='divZeroPerVariance']/table")]
        public IWebElement GoodFaithAnalysisDataTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@title='% of Loan Amount (Points)']")]
        public IWebElement PercentLoanAmountPoints { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyerAtClosing")]
        public IWebElement BorrowerAtClosingAmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyerBeforeClosing")]
        public IWebElement BorrowerBeforeClosingAmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbySellerAtClosing")]
        public IWebElement SellerAtClosingAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody[@class='ui-sortable']/tr[2]/td[5]/span")]
        public IWebElement SellerBeforeClosingAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody[@class='ui-sortable']/tr[2]/td[6]/span")]
        public IWebElement PaidByOthersAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLenderCreditsSubSection']/tbody/tr[1]/td[2]/span")]
        public IWebElement NonSpecificLenderCreditsAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLenderCreditsSubSection']/tbody/tr[2]/td[2]/span")]
        public IWebElement SpecificLenderCreditsAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLenderCreditsSubSection']/tbody/tr[3]/td[2]/span")]
        public IWebElement LenderCreditsTotalAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@class='Rounded loanEstimateCol']/span[@class='BrokenImageDisplay']")]
        public IWebElement LoanEstimateRoundedBrokenLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//table/tbody/tr[@class='Data-Row']/td[1]/span")]
        public IWebElement GoodFaithDescription { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@class='Data-Row']/td[2]/span")]
        public IWebElement LoanEstimateDisclosedRounded { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@class='Data-Row']/td[3]/span")]
        public IWebElement FinalBorrowerPaidAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@class='Data-Row']/td[4]/span")]
        public IWebElement VarianceLoanEstimateUnrounded { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody/tr[2]/td[@class='Unrounded loanEstimateCol']/span")]
        public IWebElement SectionALoanEstimateUnrounded { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody/tr[2]/td[@class='Rounded loanEstimateCol']/span")]
        public IWebElement SectionALoanEstimateRounded { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody/tr[2]/td[1]")]
        public IWebElement OriginalChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanType")]
        public IWebElement LoanType { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanProductDone")]
        public IWebElement LoanProductDone { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanId")]
        public IWebElement lblLoanId { get; set; }

        [FindsBy(How = How.Id, Using = "lblPopUpLoanId")]
        public IWebElement PopUpLoanId { get; set; }

        [FindsBy(How = How.Id, Using = "lblPopUpMicNum")]
        public IWebElement PopUpMICId { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanIDDetailsOk")]
        public IWebElement LoantypepopupDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnMicNumOk_Click")]
        public IWebElement MICpopupDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtAmountFinanced")]
        public IWebElement txtAmountFinanced { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_M3")]
        public IWebElement M03Expand { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_M4")]
        public IWebElement M04Expand { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_M5")]
        public IWebElement M05Expand { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_M6")]
        public IWebElement M06Expand { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_M7")]
        public IWebElement M07Expand { get; set; }

        [FindsBy(How = How.Id, Using = "tabDelivery")]
        public IWebElement DeliveryOptions { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCDDeliveryOptions")]
        public IWebElement CDDeliveryOptions { get; set; }

        [FindsBy(How = How.Id, Using = "btnTD")]
        public IWebElement TermsAndDates { get; set; }

        [FindsBy(How = How.Id, Using = "chkLenderIssueProvided")]
        public IWebElement LenderIssueProvided { get; set; }

        [FindsBy(How = How.Id, Using = "chkDraft")]
        public IWebElement Draft { get; set; }

        [FindsBy(How = How.Id, Using = "chkInitialCD")]
        public IWebElement InitialCD { get; set; }

        [FindsBy(How = How.Id, Using = "chkCCDPriortoClosing")]
        public IWebElement CCDPriortoClosing { get; set; }

        [FindsBy(How = How.Id, Using = "chkCCDAfterClosing")]
        public IWebElement CCDAfterClosing { get; set; }

        [FindsBy(How = How.Id, Using = "chkDtRec")]
        public IWebElement DateReceived { get; set; }

        [FindsBy(How = How.Id, Using = "txtDateIssued")]
        public IWebElement DateIssuedtxt { get; set; }

        [FindsBy(How = How.Id, Using = "txtClosingDate")]
        public IWebElement ClosingDatetxt { get; set; }

        [FindsBy(How = How.Id, Using = "txtDisbursementDate")]
        public IWebElement DisbursementDatetxt { get; set; }

        [FindsBy(How = How.Id, Using = "txtAckReceivedDt")]
        public IWebElement DateRecievedText { get; set; }

        [FindsBy(How = How.Id, Using = "rdoDeliveryTypeOther")]
        public IWebElement DelveryType_Other_RdoBtn { get; set; }

        [FindsBy(How = How.Id, Using = "rdoDeliveryTypePersonal")]
        public IWebElement DelveryType_Personal_RdoBtn { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement DeliveryButton { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement DeliveryMethod { get; set; }

        [FindsBy(How = How.Id, Using = "chkDtRec")]
        public IWebElement DateRecievedAck { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCDDeliveryComments")]
        public IWebElement Delivery_Comments { get; set; }

        [FindsBy(How = How.Id, Using = "chkComments")]
        public IWebElement CommentsChkbox { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement CommentsTextArea { get; set; }

        [FindsBy(How = How.Id, Using = "spnDtIssuedDraft")]
        public IWebElement DateIssuedSpan { get; set; }

        [FindsBy(How = How.Id, Using = "spnClosingDtDraft")]
        public IWebElement ClosingDateSpan { get; set; }

        [FindsBy(How = How.Id, Using = "spnDisbDtDraft")]
        public IWebElement DisbursementDateSpan { get; set; }

        [FindsBy(How = How.Id, Using = "btnDateRecalAlertDone")]
        public IWebElement AlertYesBtn { get; set; }

        [FindsBy(How = How.Id, Using = "btnDateRecalAlertCancel")]
        public IWebElement AlertNoBtn { get; set; }

        [FindsBy(How = How.Id, Using = "btnSundayWarningDone")]
        public IWebElement SundayAlertYesBtn { get; set; }

        [FindsBy(How = How.Id, Using = "btnSundayWarningCancel")]
        public IWebElement SundayAlertNoBtn { get; set; }

        [FindsBy(How = How.Id, Using = "spnDateRecalcAlert")]
        public IWebElement AlertMessage { get; set; }

        [FindsBy(How = How.Id, Using = "imgdivItemizedRecordingFee")]
        public IWebElement ItemizedRecordingFeePlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "divRecordingFee")]
        public IWebElement divRecordingFee { get; set; }

        [FindsBy(How = How.Id, Using = "tblItemizedRecordingFeeSection_Deed")]
        public IWebElement ItemizedRecFeeDeedTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblItemizedRecordingFeeSection_Mortgage")]
        public IWebElement ItemizedRecFeeMortgageTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblItemizedRecordingFeeSection_Mortgage Broker")]
        public IWebElement ItemizedRecFeeMortgageTable_1 { get; set; }
        
        [FindsBy(How = How.Id, Using = "tblItemizedRecordingFeeSection_Release")]
        public IWebElement ItemizedRecFeeReleaseTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblItemizedRecordingFeeSection_Miscellaneous")]
        public IWebElement ItemizedRecFeeMiscTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblItemizedRecordingFeeSection_Lender")]
        public IWebElement ItemizedRecFeeLenderTable { get; set; }
        
        [FindsBy(How = How.CssSelector, Using = "table[id*=\"tblItemizedRecordingFeeSection_Mortgage\"]")]
        public IWebElement ItemizedRecFeeMBTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnRecordingFeeDone")]
        public IWebElement RecordingFeeDone { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLenderCredits")]
        public IWebElement LenderCreditAnalysis { get; set; }

        [FindsBy(How = How.Id, Using = "imgPrepaidInterest")]
        public IWebElement F03PlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "rblId_688")]
        public IWebElement F03NewLoanRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "rblId_670")]
        public IWebElement F03MortgageBrokerRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "rblId_0")]
        public IWebElement F03NoneRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "tblPrepaidInterest")]
        public IWebElement F03TablePrepaidInterestTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrepaidInterestCancel")]
        public IWebElement F03Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrepaidInterestDone")]
        public IWebElement F03Done { get; set; }

        [FindsBy(How = How.Id, Using = "rdoLoanTermYearMonth")]
        public IWebElement rdoLoanTermYearMonthRdobtn { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLoanType")]
        public IWebElement LoanTypeDropDown { get; set; }

        [FindsBy(How = How.Id, Using = "btnLoanTypeCancel")]
        public IWebElement LoantypeCancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanPurpose")]
        public IWebElement LoanPurpose { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupChargeM3")]
        public IWebElement M03Plus { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo1")]
        public IWebElement SectionL06_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc1")]
        public IWebElement SectionL06_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt1")]
        public IWebElement SectionL06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_seqNo2")]
        public IWebElement SectionL07_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_desc2")]
        public IWebElement SectionL07_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_OtherCredits_amt2")]
        public IWebElement SectionL07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo1")]
        public IWebElement SectionL08_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc1")]
        public IWebElement SectionL08_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt1")]
        public IWebElement SectionL08_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo2")]
        public IWebElement SectionL09_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc2")]
        public IWebElement SectionL09_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt2")]
        public IWebElement SectionL09_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo3")]
        public IWebElement SectionL10_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc3")]
        public IWebElement SectionL10_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt3")]
        public IWebElement SectionL10_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_seqNo4")]
        public IWebElement SectionL11_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_desc4")]
        public IWebElement SectionL11_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_Adjustments_amt4")]
        public IWebElement SectionL11_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyerOnly")]
        public IWebElement BuyerOnly { get; set; }

        [FindsBy(How = How.Id, Using = "chkBorrowerOnly")]
        public IWebElement BorrowerOnly { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerOnly5")]
        public IWebElement SellerOnly5 { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerOnly2")]
        public IWebElement SellerOnly2 { get; set; }

        [FindsBy(How = How.Id, Using = "chkCombined")]
        public IWebElement Combined { get; set; }

        [FindsBy(How = How.Id, Using = "chkItemizedRecordingFees")]
        public IWebElement IncludeItemizedRecFees { get; set; }       

        [FindsBy(How = How.Id, Using = "chkBuyerOnlyCR")]
        public IWebElement BuyerOnlyCR { get; set; }

        [FindsBy(How = How.Id, Using = "chkBorrowerOnlyCR")]
        public IWebElement BorrowerOnlyCR { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerOnly5CR")]
        public IWebElement SellerOnly5CR { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerOnly2CR")]
        public IWebElement SellerOnly2CR { get; set; }

        [FindsBy(How = How.Id, Using = "chkCombinedCR")]
        public IWebElement CombinedCR { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyerOnlySLN")]
        public IWebElement BuyerOnlySLN { get; set; }

        [FindsBy(How = How.Id, Using = "chkBorrowerOnlySLN")]
        public IWebElement BorrowerOnlySLN { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerOnly5SLN")]
        public IWebElement SellerOnly5SLN { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerOnly2SLN")]
        public IWebElement SellerOnly2SLN { get; set; }

        [FindsBy(How = How.Id, Using = "chkCombinedSLN")]
        public IWebElement CombinedSLN { get; set; }

        [FindsBy(How = How.Id, Using = "chkAppStmtOther")]
        public IWebElement IncApp { get; set; }

        [FindsBy(How = How.Id, Using = "chkAddStmtOnForm")]
        public IWebElement IncAddenum { get; set; }

        [FindsBy(How = How.Id, Using = "chkCertSignature")]
        public IWebElement IncCert { get; set; }

        [FindsBy(How = How.Id, Using = "chkCertEscrowSignature")]
        public IWebElement IncEscro { get; set; }

        [FindsBy(How = How.Id, Using = "btnDownloadXML")]
        public IWebElement DownloadXML { get; set; }
        //TODO: ADD FindsByAttribute
        public IWebElement Payoffs_Description { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Payoffs_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "txtTo")]
        public IWebElement EmailTo { get; set; }

        [FindsBy(How = How.Id, Using = "btnSaveComment")]
        public IWebElement SaveComment { get; set; }

        [FindsBy(How = How.Id, Using = "spnMSGSundayWarning")]
        public IWebElement SundayWarning { get; set; }

        [FindsBy(How = How.Id, Using = "divImgGroupToggle_L1")]
        public IWebElement L06_Expand { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_0_-1")]
        public IWebElement E01UnroundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_0_-1")]
        public IWebElement E01RoundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_0_158857008")]
        public IWebElement B01UnroundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_0_158856982")]
        public IWebElement B02UnroundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_0_158857008")]
        public IWebElement B01RoundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_0_158856982")]
        public IWebElement B02RoundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo3")]
        public IWebElement SectionM03_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc3")]
        public IWebElement SectionM03_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt3")]
        public IWebElement SectionM03_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo4")]
        public IWebElement SectionM04_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc4")]
        public IWebElement SectionM04_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt4")]
        public IWebElement SectionM04_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo5")]
        public IWebElement SectionM05_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc5")]
        public IWebElement SectionM05_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt5")]
        public IWebElement SectionM05_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo6")]
        public IWebElement SectionM06_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc6")]
        public IWebElement SectionM06_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt6")]
        public IWebElement SectionM06_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo7")]
        public IWebElement SectionM07_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc7")]
        public IWebElement SectionM07_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt7")]
        public IWebElement SectionM07_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_seqNo8")]
        public IWebElement SectionM08_Seqno { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_desc8")]
        public IWebElement SectionM08_Label { get; set; }

        [FindsBy(How = How.Id, Using = "sectionM_amt8")]
        public IWebElement SectionM08_Amt { get; set; }

        [FindsBy(How = How.Id, Using = "spanSecurityInterest")]
        public IWebElement SecurityInterestAddress { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayDescription_-1_-1")]
        public IWebElement OtherCostE02Desc { get; set; }

        [FindsBy(How = How.Id, Using = "tdE02PlusUnrounded")]
        public IWebElement E02PlusUnroundedAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tdE02PlusRounded")]
        public IWebElement E02PlusRoundedAmt { get; set; }

        [FindsBy(How = How.Id, Using = "ChargeDescr_410224507")]
        public IWebElement PayoffEditedPane { get; set; }

        [FindsBy(How = How.Id, Using = "tblPayoffsandPaymentsSection")]
        public IWebElement PayoffTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblPayoffSubChargePopUp")]
        public IWebElement PayoffSubChargePopUpTable { get; set; }

        [FindsBy(How = How.Id, Using = "370_1")]
        public IWebElement GroupChargePlus { get; set; }

        [FindsBy(How = How.Id, Using = "371_2")]
        public IWebElement GroupChargePlus4 { get; set; }

        [FindsBy(How = How.Id, Using = "373_1")]
        public IWebElement GroupChargePlus5 { get; set; }

        [FindsBy(How = How.Id, Using = "373_2")]
        public IWebElement GroupChargePlus5_1 { get; set; }

        [FindsBy(How = How.Id, Using = "93_1")]
        public IWebElement GroupChargePlus2 { get; set; }

        [FindsBy(How = How.Id, Using = "353_1")]
        public IWebElement GroupChargePlus3 { get; set; }

        [FindsBy(How = How.Id, Using = "354_2")]
        public IWebElement GroupChargePlus6 { get; set; }

        [FindsBy(How = How.Id, Using = "354_3")]
        public IWebElement GroupChargePlus7 { get; set; }

        [FindsBy(How = How.Id, Using = "btnPayoffSubChargePopUpDone")]
        public IWebElement PayoffPopupDone { get; set; }

        [FindsBy(How = How.Id, Using = "spnTPPComments")]
        public IWebElement TotalPandPDidThisChng { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRoundedAmount_-1_-1")]
        public IWebElement RoundedSpan { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayLEAmount_-1_-1")]
        public IWebElement UnRoundedSpan { get; set; }

        [FindsBy(How = How.Id, Using = "BuyerImage")]
        public IWebElement BuyerImageDoc { get; set; }

        [FindsBy(How = How.Id, Using = "BorrowerImage")]
        public IWebElement BorrowerImageDoc { get; set; }

        [FindsBy(How = How.Id, Using = "Seller5Image")]
        public IWebElement Seller5PageImageDoc { get; set; }

        [FindsBy(How = How.Id, Using = "Seller2Image")]
        public IWebElement Seller2PageImageDoc { get; set; }

        [FindsBy(How = How.Id, Using = "CombinedImage")]
        public IWebElement CombinedImageDoc { get; set; }

        [FindsBy(How = How.Id, Using = "lblClosingDt")]
        public IWebElement ClosingDtLbl { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbursementDt")]
        public IWebElement DisbursementDtLbl { get; set; }

        [FindsBy(How = How.Id, Using = "lblDtIssued")]
        public IWebElement IssuedDtLbl { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanCostSubSection_A")]
        public IWebElement OriginalChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanCostSubSection_B")]
        public IWebElement ServicesBorrowerDidNotShopForTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanCostSubSection_C")]
        public IWebElement ServicesBorrowerDidShopForTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanCostSubSection_D")]
        public IWebElement TotalLoanCostsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_J")]
        public IWebElement TotalClosingCostsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostSubSection_H")]
        public IWebElement OtherCostsOtherSectionHTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblContactInformation")]
        public IWebElement ContactInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "imgAdd")]
        public IWebElement AdditionalContacts { get; set; }

        [FindsBy(How = How.Id, Using = "PDDImage")]
        public IWebElement PDDImageSectionA { get; set; }

        [FindsBy(How = How.Id, Using = "PDDImage")]
        public IWebElement PDDImageSectionB { get; set; }


        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody/tr[3]/td[1]/span/img[@class='PDDImage']")]
        public IWebElement OriginationChargesPDDImageSectionA_01 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_A']/tbody/tr[4]/td[1]/span/img[@class='PDDImage']")]
        public IWebElement OriginationChargesPDDImageSectionA_02 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_B']/tbody/tr[2]/td[1]/span/img[@class='PDDImage']")]
        public IWebElement ServicesBorrowerDidNotShopPDDImageSectionB_01 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblLoanCostSubSection_B']/tbody/tr[3]/td[1]/span/img[@class='PDDImage']")]
        public IWebElement ServicesBorrowerDidNotShopPDDImageSectionB_02 { get; set; }

        [FindsBy(How = How.Id, Using = "PDDImage")]
        public IWebElement PDDImageSectionC { get; set; }

        [FindsBy(How = How.Id, Using = "txtEndYear0")]
        public IWebElement Section3_Years { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId8")]
        public IWebElement PaymentCustomOption { get; set; }

        [FindsBy(How = How.Id, Using = "txtEighthOption")]
        public IWebElement PaymentCustomText { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdjustableInterestDone")]
        public IWebElement PaymentSchedule_Done { get; set; }

        [FindsBy(How = How.Id, Using = "txtAPStartDate")]
        public IWebElement APPaymentStartDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtAPEndDate")]
        public IWebElement APPaymentEndtDate { get; set; }

        [FindsBy(How = How.Id, Using = "imgddlIntPayment")]
        public IWebElement InterestOnlyPayments_PlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "imgddlOptPayments")]
        public IWebElement OptionalPayments_PlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "imgddlStepPayments")]
        public IWebElement StepPayments_PlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "imgddlSeasonalPayments")]
        public IWebElement SeasonalPayments_PlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "tblLenderCreditsSubSection")]
        public IWebElement tblLenderCreditsSubSection { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-AdjforItems_L")]
        public IWebElement adjForItemsTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dvLoanCostSection_A > table")]
        public IWebElement TableLoanCostSectionA { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dvLoanCostSection_B > table")]
        public IWebElement TableLoanCostSectionB { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dvLoanCostSection_C > table")]
        public IWebElement TableLoanCostSectionC { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dvLoanCostSection_D > table")]
        public IWebElement TableLoanCostSectionD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divOtherCostSection_E > table")]
        public IWebElement TableOtherCostSectionE { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divOtherCostSection_F > table")]
        public IWebElement TableOtherCostSectionF { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divOtherCostSection_G > table")]
        public IWebElement TableOtherCostSectionG { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divOtherCostSection_H > table")]
        public IWebElement TableOtherCostSectionH { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divOtherCostSection_I > table")]
        public IWebElement TableOtherCostSectionI { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divOtherCostSection_J > table")]
        public IWebElement TableOtherCostSectionJ { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo12")]
        public IWebElement SectionL12_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo13")]
        public IWebElement SectionL13_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo14")]
        public IWebElement SectionL14_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo15")]
        public IWebElement SectionL15_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo16")]
        public IWebElement SectionL16_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo17")]
        public IWebElement SectionL17_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo17a")]
        public IWebElement SectionL17a_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo17b")]
        public IWebElement SectionL17b_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo17c")]
        public IWebElement SectionL17c_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo17d")]
        public IWebElement SectionL17d_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "sectionL_seqNo17e")]
        public IWebElement SectionL17e_SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-AdjforItems_K")]
        public IWebElement SectionK_AdjustmentforItemsSubTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-AdjforItems_M")]
        public IWebElement SectionM_AdjustmentforItemsSubTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-AdjforItems_L")]
        public IWebElement SectionL_AdjustmentforItemsSubTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-AdjforItems_N")]
        public IWebElement SectionN_AdjustmentforItemsSubTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblLenderCreditsSection")]
        public IWebElement LenderCreditAnalysisTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_DueItemsN")]
        public IWebElement SectionN_DueItemsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_DueItemsM")]
        public IWebElement SectionM_DueItemsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_DueItemsL")]
        public IWebElement SectionL_DueItemsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbl_transSummary_OtherCreditsL")]
        public IWebElement SectionL_DueItemsTable_OtherCredits { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-Adjustments_L")]
        public IWebElement SectionL_DueItemsTable_Adjustments { get; set; }

        [FindsBy(How = How.Id, Using = "tbl-transSummary-AdjforItems_L")]
        public IWebElement SectionL_DueItemsTable_AdjustmentsForItems { get; set; }

        [FindsBy(How = How.Name, Using = "tbl-transSummary-Calculation")]
        public IWebElement TransactionSummary_CalculationTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblPayoffsandPaymentsDescr")]
        public IWebElement PayOffsAndPaymentDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tblTenPerVariance")]
        public IWebElement GoodFaithAnalysisCategoryTable { get; set; }

        [FindsBy(How = How.Id, Using = "PayoffsSubChargesPopUP")]
        public IWebElement PayoffPopupTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanTerms")]
        public IWebElement Loan_Terms { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleProjectedPayments")]
        public IWebElement Projected_Payments { get; set; }

        [FindsBy(How = How.Id, Using = "img_3011")]
        public IWebElement ProjectedPaymentsPencilIcon { get; set; }

      
        [FindsBy(How = How.Id, Using = "img_3072")]
        public IWebElement LoanDisclosurePencilIcon { get; set; }


        [FindsBy(How = How.Id, Using = "lblSecTitleCostsAtClosing")]
        public IWebElement Costs_at_Closing { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanCosts")]
        public IWebElement Loan_Costs { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleOtherCosts")]
        public IWebElement Other_Costs { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitlePayoffsandPayments")]
        public IWebElement Payoffs_and_Payments { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCalCashToClose")]
        public IWebElement Calculating_Cash_to_Close { get; set; }

        [FindsBy(How = How.Id, Using = "spnTCCLEAmount")]
        public IWebElement CCC_TotalClosingCostsJ_txt { get; set; }

        [FindsBy(How = How.Id, Using = "spnDPLEAmount")]
        public IWebElement CCC_spnDPLEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "spnDPComments")]
        public IWebElement CCC_spnDPComments { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleSummOfTrans")]
        public IWebElement Summaries_of_Transactions { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanDisclosures")]
        public IWebElement Loan_Disclosures { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleAdjustablePayment")]
        public IWebElement AP_AIR { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanCalc")]
        public IWebElement Loan_Calculations { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanCalculations")]
        public IWebElement Loan_Calculations_table { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleOtherDiscc")]
        public IWebElement Other_Disclosures { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleContInfo")]
        public IWebElement Contact_Information { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tblLoanCostSubSection_B td.SellerAtClosing span")]
        public IWebElement LoanCostsSectionBSellerAtClosingAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tblCDHeaderSec")]
        public IWebElement CDHeaderSectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "tr_Propety_1")]
        public IWebElement ClosingInfo_FileProperty1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnPropertyOk")]
        public IWebElement ClosingInfo_PropertyOk { get; set; }

        [FindsBy(How = How.Id, Using = "LoanTermInfo")]
        public IWebElement LoanTermsTable { get; set; }

        [FindsBy(How = How.Id, Using = "divLoanAmountClauses")]
        public IWebElement LoanTerms_LoanAmountClauses { get; set; }

        [FindsBy(How = How.Id, Using = "divInterestRateClauses")]
        public IWebElement LoanTerms_InterestRateClauses { get; set; }

        [FindsBy(How = How.Id, Using = "divPrincipalandInterestClauses")]
        public IWebElement LoanTerms_PrincipalAndInterestClauses { get; set; }

        [FindsBy(How = How.Id, Using = "divPrepaymentPenaltyClauses")]
        public IWebElement LoanTerms_PrepaymentPenaltyClauses { get; set; }

        [FindsBy(How = How.Id, Using = "divBaloonPaymentClauses")]
        public IWebElement LoanTerms_BalloonPaymentClauses { get; set; }
        [FindsBy(How = How.Id, Using = "lblLoanProduct1")]
        public IWebElement LoanInfo_Product1_lbl { get; set; }

        [FindsBy(How = How.Id, Using = "BorrowerInfoFAId0")]
        public IWebElement TransInfo_BorrowerInfo_FwdAddress1_chk { get; set; }
        
        [FindsBy(How = How.Id, Using = "SellerInfoFAId0")]
        public IWebElement TransInfo_SellerInfo_FwdAddress1_chk { get; set; }

        [FindsBy(How = How.Id, Using = "BorrowerCAddress_1")]
        public IWebElement TransInfo_BorrowerInfo_CurrentAddress { get; set; }

        [FindsBy(How = How.Id, Using = "sellerCAddress_1")]
        public IWebElement TransInfo_SellerInfo_CurrentAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BorrowerFAddress_1")]
        public IWebElement TransInfo_BorrowerInfo_FwdAddress { get; set; }

        [FindsBy(How = How.Id, Using = "sellerFAddress_1")]
        public IWebElement TransInfo_SellerInfo_FwdAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tblSettlmentAgnt")]
        public IWebElement SettlementAgentTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divLoanTermsHeader table")]
        public IWebElement LoanTermsHeadingTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divLoanTermsSection table")]
        public IWebElement LoanTermsSecHeadingTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblSettlmentAgnt")]
        public IWebElement tblSettlmentAgnts { get; set; }

        [FindsBy(How = How.Id, Using = "btnSettlementAgentDone")]
        public IWebElement btnSettlementAgentDone { get; set; }

        [FindsBy(How = How.Id, Using = "spanLenderUpdate")]
        public IWebElement LenderUpdate { get; set; }

        [FindsBy(How = How.Id, Using = "spanOtherUpdate")]
        public IWebElement OtherCDUpdate { get; set; }

        [FindsBy(How = How.Id, Using = "img_3009")]
        public IWebElement LoanInformationReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDEvents")]
        public IWebElement CDEvents { get; set; }

        [FindsBy(How = How.Id, Using = "img_3010")]
        public IWebElement LoanTermsReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3014")]
        public IWebElement LoanCostsSectionAReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3015")]
        public IWebElement LoanCostsSectionBReviewIcon { get; set; }
        
        [FindsBy(How = How.Id, Using = "img_3062")]
        public IWebElement SessionG_ReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3076")]
        public IWebElement OtherDisclosuresReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3073")]
        public IWebElement APnAIRReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3073")]
        public IWebElement APReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3074")]
        public IWebElement AIRReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_3061")]
        public IWebElement SectionFReviewIcon { get; set; }

        [FindsBy(How = How.Id, Using = "ddl")]
        public IWebElement ProjectedPayment_PaymentCalculation_YearRange { get; set; }

        [FindsBy(How = How.Id, Using = "btnYearRangeDone")]
        public IWebElement YearRangeDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnYearRangeCancel")]
        public IWebElement YearRangeCancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnPropertyOk")]
        public IWebElement PropertyDone { get; set; }

        [FindsBy(How = How.Id, Using = "ddlYearRanges0")]
        public IWebElement ProjectedPayment_ddlYearRanges1 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlYearRanges1")]
        public IWebElement ProjectedPayment_ddlYearRanges2 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlYearRanges2")]
        public IWebElement ProjectedPayment_ddlYearRanges3 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlYearRanges3")]
        public IWebElement ProjectedPayment_ddlYearRanges4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtBeginYear0")]
        public IWebElement ProjectedPayment_txtStartYear1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtBeginYear1")]
        public IWebElement ProjectedPayment_txtStartYear2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtBeginYear2")]
        public IWebElement ProjectedPayment_txtStartYear3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtBeginYear3")]
        public IWebElement ProjectedPayment_txtStartYear4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtEndYear0")]
        public IWebElement ProjectedPayment_txtEndYear1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtEndYear1")]
        public IWebElement ProjectedPayment_txtEndYear2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtEndYear2")]
        public IWebElement ProjectedPayment_txtEndYear3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtEndYear3")]
        public IWebElement ProjectedPayment_txtEndYear4 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI0")]
        public IWebElement ProjectedPayment_PrincInterest1Plus { get; set; }
        [FindsBy(How = How.Id, Using = "tdPI0")]
        public IWebElement ProjectedPayment_PrincInterestYear1 { get; set; }

        [FindsBy(How = How.Id, Using = "tdPI1")]
        public IWebElement ProjectedPayment_PrincInterestYear2 { get; set; }

        [FindsBy(How = How.Id, Using = "tdPI2")]
        public IWebElement ProjectedPayment_PrincInterestYear3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay0")]
        public IWebElement ProjectedPayment_EstimatedTotalYear1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay1")]
        public IWebElement ProjectedPayment_EstimatedTotalYear2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay2")]
        public IWebElement ProjectedPayment_EstimatedTotalYear3 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoMinimumMaximum")]
        public IWebElement ProjectedPayment_rdoMinimumMaximum { get; set; }

        [FindsBy(How = How.Id, Using = "rdoOnlyInterest")]
        public IWebElement ProjectedPayment_rdoOnlyInterest { get; set; }

        [FindsBy(How = How.Id, Using = "rdoPrincipalInterest")]
        public IWebElement ProjectedPayment_rdoPrincipalInterest { get; set; }

        [FindsBy(How = How.Id, Using = "txtPrincipalInterest")]
        public IWebElement ProjectedPayment_txtPrincipalInterest { get; set; }

        [FindsBy(How = How.Id, Using = "txtPopInterest")]
        public IWebElement ProjectedPayment_OnlyInterest { get; set; }

        [FindsBy(How = How.Id, Using = "txtMortInsAmt1")]
        public IWebElement ProjectedPayment_txtMortInsAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMortInsAmt2")]
        public IWebElement ProjectedPayment_txtMortInsAmt2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtEstEscAmt1")]
        public IWebElement ProjectedPayment_txtEstEscAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtEstEscAmt2")]
        public IWebElement ProjectedPayment_txtEstEscAmt2 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI1")]
        public IWebElement ProjectedPayment_PrincInterest2Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI2")]
        public IWebElement ProjectedPayment_PrincInterest3Plus { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI3")]
        public IWebElement ProjectedPayment_PrincInterest4Plus { get; set; }

        [FindsBy(How = How.Id, Using = "tblProjectedPayment")]
        public IWebElement ProjectedPaymentTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtETIAmt")]
        public IWebElement ProjectedPayment_Estimated_TI_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "txtPPEstimateOtherInEscrow")]
        public IWebElement Section3_EstimateOtherInEscrowText { get; set; }
        [FindsBy(How = How.Id, Using = "lblPPEstimateIncludesOtherInEscrowID")]
        public IWebElement Section3_lblEstimateIncludesInEscrowID { get; set; }

        [FindsBy(How = How.Id, Using = "tblRecordingFeeSection")]
        public IWebElement RecordingFeeSection { get; set; }
        [FindsBy(How = How.Id, Using = "btnPPOtherCancel")]
        public IWebElement Section3_btnPPOtherCancel { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divPopUpDateRecalculation>#divAlert.CloseButton")]
        public IWebElement AlertCloseBtn { get; set; }

        //CALCULATION
        [FindsBy(How = How.Id, Using = "chkFromBorrower")]
        public IWebElement SOTFromBorrower { get; set; }

        [FindsBy(How = How.Id, Using = "chkToBorrower")]
        public IWebElement SOTToBorrower { get; set; }

        [FindsBy(How = How.Id, Using = "chkFromSeller")]
        public IWebElement SOTFromSeller { get; set; }

        [FindsBy(How = How.Id, Using = "chkToSeller")]
        public IWebElement SOTToSeller { get; set; }

        //-----------------
        [FindsBy(How = How.Id, Using = "N3Desc")]
        public IWebElement N3PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc1")]
        public IWebElement N3SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc2")]
        public IWebElement N3SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc3")]
        public IWebElement N3SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc4")]
        public IWebElement N3SubChargeDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc5")]
        public IWebElement N3SubChargeDesc5 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc6")]
        public IWebElement N3SubChargeDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc7")]
        public IWebElement N3SubChargeDesc7 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc8")]
        public IWebElement N3SubChargeDesc8 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Desc9")]
        public IWebElement N3SubChargeDesc9 { get; set; }

        [FindsBy(How = How.Id, Using = "N3TotalAmt")]
        public IWebElement N3TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt1")]
        public IWebElement N3SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt12")]
        public IWebElement N3SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt13")]
        public IWebElement N3SubCharge_SubTotalAmt13 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt14")]
        public IWebElement N3SubCharge_SubTotalAmt14 { get; set; }


        [FindsBy(How = How.Id, Using = "N3SubCharge_SubTotalAmt5")]
        public IWebElement N3SubCharge_SubTotalAmt5 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt16")]
        public IWebElement N3SubCharge_SubTotalAmt16 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt17")]
        public IWebElement N3SubCharge_SubTotalAmt17 { get; set; }

        [FindsBy(How = How.Id, Using = "N3SubCharge_Amt18")]
        public IWebElement N3SubCharge_SubTotalAmt18 { get; set; }

        [FindsBy(How = How.Id, Using = "N4Desc")]
        public IWebElement N4PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc1")]
        public IWebElement N4SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc2")]
        public IWebElement N4SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc3")]
        public IWebElement N4SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc4")]
        public IWebElement N4SubChargeDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc5")]
        public IWebElement N4SubChargeDesc5 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc6")]
        public IWebElement N4SubChargeDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc7")]
        public IWebElement N4SubChargeDesc7 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc8")]
        public IWebElement N4SubChargeDesc8 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc9")]
        public IWebElement N4SubChargeDesc9 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Desc10")]
        public IWebElement N4SubChargeDesc10 { get; set; }


        [FindsBy(How = How.Id, Using = "N4TotalAmt")]
        public IWebElement N4TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt11")]
        public IWebElement N4SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt12")]
        public IWebElement N4SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt13")]
        public IWebElement N4SubCharge_SubTotalAmt13 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt14")]
        public IWebElement N4SubCharge_SubTotalAmt14 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt15")]
        public IWebElement N4SubCharge_SubTotalAmt5 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt16")]
        public IWebElement N4SubCharge_SubTotalAmt16 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt17")]
        public IWebElement N4SubCharge_SubTotalAmt17 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt18")]
        public IWebElement N4SubCharge_SubTotalAmt18 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt19")]
        public IWebElement N4SubCharge_SubTotalAmt19 { get; set; }

        [FindsBy(How = How.Id, Using = "N4SubCharge_Amt110")]
        public IWebElement N4SubCharge_SubTotalAmt20 { get; set; }
        


        //n06
        [FindsBy(How = How.Id, Using = "N5Desc")]
        public IWebElement N5PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc1")]
        public IWebElement N5SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc2")]
        public IWebElement N5SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc3")]
        public IWebElement N5SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc4")]
        public IWebElement N5SubChargeDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc5")]
        public IWebElement N5SubChargeDesc5 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc6")]
        public IWebElement N5SubChargeDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc7")]
        public IWebElement N5SubChargeDesc7 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc8")]
        public IWebElement N5SubChargeDesc8 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc9")]
        public IWebElement N5SubChargeDesc9 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Desc10")]
        public IWebElement N5SubChargeDesc10 { get; set; }


        [FindsBy(How = How.Id, Using = "N5TotalAmt")]
        public IWebElement N5TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt11")]
        public IWebElement N5SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt12")]
        public IWebElement N5SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt13")]
        public IWebElement N5SubCharge_SubTotalAmt13 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt14")]
        public IWebElement N5SubCharge_SubTotalAmt14 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt15")]
        public IWebElement N5SubCharge_SubTotalAmt5 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt16")]
        public IWebElement N5SubCharge_SubTotalAmt16 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt17")]
        public IWebElement N5SubCharge_SubTotalAmt17 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt18")]
        public IWebElement N5SubCharge_SubTotalAmt18 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt19")]
        public IWebElement N5SubCharge_SubTotalAmt19 { get; set; }

        [FindsBy(How = How.Id, Using = "N5SubCharge_Amt110")]
        public IWebElement N5SubCharge_SubTotalAmt20 { get; set; }


        [FindsBy(How = How.Id, Using = "N10Desc")]
        public IWebElement N10PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Desc1")]
        public IWebElement N10SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Desc2")]
        public IWebElement N10SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Desc3")]
        public IWebElement N10SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Desc4")]
        public IWebElement N10SubChargeDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Desc5")]
        public IWebElement N10SubChargeDesc5 { get; set; }


        [FindsBy(How = How.Id, Using = "N10TotalAmt")]
        public IWebElement N10TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Amt11")]
        public IWebElement N10SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Amt12")]
        public IWebElement N10SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Amt13")]
        public IWebElement N10SubCharge_SubTotalAmt13 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Amt14")]
        public IWebElement N10SubCharge_SubTotalAmt14 { get; set; }

        [FindsBy(How = How.Id, Using = "N10SubCharge_Amt15")]
        public IWebElement N10SubCharge_SubTotalAmt5 { get; set; }


        [FindsBy(How = How.Id, Using = "N9Desc")]
        public IWebElement N9PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Desc1")]
        public IWebElement N9SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Desc2")]
        public IWebElement N9SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Desc3")]
        public IWebElement N9SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Desc4")]
        public IWebElement N9SubChargeDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Desc5")]
        public IWebElement N9SubChargeDesc5 { get; set; }


        [FindsBy(How = How.Id, Using = "N9TotalAmt")]
        public IWebElement N9TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Amt11")]
        public IWebElement N9SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Amt12")]
        public IWebElement N9SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Amt13")]
        public IWebElement N9SubCharge_SubTotalAmt13 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Amt14")]
        public IWebElement N9SubCharge_SubTotalAmt14 { get; set; }

        [FindsBy(How = How.Id, Using = "N9SubCharge_Amt15")]
        public IWebElement N9SubCharge_SubTotalAmt5 { get; set; }

        //------------------------------------------------------
        //L03

        [FindsBy(How = How.Id, Using = "L3Desc")]
        public IWebElement L3PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc1")]
        public IWebElement L3SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc2")]
        public IWebElement L3SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc3")]
        public IWebElement L3SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc4")]
        public IWebElement L3SubChargeDesc4 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc5")]
        public IWebElement L3SubChargeDesc5 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc6")]
        public IWebElement L3SubChargeDesc6 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc7")]
        public IWebElement L3SubChargeDesc7 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc8")]
        public IWebElement L3SubChargeDesc8 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Desc9")]
        public IWebElement L3SubChargeDesc9 { get; set; }

        [FindsBy(How = How.Id, Using = "L3TotalAmt")]
        public IWebElement L3TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_SubTotalAmt1")]
        public IWebElement L3SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt12")]
        public IWebElement L3SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt13")]
        public IWebElement L3SubCharge_SubTotalAmt13 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt14")]
        public IWebElement L3SubCharge_SubTotalAmt14 { get; set; }


        [FindsBy(How = How.Id, Using = "L3SubCharge_SubTotalAmt5")]
        public IWebElement L3SubCharge_SubTotalAmt5 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt16")]
        public IWebElement L3SubCharge_SubTotalAmt16 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt17")]
        public IWebElement L3SubCharge_SubTotalAmt17 { get; set; }

        [FindsBy(How = How.Id, Using = "L3SubCharge_Amt18")]
        public IWebElement L3SubCharge_SubTotalAmt18 { get; set; }

        //--L04
        [FindsBy(How = How.Id, Using = "L4Desc")]
        public IWebElement L4PopUpDecription { get; set; }

        [FindsBy(How = How.Id, Using = "L4SubCharge_Desc1")]
        public IWebElement L4SubChargeDesc1 { get; set; }

        [FindsBy(How = How.Id, Using = "L4SubCharge_Desc2")]
        public IWebElement L4SubChargeDesc2 { get; set; }

        [FindsBy(How = How.Id, Using = "L4SubCharge_Desc3")]
        public IWebElement L4SubChargeDesc3 { get; set; }

        [FindsBy(How = How.Id, Using = "L4TotalAmt")]
        public IWebElement L4TotalAmt { get; set; }

        [FindsBy(How = How.Id, Using = "L4SubCharge_SubTotalAmt1")]
        public IWebElement L4SubCharge_SubTotalAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "L4SubCharge_Amt12")]
        public IWebElement L4SubCharge_SubTotalAmt12 { get; set; }

        [FindsBy(How = How.Id, Using = "L4SubCharge_Amt13")]
        public IWebElement L4SubCharge_SubTotalAmt13 { get; set; }


        [FindsBy(How = How.Id, Using = "ddlTest")]
        public IWebElement PaymentSceduleFrom1 { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTest2")]
        public IWebElement PaymentSceduleFrom2 { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId1")]
        public IWebElement PaymentScheduleForyourFirstPyment { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId2")]
        public IWebElement PaymentScheduleForyourPaymenttoPayment { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId2")]
        public IWebElement spnInterestOnlyPaymentId2 { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId3")]
        public IWebElement spnInterestOnlyPaymentId3 { get; set; }


        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId3")]
        public IWebElement PaymentScheduleFrommonthtomonth { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId4")]
        public IWebElement EveryMonth { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId6")]
        public IWebElement spnInterestOnlyPaymentId6 { get; set; }


        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId5")]
        public IWebElement EveryQuarter { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId7")]
        public IWebElement spnInterestOnlyPaymentId7 { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId6")]
        public IWebElement EveryQuartuntill { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId8")]
        public IWebElement spnInterestOnlyPaymentId8 { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId7")]
        public IWebElement EveryQUntill { get; set; }

        [FindsBy(How = How.Id, Using = "spnInterestOnlyPaymentId9")]
        public IWebElement spnInterestOnlyPaymentId9 { get; set; }

        [FindsBy(How = How.Id, Using = "rbInterestOnlyPaymentId8")]
        public IWebElement EightRadio { get; set; }

        [FindsBy(How = How.Id, Using = "txtEighthOption")]
        public IWebElement txtEighthOption { get; set; }

        [FindsBy(How = How.Id, Using = "txtAPStartDate")]
        public IWebElement APStartDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtAPEndDate")]
        public IWebElement APEndDate { get; set; }


        [FindsBy(How = How.Id, Using = "rdoFirstChargeAmount1")]
        public IWebElement APMPIPFirstChangeAmountRadio1 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoFirstChargeAmount2")]
        public IWebElement APMPIPFirstChangeAmountRadio2 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoSubsequentChange1")]
        public IWebElement APMPIPSubsequentChange1 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoSubsequentChange2")]
        public IWebElement APMPIPSubsequentChange2 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoSubsequentChange3")]
        public IWebElement APMPIPSubsequentChange3 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoMaximumPayment1")]
        public IWebElement APMPIPMaximumPayment1 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoMaximumPayment2")]
        public IWebElement APMPIPMaximumPayment2 { get; set; }
        [FindsBy(How = How.Id, Using = "chkLenderIssueProvidedBeforeClosing")]
        public IWebElement LenderIssueProvidedBeforeClosing { get; set; }

        [FindsBy(How = How.Id, Using = "chkLenderIssueProvidedAfterClosing")]
        public IWebElement LenderIssueProvidedAfterClosing { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayIncludeLenderDescr")]
        public IWebElement LenderCreditIncludes { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayExcludeLenderDescr")]
        public IWebElement LenderCreditAndExcludes { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisplayRemainingLenderDescr")]
        public IWebElement LenderCreditCreditFor { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoSettlementAgentAddress1")]
        public IWebElement SettlementAgentAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoSettlementAgentAddress2")]
        public IWebElement SettlementAgentAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoSettlementAgentAddress3")]
        public IWebElement SettlementAgentAddressLine3 { get; set; }
        
        [FindsBy(How = How.Id, Using = "lblContInfoMortgageBrokerAddress1")]
        public IWebElement MortgageBrokerAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRMortgageBrokerBAddress2")]
        public IWebElement MortgageBrokerAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRMortgageBrokerBAddress3")]
        public IWebElement MortgageBrokerAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRealEstateBrokerSAddress1")]
        public IWebElement RealEstateBrokerSAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRealEstateBrokerSAddress2")]
        public IWebElement RealEstateBrokerSAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRealEstateBrokerSAddress3")]
        public IWebElement RealEstateBrokerSAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRealEstateBrokerBAddress1")]
        public IWebElement RealEstateBrokerBAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRealEstateBrokerBAddress2")]
        public IWebElement RealEstateBrokerBAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblContInfoRealEstateBrokerBAddress3")]
        public IWebElement RealEstateBrokerBAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "spanLITypeDesc")]
        public IWebElement EscTabEscPayment { get; set; }

        [FindsBy(How = How.Id, Using = "tblEscrowTable")]
        public IWebElement EscrowTable { get; set; }

        [FindsBy(How = How.Id, Using = "pNoEscrowAccount")]
        public IWebElement NoEscrowAccount { get; set; }

        #region Dynamic Elements
        public IWebElement PaymentCalculationsYearSelect(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("ddlYearRanges" + index));
        }

        public IWebElement PaymentCalculationsYearBeginTxt(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("txtBeginYear" + index));
        }

        public IWebElement PaymentCalculationsYearEndTxt(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("txtEndYear" + index));
        }
        
        public IWebElement PaymentCalculationsPrincipalAndInterestPlusIcon(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("divImgPI" + index));
        }
        
        public IWebElement PaymentCalculationsMortgageInsurance(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("txtMortInsAmt" + index));
        }
        
        public IWebElement PaymentCalculationsEstimatedEscrow(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("txtEstEscAmt" + index));
        }

        public IWebElement PaymentCalculationsAdditionalCostShowOnForm(int ID = 0)
        {
            return this.Section3_InEscrowOtherPopUpTable.FindElement(By.Id("ShowOnFormID_" + ID));
        }

        public IWebElement PaymentCalculationsAdditionalCostIncludeInEstimate(int ID = 0)
        {
            return this.Section3_InEscrowOtherPopUpTable.FindElement(By.Id("EstimateIncludesID_" + ID));
        }

        public IWebElement PaymentCalculationsAdditionalCostInEscrow(int ID = 0)
        {
            return this.Section3_InEscrowOtherPopUpTable.FindElement(By.Id("InEscrowID_" + ID));
        }

        #endregion

        #endregion

        #region PDD Objects
        [FindsBy(How = How.Id, Using = "ddlMonthsPrepaidText")]
        public IWebElement MonthPrepaidSelect { get; set; }

        [FindsBy(How = How.Id, Using = "LenderAffiliate")]
        public IWebElement LenderAffiliate { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#USEDEFAULT,#c,#chkUseDefault")]
        public IWebElement USEDEFAULT { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cboSellerPaymentMethod, #selsellerPayMethod")]
        public IWebElement SellerPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#DESCRPTION, #txtDesc, #txtDescription")]
        public IWebElement DESCRPTION { get; set; }

        [FindsBy(How = How.Id, Using = "txtNoOfMonthsPrepaid")]
        public IWebElement NoMonthsPrepaid { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cboBuyerPaymentMethod, #selBuyPayMethod")]
        public IWebElement BuyerPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#c,#USEDEFAULT")]
        public IWebElement usedefault { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtDescription,#DESCRPTION,#txtDesc")]
        public IWebElement ChargeDescription { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtLoanEstimatedDesc")]
        public IWebElement LEDescription { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtGfeThirdPartyNameDefault")]
        public IWebElement PayeeNameCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtPayeeName")]
        public IWebElement PayeeNameOnCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#PAYTO, #txtPaTo, #txtPayTo")]
        public IWebElement PayTo { get; set; }

        [FindsBy(How = How.Id, Using = "txtUnrounded")]
        public IWebElement LoanEstimateUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "txtRounded")]
        public IWebElement LoanEstimateRounded { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerCharge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cboGFEType")]
        public IWebElement GFEType { get; set; }

        [FindsBy(How = How.Id, Using = "chkLSP")]
        public IWebElement LenderSelectedProvider { get; set; }

        [FindsBy(How = How.Id, Using = "chkPOBOB")]
        public IWebElement PaidonbehalfofBorrower { get; set; }

        [FindsBy(How = How.Id, Using = "chkPPOC")]
        public IWebElement POCEnterPost { get; set; }

        [FindsBy(How = How.Id, Using = "txtPPOCamt")]
        public IWebElement POCAmount { get; set; }

        [FindsBy(How = How.Id, Using = "cboPartialPayMethod")]
        public IWebElement POCPayMethod { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtBuyerCredit' or @id='txtBuyerCdt']")]
        public IWebElement BuyerCredit { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtSellerCredit' or @id='txtSellercdt']")]
        public IWebElement SellerCredit { get; set; }

        //[FindsBy(How = How.Id, Using = "UNROUNDED")]
        //public IWebElement LoadEstimateUnrounded { get; set; }

        //[FindsBy(How = How.Id, Using = "ROUNDED")]
        //public IWebElement LoadEstimateRounded { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyerAtClosing")]
        public IWebElement PaidbyBuyerAtClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtBPbySellerAtClosing, #txtSellerAtClosing")]
        public IWebElement PaidbySellerAtClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtAdditionalDesc,#AdditionalDescription")]
        public IWebElement AdditionalDescription { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#PAYEENAME, #txtGfeThirdPartyNameDefault")]
        public IWebElement PayeeName { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#TOTALCHARGE, #txtTotalCharge")]
        public IWebElement TotalCharge { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#FAFChkBuyerDisplayL, #chkDisplayLCDBuyer")]
        public IWebElement BuyerDisplayLenderOnCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#FAFChkSellerDisplayL")]
        public IWebElement SellerDisplayLenderOnCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#chkPartOf[type='checkbox'], #FAFChkPartOf")]
        public IWebElement PartOf { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlPaidbyBuyerClosing, #ddlBuyerAtClosingPayMethod")]
        public IWebElement PaidbyBuyerAtClosingPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlPaidbySellerClosing, #ddlSellerAtClosingPayMethod")]
        public IWebElement PaidbySellerAtClosingPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlOthersBuyer, #ddlBuyerPaidbyOthersPayMethod")]
        public IWebElement BuyerPaidByOthersPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlSellerOthers, #ddlSellerPaidbyOthersPayMethod")]
        public IWebElement SellerPaidByOthersPaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBuyerCredit")]
        public IWebElement BuyerCreditPaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerCredit")]
        public IWebElement SellerCreditPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#chkGfePOBOBFlag, #chkDoubleAsteriskFlag")]
        public IWebElement DoubleAsteriskIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayLCDBuyer")]
        public IWebElement DisplayLBorrower { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayLCDSeller")]
        public IWebElement DisplayLSeller { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img#BrokenImage")]
        public IWebElement BrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "SectionB")]
        public IWebElement SectionB { get; set; }

        [FindsBy(How = How.Id, Using = "SectionC")]
        public IWebElement SectionC { get; set; }

        [FindsBy(How = How.Id, Using = "SectionH")]
        public IWebElement SectionH { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtBPbyBuyerBeforeClosing, #txtBuyerBeforeClosing")]
        public IWebElement PaidbyBuyerBeforeClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerBeforeClosing")]
        public IWebElement PaidbySellerBeforeClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtOthersSeller, #txtSellerPaidbyOthers")]
        public IWebElement PaidbySellerOthers { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonpane ui-widget-content ui-helper-clearfix']/div[@class='ui-dialog-buttonset']/button[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only')]/span[contains(@title,'Done')]")]
        public IWebElement DoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "divSummarySectionPopUp")]
        public IWebElement SummarySectionN04 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtBPbyOthers, #txtBuyerPaidbyOthers")]
        public IWebElement PaidbyBuyerOthers { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbySellerAtClosing")]
        public IWebElement PaidBySellerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtGfeThirdPartyNameDefault")]
        public IWebElement GfeThirdPartyNameDefault { get; set; }

        [FindsBy(How = How.Id, Using = "FAFPrimaryPolicyFlag")]
        public IWebElement PrimaryPolicy { get; set; }

        [FindsBy(How = How.Id, Using = "SectionB")]
        public IWebElement SectionBDidNotShopFor { get; set; }

        [FindsBy(How = How.Id, Using = "SectionC")]
        public IWebElement SectionCDidShopFor { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyer")]
        public IWebElement BuyerPaidByBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyLender")]
        public IWebElement BuyerPaidByLender { get; set; }

        #endregion

        #region CDdata

        public class CDdata
        {
            // Closing Information
            public bool LoanTypeFHA = true;

            // Loan Terms
            public string InterestRate = "1.5";

            // Projected Payments
            public string PaymentCalculationYears = "5";
            public string MortgageInsurance = "10000";

            // Costs at Closing -- verify only
            public string ClosingCost;

            // Loan Costs -- verify only
            public string TotalLoanCosts_BorrowerPaid_BeforeClosing;

            // Other Costs -- verify only
            public string LenderCredits_BorrowerPaid_BeforeClosing;

            // Calculating Cash to Close -- verify only
            public string CashToClose_LoanEstimate;

            // Summaries of Transactions -- verify only
            public string SalePriceOfProperty_Borrower;

            // Loan Disclosures
            public bool DoesNotAcceptPartialPayment = true;

            // AP & AIR
            public bool IncludeAdjustablePaymentTable = true;
            public string InterestOnlyPayment = "YES";

            // Loan Calculations
            public string TotalOfPayments = "2500.00";

            // Other Disclosures
            public bool StateLawMayProtectYou = true;

            // Contact Information -- verify only
            public string NameLender;

            // Loan Calculation
            public string FinanceCharge = "0.00";
            public string AmountFinanced = "0.00";
            public string AnnualPercentageRate = "0.00";
            public string TotalInterestPercentage = "0.00";

        }
        #endregion

        #region Services

        public ClosingDisclosure WaitForClosingDisclosureScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Section2_LoanTerms);
            return this;
        }
        public ClosingDisclosure Open()
        {
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
            this.WaitForScreenToLoad();

            return this;
        }

        public ClosingDisclosure ClickCDTab()
        {
            // need to click the ClosingDisclosure tab first to solve issue when testing on some resolutions i.e. 1280x768
            this.tabClosingDisclosure.FAClick();
            this.WaitForScreenToLoad();
            return this;
        }
        public ClosingDisclosure GoToVarianceTab()
        {
            // need to click the ClosingDisclosure tab first to solve issue when testing on some resolutions i.e. 1280x768
            this.tabClosingDisclosure.FAClick();
            this.WaitForScreenToLoad();
            this.VarianceTab.FAClick();
            this.WaitForGoodFaithVarianceScreenToLoad();
            return this;
        }
        public void ExpandSection(IWebElement section)
        {
            if (FastDriver.WebDriver.Url.ToLower().Contains("smsfast"))
                this.SwitchToContentFrame();
            this.WaitCreation(section);

            int tries = 0;
            while (section.GetAttribute("class") == "collasable-section-open" && tries++ <= 3)
            {
                section.FAClick();
                Thread.Sleep(1000);
            }
            // TODO: check and report if unable to expand
        }

        public void ExpandChargeGroup(IWebElement group)
        {
            ChargeGroup_ExpandCollapse(group, true);
        }

        public void CollapseChargeGroup(IWebElement group)
        {
            ChargeGroup_ExpandCollapse(group, false);
        }

        private void ChargeGroup_ExpandCollapse(IWebElement group, bool expand)
        {
            if (FastDriver.WebDriver.Url.ToLower().Contains("smsfast"))
                this.SwitchToContentFrame();
            this.WaitCreation(group);

            string imageName = "expand.png";
            if (expand)
                imageName = "collapse.png";

            int tries = 0;
            while (group.GetAttribute("src").ToLower().Contains(imageName) && tries++ <= 3)
            {
                group.Click();
                Playback.Wait(1000);
            }
            // TODO: check and report if unable to expand
        }


        public ClosingDisclosure WaitForGoodFaithVarianceScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30); //on some slow environment this dialog stay open for a while need to handle it.
            Playback.Wait(3000); // Wait for "ghost" windows to disappear
            this.SwitchToContentFrame();
            this.WaitCreation(GoodFaithAnalysisTableHeader);
            return this;
        }

        public ClosingDisclosure WaitForDeliveryOptionsScreenToLoad(IWebElement ele = null)
        {
            Playback.Wait(3000); // Wait for "ghost" windows to disappear
            this.SwitchToContentFrame();
            this.WaitCreation(ele??InitialCD);
            return this;
        }

        public ClosingDisclosure WaitForLenderCreditAnalisTable()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(tblLenderCreditsSubSection);
            return this;
        }

        public ClosingDisclosure WaitForScreenToLoad(IWebElement ele = null)
        {
                this.SwitchToContentFrame();
                this.WaitCreation(ele ?? Section2_LoanTerms);
                return this;
        }

        public bool IsBrokenLinkDisplayed(IWebElement element)
        {
            try
            {
                element.FindElement(By.XPath(".//span[starts-with(@class, 'BrokenImage')]")).SendKeys(""); // Bring control into focus
                return element.FindElement(By.XPath(".//span[starts-with(@class, 'BrokenImage')]")).Displayed;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public ClosingDisclosure Delivery(string method)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(DeliveryMethod);
            DeliveryMethod.FASelectItem(method);
            DeliveryButton.FAClick();
            return this;
        }

        // Closing Information
        public void ClosingInformationSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Closing Information Section";

            if (WebDriver.Url.ToLower().Contains("smsfast"))
                this.SwitchToContentFrame();
            this.WaitCreation(ClosingInformation);

            if (updateORverify.ToLower() == "update")
            {
                LoanTypeFHA.FASetCheckbox(TestData.LoanTypeFHA);
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.LoanTypeFHA.ToString().ToLower(), LoanTypeFHA.FAGetAttribute("checked") ?? "false");
                // TODO: Add more fields to verify
            }
        }

        // Loan Terms
        public void LoanTermsSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Loan Terms Section";

            ExpandSection(Section2_LoanTerms);

            if (updateORverify.ToLower() == "update")
            {
                Section2_LoanTerms_InterestRateValue.FASetText(TestData.InterestRate);
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.InterestRate + "%", Section2_LoanTerms_InterestRateValue.Text);
                // TODO: Add more fields to verify
            }
        }

        // Projected Payments
        public void ProjectedPaymentsSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Projected Payments Section";

            ExpandSection(Section3_ProjectedPayments);

            if (updateORverify.ToLower() == "update")
            {
                Section3_Years.FASetText("5");
                Section3_MortgageInsurance.FASetText(TestData.MortgageInsurance);
                // TODO: Add more fields to update

            }
            else
            {
                Support.AreEqual(TestData.MortgageInsurance, Section3_MortgageInsurance.FAGetAttribute("value"));
                // TODO: Add more fields to verify
            }
        }
        //
        public void SetLoanPurpose(string Purpose)
        {
            this.WaitForScreenToLoad();
            this.tabClosingDisclosure.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            this.WaitForClosingDisclosureScreenToLoad();
            this.PurposePlus.ScrollIntoView();
            this.PurposePlus.FAClick();
            this.LoanPurposeTypeCDID.FASelectItem(Purpose);

            FastDriver.WebDriver.HandleDialogMessage();
            this.WaitForScreenToLoad(this.PurposeDone);
            this.PurposeDone.FAClick();
        }

        // Costs at Closing -- verify only
        public void CostAtClosingSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Cost at Closing Section";

            ExpandSection(CostsatClosing);

            if (updateORverify.ToLower() == "update")
            {
                TestData.ClosingCost = Section4_CostsatClosing_ClosingCostsAmount.Text;
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.ClosingCost ?? "$0", Section4_CostsatClosing_ClosingCostsAmount.Text);
                // TODO: Add more fields to verify
            }
        }

        // Loan Costs -- verify only
        public void LoanCostsSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Loan Costs Section";

            ExpandSection(LoanCosts);

            if (updateORverify.ToLower() == "update")
            {
                TestData.LenderCredits_BorrowerPaid_BeforeClosing = TotalLoanCostsTable.PerformTableAction(1, "Loan Costs Subtotals (A + B + C)", 3, TableAction.GetText).Message;
            }
            else
            {
                Support.AreEqual(TestData.LenderCredits_BorrowerPaid_BeforeClosing ?? "", TotalLoanCostsTable.PerformTableAction(1, "Loan Costs Subtotals (A + B + C)", 3, TableAction.GetText).Message);
                // TODO: Add more fields to verify
            }
        }


        public IWebElement GetContactTable()
        {
            this.WaitForScreenToLoad();
            return (FastDriver.WebDriver.FindElement(By.Id("divPopUpAdditionalContactInfo")).FindElement(By.TagName("Table")));
        }

        public void CloseContactInformationPopUp()
        {
            this.WaitForScreenToLoad();
            FastDriver.WebDriver.FindElement(By.Id("divPopUpAdditionalContactInfo")).FindElements(By.TagName("div"))[1].FindElements(By.TagName("SPAN"))[1].FAClick();
        }

        public void DragDrop(IWebElement Source, IWebElement Target)
        {
            (new Actions(FastDriver.WebDriver)).DragAndDrop(Source, Target).Build().Perform();

        }

        #region NAVIGATE TO CLOSING DISCLOSURE
        public void NavigateToClosingDisclosure()
        {
            Reports.TestStep = "Navigate to Closing Disclosure screen";
            FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForScreenToLoad();
            this.SwitchToContentFrame();
        }
        #endregion

        public void ExpandCostAtClosing()
        {
            if (this.CostsatClosing.GetAttribute("class").Contains("collasable-section-open"))
            {
                this.WaitCreation(this.CostsatClosing);
                this.CostsatClosing.FAClick();
            }
        }

        public void ExpandCalculatingCashToClose()
        {
            if (this.CalculateCashToClose.GetAttribute("class").Contains("collasable-section-open"))
            {
                this.WaitCreation(this.CalculateCashToClose);
                this.CalculateCashToClose.FAClick();
            }
        }

        #region EXPAND LOAN COST
        public void ExpandLoanCost()
        {
            //let's avoid having test steps within the page objects
            Reports.TestStep = "Expand Loan Costs";
            this.WaitCreation(LoanCosts);
            this.LoanCosts.FAClick();
            Reports.TestStep = "Loan Costs section has been expanded";
        }
        #endregion


        #region EXPAND LOAN TERM
        public void ExpandLoanTerm()
        {
            //let's avoid having test steps within the page objects
            Reports.TestStep = "Expand Loan Terms";
            this.WaitCreation(Loan_Terms);
            this.Loan_Terms.FAClick();
            Reports.TestStep = "Loan Terms section has been expanded";
        }
        #endregion

        #region EXPAND Projected Payment Section
        public void ExpandProjectedPayment()
        {
            WaitForScreenToLoad(ele: Section3_ProjectedPayments);
            this.Section3_ProjectedPayments.FAClick();
        }
        #endregion

        #region EXPAND Loan Disclosure Section
        public void ExpandLoanDisclosure()
        {
            //let's avoid having test steps within the page objects
            Reports.TestStep = "Expand Loan Disclosure";
            this.WaitCreation(LoanDisclosures);
            this.LoanDisclosures.FAClick();
            Reports.TestStep = " Loan Disclosure section has been expanded";
        }
        #endregion

        #region EXPAND Payoff and Payments Section
        public void ExpandPayoffandPayment()
        {
            //let's avoid having test steps within the page objects
            Reports.TestStep = "Expand Payoff and Payments ";
            this.WaitCreation(Section_Payoffs);
            this.Section_Payoffs.FAClick();
            Reports.TestStep = " Payoff and Payments section has been expanded";
        }
        #endregion

        // Other Costs -- verify only
        public void OtherCostsSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Other Costs Section";

            ExpandSection(Othercosts);

            if (updateORverify.ToLower() == "update")
            {
                TestData.LenderCredits_BorrowerPaid_BeforeClosing = TotalClosingCostsTable.PerformTableAction(1, "Lender Credits", 3, TableAction.GetText).Message;
            }
            else
            {
                Support.AreEqual(TestData.LenderCredits_BorrowerPaid_BeforeClosing ?? "", TotalClosingCostsTable.PerformTableAction(1, "Lender Credits", 3, TableAction.GetText).Message);
                // TODO: Add more fields to verify
            }
        }

        #region EXPAND OTHER COSTS
        public void ExpandOtherCosts()
        {
            Reports.TestStep = "Expand Other Costs";
            this.WaitCreation(this.Othercosts);
            this.Othercosts.Click();
        }
        #endregion

        // Calculating Cash to Close -- verify only
        public void CalculatingCashToCloseSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Calculating Cash to Close Section";

            ExpandSection(CalculatingCashtoClose);

            if (updateORverify.ToLower() == "update")
            {
                TestData.CashToClose_LoanEstimate = CalculatingCashtoCloseTable.PerformTableAction(1, "Cash to Close", 2, TableAction.GetText).Message;
            }
            else
            {
                Support.AreEqual(TestData.CashToClose_LoanEstimate ?? "$0", CalculatingCashtoCloseTable.PerformTableAction(1, "Cash to Close", 2, TableAction.GetText).Message);
                // TODO: Add more fields to verify
            }
        }

        // Summaries of Transactions -- verify only
        public void SummariesOfTransactionsSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Summaries of Transactions Section";

            ExpandSection(Summary_Of_Trans);

            if (updateORverify.ToLower() == "update")
            {
                TestData.SalePriceOfProperty_Borrower = SectionK01_Amt.Text;
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.SalePriceOfProperty_Borrower ?? "", SectionK01_Amt.Text);
                // TODO: Add more fields to verify
            }
        }

        // Loan Disclosures
        public void LoanDisclosuresSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Loan Disclosures Section";

            ExpandSection(LoanDisclosures);

            if (updateORverify.ToLower() == "update")
            {
                NoPartialPayments.FASetCheckbox(TestData.DoesNotAcceptPartialPayment);
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.DoesNotAcceptPartialPayment.ToString().ToLower(), NoPartialPayments.GetAttribute("checked") ?? "false");
                // TODO: Add more fields to verify
            }
        }

        // AP & AIR
        public void APandAir(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " AP & Air Section";

            ExpandSection(Sec9_APnAIRtable_SectionHeading);

            if (updateORverify.ToLower() == "update")
            {
                Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(TestData.IncludeAdjustablePaymentTable);

                Sec9_APnAIRtable_APInterestOnlyDrpDwn.FASelectItem(TestData.InterestOnlyPayment);
                if (TestData.InterestOnlyPayment.ToUpper() == "YES")
                {
                    this.WaitCreation(InterestOnlyPayments_PlusIcon);
                    InterestOnlyPayments_PlusIcon.FAClick();

                    this.WaitCreation(PaymentCustomOption);
                    PaymentCustomOption.FAClick();
                    PaymentCustomText.FASetText("5");
                    PaymentSchedule_Done.FAClick();
                }
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.IncludeAdjustablePaymentTable.ToString().ToLower(), Sec9_APnAIRtable_APTableChkBox.GetAttribute("checked") ?? "false");
                Support.AreEqual(TestData.InterestOnlyPayment, Sec9_APnAIRtable_APInterestOnlyDrpDwn.FAGetSelectedItem());
                // TODO: Add more fields to verify
            }
        }

        // Loan Calculations
        public void LoanCalculationsSection(CDdata TestData, string updateORverify = "Update",bool FomratasMoney = true)
        {
            Reports.TestStep = updateORverify + " Loan Calculations Section";

            ExpandSection(LoanCalculations);

            if (updateORverify.ToLower() == "update")
            {
                TotalofPayments.FASetText(TestData.TotalOfPayments);
                FinanceCharge.FASetText(TestData.FinanceCharge);
                AmountFinanced.FASetText(TestData.AmountFinanced);
                AnnualPercentageRate.FASetText(TestData.AnnualPercentageRate);
                TotalInterestPercentage.FASetText(TestData.TotalInterestPercentage);
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.TotalOfPayments, TotalofPayments.Text);
                Support.AreEqual(TestData.FinanceCharge, FinanceCharge.Text);
                Support.AreEqual(TestData.AmountFinanced, AmountFinanced.Text);
                Support.AreEqual(TestData.AnnualPercentageRate, AnnualPercentageRate.Text);
                Support.AreEqual(TestData.TotalInterestPercentage, TotalInterestPercentage.Text);
                // TODO: Add more fields to verify
            }
        }

        // Other Disclosures
        public void OtherDisclosuresSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Other Disclusures Section";

            ExpandSection(OtherDisclosures);

            if (updateORverify.ToLower() == "update")
            {
                NotProtectedbyStateLaw.FASetCheckbox(TestData.StateLawMayProtectYou);
                // TODO: Add more fields to update
            }
            else
            {
                Support.AreEqual(TestData.StateLawMayProtectYou.ToString().ToLower(), NotProtectedbyStateLaw.GetAttribute("checked") ?? "false");
                // TODO: Add more fields to verify
            }
        }

        // Contact Information
        public void ContactInformationSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Contact Information Section";

            ExpandSection(ContactInformation);

            if (updateORverify.ToLower() == "update")
            {
                TestData.NameLender = ContactInfoTable.PerformTableAction(1, "Name", 2, TableAction.GetText).Message;
            }
            else
            {
                Support.AreEqual(TestData.NameLender ?? "", ContactInfoTable.PerformTableAction(1, "Name", 2, TableAction.GetText).Message);
                // TODO: Add more fields to verify
            }
        }

        // Confirm Receipt
        public void ComfirmReceiptSection(CDdata TestData, string updateORverify = "Update")
        {
            Reports.TestStep = updateORverify + " Confirmation Receipt Section";

            ExpandSection(LoanCosts);

            if (updateORverify.ToLower() == "update")
            {


            }
            else
            {

                // TODO: Add more fields to verify
            }
        }

        public void VerifyChargeDecriptionSectionG(int lineNo, string chargeDescription, bool chargeAmountAvailable = true, bool mandatoryCharge = true, int? months = null, double? monthlyCharges = null, bool doubleAsterickChecked = false, bool editDescription = false, string newDescription = "")
        {
            if (lineNo - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            this.SwitchToContentFrame();
            this.WaitCreation(tblOtherCostSubSection_G);
            tblOtherCostSubSection_G.Click();

            string verifydescription, helptextdisplay = "", helptextruntime, displaypermonth;
            string DisplayMonthlyCharges = "";
            string displaydescription = GetFormattedStringForChargeDescrition(chargeDescription, false, 23);
            if (doubleAsterickChecked)
                displaydescription = "** " + displaydescription;
            if (monthlyCharges.HasValue)
            {
                DisplayMonthlyCharges = (FormattedAmount(Convert.ToDecimal(monthlyCharges))).ToString();
            }
            string Termdisplay = string.Empty;
            string linedisplay = string.Format("{0:01}", lineNo.ToString("D2"));

            #region Script for Section G
            Reports.TestStep = "Verify if Charges are displayed in Line No. " + lineNo;

            var rowsSectionG = tblOtherCostSubSection_G.FindElements(By.CssSelector("tr.Data-Row")).ToList();

            if (lineNo > rowsSectionG.Count)
                throw new IndexOutOfRangeException("Line Number not found");

            int index = lineNo - 1;

            IWebElement description = rowsSectionG[index].FindElements(By.CssSelector("td.Description")).FirstOrDefault(i => i.Displayed);
            //description.Click();
            verifydescription = description.Text.Clean();

            if (months.HasValue && monthlyCharges.HasValue)
            {
                helptextruntime = description.GetAttribute("title").Clean();
                displaypermonth = DisplayMonthlyCharges + "  per month for  " + months + "  mo.";
                helptextdisplay = linedisplay + ". " + chargeDescription + " " + DisplayMonthlyCharges + " per month for  " + months + " mo.";
                displaydescription = linedisplay + ".  " + displaydescription + " " + displaypermonth;
                Support.AreEqual(helptextdisplay.Clean(), helptextruntime.Clean(), "Verify Help Text");
            }
            else if (((months == null || monthlyCharges == null) && (mandatoryCharge == false && chargeAmountAvailable == true)))
            {
                if (chargeDescription != "Aggregate Adjustment")
                {
                    helptextruntime = description.GetAttribute("title").Clean();
                    displaydescription = linedisplay + ".  " + displaydescription;
                    helptextdisplay = linedisplay + ". " + chargeDescription;
                    Support.AreEqual(helptextdisplay.Clean(), helptextruntime.Clean(), "Verify Help Text");
                }
                else if (chargeDescription == "Aggregate Adjustment")
                {
                    displaydescription = "  " + linedisplay + ". " + displaydescription + "  ";
                }
            }
            else if (((months == null || monthlyCharges == null) && (mandatoryCharge == true && (chargeAmountAvailable == true || chargeAmountAvailable == false))))
            {
                helptextruntime = description.GetAttribute("title").Clean();
                displaypermonth = "  per month for  " + " mo.";
                displaydescription = linedisplay + ".  " + displaydescription + displaypermonth;
                helptextdisplay = linedisplay + ". " + chargeDescription + "  per month for  " + " mo.";
                Support.AreEqual(helptextdisplay.Clean(), helptextruntime.Clean(), "Verify Help Text");
            }
            Support.AreEqual(displaydescription.Clean(), verifydescription.Clean(), "Verify Description");

            #endregion
        }

        public void VerifyAmount(ClosingDisclosureSection section, int lineNo, string chargeDescription, double? buyerAtClosing = null, double? buyerBeforeClosing = null, double? buyerPaidbyOther = null, double? sellerAtClosing = null, double? sellerBeforeClosing = null, double? sellerPaidbyOthers = null, bool lenderExist = false)
        {
            IWebElement sectionTable = GetSectionTable(section);

            if (lineNo - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            this.SwitchToContentFrame();
            this.WaitCreation(sectionTable);
            sectionTable.Click();

            string description = string.Empty, deed = string.Empty, mortgage = string.Empty, buyeratclsingamt = string.Empty, buyerbfrclsingamt = string.Empty, verifydescription = string.Empty;
            string selleratclsingamt = string.Empty, sellerbfrclsingamt = string.Empty, sellerpaidbyotherclsingamt = string.Empty;
            string DeedAmountDisplay = string.Empty, MortgageAmountDisplay = string.Empty;
            string BuyerAtClosingDisplay = string.Empty, BuyerBeforeClosingdisplay = string.Empty, PaidbyOtherdisplay = string.Empty;
            string SellerAtClosingDisplay = string.Empty, SellerBeforeClosingdisplay = string.Empty;
            Reports.TestStep = chargeDescription;
            string byramt, slramt;

            chargeDescription = GetFormattedStringForChargeDescrition(chargeDescription, false, 23);

            var rowsSectionG = sectionTable.FindElements(By.CssSelector("tr.Data-Row")).ToList();

            if (lineNo > rowsSectionG.Count)
                throw new IndexOutOfRangeException("Line Number not found");
            int index = lineNo - 1;

            #region BUYER AT CLOSING
            IWebElement cell = rowsSectionG[index].FindElement(By.CssSelector("td.BorrowerAtClosing"));
            int buyerlength = cell.Text.Clean().Length;

            if (buyerAtClosing == null && buyerlength == 0)
            {
                Support.AreEqual("true", "true", "Expected: System does not display the Buyer At Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Buyer At Closing amount", true);
            }
            else if (buyerAtClosing == null && buyerlength > 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount", false);
            }
            else if (buyerAtClosing != null && buyerlength > 0)
            {
                if (chargeDescription == "Aggregate Adjustment")
                {
                    byramt = (FormattedAmount(Convert.ToDecimal(buyerAtClosing.Value)));
                    byramt = byramt.ToString().Replace("$", "");
                    if (buyerAtClosing == 0)
                        byramt = "0.00";
                }
                else
                {
                    byramt = (FormattedAmount(Convert.ToDecimal(buyerAtClosing.Value)));
                }
                buyeratclsingamt = cell.Text.Clean();
                Reports.TestStep = "Verify if amount is displayed in Buyer At Closing Amount";
                Support.AreEqual(byramt.Clean(), buyeratclsingamt.Clean());
            }
            else if (buyerAtClosing != null && buyerlength == 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System does not display the Buyer At Closing amount even if user has entered the amount");
                Reports.StatusUpdate("Not Expected: System does not display the Buyer At Closing amount even if user has entered the amount", false);
            }
            #endregion

            #region BUYER BEFORE CLOSING
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.BorrowerBeforeClosing"));
            int buyerbfrlength = cell.Text.Clean().Length;

            if (buyerBeforeClosing == null && buyerbfrlength == 0)
            {
                Support.AreEqual("true", "true", "Expected: System does not display the Buyer Before Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Buyer Before Closing amount", true);
            }
            else if (buyerBeforeClosing == null && buyerbfrlength != 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount", false);
            }
            else if (buyerBeforeClosing != null && buyerbfrlength >= 1)
            {
                buyerbfrclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Buyer Before Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(buyerBeforeClosing.Value))).Clean(), buyerbfrclsingamt.Clean());
            }
            else if (buyerBeforeClosing != null && buyerbfrlength == 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region SELLER AT CLOSING
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.SellerAtClosing"));
            int sellerlength = cell.Text.Clean().Length;
            if (sellerAtClosing == null && sellerlength == 0)
            {
                Support.AreEqual("true", "true", "Expected: System does not display the Seller At Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Seller At Closing amount", true);
            }
            else if (sellerAtClosing == null && sellerlength != 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Seller At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller At Closing amount even if user has not entered the amount", false);
            }
            else if (sellerAtClosing != null && sellerlength >= 1)
            {
                if (chargeDescription == "Aggregate Adjustment")
                {
                    slramt = (FormattedAmount(Convert.ToDecimal(sellerAtClosing.Value)));
                    slramt = slramt.ToString().Replace("$", "");
                    if (sellerAtClosing == 0)
                        slramt = "0.00";
                }
                else
                {
                    slramt = (FormattedAmount(Convert.ToDecimal(sellerAtClosing.Value)));
                }
                selleratclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Seller At Closing Amount";
                Support.AreEqual(slramt.Clean(), selleratclsingamt.Clean());
            }
            else if (sellerAtClosing != null && sellerlength == 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Seller At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller At Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region SELLER BEFORE CLOSING
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.SellerBeforeClosing"));
            int selleratlength = cell.Text.Clean().Length;
            if (sellerBeforeClosing == null && selleratlength == 0)
            {
                Support.AreEqual("true", "true", "Expected: System does not display the Seller Before Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Seller Before Closing amount", true);
            }
            else if (sellerBeforeClosing == null && selleratlength != 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount", false);
            }
            else if (sellerBeforeClosing != null && selleratlength >= 1)
            {
                sellerbfrclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Seller Before Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(sellerBeforeClosing.Value))).Clean(), sellerbfrclsingamt.Clean());
            }
            else if (sellerBeforeClosing != null && selleratlength == 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region PAID BY OTHERS
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.PaidByOthers"));
            int paidbyothrslength = cell.Text.Clean().Length;
            if (buyerPaidbyOther == null && paidbyothrslength == 0)
            {
                Support.AreEqual("true", "true", "Expected: System does not display the Paid by Other amount");
            }
            else if (buyerPaidbyOther == null && paidbyothrslength > 0)
            {
                Support.AreEqual("FALSE", "TRUE", "Not Expected: System displays the Paid by Other amount even if user has not entered the amount");
            }
            else if (buyerPaidbyOther != null && paidbyothrslength >= 1)
            {
                sellerpaidbyotherclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Paid by Other Amount";
                if (lenderExist == true)
                    PaidbyOtherdisplay = "(L)" + FormattedAmount(Convert.ToDecimal(buyerPaidbyOther.Value));
                else
                    PaidbyOtherdisplay = FormattedAmount(Convert.ToDecimal(buyerPaidbyOther.Value));
                Support.AreEqual(PaidbyOtherdisplay.Clean(), sellerpaidbyotherclsingamt.Clean());
            }
            else if (buyerPaidbyOther != null && paidbyothrslength == 0)
            {
                Support.AreEqual("false", "true", "Not Expected: System displays the Paid by Other amount even if user has not entered the amount");
            }
            #endregion
        }

        public void VerifyAmount(int lineNo, ClosingDisclosureSection section, string ChargeDescription, double? BuyerAtClosing = null, double? BuyerBeforeClosing = null, double? BuyerPaidbyOther = null, double? SellerAtClosing = null, double? SellerBeforeClosing = null, double? SellerPaidbyOthers = null, bool LenderExist = false, double? LoanEstimteUnroundedAmt = null, double? LoanEstimateRoundedAmt = null, bool IsBrokenLink = false)
        {
            IWebElement sectionTable = GetSectionTable(section);

            if (lineNo - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            this.SwitchToContentFrame();
            this.WaitCreation(sectionTable);
            sectionTable.Click();

            string description = string.Empty, deed = string.Empty, mortgage = string.Empty, buyeratclsingamt = string.Empty, buyerbfrclsingamt = string.Empty, verifydescription = string.Empty;
            string selleratclsingamt = string.Empty, sellerbfrclsingamt = string.Empty, sellerpaidbyotherclsingamt = string.Empty, LoanEstimateUnroundedAmount = string.Empty, LoanEstimateRoundedAmount = string.Empty;
            string DeedAmountDisplay = string.Empty, MortgageAmountDisplay = string.Empty, PaidbyOtherdisplay = string.Empty;

            Reports.TestStep = ChargeDescription;

            ChargeDescription = GetFormattedStringForChargeDescrition(ChargeDescription, false, 23);

            var rowsSectionG = sectionTable.FindElements(By.CssSelector("tr.Data-Row")).ToList();

            if (lineNo > rowsSectionG.Count)
                throw new IndexOutOfRangeException("Line Number not found");
            int index = lineNo - 1;

            #region BUYER AT CLOSING
            IWebElement cell = rowsSectionG[index].FindElement(By.CssSelector("td.BorrowerAtClosing"));
            int buyerlength = cell.Text.Clean().Length;
            if (BuyerAtClosing == null && buyerlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Buyer At Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Buyer At Closing amount", true);
            }
            else if (BuyerAtClosing == null && buyerlength > 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount", false);
            }
            else if (BuyerAtClosing != null && buyerlength > 0)
            {
                buyeratclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Buyer At Closing Amount";
                if (BuyerAtClosing == 0 && ChargeDescription == "Prepaid Interest")
                    Support.AreEqual("$" + BuyerAtClosing.ToString(), buyeratclsingamt.Clean());
                else
                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(BuyerAtClosing.Value))).Clean(), buyeratclsingamt.Clean());
            }
            else if (BuyerAtClosing != null && buyerlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System does not display the Buyer At Closing amount even if user has entered the amount");
                Reports.StatusUpdate("Not Expected: System does not display the Buyer At Closing amount even if user has entered the amount", false);
            }
            #endregion

            #region BUYER BEFORE CLOSING
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.BorrowerBeforeClosing"));
            int buyerbfrlength = cell.Text.Clean().Length;
            if (BuyerBeforeClosing == null && buyerbfrlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Buyer Before Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Buyer Before Closing amount", true);
            }
            else if (BuyerBeforeClosing == null && buyerbfrlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount", false);
            }
            else if (BuyerBeforeClosing != null && buyerbfrlength >= 1)
            {
                buyerbfrclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Buyer Before Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(BuyerBeforeClosing.Value))).Clean(), buyerbfrclsingamt.Clean());
            }
            else if (BuyerBeforeClosing != null && buyerbfrlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region SELLER AT CLOSING
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.SellerAtClosing"));
            int sellerlength = cell.Text.Clean().Length;
            if (SellerAtClosing == null && sellerlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Seller At Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Seller At Closing amount", true);
            }
            else if (SellerAtClosing == null && sellerlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller At Closing amount even if user has not entered the amount", false);
            }
            else if (SellerAtClosing != null && sellerlength >= 1)
            {
                selleratclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Seller At Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(SellerAtClosing.Value))).Clean(), selleratclsingamt.Clean());
            }
            else if (SellerAtClosing != null && sellerlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller At Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region SELLER BEFORE CLOSING
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.SellerBeforeClosing"));
            int selleratlength = cell.Text.Clean().Length;
            if (SellerBeforeClosing == null && selleratlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Seller Before Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Seller Before Closing amount", true);
            }
            else if (SellerBeforeClosing == null && selleratlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount", false);
            }
            else if (SellerBeforeClosing != null && selleratlength >= 1)
            {
                sellerbfrclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Seller Before Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(SellerBeforeClosing.Value))).Clean(), sellerbfrclsingamt.Clean());
            }
            else if (SellerBeforeClosing != null && selleratlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region PAID BY OTHERS
            cell = rowsSectionG[index].FindElement(By.CssSelector("td.PaidByOthers"));
            int paidbyothrslength = cell.Text.Clean().Length;
            if (BuyerPaidbyOther == null && paidbyothrslength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Paid by Other amount");
                Reports.StatusUpdate("Expected: System does not display the Paid by Other amount", true);
            }
            else if (BuyerPaidbyOther == null && paidbyothrslength > 0)
            {
                Support.AreEqual("True", "True", "Not Expected: System displays the Paid by Other amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Paid by Other amount even if user has not entered the amount", false);
            }
            else if (BuyerPaidbyOther != null && paidbyothrslength >= 1)
            {
                sellerpaidbyotherclsingamt = cell.Text.Replace("(L)", "");
                Reports.TestStep = "Verify if amount is displayed in Paid by Other Amount";
                if (LenderExist)
                    PaidbyOtherdisplay = "(L)" + FormattedAmount(Convert.ToDecimal(BuyerPaidbyOther.Value));
                else
                    PaidbyOtherdisplay = FormattedAmount(Convert.ToDecimal(BuyerPaidbyOther.Value));
                Support.AreEqual(PaidbyOtherdisplay.Clean(), sellerpaidbyotherclsingamt.Clean());
            }
            else if (BuyerPaidbyOther != null && paidbyothrslength == 0)
            {
                Support.AreEqual("True", "True", "Not Expected: System displays the Paid by Other amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Paid by Other amount even if user has not entered the amount", false);
            }
            #endregion

            #region LOANESTIMATE UNROUNDED
            if (LoanEstimteUnroundedAmt.HasValue)
            {
                cell = rowsSectionG[index].FindElement(By.CssSelector("td.Unrounded.loanEstimateCol"));
                if (section != ClosingDisclosureSection.E2)
                {
                    int LoanEstimateUnroundedLenth = cell.Text.Clean().Length;
                    if (LoanEstimteUnroundedAmt == null && LoanEstimateUnroundedLenth == 0)
                    {
                        Support.AreEqual("True", "True", "Expected: System does not display the LoanEstimate Unrounded amount " + cell.Text);
                        Reports.StatusUpdate("Expected: System does not display the LoanEstimate Unrounded amount", true);
                    }
                    else if (LoanEstimteUnroundedAmt == null && LoanEstimateUnroundedLenth != 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount " + cell.Text);
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount", false);
                    }
                    else if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth >= 1)
                    {
                        LoanEstimateUnroundedAmount = cell.Text;
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate Unrounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimteUnroundedAmt.Value))).Clean(), LoanEstimateUnroundedAmount.Clean());
                    }
                    else if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth == 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount " + cell.Text);
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Unrounded  amount even if user has not entered the amount", false);
                    }
                }
                else
                {
                    LoanEstimateUnroundedAmount = E01UnroundedAmount.Text.Clean();
                    int LoanEstimateUnroundedLenth = LoanEstimateUnroundedAmount.Length;
                    if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth != 19)
                    {
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate Unrounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimteUnroundedAmt.Value))).Clean(), LoanEstimateUnroundedAmount.Clean());
                    }
                    else if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth == 19)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Unrounded  amount even if user has not entered the amount", false);
                    }
                }
            }

            #endregion

            #region LOANESTIMATE ROUNDED
            if (LoanEstimateRoundedAmt.HasValue)
            {
                cell = rowsSectionG[index].FindElement(By.CssSelector("td.Rounded.loanEstimateCol"));
                if (section != ClosingDisclosureSection.E2)
                {
                    int LoanEstimateRoundedLenth = cell.Text.Clean().Length;
                    if (LoanEstimateRoundedAmt == null && LoanEstimateRoundedLenth == 0)
                    {
                        Support.AreEqual("True", "True", "Expected: System does not display the LoanEstimate Rounded amount");
                        Reports.StatusUpdate("Expected: System does not display the LoanEstimate Rounded amount", true);
                    }
                    else if (LoanEstimateRoundedAmt == null && LoanEstimateRoundedLenth != 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount", false);
                    }
                    else if (LoanEstimateRoundedAmt != null && LoanEstimateRoundedLenth >= 1)
                    {
                        LoanEstimateRoundedAmount = cell.Text;
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate Rounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateRoundedAmt.Value))).Clean(), LoanEstimateRoundedAmount.Clean());
                    }
                    else if (LoanEstimateRoundedAmt != null && LoanEstimateRoundedLenth == 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Rounded  amount even if user has not entered the amount", false);
                    }
                    if (IsBrokenLink)
                    {
                        Reports.TestStep = "Verify the Rounded Broken Link for Description:" + ChargeDescription;
                        Playback.Wait(3000);
                        bool exists;
                        try
                        {
                            rowsSectionG[index].FindElement(By.CssSelector("td:nth-child(8) span.BrokenImageDisplay")).Click();
                            exists = true;
                        }
                        catch (Exception) { exists = false; }
                        Reports.StatusUpdate("Rounded Broken Link for Descritpion '" + ChargeDescription + "' should be displayed", exists);
                    }
                }
                else
                {
                    LoanEstimateUnroundedAmount = E02PlusRoundedAmt.Text.Clean();
                    int LoanEstimateUnroundedLenth = LoanEstimateUnroundedAmount.Length;
                    if (LoanEstimateRoundedAmt != null && LoanEstimateUnroundedLenth >= 1)
                    {
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate rounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateRoundedAmt.Value))).Clean(), LoanEstimateUnroundedAmount.Clean());
                    }
                    else if (LoanEstimateRoundedAmt != null && LoanEstimateUnroundedLenth == 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate rounded  amount even if user has not entered the amount", false);
                    }
                    if (IsBrokenLink)
                    {
                        Reports.TestStep = "Verify the Rounded 'broken link' image for description: " + ChargeDescription;
                        Playback.Wait(3000);
                        bool exists = false;
                        try
                        {
                            rowsSectionG[index].FindElement(By.TagName("img")).Click();
                            exists = true;
                        }
                        catch (Exception) { exists = false; }
                        Reports.StatusUpdate("Rounded Broken Link for Descritpion '" + ChargeDescription + "' should be displayed", exists);
                    }
                }
            }
            #endregion
        }

        public void VerifyAmountSalesTax(int lineNo, ClosingDisclosureSection section, string ChargeDescription, double? BuyerAtClosing, double? BuyerBeforeClosing = null, double? BuyerPaidbyOther = null, double? SellerAtClosing = null, double? SellerBeforeClosing = null, double? SellerPaidbyOthers = null, bool LenderExist = false, double? LoanEstimteUnroundedAmt = null, double? LoanEstimateRoundedAmt = null, bool IsBrokenLink = false, bool SalesTaxVerification = false)
        {
            IWebElement sectionTable = GetSectionTable(section);

            if (lineNo - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            this.SwitchToContentFrame();
            this.WaitCreation(sectionTable);
            sectionTable.Click();

            string description = string.Empty, deed = string.Empty, mortgage = string.Empty, buyeratclsingamt = string.Empty, buyerbfrclsingamt = string.Empty, verifydescription = string.Empty;
            string selleratclsingamt = string.Empty, sellerbfrclsingamt = string.Empty, sellerpaidbyotherclsingamt = string.Empty, LoanEstimateUnroundedAmount = string.Empty, LoanEstimateRoundedAmount = string.Empty;
            string DeedAmountDisplay = string.Empty, MortgageAmountDisplay = string.Empty, PaidbyOtherdisplay = string.Empty;

            if (SalesTaxVerification == true)
            {
                Reports.TestStep = ChargeDescription + " - Sales Tax ";
            }
            else
            {
                Reports.TestStep = ChargeDescription;
            }
            double? Paidbyothers = null;
            if (BuyerPaidbyOther.HasValue && !SellerPaidbyOthers.HasValue)
            {
                Paidbyothers = BuyerPaidbyOther;
            }
            //Modified according to US559013
            //if (!BuyerPaidbyOther.HasValue && SellerPaidbyOthers.HasValue)
            //{
            //    Paidbyothers = SellerPaidbyOthers;
            //}
            //if (BuyerPaidbyOther.HasValue && SellerPaidbyOthers.HasValue)
            //{
            //    Paidbyothers = BuyerPaidbyOther + SellerPaidbyOthers;
            //}

            ChargeDescription = GetFormattedStringForChargeDescrition(ChargeDescription, false, 23);

            var rowsSectionB = sectionTable.FindElements(By.CssSelector("tr.Data-Row")).ToList();

            if (lineNo > rowsSectionB.Count)
            {
                throw new IndexOutOfRangeException("Line Number not found");
            }
            int index = lineNo - 1;

            #region BUYER AT CLOSING
            IWebElement cell = rowsSectionB[index].FindElement(By.CssSelector("td.BorrowerAtClosing"));
            int buyerlength = cell.Text.Clean().Length;
            if (BuyerAtClosing == null && buyerlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Buyer At Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Buyer At Closing amount", true);
            }
            else if (BuyerAtClosing == null && buyerlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount", false);
            }
            else if (BuyerAtClosing != null && buyerlength >= 1)
            {
                buyeratclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Buyer At Closing Amount";
                if (BuyerAtClosing == 0 && ChargeDescription == "Prepaid Interest")
                    Support.AreEqual("$" + BuyerAtClosing.ToString(), buyeratclsingamt.Trim());
                else
                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(BuyerAtClosing.Value))).Trim(), buyeratclsingamt.Trim());
            }
            else if (BuyerAtClosing != null && buyerlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer At Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region BUYER BEFORE CLOSING
            cell = rowsSectionB[index].FindElement(By.CssSelector("td.BorrowerBeforeClosing"));
            int buyerbfrlength = cell.Text.Length;
            if (BuyerBeforeClosing == null && buyerbfrlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Buyer Before Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Buyer Before Closing amount", true);
            }
            else if (BuyerBeforeClosing == null && buyerbfrlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount", false);
            }
            else if (BuyerBeforeClosing != null && buyerbfrlength >= 1)
            {
                buyerbfrclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Buyer Before Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(BuyerBeforeClosing.Value))).Trim(), buyerbfrclsingamt.Trim());
            }
            else if (BuyerBeforeClosing != null && buyerbfrlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Buyer Before Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region SELLER AT CLOSING
            cell = rowsSectionB[index].FindElement(By.CssSelector("td.SellerAtClosing"));
            int sellerlength = cell.Text.Length;
            if (SellerAtClosing == null && sellerlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Seller At Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Seller At Closing amount", true);
            }
            else if (SellerAtClosing == null && sellerlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller At Closing amount even if user has not entered the amount", false);
            }
            else if (SellerAtClosing != null && sellerlength >= 1)
            {
                selleratclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Seller At Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(SellerAtClosing.Value))).Trim(), selleratclsingamt.Trim());
            }
            else if (SellerAtClosing != null && sellerlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller At Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller At Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region SELLER BEFORE CLOSING
            cell = rowsSectionB[index].FindElement(By.CssSelector("td.SellerBeforeClosing"));
            int selleratlength = cell.Text.Length;
            if (SellerBeforeClosing == null && selleratlength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Seller Before Closing amount");
                Reports.StatusUpdate("Expected: System does not display the Seller Before Closing amount", true);
            }
            else if (SellerBeforeClosing == null && selleratlength != 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount", false);
            }
            else if (SellerBeforeClosing != null && selleratlength >= 1)
            {
                sellerbfrclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Seller Before Closing Amount";
                Support.AreEqual((FormattedAmount(Convert.ToDecimal(SellerBeforeClosing.Value))).Trim(), sellerbfrclsingamt.Trim());
            }
            else if (SellerBeforeClosing != null && selleratlength == 0)
            {
                Support.AreEqual("True", "False", "Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Seller Before Closing amount even if user has not entered the amount", false);
            }
            #endregion

            #region PAID BY OTHERS
            cell = rowsSectionB[index].FindElement(By.CssSelector("td.PaidByOthers"));
            int paidbyothrslength = cell.Text.Length;
            if (Paidbyothers == null && paidbyothrslength == 0)
            {
                Support.AreEqual("True", "True", "Expected: System does not display the Paid by Other amount");
                Reports.StatusUpdate("Expected: System does not display the Paid by Other amount", true);
            }
            else if (Paidbyothers == null && paidbyothrslength != 0)
            {
                Support.AreEqual("True", "True", "Not Expected: System displays the Paid by Other amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Paid by Other amount even if user has not entered the amount", false);
            }
            else if (Paidbyothers != null && paidbyothrslength >= 1)
            {
                sellerpaidbyotherclsingamt = cell.Text;
                Reports.TestStep = "Verify if amount is displayed in Paid by Other Amount";
                if (LenderExist == true)
                    PaidbyOtherdisplay = "(L)" + FormattedAmount(Convert.ToDecimal(Paidbyothers.Value));
                else
                    PaidbyOtherdisplay = FormattedAmount(Convert.ToDecimal(Paidbyothers.Value));
                Support.AreEqual(PaidbyOtherdisplay.Trim(), sellerpaidbyotherclsingamt.Trim());
            }
            else if (Paidbyothers != null && paidbyothrslength == 0)
            {
                Support.AreEqual("True", "True", "Not Expected: System displays the Paid by Other amount even if user has not entered the amount");
                Reports.StatusUpdate("Not Expected: System displays the Paid by Other amount even if user has not entered the amount", false);
            }
            #endregion

            #region LOANESTIMATE UNROUNDED
            if (LoanEstimteUnroundedAmt.HasValue)
            {
                cell = rowsSectionB[index].FindElement(By.CssSelector("td.Unrounded.loanEstimateCol"));
                if (section != ClosingDisclosureSection.E2)
                {
                    int LoanEstimateUnroundedLenth = cell.Text.Length;
                    if (LoanEstimteUnroundedAmt == null && LoanEstimateUnroundedLenth == 0)
                    {
                        Support.AreEqual("True", "True", "Expected: System does not display the LoanEstimate Unrounded amount " + cell.Text);
                        Reports.StatusUpdate("Expected: System does not display the LoanEstimate Unrounded amount", true);
                    }
                    else if (LoanEstimteUnroundedAmt == null && LoanEstimateUnroundedLenth != 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount " + cell.Text);
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount", false);
                    }
                    else if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth >= 1)
                    {
                        LoanEstimateUnroundedAmount = cell.Text;
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate Unrounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimteUnroundedAmt.Value))).Trim(), LoanEstimateUnroundedAmount.Trim());
                    }
                    else if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth == 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount " + cell.Text);
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Unrounded  amount even if user has not entered the amount", false);
                    }
                }
                else
                {
                    LoanEstimateUnroundedAmount = E01UnroundedAmount.Text.Trim();
                    int LoanEstimateUnroundedLenth = LoanEstimateUnroundedAmount.Length;
                    if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth != 19)
                    {
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate Unrounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimteUnroundedAmt.Value))).Trim(), LoanEstimateUnroundedAmount.Trim());
                    }
                    else if (LoanEstimteUnroundedAmt != null && LoanEstimateUnroundedLenth == 19)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Unrounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Unrounded  amount even if user has not entered the amount", false);
                    }
                }
            }

            #endregion

            #region LOANESTIMATE ROUNDED
            if (LoanEstimateRoundedAmt.HasValue)
            {
                cell = rowsSectionB[index].FindElement(By.CssSelector("td.Rounded.loanEstimateCol"));
                if (section != ClosingDisclosureSection.E2)
                {
                    int LoanEstimateRoundedLenth = cell.Text.Length;
                    if (LoanEstimateRoundedAmt == null && LoanEstimateRoundedLenth == 0)
                    {
                        Support.AreEqual("True", "True", "Expected: System does not display the LoanEstimate Rounded amount");
                        Reports.StatusUpdate("Expected: System does not display the LoanEstimate Rounded amount", true);
                    }
                    else if (LoanEstimateRoundedAmt == null && LoanEstimateRoundedLenth != 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount", false);
                    }
                    else if (LoanEstimateRoundedAmt != null && LoanEstimateRoundedLenth >= 1)
                    {
                        LoanEstimateRoundedAmount = cell.Text;
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate Rounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateRoundedAmt.Value))).Trim(), LoanEstimateRoundedAmount.Trim());
                    }
                    else if (LoanEstimateRoundedAmt != null && LoanEstimateRoundedLenth == 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate Rounded  amount even if user has not entered the amount", false);
                    }
                    if (IsBrokenLink)
                    {
                        Reports.TestStep = "Verify the Rounded Broken Link for Descritpion:" + ChargeDescription;
                        Playback.Wait(3000);
                        bool exists = false;
                        try
                        {
                            rowsSectionB[index].FindElement(By.CssSelector("td:nth-child(8) span.BrokenImageDisplay")).Click();
                            exists = true;
                        }
                        catch (Exception) { exists = false; }
                        Reports.StatusUpdate("Rounded Broken Link for Descritpion '" + ChargeDescription + "' should be displayed", exists);
                    }
                }
                else
                {
                    LoanEstimateUnroundedAmount = E02PlusRoundedAmt.Text.Trim();
                    int LoanEstimateUnroundedLenth = LoanEstimateUnroundedAmount.Length;
                    if (LoanEstimateRoundedAmt != null && LoanEstimateUnroundedLenth >= 1)
                    {
                        Reports.TestStep = "Verify if amount is displayed in LoanEstimate rounded Amount";
                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateRoundedAmt.Value))).Trim(), LoanEstimateUnroundedAmount.Trim());
                    }
                    else if (LoanEstimateRoundedAmt != null && LoanEstimateUnroundedLenth == 0)
                    {
                        Support.AreEqual("True", "False", "Not Expected: System displays the LoanEstimate Rounded amount even if user has not entered the amount");
                        Reports.StatusUpdate("Not Expected: System displays the LoanEstimate rounded  amount even if user has not entered the amount", false);
                    }
                    if (IsBrokenLink)
                    {
                        Reports.TestStep = "Verify the Rounded 'broken link' image for description: " + ChargeDescription;
                        Playback.Wait(3000);
                        bool exists = false;
                        try
                        {
                            rowsSectionB[index].FindElement(By.TagName("img")).Click();
                            exists = true;
                        }
                        catch (Exception) { exists = false; }
                        Reports.StatusUpdate("Rounded Broken Link for Descritpion '" + ChargeDescription + "' should be displayed", exists);
                    }
                }
            }
            #endregion
        }

        #region To Verify or Modify the Loan Estimate Unrounded and Rounded value in CD Section A,B,C,E,F,G and H
        public void LoanEstimateColumn(ClosingDisclosureSection Section, string Description, string Option, bool isrounded, decimal LEValue, bool IsBrokenLink)
        {
            #region SUMMARY
            // <summary>
            // This function 'LoanEstimateColumn' is to Modify the Loan Estimate column values in CD section A,B,C,E,F,G and H.
            // Section - To Specify Section B or C or H in CD
            // Description - The Description list in CD
            // Option - Specify to verify or Edit the Loan Estimate column - "Verify/Edit"
            // isrounded - Boolean value - True - To Modify Rounded field, False - To Modify Unrounded Field value
            // LEValue - The value to modify the Loan Estimate Field
            // IsPencelicon - verify the penciol icon 
            // </summary>
            #endregion
            #region Variable Declaration
            //Get row count for the section and loop it to find the Charge Description
            string CellValue, cellval;
            int RowCount, RowIndex = 0;
            //Pointing to appropriate Table - SectionB/SectionC/SectionH in Loan CD Screen
            var TableSubSection = LoanCosts;
            bool exists = false;                                
            #endregion
            try
            {
                CellValue = "";
                #region SELECT SECTION FOR TABLE
                switch (Section)
                {
                    case ClosingDisclosureSection.A:
                        TableSubSection = this.TableLoanCostSectionA;
                        break;
                    case ClosingDisclosureSection.B:
                        TableSubSection = this.TableLoanCostSectionB;
                        break;
                    case ClosingDisclosureSection.C:
                        TableSubSection = this.TableLoanCostSectionC;
                        break;
                    case ClosingDisclosureSection.D:
                        TableSubSection = this.TableLoanCostSectionD;
                        break;
                    case ClosingDisclosureSection.E:
                        TableSubSection = this.TableOtherCostSectionE;
                        break;
                    case ClosingDisclosureSection.F:
                        TableSubSection = this.TableOtherCostSectionF;
                        break;
                    case ClosingDisclosureSection.G:
                        TableSubSection = this.TableOtherCostSectionG;
                        break;
                    case ClosingDisclosureSection.H:
                        TableSubSection = this.TableOtherCostSectionH;
                        break;
                    default:
                        TableSubSection = null;
                        break;
                }
                #endregion
                #region Get row count for the section and loop it to find the Charge Description

                var SubSectionDescriptions = TableSubSection.FindElements(By.CssSelector("td.Description span.DescriptionMarker"));
                var TableRows = TableSubSection.FindElements(By.CssSelector("tr"));
                RowCount = TableSubSection.FindElements(By.CssSelector("tr")).Count;

                for (RowIndex = 1; RowIndex < RowCount; RowIndex++)
                {
                    if (Section.Equals(ClosingDisclosureSection.A) && RowIndex == 1)
                    {
                        #region SECTION A VALUE CHECK
                        string boundary = "";
                        if (boundary != "")
                        {
                            CellValue = TableRows[RowIndex].Text.ToString();
                            foreach (var item in SubSectionDescriptions)
                            {
                                cellval = item.Text.ToString();
                            }
                        }
                        else
                        {
                            Reports.StatusUpdate("Line 1 does not have value", true);
                        }
                        #endregion
                    }
                    else
                    {
                        var rounded = TableRows[RowIndex].FindElement(By.CssSelector("td.Rounded"));//Get Rounded Cell
                        var unrounded = TableRows[RowIndex].FindElement(By.CssSelector("td.Unrounded"));//Get Unrounded Cell
                        CellValue = TableRows[RowIndex].Text.ToString();
                    }


                    var tableContainsCharge = TableSubSection.Text.ToLower().Contains(Description.ToLower().Trim().ToString());
                    Support.AreEqual(true.ToString(), tableContainsCharge.ToString());

                    if (CellValue.ToLower().Contains(Description.ToLower()))
                    {
                        #region VERIFY CHARGE DESCRIPTION DISPLAYED IN SECTION
                        Reports.TestStep = "Verify Charge Description Displayed in Section";
                        Support.AreEqual("True", "True", "The Description: " + Description + " is listed in the Section");
                        if (isrounded == false)
                        {
                            if (Option.ToLower() == "edit")
                            {
                                #region MODIFY LOAN ESTIMATE UNROUNDED VALUE
                                Reports.TestStep = "Modify Loan Estimate Unrounded Value";
                                Playback.Wait(1000);
                                TableRows[RowIndex].FindElement(By.CssSelector("span[id*=\"lblDisplayLEAmount\"]")).Click(); // Get UNROUNDED cell value
                                Keyboard.SendKeys("{HOME}", ModifierKeys.Shift);
                                Keyboard.SendKeys("{DELETE}");//delete existing text
                                Keyboard.SendKeys(LEValue.ToString());
                                FastDriver.BottomFrame.Done();
                                this.SwitchToContentFrame();
                                if (Section.Equals(ClosingDisclosureSection.A) || Section.Equals(ClosingDisclosureSection.B) || Section.Equals(ClosingDisclosureSection.C) || Section.Equals(ClosingDisclosureSection.D))
                                {
                                    ExpandLoanCost();
                                }
                                else
                                {
                                    ExpandOtherCosts();
                                }
                                this.SwitchToContentFrame();

                                Reports.TestStep = "Select Display Loan Estimate Unrounded Column Checkbox and verify the modified details in CD...";
                                this.SelectDisplayLoanEstimate();
                                this.DisplayLoanEstimate.SendKeys(Keys.Right);
                                this.DisplayLoanEstimate.SendKeys(Keys.Right);
                                this.DisplayLoanEstimate.SendKeys(Keys.Right);
                                this.DisplayLoanEstimate.SendKeys(Keys.Down);

                                Playback.Wait(5000);//waiting for DOM to be updated
                                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                                this.SwitchToContentFrame();
                                TableRows = TableSubSection.FindElements(By.CssSelector("tr"));
                                this.WaitForElement(TableRows[RowIndex]);
                                #endregion
                            }
                            #region VERIFY LOAN ESTIMATE UNROUNDED VALUE
                            Reports.TestStep = "Verify Loan Estimate Unrounded Value";
                            string temp = String.Format("{0:C}", LEValue);
                            if (temp == "$0.00")
                            {
                                temp = "$0";
                            }
                            var unrounded = TableRows[RowIndex].FindElement(By.CssSelector("td.Unrounded"));
                            Support.AreEqual(temp, unrounded.Text.ToString());
                            #endregion
                        }
                        else
                        {
                            if (Option.ToLower() == "edit")
                            {
                                #region MODIFY LOAN ESTIMATE ROUNDED VALUE
                                Reports.TestStep = "Modify Loan Estimate Rounded Value";
                                TableRows[RowIndex].FindElement(By.CssSelector("span[id*=\"lblDisplayRoundedAmount\"]")).SendKeys("");//focus
                                TableRows[RowIndex].FindElement(By.CssSelector("span[id*=\"lblDisplayRoundedAmount\"]")).Click(); // Get ROUNDED cell value the TableRows staled. need to get it after reload CD
                                Keyboard.SendKeys("{HOME}", ModifierKeys.Shift);//select existing text
                                TableRows[RowIndex].FindElement(By.CssSelector("span[id*=\"lblDisplayRoundedAmount\"]")).SendKeys("{DELETE}");//delete existing text
                                TableRows[RowIndex].FindElement(By.CssSelector("span[id*=\"lblDisplayRoundedAmount\"]")).SendKeys(LEValue.ToString());
                                FastDriver.BottomFrame.Done();
                                this.NavigateToClosingDisclosure();
                                this.WaitForClosingDisclosureScreenToLoad();
                                if (Section.Equals(ClosingDisclosureSection.A) || Section.Equals(ClosingDisclosureSection.B) || Section.Equals(ClosingDisclosureSection.C) || Section.Equals(ClosingDisclosureSection.D))
                                {
                                    ExpandLoanCost();
                                }
                                else
                                {
                                    ExpandOtherCosts();
                                }
                                Reports.TestStep = "Select Display Loan Estimate Rounded Column Checkbox and verify the modified details in CD...";
                                this.SelectDisplayLoanEstimate();
                                #endregion
                            }
                            #region VERIFY THE ROUNDED BROKEN LINK FOR DESCRIPTION
                            Reports.TestStep = "Verify the Rounded Broken Link for Description:" + Description;
                            TableRows = TableSubSection.FindElements(By.CssSelector("tr"));
                            if (IsBrokenLink)
                            {
                                IWebElement loanEstimateRounded = TableRows[RowIndex].FindElement(By.CssSelector("td.Rounded"));
                                exists = this.IsBrokenLinkDisplayed(loanEstimateRounded);
                                Support.AreEqual("True".ToLower(), exists.ToString().ToLower(), "System displays Broken icon in CD Screen");
                            }
                            #endregion

                            #region VERIFY LOAN ESTIMATE ROUNDED VALUE
                            decimal tempx = LEValue;
                            LEValue = Math.Round(LEValue);
                            if (tempx - LEValue > 0.49M)
                            {
                                LEValue++;
                            }
                            string temp = String.Format("{0:C}", LEValue);
                            if (temp == "$0.00")
                            {
                                temp = "$0";
                            }
                            TableRows[RowIndex].SendKeys(Keys.Right);
                            TableRows[RowIndex].SendKeys(Keys.Right);
                            TableRows[RowIndex].SendKeys(Keys.Right);
                            TableRows[RowIndex].SendKeys(Keys.Down);
                            var rounded = TableRows[RowIndex].FindElement(By.CssSelector("td.Rounded"));
                            Support.AreEqual(temp, rounded.Text.ToString());
                            #endregion
                        }
                        break;
                        #endregion
                    }
                }
                #endregion
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for " + Description, "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }
        #endregion

        #region VERIFY DESCRIPTION ON CD SCREEN
        public string VerifyDescription(ClosingDisclosureSection Section, int LineNumber, string ChargeDescription)
        {
            #region Variable Description
            var TableSubSection = LoanCosts;//this value is assigned only to initialize this variable
            string HelpTextDescription = "";
            #endregion
            try
            {
                #region SELECT SECTION FOR TABLE
                switch (Section)
                {
                    case ClosingDisclosureSection.A:
                        TableSubSection = this.TableLoanCostSectionA;
                        break;
                    case ClosingDisclosureSection.B:
                        TableSubSection = this.TableLoanCostSectionB;
                        break;
                    case ClosingDisclosureSection.C:
                        TableSubSection = this.TableLoanCostSectionC;
                        break;
                    case ClosingDisclosureSection.D:
                        TableSubSection = this.TableLoanCostSectionD;
                        break;
                    case ClosingDisclosureSection.E:
                        TableSubSection = this.TableOtherCostSectionE;
                        break;
                    case ClosingDisclosureSection.F:
                        TableSubSection = this.TableOtherCostSectionF;
                        break;
                    case ClosingDisclosureSection.G:
                        TableSubSection = this.TableOtherCostSectionG;
                        break;
                    case ClosingDisclosureSection.H:
                        TableSubSection = this.TableOtherCostSectionH;
                        break;
                    default:
                        TableSubSection = null;
                        break;
                }
                #endregion
                #region Find the Charge Description using Line Number
                var SubSectionSalesTaxDescriptions = TableSubSection.FindElements(By.CssSelector("td.Description span.TextWrap"));
                var TableRows = TableSubSection.FindElements(By.CssSelector("tr"));
                bool tableContainsCharge = false;
                
                tableContainsCharge = TableSubSection.Text.ToLower().Contains(ChargeDescription.ToLower().Trim().ToString());
                if (tableContainsCharge)
                {
                    string ChargeDescriptionWithSalesTax = ChargeDescription + " - Sales Tax ";
                    if (LineNumber > 0)
                    {
                        HelpTextDescription = SubSectionSalesTaxDescriptions[LineNumber - 1].Text.ToString();
                        bool containsSalesTax = HelpTextDescription.ToLower().Replace(" ", "").Contains("-salestax");
                        if (!containsSalesTax)
                        {
                            Reports.TestStep = "'- Sales Tax' will be added at the end of " + HelpTextDescription;
                            HelpTextDescription += " - Sales Tax ";
                        }
                    }
                    Support.AreEqual(ChargeDescriptionWithSalesTax.Trim().ToLower(), HelpTextDescription.Trim().ToLower());
                }
                #endregion
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for " + ChargeDescription, "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }

            return HelpTextDescription;
        }
        #endregion

        #region EDIT COST DESCRIPTION
        public void EditCostDescription(ClosingDisclosureSection Section, string Description, string ModifyDescription)
        {
            #region SUMMARY
            /**** Parameter Description
             * string Section - Indicates SectionB/SectionC/SectionH in CD screen
             * String FeeDescription - Original Fee Description displayed in CD
             * bool EditDescription - Indicate whether the Description is editable or not.(true/false)
             * string ModifyFeeDescription - The string to modify the Description value. 
             * string ModifyAddlDescription - The string to modify the Additional Description value.
             *****/
            #endregion
            #region Variable Declaration
            //Get row count for the section and loop it to find the Charge Description
            string CellValue/*, cellval*/;
            //int y = 0, j;
            int RowCount, RowIndex/*, i*/ = 0;
            var TableSubSection = LoanCosts;
            #endregion
            try
            {
                //Pointing to appropriate Table - SectionB/SectionC/SectionH in Loan CD Screen
                CellValue = "";
                #region SELECT SECTION FOR TABLE
                switch (Section)
                {
                    case ClosingDisclosureSection.A:
                        TableSubSection = this.TableLoanCostSectionA;
                        break;
                    case ClosingDisclosureSection.B:
                        TableSubSection = this.TableLoanCostSectionB;
                        break;
                    case ClosingDisclosureSection.C:
                        TableSubSection = this.TableLoanCostSectionC;
                        break;
                    case ClosingDisclosureSection.D:
                        TableSubSection = this.TableLoanCostSectionD;
                        break;
                    case ClosingDisclosureSection.E:
                        TableSubSection = this.TableOtherCostSectionE;
                        break;
                    case ClosingDisclosureSection.F:
                        TableSubSection = this.TableOtherCostSectionF;
                        break;
                    case ClosingDisclosureSection.G:
                        TableSubSection = this.TableOtherCostSectionG;
                        break;
                    case ClosingDisclosureSection.H:
                        TableSubSection = this.TableOtherCostSectionH;
                        break;
                    default:
                        TableSubSection = null;
                        break;
                }
                #endregion
                #region Get row count for the section and loop it to find the Charge Description
                var SubSectionDescriptions = TableSubSection.FindElements(By.CssSelector("td.Description span.DescriptionMarker"));
                var TableRows = TableSubSection.FindElements(By.CssSelector("tr"));
                RowCount = TableSubSection.FindElements(By.CssSelector("tr")).Count;

                for (RowIndex = 1; RowIndex < RowCount; RowIndex++)
                {
                    CellValue = TableRows[RowIndex].Text.ToString();
                    var tableContainsCharge = TableSubSection.Text.ToLower().Contains(Description.ToLower().Trim().ToString());
                    Support.AreEqual(true.ToString(), tableContainsCharge.ToString());
                    if (CellValue.ToLower().Contains(Description.ToLower()))
                    {
                        #region Edit Fee Description if the EditDescription value is True
                        var contentEditable = TableRows[RowIndex].FindElement(By.CssSelector("td.Description span.TextWrap.DescColor[contenteditable=\"\"]"));
                        if (contentEditable != null) //if it's null then the contenteditable property is not present
                        {
                            Reports.TestStep = "EDIT THE CHARGE DESCRIPTION IN SECTION";
                            Reports.StatusUpdate("The Description: " + Description + " is Editable in the CD Screen", true);
                            Support.AreEqual("True", "True", "The Description: " + Description + " is Editable in the CD Screen");
                        }
                        else
                        {
                            Reports.StatusUpdate("The Description: " + Description + " is Not Editable in the CD Screen SECTION", false);
                            Support.AreEqual("True", "False", "The Description: " + Description + " is Not Editable in the CD Screen SECTION");
                        }
                        // CLICK ON THE DESCRIPTION TO MODIFY
                        TableRows[RowIndex].FindElement(By.CssSelector("td.Description span.TextWrap.DescColor")).Click();
                        Keyboard.SendKeys("{HOME}", ModifierKeys.Shift);
                        Keyboard.SendKeys("{DELETE}");
                        Keyboard.SendKeys(ModifyDescription);

                        Reports.StatusUpdate("The Description Field value is Modified.", true);
                        Support.AreEqual("True", "True", "The Description: " + Description + " Field value is Modified to " + ModifyDescription + " in " + Section + "");
                        break;
                        #endregion
                    }
                }
                #endregion
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for " + Description, "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }
        #endregion
        public void VerifyLenderCreditAnalysis(int lineNumber, string chargeDescription, double? finalBorrowerPaid)
        {
            if (lineNumber - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            Reports.TestStep = chargeDescription;
            var rows = tblLenderCreditsSubSection.FindElements(By.CssSelector("tr.Data-Row"));

            if (lineNumber > rows.Count)
                throw new IndexOutOfRangeException("Line Number not found");
            int index = lineNumber - 1;

            if (lineNumber == 0)
            {
                bool exists = rows.FirstOrDefault(row => row.FindElement(By.CssSelector("td:nth-child(1)")).Text.Contains(chargeDescription)) == null;

                if (exists)
                    Reports.StatusUpdate(chargeDescription + " does exist under Good Faith Analysis 0% Category", false);
                else
                    Reports.StatusUpdate(chargeDescription + " does not exist under Good Faith Analysis 0% Category", true);
            }
            else
            {
                Reports.TestStep = "Verify if description is displayed under Lender Credit Analysis Column/tab";
                IWebElement cell = rows[index].FindElement(By.CssSelector("td:nth-child(1)"));
                string verifydescription = cell.Text;
                Support.AreEqual(chargeDescription.Trim(), verifydescription.Trim());

                string Final_BorrowerPaid = rows[index].FindElement(By.CssSelector("td:nth-child(2)")).Text;
                Debug.Print(Final_BorrowerPaid);
                if (finalBorrowerPaid == 0)
                {
                    Reports.TestStep = "Verify if amount is displayed in Final Borrower Paid Column";
                    if (Final_BorrowerPaid.Clean() == "")
                    {
                        Support.AreEqual("True", "True", "Final (Borrower-Paid) Value is blank for " + chargeDescription);
                    }
                    else
                    {
                        Support.AreEqual("$0.00", Final_BorrowerPaid.Trim());
                    }
                }
                else
                {
                    Reports.TestStep = "Verify if amount is displayed in Final Borrower Paid Column";
                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(finalBorrowerPaid.Value))).Trim(), Final_BorrowerPaid.Trim());
                }
            }
        }

        #region Verify Loan Costs and Other Cost Charge and Fee Description in CD Screen
        public void VerifyCostsDescription_PayeeName(ClosingDisclosureSection Section, bool isChrDisplay, string ChargeDescription, bool IsPayeeName, string ExpectedPayeeName)
        {
            /**** Parameter Description
             * string Section - Indicates SectionB/SectionC/SectionH in CD screen
             * bool isChrDisplay - Indicates whether the Charge Description should listed or not in the section.(true/false)
             * string ChargeDescription - Expected Charge Description 
             * bool IsPayeeName - Indicates whether need to Charge should have Payee Name or not.(true/false)
             * string ExpectedPayeeName - Expected PayeeName
             *****/
            try
            {
                string CellValue, cellval;
                int y = 0, j;
                int RowCount, RowIndex, i = 0;
                //Pointing to appropriate Table - SectionB/SectionC/SectionH in Loan CD Screen
                var TableSubSection = this.LoanCosts;
                #region Select Table for Section
                switch (Section)
                {
                    case ClosingDisclosureSection.A:
                        TableSubSection = this.TableLoanCostSectionA;
                        break;
                    case ClosingDisclosureSection.B:
                        TableSubSection = this.TableLoanCostSectionB;
                        break;
                    case ClosingDisclosureSection.C:
                        TableSubSection = this.TableLoanCostSectionC;
                        break;
                    case ClosingDisclosureSection.D:
                        TableSubSection = this.TableLoanCostSectionD;
                        break;
                    case ClosingDisclosureSection.H:
                        TableSubSection = this.TableOtherCostSectionH;
                        break;
                    //add more sections if necessary
                    default:
                        TableSubSection = null;
                        break;
                }
                #endregion

                //Get row count for the section and loop it to find the Charge Description
                List<string> Elements = new List<string>();
                List<string> Payees = new List<string>();
                var SubSectionDescriptions = TableSubSection.FindElements(By.CssSelector("td.Description span.DescriptionMarker"));
                var SubSectionPayees = TableSubSection.FindElements(By.CssSelector("td.Description span:last-child"));
                int DescCount = SubSectionDescriptions.Count;
                RowCount = TableSubSection.FindElements(By.CssSelector("tr")).Count;
                foreach (var payee in SubSectionPayees)
                {
                    Payees.Add(payee.GetAttribute("Title").Trim());
                }
                for (RowIndex = 0; RowIndex < RowCount; RowIndex++)
                {
                    CellValue = SubSectionDescriptions[RowIndex].ToString();
                    foreach (var item in SubSectionDescriptions)
                    {
                        cellval = item.Text.ToString();
                        Elements.Add(cellval);
                    }

                    j = Elements.Count;
                    //if (j == 5)
                    //    y = 4;
                    //else
                    //    y = 3;
                    y = RowCount - 1;
                    #region Verify Table contains Charge
                    var tableContainsCharge = TableSubSection.Text.ToLower().Contains(ChargeDescription.ToLower().Trim().ToString());
                    Support.AreEqual(true.ToString(), tableContainsCharge.ToString());
                    if (tableContainsCharge)
                    {

                        for (int charge = 0; charge < RowCount; charge++)
                        {
                            if (TableSubSection.Text.ToLower().Contains(ChargeDescription.ToLower().Trim().ToString()))
                            {
                                i = 1;
                                Reports.TestStep = "Verify Charge Description is displayed in this Section";
                                Support.AreEqual("True", "True", "The Description: " + ChargeDescription + " is listed in the Section");
                                break;
                            }
                        }
                    }
                    #endregion
                    #region CHECK PAYEE NAME
                    if (IsPayeeName == true)
                    {
                        if (Payees != null)
                        {
                            string hh = ExpectedPayeeName.Trim();//dummy stop
                            //if (string.Compare((ExpectedPayeeName.Trim()), (Payees[y-1].Trim()), true) == 0)
                            //Used "Contains" instead of "Compare" because Closing Disclosure screen doesn't 
                            //show the whole payee name and that makes the comparison fail
                            if (ExpectedPayeeName.Trim().Contains(Payees[y - 1].Trim()))
                            {
                                //If the Payee Name is Match with the Expected, then return pass
                                Support.AreEqual("True", "True", "The Expected PayeeName: " + Payees[y - 1] + " is displayed for the Charge: " + ChargeDescription + "");
                                Support.AreEqual("True", "True", "The Charge Description is displayed properly: " + CellValue + "");
                                break;
                            }
                            else
                            {
                                //If the Payee Name is not Match with the Expected, then return pass
                                Support.AreEqual("False", "True", "The PayeeName: " + Payees[y - 1] + " is not match with the Expected PayeeName: " + ExpectedPayeeName + " for the Charge: " + ChargeDescription + "");
                                Support.AreEqual("False", "True", "The Charge Description is not displayed properly: " + CellValue + "");
                            }
                        }
                    }
                    else
                    {
                        if (Elements[y] == null)
                        {
                            Support.AreEqual("True", "True", "The Payeename not displayed for the Charge: " + ChargeDescription + "");
                            Support.AreEqual("True", "True", "The Charge Description is displayed as expected: " + CellValue + "");
                        }
                    }
                    #endregion
                }

                if (i == 0)
                {
                    //Is charge Description should display or not, if true, should display the description, else should not display
                    if (isChrDisplay == true)
                    {
                        Support.AreEqual("False", "True", "The Description: " + ChargeDescription + " is not listed in the Section");
                    }
                    else
                    {
                        Support.AreEqual("True", "True", "The Description: " + ChargeDescription + " is not listed in the Section as expected");
                    }

                }
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for " + ChargeDescription, "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }
        #endregion

        public void CD_VerifyCostsDescrption_PayeeName(ClosingDisclosureSection Section, bool isChrDisplay, string ChargeDescription, bool IsPayeeName, string ExpectedPayeeName)
        {
            /**** Parameter Description
             * string Section - Indicates SectionB/SectionC/SectionH in CD screen
             * bool isChrDisplay - Indicates whether the Charge Description should listed or not in the section.(true/false)
             * string ChargeDescription - Expected Charge Description 
             * bool IsPayeeName - Indicates whether need to Charge should have Payee Name or not.(true/false)
             * string ExpectedPayeeName - Expected PayeeName
             *****/
            try
            {
                string CellValue, cellval;
                int y = 0, j;
                int RowCount, RowIndex, i = 0;
                bool isPresent = false;
                //Pointing to appropriate Table - SectionB/SectionC/SectionH in Loan CD Screen
                var TableSubSection = this.LoanCosts;
                #region Select Table for Section
                TableSubSection = GetSectionTable(Section);
                #endregion

                //Get row count for the section and loop it to find the Charge Description
                List<string> Elements = new List<string>();
                List<string> Payees = new List<string>();
                var SubSectionDescriptions = TableSubSection.FindElements(By.CssSelector("td.Description span.DescriptionMarker"));
                var SubSectionPayees = TableSubSection.FindElements(By.CssSelector("td.Description span:last-child"));
                int DescCount = SubSectionDescriptions.Count;
                RowCount = TableSubSection.FindElements(By.CssSelector("tr")).Count;
                foreach (var payee in SubSectionPayees)
                {
                    Payees.Add(payee.GetAttribute("Title").Trim());
                }
                for (RowIndex = 0; RowIndex < RowCount; RowIndex++)
                {
                    CellValue = SubSectionDescriptions[RowIndex].ToString();
                    foreach (var item in SubSectionDescriptions)
                    {
                        cellval = item.Text.ToString();
                        Elements.Add(cellval);
                    }

                    j = Elements.Count;
                    //if (j == 5)
                    //    y = 4;
                    //else
                    //    y = 3;
                    y = Payees.Count >= RowIndex ? RowIndex : -1;
                    #region Verify Table contains Charge
                    var tableContainsCharge = TableSubSection.Text.ToLower().Contains(ChargeDescription.ToLower().Trim().ToString());
                    Support.AreEqual(true.ToString(), tableContainsCharge.ToString());
                    if (tableContainsCharge)
                    {

                        for (int charge = 0; charge < RowCount; charge++)
                        {
                            if (TableSubSection.Text.ToLower().Contains(ChargeDescription.ToLower().Trim().ToString()))
                            {
                                i = 1;
                                Reports.TestStep = "Verify Charge Description is displayed in this Section";
                                Support.AreEqual("True", "True", "The Description: " + ChargeDescription + " is listed in the Section");
                                break;
                            }
                        }
                    }
                    #endregion
                    #region CHECK PAYEE NAME
                    if (IsPayeeName == true)
                    {
                        if (Payees != null && (y >= 0))
                        {
                            string hh = ExpectedPayeeName.Trim();//dummy stop
                            //if (string.Compare((ExpectedPayeeName.Trim()), (Elements[y].Trim()), true) == 0)
                            if ((string.Compare((ExpectedPayeeName.Clean()), (Payees[y].Clean()), true) == 0))
                            {
                                //If the Payee Name is Match with the Expected, then return pass
                                Support.AreEqual("True", "True", "The Expected PayeeName: " + Payees[y] + " is displayed for the Charge: " + ChargeDescription + "");
                                Support.AreEqual("True", "True", "The Charge Description is displayed properly: " + CellValue + "");
                                isPresent = true;
                                break;
                            }
                            //else
                            //{
                            //    //If the Payee Name is not Match with the Expected, then return pass
                            //    Support.AreEqual("False", "True", "The PayeeName: " + Payees[y] + " is not match with the Expected PayeeName: " + ExpectedPayeeName + " for the Charge: " + ChargeDescription + "");
                            //    Support.AreEqual("False", "True", "The Charge Description is not displayed properly: " + CellValue + "");
                            //}
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        if (Elements[y] == null)
                        {
                            Support.AreEqual("True", "True", "The Payeename not displayed for the Charge: " + ChargeDescription + "");
                            Support.AreEqual("True", "True", "The Charge Description is displayed as expected: " + CellValue + "");
                        }
                    }
                    #endregion
                }

                if (!isPresent)
                    Support.AreEqual("False", "True", "The PayeeName: " + Payees[y] + " is not match with the Expected PayeeName: " + ExpectedPayeeName + " for the Charge: " + ChargeDescription + "");

                if (i == 0)
                {
                    //Is charge Description should display or not, if true, should display the description, else should not display
                    if (isChrDisplay == true)
                    {
                        Support.AreEqual("False", "True", "The Description: " + ChargeDescription + " is not listed in the Section");
                    }
                    else
                    {
                        Support.AreEqual("True", "True", "The Description: " + ChargeDescription + " is not listed in the Section as expected");
                    }
                }
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for " + ChargeDescription, "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }

        public void EditLoanEstimateSectionG(int lineNo, string description, double? loanEstimateUnRounded, double? loanEstimateRounded = null, bool isBrokenLink = false)
        {
            if (lineNo - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            this.SwitchToContentFrame();
            this.WaitCreation(tblOtherCostSubSection_G);
            tblOtherCostSubSection_G.Click();

            if (loanEstimateUnRounded.HasValue)
                Reports.TestStep = "Edit Loan Estimate Unrounded for " + description + " to " + loanEstimateUnRounded;
            if (loanEstimateRounded.HasValue)
                Reports.TestStep = "Edit Loan Estimate Rounded for " + description + " to " + loanEstimateRounded;

            var rowsSectionG = tblOtherCostSubSection_G.FindElements(By.CssSelector("tr.Data-Row")).GetAllVisible();

            if (lineNo > rowsSectionG.Count)
                throw new IndexOutOfRangeException("Line Number not found");
            int index = lineNo - 1;

            var cell = rowsSectionG[index].FindElement(By.CssSelector("td.loanEstimateCol.Unrounded"));
            var input = cell.FindElements(By.TagName("span")).FirstOrDefault(i => i.Displayed);

            if (loanEstimateUnRounded.HasValue)
            {
                input = cell.FindElements(By.TagName("span")).FirstOrDefault(i => i.Displayed);
                input.Click();
                input.Clear();
                input.FASetText(loanEstimateUnRounded.ToString() + FAKeys.Tab + FAKeys.Tab);
            }
            if (loanEstimateRounded.HasValue)
            {
                cell = rowsSectionG[index].FindElement(By.CssSelector("td.loanEstimateCol.Rounded"));
                input = cell.FindElements(By.TagName("span")).FirstOrDefault(i => i.Displayed);

                input.Click();
                input.Clear();
                input.FASetText(loanEstimateRounded.ToString() + FAKeys.Tab + FAKeys.Tab);

                if (isBrokenLink)
                {
                    Playback.Wait(5000); //this takes too long to show up
                    Reports.TestStep = "Verify the Rounded 'broken link' image for description: " + description;
                    Reports.StatusUpdate("System displays Broken icon in CD Screen", this.IsBrokenLinkDisplayed(rowsSectionG[index].FindElement(By.CssSelector("td.loanEstimateCol.Rounded"))));
                }
            }
        }

        public void EditDescriptionSectionG(string description, string newDescription, int? lineNo = null)
        {
            int index;
            index = lineNo ?? -1;

            var rows = tblOtherCostSubSection_G.FindElements(By.CssSelector("tr.Data-Row"));
            IWebElement row;
            row = index != -1 ? rows[index] : rows.FirstOrDefault(rr => rr.FindElement(By.CssSelector("td.Description")).Text.Contains(description));

            if (row.FindElement(By.CssSelector("td.Description > span:nth-child(3)")).Text == "**")
            {
                row.FindElement(By.CssSelector("td.Description > span:nth-child(4)")).Click();
                Keyboard.SendKeys("{DEL}");
                row.FindElement(By.CssSelector("td.Description > span:nth-child(4)")).FASetText(newDescription);
                //row.FindElement(By.CssSelector("td.Description > span:nth-child(4)")).Click();
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            else
            {
                row.FindElement(By.CssSelector("td.Description > span:nth-child(3)")).Click();
                Keyboard.SendKeys("{DEL}");
                row.FindElement(By.CssSelector("td.Description > span:nth-child(3)")).FASetText(newDescription);
                //row.FindElement(By.CssSelector("td.Description > span:nth-child(3)")).Click();
                Keyboard.SendKeys(FAKeys.TabAway);
            }
        }

        public void VerifyChargeDecriptionSectionBCH(ClosingDisclosureSection section, string description, int lineNo, bool isEditable = true, string additionalDesc = null)
        {
            IWebElement table = GetSectionTable(section);
            this.SwitchToContentFrame();
            this.WaitCreation(table);
            table.Click();

            IWebElement element;
            try
            {
                if (isEditable)
                {
                    element = table.PerformTableAction(lineNo, 1, TableAction.GetCell).Element
                        .FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(j => j.GetAttribute("Title").Contains(description) && j.Displayed);
                    Support.AreEqual(description, element.Text.Trim());
                }
                else
                {
                    var td = table.FindElements(By.TagName("td"));
                    foreach (var item in td)
                    {
                        if (additionalDesc != null)
                        {
                            if (item.Text.Contains(description) && item.Text.Contains(additionalDesc))
                            {
                                Debug.Print(item.Text);
                                var payeeName = item.FindElements(By.TagName("span"));
                                foreach (var item2 in payeeName)
                                {
                                    if (item2.Text.Contains(description))
                                        Support.AreEqual(description, item2.Text.Trim());
                                }
                            }
                        }
                        else if (item.Text.Contains(description))
                        {
                            var payeeName = item.FindElements(By.TagName("span"));
                            foreach (var item2 in payeeName)
                            {
                                if (item2.Text.Contains(description))
                                    Support.AreEqual(description, item2.GetAttribute("Title").ToString().Trim());
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Support.Fail(e.Message);
            }

        }

        #region Calculate Final Borrower Paid Amount for the Specified Fee
        public double CalculateFinalBorrowerPaidAmountForSalesTax(ClosingDisclosureSection Section, int lineNo, string ChargeDescription)
        {
            //this method should work with decimals, but it was set to double so its result 
            //can be used on other methods like VerifyAmountForCategory
            Reports.TestStep = "Calculate Final Borrower Paid Amount for the Specified Fee";
            IWebElement sectionTable = GetSectionTable(Section);
            if (lineNo - 1 < 0)
                throw new IndexOutOfRangeException("Provide a valid Line Number");

            this.SwitchToContentFrame();
            this.WaitCreation(sectionTable);
            sectionTable.Click();
            var rows = sectionTable.FindElements(By.CssSelector("tr.Data-Row")).ToList();
            if (lineNo > rows.Count)
                throw new IndexOutOfRangeException("Line Number not found");
            int index = lineNo - 1;

            #region BUYER AT CLOSING
            IWebElement cell = rows[index].FindElement(By.CssSelector("td.BorrowerAtClosing"));
            int buyerlength = cell.Text.Clean().Length;
            double BuyerAtClosing = 0.0;
            if (buyerlength > 0)
                BuyerAtClosing = Convert.ToDouble(cell.Text.Clean().Replace("$", ""));
            #endregion

            #region BUYER BEFORE CLOSING
            cell = rows[index].FindElement(By.CssSelector("td.BorrowerBeforeClosing"));
            int buyerbfrlength = cell.Text.Clean().Length;
            double BuyerBeforeClosing = 0.0;
            if (buyerbfrlength > 0)
                BuyerBeforeClosing = Convert.ToDouble(cell.Text.Clean().Replace("$", ""));
            #endregion

            return BuyerAtClosing + BuyerBeforeClosing;
        }
        #endregion

        #endregion

        #region Private services
        private static string CurrencyFormat
        {
            get
            {
                return "C";
            }
        }
        private static string CurrencyFormatWithoutDecimal
        {
            get
            {
                return "C0";
            }
        }
        private static string CurrencyFormatWithoutDollarSign
        {
            get
            {
                return "#,##0.00";
            }
        }

        private static string GetFormattedStringForChargeDescrition(string reqVal, bool prefixAsterisk, int maxChar, params string[] args)
        {
            if (string.IsNullOrWhiteSpace(reqVal)) return string.Empty;
            string prefixVal = string.Empty;
            string retVal = string.Empty;
            bool prefixAsteriskMandatory = false;
            int MaxCharLength = maxChar;
            int MaxCharWithAsterisk = maxChar - 1;

            int cutoffCharLength = MaxCharLength;

            foreach (string arg in args)
            {
                if (arg != null && arg.Length > MaxCharLength)
                {
                    prefixAsteriskMandatory = true;
                    break;
                }
            }

            if ((prefixAsteriskMandatory) || (reqVal.Length > MaxCharLength && prefixAsterisk))
            {
                prefixVal = "*";
                cutoffCharLength = MaxCharWithAsterisk;
            }

            if (reqVal.Length > cutoffCharLength)
            {
                if (reqVal.Substring(cutoffCharLength, 1) == " ")
                    return prefixVal + reqVal.Substring(0, cutoffCharLength);
                else if (reqVal.Substring(0, cutoffCharLength).LastIndexOf(" ") > 0)
                    return prefixVal + reqVal.Substring(0, reqVal.Substring(0, cutoffCharLength).LastIndexOf(" "));
                else
                    return prefixVal;
            }
            else if (reqVal.Trim().Length > 0 || prefixVal == "*")
                return prefixVal + reqVal;
            else
            {
                foreach (string arg in args)
                {
                    if (arg != null && arg.Trim().Length > 0)
                        return prefixVal + reqVal;
                }
            }

            return reqVal;
        }

        private static string FormattedAmount(decimal amount, bool returnZeroWhenEmptyString = false, bool withDollarSign = true)
        {
            string formattedAmt = string.Empty;
            string currFormat = string.Empty;
            if (withDollarSign)
                currFormat = CurrencyFormat;
            else
                currFormat = CurrencyFormatWithoutDollarSign;
            if (amount < 0)
            {
                var culture = System.Globalization.CultureInfo.CurrentCulture;
                var mutableNfi = (System.Globalization.NumberFormatInfo)culture.NumberFormat.Clone();
                mutableNfi.CurrencyNegativePattern = 1;
                formattedAmt = amount != 0 ? (amount % 1000000000).ToString(currFormat, mutableNfi) : string.Empty;
            }
            else
                formattedAmt = amount != 0 ? (amount % 1000000000).ToString(currFormat) : string.Empty;

            return (returnZeroWhenEmptyString && string.IsNullOrWhiteSpace(formattedAmt)) ? 0.ToString(CurrencyFormatWithoutDecimal) : formattedAmt;

        }

        private IWebElement GetSectionTable(ClosingDisclosureSection section)
        {
            switch (section)
            {
                case ClosingDisclosureSection.A:
                    return TableLoanCostSectionA;
                case ClosingDisclosureSection.B:
                    return ServicesBorrowerDidNotShopForTable;
                case ClosingDisclosureSection.C:
                    return ServicesBorrowerDidShopForTable;
                case ClosingDisclosureSection.D:
                    return TableLoanCostSectionD;
                case ClosingDisclosureSection.E:
                    return TableOtherCostSectionE;
                //case ClosingDisclosureSection.E2:
                //    break;
                //case ClosingDisclosureSection.F:
                //    break;
                case ClosingDisclosureSection.G:
                    return tblOtherCostSubSection_G;
                case ClosingDisclosureSection.H:
                    return OtherCostsOtherSectionHTable;
                //case ClosingDisclosureSection.I:
                //    break;
                case ClosingDisclosureSection.J:
                    return TotalClosingCostsTable;
                default:
                    throw new NoSuchElementException("Section not avaiable");
            }

        }

        private IWebElement GetSectionTableForItemsUnpaidBySeller(ClosingDisclosureSection section)
        {
            switch (section)
            {
                //case ClosingDisclosureSection.A:
                //    break;
                //case ClosingDisclosureSection.B:
                //    break;
                //case ClosingDisclosureSection.C:
                //    break;
                //case ClosingDisclosureSection.D:
                //    break;
                //case ClosingDisclosureSection.E:
                //    break;
                //case ClosingDisclosureSection.E2:
                //    break;
                //case ClosingDisclosureSection.F:
                //    break;
                //case ClosingDisclosureSection.G:
                //    return tblOtherCostSubSection_G;
                //case ClosingDisclosureSection.H:
                //    break;
                //case ClosingDisclosureSection.I:
                //    break;
                //case ClosingDisclosureSection.J:
                //    break;
                case ClosingDisclosureSection.L:
                    return SectionL_AdjustmentforItemsSubTable;
                default:
                    throw new NoSuchElementException("Section not avaiable");
            }

        }

        #endregion

        public void SetLoanInformation(CDLoanInformation data)
        {
            #region  Loan Information
            this.LoanTermPlus.FADoubleClick();
            this.LoanTermYearTextbox.FASetText(data.Years.ToString());
            this.LoanTermMonthTextbox.FASetText(data.Months.ToString());
            this.LoanTermDone.FAClick();
            this.imgLoanProduct.FADoubleClick();
            this.LoanProductTypeCDID.FASelectItem(data.ProductType);
            this.LoanProducttxt.FASetText(data.ProductComment);
            this.btnLoanProductDone.FAClick();
            this.LoanTypeConventional.FASetCheckbox(data.IsConventional);
            this.LoanType.FASelectItem(data.Type);
            this.LoantypeDone.FAClick();
            this.LoanIDValue.FAClick();
            this.LoanIDValue.FASetText(data.LenderID);
            this.MICValue.FAClick();
            this.MICValue.FASetText(data.MICNumber);
            #endregion
        }

        public void SetLoanTerms(CDLoanTerms data)
        {
            #region  Loan Amount
            this.Section2_LoanTerms_LoanAmountDropdown.FASelectItem(data.IsLoanAmountIncreasedAfterClosing ? "YES" : "NO");
            if (data.IsLoanAmountIncreasedAfterClosing)
            {
                this.LoanTerm_LoanAmount_plusIcon.FADoubleClick();
                this.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(!string.IsNullOrEmpty(data.LoanAmountCondition));
                if (!string.IsNullOrEmpty(data.LoanAmountCondition))
                {                    
                    this.LoanTerm_LoanAmount_CanGo_DrpDwn.FASelectItem(data.LoanAmountCondition);
                    this.LoanTerm_LoanAmount_Amount.FASetText(data.LoanAmountAsHighAs.ToString("F2"));
                }
                this.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(data.LoanAmountIncreasedUntilYear != null);
                if (data.LoanAmountIncreasedUntilYear != null)
                {
                    this.LoanTerm_LoanAmount_year.FASetText(data.LoanAmountIncreasedUntilYear.ToString());
                }
                this.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            #endregion
            #region  Interest Rate
            this.Section2_LoanTerms_InterestRateValue.JSSetText(data.InterestRate.ToString("F2"));
            this.Section2_LoanTerms_InterestRateDropdown.FASelectItem(data.IsInterestRateIncreasedAfterClosing ? "YES" : "NO");
            if(data.IsInterestRateIncreasedAfterClosing)
            {
                this.LoanTerm_InterestRate_plusIcon.FADoubleClick();
                this.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(data.InterestRateAdjustsEveryYears != null);
                if (data.InterestRateAdjustsEveryYears != null)
                {
                    this.LoanTerm_IR_Adjust_Year.FASetText(data.InterestRateAdjustsEveryYears.ToString());
                    this.LoanTerm_IR_FirstRate_Year.FASetText(data.InterestRateAdjustsStartingInYear.ToString());
                }
                this.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(data.InterestRateCanGoAsHighAs != null);
                if (data.InterestRateCanGoAsHighAs != null)
                {
                    this.LoanTerm_IR_CeilingRate.FASetText(data.InterestRateCanGoAsHighAs.ToString("F2"));
                    this.LoanTerm_IR_Effective_Year.FASetText(data.InterestRateCanGoAsHighAsInYear.ToString("F2"));
                }
                this.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            #endregion
            #region  Monthly Principal and Interest
            this.Section2_LoanTerms_MonthlyPrincipalValue.JSSetText(data.MonthlyPayment.ToString("F2"));
            this.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItem(data.IsMonthlyPaymentIncreasedAfterClosing ? "YES" : "NO");
            if (data.IsMonthlyPaymentIncreasedAfterClosing)
            {
                this.LoanTerm_PI_plusIcon.FADoubleClick();
                this.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(data.MonthlyPaymentAdjustsEveryYears != null);
                if (data.MonthlyPaymentAdjustsEveryYears != null)
                {
                    this.LoanTerm_PI_Adjust_Year.FASetText(data.MonthlyPaymentAdjustsEveryYears.ToString());
                    this.LoanTerm_PI_FirstRate_Year.FASetText(data.MonthlyPaymentAdjustsStartingInYear.ToString());
                }
                this.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(data.MonthlyPaymentCanGoAsHighAs != null);
                if (data.MonthlyPaymentCanGoAsHighAs != null)
                {
                    this.LoanTerm_PI_MaxAmmount.FASetText(data.MonthlyPaymentCanGoAsHighAs.ToString("F2"));
                    this.LoanTerm_PI_Effective_Year.FASetText(data.MonthlyPaymentCanGoAsHighAsInYear.ToString());
                }
                this.LoanTerm_PlusPanel_checkbox3.FASetCheckbox(data.MonthlyPaymentOnlyInterestUntilYear != null);
                if (data.MonthlyPaymentOnlyInterestUntilYear != null)
                {
                    this.LoanTerm_PI_InterestOnly_Year.FASetText(data.MonthlyPaymentOnlyInterestUntilYear.ToString());
                }
                this.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            #endregion
            #region  Prepayment Penalty
            this.Section2_LoanTerms_PrepaymentPenaltyDropdown.FASelectItem(data.HasPrepaymentPenalty ? "YES" : "NO");
            if (data.HasPrepaymentPenalty)
            {
                this.LoanTerm_PP_plusIcon.FADoubleClick();
                this.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(data.PrepaymentPenaltyGoesAsHighAs != null);
                if (data.PrepaymentPenaltyGoesAsHighAs != null)
                {
                    this.LoanTerm_PP_MaxAmmount.FASetText(data.PrepaymentPenaltyGoesAsHighAs.ToString("F2"));
                    this.LoanTerm_PP_Expiration_Year.FASetText(data.PrepaymentPenaltyGoesAsHighAsIfPaidDuringFirstYears.ToString());
                }
                this.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            #endregion
            #region  Balloon Payment
            this.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItem(data.HasBalloonPayment ? "YES" : "NO");
            if (data.HasBalloonPayment)
            {
                this.LoanTerm_BP_plusIcon.FAClick();
                this.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(data.BalloonPaymentAtTheEndOfLoanTerm != null);
                if (data.BalloonPaymentAtTheEndOfLoanTerm != null)
                {
                    this.LoanTerm_BP_MaxAmmount.FASetText(data.BalloonPaymentAtTheEndOfLoanTerm.ToString("F2"));
                }
                this.LoanTerm_LoanAmount_DoneBtn.FAClick();
            }
            #endregion
        }

        public void SetProjectedPayments(CDProjectedPayments data)
        {
            #region Payment Calculation
            this.Section3_ProjectedPaymentPlusIcon.FAClick();
            this.ProjectedPayment_PaymentCalculation_YearRange.FASelectItem(data.PaymentCalculations.Length.ToString());
            this.YearRangeDone.FAClick();
            for (int i = 0; i < data.PaymentCalculations.Length; i++)
            {
                if (data.PaymentCalculations[i].EndYear != data.PaymentCalculations[i].StartYear)
                {
                    this.PaymentCalculationsYearSelect(i).FASelectItem("Years");
                    if (this.PaymentCalculationsYearBeginTxt(i).IsEnabled())
                    {
                        this.PaymentCalculationsYearBeginTxt(i).FASetText(data.PaymentCalculations[i].StartYear.ToString());
                    }
                    this.PaymentCalculationsYearEndTxt(i).FASetText(data.PaymentCalculations[i].EndYear.ToString());
                }
                else
                {
                    this.PaymentCalculationsYearSelect(i).FASelectItem("Year");
                    if (this.PaymentCalculationsYearBeginTxt(i).IsEnabled())
                    {
                        this.PaymentCalculationsYearBeginTxt(i).FASetText(data.PaymentCalculations[i].StartYear.ToString());
                    }
                }
                this.PaymentCalculationsPrincipalAndInterestPlusIcon(i).FAClick();
                if (data.PaymentCalculations[i].PrincipalAndInterest != null)
                {
                    this.ProjectedPayment_rdoPrincipalInterest.FAClick();
                    this.ProjectedPayment_txtPrincipalInterest.FASetText(data.PaymentCalculations[i].PrincipalAndInterest.ToString("F2"));
                }
                else if (data.PaymentCalculations[i].Minimum != null)
                {
                    this.ProjectedPayment_rdoMinimumMaximum.FAClick();
                    this.Section3_txtMinimum.FASetText(data.PaymentCalculations[i].Minimum.ToString());
                    FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                    this.Section3_txtMaximum.FASetText(data.PaymentCalculations[i].Maximum.ToString());
                }
                else if (data.PaymentCalculations[i].Interest != null)
                {
                    this.ProjectedPayment_rdoOnlyInterest.FAClick();
                    this.ProjectedPayment_OnlyInterest.FASetText(data.PaymentCalculations[i].Interest.ToString("F2"));
                }
                this.Section3_btnPrincipalInterestDone.FAClick();
                this.PaymentCalculationsMortgageInsurance(i).FASetText(data.PaymentCalculations[i].MortgageInsurance.ToString("F2"));
                this.PaymentCalculationsEstimatedEscrow(i).FASetText(data.PaymentCalculations[i].EstimatedEscrow.ToString("F2"));
            }
            this.ProjectedPayment_Estimated_TI_Amount.FASetText(data.EstimatedTaxesInsuranceAndAssesments.ToString("F2"));
            this.Section3_PropertyTax.FASetCheckbox(data.PropertyTaxes);
            if (data.PropertyTaxes)
            {
                this.Section3_PropertyTaxInEscrow.FASelectItem(data.PropertyTaxesInEscrow);
            }
            this.Section3_HomeownersInsurance.FASetCheckbox(data.HomeownerInsurance);
            if (data.HomeownerInsurance)
            {
                this.Section3_HomeownersInsuranceInEscrow.FASelectItem(data.HomeownerInsuranceInEscrow);
            }
            if (data.AdditionalEstimatedPropertyCosts.Length > 0)
            {
                this.Section3_OthersInEscrowPlus.FAClick();
                for (int i = 0; i < data.AdditionalEstimatedPropertyCosts.Length; i++)
                {
                    int otherTypeID = data.AdditionalEstimatedPropertyCosts[i].ID;
                    this.PaymentCalculationsAdditionalCostIncludeInEstimate(otherTypeID).FASetCheckbox(data.AdditionalEstimatedPropertyCosts[i].Included);
                    if (data.AdditionalEstimatedPropertyCosts[i].Included)
                    {
                        if (data.AdditionalEstimatedPropertyCosts[i].ShowOnForm)
                        {
                            this.PaymentCalculationsAdditionalCostShowOnForm(otherTypeID).FAClick();
                        }
                        this.PaymentCalculationsAdditionalCostInEscrow(otherTypeID).FASetCheckbox(data.AdditionalEstimatedPropertyCosts[i].InEscrow);
                        if (!string.IsNullOrEmpty(data.AdditionalEstimatedPropertyCosts[i].Other))
                        {
                            this.txtPOPupEstimateOther.FASetText(data.AdditionalEstimatedPropertyCosts[i].Other);
                        }
                    }
                }
                this.Section3_OtherpopupDone.FAClick();
            }
            #endregion
        }

        public void VerifySectionByLineNo_EmptyCharges(ClosingDisclosureSection section, int lineNumber, string description, string fromDate, string toDate, string amount)
        {
            #region Variable declaration
            IWebElement lineNumberCell;
            IWebElement descriptionCell;
            IWebElement fromDateCell;
            IWebElement toDateCell;
            IWebElement toLabelCell;
            IWebElement amountCell;
            IWebElement table;
            int rowIndex = 0;
            #endregion

            string sectionName = section.ToString();
            Reports.TestStep = "Verify the line " + lineNumber + " in section " + sectionName;

            switch (section)
            {
                case ClosingDisclosureSection.M:
                    {
                        if (lineNumber == 9)
                            rowIndex = 2;
                        else if (lineNumber == 10)
                            rowIndex = 3;
                        else if (lineNumber == 11)
                            rowIndex = 4;
                        else
                            Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

                        table = SectionM_AdjustmentforItemsSubTable;

                        break;
                    }
                case ClosingDisclosureSection.L:
                    {
                        if (lineNumber == 12)
                            rowIndex = 2;
                        else if (lineNumber == 13)
                            rowIndex = 3;
                        else if (lineNumber == 14)
                            rowIndex = 4;
                        else
                            Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

                        table = SectionL_AdjustmentforItemsSubTable;

                        break;
                    }

                case ClosingDisclosureSection.N:
                    {
                        if (lineNumber == 14)
                            rowIndex = 2;
                        else if (lineNumber == 15)
                            rowIndex = 3;
                        else if (lineNumber == 16)
                            rowIndex = 4;
                        else
                            Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

                        table = SectionN_AdjustmentforItemsSubTable;

                        break;
                    }
                default:
                    {
                        table = null;
                        Support.Fail(string.Format("Unexpected Section to verify: {0}", sectionName));
                        break;
                    }
            }

            lineNumberCell = table.PerformTableAction(rowIndex, 1, TableAction.GetCell).Element;
            descriptionCell = table.PerformTableAction(rowIndex, 2, TableAction.GetCell).Element;
            fromDateCell = table.PerformTableAction(rowIndex, 3, TableAction.GetCell).Element;
            toLabelCell = table.PerformTableAction(rowIndex, 4, TableAction.GetCell).Element;
            toDateCell = table.PerformTableAction(rowIndex, 5, TableAction.GetCell).Element;
            amountCell = table.PerformTableAction(rowIndex, 7, TableAction.GetCell).Element;

            if (lineNumberCell.Text.Length > 0)
            {
                if (int.Parse(lineNumberCell.Text.Clean()) == lineNumber)
                    Support.AreEqual(int.Parse(lineNumberCell.Text.Clean()).ToString(), lineNumber.ToString(), "Line number validation");
                else
                    Reports.StatusUpdate("Line Number Actual = " + lineNumberCell.Text + "Expected = " + lineNumber.ToString(), false);
            }
            else
                Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

            if (descriptionCell.Text.Length > 0)
            {
                string desc = descriptionCell.Text;

                if (desc == description)
                    Support.AreEqual(description, desc, "Description validation");
                else
                    Reports.StatusUpdate("Line - " + lineNumber + ". Description Actual = " + desc + "; Expected=" + description, false);
            }
            else
                Reports.StatusUpdate("Blank charge description shown in sec " + sectionName, false);

            if (fromDateCell.Text.Length == 0)
                Reports.StatusUpdate("From Date in Sec " + sectionName + " for descripton " + description + " is blank", true);
            else
                Reports.StatusUpdate("From Date in Sec " + sectionName + " for descripton " + description + " should be blank", false);

            if (toLabelCell.Text.Contains("to"))
                Reports.StatusUpdate("'To' label is displayed", true);
            else
                Reports.StatusUpdate("To label is not displayed", false);

            if (toDateCell.Text.Length > 0)
                Reports.StatusUpdate("To Date in Sec " + sectionName + " for descripton " + description + " should be blank", false);
            else
                Reports.StatusUpdate("To Date in Sec " + sectionName + " for descripton " + description + " is blank", true);

            if (amountCell.Text.Length > 0)
                Reports.StatusUpdate("Amount in " + sectionName + "for descripton " + description + "should be blank", false);
            else
                Reports.StatusUpdate("Amount in " + sectionName + "for descripton " + description + "is blank", true);
        }

        public void VerifySectionByLineNo_ChargesAvailable(ClosingDisclosureSection section, int lineNumber, string description, string fromDate, string toDate, string amount)
        {
            #region Variable declaration
            IWebElement lineNumberCell;
            IWebElement descriptionCell;
            IWebElement fromDateCell;
            IWebElement toLabelCell;
            IWebElement toDateCell;
            IWebElement amountCell;
            IWebElement table;
            int rowIndex = 0;
            int range = 0;
            #endregion

            string sectionName = section.ToString();
            Reports.TestStep = "Verify the line " + lineNumber + " in section " + sectionName;

            switch (section)
            {
                case ClosingDisclosureSection.M:
                    {
                        if (lineNumber == 9)
                            rowIndex = 2;
                        else if (lineNumber == 10)
                            rowIndex = 3;
                        else if (lineNumber == 11)
                            rowIndex = 4;
                        else
                            Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

                        table = SectionM_AdjustmentforItemsSubTable;

                        break;
                    }
                case ClosingDisclosureSection.L:
                    {
                        if (lineNumber == 12)
                            rowIndex = 2;
                        else if (lineNumber == 13)
                            rowIndex = 3;
                        else if (lineNumber == 14)
                            rowIndex = 4;
                        else
                            Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

                        table = SectionL_AdjustmentforItemsSubTable;

                        break;
                    }
                case ClosingDisclosureSection.N:
                    {
                        if (lineNumber == 14)
                            rowIndex = 2;
                        else if (lineNumber == 15)
                            rowIndex = 3;
                        else if (lineNumber == 16)
                            rowIndex = 4;
                        else
                            Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

                        table = SectionN_AdjustmentforItemsSubTable;

                        break;
                    }
                default:
                    {
                        table = null;
                        Support.Fail(string.Format("Unexpected Section to verify: {0}", sectionName));
                        break;
                    }
            }

            table.Click();

            lineNumberCell = table.PerformTableAction(rowIndex, 1, TableAction.GetCell).Element;
            descriptionCell = table.PerformTableAction(rowIndex, 2, TableAction.GetCell).Element;
            fromDateCell = table.PerformTableAction(rowIndex, 3, TableAction.GetCell).Element;
            toLabelCell = table.PerformTableAction(rowIndex, 4, TableAction.GetCell).Element;
            toDateCell = table.PerformTableAction(rowIndex, 5, TableAction.GetCell).Element;
            amountCell = table.PerformTableAction(rowIndex, 7, TableAction.GetCell).Element;

            if (lineNumberCell.Text.Length > 0)
            {
                if (int.Parse(lineNumberCell.Text.Clean()) == lineNumber)
                    Support.AreEqual(int.Parse(lineNumberCell.Text.Clean()).ToString(), lineNumber.ToString(), "Line number validation");
                else
                    Reports.StatusUpdate("Line Number Actual = " + lineNumberCell.Text + "Expected = " + lineNumber.ToString(), false);
            }
            else
                Reports.StatusUpdate("Invalid Fixed Line number in section " + sectionName, false);

            if (descriptionCell.Text.Length > 0)
            {
                string desc = descriptionCell.Text;

                if (desc == description)
                    Support.AreEqual(description, desc, "Description validation");
                else
                    Reports.StatusUpdate("Line - " + lineNumber + ". Description Actual = " + desc + "; Expected = " + description, false);
            }
            else
                Reports.StatusUpdate("Blank charge description shown in sec " + sectionName, false);

            if (fromDateCell.Text.Length > 0)
            {
                string fdate = fromDateCell.Text;

                if (fdate == fromDate)
                    Support.AreEqual(fromDate, fdate, "From Date validation");
                else
                    Reports.StatusUpdate("From Date Actual = " + fdate + "; Expected = " + fromDate, false);
            }
            else
                Reports.StatusUpdate("From Date in Sec " + sectionName + " for descripton " + description + " is blank", false);

            if (toLabelCell.Text.Contains("to"))
                Reports.StatusUpdate("To label is displayed", true);
            else
                Reports.StatusUpdate("To label is not displayed", false);

            if (toDateCell.Text.Length > 0)
            {
                string tdate = toDateCell.Text;

                if (tdate == toDate)
                    Support.AreEqual(tdate, toDate, "To Date validation");
                else
                    Reports.StatusUpdate("To Date Actual = " + tdate + "Expected = " + toDate, false);
            }
            else
                Reports.StatusUpdate("To Date in Sec " + sectionName + " for descripton " + description + " is blank", false);

            if (amountCell.Text.Length > 0)
            {
                string amt = amountCell.Text.Clean();
                string convertedAmount = "$" + string.Format("{0:#,##0.00}", amount.Clean());
                range = convertedAmount.Length;
                if (range > 15)
                {
                    string temp = convertedAmount;
                    temp = temp.Replace("$", "");
                    string[] dotSplit = temp.Split('.');
                    string decimalValue = dotSplit[1];
                    int extra = dotSplit[0].Length - 11;
                    Debug.Print(extra.ToString());
                    temp = dotSplit[0].Substring((extra)) + "." + decimalValue;
                    Debug.Print(temp);
                    temp = "$" + String.Format("{0:C}", temp.Clean());
                    Debug.Print(temp);
                    convertedAmount = temp;
                }
                if (amt == convertedAmount)
                    Support.AreEqual(convertedAmount, amt, "Charge Amount validation");
                else
                    Reports.StatusUpdate("Amount value. Actual = " + amt + " Expected = " + convertedAmount, false);
            }
            else
                Reports.StatusUpdate("Amount in " + sectionName + " for descripton " + description + " is shown as blank", false);

        }

        #region charges from Adjustment For Items Table

        public List<string> getTotalCreditChargeAmountFromAdjForItemsTable()
        {
            var rows = adjForItemsTable.FindElements(By.TagName("tr"));
            List<string> charges = new List<string>();

            var td = adjForItemsTable.FindElements(By.TagName("td"));
            foreach (var item in td)
            {
                if (item.Text.Contains("$"))
                    charges.Add(item.Text.Trim());
            }

            return charges;
        }

        #endregion

        #region charge description from Adjustment For Items Table

        public List<string> getChargeDescriptionsFromAdjForItemsTable()
        {
            var rows = adjForItemsTable.FindElements(By.TagName("tr"));
            List<string> description = new List<string>();

            IWebElement element;
            foreach (var item in rows)
            {
                try
                {
                    element = item.FindElement(By.CssSelector("[class='SubsectiontdWidth']"));
                    description.Add(element.Text.Trim());
                }
                catch (Exception e)
                {
                    System.Console.WriteLine(e.Message);
                }
            }

            return description;
        }

        #endregion

        #region function to verify supplementary charges

        public void charge_Verification(ClosingDisclosureSection section, int seqNo)
        {
            IWebElement sectionTable = GetSectionTableForItemsUnpaidBySeller(section);

            if (seqNo >= 12 && seqNo <= 17)
            {
                this.SwitchToContentFrame();
                this.WaitCreation(sectionTable);
                sectionTable.Click();
                var element = sectionTable.PerformTableAction((seqNo - 10), 2, TableAction.GetCell).Element;
                element = element.FindElements(By.CssSelector("span")).FirstOrDefault(i => i.GetAttribute("Title").Contains("Flood Desc") && i.Displayed);
                Support.AreEqual("Th!s is a Flood Desc1", element.GetAttribute("Title").ToString().Trim());
                element = sectionTable.PerformTableAction((seqNo - 10), 6, TableAction.GetCell).Element;
                Support.AreEqual("$300,000.00", element.Text.Trim());
            }
        }

        #endregion

        public void VerifyAmountForCategory(int LineNo, string chargeDesc = null, double? LoanEstimateRounded = null, double? LoanEstimateUnrounded = null, double? FinalBorrowerPaid = null)
        {
            string convertedAmount = string.Empty;

            if (chargeDesc != string.Empty)
            {
                Support.AreEqual(chargeDesc, GoodFaithAnalysisCategoryTable.PerformTableAction(LineNo, 1, TableAction.GetText).Message.Trim());
            }
            if (LoanEstimateRounded.HasValue)
            {
                convertedAmount = String.Format("{0:C}", LoanEstimateRounded).Replace(".00", string.Empty);
                Support.AreEqual(convertedAmount, GoodFaithAnalysisCategoryTable.PerformTableAction(LineNo, 2, TableAction.GetText).Message.Trim());
            }
            if (LoanEstimateUnrounded.HasValue)
            {
                convertedAmount = String.Format("{0:C}", LoanEstimateUnrounded);
                Support.AreEqual(convertedAmount, GoodFaithAnalysisCategoryTable.PerformTableAction(LineNo, 3, TableAction.GetText).Message.Trim());
            }
            if (FinalBorrowerPaid.HasValue)
            {
                convertedAmount = String.Format("{0:C}", FinalBorrowerPaid);
                Support.AreEqual(convertedAmount, GoodFaithAnalysisCategoryTable.PerformTableAction(LineNo, 5, TableAction.GetText).Message.Trim());
            }

        }

        public void VerifyAmountForCategory(string tableID, int LineNo, string chargeDesc = null, double? LoanEstimateDisclosedRounded = null, double? LoanEstimateUnrounded = null, double? FinalBorrowerPaid = null)
        {
            var table = WebDriver.FindElement(By.Id(tableID));
            string convertedAmount = string.Empty;

            if (chargeDesc != string.Empty)
            {
                Support.AreEqual(chargeDesc, table.PerformTableAction(LineNo, 1, TableAction.GetText).Message.Trim());
            }
            if (LoanEstimateDisclosedRounded.HasValue)
            {
                convertedAmount = String.Format("{0:C}", LoanEstimateDisclosedRounded).Replace(".00", string.Empty);
                Support.AreEqual(convertedAmount, table.PerformTableAction(LineNo, 2, TableAction.GetText).Message.Trim());
            }
            if (LoanEstimateUnrounded.HasValue)
            {
                convertedAmount = String.Format("{0:C}", LoanEstimateUnrounded);
                Support.AreEqual(convertedAmount, table.PerformTableAction(LineNo, 4, TableAction.GetText).Message.Trim());
            }
            if (FinalBorrowerPaid.HasValue)
            {
                if (FinalBorrowerPaid < 0)
                    convertedAmount = "-" + String.Format("{0:C}", FinalBorrowerPaid).Replace("(", "").Replace(")", "");
                else
                    convertedAmount = String.Format("{0:C}", FinalBorrowerPaid);
                Support.AreEqual(convertedAmount, table.PerformTableAction(LineNo, 3, TableAction.GetText).Message.Trim());
            }

        }
        
        public void editLoanEstimateColumn(ClosingDisclosureSection section, string desc, bool isRounded, double amt, int lineNo)
        {
            IWebElement table = GetSectionTable(section);
            string temp = "$" + string.Format("{0:#,##0.00}", Convert.ToString(amt)); // String.Format("{0:C}", amt.ToString());
            string[] decimalPart = temp.Split('.');
            Debug.Print("Valor de temp: " + temp);
            Debug.Print("Valor decimal: " + decimalPart[1]);
            var cell = table.FindElements(By.TagName("tr"))[lineNo].FindElements(By.TagName("td")).FirstOrDefault(i => i.Text.Contains(desc) && i.Displayed);

            if (isRounded)
            {
                amt = Math.Round(amt);
                temp = "$" + string.Format("{0:#,##0.00}", amt.ToString().Clean()) + ".00";
                Debug.Print("Valor temp 2: " + temp);
            }

            IWebElement element;
            if (cell.Displayed && isRounded)
            {
                element = table.PerformTableAction((lineNo + 1), 8, TableAction.GetCell).Element.FindElements(By.CssSelector("span[contenteditable]"))
                    .FirstOrDefault(i => i.GetAttribute("Id").Contains("lblDisplayRoundedAmount") && i.Displayed);

                while (true)
                {
                element.Click();
                    Playback.Wait(500);
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(1000);
                    Keyboard.SendKeys(Convert.ToString(amt));
                Playback.Wait(1000);
                    DisplayLoanEstimate.Click();
                    Playback.Wait(2000);
                    DisplayLoanEstimate.Click();
                    //table.Click();

                    if (element.Text.Replace(",", "").Clean() == temp)
                        break;
                }
            }
            else
            {
                element = table.PerformTableAction((lineNo + 1), 7, TableAction.GetCell).Element.FindElements(By.CssSelector("span[contenteditable]"))
                    .FirstOrDefault(i => i.GetAttribute("Id").Contains("lblDisplayLEAmount") && i.Displayed);

                while (true)
                {
                element.Click();
                    Playback.Wait(500);
                element.Click();
                Playback.Wait(1000);
                Keyboard.SendKeys("^A");
                Playback.Wait(1000);
                Keyboard.SendKeys("{DELETE}");
                Playback.Wait(1000);
                Keyboard.SendKeys(Convert.ToString(amt));
                Playback.Wait(1000);
                    DisplayLoanEstimate.Click();
                    Playback.Wait(2000);
                    DisplayLoanEstimate.Click();
                    //table.Click();

                    if (element.Text.Replace(",", "").Clean() == temp)
                        break;
                }
            }

        }

        public void editCostDescription(ClosingDisclosureSection section, string desc, string modifiedDesc)
        {
            IWebElement table = GetSectionTable(section);

            try
            {
                var element = table.FindElements(By.TagName("td")).FirstOrDefault(i => i.Text.Contains(desc) && i.Displayed);
                element = element.FindElements(By.CssSelector("span[contenteditable]")).FirstOrDefault(j => j.GetAttribute("Title").Contains(desc) && j.Displayed);

                Reports.StatusUpdate("The Description: " + desc + " is Editable in the CD Screen", true);
                element.Clear();
                element.FASetText(modifiedDesc);
                Keyboard.SendKeys(FAKeys.TabAway);
                Reports.StatusUpdate("The Description Field value is Modified.", true);
            }
            catch (Exception e)
            {
                Support.Fail(e.Message);
                Reports.StatusUpdate("The Description: " + desc + " is Not Editable in the CD Screen SECTION", false);
            }


        }

        public void ValidateSectionMDueItemsLine(int i, string description, double credit)
        {
            int rowIndex = i + 4; //since perform table action starts from 1, the 3rd row is the 4rd rendered because the table header counts as the first row
            string expectedLineNumber = "0" + (rowIndex - 1); //normalize expected line number
            string cellText = SectionM_DueItemsTable.PerformTableAction(rowIndex, 1, TableAction.GetText).Message.Clean();

            if (cellText.StartsWith(expectedLineNumber))
                Reports.StatusUpdate(string.Format("The value Serial no is verifed: {0}", expectedLineNumber), true);
            else
                Reports.StatusUpdate("The value Serial is not matching. Cell text = " + cellText + ", Expected line number = " + expectedLineNumber, false);

            if (cellText.Clean().Contains(description))
                Reports.StatusUpdate("The value Desc is verifed: " + description, true);
            else
                Reports.StatusUpdate("The value Desc is not matching. Actual = " + cellText + ", Expected = " + description, false);

            string amount = SectionM_DueItemsTable.PerformTableAction(rowIndex, 3, TableAction.GetText).Message.Clean();
            amount = amount.Replace(",", "").Replace("$", "");//normalize actual amount
            string expectedAmount = credit.ToString() + ".00"; //normalize expected amount
            if (amount == expectedAmount)
                Reports.StatusUpdate("The  value seller credit is  verifed. Actual=" + amount + " Expected=" + expectedAmount, true);
            else
                Reports.StatusUpdate("The value  seller credit not matching. Actual=" + amount + " Expected=" + expectedAmount, false);
        }

        public void ValidateSuplementaryChargesSectionM(bool ignoreLine16, List<string> descriptions, List<string> fromDates, List<string> toDates, List<string> credits)
        {
            this.SwitchToContentFrame();

            int asciiChar = 96;
            for (int i = 5; i <= SectionM_AdjustmentforItemsSubTable.GetRowCount(); i++)
            {
                int arrayIndex = i - 5;
                int LineNo = i + 7;
                bool below16 = LineNo < 16;
                bool over16 = LineNo > 16;

                if (over16 || below16)
                {
                    string expectedLineNo = over16 ? "16" + (char)(asciiChar + LineNo - 16) : LineNo.ToString();
                    Reports.TestStep = over16 ? "verifying supplementary line no " + expectedLineNo + " of section M" : "verifying line " + expectedLineNo + " of section M";
                    string actualLineNo = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 1, TableAction.GetText).Message.Clean();
                    if (actualLineNo.Contains(expectedLineNo))
                        Reports.StatusUpdate("the value line no is verifed." + "Actual=" + actualLineNo + " Expected=" + expectedLineNo, true);
                    else
                        Reports.StatusUpdate("the value  not matching." + "Actual=" + actualLineNo + " Expected=" + expectedLineNo, false);

                    string actualHelptext = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).GetAttribute("title").Clean();
                    string expectedHelptext = over16 ? descriptions[arrayIndex - 1] : descriptions[arrayIndex];
                    if (actualHelptext == expectedHelptext)
                        Reports.StatusUpdate("the value desc is verifed." + "Actual=" + actualHelptext + " Expected=" + expectedHelptext, true);
                    else
                        Reports.StatusUpdate("the value Description not matching." + "Actual=" + actualHelptext + " Expected=" + expectedHelptext, false);

                    string actualFromDate = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    string expectedFromDate = (over16 ? fromDates[arrayIndex - 1] : fromDates[arrayIndex]);
                    if (actualFromDate == expectedFromDate)
                        Reports.StatusUpdate("the value From Date is verifed." + "Actual=" + actualFromDate + " Expected=" + expectedFromDate, true);
                    else
                        Reports.StatusUpdate("the value From Date not matching." + "Actual=" + actualFromDate + " Expected=" + expectedFromDate, false);

                    string actualToDate = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 5, TableAction.GetText).Message.Clean();
                    string expectedToDate = (over16 ? toDates[arrayIndex - 1] : toDates[arrayIndex]);
                    if (actualToDate == expectedToDate)
                        Reports.StatusUpdate("the value To Date is verifed." + "Actual=" + actualToDate + " Expected=" + expectedToDate, true);
                    else
                        Reports.StatusUpdate("the value To Date not matching." + "Actual=" + actualToDate + " Expected=" + expectedToDate, false);

                    string expectedAmount = over16 ? credits[arrayIndex - 1].FormatAsMoney(true) : credits[arrayIndex].FormatAsMoney(true);
                    string actualAmount = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 7, TableAction.GetText).Message.Clean();
                    if (actualAmount == expectedAmount)
                        Reports.StatusUpdate("the value Amount is verifed." + "Actual=" + actualAmount + " Expected=" + expectedAmount, true);
                    else
                        Reports.StatusUpdate("the value Amount not matching." + "Actual=" + actualAmount + " Expected=" + expectedAmount, false);
                }
                else if (!ignoreLine16)
                {
                    string expectedLineNo = LineNo.ToString();
                    Reports.TestStep = "verifying line " + expectedLineNo + " of section M";
                    string actualLineNo = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 1, TableAction.GetText).Message.Clean();
                    if (actualLineNo.Contains(expectedLineNo))
                        Reports.StatusUpdate("the value line no is verifed." + "Actual=" + actualLineNo + " Expected=" + expectedLineNo, true);
                    else
                        Reports.StatusUpdate("the value  not matching." + "Actual=" + actualLineNo + " Expected=" + expectedLineNo, false);

                    string actualHelptext = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).GetAttribute("title").Clean();
                    string expectedHelptext = descriptions[arrayIndex];
                    if (actualHelptext == expectedHelptext)
                        Reports.StatusUpdate("the value desc is verifed." + "Actual=" + actualHelptext + " Expected=" + expectedHelptext, true);
                    else
                        Reports.StatusUpdate("the value Description not matching." + "Actual=" + actualHelptext + " Expected=" + expectedHelptext, false);

                    string actualFromDate = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 3, TableAction.GetText).Message.Clean();
                    string expectedFromDate = fromDates[arrayIndex];
                    if (actualFromDate == expectedFromDate)
                        Reports.StatusUpdate("the value From Date is verifed." + "Actual=" + actualFromDate + " Expected=" + expectedFromDate, true);
                    else
                        Reports.StatusUpdate("the value From Date not matching." + "Actual=" + actualFromDate + " Expected=" + expectedFromDate, false);

                    string actualToDate = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 5, TableAction.GetText).Message.Clean();
                    string expectedToDate = toDates[arrayIndex];
                    if (actualToDate == expectedToDate)
                        Reports.StatusUpdate("the value To Date is verifed." + "Actual=" + actualToDate + " Expected=" + expectedToDate, true);
                    else
                        Reports.StatusUpdate("the value To Date not matching." + "Actual=" + actualToDate + " Expected=" + expectedToDate, false);

                    string expectedAmount = credits[arrayIndex].FormatAsMoney(true);
                    string actualAmount = SectionM_AdjustmentforItemsSubTable.PerformTableAction(i, 7, TableAction.GetText).Message.Clean();
                    if (actualAmount == expectedAmount)
                        Reports.StatusUpdate("the value Amount is verifed." + "Actual=" + actualAmount + " Expected=" + expectedAmount, true);
                    else
                        Reports.StatusUpdate("the value Amount not matching." + "Actual=" + actualAmount + " Expected=" + expectedAmount, false);
                }
            }
        }

        public void ValidateSuplementaryLine(string amount)
        {
            this.SwitchToContentFrame();
            Reports.TestStep = "verifying supplementary line no 16 of section M";
            string actualLineNo = SectionM_AdjustmentforItemsSubTable.PerformTableAction(9, 1, TableAction.GetText).Message.Clean();
            if (actualLineNo.Contains("16"))
                Reports.StatusUpdate("the value line no is verifed." + "Actual=" + actualLineNo + " Expected=16", true);
            else
                Reports.StatusUpdate("the value  not matching." + "Actual=" + actualLineNo + " Expected=16", false);

            Reports.TestStep = "verifying Supplementary line description";
            string actualHelptext = SectionM_AdjustmentforItemsSubTable.PerformTableAction(9, 2, TableAction.GetCell).Element.FindElement(By.TagName("span")).GetAttribute("title").Clean();
            if (actualHelptext == "See attached page for additional information")
                Reports.StatusUpdate("the value desc is verifed." + "Actual=" + actualHelptext + " Expected=See attached page for additional information", true);
            else
                Reports.StatusUpdate("the value Description not matching." + "Actual=" + actualHelptext + " Expected=See attached page for additional information", false);

            Reports.TestStep = "verifying Supplementary line sum charges";
            string expectedAmount = amount.FormatAsMoney(true);
            string actualAmount = SectionM_AdjustmentforItemsSubTable.PerformTableAction(9, 4, TableAction.GetText).Message.Clean();
            if (actualAmount == expectedAmount)
                Reports.StatusUpdate("the value Amount is verifed." + "Actual=" + actualAmount + " Expected=" + expectedAmount, true);
            else
                Reports.StatusUpdate("the value Amount not matching." + "Actual=" + actualAmount + " Expected=" + expectedAmount, false);
        }

        public void CheckDoubleAsterisk_CD(string ChrDesc, string tblsubsectionID, bool Condn)
        {
            this.SwitchToContentFrame();
            int count_Description = 0;
            string[] sectionID;
            var table = WebDriver.FindElement(By.Id(tblsubsectionID));
            sectionID = tblsubsectionID.Split('_');
            
            if (Condn)
            {
                for (int i = 1; i < table.GetRowCount(); i++)
                {

                    string Desc = table.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].Text;
                    Desc = Desc.Replace("'", "");

                    if (Desc.ToLower().Trim().Contains(ChrDesc.ToLower().Trim()))
                    {
                        Reports.StatusUpdate("The Charge Description: " + Desc + " is Displayed in the Section " + sectionID[1], true);
                        count_Description++;
                        if (table.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].Text.Substring(4, 4).Contains("**"))
                        {
                            Support.AreEqual("true", "true", "Double asterisk is displayed before Charge Description");
                            Reports.StatusUpdate("Double asterisk is displayed before Charge Description " + Desc, true);
                        }
                        else
                        {
                            Support.AreEqual("false", "true", "Double asterisk is not displayed before Charge Description");
                            Reports.StatusUpdate("Double asterisk is not displayed before the Charge Description " + Desc, false);
                        }
                        break;
                    }
                    else
                        continue;
                }
            }
            else
                for (int i = 1; i < table.GetRowCount(); i++)
                {
                    if (table.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[2].Text == ChrDesc)
                    {
                        string Desc = table.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].Text;
                        Desc = Desc.Replace("'", "");
                        if (Desc.ToLower().Trim().Contains(ChrDesc.ToLower().Trim()))
                        {
                            Reports.StatusUpdate("The Charge Description: " + ChrDesc + " is Displayed in the Section " + sectionID[1], true);
                            count_Description++;
                            if (table.FindElements(By.TagName("tr"))[i].FindElements(By.TagName("td"))[0].Text.Substring(5, 4).Contains("**"))
                            {
                                Support.AreEqual("false", "true", "Double asterisk is displayed before Charge Description");
                                Reports.StatusUpdate("Double asterisk is displayed before Charge Description " + Desc, false);
                            }
                            else
                            {
                                Support.AreEqual("true", "true", "Double asterisk is not displayed before Charge Description");
                                Reports.StatusUpdate("Double asterisk is not displayed before the Charge Description " + Desc, true);
                            }
                            break;
                        }
                        else
                            continue;
                    }
                }
        }

        public void WaitForElement(IWebElement Element)
        {
            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                try
                {
                    //return Element.Exists() && Element.Displayed && Element.Enabled;
                    return Element.Exists() && Element.Displayed;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
            });
        }

        public void SelectDisplayLoanEstimate()
        {
            do
            {
                this.DisplayLoanEstimate.FASetCheckbox(true);
            }
            while (!this.DisplayLoanEstimate.Selected);
        }

        public bool doesElementExist(IWebElement element)
        {

            try
            {

                return element.Displayed;
    }
            catch (NoSuchElementException)
            {
                return false;
            }
        }
        //
        public bool ScrollToElement(IWebElement Element)
        {
            try
            {
                System.Drawing.Point pt = Element.Location;
                IJavaScriptExecutor js = (IJavaScriptExecutor)FastDriver.WebDriver;
                js.ExecuteScript("scrollTo(" + pt.X + "," + pt.Y + ")");
                Thread.Sleep(3000);
                if (Element.IsDisplayed())
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to scroll" + ex.Message, false);
                return false;
            }
        }
        
       public void SelectIncludeAdjustablePaymentAPTable()
        {
            this.Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(true);
        }

       public void DeSelectIncludeAdjustablePaymentAPTable()
       {
           this.Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(false);
           Support.AreEqual("All modified information will be erased from the AP table. Do you wish to continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: true));
       }

       public void SelectYesinInterestOnlyPaymentsandClickPlusIcon()
       {
           this.Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(true);
           this.Sec9_APnAIRtable_APInterestOnlyDrpDwn.FASelectItem("YES");
           this.InterestOnlyPayments_PlusIcon.FAClick();
       }

       public void SelectYesinOptionalPaymentsandClickPlusIcon()
       {
           this.Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(true);
           this.Sec9_APnAIRtable_APOptionalPaymentsDrpDwn.FASelectItem("YES");
           this.OptionalPayments_PlusIcon.FAClick();
       }

       public void SelectYesinStepPaymentsandClickPlusIcon()
       {
           this.Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(true);
           this.Sec9_APnAIRtable_APStepPaymentsDrpDwn.FASelectItem("YES");
           this.StepPayments_PlusIcon.FAClick();
       }

       public void SelectYesinSeasonalPaymentsandClickPlusIcon()
       {
           this.Sec9_APnAIRtable_APTableChkBox.FASetCheckbox(true);
           this.Sec9_APnAIRtable_APSeasonalPaymentsDrpDwn.FASelectItem("YES");
           this.SeasonalPayments_PlusIcon.FAClick();
       }

       public void EnterDetailsInterestOnlyPaymentsPopUp(IWebElement Radio, IWebElement FirstTextBox , IWebElement SecondTextBox ,string Data1 ,string Data2)
       {
           Radio.FAClick();
           if (Data1 != null)
           {
               if (Data1 != null)
               {
                   FirstTextBox.Clear();
                   FirstTextBox.FASetText(Data1);
               }
               if (Data2 != null)
               {
                   SecondTextBox.Clear();
                   SecondTextBox.FASetText(Data2);
               }
            }
           else
           {
              this.PaymentSceduleFrom1.FASelectItem("Jan");
              this.PaymentSceduleFrom2.FASelectItem("Nov");
           }
           this.PaymentSchedule_Done.FAClick();
       }


        public enum RecordingFeeTransferTax
        {
            RecordingFee, TransferTax
        }

        public void EditLoanEstimateSecE(RecordingFeeTransferTax RecTransfer, double? LoanEstimateUnRounded, double? LoanEstimateRounded = null, bool IsBrokenLink = false)
        {
            this.SwitchToContentFrame();
            if (LoanEstimateUnRounded.HasValue)
                Reports.TestStep = "Edit Loan Estimate Unrounded for  Recording Fees  to " + LoanEstimateUnRounded;
            if (LoanEstimateRounded.HasValue)
                Reports.TestStep = "Edit Loan Estimate Rounded for Recording Fees  to " + LoanEstimateRounded;

            switch (RecTransfer)
            {
                case RecordingFeeTransferTax.RecordingFee:
                    if (LoanEstimateUnRounded.HasValue)
                    {
                        Reports.TestStep = "Edit Loan Estimate Unrounded amount for Recording Fees";
                        //this.UnRoundedSpan.FAClick();
                        this.UnRoundedSpan.Clear();
                        this.UnRoundedSpan.FASetText(LoanEstimateUnRounded.ToString());
                    }
                    if (LoanEstimateRounded.HasValue)
                    {
                        Reports.TestStep = "Edit Loan Estimate rounded amount for Recording Fees";
                        this.RoundedSpan.Clear();
                        this.RoundedSpan.FASetText(LoanEstimateRounded.ToString());
                    }
                    if (IsBrokenLink == true)
                    {
                        Reports.TestStep = "VERIFY THE ROUNDED BROKEN LINK FOR DESCRIPTION : Recording Fees";
                        Support.IsTrue(this.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("div#divOtherCostSection_E td.Rounded span img"))) != IsBrokenLink, "CD Section E LE amount broken image");
                    }
                    break;
                case RecordingFeeTransferTax.TransferTax:
                    if (LoanEstimateUnRounded.HasValue)
                    {
                        Reports.TestStep = "Edit Loan Estimate Unrounded amount for Transfer Tax";
                        //this.UnRoundedSpan.FAClick();
                        this.E02PlusUnroundedAmt.Clear();
                        this.E02PlusUnroundedAmt.FASetText(LoanEstimateUnRounded.ToString());
                    }
                    if (LoanEstimateRounded.HasValue)
                    {
                        Reports.TestStep = "Edit Loan Estimate rounded amount for Transfer Tax";
                        this.E02PlusRoundedAmt.Clear();
                        this.E02PlusRoundedAmt.FASetText(LoanEstimateRounded.ToString());
                    }
                    if (IsBrokenLink == true)
                    {
                        Reports.TestStep = "VERIFY THE ROUNDED BROKEN LINK FOR DESCRIPTION : Transfer Tax";
                        Support.IsTrue(this.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("td#tdE02PlusRounded span img, td.Rounded span img"))) != IsBrokenLink, "CD Section E LE amount broken image");
                    }
                    break;
                default:
                    Reports.TestStep = "Select Recording Fees or Transfer Tax";
                    break;

            }
        }
        //
        public ClosingDisclosureEventsLog OpenClosingDisclosureEventsLog()
        {
            this.Open();
            this.tabClosingDisclosure.FAClick();
            this.WaitForClosingDisclosureScreenToLoad();
            this.CDEvents.Highlight();
            this.CDEvents.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            return FastDriver.ClosingDisclosureEventsLog.WaitForScreenToLoad();
        }
        public void RejectLenderUpdate()
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Click on Lender Update";
            this.LenderUpdate.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.WaitForScreenToLoad();

            //Click pencil icon
            Reports.TestStep = "Click on Pencil icon in Projected Payments and reject lender update review";
            this.ProjectedPaymentsPencilIcon.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            FastDriver.LenderUpdatesReviewDlg.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            FastDriver.LenderUpdatesReviewDlg.WaitForScreenToLoad(FastDriver.LenderUpdatesReviewDlg.Accept);

            FastDriver.LenderUpdatesReviewDlg.Reject.FAClick();
            FastDriver.LenderUpdatesReviewDlg.RejectComment.FASetText("Rejected for testing");
            FastDriver.LenderUpdatesReviewDlg.Done.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.WaitForScreenToLoad();


            //this.LenderUpdate.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false,30);
            //Reports.TestStep = "Click on Pencil icon in Projected Payments and reject lender update review";
            //this.WaitForScreenToLoad();
            //this.ProjectedPaymentsPencilIcon.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            //FastDriver.LenderUpdatesReviewDlg.WaitForScreenToLoad();
            //FastDriver.LenderUpdatesReviewDlg.Reject.FAClick();
            //FastDriver.LenderUpdatesReviewDlg.RejectComment.FASetText("Rejected for testing");
            //FastDriver.LenderUpdatesReviewDlg.Done.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
        }
        public void AcceptLenderUpdate()
        {
            this.Open();

            Reports.TestStep = "Click on Lender Update";
            this.LenderUpdate.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.WaitForScreenToLoad();

            //Click pencil icon
            Reports.TestStep = "Click on ProjectedPaymentsPencilIcon and Accept";
            this.ProjectedPaymentsPencilIcon.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            FastDriver.LenderUpdatesReviewDlg.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            FastDriver.LenderUpdatesReviewDlg.WaitForScreenToLoad(FastDriver.LenderUpdatesReviewDlg.Accept);

            FastDriver.LenderUpdatesReviewDlg.Accept.FAClick();
            FastDriver.LenderUpdatesReviewDlg.Done.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.WaitForScreenToLoad();

           //this.LenderUpdate.FAClick();

           //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
           //this.WaitForScreenToLoad();
           //IWebElement ProjectedPaymentsPencilIcon = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "divProjectedPaymentsHeader").FAFindElement(ByLocator.TagName, "IMG");
           //ProjectedPaymentsPencilIcon.FAClick();
           // FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,20);
           // FastDriver.LenderUpdatesReviewDlg.WaitForScreenToLoad();
           // FastDriver.LenderUpdatesReviewDlg.Accept.FAClick();
           // FastDriver.LenderUpdatesReviewDlg.Done.ScrollIntoView();
           // FastDriver.LenderUpdatesReviewDlg.Done.FAClick();
           // FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,30);

           
        }
        //
        public void AcceptLenderUpdateForAdditionalInfo()
        {
            this.Open();

            Reports.TestStep = "Click on Lender Update";
            this.LenderUpdate.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.WaitForScreenToLoad();

            //Click pencil icon
            Reports.TestStep = "Accept lender update for additional details";
            this.LoanDisclosurePencilIcon.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            FastDriver.LenderUpdatesReviewDlg.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            FastDriver.LenderUpdatesReviewDlg.WaitForScreenToLoad(FastDriver.LenderUpdatesReviewDlg.Accept);

            FastDriver.LenderUpdatesReviewDlg.Accept.FAClick();
            FastDriver.LenderUpdatesReviewDlg.Done.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.WaitForScreenToLoad();

            //Reports.TestStep = "Accept lender update for additional details";
           // this.LenderUpdate.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            //this.WaitForScreenToLoad();
            //IWebElement LoanDisclosurePencilIcon = FastDriver.WebDriver.FAFindElement(ByLocator.Id, "divLoanDiscHeader").FAFindElement(ByLocator.TagName, "IMG");
            //LoanDisclosurePencilIcon.ScrollIntoView();
            //LoanDisclosurePencilIcon.JSClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,30);
            //FastDriver.LenderUpdatesReviewDlg.WaitForScreenToLoad();
            //FastDriver.LenderUpdatesReviewDlg.Accept.FAClick();
            //FastDriver.LenderUpdatesReviewDlg.Done.FAClick();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,30);
        }
        //
        public void ClickReviewedOnAdditionalLenderUpdate()
        {
            this.WaitForScreenToLoad();
            this.OtherCDUpdate.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,30);
            FastDriver.OtherCDUpdatesReview.WaitForScreenToLoad();
            FastDriver.OtherCDUpdatesReview.Reviewed.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(false);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false,30);
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);         
        }
        //
        public Dictionary<string, string> GetLenderDetails()
        {
            if (!this.LenderName.Exists())
                this.WaitForScreenToLoad(this.LenderCDDone);
            Dictionary<string, string> LenderDetails = new Dictionary<string, string>();
            try
            {
                this.LenderName.ScrollIntoView();
                LenderDetails.Add("LenderName", string.IsNullOrEmpty(this.LenderName.FAGetValue().Trim()) ? "Blank" : this.LenderName.FAGetValue().Trim());
                LenderDetails.Add("LenderBusinessPhone", string.IsNullOrEmpty(this.LenderPhone.FAGetValue().Trim()) ? "Blank" : this.LenderPhone.FAGetValue().Trim());
                LenderDetails.Add("LenderBusinessPhoneExtension", string.IsNullOrEmpty(this.LenderPhoneExt.FAGetValue().Trim()) ? "Blank" : this.LenderPhoneExt.FAGetValue().Trim());
                LenderDetails.Add("LenderAddressLine1", string.IsNullOrEmpty(this.LenderAddressLine1.FAGetValue().Trim()) ? "Blank" : this.LenderAddressLine1.FAGetValue().Trim());
                LenderDetails.Add("LenderAddressLine2", string.IsNullOrEmpty(this.LenderAddressLine2.FAGetValue().Trim()) ? "Blank" : this.LenderAddressLine2.FAGetValue().Trim());
                LenderDetails.Add("LenderAddressLine3", string.IsNullOrEmpty(this.LenderAddressLine3.FAGetValue().Trim()) ? "Blank" : this.LenderAddressLine3.FAGetValue().Trim());
                LenderDetails.Add("LenderAddressLine4", string.IsNullOrEmpty(this.LenderAddressLine4.FAGetValue().Trim()) ? "Blank" : this.LenderAddressLine4.FAGetValue().Trim());

                LenderDetails.Add("LenderEmail", string.IsNullOrEmpty(this.LenderEmail.FAGetValue().Trim()) ? "Blank" : this.LenderEmail.FAGetValue().Trim());
                LenderDetails.Add("LenderNMLSID", string.IsNullOrEmpty(this.LenderNMLSId.FAGetValue().Trim()) ? "Blank" : this.LenderNMLSId.FAGetValue().Trim());
                LenderDetails.Add("LenderStateLicenseID", string.IsNullOrEmpty(this.LenderLicenseId.FAGetValue().Trim()) ? "Blank" : this.LenderLicenseId.FAGetValue().Trim());
                //
                LenderDetails.Add("LenderCity", string.IsNullOrEmpty(this.LenderCity.FAGetValue().Trim()) ? "Blank" : this.LenderCity.FAGetValue().Trim());
                LenderDetails.Add("LenderState", string.IsNullOrEmpty(this.LenderState.FAGetSelectedItem().Trim()) ? "Blank" : this.LenderState.FAGetSelectedItem().Trim());
                LenderDetails.Add("LenderZip", string.IsNullOrEmpty(this.LenderZip.FAGetValue().Trim()) ? "Blank" : this.LenderZip.FAGetValue().Trim());
               //
                LenderDetails.Add("LenderContactFirstName", string.IsNullOrEmpty(this.LenderContactFirstName.FAGetValue().Trim()) ? "Blank" : this.LenderContactFirstName.FAGetValue().Trim());
                LenderDetails.Add("LenderContactLastName", string.IsNullOrEmpty(this.LenderContactLastName.FAGetValue().Trim()) ? "Blank" : this.LenderContactLastName.FAGetValue().Trim());
                LenderDetails.Add("LenderContactNMLSID", string.IsNullOrEmpty(this.LenderContactNMLSId.FAGetValue().Trim()) ? "Blank" : this.LenderContactNMLSId.FAGetValue().Trim());
                
                return LenderDetails;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return LenderDetails;
            }

        }
        //
        public void SetLenderDetails()
        {
            this.WaitForScreenToLoad();
            Dictionary<string, string> LenderDetails = new Dictionary<string, string>();
            try
            {
                string Random=Support.RandomString("NNNNN");
                this.LenderName.FASetText("LenderName " + Random);
                this.LenderAddressLine1.FASetText("Address line 1" + Random);
                this.LenderAddressLine2.FASetText("Address line 2" + Random);
                this.LenderAddressLine3.FASetText("Address line 3" + Random);
                this.LenderAddressLine4.FASetText("Address line 4" + Random);
                this.LenderPhone.FASetText(@"(345)621-5678");
                this.LenderPhoneExt.FASetText("567");
                this.LenderEmail.FASetText("lenderemail"+Random+"@first.com");
                this.LenderNMLSId.FASetText("1" + Random);
                this.LenderLicenseId.FASetText("7" + Random);
                this.LenderCity.FASetText("City"+Random);
                this.LenderState.FASelectItemByIndex(this.LenderState.FAGetSelectedIndex()+2);
                this.LenderZip.FASetText(Random);
                this.LenderContactFirstName.FASetText("LenderContactFN" + Random);
                this.LenderContactLastName.FASetText("LenderContactLN" + Random);
                this.LenderContactLicenseId.FASetText(Random);
                this.LenderContactNMLSId.FASetText(Random);
                //
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        public void CalculatingCashToCloseClause(string DivId, string OtherTestBoxID, int RowIndex, bool Navigate = true)
        {
            Reports.TestStep = "Edit Clause at " + RowIndex.ToString() + "th Row and verify on Cd screen";
            if (Navigate)
            {
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.SwitchToContentFrame();
                this.CalculateCashToClose.FAClick();
                this.CalculatingCashtoCloseTable.FAMoveToElement();
                this.CalculatingCashtoCloseTable.PerformTableAction(RowIndex, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
            }
            this.SwitchToContentFrame();
            //FastDriver.WebDriver.FindElement(By.Id(DivId)).Highlight();
            FastDriver.WebDriver.FindElement(By.Id(DivId)).FindElement(By.Id("optCCC2973")).FAClick();
            FastDriver.WebDriver.FindElement(By.Id(DivId)).FindElement(By.Id(OtherTestBoxID)).FASetText("Other Comments");
            FastDriver.WebDriver.FindElement(By.Id(DivId)).FindElement(By.Id("btnCalculateCashToCloseDone")).FAClick();
            Support.AreEqual("True", this.CalculatingCashtoCloseTable.PerformTableAction(RowIndex, 4, TableAction.GetText).Message.ToString().Contains("Other Comments").ToString());
        }

        public void CalculatingCashToCloseStatement(string DivId, string RadioButtonID, int RowIndex, string Statement, bool Navigate = true)
        {
            Reports.TestStep = "Edit Clause at " + RowIndex.ToString() + "th Row and verify on Cd screen";
            if (Navigate)
            {
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure");
                this.SwitchToContentFrame();
                this.CalculateCashToClose.FAClick();
                //this.CalculatingCashtoCloseTable.FAMoveToElement();
                this.CalculatingCashtoCloseTable.PerformTableAction(RowIndex, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG").FAClick();
            }
            this.SwitchToContentFrame();
            //FastDriver.WebDriver.FindElement(By.Id(DivId)).Highlight();
            FastDriver.WebDriver.FindElement(By.Id(DivId)).FindElement(By.Id(RadioButtonID)).FAClick();
            FastDriver.WebDriver.FindElement(By.Id(DivId)).FindElement(By.Id("btnCalculateCashToCloseDone")).FAClick();
            Reports.TestStep = "Verify " + Statement + " on Cd screen";
            Support.AreEqual("True", this.CalculatingCashtoCloseTable.PerformTableAction(RowIndex, 4, TableAction.GetText).Message.ToString().Replace("\n", "").Replace("\r", "").Contains(Statement).ToString());
        }


    }

    public class IEMessageDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnYes")]
        public IWebElement IEAlertYesBtn { get; set; }

        [FindsBy(How = How.Id, Using = "btnNo")]
        public IWebElement IEAlertNoBtn { get; set; }

        [FindsBy(How = How.Id, Using = "spnMessage")]
        public IWebElement IEAlertMessage { get; set; }

        #endregion

    }
    public class ClosingDisclosureEventsLog : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlCDEventType")]
        public IWebElement CDEventsCategory { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDEventsLenderComments")]
        public IWebElement LenderCommentsBtn { get; set; }

        // maybe use xpath to get table with header columns: "//table[@id='tblClosingDisclosureEvents'/ancesor::table[1]"
        [FindsBy(How = How.Id, Using = "tblClosingDisclosureEvents")]
        public IWebElement EventTable { get; set; }
        //



        public ClosingDisclosureEventsLog WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? EventTable);

            return this;
        }

        #endregion
        public ClosingDisclosureEventsLog WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame(true);
            this.WaitCreation(this.CDEventsCategory);
            return this;
        }
        //
        public void CloseCDEventsDlg()
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            IWebElement button = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//button[contains(@title,'close')]");
            button.FAClick();
        }
        public bool ValidateEvent(string EventName)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Validate event " + EventName;
            string Status = "";
            if (FastDriver.ClosingDisclosureEventsLog.EventTable.FAGetText().Contains(EventName))
            {
                Status = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, "Event", TableAction.Click).Status.ToString();
                if (Status.Equals("Success"))
                {
                    return true;
                }
            }

                return false;
        }
        //
        public bool ValidateStartDateForEvent(string EventName, DateTime ExpectedStartDate)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Validate start date for event " + EventName;
            string ActualStartDate = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, @"Start Date/Time", TableAction.GetText).Message.Trim();
            DateTime StartDate;
            bool isConverted = DateTime.TryParse(ActualStartDate.Substring(0,19), out StartDate);
            if (isConverted)
            {
                double diff = ExpectedStartDate.Subtract(StartDate).TotalSeconds;
                if (Math.Abs(diff) <= 90)
                    return true;
            }       
                return false;
        }
        //
        public bool ValidateCompletionDateForEvent(string EventName, DateTime ExpectedCompletionDate)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Validate completion date for event " + EventName;
            //string ActualCompletionDate = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, @"Completion Date/Time", TableAction.GetText).Message.Trim();
          // ActualCompletionDate= Convert.ToDateTime(ActualCompletionDate.Replace("PST"," ").Trim()).Date.ToDateString();
           string ActualCompletionDate = GetCompletionDateTime(EventName);
            DateTime CompletionDate;
            if (!string.IsNullOrEmpty(ActualCompletionDate.Trim()))
            {

                bool isConverted = DateTime.TryParse(ActualCompletionDate.Substring(0, 19), out CompletionDate);
                if (isConverted)
                {
                    double diff = ExpectedCompletionDate.Subtract(CompletionDate).TotalSeconds;
                    if (Math.Abs(diff) <= 90)
                        return true;
                }
            }
           return false;
        }
        //
        private string GetCompletionDateTime(string EventName)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Get completion date for event " + EventName;
            // ActualCompletionDate= Convert.ToDateTime(ActualCompletionDate.Replace("PST"," ").Trim()).Date.ToDateString();
            for (int i = 0; i < 7; i++)
            {
                string ActualCompletionDate = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, @"Completion Date/Time", TableAction.GetText).Message.Trim();
                if (string.IsNullOrEmpty(ActualCompletionDate.Trim()))
                {
                    Thread.Sleep(7000);
                    FastDriver.ClosingDisclosureEventsLog.CloseCDEventsDlg();
                    FastDriver.ClosingDisclosure.OpenClosingDisclosureEventsLog();
                }
                else
                    return ActualCompletionDate;
            }
            return string.Empty;
        }
        //
        public bool ValidateSourceForEvent(string EventName, string ExpectedSource)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Validate Source for event " + EventName;
            string ActualSource = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, "Source", TableAction.GetText).Message.Trim();
            if (ActualSource.Equals(ExpectedSource))
            {
                return true;
            }
            else
                return false;
        }
        //
        public bool ValidateUserNameForEvent(string EventName, string ExpectedUserName)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Validate UserName for event " + EventName;
            string ActualUserName = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, "User", TableAction.GetText).Message.Trim();
            if (ActualUserName.Equals(ExpectedUserName))
            {
                return true;
            }
            else
                return false;
        }
        //
        public string GetCommentForEvent(string EventName)
        {
            this.WaitForScreenToLoad();
            Reports.TestStep = "Get Comment for event " + EventName;
            string Comment = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, "Comments", TableAction.GetText).Message.Trim();
            return Comment;
        }
        //
        public bool ValidatePDFIconForLenderUpdateReceived(string EventName)
        {
            try
            {
                this.WaitForScreenToLoad();
                IWebElement PDFIcon = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, "Event", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG");
                if (PDFIcon.IsDisplayed())
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return false;
            }
        }
        //
        public bool OpenPDF(string EventName)
        {
            this.WaitForScreenToLoad();
            IWebElement PDFIcon = FastDriver.ClosingDisclosureEventsLog.EventTable.PerformTableAction("Event", EventName, "Event", TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG");
            if (PDFIcon.IsDisplayed())
            {
                PDFIcon.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                return true;
            }
            else
                return false;
        }

       

    }

    public class LenderCommentsPopup : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "spanGenericComments")]
        public IWebElement GenericCommentsTxt { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='HeadingCDNote']")]
        public IWebElement NoLenderCommentsMsg { get; set; }


        [FindsBy(How = How.Id, Using = "spanChargeOrFeeComments")]
        public IWebElement ChargeOrFeeCommentsTxt { get; set; }

        [FindsBy(How = How.Id, Using = "btnLenderCommentsDone")]
        public IWebElement Done { get; set; }

        public LenderCommentsPopup WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? Done);

            return this;
        }





        #endregion

    }

    public class CDLenderReviewPopUp : PageObject
    {
        #region WebElements


        [FindsBy(How = How.XPath, Using = "//input[@type='radio' and @value='2']")]
        public IWebElement PendingReviewAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        public CDLenderReviewPopUp WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? PendingReviewAll);

            return this;
        }





        #endregion

    }

    public class OtherCDUpdatesReview : PageObject
    {
        [FindsBy(How = How.Id, Using = "HdnUnMappedFields")]
        private IWebElement AddlLenderUpdatesDialog;

        #region WebElements

        [FindsBy(How = How.Id, Using = "btnReviewInfoDone")]
        public IWebElement Reviewed { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleTransactionInformation")]
        public IWebElement TransactionInformation { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleCostsAtClosing")]
        public IWebElement CostsatClosing { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleLoanCosts")]
        public IWebElement LoanCosts { get; set; }

        [FindsBy(How = How.Id, Using = "lblCalculateCashToClose")]
        public IWebElement CalculatingCashToClose { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecTitleContInfo")]
        public IWebElement ContactInformation { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherCDCommentsLabel")]
        public IWebElement LenderCommentsLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='lblOtherCDComments']/table")]
        public IWebElement LenderCommentsTxtBoxTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtOtherCDUpdateCommentsToLender")]
        public IWebElement CommentsToLenderTxtBox { get; set; }

        #endregion
        public OtherCDUpdatesReview WaitForScreenToLoad()
        {

            WebDriver.WaitForWindowAndSwitch("Add'l Lender Updates", true, 10);
            WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(Reviewed);

            return this;
        }

        //public OtherCDUpdatesReview WaitForScreenToLoad(IWebElement element = null)
        //{

        //    FastDriver.WebDriver.SwitchTo().DefaultContent();
        //    this.WaitCreation(element ?? Reviewed);

        //    return this;
        //}

    }

    public struct CDLoanInformation
    {
        public int Years;
        public int Months;
        public string ProductType;
        public string ProductComment;
        public bool IsConventional;
        public string Type;
        public string LenderID;
        public string MICNumber;
    }

    public struct CDLoanTerms
    {
        public bool IsLoanAmountIncreasedAfterClosing;
        public string LoanAmountCondition;
        public decimal LoanAmountAsHighAs;
        public int? LoanAmountIncreasedUntilYear;
        public decimal InterestRate;
        public bool IsInterestRateIncreasedAfterClosing;
        public int? InterestRateAdjustsEveryYears;
        public int InterestRateAdjustsStartingInYear;
        public decimal? InterestRateCanGoAsHighAs;
        public int InterestRateCanGoAsHighAsInYear;
        public decimal MonthlyPayment;
        public bool IsMonthlyPaymentIncreasedAfterClosing;
        public int? MonthlyPaymentAdjustsEveryYears;
        public int MonthlyPaymentAdjustsStartingInYear;
        public decimal? MonthlyPaymentCanGoAsHighAs;
        public int MonthlyPaymentCanGoAsHighAsInYear;
        public int? MonthlyPaymentOnlyInterestUntilYear;
        public bool HasPrepaymentPenalty;
        public decimal? PrepaymentPenaltyGoesAsHighAs;
        public int PrepaymentPenaltyGoesAsHighAsIfPaidDuringFirstYears;
        public bool HasBalloonPayment;
        public decimal? BalloonPaymentAtTheEndOfLoanTerm;
    }

    public struct CDProjectedPayments
    {
        public struct PaymentCalculation
        {
            public int StartYear;
            public int EndYear;
            public decimal? PrincipalAndInterest;
            public int? Maximum;
            public int? Minimum;
            public decimal? Interest;
            public decimal MortgageInsurance;
            public decimal EstimatedEscrow;
        }
        public PaymentCalculation[] PaymentCalculations;
        public decimal EstimatedTaxesInsuranceAndAssesments;
        public bool PropertyTaxes;
        public bool HomeownerInsurance;
        public string PropertyTaxesInEscrow;
        public string HomeownerInsuranceInEscrow;
        public struct AdditionalEstimatedPropertyCost
        {
            public int ID;
            public bool ShowOnForm;
            public bool Included;
            public bool InEscrow;
            public string Other;
        }
        public AdditionalEstimatedPropertyCost[] AdditionalEstimatedPropertyCosts;
    }
}
