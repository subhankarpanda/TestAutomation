﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.ObjectModel;
using System.Globalization;

namespace FASTSelenium.PageObjects
{
    public class ClosingDisclosureGFV : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "tblZeroPerVariance")]
        public IWebElement TableZeroPerVariance { get; set; }
        [FindsBy(How = How.Id, Using = "tblTenPerVariance")]
        public IWebElement TableTenPerVariance { get; set; }
        #endregion

        #region VERIFY AMOUNT AND DESCRIPTION FOR 0% CATEGORY

        public void VerifyAmountForCategory(string TableID, int LineNumber, ClosingDisclosureSection Section, int lineno, string ChargeDescription, double? LoanEstimateRounded, double? FinalBorrowerPaid, double? LoanEstimateUnRounded, bool PartOf = false)
        {
            try
            {
                int filterrowcount = 0;
                string linedisplay = string.Format("{0:00}", lineno.ToString("00"));
                ReadOnlyCollection<IWebElement> tableRowsCollection = null;
                ReadOnlyCollection<IWebElement> tableTenRowsCollection = null;
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.VarianceTab.Click();

                WaitForVarianceTabToLoad();

                try
                {
                    this.WaitCreation(FastDriver.ClosingDisclosureGFV.TableZeroPerVariance);
                    tableRowsCollection = FastDriver.ClosingDisclosureGFV.TableZeroPerVariance.FindElements(By.CssSelector("tr"));
                }
                catch (NoSuchElementException) { }


                try
                {
                    this.WaitCreation(FastDriver.ClosingDisclosureGFV.TableZeroPerVariance);
                    tableTenRowsCollection = FastDriver.ClosingDisclosureGFV.TableTenPerVariance.FindElements(By.CssSelector("tr"));
                }
                catch (NoSuchElementException) { }
                  
                

        

                //if(TableID.Equals("tblZeroPerVariance") && FastDriver.ClosingDisclosureGFV.TableZeroPerVariance.Displayed)
                if (TableID.Equals("tblZeroPerVariance"))
                {
                    #region TableZeroPerVariance

                    #region CheckTableStatus
                    try
                    {
                        if (tableRowsCollection.Count != 0)
                        {
                            filterrowcount = tableRowsCollection.Count;
                        }
                        else
                            throw new Exception();
                    }
                    catch (System.Exception)
                    {
                        if (LineNumber == 0)
                        {
                            Support.AreEqual("true", "true", TableID + "Table does not exist as there are no charges");
                        }
                        else
                        {
                            Support.AreEqual("true", "false", TableID + "Table does not exist even if charges are available");
                        }
                        return;
                    }
                    #endregion
                    if (LineNumber == 0)
                    {
                        #region CheckDescription
                        int flage = 0;
                        for (int i = 0; i < filterrowcount; i++)
                        {
                            var table = tableRowsCollection[0].FindElements(By.CssSelector("td"));
                            string verifydescription = table[0].Text.ToString();
                            if (verifydescription.Contains(ChargeDescription))
                            {
                                flage = 1;
                                break;
                            }
                        }
                        if (flage == 1)
                        {
                            Support.AreEqual(ChargeDescription, "does exist under Good Faith Analysis 10% Category", bIgnoreCase: false);
                        }
                        else
                        {
                            Support.AreEqual(ChargeDescription, "does exist under Good Faith Analysis 10% Category", bIgnoreCase: false);
                        }
                        #endregion
                    }
                    else
                    {
                        #region CheckOtherColumns
                        filterrowcount = tableRowsCollection.Count;
                        for (int i = LineNumber; i <= LineNumber; i++)
                        {
                            int l = i - 1;
                            var table = tableRowsCollection[l].FindElements(By.CssSelector("td"));
                            string verifydescription = table[0].Text.ToString();
                            #region CheckSections
                            if (Section == ClosingDisclosureSection.A)
                            {
                                string ActualDescription = "A " + linedisplay + " " + ChargeDescription;
                                Support.AreEqual(ActualDescription.Trim(), verifydescription.Trim());
                            }
                            if (Section == ClosingDisclosureSection.B)
                            {
                                string ActualDescription = "B " + linedisplay + " " + ChargeDescription;
                                Support.AreEqual(ActualDescription.Trim(), verifydescription.Trim());
                            }
                            #endregion
                            #region CheckAmounts
                            if (i == LineNumber)
                            {
                                string LoanEstimate_Rounded = table[1].Text.ToString();
                                Reports.TestStep = "Verify if amount is displayed in Loan Estimate Rounded Column";
                                if (LoanEstimateRounded == 0.0 && LoanEstimate_Rounded.Trim().Equals("$0"))
                                {
                                    if (PartOf == true)
                                    {
                                        Support.AreEqual("Part of $" + LoanEstimateRounded.ToString().Trim(), LoanEstimate_Rounded.Trim());
                                    }
                                    else
                                    {
                                        Support.AreEqual("$" + LoanEstimateRounded.ToString().Trim(), LoanEstimate_Rounded.Trim());
                                    }
                                }
                                string s = FormattedAmount(Convert.ToDecimal(LoanEstimateRounded.Value));
                                if (s.Length >= 3)
                                {
                                    s = s.Substring(0, s.Length - 3);
                                    if (PartOf == true)
                                        s = "Part of " + s; 
                                    Support.AreEqual(s.Trim(), LoanEstimate_Rounded.Trim());
                                }
                                string Final_BorrowerPaid = table[2].Text.ToString();
                                Reports.TestStep = "Verify if amount is displayed in Final Borrower Paid Column";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(FinalBorrowerPaid.Value))).Trim(), Final_BorrowerPaid.Trim());

                                string LoanEstimate_UnRounded = table[3].Text.ToString();
                                Reports.TestStep = "Verify if amount is displayed in Loan Estimate Unrounded Column";
                                if (LoanEstimateUnRounded == 0.0 && LoanEstimate_UnRounded.Trim().Equals("$0.00"))
                                {
                                    Reports.TestStep = "Verify if amount is displayed in Final Borrower Paid Column";
                                    Support.AreEqual("$" + LoanEstimateUnRounded + ".00".ToString().Trim(), LoanEstimate_UnRounded.Trim());
                                }
                                else
                                {
                                    Reports.TestStep = "Verify if amount is displayed in Final Borrower Paid Column";
                                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateUnRounded.Value))).Trim(), LoanEstimate_UnRounded.Trim());
                                }
                                double? AmountsExceeding = FinalBorrowerPaid - LoanEstimateUnRounded;
                                if (AmountsExceeding > 0)
                                {
                                    string Amounts_Exceeding = table[4].Text.ToString();
                                    Reports.TestStep = "Verify if amount is displayed in Amounts Exceeding 0% Good Faith Limit Column";
                                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(AmountsExceeding.Value))).Trim(), Amounts_Exceeding.Trim());
                                }
                                else
                                {
                                    string Amounts_Exceeding = table[4].Text.ToString();
                                    Reports.TestStep = "Verify if amount is displayed in Amounts Exceeding 0% Good Faith Limit Column";
                                    Reports.StatusUpdate("Difference of Final Amount and Loan Estimate Amount is=" + AmountsExceeding, true);
                                    Support.AreEqual("$0.00", Amounts_Exceeding.Trim());
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    #endregion
                }
                else
                {
                    #region TableTenPerVariance
                    #region CheckTableStatus
                    try
                    {
                        if (tableTenRowsCollection.Count != 0)
                        {
                            filterrowcount = tableTenRowsCollection.Count;
                        }
                        else
                            throw new Exception();
                    }
                    catch (System.Exception)
                    {
                        if (LineNumber == 0)
                        {
                            Support.AreEqual("true", "true", TableID + "Table does not exist as there are no charges");
                        }
                        else
                        {
                            Support.AreEqual("true", "false", TableID + "Table does not exist even if charges are available");
                        }
                        return;
                    }
                    #endregion
                    if (LineNumber == 0)
                    {
                        #region CheckDescription
                        int flage = 0;
                        for (int i = 0; i < filterrowcount; i++)
                        {
                            var table = tableTenRowsCollection[0].FindElements(By.CssSelector("td"));
                            string verifydescription = table[0].Text.ToString();
                            if (verifydescription.Contains(ChargeDescription))
                            {
                                flage = 1;
                                break;
                            }
                        }

                        if (flage == 1)
                        {
                            Support.AreEqual(ChargeDescription, "does exist under Good Faith Analysis 10% Category", bIgnoreCase: false);
                        }
                        else
                        {
                            Support.AreEqual(ChargeDescription, "does not exist under Good Faith Analysis 10% Category", bIgnoreCase: true);
                        }
                        #endregion
                    }

                    else
                    {
                        #region CheckOtherColumns
                        filterrowcount = tableRowsCollection.Count;
                        for (int i = LineNumber; i <= LineNumber; i++)
                        {
                            int l = i - 1;
                            var table = tableTenRowsCollection[l].FindElements(By.CssSelector("td"));
                            string verifydescription = table[0].Text.ToString();
                            #region CheckSections
                            if (Section == ClosingDisclosureSection.A)
                            {
                                string ActualDescription = "A " + linedisplay + " " + ChargeDescription;
                                Reports.TestStep = "Verify the Section and Line Number along with descriptions";
                                Support.AreEqual(ActualDescription.Trim(), verifydescription.Trim());
                            }

                            if (Section == ClosingDisclosureSection.B)
                            {

                                string ActualDescription = "B " + linedisplay + " " + ChargeDescription;
                                Reports.TestStep = "Verify the Section and Line Number along with descriptions";
                                Support.AreEqual(ActualDescription.Trim(), verifydescription.Trim());
                            }

                            if (Section == ClosingDisclosureSection.C)
                            {
                                string ActualDescription = "C " + linedisplay + " " + ChargeDescription;
                                Reports.TestStep = "Verify the Section and Line Number along with descriptions";
                                Support.AreEqual(ActualDescription.Trim(), verifydescription.Trim());
                            }
                            #endregion
                            #region CheckAmounts
                            if (i == LineNumber)
                            {
                                string LoanEstimate_Rounded = table[1].Text.ToString();
                                Reports.TestStep = "Verify if amount is displayed in Loan Estimate Rounded Column";
                                if (LoanEstimateRounded == 0.0 && LoanEstimate_Rounded.Trim().Equals("$0"))
                                {
                                    if(PartOf)
                                    {
                                        Support.AreEqual("Part of $" + LoanEstimateRounded.ToString().Trim(), LoanEstimate_Rounded.Trim());
                                    }
                                    else
                                    {
                                        Support.AreEqual("$" + LoanEstimateRounded.ToString().Trim(), LoanEstimate_Rounded.Trim());
                                    }                                    
                                }
                                string s = FormattedAmount(Convert.ToDecimal(LoanEstimateRounded.Value));
                                if (s.Length >= 3)
                                {
                                    s = s.Substring(0, s.Length - 3);
                                    if (PartOf == true)
                                        s = "Part of " + s; 
                                    Support.AreEqual(s.Trim(), LoanEstimate_Rounded.Trim());
                                }
                                string LoanEstimate_UnRounded = table[2].Text.ToString();
                                Reports.TestStep = "Verify if amount is displayed in Loan Estimate Unrounded Column";
                                if (LoanEstimateUnRounded == 0.0 && LoanEstimate_UnRounded.Trim().Equals("$0.00"))
                                {
                                    Support.AreEqual("$" + LoanEstimateUnRounded + ".00".ToString().Trim(), LoanEstimate_UnRounded.Trim());
                                }
                                else
                                {
                                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateUnRounded.Value))).Trim(), LoanEstimate_UnRounded.Trim());
                                }
                                if (FinalBorrowerPaid > 0)
                                {
                                    string LoanEstimateIncludedAmounts = table[3].Text.ToString();
                                    Reports.TestStep = "Verify if amount is displayed in Loan Estimate  Included Amounts (1) Column";
                                    if (LoanEstimateIncludedAmounts.Trim().Equals("$0.00"))
                                    {
                                        Support.AreEqual("$" + LoanEstimateUnRounded + ".00", LoanEstimateIncludedAmounts.Trim());
                                    }
                                    else
                                    {
                                        Support.AreEqual((FormattedAmount(Convert.ToDecimal(LoanEstimateUnRounded.Value))).Trim(), LoanEstimateIncludedAmounts.Trim());
                                    }
                                }

                                else
                                {
                                    string LoanEstimateIncludedAmounts = table[3].Text.ToString();
                                    Reports.TestStep = "Verify if amount is displayed in Loan Estimate  Included Amounts (1) Column";
                                    Support.AreEqual("$" + FinalBorrowerPaid.Value + ".00", LoanEstimateIncludedAmounts.Trim());
                                }
                                string Final_BorrowerPaid = table[4].Text.ToString();
                                Reports.TestStep = "Verify if amount is displayed in Final Borrower Paid Column";

                                if (FinalBorrowerPaid == 0.0 && Final_BorrowerPaid.Trim().Equals("$0.00"))
                                {
                                    Support.AreEqual("$" + FinalBorrowerPaid + ".00".ToString().Trim(), Final_BorrowerPaid.Trim());
                                }
                                else
                                {
                                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(FinalBorrowerPaid.Value))).Trim(), Final_BorrowerPaid.Trim());
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                    #endregion
                }
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for GFV Screen", "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }

        #endregion

        #region VERIFY AGGREGATE AMOUNT FOR 0%  AND 10% CATEGORY

        public void VerifyAggregateAmountForGFV(string TableID, double? AggregateAmountsExceeding, double? AggregateLoanEstimate, double? AggregateFinal, double? TenPercentofAggregateLoanEstimate, double? differenceofFinalandLoanEstimate, double? Costabovetenpercent, double? Costabovetotalzeroandtenpercent)
        {
            try
            {
                int filterrowcount = 0;
                int flage = 0;
                ReadOnlyCollection<IWebElement> tableRowsCollection = null;
                ReadOnlyCollection<IWebElement> tableTenRowsCollection = null;
                //string linedisplay = string.Format("{0:00}", lineno.ToString("00"));
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>(@"Home>Order Entry>Escrow Closing>Closing Disclosure");
                FastDriver.ClosingDisclosure.SwitchToContentFrame();
                FastDriver.ClosingDisclosure.VarianceTab.Click();
                WaitForVarianceTabToLoad();
                try
                {
                    this.WaitCreation(FastDriver.ClosingDisclosureGFV.TableZeroPerVariance);
                    tableRowsCollection = FastDriver.ClosingDisclosureGFV.TableZeroPerVariance.FindElements(By.CssSelector("tr"));
                }
                catch (NoSuchElementException) { }


                try
                {
                    this.WaitCreation(FastDriver.ClosingDisclosureGFV.TableZeroPerVariance);
                    tableTenRowsCollection = FastDriver.ClosingDisclosureGFV.TableTenPerVariance.FindElements(By.CssSelector("tr"));
                }
                catch (NoSuchElementException) { }
                if (TableID.Equals("tblZeroPerVariance"))
                {
                    #region TABLE ZERO PER VARIANCE
                    try
                    {
                        var table = tableRowsCollection[0].FindElements(By.CssSelector("td"));
                        filterrowcount = table.Count;                            
                        for (int i = 0; i < filterrowcount; i++)
                        {
                            string verifydescription = table[i].Text.ToString();
                            if (verifydescription.Contains("Increase in Closing Costs above legal limits - 0% Category"))
                            {
                                //string Aggregate_Amounts_Exceeding = SectionSelect.Rows[i].GetChildren()[1].GetProperty("InnerText").ToString();
                                string Aggregate_Amounts_Exceeding = table[i].Text.ToString();// FIX THIS!!!
                                Reports.TestStep = "Verify the Aggregate of 0% Category";

                                Support.AreEqual("true", "true", "" + "Increase in Closing Costs above legal limits - 0% Category:" + Aggregate_Amounts_Exceeding);
                                if (AggregateAmountsExceeding == 0)
                                {
                                    string AggregateAmountsExceeding_Zero = "$0.00";
                                    Support.AreEqual(AggregateAmountsExceeding_Zero, Aggregate_Amounts_Exceeding.Trim());
                                    flage = 1;
                                    break;
                                }
                                else
                                {
                                    Support.AreEqual((FormattedAmount(Convert.ToDecimal(AggregateAmountsExceeding.Value))).Trim(), Aggregate_Amounts_Exceeding.Trim());
                                    flage = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (flage == 0)
                        {
                            Reports.StatusUpdate("Increase in Closing Costs above legal limits - 0% Category doesn't exist under 0% category", true);
                        }
                    }
                    catch (Exception e)
                    {
                        Reports.UpdateDebugLog(e.Message + " for " + TableID, "", "", "", "", "", Reports.Result(false), e.Message);
                        Reports.TestResult = false;
                    }
                    #endregion
                }
                if(TableID.Equals("tblTenPerVariance"))
                {
                    #region TABLE TEN PER VARIANCE
                    var table = tableTenRowsCollection;
                    filterrowcount = table.Count;
                    for (int i = 0; i < filterrowcount; i++)
                    {
                        string verifydescription = table[i].Text.ToString();
                        //Description[0]
                        //Loan Estimate included Amounts[1]
                        //Final (Borrower Paid)[2]
                        #region TOTAL AGGREGATE FEES
                        if (verifydescription.Contains("Total Aggregate Fees"))
                        {
                            string Runtime_AggregateLoanEstimate = (table[i].Text.ToString().Split('$'))[1];
                            Reports.TestStep = "Verify the Aggregate of 10% Category";
                            if (AggregateLoanEstimate == 0.0 && AggregateFinal == 0)
                            {
                                string AggregateLoanEstimatezero = "$0.00";
                                string AggregateFinalzero = "$0.00";
                                Support.AreEqual(AggregateLoanEstimatezero, "$" + Runtime_AggregateLoanEstimate.Trim());
                                string Runtime_AggregateFinal = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual(AggregateFinalzero, "$" + Runtime_AggregateFinal.Trim());
                                Support.AreEqual("true", "true", "" + "Total Aggregate Fees For Final (Borrower Paid) is:" + Runtime_AggregateFinal);
                                break;
                            }
                            if (AggregateLoanEstimate == 0.0 && AggregateFinal != 0)
                            {
                                string AggregateLoanEstimatezero = "$0.00";
                                Support.AreEqual(AggregateLoanEstimatezero, "$" + Runtime_AggregateLoanEstimate.Trim());
                                string Runtime_AggregateFinal = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(AggregateFinal.Value))).Trim(), "$" + Runtime_AggregateFinal.Trim());
                                Support.AreEqual("true", "true", "" + "Total Aggregate Fees For Final (Borrower Paid) is:" + Runtime_AggregateFinal);
                                break;
                            }
                            else
                            {
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(AggregateLoanEstimate.Value))).Trim(), "$" + Runtime_AggregateLoanEstimate.Trim());
                                string Runtime_AggregateFinal = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(AggregateFinal.Value))).Trim(), "$" + Runtime_AggregateFinal.Trim());
                                Support.AreEqual("true", "true", "" + "Total Aggregate Fees For Final (Borrower Paid) is:" + Runtime_AggregateFinal);
                                break;
                            }
                        }
                        #endregion
                    }
                    for (int i = 0; i <= filterrowcount; i++)
                    {
                        #region Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate
                        string verifydescription = table[i].Text.ToString();
                        if (verifydescription.Contains("Comparison of Loan Estimate 10% to Final Amount Exceeding Loan Estimate"))
                        {
                            if (TenPercentofAggregateLoanEstimate == 0 && differenceofFinalandLoanEstimate == 0)
                            {
                                string TenPercentofAggregateLoanEstimatezero, differenceofFinalandLoanEstimatezero;
                                TenPercentofAggregateLoanEstimatezero = "$0.00";
                                differenceofFinalandLoanEstimatezero = "$0.00";
                                string Runtime_TenPercentofAggregateLoanEstimate = (table[i].Text.ToString().Split('$'))[1];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual(TenPercentofAggregateLoanEstimatezero, "$" + Runtime_TenPercentofAggregateLoanEstimate.Trim());
                                string Runtime_differenceofFinalandLoanEstimate = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the differences of Total Final and Total Loan Estimate";
                                Support.AreEqual(differenceofFinalandLoanEstimatezero, "$" + Runtime_differenceofFinalandLoanEstimate.Trim());
                                break;
                            }
                            if (TenPercentofAggregateLoanEstimate == 0 && differenceofFinalandLoanEstimate != 0)
                            {
                                string TenPercentofAggregateLoanEstimatezero = "$0.00";
                                string Runtime_TenPercentofAggregateLoanEstimate = (table[i].Text.ToString().Split('$'))[1];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual(TenPercentofAggregateLoanEstimatezero, "$" + Runtime_TenPercentofAggregateLoanEstimate.Trim());
                                string Runtime_differenceofFinalandLoanEstimate = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the differences of Total Final and Total Loan Estimate";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(differenceofFinalandLoanEstimate.Value))).Trim(), "$" + Runtime_differenceofFinalandLoanEstimate.Trim());
                                break;
                            }
                            if (TenPercentofAggregateLoanEstimate != 0 && differenceofFinalandLoanEstimate == 0)
                            {
                                string differenceofFinalandLoanEstimatezero = "$0.00";
                                string Runtime_TenPercentofAggregateLoanEstimate = (table[i].Text.ToString().Split('$'))[1];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(TenPercentofAggregateLoanEstimate.Value))).Trim(), "$" + Runtime_TenPercentofAggregateLoanEstimate.Trim());
                                string Runtime_differenceofFinalandLoanEstimate = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the differences of Total Final and Total Loan Estimate";
                                Support.AreEqual(differenceofFinalandLoanEstimatezero, "$" + Runtime_differenceofFinalandLoanEstimate.Trim());
                                break;
                            }
                            if (TenPercentofAggregateLoanEstimate != 0 && differenceofFinalandLoanEstimate != 0)
                            {
                                string Runtime_TenPercentofAggregateLoanEstimate = (table[i].Text.ToString().Split('$'))[1];
                                Reports.TestStep = "Verify the Aggregate of 10% Category";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(TenPercentofAggregateLoanEstimate.Value))).Trim(), "$" + Runtime_TenPercentofAggregateLoanEstimate.Trim());
                                string Runtime_differenceofFinalandLoanEstimate = (table[i].Text.ToString().Split('$'))[2];
                                Reports.TestStep = "Verify the differences of Total Final and Total Loan Estimate";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(differenceofFinalandLoanEstimate.Value))).Trim(), "$" + Runtime_differenceofFinalandLoanEstimate.Trim());
                                break;
                            }
                        }
                        #endregion
                    }
                    for (int i = 0; i <= filterrowcount; i++)
                    {
                        #region Increase in Closing Costs above legal limits - 10% Category
                        string verifydescription = table[i].Text.ToString();
                        if (verifydescription.Contains("Increase in Closing Costs above legal limits - 10% Category"))
                        {
                            if (Costabovetenpercent == 0)
                            {
                                string Costabovetenpercentzero = "$0.00";
                                string Runtime_Costabovetenpercent = (table[i].Text.ToString().Split('$'))[1];
                                Reports.TestStep = "Verify Increase in Closing Costs above Legal Limits – 10% Category";
                                Support.AreEqual(Costabovetenpercentzero, "$" + Runtime_Costabovetenpercent.Trim());
                                break;
                            }
                            else
                            {
                                string Runtime_Costabovetenpercent = (table[i].Text.ToString().Split('$'))[1];
                                Reports.TestStep = "Verify Increase in Closing Costs above Legal Limits – 10% Category";
                                Support.AreEqual((FormattedAmount(Convert.ToDecimal(Costabovetenpercent.Value))).Trim(), "$" + Runtime_Costabovetenpercent.Trim());
                                break;
                            }
                        }
                        #endregion
                    }
                    #endregion
                }
                if (TableID.Equals("tblCategoryTotal"))
                {
                    #region TABLE CATEGORY TOTAL
                    var table = tableRowsCollection[0].FindElements(By.CssSelector("td"));// fix this!!!
                    filterrowcount = table.Count;                            
                    
                    for (int i = 0; i < filterrowcount; i++)
                    {
                        string verifydescription = table[i].Text.ToString();
                        if (verifydescription.Trim().Contains("Increase in Closing Costs above legal limits - Total 0% and 10% Category"))
                        {
                            string Runtime_Costabovetotalzeroandtenpercent = (table[i].Text.ToString().Split('$'))[1];
                            Reports.TestStep = "Verify Increase in Closing Costs above legal limits - Total 0% and 10% Category";
                            Support.AreEqual((FormattedAmount(Convert.ToDecimal(Costabovetotalzeroandtenpercent.Value))).Trim(), "$" + Runtime_Costabovetotalzeroandtenpercent.Trim());
                            flage = 1;
                            break;
                        }
                    }
                    #endregion
                }
                if (flage == 0)
                {
                    Reports.StatusUpdate("Increase in Closing Costs above legal limits - Total 0% and 10% Category doesn't exist", true);
                }
            }
            catch (Exception e)
            {
                Reports.UpdateDebugLog(e.Message + " for GFV", "", "", "", "", "", Reports.Result(false), e.Message);
                Reports.TestResult = false;
            }
        }
        #endregion

        #region Format
        public string CurrencyFormat
        {
            get
            {
                return "C";
            }
        }
        public string CurrencyFormatWithoutDecimal
        {
            get
            {
                return "C0";
            }
        }
        public string CurrencyFormatWithoutDollarSign
        {
            get
            {
                return "#,##0.00";
            }
        }
        public string FormattedAmount(decimal amount, bool returnZeroWhenEmptyString = false, bool withDollarSign = true)
        {
            string formattedAmt = string.Empty;
            string currFormat = string.Empty;
            if (withDollarSign)
                currFormat = CurrencyFormat;
            else
                currFormat = CurrencyFormatWithoutDollarSign;
            if (amount < 0)
            {
                var culture = CultureInfo.CurrentCulture;
                var mutableNfi = (NumberFormatInfo)culture.NumberFormat.Clone();
                mutableNfi.CurrencyNegativePattern = 1;
                formattedAmt = amount != 0 ? (amount % 1000000000).ToString(currFormat, mutableNfi) : string.Empty;
            }
            else
                formattedAmt = amount != 0 ? (amount % 1000000000).ToString(currFormat) : string.Empty;

            return (returnZeroWhenEmptyString && string.IsNullOrWhiteSpace(formattedAmt)) ? 0.ToString(CurrencyFormatWithoutDecimal) : formattedAmt;
        }
        #endregion

        public void WaitForVarianceTabToLoad(){
            
            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                bool pageDisplayed = false;
                try
                {
                    this.SwitchToContentFrame();
                    try
                    {
                        pageDisplayed = WebDriver.FindElement(By.Id("tblTenPerVariance")).Displayed;
                    }
                    catch (NoSuchElementException) { };

                    try {
                        pageDisplayed = WebDriver.FindElement(By.Id("tblZeroPerVariance")).Displayed;
                    }
                    catch (NoSuchElementException){};

                    return pageDisplayed; 
                    
                }
                catch (WebDriverTimeoutException)
                {
                    return pageDisplayed;
                }
               

            });
            
        }
    }
}