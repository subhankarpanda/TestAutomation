using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ClosingProtectionLetter : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkMissouri")]
		public IWebElement UseMissouriLetter { get; set; }

		[FindsBy(How = How.Id, Using = "ddlCplTypes")]
		public IWebElement LetterType { get; set; }

		[FindsBy(How = How.Id, Using = "ddlUnderWriters")]
		public IWebElement UnderWriters { get; set; }

		[FindsBy(How = How.Id, Using = "ddlAgentClosingAttorneys")]
		public IWebElement AgentClosingAttorney { get; set; }

		[FindsBy(How = How.Id, Using = "ddlMyClosingAttorneys")]
		public IWebElement MyClosingAttorney { get; set; }

		[FindsBy(How = How.Id, Using = "ddlAgentOffices")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "ddlApprovedAttorneys")]
		public IWebElement ApprovedAttorney { get; set; }

        [FindsBy(How = How.Id, Using = "ddlAgentFirms")]
        public IWebElement Firms { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
		public IWebElement Buyer { get; set; }

		[FindsBy(How = How.Id, Using = "chkBuyerBorrower")]
		public IWebElement BuyerBorrower { get; set; }

		[FindsBy(How = How.Id, Using = "chkBorrower")]
		public IWebElement Borrower { get; set; }

		[FindsBy(How = How.Id, Using = "chkSeller")]
		public IWebElement Seller { get; set; }

		[FindsBy(How = How.Id, Using = "chkLender")]
		public IWebElement Lender { get; set; }

		[FindsBy(How = How.Id, Using = "dtClosing")]
		public IWebElement ClosingDate { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine1")]
		public IWebElement PropertyAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine2")]
		public IWebElement PropertyAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine3")]
		public IWebElement PropertyAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddrLine4")]
		public IWebElement PropertyAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "txtCity")]
		public IWebElement PropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "cboState")]
		public IWebElement PropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "txtZip")]
		public IWebElement PropertyZip { get; set; }

		[FindsBy(How = How.Id, Using = "txtCounty")]
		public IWebElement PropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "cboCountry")]
		public IWebElement PropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBuyerSummary_0_chkBuyer")]
		public IWebElement BuyerSummary { get; set; }

        [FindsBy(How = How.Id, Using = "dgridBuyerSummary")]
        public IWebElement BuyerSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSellerSummary_0_chkSeller")]
		public IWebElement SellerSummary { get; set; }

		[FindsBy(How = How.Id, Using = "btnSubmitCPLRequest")]
		public IWebElement SubmitCPLRequest { get; set; }

		[FindsBy(How = How.Id, Using = "txtContact")]
		public IWebElement LenderDetailsContact { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddress")]
		public IWebElement LenderDetailsAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddress2")]
		public IWebElement LenderDetailsAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtLenderCity")]
		public IWebElement LenderDetailsCity { get; set; }

		[FindsBy(How = How.Id, Using = "ddlLenderState")]
		public IWebElement LenderDetailsState { get; set; }

		[FindsBy(How = How.Id, Using = "txtLenderZipCode")]
		public IWebElement LenderDetailsZipCode { get; set; }

		[FindsBy(How = How.Id, Using = "txtBusinessPhone")]
		public IWebElement LenderDetailsPhone { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmailAddress")]
		public IWebElement LenderDetailsEmail { get; set; }

		[FindsBy(How = How.Id, Using = "txtFaxPhone")]
		public IWebElement LenderDetailsFax { get; set; }

		[FindsBy(How = How.Id, Using = "txtCellPhone")]
		public IWebElement LenderDetailsCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "dgridBuyerSummary_1_chkBuyer")]
		public IWebElement BuyerSummary1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridLenderSummary")]
		public IWebElement LenderTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSellerSummary_1_chkSeller")]
		public IWebElement SellerSummary1 { get; set; }

		[FindsBy(How = How.Id, Using = "lblLogin")]
		public IWebElement RequestedBy { get; set; }

		[FindsBy(How = How.Id, Using = "gridAddress")]
		public IWebElement Property { get; set; }

		[FindsBy(How = How.Id, Using = "txtAlternateFileNumber")]
		public IWebElement AlternateFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtTitleInsMortgageeClauseTextLender")]
        public IWebElement TitleInsuranceMortgagee { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSellerSummary")]
        public IWebElement SellerSummaryTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Lenders Advantage A Division Of First American Title Ins.']")]
        public IWebElement NewLoanLender { get; set; }

        #endregion

        public ClosingProtectionLetter WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? UseMissouriLetter);
            return this;
        }


        public ClosingProtectionLetter Open()
        {
            FastDriver.LeftNavigation.Navigate<ClosingProtectionLetter>("Home>Order Entry>Closing Protection Letter").WaitForScreenToLoad();

            return this;
        }

	}
}
