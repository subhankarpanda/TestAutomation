using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class ConfirmationDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Name, Using = "OK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Name, Using = "Cancel")]
        public IWebElement Cancel { get; set; }

        #endregion

        public ConfirmationDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(OK);

            return this;
        }
    }
}
