using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class CopyDocuments : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "textFromFileNumber")]
		public IWebElement FromFileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "textToFileNumber")]
		public IWebElement ToFileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelectAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.LinkText, Using = "View Thumbnails")]
		public IWebElement ImageDocIcon { get; set; }

		[FindsBy(How = How.LinkText, Using = "View Thumbnails")]
		public IWebElement ViewThumbnails { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCopyDocument_0_chkSel")]
		public IWebElement copydoccheckbox1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCopyDocument_1_chkSel")]
		public IWebElement copydoccheckbox2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCopyDocument_2_chkSel")]
		public IWebElement copydoccheckbox3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCopyDocument")]
		public IWebElement DocListTable { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ExpandIcon { get; set; }

		#endregion

        public CopyDocuments WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FromFileNumber);
            return this;
        }
	}
}
