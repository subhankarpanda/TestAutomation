using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class CopyFrom : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnSearch")]
		public IWebElement Search { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileNumber")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ddlRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "optExceptions")]
		public IWebElement Exceptions { get; set; }

		[FindsBy(How = How.Id, Using = "optRequirements")]
		public IWebElement Requirements { get; set; }

		[FindsBy(How = How.Id, Using = "optInfo")]
		public IWebElement Info { get; set; }

		[FindsBy(How = How.Id, Using = "optAll")]
		public IWebElement All { get; set; }

		[FindsBy(How = How.Id, Using = "Button1")]
		public IWebElement Refresh { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddExpreqInfoPhrases")]
		public IWebElement AddPhrases { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_0_chkSelect")]
		public IWebElement CheckBox1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_1_chkSelect")]
		public IWebElement CheckBox2 { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_grdSearchResults")]
		public IWebElement Resultstable { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults")]
		public IWebElement Resultstable1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_0_btnList")]
		public IWebElement List1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_1_btnList")]
		public IWebElement List2 { get; set; }

        [FindsBy(How = How.Id, Using = "rbExcReqInfo")]
        public IWebElement Radio_ExcReqInfEnd { get; set; }

        [FindsBy(How = How.Id, Using = "rbEndorsements")]
        public IWebElement Radio_rbEndorsements { get; set; }

        [FindsBy(How = How.Id, Using = "rbInfoNotes")]
        public IWebElement Radio_rbInfoNotes { get; set; }

        [FindsBy(How = How.Id, Using = "btnSearchDocuments")]
        public IWebElement Searchbtn { get; set; }

        [FindsBy(How = How.Id, Using = "gridExpReqInfoCpyDocumentList")]
        public IWebElement DocResultGrid { get; set; }

        [FindsBy(How = How.Id, Using = "#gridExpReqInfoCpyDocumentList, #gridExpReqInfoCpyDocumentList")]
        public IWebElement DocumentsTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkSelExpReqInfoPhrases")]
        public IWebElement GridChkbox_0 { get; set; }


        [FindsBy(How = How.Id, Using = "btnphraseSelect")]
        public IWebElement BtnList_phrase { get; set; }
          // Added By rishi
        [FindsBy(How = How.Id, Using = "txtNewFileNum")]
        public IWebElement Copy_FileNum { get; set; }

        [FindsBy(How = How.Id, Using = "ddCopyFromRegion")]
        public IWebElement CopyFrom_Region { get; set; }

        [FindsBy(How = How.Id, Using = "btnrefreshDocs")]
        public IWebElement CopyFrom_RefreshBtn { get; set; }

        [FindsBy(How = How.Id, Using = "rbRequirements")]
        public IWebElement CopyFrom_RadioRequirement { get; set; }
        [FindsBy(How = How.Id, Using = "rbExceptions")]
        public IWebElement CopyFrom_RadioExceptions { get; set; }



        ////div/span[text()='Copy From']/ancestor::div[2]//div/button/span[text()='Done']

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Copy From']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement CopyFrom_BottomDone { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select Exceptions']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement CopyFromExcep_Done { get; set; }

        public CopyFrom WaitForScreenToLoad()
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            wait.Until(d =>
            {
                this.SwitchToContentFrame();
                return AddPhrases.Exists() || Refresh.Exists();
            });
            return this;
        }
		#endregion

	}
}
