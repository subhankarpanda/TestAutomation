using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DateDownRequest : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "lblFileNum")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSubmit")]
		public IWebElement Submit { get; set; }

		[FindsBy(How = How.Id, Using = "dgDateDown_0_rdoSel")]
		public IWebElement SelectPropertyRadio1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgDateDown")]
		public IWebElement PropertyTable { get; set; }

		[FindsBy(How = How.Id, Using = "lblErrMsg")]
		public IWebElement TitleErrorMessage { get; set; }

		[FindsBy(How = How.Id, Using = "lblProcessStatus")]
		public IWebElement CurrentlyProcessing { get; set; }

		#endregion

        public DateDownRequest WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? Submit);

            return this;
        }

        public DateDownRequest WaitForDialogToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Date Down Request", true, timeoutSeconds: 10);
            
            return this.WaitForScreenToLoad();
        }
	}
}
