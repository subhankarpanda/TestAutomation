using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DepositAdjustment : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDocmtNo")]
		public IWebElement DocumentNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtAmnt")]
		public IWebElement Amount { get; set; }

		[FindsBy(How = How.Id, Using = "ddlBankAct")]
		public IWebElement BankAcount { get; set; }

		[FindsBy(How = How.Id, Using = "txtIseDate")]
		public IWebElement IssueDate { get; set; }

		[FindsBy(How = How.Id, Using = "optBuyer")]
		public IWebElement CredittoBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "optSeller")]
		public IWebElement CredittoSeller { get; set; }

		[FindsBy(How = How.Id, Using = "optOther")]
		public IWebElement CredittoOther { get; set; }

		[FindsBy(How = How.Id, Using = "txtAdjDate")]
		public IWebElement AdjustmentDate { get; set; }

		[FindsBy(How = How.Id, Using = "ddlAdjReason")]
		public IWebElement AdjustmentReason { get; set; }

		[FindsBy(How = How.Id, Using = "txtDscrp")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "txtComment")]
		public IWebElement Comment { get; set; }

		[FindsBy(How = How.Id, Using = "chkbxUptTrstAcntg")]
		public IWebElement UpdateTrustAccounting { get; set; }

		[FindsBy(How = How.Id, Using = "ddlTypFunds")]
		public IWebElement TypeofFunds { get; set; }

		[FindsBy(How = How.Id, Using = "AdjUserName")]
		public IWebElement Loggedonuser { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrFileNo")]
		public IWebElement CorrFileNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrDocmtNo")]
		public IWebElement CorrectDocumentNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrDocmtNo")]
		public IWebElement CorrectDocumentNoEdit { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrAmnt")]
		public IWebElement CorrectAmount { get; set; }

		[FindsBy(How = How.Id, Using = "ddlCorrBankAcnt")]
		public IWebElement CorrectBankAccount { get; set; }

		[FindsBy(How = How.Id, Using = "ddlCorrBankAcnt")]
		public IWebElement CorrectBankAccountEnabled { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrDscrp")]
		public IWebElement CorrectDescription { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrComment")]
		public IWebElement CorrectComment { get; set; }

		[FindsBy(How = How.Id, Using = "ddlCorrBankAcnt")]
		public IWebElement CorrectBankAcctNumber { get; set; }

		[FindsBy(How = How.Id, Using = "txtDocmtNo")]
		public IWebElement AdhocDocNumber { get; set; }

		[FindsBy(How = How.Id, Using = "txtAmnt")]
		public IWebElement AdhocAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrPyePyr")]
		public IWebElement Payorname { get; set; }

		[FindsBy(How = How.Id, Using = "optSeller")]
		public IWebElement optAdhocSeller { get; set; }

		[FindsBy(How = How.Id, Using = "optOther")]
		public IWebElement optAdhocOther { get; set; }

		[FindsBy(How = How.LinkText, Using = "Adjustment Date: Adjustment Date is required")]
		public IWebElement Adjustmentdateblank { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMsg { get; set; }
		[FindsBy(How = How.LinkText, Using = "Issue Date: Issue Date is required")]
		public IWebElement Issuedateblank { get; set; }

		[FindsBy(How = How.LinkText, Using = "Document No.: You must change Document No. to create this adjustment")]
		public IWebElement samedocumentno { get; set; }

		[FindsBy(How = How.Id, Using = "lblItmTyp")]
		public IWebElement ItemType { get; set; }

		[FindsBy(How = How.Id, Using = "lblPyePyr")]
		public IWebElement PayornameEdit { get; set; }

		[FindsBy(How = How.Id, Using = "lblDescr")]
		public IWebElement Depositdescription { get; set; }

		[FindsBy(How = How.Id, Using = "AdjUserName")]
		public IWebElement User { get; set; }

		[FindsBy(How = How.Id, Using = "AdjUserName")]
		public IWebElement PostedBy { get; set; }

		[FindsBy(How = How.Id, Using = "lblPstdDate")]
		public IWebElement PostedOn { get; set; }

		[FindsBy(How = How.Id, Using = "lblFileNo")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Print { get; set; }
        [FindsBy(How = How.Id, Using = "lblBnkName")]
        public IWebElement BankName { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }
		#endregion

        public DepositAdjustment WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AdjustmentReason);

            return this;
        }

	}

    public class DepositAdjustmentConfirmation : PageObject
    {

        #region WebElements DepositAdjustmentConfirmation

        [FindsBy(How = How.Id, Using = "ddlProcess")]
        public IWebElement ReasonForLoss { get; set; }

        [FindsBy(How = How.Id, Using = "txtLossExplanation")]
        public IWebElement AdditionalLossExplanation { get; set; }

        [FindsBy(How = How.Id, Using = "ddlPropertyType")]
        public IWebElement PropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "txtPassword")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        #endregion
        public DepositAdjustmentConfirmation WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? ReasonForLoss);
            return this;
        }
    }
}
