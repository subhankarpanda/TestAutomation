using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DepositList : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//strong/span[contains(text(),'Advanced Search')]")]
        public IWebElement AdvancedSearch { get; set; }

        [FindsBy(How = How.Id, Using = "textReceiptNum")]
        public IWebElement ReceiptNumber { get; set; }

        [FindsBy(How = How.Id, Using = "cBoxExclude")]
        public IWebElement ShowExcluded { get; set; }

		[FindsBy(How = How.Id, Using = "txtSearchDate")]
		public IWebElement SearchDate { get; set; }

		[FindsBy(How = How.Id, Using = "cboBankAccounts")]
		public IWebElement BankAccounts { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFind")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "textIssueDtFrom")]
		public IWebElement IssueDateFrom { get; set; }

		[FindsBy(How = How.Id, Using = "textIssueDtTo")]
		public IWebElement IssueDateTo { get; set; }

		[FindsBy(How = How.Id, Using = "cBoxExclude")]
		public IWebElement ExcludeCheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "cBoxSelectAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdExclude")]
		public IWebElement Exclude { get; set; }

		[FindsBy(How = How.Id, Using = "cmdComplete")]
		public IWebElement Complete { get; set; }

		[FindsBy(How = How.Id, Using = "dGridReceipts_0_cBoxSelect")]
		public IWebElement PendingReceipts { get; set; }

		[FindsBy(How = How.Id, Using = "dgDepositLists_0_labelStatus")]
		public IWebElement PendingElement { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFindNow")]
		public IWebElement DepositListEdit_FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "dGridReceipts_dGridReceipts")]
		public IWebElement ReceiptsTable { get; set; }

		[FindsBy(How = How.Id, Using = "dGridReceipts_0_cBoxSelect")]
		public IWebElement Receipt1 { get; set; }

		[FindsBy(How = How.Id, Using = "labelTotalCount")]
		public IWebElement TotalCount { get; set; }

		[FindsBy(How = How.Id, Using = "labelTotalDeposit")]
		public IWebElement TotalDeposit { get; set; }

		[FindsBy(How = How.Id, Using = "dgDepositLists_dgDepositLists")]
		public IWebElement DepositListTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgDepositLists_0_labelDate")]
		public IWebElement DepositListDate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Create/Edit  Deposit List")]
		public IWebElement CreateEditDepositList { get; set; }

		[FindsBy(How = How.Id, Using = "labelBankAcNumber")]
		public IWebElement BankAcct { get; set; }

		[FindsBy(How = How.LinkText, Using = "Issue Date From: ")]
		public IWebElement IssueDate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Receipts/Deposits ")]
		public IWebElement ReceiptsDeposits { get; set; }

		[FindsBy(How = How.Id, Using = "labelChecksCount")]
		public IWebElement CountChecks { get; set; }

		[FindsBy(How = How.Id, Using = "labelOthersCount")]
		public IWebElement CountOthers { get; set; }

		[FindsBy(How = How.Id, Using = "labelCashCount")]
		public IWebElement CountCash { get; set; }

		[FindsBy(How = How.Id, Using = "labelTotalChecks")]
		public IWebElement TotalChecks { get; set; }

		[FindsBy(How = How.Id, Using = "labelTotalOthers")]
		public IWebElement TotalOther { get; set; }

		[FindsBy(How = How.Id, Using = "labelTotalCash")]
		public IWebElement TotalCash { get; set; }

		[FindsBy(How = How.LinkText, Using = "Last 30 deposit lists starting on: ")]
		public IWebElement Last30deposits { get; set; }

		[FindsBy(How = How.Id, Using = "dGridReceipts_0_labelIssueDate")]
		public IWebElement ReceiptIssueDate { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

		#endregion

        public DepositList WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FindNow);
            return this;
        }

        public bool IsCheckBoxEnabled(IWebElement element)
        {
            element.FindElement(By.XPath("//span/input[1]"));
            return element.IsEnabled();
        }
        public DepositList PrintDepositReceipt()
        {
            FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);
            return this;
        }

        public DepositList CompletePendingDepositList()
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(FindNow);
                if (!this.New.IsEnabled())
                {
                    this.FindNow.FAClick();
                    this.WaitCreation(FastDriver.DepositList.DepositListTable);
                    this.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                    this.Edit.FAClick();
                    this.WaitForScreenToLoad(FastDriver.DepositList.ShowExcluded);
                    this.DepositListEdit_FindNow.FAClick();
                    FastDriver.WebDriver.HandleDialogMessage(false, true, 10, true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    this.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                    this.ReceiptsTable.PerformTableAction(1, 1, TableAction.On);
                    this.Complete.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                    FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                    FastDriver.PrintDlg.ClickPrint();
                    FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);
                    FastDriver.BottomFrame.Done();
                    this.SwitchToContentFrame();
                    this.WaitCreation(FindNow);
                }
            }
            catch
            {

            }

            return this;
        }

        public int VerifyDepositListNumDisplayedInTable(string Number)
        {
            this.SwitchToContentFrame();
            return FastDriver.WebDriver.FindElements(By.XPath("//table[@id='dgDepositLists_dgDepositLists']//*[text()='" + Number + "']")).Count;
        }
	}

	public class DocumentDeliveryScriptlet : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }

		#endregion

	}
}
