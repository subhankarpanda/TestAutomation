using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.IIS;

namespace FASTSelenium.PageObjects.IIS
{
	public class DepositOutsideEscrow : PageObject
	{
        public struct HeldBy
        {
            public const string BuyersAttorney = "Buyer's Attorney";
            public const string BuyersBroker = "Buyer's Broker";
            public const string OutsideTitleCompany = "Outside Title Company";
            public const string SellersAttorney = "Seller's Attorney";
            public const string SellersBroker = "Seller's Broker";
        }

        public struct OEDeposit
        {
            public string HeldBy;
            public decimal Amount;
            public string Comment;
        }

		#region WebElements

        [FindsBy(How = How.Id, Using = "txtTotDep")]
		public IWebElement TotalDeposit { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdErnMny_0_ddlHeldBy")]
		public IWebElement EarnerstMoneyHeldBy_0 { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdErnMny_0_txtName")]
		public IWebElement EarnerstMoneyName_0 { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdErnMny_0_txtAmnt")]
		public IWebElement EarnerstMoneyAmount_0 { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdErnMny_1_ddlHeldBy")]
		public IWebElement EarnerstMoneyHeldBy_1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdErnMny_1_txtName")]
		public IWebElement EarnerstMoneyName_1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdErnMny_1_txtAmnt")]
		public IWebElement EarnerstMoneyAmount_1 { get; set; }


        [FindsBy(How = How.Id, Using = "dgrdErnMny_2_ddlHeldBy")]
        public IWebElement EarnerstMoneyHeldBy_2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_2_txtName")]
        public IWebElement EarnerstMoneyName_2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_2_txtAmnt")]
        public IWebElement EarnerstMoneyAmount_2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_3_ddlHeldBy")]
        public IWebElement EarnerstMoneyHeldBy_3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_3_txtName")]
        public IWebElement EarnerstMoneyName_3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_3_txtAmnt")]
        public IWebElement EarnerstMoneyAmount_3 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_4_ddlHeldBy")]
        public IWebElement EarnerstMoneyHeldBy_4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_4_txtName")]
        public IWebElement EarnerstMoneyName_4 { get; set; }

        [FindsBy(How = How.Id, Using = "dgrdErnMny_4_txtAmnt")]
        public IWebElement EarnerstMoneyAmount_4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtXsDep")]
		public IWebElement ExcessDeposit { get; set; }

		[FindsBy(How = How.Id, Using = "txtDisPro")]
		public IWebElement DisbursedasProceeds { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdTolCure0_0_ddlCuredBy")]
		public IWebElement Curefor0Tolerance_CuredBy { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdTolCure0_0_txtName")]
		public IWebElement Curefor0Tolerance_Name { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdTolCure0_0_txtAmnt")]
		public IWebElement Curefor0Tolerance_Amount { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdTolCure10_0_ddlCuredBy")]
		public IWebElement Curefor10Tolerance_CuredBy { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdTolCure10_0_txtName")]
		public IWebElement Curefor10Tolerance_Name { get; set; }

		[FindsBy(How = How.Id, Using = "dgrdTolCure10_0_txtAmnt")]
		public IWebElement Curefor10Tolerance_Amount { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Error { get; set; }

		[FindsBy(How = How.Id, Using = "lblDepMny")]
		public IWebElement EarnestMoneyDistribution { get; set; }

		#endregion

        public DepositOutsideEscrow Open()
        {
            FastDriver.LeftNavigation.Navigate<DepositOutsideEscrow>("Home>Order Entry>Escrow Closing>Deposits>Deposit Outside Escrow");
            this.WaitForScreenToLoad();

            return this;
        }

        public DepositOutsideEscrow WaitForScreenToLoad()
        {
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d => {
                try {
                    
                    this.SwitchToContentFrame();
                    return TotalDeposit.Displayed;

                }catch(NoSuchElementException){
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }
            });
           
            return this;
        }

        [Obsolete("Use the SetDeposit method for this operation")]
        public DepositOutsideEscrow Deposit(DepositOutsideEscrowParameters deposit)
        {
            this.SwitchToContentFrame();

            TotalDeposit.FASetText(deposit.TotalDeposit.ToString());

            if (deposit.EarnerstMoneyHeldBy_0 != "")
                EarnerstMoneyHeldBy_0.FASelectItem(deposit.EarnerstMoneyHeldBy_0);

            if (deposit.EarnerstMoneyName_0 != "")
                EarnerstMoneyName_0.FASetText(deposit.EarnerstMoneyName_0);

            if (deposit.EarnerstMoneyAmount_0 != 0)
                EarnerstMoneyAmount_0.FASetText(deposit.EarnerstMoneyAmount_0.ToString());

            if (deposit.EarnerstMoneyHeldBy_1 != "")
                EarnerstMoneyHeldBy_1.FASelectItem(deposit.EarnerstMoneyHeldBy_1);

            if (deposit.EarnerstMoneyName_1 != "")
                EarnerstMoneyName_1.FASetText(deposit.EarnerstMoneyName_1);

            if (deposit.EarnerstMoneyAmount_1 != 1)
                EarnerstMoneyAmount_1.FASetText(deposit.EarnerstMoneyAmount_1.ToString());
            
            if (deposit.ExcessDeposit != 0)
                ExcessDeposit.FASetText(deposit.ExcessDeposit.ToString());

            if (deposit.DisbursedasProceeds != 0)
                DisbursedasProceeds.FASetText(deposit.DisbursedasProceeds.ToString());

            if (deposit.Curefor0Tolerance_Amount != 0)
                Curefor0Tolerance_Amount.FASetText(deposit.Curefor0Tolerance_Amount.ToString());

            if (deposit.Curefor10Tolerance_Amount != "")
                Curefor10Tolerance_Amount.FASetText(deposit.Curefor10Tolerance_Amount);

            return this;
        }

        /// <summary>
        /// Add Outside Escrow Deposit
        /// </summary>
        /// <param name="deposits">Deposits Array</param>
        /// <returns>DepositOutsideEscrow Page Object</returns>
        public DepositOutsideEscrow SetDeposit(OEDeposit[] deposits)
        {
            #region Add Deposit Outside Escrow
            FastDriver.DepositOutsideEscrow.Open();
            decimal total = 0;
            for (int i = 0; i < deposits.Length; i++)
            {
                FastDriver.WebDriver.FindElement(By.Id("dgrdErnMny_" + i + "_ddlHeldBy")).FASelectItem(deposits[i].HeldBy.ToString());
                if (string.IsNullOrEmpty(FastDriver.WebDriver.FindElement(By.Id("dgrdErnMny_" + i + "_txtName")).Text))
                    FastDriver.WebDriver.FindElement(By.Id("dgrdErnMny_" + i + "_txtName")).FASetText(deposits[i].Comment);
                FastDriver.WebDriver.FindElement(By.Id("dgrdErnMny_" + i + "_txtAmnt")).FASetText(deposits[i].Amount.ToString("N2"));
                total += deposits[i].Amount;
            }
            FastDriver.DepositOutsideEscrow.TotalDeposit.FASetText(total.ToString("N2"));
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
            #endregion

            return this;
        }
	}
}
