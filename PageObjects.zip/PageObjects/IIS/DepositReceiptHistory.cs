﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class DepositReceiptHistory : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdhoc")]
        public IWebElement AdHocAdjustment { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdjust")]
		public IWebElement Adjust { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_grdDA")]
		public IWebElement ReceiptsDepositActivityTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnView")]
        public IWebElement ViewDetails { get; set; }
		#endregion

        public DepositReceiptHistory Open()
        {
            FastDriver.LeftNavigation.Navigate<DepositReceiptHistory>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
            this.WaitForScreenToLoad();
            return this;
        }

        public DepositReceiptHistory WaitForScreenToLoad()
        {
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d => {
                try {
                    
                    this.SwitchToContentFrame();
                    return Adjust.Displayed;

                }catch(NoSuchElementException){
                    return false;
                }
             });
            return this;
        }

        public DepositReceiptHistory PrintDepositReceipt()
        {
            FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            FastDriver.WebDriver.WaitForDeliveryWindow("Print", 300);
            return this;
        }

        public DepositReceiptHistory EmailDepositReceipt()
        {
            FastDriver.EmailDlg.WaitForDialogToLoad();
            FastDriver.EmailDlg.ToText.FASetText(AutoConfig.DeliverEmailTo, clearFirst: false); // Starting from v10.03.0003 build, it doesn't work if not passing clearFirst: false
            FastDriver.EmailDlg.Subject.FASetText(Environment.MachineName + " - " + AutoConfig.FASTHomeURL);
            FastDriver.EmailDlg.Email.FAClick();
            FastDriver.WebDriver.WaitForDeliveryWindow("Email", 300);
            return this;
        }

        public DepositReceiptHistory FaxDepositReceipt()
        {
                FastDriver.FaxDlg.WaitForScreenToLoad();
                FastDriver.FaxDlg.Insert.FAClick();
                FastDriver.FaxDlg.Name.FASetText(@"QA");
                FastDriver.FaxDlg.Attn.FASetText(@"1");
                FastDriver.FaxDlg.FAXNumber.FASetText(AutoConfig.DeliverFaxTo);
                FastDriver.FaxDlg.FAX.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Fax", 300);
                return this;
        }

        public DepositReceiptHistory ImagedocDepositReceipt()
        {
                FastDriver.ImageDocDlg.WaitForScreenToLoad();
                FastDriver.ImageDocDlg.WaitCreation(FastDriver.ImageDocDlg.ImageDoc);
                FastDriver.ImageDocDlg.ImageDoc.FAClick();
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc", 300);
                return this;
        }
	}
}


