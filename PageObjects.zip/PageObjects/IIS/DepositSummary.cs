using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using System.IO;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class DepositSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "grdDA_grdDA")]
        public IWebElement Receipts_DepositActivitytable { get; set; }

        [FindsBy(How = How.Id, Using = "btnView")]
        public IWebElement ViewDetails { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdjust")]
        public IWebElement Adjust { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdhoc")]
        public IWebElement AdHocAdjustment { get; set; }

        [FindsBy(How = How.Id, Using = "btnVoid")]
        public IWebElement Void { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalNet")]
        public IWebElement Net3300 { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalNet")]
        public IWebElement SumTotal { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_2_lblDesc")]
        public IWebElement RepostDescription { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalNet")]
        public IWebElement NetTotal { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerNet")]
        public IWebElement NetTotalBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerNet")]
        public IWebElement NetTotalSeller { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherNet")]
        public IWebElement NetTotalOther { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerIssued")]
        public IWebElement BuyerIssued { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerIssued")]
        public IWebElement SellerIssued { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherIssued")]
        public IWebElement OtherIssued { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalIssued")]
        public IWebElement TotalIssued { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerAdjusted")]
        public IWebElement NetAdjBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerAdjusted")]
        public IWebElement NetAdjSeller { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherAdjusted")]
        public IWebElement NetAdjOther { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAdjusted")]
        public IWebElement NetAdjTotal { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_1_lblDocument")]
        public IWebElement DocumentNo { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_0_lblPayor")]
        public IWebElement Payor { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_0_lblDocument")]
        public IWebElement DocumentNo1 { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_0_lblAmount")]
        public IWebElement Amount1 { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_0_lblIssueDate")]
        public IWebElement Issuedate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tblHeader")]
        public IWebElement DepositReceiptHistoryTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "grdDA_grdDA")]
        public IWebElement ReceiptsDepositActivityTable { get; set; }

        #endregion

        public DepositSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<DepositSummary>("Home>Order Entry>Escrow Closing>Deposits>Deposit/Receipt History");
            this.WaitForScreenToLoad();

            return this;
        }

        public DepositSummary WaitForScreenToLoad(IWebElement element = null)
        {
            Thread.Sleep(10000);
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Receipts_DepositActivitytable);

            return this;
        }
        public void SelectRowInaTable()
        {
            List<IWebElement> rows = Receipts_DepositActivitytable.FindElements(By.TagName("TR")).ToList();
            foreach(IWebElement eachrow in rows)
            {
                if (eachrow.Displayed)
                {
                    eachrow.FAClick();
                    if (Adjust.Enabled)
                    {
                        break;
                    }
                }
            }
        }
        public bool ValidateDataInHistoryTable(string Status, string Amount)
        {
            this.WaitForScreenToLoad();
            System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> rows = FastDriver.DepositSummary.DepositReceiptHistoryTable.FindElements(By.TagName("tr"));
            foreach (IWebElement row in rows)
            {
                string InnerText = row.FAGetText();
                if (InnerText.Contains(Status) && InnerText.Contains(Amount))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
