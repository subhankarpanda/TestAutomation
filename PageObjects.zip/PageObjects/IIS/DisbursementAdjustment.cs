using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DisbursementAdjustment : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDocNo")]
		public IWebElement DocumentNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtAmt")]
		public IWebElement Amount { get; set; }

		[FindsBy(How = How.Id, Using = "ddlBnkAct")]
		public IWebElement BankAccount { get; set; }

		[FindsBy(How = How.Id, Using = "txtIssDate")]
		public IWebElement IssueDate { get; set; }

		[FindsBy(How = How.Id, Using = "ddlTypOfFnds")]
		public IWebElement TypeOfFunds { get; set; }

		[FindsBy(How = How.Id, Using = "txtAdjDate")]
		public IWebElement AdjustmentDate { get; set; }

		[FindsBy(How = How.Id, Using = "ddlAdjResn")]
		public IWebElement AdjustmentReason { get; set; }

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "txtComent")]
		public IWebElement Comment { get; set; }

		[FindsBy(How = How.Id, Using = "chkUpdttrustacc")]
		public IWebElement UpdateTrustAccounting { get; set; }

		[FindsBy(How = How.Id, Using = "ddlCorrBankAcnt")]
		public IWebElement CorrectBankAcctNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ddlCorrBankAcnt")]
		public IWebElement CorrectBankAcctNumberEdit { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorrDocmtNo")]
		public IWebElement CorrectingTransDocumentNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorComent")]
		public IWebElement CorrectingTransComment { get; set; }

		[FindsBy(How = How.Id, Using = "txtCorDesc")]
		public IWebElement CorrectingTransDescription { get; set; }

		[FindsBy(How = How.Id, Using = "lblItemType")]
		public IWebElement ItemType { get; set; }

		[FindsBy(How = How.Id, Using = "lblPostdon")]
		public IWebElement PostedOn { get; set; }

		[FindsBy(How = How.Id, Using = "lblUserName")]
		public IWebElement PostedBy { get; set; }

		[FindsBy(How = How.Id, Using = "lblPayePayr")]
		public IWebElement Payee { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }
		#endregion

        public DisbursementAdjustment WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(AdjustmentReason);

            return this;
        }
	}
}
