using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DisbursementHistory : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnView")]
		public IWebElement ViewDetails { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdj")]
		public IWebElement Adjust { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdhocAdj")]
		public IWebElement AdHocAdjustment { get; set; }

		[FindsBy(How = How.Id, Using = "dgDisbActvty_2_lblAmt")]
		public IWebElement FeeAmount { get; set; }

		[FindsBy(How = How.Id, Using = "dgDisbActvty_3_lblAmt")]
		public IWebElement CheckAmount1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgDisbActvty_0_lblAmt")]
		public IWebElement CheckAmount2 { get; set; }

		[FindsBy(How = How.Id, Using = "lblNetDisbAmnt")]
		public IWebElement NetDisbursementAmount { get; set; }

		[FindsBy(How = How.Id, Using = "dgDisbSmry_3_lblAmt")]
		public IWebElement WireAmount { get; set; }

		[FindsBy(How = How.Id, Using = "dgDisbActvty_dgDisbActvty")]
		public IWebElement DisbursementTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgDisbSmry_dgDisbSmry")]
        public IWebElement ActiveDisbursementTable { get; set; }
        
		[FindsBy(How = How.Id, Using = "dgDisbActvty_3_lblAmt")]
		public IWebElement AdjAmount { get; set; }
        
		[FindsBy(How = How.Id, Using = "ddlCorrBankAcnt")]
		public IWebElement CorrectBankAcctNumber { get; set; }

		[FindsBy(How = How.Id, Using = "grdServiceFee")]
		public IWebElement ServiceFeeTable { get; set; }
        
		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }
        
        [FindsBy(How = How.Id, Using = "lblIsudAmnt")]
        public IWebElement NetIssuedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetAdjAmnt")]
        public IWebElement NetAdjAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetDisbAmnt")]
        public IWebElement NetDisbAmount { get; set; }

        #endregion

        public DisbursementHistory Open()
        {
            FastDriver.LeftNavigation.Navigate<DisbursementHistory>("Home>Order Entry>Escrow Closing>Disbursements>Disbursement History");
            this.WaitForScreenToLoad();

            return this;
        }

        public DisbursementHistory WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? DisbursementTable);

            return this;
        }

        public void PerformDelivery(string DeliveryMethod)
        {
            FastDriver.DisbursementHistory.WaitForScreenToLoad(FastDriver.DisbursementHistory.Deliver);
            FastDriver.DisbursementHistory.Method.FASelectItem(DeliveryMethod);
            FastDriver.DisbursementHistory.Deliver.FAClick();
        }
	}
}
