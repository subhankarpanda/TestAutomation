using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocPackageDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNewPack")]
		public IWebElement CreateNewPackage { get; set; }

		[FindsBy(How = How.Id, Using = "dgPackage_0_rdPackage")]
		public IWebElement SelectPackage1 { get; set; }

		#endregion

        public DocPackageDlg WaitForScreenToLoad()
        {

            try
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            }
            catch (Exception)
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_1_iframe");
            }

            try
            {
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }
            catch { }

            this.WaitCreation(CreateNewPackage);
            return this;
        }

	}
}
