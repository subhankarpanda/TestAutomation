using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocPrepTextEditorDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.XPath, Using = "//span[@id='tlbNotes']/table/tbody/tr/td/span/button")]
        public IWebElement CheckSpelling { get; set; }

		[FindsBy(How = How.Id, Using = "txtNote")]
		public IWebElement Note { get; set; }

		#endregion

        public DocPrepTextEditorDlg WaitForScreenToLoad(IWebElement element = null, string windowName = "Finalize Document")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Note);
            return this;
        }
	}
}
