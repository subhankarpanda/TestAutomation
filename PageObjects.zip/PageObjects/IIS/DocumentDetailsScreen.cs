using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocumentDetailsScreen : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "lblDocID")]
		public IWebElement DocID { get; set; }

		[FindsBy(How = How.Id, Using = "lblServiceFileID")]
		public IWebElement FileID { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement DeliveryUser { get; set; }

		#endregion

        public DocumentDetailsScreen WaitForScreenToLoad(IWebElement element = null)
        {
            this.WebDriver.SwitchTo().DefaultContent();
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? DocID);
            return this;
        }
	}
}
