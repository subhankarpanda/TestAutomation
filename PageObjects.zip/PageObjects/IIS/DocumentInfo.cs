using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocumentInfo : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnSave")]
		public IWebElement Save { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnSv")]
        public IWebElement TitlePolicyInfoSave { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnCpyFrm")]
		public IWebElement CopyFrom { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnCF")]
        public IWebElement LenderCopyFrom { get; set; }
		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_chkApp")]
		public IWebElement ApprovedCheckBox { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtEffDat")]
		public IWebElement EffectiveDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInfo2Excp")]
		public IWebElement Exceptions1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtExcp")]
		public IWebElement Exceptions { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlExcp")]
		public IWebElement ExceptionSourceRegion { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtReq")]
		public IWebElement Requirements { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlReq")]
		public IWebElement RequirementsSourceRegion { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInf")]
		public IWebElement InformationalNotes { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlInf")]
		public IWebElement InformationalNotesRegion { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtDesc")]
		public IWebElement DocumentDescription { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInfo2Desc")]
		public IWebElement LenderOwnerDescription { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtEDt")]
		public IWebElement LenderOwnerEffectiveDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdLn_0_chkLnSel")]
		public IWebElement LenderCheckBox { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdSlr_0_chkSlrSel")]
		public IWebElement SellersCheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdProp_0_chkProp")]
		public IWebElement Propertycheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdProp_1_chkProp")]
		public IWebElement Propertycheckbox2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdProp_2_chkProp")]
		public IWebElement Propertycheckbox3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdByr_0_chkByrSel")]
		public IWebElement Buyercheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnAN")]
		public IWebElement AssignNum { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInf2PN")]
		public IWebElement PolicyNum { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_chkInfo2PN")]
		public IWebElement AutoNumber { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnAPN")]
		public IWebElement AssignPolicyNumber { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInf2IsuDt")]
		public IWebElement IssueDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdLn_1_chkLnSel")]
		public IWebElement LenderCheckBox1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtByr")]
		public IWebElement Buyeramount { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtSel")]
		public IWebElement Selleramount { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_lblLib")]
		public IWebElement LiabilityAmount { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_lblExSR")]
		public IWebElement MultipleSource { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_lblLibty")]
		public IWebElement SalesLiabilityAmount { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtWvd")]
		public IWebElement Waived { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_TC_DS_DRD_DTC_SrcRlt")]
		public IWebElement SearchResults { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtEDt")]
		public IWebElement policywotitlereporteffectiveDate { get; set; }

        // Added By Rishi
        [FindsBy(How = How.Id, Using = "txtEffectiveDate")]
        public IWebElement EffectiveDateText { get; set; }

        

		#endregion

        public DocumentInfo WaitForWindowToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? DocumentDescription);

            return this;
        }

        public DocumentInfo WaitForScreenToLoad(IWebElement element = null)
        {
            this.WebDriver.SwitchTo().DefaultContent();
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? LenderOwnerDescription);
            return this;
        }

        public DocumentInfo WaitForPolicyNumToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PolicyNum);
            return this;
        }

	}
}
