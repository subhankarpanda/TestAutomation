using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocumentNameDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDocName")]
		public IWebElement DocName { get; set; }
        #endregion

        public DocumentNameDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? DocName);
            return this;
        }

        public DocumentNameDlg WaitForDialogLoad1(IWebElement Element = null)
        {

            WebDriver.WaitForWindowAndSwitch("Document Name", timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Element ?? DocName);

            return this;
        }
		

	}
	public class EditNameDocumentDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkChgType")]
		public IWebElement ChangeDocumentType { get; set; }

		[FindsBy(How = How.Id, Using = "chkCrtCpy")]
		public IWebElement CreateaCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cboDocumentType")]
		public IWebElement DocumentType { get; set; }

		[FindsBy(How = How.Id, Using = "txtEditDocName")]
		public IWebElement EditDocName { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddInformation")]
		public IWebElement AdditionalInformation { get; set; }

		[FindsBy(How = How.Id, Using = "txtDocumentName")]
		public IWebElement ChangeDocumentName { get; set; }

		#endregion

	}
}
