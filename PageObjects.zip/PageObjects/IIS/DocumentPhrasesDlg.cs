using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocumentPhrasesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnUnSelect")]
		public IWebElement UnSelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_0_chkPhrasSel")]
		public IWebElement grdPhrases0PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_1_chkPhrasSel")]
		public IWebElement grdPhrases1PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_2_chkPhrasSel")]
		public IWebElement grdPhrases2PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_3_chkPhrasSel")]
		public IWebElement grdPhrases3PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_4_chkPhrasSel")]
		public IWebElement grdPhrases4PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_5_chkPhrasSel")]
		public IWebElement grdPhrases5PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_6_chkPhrasSel")]
		public IWebElement grdPhrases6PhrasSel { get; set; }

		[FindsBy(How = How.Id, Using = "txtNote")]
		public IWebElement Reason { get; set; }

		#endregion

	}
}
