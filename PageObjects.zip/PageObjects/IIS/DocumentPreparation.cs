using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Interactions;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class DocumentPreparation : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase")]
        public IWebElement DocumenPhraseTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_5_chkWaive")]
        public IWebElement WaiveT3 { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_14_chkWaive")]
        public IWebElement WaiveN19 { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_0_txttextData")]
        public IWebElement BusinessSourceFax { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_1_txttextData")]
        public IWebElement BusinessSourceBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_2_txttextData")]
        public IWebElement BusinessSourceCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_3_txttextData")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_4_txttextData")]
        public IWebElement PagerNumber { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Phrase")]
        public IWebElement Phraselink { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Document")]
        public IWebElement DocumentLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@id='AM_ICP_Document']/u")]
        public IWebElement DocumentLinkShortCutKey { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr/td/span[@class='cTitle']")]
        public IWebElement DocumentPreparationHeader { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Element")]
        public IWebElement ElementLink { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Tools")]
        public IWebElement ToolsLink { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_InsertPhrase")]
        public IWebElement PhraseInsertlink { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_1_chkWaive")]
        public IWebElement Waive { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_1_grdDocPhrase_0_txttextData")]
        public IWebElement BuyerNames { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseArea")]
        public IWebElement PhraseArea { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_grdDocuments")]
        public IWebElement PhraseTable { get; set; }

        #endregion

        public DocumentPreparation WaitForWindowToLoad()
        {
            // this.WebDriver.SwitchTo().DefaultContent();
            //this.SwitchToTitleFrame();
            this.SwitchToContentFrame();
            this.WaitCreation(DocumenPhraseTable);
            // this.WaitCreation(DocumentPreparationHeader);

            return this;
        }

        public DocumentPreparation OpenFinalizeDialog()
        {
            //Actions builder = new Actions(FastDriver.WebDriver);
            //builder.KeyDown(Keys.Alt).SendKeys("o").KeyUp(Keys.Alt).SendKeys("z").Perform();
            //builder.MoveToElement(FastDriver.WebDriver.FindElement(By.XPath("//a[@id='AM_ICP_Document']/u")), 5, 5).Build().Perform();
            //builder.SendKeys(Keys.Alt + "o").Build().Perform();
            DocumentLinkShortCutKey.FAClick();
            Keyboard.SendKeys("%o");
            Playback.Wait(1000);
            Keyboard.SendKeys("z");
            return this;
        }

        public DocumentPreparation WaitForScreenToLoad(IWebElement element = null)
        {
            this.WebDriver.SwitchTo().DefaultContent();
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? DocumentLink);
            return this;

            //WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            //wait.Until(d =>
            //{
            //    try
            //    {
            //        FastDriver.WebDriver.SwitchTo().DefaultContent();
            //        this.SwitchToContentFrame();
            //        this.WaitElementDisplayed(element ?? DocumentLink);
            //        return true;
            //        //return BuyerNames.Exists() || BuyerNames.IsDisplayed();
            //    }
            //    catch (NoSuchElementException) {
            //        return false;
            //   }
            //});
            //return this;
        }

        public void SelectPhrasefromTable(string phraseName)
        {
            var tables = this.PhraseTable.FindElements(By.ClassName("cFrame"));
            foreach(IWebElement table in tables)
            {
                if(table.FAGetText().Contains(phraseName))
                {
                    var Rows = table.FindElements(By.TagName("TR"));
                    var tables2= Rows[1].FindElements(By.TagName("TABLE"));
                    var Rows2 = tables2[0].FindElements(By.TagName("TR"));
                    Rows2[0].FAClick();
                    break;
                }
            }
        }

        public Boolean VerifyPhraseWaivedorUnWaived(string phraseName)
        {
            bool result=false;
            var tables = this.PhraseTable.FindElements(By.ClassName("cFrame"));
            foreach(IWebElement table in tables)
            {
                if (table.FAGetText().Contains(phraseName))
                {
                    try
                    {
                        var waiveChecBox = table.FindElement(By.TagName("INPUT"));
                        result = true && waiveChecBox.IsSelected();
                        break;
                    }
                    catch(NoSuchElementException)
                    {
                        result = false;
                    }
                }
            }
            return result;
        }

        public void EditPhraseText(string phraseName)
        {
            var tables = this.PhraseTable.FindElements(By.ClassName("cFrame"));
            foreach (IWebElement table in tables)
            {
                if (table.FAGetText().Contains(phraseName))
                {
                    var Rows = table.FindElements(By.TagName("TR"));
                    var tables2 = Rows[1].FindElements(By.TagName("TABLE"));
                    var Rows2 = tables2[0].FindElements(By.TagName("TR"));
                    Rows2[0].FAClick();
                    var cells=Rows2[0].FindElements(By.TagName("TD"));
                    cells[2].Highlight();
                    cells[2].FindElement(By.TagName("Input")).FASetText("PhraseDtlChanged");
                    break;
                }
            }
        }

        public string GetPhraseText(string phraseName)
        {
            string phraseText = null;
            var tables = this.PhraseTable.FindElements(By.ClassName("cFrame"));
            foreach (IWebElement table in tables)
            {
                if (table.FAGetText().Contains(phraseName))
                {
                    var Rows = table.FindElements(By.TagName("TR"));
                    var tables2 = Rows[1].FindElements(By.TagName("TABLE"));
                    var Rows2 = tables2[0].FindElements(By.TagName("TR"));
                    Rows2[0].FAClick();
                    var cells = Rows2[0].FindElements(By.TagName("TD"));
                    cells[2].Highlight();
                    phraseText = cells[2].FindElement(By.TagName("Input")).FAGetValue();
                    break;
                }
            }
            return phraseText;
        }

    }

    public class DocumentPreparationwin : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_0_txttextData")]
        public IWebElement grdDocumenPhrase0textData { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_1_txttextData")]
        public IWebElement grdDocumenPhrase1textData { get; set; }

        [FindsBy(How = How.LinkText, Using = "/SMSFast/FastNetApp4/images/ico_write.gif")]
        public IWebElement Textelementwriteimage { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_0_txttextData")]
        public IWebElement BusinessSourceFax { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_1_txttextData")]
        public IWebElement BusinessSourceBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_2_txttextData")]
        public IWebElement BusinessSourceCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_3_txttextData")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_4_txttextData")]
        public IWebElement PagerNumber { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_lblOriginalCd")]
        public IWebElement PhraseNamePane { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/FastNetApp4/images/ico_lock.gif")]
        public IWebElement LockImage { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_0_lblDescription")]
        public IWebElement PhraseMarker { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_grdDocuments")]
        public IWebElement PhraseTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/FastNetApp4/images/ico_brokenlink.gif")]
        public IWebElement BrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_1_grdDocPhrase_0_txttextData")]
        public IWebElement BusinessAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgSelect_0_lblName")]
        public IWebElement SelectTitleReportPane { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_1_chkWaive")]
        public IWebElement Waive { get; set; }

        //Misc. Disbursements Information table at Document Preparation : BusinessSourceContactInfo screen  
        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_0_txttextData")]
        public IWebElement MiscDisbAttention { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_1_txttextData")]
        public IWebElement MiscDisbAddrBusinessLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_13_txttextData")]
        public IWebElement MiscDisbPhone1BusFaxNo { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_15_txttextData")]
        public IWebElement MiscDisbPhone1BusNo { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_21_txttextData")]
        public IWebElement MiscDisbPhone1CellPhoneNo { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_25_txttextData")]
        public IWebElement MiscDisbPhoneEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_1_grdDocPhrase")]
        public IWebElement Phrase2Table { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='1st Bus Phone & Ext  No.']")]
        public IWebElement firstBusPhoneAndExtNo { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='BSCI/BSCI']")]
        public IWebElement BSCI { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp2")]
        public IWebElement Expand { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Document")]
        public IWebElement Document { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_DocumentPreview")]
        public IWebElement DocumentPreview { get; set; }

        #endregion

        public DocumentPreparationwin WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? BusinessSourceBusinessPhone);
            return this;
        }

        public DocumentPreparationwin WaitForScreen(int timeout = 5)
        {
            this.SwitchToContentFrame();
            return this;
        }

        public DocumentPreparationwin WaitForElementToLoad(IWebElement elem = null)
        {
            this.SwitchToContentFrame();
            if (elem != null)
                this.WaitCreation(elem);
            else
                this.WaitCreation(BusinessSourceBusinessPhone);
            return this;
        }

        public void VerifyMultplColValues(int RowNum, Dictionary<int, string> DictionaryObj)
        {
            int RowNumber = RowNum + 1;
            this.SwitchToContentFrame();
            this.WaitCreation(PhraseTable);
            if (DictionaryObj.Count == 0)
            {
                throw new Exception("Dictionary does not have Keys. Please add Key and Value");
            }

            foreach (var ColNum in DictionaryObj.Keys)
                if (PhraseTable.FindElements(By.XPath("//tr[" + RowNumber + "]/td[" + ColNum + "]//child::*[contains(*,'" + DictionaryObj[ColNum].ToString() + "')]")).Count > 0)
                {
                    Reports.UpdateDebugLog("Verify Text in Buyer Summary Table", "", "Text in Table", "TEXT", DictionaryObj[ColNum], "", Reports.Result(true), "");

                }
                else
                {
                    Reports.UpdateDebugLog("Verify Text in Buyer Summary Table", "", "Text in Table", "TEXT", DictionaryObj[ColNum], "", Reports.Result(false), "");
                }
        }


        public bool VerifyValueInTable(int RowNum, string ValueAttr)
        {
            if (PhraseTable.FindElements(By.XPath("//table[@id='grdDocuments_grdDocuments']//tr[" + RowNum + "]//child::*[@value='" + ValueAttr + "']")).Count > 0)
                return true;
            else
                return false;
        }

        public bool VerifyTextInTable(int RowNum, string TextAttr)
        {
            if (PhraseTable.FindElements(By.XPath("//table[@id='grdDocuments_grdDocuments']//tr[" + RowNum + "]//child::*[text()='" + TextAttr + "']")).Count > 0)
                return true;
            else
                return false;
        }


    }

    public class DocumentPreparationMenu : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "AM_ICP_Document")]
        public IWebElement menuDocument { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Done")]
        public IWebElement menuDocumentDone { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Save")]
        public IWebElement menuDocumentSave { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Finalize")]
        public IWebElement menuDocumentFinalize { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Preview")]
        public IWebElement menuDocumentPreview { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Print")]
        public IWebElement menuDocumentPrint { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Fax")]
        public IWebElement menuDocumentFax { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Email")]
        public IWebElement menuDocumentEmail { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Document_Refresh")]
        public IWebElement menuDocumentRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Phrase")]
        public IWebElement menuPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_InsertPhrase")]
        public IWebElement menuPhraseInsertPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_InsertTemplate")]
        public IWebElement menuPhraseInsertTemplate { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_InsertMisc")]
        public IWebElement menuPhraseInsertMisc { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_InsertMarker")]
        public IWebElement menuPhraseInsertMarker { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_Edit")]
        public IWebElement menuPhraseEdit { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_View")]
        public IWebElement menuPhraseView { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_Delete")]
        public IWebElement menuPhraseDelete { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_Waive")]
        public IWebElement menuPhraseWaive { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_Refresh")]
        public IWebElement menuPhraseRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_Move")]
        public IWebElement menuPhraseMove { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Phrase_Addtopending")]
        public IWebElement menuPhraseAddtopending { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Element")]
        public IWebElement menuElement { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Element_Edit")]
        public IWebElement menuElementEdit { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Element_Refresh")]
        public IWebElement menuElementRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Element_Findblankelements")]
        public IWebElement menuElementFindblankelements { get; set; }

        [FindsBy(How = How.Id, Using = "AM_ICP_Tools")]
        public IWebElement menuTools { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Tools_Draft")]
        public IWebElement menuToolsDraft { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Tools_Proforma")]
        public IWebElement menuToolsProforma { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_Tools_SpellCheck")]
        public IWebElement menuToolsSpellCheck { get; set; }

        [FindsBy(How = How.Id, Using = "AS_ICP_ToolsDraft")]
        public IWebElement MenuToolsDraft { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='NPBS/NPBS']")]
        public IWebElement NPBS { get; set; }

        [FindsBy(How = How.Id, Using = "//span[contains(text(),'JVR/JVR1']")]
        public IWebElement JVR1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='JV01']")]
        public IWebElement JV01 { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='BSCI/BSCI']")]
        public IWebElement BSCI { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_1_lblOriginalCd")]
        public IWebElement PharseJVE { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_lblOriginalCd")]
        public IWebElement Phrase1 { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp2")]
        public IWebElement Expand1 { get; set; }

        [FindsBy(How = How.Id, Using = "grdDocuments_0_grdDocPhrase_12_txttextData")]
        public IWebElement policynumber { get; set; }
        [FindsBy(How = How.Id, Using = "grdDocuments_0_lblName")]
        public IWebElement label1 { get; set; }
        [FindsBy(How = How.Id, Using = "grdDocuments_1_grdDocPhrase_0_txttextData")]
        public IWebElement BuyerNames { get; set; }
        #endregion

        public DocumentPreparationMenu WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? menuDocument);
            return this;
        }

        public bool IsFinalizeDocumentDialogPresent()
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(menuDocument);
                Expand1.Click();
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("%o");
                Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
                Keyboard.SendKeys("z");
                Playback.Wait(3000);
                FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        public DocumentPreparationMenu FinalizeDocument()
        {
            WaitForScreenToLoad();
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("%o");
            Playback.Wait(2000); //must explicitely wait, no way to dynamically wait for these
            Keyboard.SendKeys("z");
            Playback.Wait(3000);
            FastDriver.DocPrepTextEditorDlg.WaitForScreenToLoad();
            return this;
        }

    }
}
