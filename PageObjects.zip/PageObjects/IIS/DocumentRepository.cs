using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
using System.Windows.Input;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
    using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using UIModifierKeys = System.Windows.Input.ModifierKeys;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using FASTWCFHelpers.FastFileService;
    using FASTWCFHelpers;
    using FASTWCFHelpers.Factories;

    public class DocumentRepository : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo")]
        public IWebElement RTMPackageReturnTo { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_btnSearchGAB")]
        public IWebElement RTMPackageSearchGAB { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_ddlOfficeName")]
        public IWebElement RTMPackageOfficeName { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliverGUI")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srch_cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srch_cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srch_cboSource")]
        public IWebElement Source { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srch_cboTempType")]
        public IWebElement TemplateType { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srch_txtDesc")]
        public IWebElement TemplateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_grdSrchResults_grdSrchResults")]
        public IWebElement SearchResultsTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#TC_DS_DRD_DTC_SrcRlt_btnScan,#TC_FT_FIT_srchRslts_TC_tpSrch_btnScan")]
        //[FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnScan")]
        public IWebElement Scan { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_btnScan")]
        public IWebElement Scan_FiltrTempTab { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnScan")]
        public IWebElement Scan_DocsTab { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#TC_FT_FIT_srchRslts_TC_tpSrch_btnUpld,#TC_DS_DRD_DTC_SrcRlt_btnUpld")]
        public IWebElement Upload { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_btnUpld")]
        public IWebElement FilteredTemplateUpload { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnUpld")]
        public IWebElement DocumentsUpload { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnAdd")]
        public IWebElement AddDocRep { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(@id,'_btnAdd')]")]
        public IWebElement AddGeneric { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_btnCrtEdt")]
        public IWebElement CreateEdit { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_btnSave")]
        public IWebElement CreateSave { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_ddlSrchType")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnUnRemove")]
        public IWebElement Restore { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnPurge")]
        public IWebElement Purge { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnVdl")]
        public IWebElement ViewDeliveryInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnRecordDocs")]
        public IWebElement RecordedDocsRequest { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnSchedule")]
        public IWebElement ScheduleBDocs { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnDetails")]
        public IWebElement Details { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnDearc")]
        public IWebElement De_archive { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnAssct")]
        public IWebElement Associate { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnRTM")]
        public IWebElement RTMPackage { get; set; }

        [FindsBy(How = How.Id, Using = "TC_AD_DRA_btnModify")]
        public IWebElement Modify { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_btnAddaddresses")]
        public IWebElement AddAddressees { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_gdSR")]
        public IWebElement DocumentsTable { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_btnDocSec")]
        public IWebElement PublishButtonColour { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_DS_DRD_DTC_Info")]
        public IWebElement Info { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdProp")]
        public IWebElement Properties { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdProp_1_chkProp")]
        public IWebElement Properties2chkbox { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnSv")]
        public IWebElement InfoSave { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='UK ENDOR T']")]
        public IWebElement UKENDORTElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Endorsement/Guarantee']")]
        public IWebElement EndorsementGuaranteeElement { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_Type")]
        public IWebElement endorsementGuaranteeElement { get; set; }

        [FindsBy(How = How.XPath, Using = "span[.='Lender Policy']")]
        public IWebElement LenderPolicyElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Owner Policy']")]
        public IWebElement OwnerPolicyElement { get; set; }

        [FindsBy(How = How.LinkText, Using = "Title Reports")]
        public IWebElement TitleReportsElement { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_btnUp")]
        public IWebElement EditnameButton { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_1_btnUp")]
        public IWebElement EditnameButton1 { get; set; }

        [FindsBy(How = How.XPath, Using = "span[.='Accomm Signing-Customer Buyer 0']")]
        public IWebElement AccommSigng_CustomerBuyerElement { get; set; }

        [FindsBy(How = How.XPath, Using = "span[.='Accomm Signing-Customer Seller 0']")]
        public IWebElement AccommSign_CustomerSellerElement { get; set; }

        [FindsBy(How = How.LinkText, Using = "Accomm Signing-Customer Buyer 0")]
        public IWebElement AccommSigng_CustomerBuyerElement1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Accomm Signing-Customer Seller")]
        public IWebElement AccommSign_CustomerSellerElement1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Automation Test Title Report']")]
        public IWebElement AutomationTestTitleReport { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='INST-Estimated Settlement Statement']")]
        public IWebElement EstimatedSettlementStatement { get; set; }

        [FindsBy(How = How.LinkText, Using = "Title Ltr/Transmittal")]
        public IWebElement TitleLtrTransmittalElement { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnVdl")]
        public IWebElement DistributionAndDeliveryInstructions { get; set; }

        [FindsBy(How = How.LinkText, Using = "Distribution And Delivery Instructions")]
        public IWebElement DistributionAndDeliveryInstructionsElement { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_DS")]
        public IWebElement DocumentsTab { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_Name")]
        public IWebElement ScannedDoc { get; set; }

        [FindsBy(How = How.LinkText, Using = "SEC-TA-Accounting")]
        public IWebElement ScannedSecDoc { get; set; }

        [FindsBy(How = How.LinkText, Using = "PO-Invoice INST-Estimated Settlement Statement")]
        public IWebElement EditedDoc { get; set; }

        [FindsBy(How = How.LinkText, Using = "ManualDocumentName")]
        public IWebElement ManualDoc { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnVdl")]
        public IWebElement EditedDocType { get; set; }

        [FindsBy(How = How.LinkText, Using = "Recorded Documents")]
        public IWebElement EditedDocType1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Search Result")]
        public IWebElement EditedDocType2 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Policy w/o Title Repor...")]
        public IWebElement PWTRElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'PDF.gif')]")]
        public IWebElement PDFViewFiles { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'thumbnail.gif')]")]
        public IWebElement Thumbnail { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_1_btnDocSec")]
        public IWebElement Publish { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_btnMulPub")]
        public IWebElement PublishButton { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_1_ChkCVF")]
        public IWebElement Flag { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_2_ChkCVF")]
        public IWebElement Flag1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_chkInfo2PN")]
        public IWebElement CheckPolicyNo { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_btnWatermark")]
        public IWebElement WMEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_1_btnWatermark")]
        public IWebElement WMEllipsis1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtDesc")]
        public IWebElement InfoDescription { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInfo2Desc")]
        public IWebElement InfoLenderDescription { get; set; }
        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtEffDat")]
        public IWebElement EffectiveDate { get; set; }
        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtExcp")]
        public IWebElement Exceptions { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtReq")]
        public IWebElement Requirements { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInf")]
        public IWebElement Information { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlInf")]
        public IWebElement InfoSourceRegion { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnSave")]
        public IWebElement btnInfoSave { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtEDt")]
        public IWebElement PWTREffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtInf2PN")]
        public IWebElement PolicyNumber { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlFastProduct")]
        public IWebElement Product { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_grdProp_0_chkProp")]
        public IWebElement propertychk { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_DS_DRD_DTC_SrcRlt")]
        public IWebElement SearchResults { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtLicenseNumber")]
        public IWebElement LicenseNumber { get; set; }

        [FindsBy(How = How.LinkText, Using = "Split Image")]
        public IWebElement SplitImage1 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Split Image")]
        public IWebElement SplitImage2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SplitImage3 { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous PDFDocument")]
        public IWebElement UploadRowPDF { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous JPGFile")]
        public IWebElement UploadRowJPG { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous TIFFFile")]
        public IWebElement UploadRowTIFF { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous DOCFile")]
        public IWebElement UploadRowDoc { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous DOCXFile")]
        public IWebElement UploadRowDocx { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous XLSFile")]
        public IWebElement UploadRowXls { get; set; }

        [FindsBy(How = How.LinkText, Using = "Miscellaneous XLSXFile")]
        public IWebElement UploadRowXlsx { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_Name")]
        public IWebElement Docname { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_1_Name")]
        public IWebElement Docname1 { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_RTM")]
        public IWebElement RTMPackagesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_FT")]
        public IWebElement FilteredTemplatesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_AD")]
        public IWebElement AssociateDocsTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'collapse.gif')]")]
        public IWebElement ExpandIcon { get; set; }

        [FindsBy(How = How.LinkText, Using = "Form")]
        public IWebElement Form { get; set; }

        [FindsBy(How = How.Id, Using = "TC_FT_FIT_srchRslts_TC_tpSrch_grdSrchResults_grdSrchResults")]
        public IWebElement SearchTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "SplitDocName")]
        public IWebElement SplitName { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_SrcRlt_gdSR_0_Desc")]
        public IWebElement Date { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnAN")]
        public IWebElement AssignNum { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnSv")]
        public IWebElement Save { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnAPN")]
        public IWebElement InfoTabAssignPolicyNumberButton { get; set; }

        [FindsBy(How = How.XPath, Using = ".//span[contains(text(),'Miscellaneous')]")]
        public IWebElement Miscellaneous { get; set; }

        [FindsBy(How = How.Id, Using = "TC_AD_DRA_dgAssocDoc_dgAssocDoc")]
        public IWebElement AssPackageTable { get; set; }

        [FindsBy(How = How.Id, Using = "TC_AD_DRA_dgDocs_dgDocs")]
        public IWebElement PackageDocumentsTable { get; set; }

        [FindsBy(How = How.Id, Using = "TC_AD_DRA_btnAddRemove")]
        public IWebElement PackageRemove { get; set; }


        [FindsBy(How = How.XPath, Using = "//span[.='Lender Policy']")]
        public IWebElement LenderPolicy { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_dgRTMPackages_0_txtName")]
        public IWebElement RTMPackageName { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs")]
        public IWebElement RTMPackageNameSubTable { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_btnRemove")]
        public IWebElement RTMPackageRemove { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_btnRemoveDocs")]
        public IWebElement RTMPackageRemoveDocument { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_btnSelectFileAddressees")]
        public IWebElement RTMPackageSelectAddress { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_RTM_RTMDOC_tabRTMSubTab_MailTo")]
        public IWebElement RTMPackageMailTo { get; set; }
        [FindsBy(How = How.XPath, Using = "//span[.='SEC-Settlement Secured Image']")]
        public IWebElement SecuredImage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='PROP1APN1_PDF']")]
        public IWebElement PROP1APN1_PDF { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='SP-Prior']")]
        public IWebElement SP_Prior { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Final Closing Instructions']")]
        public IWebElement FinalClosingInstructions { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'bin laden')]")]
        public IWebElement BinLaden { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Closing Protection Letter - LENDER']")]
        public IWebElement ClosingProtectionLetterDoc { get; set; }
        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_lblLib")]
        public IWebElement LiabilityAmt { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Accomm Signing-Customer Buyer']")]
        public IWebElement AccommSigning_CustomerBuyer { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Accomm Signing-Customer Seller']")]
        public IWebElement AccommSigning_CustomerSeller { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlExcp")]
        public IWebElement InfoExceptions { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_ddlReq")]
        public IWebElement InfoRequirement { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_dgRTMPackages_0_lblName")]
        public IWebElement RTMPackageId { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Bus Source']")]
        public IWebElement BusSource { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Search Result']")]
        public IWebElement SearchResult { get; set; }

        //SRT 08
        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnCpyFrm")]
        public IWebElement CopyFrom { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_txtEDt")]
        public IWebElement EffectiveDatePolicy { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnSv")]
        public IWebElement btnInfoSavePolicy { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DS_DRD_DTC_Info_UcInf_btnCF")]
        public IWebElement CopyFromPolicy { get; set; }

        [FindsBy(How = How.Id, Using = "btnMoveImage")]
        public IWebElement MoveImage { get; set; }
        //SRT 08


        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_lblName")]
        public IWebElement MailTo1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_lblAddress")]
        public IWebElement MailToAddress1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_txtAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_txtReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_ddlPackaging")]
        public IWebElement Packaging { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_ddlCourierMethod")]
        public IWebElement CourierMethod1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_ddlPrintPages")]
        public IWebElement PrintOption1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_cbxRetEnvelope")]
        public IWebElement IncludeReturnEnvelope { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_cbxSigReq")]
        public IWebElement SignatureRequired1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_cbxSkipAddrValidation")]
        public IWebElement SkipAddressValidation1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_ddlOfficeName")]
        public IWebElement ReturnToOfficeName { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_txtAttention")]
        public IWebElement ReturnToAttention { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_lblOfficeAddress")]
        public IWebElement ReturnToAddress { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_txtReference")]
        public IWebElement ReturnToReference { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblDocName")]
        public IWebElement DocumentDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblDate")]
        public IWebElement IssueDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblType")]
        public IWebElement DocumentType1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblTab")]
        public IWebElement Tab1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblCopies")]
        public IWebElement Copies1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblColor")]
        public IWebElement Colour1 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblStatus")]
        public IWebElement Status1 { get; set; }



        #endregion
        public DocTemplateRequest GetDocTemplatesDefaultRequest(int DocTemplateTypeId)
        {
            return new DocTemplateRequest()
            {
                DocTemplateTypeCdID = DocTemplateTypeId,
                DocumentSource = DocSource.Both,
                RegionID = 1486,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }
        public DocumentRepository WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            if (SearchResultsTable.IsDisplayed() && SearchResultsTable.Exists())
                this.WaitCreation(element ?? SearchResultsTable);
            else
                this.WaitCreation(element ?? DocumentsTable);
            return this;
        }

        public DocumentRepository WaitForTemplatesScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Add);
            return this;
        }

        public DocumentRepository WaitForDocumentRepositoryTemplatesScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            if (FilteredTemplatesTab.IsDisplayed() && FilteredTemplatesTab.Exists())
            {
                this.WaitCreation(element ?? FilteredTemplatesTab);
                FilteredTemplatesTab.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                WaitForTemplatesScreenToLoad();
            }
            else
            {
                this.WaitCreation(element ?? DocumentsTab);
                FilteredTemplatesTab.FAClick();
                WaitForTemplatesScreenToLoad();
            }
            return this;
        }
        public DocumentRepository FinalizeDocumentUsingWebService(int fileID, int docID)
        {
            FileService.FinalizeDocument(RequestFactory.GetFinalizeDocumentRequest(fileID, docID));
            return this;
        }

        public DocumentRepository WaitForDocumentsScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? DocumentsTable);
            return this;
        }

        /// <summary>
        /// Wait for the Bottom Frame to Load.
        /// </summary>
        /// <returns></returns>
        public DocumentRepository WaitForPageToLoad()
        {
            //Wait for the whole page to Load
            this.SwitchToBottomFrame();
            this.WaitCreation(FastDriver.BottomFrame.btnDone);
            //

            this.SwitchToContentFrame();
            return this;
        }


        public DocumentRepository SelectDeliveryMethod(string method)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Method);
            this.Method.FASelectItemBySendingKeys(method);
            return this;
        }

        public DocumentRepository PerformDelivery(string method)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Method);
            Method.FASelectItem(method);
            Deliver.FAClick();
            return this;
        }


        public DocumentRepository ClickDeliver()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Deliver);
            this.Deliver.FAClick();
            return this;
        }

        public DocumentRepository SearchDocument(string source, string templateType, string templateDescription)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Source);
            Source.FASelectItem(source);
            TemplateType.FASelectItem(templateType);
            TemplateDescription.FASetText(templateDescription);
            FindNow.FAClick();

            this.WaitCreation(SearchResultsTable);

            return this;
        }

        public DocumentRepository WaitForElementToLoad(IWebElement Element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Element ?? ScannedDoc);

            return this;
        }

        public void UploadImgDoc(string docType, string docName, string addtlInfo)
        {
            Reports.TestStep = "Navigate to Doc Repository and Click on Upload.";
            FastDriver.LeftNavigation.Navigate<DocumentRepository>(@"Home>Order Entry>Document Repository").WaitForScreenToLoad();
            FastDriver.DocumentRepository.Upload.FAClick();
            Thread.Sleep(10000);

            Reports.TestStep = "Browse document and upload it (jpg).";
            if (!((Reports.DEPLOYDIR + "\\JpegFile.jpg").ToString() == "True"))
            {
                Support.GetEmbeddedImages("AutoSupport", "support.JpegFile.jpg", Reports.DEPLOYDIR + "\\JpegFile.jpg");
            }
            string FilePath = Reports.DEPLOYDIR + "\\JpegFile.jpg";
            FastDriver.UploadDocumentDlg.UploadFile(FilePath);

            Reports.TestStep = "Save Scanned doc,entering Name so that it will appear in Edit Disb Screen.";
            FastDriver.SaveDocumentDlg.SaveDocument(docType, docName, addtlInfo);
            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.NoTitleWindow, false);
            }
            catch (TimeoutException)
            {
                Reports.StatusUpdate("Saving... NoTitle window has closed fast.", true);
            }
        }

        /// <summary>
        /// This method uploads the scanned document.
        /// </summary>
        public void ScanImageDoc(string docType, string docName, string addtlInfo)
        {
            Reports.TestStep = "Navigate to document repository page and click on the scan button.";
            this.Open();
            this.FilteredTemplatesTab.FAClick();
            this.WaitForTemplatesScreenToLoad();
            this.Scan.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

            Reports.TestStep = "Click on Open button and load the image document.";
            FastDriver.ImagingWorkBench.WaitForWindowToLoad();
            FastDriver.ImagingWorkBench.ClickOpen(); //this is clicking using screen coordinates (Windows control)
            FastDriver.OpenImageDlg.OpenImage(Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif");
            FastDriver.BottomFrame.Done();
            Playback.Wait(4000); //wait for Save Document dialog (bacause we are using AutoIt to handle it)
            Reports.TestStep = "Save the TIF Doc.";
            FastDriver.SaveDocumentDlg.SaveDocumentUsingAutoIt(docType, docName, addtlInfo);
            FastDriver.WebDriver.WaitForWindowAndSwitch("Upload Document", false, 20);

            Reports.TestStep = "Navigate to document Repository and click edit on the created status.";
            this.Open();
        }


        public DocumentRepository SelectAllDocuments()
        {
            this.SwitchToContentFrame();
            var docs = DocumentsTable.FindElements(By.XPath(".//tr")).GetAllVisible();

            Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

            Playback.Wait(500); // need this
            for (int i = 0; i < docs.Count; i++)
            {
                docs[i].FAClick(); // click on row to select
            }

            Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

            return this;
        }

        public DocumentRepository SelectRowsByIndex(List<int> rowIndexesToSelect)
        {
            this.SwitchToContentFrame();
            List<IWebElement> rows = new List<IWebElement>();
            rowIndexesToSelect.ForEach(rowIndex => rows.Add(DocumentsTable.PerformTableAction(rowIndex, 4, TableAction.GetCell).Element));

            Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

            Playback.Wait(500); // need this
            rows.ForEach(row => row.FAClick());

            Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

            return this;
        }

        public DocumentRepository SelectDocumentsByName(List<string> documentsToSelect)
        {
            WaitForScreenToLoad();
            List<IWebElement> documents = new List<IWebElement>();
            documentsToSelect.ForEach(documentName => documents.Add(DocumentsTable.PerformTableAction(4, documentName, 4, TableAction.GetCell).Element));

            Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

            Playback.Wait(500); // need this
            documents.ForEach(row => row.FAClick());

            Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

            return this;
        }

        //public DocumentRepository SelectRowsByIndex(List<int> rowIndexesToSelect)
        //{
        //    this.SwitchToContentFrame();
        //    List<IWebElement> rows = new List<IWebElement>();
        //    rowIndexesToSelect.ForEach(rowIndex => rows.Add(DocumentsTable.PerformTableAction(rowIndex, 4, TableAction.GetCell).Element));

        //    Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

        //    Playback.Wait(500); // need this
        //    rows.ForEach(row => row.FAClick());

        //    Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

        //    return this;
        //}

        //public DocumentRepository SelectDocumentsByName(List<string> documentsToSelect)
        //{
        //    WaitForScreenToLoad();
        //    List<IWebElement> documents = new List<IWebElement>();
        //    documentsToSelect.ForEach(documentName => documents.Add(DocumentsTable.PerformTableAction(4, documentName, 4, TableAction.GetCell).Element));

        //    Report.UpdateLog(WebDriver, "Hold Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.PressModifierKeys(UIModifierKeys.Control)); // hold down CTRL key

        //    Playback.Wait(500); // need this
        //    documents.ForEach(row => row.FAClick());

        //    Report.UpdateLog(WebDriver, "Release Key", UIModifierKeys.Control.ToString(), () => UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control)); // release CTRL key

        //    return this;
        //}

        public DocumentRepository Open()
        {

            FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
            return WaitForScreenToLoad();
        }

        public DocumentRepository WaitForInfoTabToLoad()
        {
            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return btnInfoSave.IsDisplayed() || Save.IsDisplayed();
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }

            });

            return this;
        }

        public DocumentRepository WaitForDocumentOnDocumentTable(string DocumentName)
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromMinutes(5));

            try
            {
                wait.Until(d =>
                {
                    try
                    {
                        this.Open();
                        this.DocumentsTab.Click();
                        this.WaitForDocumentsScreenToLoad();

                        //Column 4 is the fourth under the Name column (which is the first to show up)
                        this.DocumentsTable.FindElements(By.CssSelector("tr td:nth-child(4)")).First(element => element.FAGetText().Trim() == DocumentName);
                        return true;

                    }
                    catch (Exception)
                    {
                        return false;
                    }

                });
            }
            catch (WebDriverException)
            {
                Support.Fail("Could not find " + DocumentName + " on Document Table");
            }


            return this;
        }

        public DocumentRepository WaitForAssociateDocTabToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            this.WaitCreation(AssPackageTable);
            return this;
        }

        public DocumentRepository WaitForRTMPackageTabToLoad()
        {
            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return AddAddressees.IsDisplayed();
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }

            });

            return this;
        }

        public DocumentRepository ClickLastPhrase()
        {
            string rCount = FastDriver.DocumentRepository.DocumentsTable.FindElements(By.CssSelector("tr")).Count.ToString();
            for (int rCounter = 0; rCounter < Int32.Parse(rCount); rCounter++)
            {
                if (((IWebElement)FastDriver.DocumentRepository.DocumentsTable.FindElement(By.CssSelector("#TC_DS_DRD_DTC_SrcRlt_gdSR_" + rCounter + "_Name"))).FAGetText().Equals("Bus Source"))
                {
                    ((IWebElement)FastDriver.DocumentRepository.DocumentsTable.FindElement(By.CssSelector("#TC_DS_DRD_DTC_SrcRlt_gdSR_" + rCounter + "_Name"))).FAClick();

                    if (rCounter == 1001)
                    {
                        Reports.StatusUpdate("Document Bus Source added to Doc Repository", false);
                    }
                    else
                    {
                        Reports.StatusUpdate("Document Bus Source added to Doc Repository", true);
                    }
                    break;
                }
            }
            return this;
        }

        public void validateSequenceOfDocuments()
        {
            int NumOne = 0;
            int NumTwo = 0;
            int ResultsCount = 0;
            this.SwitchToContentFrame();
            this.WaitCreation(DocumentsTable);
            for (int i = 1; i <= DocumentsTable.GetRowCount(); i++)
            {
                IWebElement row = DocumentsTable.FAFindElements(ByLocator.TagName, "tr").GetAllVisible()[i];
                string Text = row.Text;
                if (Text.Contains("Miscellaneous"))
                {
                    NumOne = i;
                    ResultsCount++;
                }
                else if (Text.Contains("Final Closing"))
                {
                    NumTwo = i;
                    ResultsCount++;
                }

                if (ResultsCount == 2)
                    break;
            }
        }
    }
    public class ImageDetailsScreen : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnChangeType")]
        public IWebElement Change { get; set; }

        [FindsBy(How = How.Id, Using = "lblComments")]
        public IWebElement FASTSearch { get; set; }

        [FindsBy(How = How.LinkText, Using = "Change Image Type")]
        public IWebElement Changecell { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='pnlImgDetails']/table")]
        public IWebElement ImageDetailsTable { get; set; }
        #endregion

        #region Useful Methods
        public ImageDetailsScreen WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FASTSearch);
            return this;
        }
        #endregion

    }

    public class EditDocumentDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtEditDocName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "chkChgType")]
        public IWebElement ChangeDocumentType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentType")]
        public IWebElement DocumentType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentName")]
        public IWebElement DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "txtEditDocName")]
        public IWebElement EditDocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "chkCrtCpy")]
        public IWebElement CreateCopy { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddInformation")]
        public IWebElement AdditionalInformaton { get; set; }
        [FindsBy(How = How.Id, Using = "txtFileNo")]
        public IWebElement FileNo { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comment { get; set; }

        [FindsBy(How = How.Id, Using = "chxCreateaCopy")]
        public IWebElement CreateaCopy { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Edit Document']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement EditDocument_Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Edit Document']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement EditDocument_Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFileNum")]
        public IWebElement EditFileNum { get; set; }

        [FindsBy(How = How.Id, Using = "divEditDocumentNameDialog")]
        public IWebElement EditDocumentNameDialog { get; set; }


        [FindsBy(How = How.Id, Using = "txtDocName")]
        public IWebElement EditDocName { get; set; }

        [FindsBy(How = How.Id, Using = "chxChangeDocType")]
        public IWebElement ChangeDocTypeChk { get; set; }


        [FindsBy(How = How.Id, Using = "ddlDocType")]
        public IWebElement DocumentTypeCbo { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDocName")]
        public IWebElement DocumentNameCbo { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement EditDocumentComment { get; set; }

        [FindsBy(How = How.Id, Using = "txtDocuName")]
        public IWebElement EditDocNameChkTrue { get; set; }

        [FindsBy(How = How.Id, Using = "txtaddInfo")]
        public IWebElement EditDocumentAdditionalInfo { get; set; }
        
        
        
        

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement comments { get; set; }

        #endregion

        public EditDocumentDlg WaitForScreenToLoad(IWebElement e = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(e ?? Name);

            return this;
        }
    }

    public class TitleSelection : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "dgSelect_1_lblName")]
        public IWebElement TitleReport { get; set; }

        #endregion
        public TitleSelection WaitForScreenToLoad()
        {

            WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(30));
            wait.Until(d =>
            {
                this.SwitchToContentFrame();
                return Select.Exists();
            });
            return this;
        }

    }

    public class Epolicy : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "StatusMessage2")]
        public IWebElement Message { get; set; }

        #endregion

    }
}
