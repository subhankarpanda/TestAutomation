using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class DocumentRetainDeleteDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "Retain")]
		public IWebElement RetainInQueue { get; set; }

		[FindsBy(How = How.Id, Using = "Delete")]
		public IWebElement Delete { get; set; }

		#endregion

	}
}
