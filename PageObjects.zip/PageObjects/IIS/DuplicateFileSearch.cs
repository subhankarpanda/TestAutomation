﻿using System;
using System.Threading;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class DuplicateFileSearch : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdContinue")]
        public IWebElement SkipSearchButton { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_ddType1")]
        public IWebElement Buyer1Type { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textName1")]
        public IWebElement Buyer1FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textMiddle1")]
        public IWebElement Buyer1MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textLast1")]
        public IWebElement Buyer1LastName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSuffix1")]
        public IWebElement Buyer1Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPName1")]
        public IWebElement Buyer1SpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPMiddle1")]
        public IWebElement Buyer1SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPLast1")]
        public IWebElement Buyer1SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPSuffix1")]
        public IWebElement Buyer1SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_ddType2")]
        public IWebElement Buyer2Type { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textName2")]
        public IWebElement Buyer2FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textMiddle2")]
        public IWebElement Buyer2MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textLast2")]
        public IWebElement Buyer2LastName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSuffix2")]
        public IWebElement Buyer2Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPName2")]
        public IWebElement Buyer2SpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPMiddle2")]
        public IWebElement Buyer2SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPLast2")]
        public IWebElement Buyer2SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "ucBuyer_textSPSuffix2")]
        public IWebElement Buyer2SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_txtAPNTaxNo")]
        public IWebElement PropertyAddressAPNTaxNo { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textStreet")]
        public IWebElement PropertyAddressStreet1 { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textAddress1")]
        public IWebElement PropertyAddressStreet2 { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textAddress2")]
        public IWebElement PropertyAddressStreet3 { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textAddress3")]
        public IWebElement PropertyAddressStreet4 { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textCity")]
        public IWebElement PropertyAddressCity { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_ddState")]
        public IWebElement PropertyAddressState { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textZip")]
        public IWebElement PropertyAddressZip { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_textCounty")]
        public IWebElement PropertyCounty { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_ddCountry")]
        public IWebElement PropertyCountry { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GABIDCode { get; set; }
        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement NameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboSalesRep1")]
        public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboSalesRep2")]
        public IWebElement SalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_labelCountyCountry")]
        public IWebElement LT_Reg { get; set; }

        [FindsBy(How = How.Id, Using = "ucPropertyAddress_labelCtStZp")]
        public IWebElement CityProvincePostalCd { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement NewLenderInformationName1 { get; set; }

        #endregion

        public DuplicateFileSearch Open()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            this.WaitForScreenToLoad();

            return this;
        }

        public DuplicateFileSearch WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SkipSearchButton);

            return this;
        }

        public QuickFileEntry ClickSkipSearchButton()
        {
            WaitForScreenToLoad();
            SkipSearchButton.FAClick();
            return FastDriver.QuickFileEntry;
        }

        public DuplicateFileSearchResults ClickFindNow()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(FindNow);
            FindNow.FAClick();
            return FastDriver.DuplicateFileSearchResults;
        }

        public void SetBuyerInfo(string Buyer1Type, string Buyer1FirstName, string Buyer1LastName, string Buyer2Type, string Buyer2FirstName, string Buyer2LastName, string Buyer2SpouseName)
        {
            this.SwitchToContentFrame();
            FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem(Buyer1Type);
            FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText(Buyer1FirstName);
            if (!(Buyer1LastName == ""))
            {
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText(Buyer1LastName);
            }
            FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem(Buyer2Type);
            FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText(Buyer2FirstName);
            FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText(Buyer2LastName);
            FastDriver.DuplicateFileSearch.Buyer2SpouseFirstName.FASetText(Buyer2SpouseName);
        }
    }
}