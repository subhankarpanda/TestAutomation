using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class DuplicateFileSearchResults : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdView")]
        public IWebElement View { get; set; }

        [FindsBy(How = How.Id, Using = "cmdSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "cmdBack")]
        public IWebElement GoBack { get; set; }

        [FindsBy(How = How.Id, Using = "cmdContinue")]
        public IWebElement Continue { get; set; }

        [FindsBy(How = How.Id, Using = "dGridResults")]
        public IWebElement SearchResults { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Filen1 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Filen2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Filen3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Filen4 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Filen5 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridResults_1_labelProperty")]
        public IWebElement SearchResultsPane { get; set; }

        [FindsBy(How = How.Id, Using = "dGridResults")]
        public IWebElement SearchResultsTable { get; set; }

        #endregion

        public DuplicateFileSearchResults WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SearchResults);

            return this;
        }

        public string SearchFileInResultsTable(string FileNum)
        {
            this.SwitchToContentFrame();

            IWebElement element = FastDriver.DuplicateFileSearchResults.SearchResultsTable.PerformTableAction("File No.", FileNum, "File No.", TableAction.Click).Element;
            string FileExistStatus = element.FAGetText().ToString().Trim();
            return FileExistStatus;
        }

        public int VerifyFileDisplayedInTabl(string FileNumber)
        {
            this.SwitchToContentFrame();
            return FastDriver.WebDriver.FindElements(By.XPath("//table[@id='dGridResults']//*[text()='" + FileNumber + "']")).Count;
        }

        public DuplicateFileSearch ClickGoBack()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GoBack, 5);
            GoBack.FAClick();
            return FastDriver.GetPage<DuplicateFileSearch>();
        }

        public FileHomepage ClickSelect()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Select, 5);
            Select.FAClick();
            return FastDriver.GetPage<FileHomepage>();
        }

        public FileSummaryDlg ClickView()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Select, 5);
            View.FAClick();
            return FastDriver.GetPage<FileSummaryDlg>();
        }

        public QuickFileEntry ClickContinue()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Select, 5);
            Continue.FAClick();
            return FastDriver.GetPage<QuickFileEntry>();
        }
    }
}
