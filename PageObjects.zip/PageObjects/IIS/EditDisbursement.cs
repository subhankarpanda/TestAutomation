using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Collections.Generic;


namespace FASTSelenium.PageObjects.IIS
{
    public class EditDisbursement : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlDisbType")]
        public IWebElement DisburseAs { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "txtRef")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSourceOfWireIns")]
        public IWebElement SourceofwireIns { get; set; }

        [FindsBy(How = How.Id, Using = "ddlAcnt")]
        public IWebElement FromAccount { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddDoc")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemoveDoc")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "ddlWireAcctNo")]
        public IWebElement OriginatorAcctNo { get; set; }

        [FindsBy(How = How.Id, Using = "txtWireInfo")]
        public IWebElement OriginatorInformation { get; set; }

        [FindsBy(How = How.Id, Using = "txtABANum")]
        public IWebElement ReceivingBankABANumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtRecBnkName")]
        public IWebElement ReceivingBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtRecBankAddr")]
        public IWebElement ReceivingBankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtBnAcctNumUSA")]
        public IWebElement BeneficiaryAccountNumber { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/FastNetApp1/Images2/DataGovernance.GIF")]
        public IWebElement CheckMark { get; set; }

        [FindsBy(How = How.Id, Using = "btnRefresh")]
        public IWebElement Refresh { get; set; }

        [FindsBy(How = How.Id, Using = "txtBenfryName")]
        public IWebElement BeneficiaryName { get; set; }

        [FindsBy(How = How.Id, Using = "txtBenfryAddr")]
        public IWebElement BeneficiaryAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote1")]
        public IWebElement BeneficiaryNote1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote2")]
        public IWebElement BeneficiaryNote2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote3")]
        public IWebElement BeneficiaryNote3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote4")]
        public IWebElement BeneficiaryNote4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtIntBIC")]
        public IWebElement IntermediaryBankBIC { get; set; }

        [FindsBy(How = How.Id, Using = "txtIntBankName")]
        public IWebElement IntermediaryBankBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtIntBankAdd")]
        public IWebElement IntermediaryBankBankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtBicAcc")]
        public IWebElement BeneficiaryBankBIC { get; set; }

        [FindsBy(How = How.Id, Using = "txtBenBank")]
        public IWebElement BeneficiaryBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtBenbankAdd")]
        public IWebElement BeneficiarybankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp8")]
        public IWebElement HoldInformation { get; set; }

        [FindsBy(How = How.Id, Using = "btnRelHold")]
        public IWebElement ReleaseHold { get; set; }

        [FindsBy(How = How.Id, Using = "txtHoldFor")]
        public IWebElement HoldFor { get; set; }

        [FindsBy(How = How.Id, Using = "txtUntil")]
        public IWebElement Until { get; set; }

        [FindsBy(How = How.Id, Using = "txtPurOfHold")]
        public IWebElement PurposeOfHold { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement HoldInformationTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtRelDate")]
        public IWebElement ReleaseDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtVochrDesc")]
        public IWebElement VoucherDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtVochrMemo")]
        public IWebElement VoucherMemo { get; set; }

        [FindsBy(How = How.Id, Using = "txtVochrDetail")]
        public IWebElement VoucherChargeDetail { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement DisbursementRecapTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblStatus")]
        public IWebElement StatusLbl { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp2")]
        public IWebElement OpenDisbDetails { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp7")]
        public IWebElement Wireinstruction { get; set; }

        [FindsBy(How = How.Id, Using = "lblUserName")]
        public IWebElement UserName { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Errormessage { get; set; }

        [FindsBy(How = How.Id, Using = "Img3")]
        public IWebElement ThumbnailImage { get; set; }

        [FindsBy(How = How.Id, Using = "chkApproval1")]
        public IWebElement Approve1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtPayee")]
        public IWebElement DisbursementPayee { get; set; }

        [FindsBy(How = How.Id, Using = "tblSourceDoc")]
        public IWebElement WireInstructionTable { get; set; }

        [FindsBy(How = How.Id, Using = "Img3")]
        public IWebElement Image { get; set; }

        [FindsBy(How = How.Id, Using = "Img3")]
        public IWebElement Image1 { get; set; }

        [FindsBy(How = How.Id, Using = "Img3")]
        public IWebElement Image2 { get; set; }

        [FindsBy(How = How.Id, Using = "chkApproval2")]
        public IWebElement Approval2 { get; set; }

        [FindsBy(How = How.Id, Using = "Img3")]
        public IWebElement smsfastFases2thumbnailgif { get; set; }

        [FindsBy(How = How.Id, Using = "txtbnAcctNumConfirm")]
        public IWebElement BeneficiaryConfirmAccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "lblT32ExtDate")]
        public IWebElement Trust32ExtractDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtPayeeNameOnly")]
        public IWebElement DisbursementPayee1 { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "lblPayee")]
        public IWebElement Payee { get; set; }

        [FindsBy(How = How.Id, Using = "lblFromDocRep")]
        public IWebElement SourseOfWireInsLabel { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblDisbRecap']//*[text()='HELD']")]
        public IWebElement HeldStatus { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblDisbRecap']//*[text()='PENDING']")]
        public IWebElement PendingStatus { get; set; }

        [FindsBy(How = How.Id, Using = "lblBnkCode")]
        public IWebElement BankCode { get; set; }

        [FindsBy(How = How.Id, Using = "lblBnkName")]
        public IWebElement BankName { get; set; }

        [FindsBy(How = How.Id, Using = "lblPostdDate")]
        public IWebElement PostedOnDate { get; set; }

        [FindsBy(How = How.Id, Using = "lblDocName")]
        public IWebElement ImageName { get; set; }

        [FindsBy(How = How.Id, Using = "Img1")]
        public IWebElement ImageCloseBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'DataGovernance.GIF')]")]
        public IWebElement DataGovernanceImg { get; set; }

        [FindsBy(How = How.ClassName, Using = "ui-dialog-title")]
        public IWebElement TIFFEmptyWindowHeader { get; set; }

       /* [FindsBy(How = How.XPath, Using = "//span[contains(text(),'http -- Webpage Dialog')]")] -- working fine 15/03/2016
        public IWebElement TIFFEmptyWindowHeader1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/div/span[contains(@class,'ui-dialog-title')]")] -- working fine 15/03/2016
        public IWebElement TIFFEmptyWindowHeader2 { get; set; }*/

        [FindsBy(How = How.XPath, Using = "//span[contains(@class, 'ui-button-icon-primary')]")]// ui-icon ui-icon-closethick
        public IWebElement TIFFEmptyWindowCloseButton { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table#tblHldInfo td#cBntExp8")]
        public IWebElement HoldInformationIcon { get; set; }

        [FindsBy(How = How.Id, Using = "lblAmt")]
        public IWebElement DisbursementAmnt { get; set; }

        [FindsBy(How = How.Id, Using = "lblIssdDate")]
        public IWebElement IssueDate { get; set; }

        [FindsBy(How = How.Id, Using = "DocumentNo")]
        public IWebElement DocumentNo { get; set; }

        [FindsBy(How = How.Id, Using = "lblMnlChkRsn")]
        public IWebElement ManualCheckReason { get; set; }

        #region SRT-ServReq
        //Team                           :  SRT-Team2
        //Iteration                      :  r08
        //Appended By/ Created By        :  Diego Hilario
        [FindsBy(How = How.Id, Using = "btnNote1")]
        public IWebElement Note1Button { get; set; }

        [FindsBy(How = How.Id, Using = "btnNote2")]
        public IWebElement Note2Button { get; set; }

        [FindsBy(How = How.Id, Using = "btnNote3")]
        public IWebElement Note3Button { get; set; }

        [FindsBy(How = How.Id, Using = "btnNote4")]
        public IWebElement Note4Button { get; set; }
        #endregion
        #endregion

        public EditDisbursement WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? StatusLbl);

            return this;
        }

        public void SaveReleaseHold()
        {
            Reports.TestStep = "Release Hold and Save the changes made.";
            FastDriver.ActiveDisbursementSummary.Edit.FAClick();
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.ReleaseHold.FAClick();
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        public void SaveHoldDays(String Days)
        {
            Reports.TestStep = "Save the Hold Days Info";
            string value = string.Empty;
            if (DateTime.Today.AddDays(Convert.ToInt32(Days)).DayOfWeek.ToString() == "Saturday" || DateTime.Today.AddDays(Convert.ToInt32(Days)).DayOfWeek.ToString() == "Sunday")
                value = (Convert.ToInt32(Days) + 3).ToString();
            else
                value = Days;
            int Count1 = FastDriver.WebDriver.FindElements(By.XPath("//td[@id='cBntExp8' and @class='cButtonExpandFalse']")).Count();
            if (Count1 > 0)
            {
                FastDriver.EditDisbursement.HoldInformation.FAClick();
            }
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.HoldFor.FASetText(value);
            if (Days != "6")
            {
                FastDriver.EditDisbursement.PurposeOfHold.FASetText("Holding the disbursement", true);
            }
            FastDriver.BottomFrame.Save();
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
        }

        public void ConvertToWire()
        {
            Reports.TestStep = "Convert to wire attach Instruction.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.DisburseAs.FASelectItem("Wire");
            FastDriver.EditDisbursement.SourceofwireIns.FASelectItem("From Document Repository");
            FastDriver.EditDisbursement.Add.FAClick();

            Reports.TestStep = "Select the wire Instruction Doc.";
            FastDriver.SelectWireInstructionsDlg.SelectWireInstruction();

            Reports.TestStep = "Convert to wire attach Instruction.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            FastDriver.EditDisbursement.ReceivingBankABANumber.FASetText("12346689");
            FastDriver.EditDisbursement.ReceivingBankName.FASetText("ReceivingBankName");
            FastDriver.EditDisbursement.ReceivingBankAddress.FASetText("ReceivingBangAddress");
            FastDriver.EditDisbursement.BeneficiaryAccountNumber.FASetText("12356465");
            FastDriver.EditDisbursement.BeneficiaryConfirmAccountNumber.FASetText("12356465");
            FastDriver.EditDisbursement.BeneficiaryName.FASetText("BeneficiaryName");
            FastDriver.EditDisbursement.BeneficiaryNote1.FASetText("Benificiary Note 1");
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        public void ClickOnWireInstructionImageAndApprove(string ApprovalType)
        {
            Reports.TestStep = "Click on Wire Instruction Image.";
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            // FastDriver.EditDisbursement.Image.FAClick();
            FastDriver.EditDisbursement.ImageName.FAClick();

            Reports.StatusUpdate("Verify Image Load: Look for Screenshot", true);
            FastDriver.EditDisbursement.ImageCloseBtn.FAClick();
            //try
            //{
            //    BrowserWindow sBr = new BrowserWindow();
            //    sBr.SearchProperties["ClassName"] = "Internet Explorer_TridentDlgFrame";
            //    sBr.SearchProperties.Add("Name", "Fastimages", PropertyExpressionOperator.Contains);
            //    sBr.SetFocus();
            //}
            //catch { }
            //Keyboard.SendKeys("%{SPACE}C");
            //Thread.Sleep(10000);


            Reports.TestStep = "Approve Document repository for wire DGC.";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.EditDisbursement.WaitForScreenToLoad();
            if (ApprovalType == "FirstApproval")
            {
                if (FastDriver.EditDisbursement.Approve1.Enabled.ToString() == "True")
                {
                    FastDriver.EditDisbursement.Approve1.FASetCheckbox(true);
                }
            }
            if (ApprovalType == "SecondApproval")
            {
                if (FastDriver.EditDisbursement.Approval2.Enabled.ToString() == "True")
                {
                    FastDriver.EditDisbursement.Approval2.FASetCheckbox(true);
                }
            }
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        public void VerifyHELDstatus()
        {
            int Count1 = FastDriver.WebDriver.FindElements(By.XPath("//table[@id='tblDisbRecap']//*[text()='HELD']")).Count();
            if (!(Count1 > 0))
            {
                Reports.StatusUpdate("Held Status does not appear in Disbursement Recap Table", false);
            }
        }

        public void VerifyPENDINGstatus()
        {
            int Count2 = FastDriver.WebDriver.FindElements(By.XPath("//table[@id='tblDisbRecap']//*[text()='PENDING']")).Count();
            if (!(Count2 > 0))
            {
                Reports.StatusUpdate("Pending Status does not appear in Disbursement Recap Table", false);
            }
        }

        public void VerifyDataGovernanceImg()
        {
            int Count1 = FastDriver.WebDriver.FindElements(By.XPath("//img[contains(@src,'DataGovernance.GIF')]")).Count();
            if (Count1 > 0)
            {
                Reports.StatusUpdate("Data Governance Check Mark appears.", true);
            }
            else
            {
                Reports.StatusUpdate("Data Governance Check Mark does not appear.", false);
            }
        }

        public void VerifyBrokenImg()
        {
            int Count2 = FastDriver.WebDriver.FindElements(By.XPath("//img[contains(@src,'BrokenLink.GIF')]")).Count();
            if (Count2 > 0)
            {
                Reports.StatusUpdate("Broken Image appears.", true);
            }
            else
            {
                Reports.StatusUpdate("Broken Image does not appear.", false);
            }
        }

        public void Expand(IWebElement button)
        {
            if (button.GetAttribute("class") == "cButtonExpandFalse")
                button.FAClick();
        }

        public Dictionary<string, string> GetWireDetails()
        {
            this.WaitForScreenToLoad();
            if (!this.DisburseAs.FAGetSelectedItem().Equals("Wire"))
                this.DisburseAs.FASelectItem("Wire");
            Thread.Sleep(4000);
            Dictionary<string, string> WireInstructions = new Dictionary<string, string>();
            WireInstructions.Add("ABANumber", this.ReceivingBankABANumber.FAGetValue());
            WireInstructions.Add("BankName", this.ReceivingBankAddress.FAGetValue());
            WireInstructions.Add("BankAddress", this.ReceivingBankAddress.FAGetValue());
            WireInstructions.Add("AccountNumber", this.BeneficiaryAccountNumber.FAGetValue());
            return WireInstructions;

        }
    }
    public class Dlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Name, Using = "File name:")]
        public IWebElement Filename { get; set; }

        [FindsBy(How = How.Name, Using = "Open")]
        public IWebElement Open { get; set; }

        #endregion

    }
}
