using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class EditPhraseMarkerDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cBntExp50")]
		public IWebElement ExpandForm { get; set; }

		[FindsBy(How = How.Id, Using = "txtFormName")]
		public IWebElement FormName { get; set; }

		[FindsBy(How = How.Id, Using = "chkPBrk")]
		public IWebElement PageBreak { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "Td1")]
		public IWebElement ExpandAutooutlineNumber { get; set; }

		[FindsBy(How = How.Id, Using = "chkAuto")]
		public IWebElement AutoOutlineStart { get; set; }

		[FindsBy(How = How.Id, Using = "Button1")]
		public IWebElement Finish { get; set; }

		#endregion

	}
}
