using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class EditorDeleteDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnUnSelect")]
		public IWebElement UnSelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_0_chkPhrasSel")]
		public IWebElement FirstCheckBox { get; set; }

		[FindsBy(How = How.Id, Using = "txtNote")]
		public IWebElement ReasonNote { get; set; }

		#endregion

        public EditorDeleteDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Title");
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? SelectAll);

            return this;
        }

	}
}
