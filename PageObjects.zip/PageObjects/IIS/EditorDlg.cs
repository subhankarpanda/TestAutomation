using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class EditorDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnUnSelect")]
		public IWebElement UnSelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_0_chkPhrasSel")]
		public IWebElement Phrases0Delete { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_1_chkPhrasSel")]
		public IWebElement Phrases1Delete { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_2_chkPhrasSel")]
		public IWebElement Phrases2Delete { get; set; }

		[FindsBy(How = How.Id, Using = "txtNote")]
		public IWebElement Note { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Phrases0Name { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Phrases1Name { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_0_lblPhraseName")]
		public IWebElement Phrases2Name { get; set; }

		[FindsBy(How = How.LinkText, Using = "Reason: ")]
		public IWebElement Reason { get; set; }

		[FindsBy(How = How.Id, Using = "grdPhrases_grdPhrases")]
		public IWebElement PharsesTable { get; set; }

		#endregion

        public EditorDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? PharsesTable);
            return this;
        }
	}
}
