using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;


namespace FASTSelenium.PageObjects.IIS
{
    public class GenericEmail : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkBusinessSourceRef")]
        public IWebElement BusinessSourceReference { get; set; }

        [FindsBy(How = How.Id, Using = "chkFileNum")]
        public IWebElement FileNumberChk_GenericEmail { get; set; }

        [FindsBy(How = How.Id, Using = "chkPropertyAddr")]
        public IWebElement PropertyAddressChk_GenericEmail { get; set; }


        [FindsBy(How = How.Id, Using = "chkClear")]
        public IWebElement ClearChk_GenericEmail { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnEmail")]
        public IWebElement Email { get; set; }

        [FindsBy(How = How.Id, Using = "btnFrom")]
        public IWebElement FromButton { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_txtFrom")]
        public IWebElement From { get; set; }

        [FindsBy(How = How.Id, Using = "btnTo")]
        public IWebElement ToButton { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_txtTo")]
        public IWebElement To { get; set; }

        [FindsBy(How = How.Id, Using = "btnCc")]
        public IWebElement CcButton { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_txtCC")]
        public IWebElement CC { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_txtSubject")]
        public IWebElement EmailSubject { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_FontName")]
        public IWebElement FontNameType { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_FontSize")]
        public IWebElement FontSize { get; set; }

        [FindsBy(How = How.Id, Using = "Button1")]
        public IWebElement Bold { get; set; }

        [FindsBy(How = How.Id, Using = "Button2")]
        public IWebElement Italic { get; set; }

        [FindsBy(How = How.Id, Using = "Button3")]
        public IWebElement Underline { get; set; }

        [FindsBy(How = How.Id, Using = "Button4")]
        public IWebElement AlignLeft { get; set; }

        [FindsBy(How = How.Id, Using = "Button5")]
        public IWebElement Center { get; set; }

        [FindsBy(How = How.Id, Using = "Button6")]
        public IWebElement AlignRight { get; set; }

        [FindsBy(How = How.Id, Using = "btnMsgSpellCheck")]
        public IWebElement CheckSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "btnSubjectSpellCheck")]
        public IWebElement CheckSubjectSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabContainer_tabEmailHistory")]
        public IWebElement EmailHistoryTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabContainer_tabGenericEmail")]
        public IWebElement GenericEmailTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabGenericEmail_txtMessage")]
        public IWebElement MessageBody { get; set; }
        

        #endregion
        public GenericEmail Open()
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.GenericEmail>("Home>Order Entry>Generic Email");
            this.WaitForScreenToLoad();

            return this;
        }
        public GenericEmail WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GenericEmailTab);

            return this;
        }
        public GenericEmail VerifyFromToCCSubject(string fromEmail, string filenumber = "", string addressline = "", string Subjecttext = "", string toaddress = "", string ccaddress = "")
        {
            if ((!string.IsNullOrEmpty(filenumber)) && (!string.IsNullOrEmpty(addressline)))
                Support.AreEqual("File Number-" + filenumber + "-Address-" + addressline, EmailSubject.FAGetValue());
            else
                Support.AreEqual(Subjecttext, EmailSubject.FAGetValue());
            Support.AreEqual(fromEmail, From.FAGetValue());
            Support.AreEqual(toaddress, To.FAGetValue());
            Support.AreEqual(ccaddress, CC.FAGetValue());
            return this;
        }

        public GenericEmail SetToCCSubMessage(string toaddress = null, string ccaddress = null, string subject = null, string fontName = null, string fontsize = null, string Messagebody = null)
        {
            if (!string.IsNullOrEmpty(toaddress))
                To.FASetText(toaddress);
            if (!string.IsNullOrEmpty(ccaddress))
                CC.FASetText(ccaddress);
            if (!string.IsNullOrEmpty(subject))
                EmailSubject.FASetText(subject);
            if (!string.IsNullOrEmpty(fontName))
                FontNameType.FASelectItem(fontName);
            if (!string.IsNullOrEmpty(fontsize))
                FontSize.FASelectItem(fontsize);
            if (!string.IsNullOrEmpty(Messagebody))
            {
                this.WaitForFrameAndSwitch("tabContainer_tabGenericEmail_tbContentElement");
                IJavaScriptExecutor js = this.WebDriver as IJavaScriptExecutor;
                IWebElement body = WebDriver.FindElement(By.CssSelector("body"));
                js.ExecuteScript("arguments[0].innerHTML =" + "'" + Messagebody + "'", body);
                this.SwitchToContentFrame();
            }
            return this;
        }




    }
    public class Editor : PageObject
    {
        #region WebElements

        #endregion

    }
    public class EmailHistory : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_txtDateFilter")]
        public IWebElement FilterByDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_btnApply")]
        public IWebElement Apply { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_dgridHistory_0_cmdshowmessage")]
        public IWebElement EmailMessage { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_dgridHistory_dgridHistory")]
        public IWebElement MailHistoryResults { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_dgridHistory_0_labelDateSent")]
        public IWebElement DateSentPane { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_dgridHistory_0_labelSubject")]
        public IWebElement SubjestPane { get; set; }

        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_dgridHistory_0_labelRecipeints")]
        public IWebElement RecepientPane { get; set; }
        [FindsBy(How = How.Id, Using = "tabContainer_tabEmailHistory_dgridHistory_dgridHistory")]
        public IWebElement HistoryTable { get; set; }


        #endregion
        public EmailHistory WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(HistoryTable);

            return this;
        }
        public EmailHistory VerifyDatafromHistory(int rowindex, int columnindex, string CellText)
        {

            OperationResult result = HistoryTable.PerformTableAction(rowindex, columnindex, TableAction.GetText);
            Support.AreEqual(result.Message.Trim(), CellText);

            return this;
        }
        public EmailHistory VerifyDatafromHistory(int rowindex, int columnindex, DateTime date)
        {

            OperationResult result = HistoryTable.PerformTableAction(rowindex, columnindex, TableAction.GetText);
            if (result.Message.Equals(date.ToString("M/d/yyyy")))
                Support.AreEqual(result.Message.Trim(), date.ToString("M/d/yyyy"));
            else

                Support.AreEqual(result.Message.Trim(), date.ToString("MM/dd/yyyy"));

            return this;
        }

    }
}
