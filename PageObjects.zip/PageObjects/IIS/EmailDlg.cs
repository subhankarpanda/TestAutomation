using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class EmailDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkBusinessSourceRef")]
        public IWebElement BusinessSourceReference { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnEmail")]
        public IWebElement Email { get; set; }

        [FindsBy(How = How.Id, Using = "btnFrom")]
        public IWebElement From { get; set; }

        [FindsBy(How = How.Id, Using = "txtFrom")]
        public IWebElement FromText { get; set; }

        [FindsBy(How = How.Id, Using = "btnTo")]
        public IWebElement To { get; set; }

        [FindsBy(How = How.Id, Using = "txtTo")]
        public IWebElement ToText { get; set; }

        [FindsBy(How = How.Id, Using = "btnCc")]
        public IWebElement Cc { get; set; }

        [FindsBy(How = How.Id, Using = "txtCC")]
        public IWebElement CCText { get; set; }

        [FindsBy(How = How.Id, Using = "DeliveryFormat")]
        public IWebElement DeliveryFormat { get; set; }

        [FindsBy(How = How.Id, Using = "txtSubject")]
        public IWebElement Subject { get; set; }

        [FindsBy(How = How.Id, Using = "txtMessage")]
        public IWebElement Message { get; set; }

        [FindsBy(How = How.Id, Using = "imgDocument")]
        public IWebElement imgDocument { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
        public IWebElement Buyer { get; set; }

        [FindsBy(How = How.Id, Using = "pubDocument")]
        public IWebElement pubDocument { get; set; }

        [FindsBy(How = How.Id, Using = "chkSeller")]
        public IWebElement Seller { get; set; }

        [FindsBy(How = How.Id, Using = "markDraft")]
        public IWebElement markDraft { get; set; }

        [FindsBy(How = How.Id, Using = "chkMisc")]
        public IWebElement Misc { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "chkFileNum")]
        public IWebElement FileNumerCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerName")]
        public IWebElement SellerNamecheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkLoanNum")]
        public IWebElement LoanNumCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyerName")]
        public IWebElement BuyerNameCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkPropertyAddr")]
        public IWebElement PropertyAddressCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkClear")]
        public IWebElement ClearCheckBox { get; set; }


        //srt r10
        [FindsBy(How = How.Id, Using = "btnMsgSpellCheck")]
        public IWebElement SpellCheck_Msg { get; set; }

        #endregion

        public EmailDlg WaitForDialogToLoad(int timeout = 10)
        {
            //WebDriver.WaitForWindowAndSwitch("Email", timeoutSeconds: timeout);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(ToText);
            return this;
        }

        public EmailDlg WaitForDialogToLoad1(int timeout = 10)
        {
            //WebDriver.WaitForWindowAndSwitch("Email", timeoutSeconds: timeout);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(ToText);
            return this;
        }

        // overload
        public EmailDlg WaitForScreenToLoad()
        {
            FastDriver.WebDriver.HandleDialogMessage();
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(ToText);
            return this;
        }

        public void SendEmail()
        {
            Reports.TestStep = "Add the details and send the email.";
            this.ToText.FASetText(AutoConfig.DeliverEmailTo);
            this.Message.FASetText("This is Testing Mail. Please ignore it....",true);
            this.Email.FAClick();
        }

        public EmailDlg SetToCCSubMessage(string toaddress, string ccaddress, string subject=null,string messagebody=null)
        {
            ToText.FASetText(toaddress);
            CCText.FASetText(ccaddress);
            if (!string.IsNullOrEmpty(subject))
            Subject.FASetText(subject);
            if (!string.IsNullOrEmpty(subject))
            Message.FASetText(messagebody);
            Email.FAClick();
            return this;
        }


    }
}
