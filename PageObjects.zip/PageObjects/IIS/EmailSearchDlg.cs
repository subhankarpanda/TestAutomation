using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class EmailSearchDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "optSearch_0")]
		public IWebElement GlobalAddressBookRadio { get; set; }

		[FindsBy(How = How.Id, Using = "optSearch_1")]
		public IWebElement FileAddressBookRadio { get; set; }

		[FindsBy(How = How.Id, Using = "optSearch_2")]
		public IWebElement EmployeeSearchRadio { get; set; }

		[FindsBy(How = How.Id, Using = "txtEntityName")]
		public IWebElement EntityName { get; set; }

		[FindsBy(How = How.Id, Using = "BtnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "ddlEntityType")]
		public IWebElement EntityType { get; set; }

		[FindsBy(How = How.Id, Using = "BtnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "txtfirstName")]
		public IWebElement firstName { get; set; }

		[FindsBy(How = How.Id, Using = "BtnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "txtLastName")]
		public IWebElement LastName { get; set; }

		[FindsBy(How = How.Id, Using = "Btnfinished")]
		public IWebElement Finished { get; set; }

		[FindsBy(How = How.Name, Using = "grdTitleAndEscrowResults")]
		public IWebElement GlobalAddressBookTable { get; set; }

		[FindsBy(How = How.Name, Using = "grdSearchResults")]
		public IWebElement FileAddressBookTable { get; set; }

        [FindsBy(How = How.Name, Using = "grdSalesRep")]
        public IWebElement EmpSearchSalesRepTable { get; set; }

		#endregion

        #region Services

        public EmailSearchDlg WaitForDialogToLoad(int timeout = 10)
        {
            //WebDriver.WaitForWindowAndSwitch("Email", timeoutSeconds: timeout);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(FileAddressBookRadio);
            return this;
        }


        public EmailSearchDlg WaitForScreenToLoad(int timeout = 10)
        {
            return WaitForDialogToLoad(timeout);
        }

        public EmailSearchDlg WaitForResultsToLoad()
        {
            FastDriver.WebDriver.HandleDialogMessage();
            this.WaitForScreenToLoad();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.WaitForScreenToLoad();
            return this;
        }

        #endregion
    }
}
