using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class EmployeeSelectionbyOfficeDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "lstEmployees")]
        public IWebElement EmployeeList { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "chkHmeOficeOnly")]
		public IWebElement HomeOfficeOnly { get; set; }

		[FindsBy(How = How.Id, Using = "ddlSelctOffice")]
		public IWebElement SelectOffice { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='QA071, FAST']")]
        public IWebElement QA071 { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='QA08, FAST']")]
		public IWebElement QA08 { get; set; }

        [FindsBy(How = How.XPath, Using = "//option[.='QA09, FAST']")]
        public IWebElement QA09 { get; set; }

        #endregion

        public EmployeeSelectionbyOfficeDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Select);

            return this;
        }

    }
}
