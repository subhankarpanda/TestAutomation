using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class EscrowFileBalanceSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnTrialBalanceNote")]
        public IWebElement TrialBalanceNote { get; set; }

        [FindsBy(How = How.Id, Using = "idLPSGrid_0_labelRecvd")]
        public IWebElement Recieved { get; set; }

        [FindsBy(How = How.Id, Using = "lblSHORT_EXCESS")]
        public IWebElement Inbalance { get; set; }

        [FindsBy(How = How.Id, Using = "lblCF_NetIssuedDisb")]
        public IWebElement NetIssuedDisb { get; set; }

        [FindsBy(How = How.Id, Using = "lblCF_CurrentFunds")]
        public IWebElement CurrentAvailableFunds { get; set; }

        [FindsBy(How = How.Id, Using = "lblCF_NetTotalDeposits")]
        public IWebElement NetDeposit { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSA_NetTotalDisb")]
        public IWebElement Payoffloannettotaldisb { get; set; }

        [FindsBy(How = How.Id, Using = "lblCF_CurrentFunds")]
        public IWebElement Net3300 { get; set; }

        [FindsBy(How = How.Id, Using = "lblB_FundsDue")]
        public IWebElement BuyerFundsDue { get; set; }

        [FindsBy(How = How.Id, Using = "lblS_NetCheck")]
        public IWebElement NetSellerCheck { get; set; }

        [FindsBy(How = How.Id, Using = "trHideShowCashDepositMultiple")]
        public IWebElement Thisfilecom8300isrequired { get; set; }

        [FindsBy(How = How.LinkText, Using = "This file contains individual cash equivalent instruments in amounts of $10,000 or less, whose sum is in excess of $10,000.00. Please investigate whether form 8300 is required to be filed.")]
        public IWebElement Checkstatictextwith8300 { get; set; }

        [FindsBy(How = How.Id, Using = "trHideShowCashDepositSingle")]
        public IWebElement Thisfilecontaionsexcessof1000000 { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[contains(text(),'Issued Check Amounts exceed Actual Charge Amounts')]")]
        public IWebElement IssuedAmountsexceedactulachargemessage { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSA_NetTotalDisb")]
        public IWebElement NetTotalDisbursements { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSA_FileBalance")]
        public IWebElement FileBalance { get; set; }

        [FindsBy(How = How.Id, Using = "lblB_NetCheck")]
        public IWebElement BuyerNetCheck { get; set; }

        [FindsBy(How = How.Id, Using = "lblS_NetCheck")]
        public IWebElement SellerNetCheck { get; set; }

        [FindsBy(How = How.Id, Using = "idLPSGrid_0_labelLoanAmounts")]
        public IWebElement LoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblS_FHAC")]
        public IWebElement FundsHeldAfterCloseSeller { get; set; }

        [FindsBy(How = How.Id, Using = "lblS_FundsDue")]
        public IWebElement SellerFundsDue { get; set; }

        [FindsBy(How = How.Id, Using = "lblIssuedTotal")]
        public IWebElement TotalIssuedDeposit { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetAdjustTotal")]
        public IWebElement NetDepositAdjustment { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetDepositTotal")]
        public IWebElement NetDepositTotal { get; set; }

        [FindsBy(How = How.Id, Using = "lblB_CheckIssuedFlag")]
        public IWebElement BuyerCheckIssuedFlag { get; set; }

        [FindsBy(How = How.Id, Using = "lblS_CheckIssuedFlag")]
        public IWebElement SellerCheckIssuedFlag { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table#tblFBS>tbody>tr:last-child td.cFrameBody>table>tbody>tr:nth-child(2)>td:nth-child(2) table:last-child")]
        public IWebElement FBSProjectedTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotNetIssuedFlag")]
        public IWebElement DisbSumTotNetIssuedFlag { get; set; }

        [FindsBy(How = How.Id, Using = "idLPSGrid")]
        public IWebElement LoanProceedsSummaryTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table#tblFBS td.cFrameBody:first-child td.cFrameBody:first-child > table:first-child")]
        public IWebElement BuyerSellerAmountsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblDeposDisbSummary")]
        public IWebElement DepositOrDisbursementSummaryTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tblDeposDisbSummary tr:nth-child(2) td.cFrameLabel table table:first-child")]
        public IWebElement DisbursementSummaryTotals { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tblDeposDisbSummary tr:nth-child(2) table:nth-child(1) td.cFrameBody table table:first-child")]
        public IWebElement DepositToEscrowSummaryTotals { get; set; }

        [FindsBy(How = How.Id, Using = "lblIssuedIBADisbursementAmount")]
        public IWebElement IssuedIBADisbursements { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement cboMethod { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement btnDeliver { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#lblDisbSumTotNetTotDisb")]
        public IWebElement DisbSummaryNetTotal { get; set; }

        [FindsBy(How = How.Id, Using = "lbl_ListingBrokerFundsDue")]
        public IWebElement ListingBrokerFundsDue { get; set; }

        [FindsBy(How = How.Id, Using = "lbl_ListingBrokerFundsDue")]
        public IWebElement SellingBrokerFundsDue { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_BuyerFundsDue")]
        public IWebElement BuyerFundsDue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tblFBS")]
        public IWebElement FileBalanceSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblDifferenceAmount")]
        public IWebElement DifferenceAmountValue { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[contains(text(),'Difference Amount: $')]")]
        public IWebElement DifferenceAmountLabel { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table#tblFBS>tbody>tr:last-child td.cFrameBody>table>tbody>tr:nth-child(2)>td:nth-child(2) table:first-child")]
        public IWebElement FilaBalanceSummaryActualPostedTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_FileBalance")]
        public IWebElement ProjectedFileBalanceAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_Borrower")]
        public IWebElement FundsDueLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_BuyerFundsDue")]
        public IWebElement FundsDueAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_Borrower")]
        public IWebElement BuyerFundsDueLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_BuyerFundsDue")]
        public IWebElement BuyerFundsDueAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table/tbody/tr/td/b[text()='Seller's Funds Due:']")]
        public IWebElement SellerFundsDueLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSP_SellerFundsDue")]
        public IWebElement SellerFundsDueAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSA_BuyerFundsHeld")]
        public IWebElement BuyerFundsHeld { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSA_SellerFundsHeld")]
        public IWebElement SellerFundsHeld { get; set; }

        [FindsBy(How = How.Id, Using = "idLPSGrid_0_labelProjectedLoanFunding")]
        public IWebElement ProjectedLoanFunding { get; set; }

        [FindsBy(How = How.Id, Using = "lblOutsideofEscrowDeposits")]
        public IWebElement DepositOutsideEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "lblInitialDeposits")]
        public IWebElement InitialDeposits { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotIssuedCheckAmount")]
        public IWebElement IssuedChecks { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotIssuedWiresAmount")]
        public IWebElement IssuedWires { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotIssuedFeeXferAmount")]
        public IWebElement IssuedFeeTransfer { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotTotalIssuedAmount")]
        public IWebElement TotalIssuedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotNetAdj")]
        public IWebElement NetAdjustments { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotNetIssued")]
        public IWebElement DisbursementSummaryTotalNetIssued { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotActualIssuedCharges")]
        public IWebElement DisbursementSummaryTotalActualIssuedCharges { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotHeldCheckAmount")]
        public IWebElement DisbursementSummaryTotalHeldCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotHeldFeeXferAmount")]
        public IWebElement DisbursementSummaryTotalHeldFeeTransferAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotCreatedIssueAmount")]
        public IWebElement DisbursementSummaryTotalCreatedIssueAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotPendingIssueAmount")]
        public IWebElement DisbursementSummaryTotalPendingIssueAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotDisbPendingHeld")]
        public IWebElement DisbursementSummaryTotalPendingHeld { get; set; }

        [FindsBy(How = How.Id, Using = "lblDisbSumTotNetTotDisb")]
        public IWebElement DisbursementSummaryTotalNetTotalDisbursement { get; set; }

        [FindsBy(How = How.Id, Using = "lblFBSA_NetTotalDeposits")]
        public IWebElement FileBalanceSummaryActOrProjNetTotalDeposits { get; set; }
        


        #endregion

        public EscrowFileBalanceSummary Method(string method)
        {

            this.SwitchToContentFrame();
            this.WaitCreation(cboMethod);
            this.cboMethod.FASelectItem(method);

            return this;
        }

        public EscrowFileBalanceSummary Deliver()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(btnDeliver);
            this.btnDeliver.FAClick();

            return this;
        }

        public EscrowFileBalanceSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TrialBalanceNote);
            return this;
        }

        public EscrowFileBalanceSummary Open()
        {

            FastDriver.LeftNavigation.Navigate<EscrowFileBalanceSummary>("Home>Order Entry>Escrow Closing>File Balance Summary");
            return WaitForScreenToLoad();
        }


    }
}
