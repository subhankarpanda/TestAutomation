using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class EventTrackingLog : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddEventCategory")]
        public IWebElement EventCategory { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_FAFDataGrid1")]
        public IWebElement EventTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@name='FAFDataGrid1_FAFDataGrid1']/tbody/tr/td/table")]
        public IWebElement EventTableHeader { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFComments")]
        public IWebElement Comments { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement AdjustComments { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_1_FAFComments")]
        public IWebElement Comments1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFEventName")]
        public IWebElement EventName { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFStartDate")]
        public IWebElement StartDate { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFEndDate")]
        public IWebElement CompletionDate { get; set; }

        [FindsBy(How = How.Id, Using = "btnDetails")]
        public IWebElement Details { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFSource")]
        public IWebElement Source0 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_1_FAFSource")]
        public IWebElement Source1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_1_FAFUserName")]
        public IWebElement User1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFUserName")]
        public IWebElement User0 { get; set; }


        [FindsBy(How = How.Id, Using = "FAFDataGrid1_1_FAFStartDate")]
        public IWebElement StartDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_1_FAFEndDate")]
        public IWebElement CompletionDate1 { get; set; }
        //      FAFDataGrid1_0_FAFEventName

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFEventName")]
        public IWebElement Event0_Rw0Cl1 { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_1_FAFEventName")]
        public IWebElement Event0_Rw1Cl1 { get; set; }
        #endregion

        public EventTrackingLog Open()
        {
            FastDriver.LeftNavigation.Navigate<EventTrackingLog>("Home>Order Entry>Event/Tracking Log");
            this.WaitForScreenToLoad();

            return this;
        }

        public EventTrackingLog WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? EventTable);

            return this;
        }

        public EventTrackingLog WaitForWindowToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(EventTable);

            return this;
        }
        #region Services


        public EventTrackingLog SelectEventCategory(string category)
        {
            EventCategory.FASelectItem(category);
            Playback.Wait(3000);
            this.WaitCreation(EventName);
            return this;
        }

        public EventTrackingLog VerifyEventTableData(int rowindex, int columnindex, string verificationtext)
        {
            OperationResult opresult = EventTable.PerformTableAction(rowindex, columnindex, TableAction.GetText);
            Support.AreEqual(opresult.Message.Clean(), verificationtext);
            return this;
        }

        public EventTrackingLog VerifyEvent(int columnToSearch, string eventName)
        {
            Support.AreEqual(true, EventTable.PerformTableAction(columnToSearch, eventName, columnToSearch, TableAction.GetText).Message.Clean().Contains(eventName), string.Format("Verifying event {0} exists in Event Table", eventName));
            return this;
        }

        public bool VerifyDocDeliveryEventDetails(string expctdEventName)
        {
            bool result = false;
            string eventName = string.Empty;
            string startDate = string.Empty;
            string completionDate = string.Empty;
            string Source = string.Empty;
            string user = string.Empty;
            string Comments = string.Empty;

            eventName = EventTable.PerformTableAction(1,"["+expctdEventName+"]",1,TableAction.GetText).Message;
            startDate = EventTable.PerformTableAction(1, "[" + expctdEventName + "]", 2, TableAction.GetText).Message;
            completionDate = EventTable.PerformTableAction(1, "[" + expctdEventName + "]", 3, TableAction.GetText).Message;
            Source = EventTable.PerformTableAction(1, "[" + expctdEventName + "]", 4, TableAction.GetText).Message;
            user=EventTable.PerformTableAction(1, "[" + expctdEventName + "]", 6, TableAction.GetText).Message;
            Comments = EventTable.PerformTableAction(1, "[" + expctdEventName + "]",5, TableAction.GetText).Message;

            result = (!result) && (!string.IsNullOrEmpty(eventName));
            if (result)
            {
                result = result && startDate.Contains(DateTime.Now.ToString("MM/dd/yyyy"));
                result = result && completionDate.Contains(DateTime.Now.ToString("MM/dd/yyyy"));
                if(AutoConfig.UserName.Equals("Fastts\\Fastqa07"))
                {
                    result = result && user.Equals("FAST QA07");
                }
                if (expctdEventName.Contains("Fax"))
                {
                    result = result && Comments.Contains("Delivery Submitted");
                }
                else
                {
                    result = result && Comments.Contains("Delivery Successful"); 
                }
            }
            string statusString=result?"Correct":"incorrect";
            Reports.StatusUpdate("Event log for the event " + expctdEventName + " is " + statusString, result);
            return result;
        }
        public bool ValidateEvent(string EventName)
        {
            this.WaitForScreenToLoad();
            string Status = "";
            if (this.EventTable.FAGetText().Contains(EventName))
            {
                Status = this.EventTable.PerformTableAction("Event", EventName, "Event", TableAction.Click).Status.ToString();
                if (Status.Equals("Success"))
                {
                    return true;
                }
            }

            return false;
        }
        //
        public bool ValidateStartDateForEvent(string EventName, DateTime ExpectedStartDate)
        {
            this.WaitForScreenToLoad();
            string ActualStartDate = this.EventTable.PerformTableAction("Event", EventName, @"Start Date/Time", TableAction.GetText).Message.Trim();
            DateTime StartDate;
            bool isConverted = DateTime.TryParse(ActualStartDate.Substring(0,19), out StartDate);
            if (isConverted)
            {
                int diff = ExpectedStartDate.Subtract(StartDate).Seconds;
                if (diff <= 90)
                    return true;
            }
            return false;
        }
        //
        public bool ValidateCompletionDateForEvent(string EventName, DateTime ExpectedCompletionDate)
        {
            this.WaitForScreenToLoad();
            string ActualCompletionDate = this.EventTable.PerformTableAction("Event", EventName, @"Completion Date/Time", TableAction.GetText).Message.Trim();
            // ActualCompletionDate= Convert.ToDateTime(ActualCompletionDate.Replace("PST"," ").Trim()).Date.ToDateString();
            DateTime CompletionDate;
            bool isConverted = DateTime.TryParse(ActualCompletionDate.Substring(0, 19).Trim(), out CompletionDate);
            if (isConverted)
            {
                int diff = ExpectedCompletionDate.Subtract(CompletionDate).Seconds;
                if (diff <= 90)
                    return true;
            }
            return false;
        }
        //
        public bool ValidateSourceForEvent(string EventName, string ExpectedSource)
        {
            this.WaitForScreenToLoad();
            string ActualSource = this.EventTable.PerformTableAction("Event", EventName, "Source", TableAction.GetText).Message.Trim();
            if (ActualSource.Equals(ExpectedSource))
            {
                return true;
            }
            else
                return false;
        }
        //
        public bool ValidateUserNameForEvent(string EventName, string ExpectedUserName)
        {
            this.WaitForScreenToLoad();
            string ActualUserName = this.EventTable.PerformTableAction("Event", EventName, "User", TableAction.GetText).Message.Trim();
            if (ActualUserName.Equals(ExpectedUserName))
            {
                return true;
            }
            else
                return false;
        }
        //
        public string GetCommentForEvent(string EventName)
        {
            this.WaitForScreenToLoad();
            string Comment = this.EventTable.PerformTableAction("Event", EventName, "Comments", TableAction.GetText).Message.Trim();
            return Comment;
        }
        #endregion Services
    }
}
