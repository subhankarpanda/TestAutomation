using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class EventTrackingLogDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddEventCategory")]
		public IWebElement EventCategory { get; set; }

		[FindsBy(How = How.Id, Using = "labelFileName")]
		public IWebElement WorkFlow { get; set; }

		[FindsBy(How = How.Id, Using = "labelFileNumber")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_FAFDataGrid1")]
		public IWebElement EventTable { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFSource")]
		public IWebElement Source { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFUserName")]
		public IWebElement User { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFStartDate")]
		public IWebElement StartDate { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_FAFEndDate")]
		public IWebElement CompleteDate { get; set; }

        #endregion

        public EventTrackingLogDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Comments);

            return this;
        }

    }
}
