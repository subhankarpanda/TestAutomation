using System;
using System.Threading;
using System.Collections.Generic;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITest.Input;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using FASTSelenium.DataObjects.IIS;

namespace FASTSelenium.PageObjects.IIS
{
    public class ExchangeDeposit : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Print { get; set; }
        [FindsBy(How = How.Id, Using = "btnHtry")]
        public IWebElement History { get; set; }

        [FindsBy(How = How.Id, Using = "txtAmnt")]
        public IWebElement Amount { get; set; }

        [FindsBy(How = How.Id, Using = "txtRcpNo")]
        public IWebElement ReceiptNo { get; set; }

        [FindsBy(How = How.Id, Using = "btnMnl")]
        public IWebElement Manual { get; set; }

        [FindsBy(How = How.Id, Using = "chkUpTrAcnt")]
        public IWebElement UpdateTrustAccounting { get; set; }

        [FindsBy(How = How.Id, Using = "txtIsuDte")]
        public IWebElement IssueDte { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSelTpFnd")]
        public IWebElement TypeofFunds { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSelDpstTp")]
        public IWebElement Representing { get; set; }

        [FindsBy(How = How.Id, Using = "txtDecp")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "chkAftrHrs")]
        public IWebElement AfterHours { get; set; }

        [FindsBy(How = How.Id, Using = "ddlCstTyp")]
        public IWebElement ReceivedFrom { get; set; }

        [FindsBy(How = How.Id, Using = "txtPyr")]
        public IWebElement Payor { get; set; }

        [FindsBy(How = How.Id, Using = "optByr")]
        public IWebElement CredittoBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "optSlr")]
        public IWebElement CredittoSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSelDpstTo")]
        public IWebElement DepositedTo { get; set; }

        [FindsBy(How = How.Id, Using = "txtComnt")]
        public IWebElement Comment { get; set; }

        [FindsBy(How = How.Id, Using = "txtChkNum")]
        public IWebElement CheckNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtABANum")]
        public IWebElement ABANumber { get; set; }

        [FindsBy(How = How.Id, Using = "chkOtfStat")]
        public IWebElement OutofState { get; set; }

        [FindsBy(How = How.Id, Using = "txtBnkNm1")]
        public IWebElement BankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtChkAcntNum")]
        public IWebElement AccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "lblTransmDt")]
        public IWebElement TransmissionDate { get; set; }

        [FindsBy(How = How.Id, Using = "optOtr")]
        public IWebElement CredittoOther { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement DepositRecapTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblTtlDpst")]
        public IWebElement TotalDeposits { get; set; }

        [FindsBy(How = How.Id, Using = "lblByrDpst")]
        public IWebElement BuyerDeposits { get; set; }

        [FindsBy(How = How.Id, Using = "lblSlrDpst")]
        public IWebElement SellerDeposits { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtrDpst")]
        public IWebElement OtherDeposits { get; set; }

        [FindsBy(How = How.Id, Using = "txtBnkNm2")]
        public IWebElement WireBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtConfmNum")]
        public IWebElement ConfirmationNum { get; set; }

        [FindsBy(How = How.Id, Using = "txtBnkCont")]
        public IWebElement BankContact { get; set; }

        [FindsBy(How = How.Id, Using = "txtConfmDat")]
        public IWebElement ConfirmationDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtFedrlRoutnNum")]
        public IWebElement FederalRoutingNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtConfmTime")]
        public IWebElement ConfirmationTime { get; set; }

        [FindsBy(How = How.Id, Using = "lblManRptRsn")]
        public IWebElement ManualReceiptReason { get; set; }

        [FindsBy(How = How.Id, Using = "lblBankName")]
        public IWebElement DepositBankName { get; set; }
        #endregion

        public ExchangeDeposit Open()
        {
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>1031 Exchange>Accounting>Deposit/Receipts");
            this.WaitForScreenToLoad();

            return this;
        }

        public ExchangeDeposit WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Amount);

            return this;
        }

        /// <summary>
        /// This function performs all kind of deposit in escrow account.
        /// </summary>
        /// <param name="deposit">Data input for the performing the deposit action.</param>
        /// <returns></returns>
        public ExchangeDeposit Deposit(DepositParameters deposit)
        {
            WaitForScreenToLoad(Amount);

            Amount.FASetText(deposit.Amount.ToString());

            if (deposit.TypeofFunds != "")
                TypeofFunds.FASelectItem(deposit.TypeofFunds);

            if (deposit.Representing != "")
                Representing.FASelectItem(deposit.Representing);

            if (deposit.ReceivedFrom != "")
                ReceivedFrom.FASelectItem(deposit.ReceivedFrom);

            if (deposit.DepositedTo != "")
                DepositedTo.FASelectItem(deposit.DepositedTo);

            if (deposit.Payor != "")
                Payor.FASetText(deposit.Payor);

            if (deposit.Description != "")
                Description.FASetText(deposit.Description);
            
            if (CredittoSeller.IsEnabled())
                CredittoSeller.FASetCheckbox(deposit.CreditToSeller);
            if (CredittoBuyer.IsEnabled())
                CredittoBuyer.FASetCheckbox(deposit.CreditToBuyer);
            if (CredittoOther.IsEnabled())
                CredittoOther.FASetCheckbox(deposit.CreditToOther);

            if (deposit.Comments != "")
                Comment.FASetText(deposit.Comments);

            if (deposit.TypeofFunds == "Cashier's Check" || deposit.TypeofFunds == "Company Check" || deposit.TypeofFunds == "Money Order" || deposit.TypeofFunds == "Personal Check")
            {
                if (deposit.CheckNumber != "")
                {
                    CheckNumber.FASetText(deposit.CheckNumber);
                }
                if (deposit.ABANumber != "")
                {
                    ABANumber.FASetText(deposit.ABANumber);
                }
                if (deposit.AccountNumber != "")
                {
                    AccountNumber.FASetText(deposit.AccountNumber);
                }
                if (deposit.BankName != "")
                {
                    BankName.FASetText(deposit.BankName);
                }
            }

            if (deposit.TypeofFunds == "Wire")
            {
                if (deposit.WireBankName != "")
                {
                    WireBankName.FASetText(deposit.WireBankName);
                }
                if (deposit.ConfirmationNumber != "")
                {
                    ConfirmationNum.FASetText(deposit.ConfirmationNumber);
                }
                if (deposit.BankContact != "")
                {
                    BankContact.FASetText(deposit.BankContact);
                }
                ConfirmationDate.FASetText(DateTime.Now.ToDateString());

                if (deposit.FedRoutingNumber != "")
                {
                    FederalRoutingNumber.FASetText(deposit.FedRoutingNumber);
                }

                if (deposit.ConfirmationTime != "")
                {
                    ConfirmationTime.FASetText(deposit.ConfirmationTime);
                }
            }
            return this;
        }

        public void SaveandCancleMessage()
        {
            WaitForScreenToLoad(Amount);
            FastDriver.BottomFrame.Save();
            Reports.TestStep = "Verify Message and Click cancel";
            Support.AreEqual("Deposit Receipt is ready for printing. Continue?", FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false));
            FastDriver.DepositInEscrow.SwitchToContentFrame();
        }

        /// <summary>
        /// This funciton verifies "Enabled" property for all the fields available after performing the deposit.
        /// </summary>
        /// <returns>returns true if values are maching with the expected one.</returns>
        public bool VerifyFieldsDisabledAfterDeposit()
        {
            bool result = true;
            result = result && this.Amount.Enabled.Equals(false);
            result = result && this.ReceiptNo.Enabled.Equals(false);
            result = result && this.IssueDte.Enabled.Equals(false);
            result = result && this.TypeofFunds.Enabled.Equals(false);
            result = result && this.Representing.Enabled.Equals(false);
            result = result && this.Description.Enabled.Equals(false);
            result = result && this.ReceivedFrom.Enabled.Equals(false);
            result = result && this.Payor.Enabled.Equals(false);
            result = result && this.DepositedTo.Enabled.Equals(false);
            result = result && this.CredittoBuyer.Enabled.Equals(true);
            result = result && this.CredittoOther.Enabled.Equals(true);
            result = result && this.CredittoSeller.Enabled.Equals(true);
            return result;
        }

        /// <summary>
        /// This funciton verifies "Enabled" property for all the fields available On page load.
        /// </summary>
        /// <returns>returns true if values are maching with the expected one.</returns>
        public bool VerifyFieldsOnPageLoad()
        {
            bool result = true;
            result = result && this.Amount.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for Amount field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.ReceiptNo.Enabled.Equals(false);
            Reports.StatusUpdate(controlDescription: "Validation for ReceiptNo field: " + result.ToString(), status: result, expectedValue: "False", actualValue: (!result).ToString());
            result = result && this.IssueDte.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for IssueDte field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.TypeofFunds.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for TypeofFunds field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.Representing.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for Representing field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.Description.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for Description field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.ReceivedFrom.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for ReceivedFrom field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.Payor.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for Payor field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.DepositedTo.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for DepositedTo field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.CredittoBuyer.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for CredittoBuyer field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.CredittoOther.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for CredittoOther field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            result = result && this.CredittoSeller.Enabled.Equals(true);
            Reports.StatusUpdate(controlDescription: "Validation for CredittoSeller field: " + result.ToString(), status: result, expectedValue: "True", actualValue: result.ToString());
            return result;
        }

        /// <summary>
        /// This Function verifies the values of total buyer deposit seller deposits, and other deposits and their total sum.
        /// </summary>
        /// <param name="expectedBuyerDeposit"></param>
        /// <param name="expectedSellerDeposit"></param>
        /// <param name="expectedOtherDeposit"></param>
        /// <returns></returns>
        public bool VerifyUpdatedDeposits(double expectedBuyerDeposit, double expectedSellerDeposit, double expectedOtherDeposit)
        {
            double buyerDeposit = Convert.ToDouble(this.BuyerDeposits.FAGetText());
            double sellerDeposit = Convert.ToDouble(this.SellerDeposits.FAGetText());
            double otherDeposit = Convert.ToDouble(this.OtherDeposits.FAGetText());
            double totalDeposit = Convert.ToDouble(this.TotalDeposits.FAGetText());
            double expectedTotal = expectedBuyerDeposit + expectedSellerDeposit + expectedOtherDeposit;

            bool result = false;
            result = (!result) && (buyerDeposit.Equals(expectedBuyerDeposit));
            Reports.StatusUpdate("Validation result for 'Buyer Deposit is matching with expected value: " + result.ToString(), result, "BuyerDeposits", "Value Comparison", expectedBuyerDeposit.ToString(), buyerDeposit.ToString());
            result = (result) && (sellerDeposit.Equals(expectedSellerDeposit));
            Reports.StatusUpdate("Validation result for 'Seller Deposit is matching with expected value: " + result.ToString(), result, "SellerDeposits", "Value Comparison", expectedSellerDeposit.ToString(), sellerDeposit.ToString());
            result = (result) && (otherDeposit.Equals(expectedOtherDeposit));
            Reports.StatusUpdate("Validation result for 'Other Deposit is matching with expected value: " + result.ToString(), result, "OtherDeposits", "Value Comparison", expectedOtherDeposit.ToString(), otherDeposit.ToString());
            result = (result) && (totalDeposit.Equals(expectedTotal));
            Reports.StatusUpdate("Validation result for 'Total Deposit is matching with expected value: " + result.ToString(), result, "TotalDeposits", "Value Comparison", expectedTotal.ToString(), totalDeposit.ToString());

            return result;
        }
    }
}
