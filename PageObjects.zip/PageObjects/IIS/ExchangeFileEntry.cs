using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ExchangeFileEntry : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "__tab_TC_RL")]
		public IWebElement RelinquishedTab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_cboPropertyType")]
		public IWebElement RelPropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtPropertySt1")]
		public IWebElement RelPropertyAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtPropertySt2")]
		public IWebElement RelPropertyAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtPropertySt3")]
		public IWebElement RelPropertyAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtPropertySt4")]
		public IWebElement RelPropertyAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtPropertyCity")]
		public IWebElement RelPropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_cboPropertyState")]
		public IWebElement RelPropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtPropertyZIP")]
		public IWebElement RelPropertyZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_cboPropertyCounty")]
		public IWebElement RelPropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_cboPropertyCountry")]
		public IWebElement RelPropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeTerms_txtEscNo")]
		public IWebElement RelTermsEscrowNumber { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeTerms_txtInProp")]
		public IWebElement RELIntinProperty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeTerms_txtSalePrice")]
		public IWebElement TRelTermsSalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_txtEstDaystoClose")]
		public IWebElement RelEstDaystoClose { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_txtEstSettleDate")]
		public IWebElement RelEstSettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_txtCOEDt")]
		public IWebElement RelCOEDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_txtDateOfContractAccpt")]
		public IWebElement RelDateofAcceptance { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_txtDtOfCont")]
		public IWebElement RelDateofContract { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_chkPreRec")]
		public IWebElement RelPreliminaryRecieved { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_chkAgreeRec")]
		public IWebElement RelAgreementReceived { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeDates_chkActCOE")]
		public IWebElement RelActualCOE { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucEOBP_txtGABcode")]
		public IWebElement RelEscrowOfficerGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucEOBP_txtName")]
		public IWebElement RelEscrowOfficerPName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucEOBP_cmdFindName")]
		public IWebElement RelEscrowOfficeFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucEOBP_chkEditContactInfo")]
		public IWebElement RelEscrowOfficeEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucTxABP_txtGABcode")]
		public IWebElement RelTaxPayersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucTxABP_txtName")]
		public IWebElement RelTaxPayersAgentName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucTxABP_cmdFindName")]
		public IWebElement RelTaxPayersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucTxABP_chkEditContactInfo")]
		public IWebElement RelTaxPayersAgentEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucBsABP_txtGABcode")]
		public IWebElement RelBuyersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucBsABP_txtName")]
		public IWebElement RelBuyersAgentName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucBsABP_cmdFindName")]
		public IWebElement RelBuyersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucBsABP_chkEditContactInfo")]
		public IWebElement RelBuyersAgentEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnNewSrch")]
		public IWebElement RelBuyersNewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnAddNew")]
		public IWebElement RelBuyersAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnRemove")]
		public IWebElement RelBuyersRemove { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_cboType")]
		public IWebElement RelBuyersType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtIndMiddle")]
		public IWebElement RelBuyersIndividualMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtIndLast")]
		public IWebElement RelBuyersIndividualLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtIndSuffix")]
		public IWebElement RelBuyersIndividualSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtIndSSNTIN")]
		public IWebElement RelBuyersIndividualSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSt1")]
		public IWebElement RelAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSt2")]
		public IWebElement RelAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSt3")]
		public IWebElement RelAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSt4")]
		public IWebElement RelAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtCity")]
		public IWebElement RelBuyersCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_cboState")]
		public IWebElement RelBuyersState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtZIP")]
		public IWebElement RelBuyersZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtBusPh")]
		public IWebElement RelBuyersBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtHomePh")]
		public IWebElement RelBuyersHomePhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtBusFax")]
		public IWebElement RelBuyersBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtCellFax")]
		public IWebElement RelBuyersCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtPager")]
		public IWebElement RelBuyersPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtEmail")]
		public IWebElement RelBuyersEmail { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtCounty")]
		public IWebElement RelBuyersCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_cboCountry")]
		public IWebElement RelBuyersCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtHusName")]
		public IWebElement RelBuyersHusbandFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtHusMiddle")]
		public IWebElement RelBuyersHusbandMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtHusLast")]
		public IWebElement RelBuyersHusbandLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtHusSuffix")]
		public IWebElement RelBuyersHusbandSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtHusSSNTIN")]
		public IWebElement RelBuyersHusbandSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSpouseName")]
		public IWebElement RelBuyersSpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSpouseMiddle")]
		public IWebElement RelBuyersSpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSpouseLast")]
		public IWebElement RelBuyersSpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSpouseSuffix")]
		public IWebElement RelBuyersSpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtSpouseSSNTIN")]
		public IWebElement RelBuyersSpouseSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtTrustBEName")]
		public IWebElement RelBuyersTrustEstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_radTrustBESSN")]
		public IWebElement RelBuyersTrustEstSSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_radTrustBETIN")]
		public IWebElement RelBuyersTrustEstTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement RelBuyersTrustEstSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtTrustBEName")]
		public IWebElement RelBuyersBusEntityName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_radTrustBESSN")]
		public IWebElement RelBuyersBusEntitySSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_radTrustBETIN")]
		public IWebElement RelBuyersBusEntityTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement RelBuyersBusEntitySSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_TC_RP")]
		public IWebElement ReplacementTab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_cboPropertyType")]
		public IWebElement REPPropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtTran")]
		public IWebElement REPPropertyTransactionNo { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtPropertySt1")]
		public IWebElement REPPropertyAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtPropertySt2")]
		public IWebElement REPPropertyAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtPropertySt3")]
		public IWebElement REPPropertyAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtPropertySt4")]
		public IWebElement REPPropertyAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtPropertyCity")]
		public IWebElement REPPropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_txtPropertyZIP")]
		public IWebElement REPPropertyZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_cboPropertyCounty")]
		public IWebElement REPPropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_cboPropertyCountry")]
		public IWebElement REPPropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeTerms_txtEscNo")]
		public IWebElement REPTermsEscrowNo { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeTerms_txtInProp")]
		public IWebElement REPIntinProperty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeTerms_txtSalePrice")]
		public IWebElement REPTermsSalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_txtEstDaystoClose")]
		public IWebElement REPEstDaystoClose { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_txtCOEDt")]
		public IWebElement REPCOEDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_txtDtOfCont")]
		public IWebElement REPDateofContract { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_txtEstSettleDate")]
		public IWebElement REPEstSettleDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_txtDateOfContractAccpt")]
		public IWebElement REPDateofContractAcceptance { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_chkPreRec")]
		public IWebElement REPPreliminaryReceived { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_chkAgreeRec")]
		public IWebElement REPAgreementReceived { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeDates_chkActCOE")]
		public IWebElement REPActualCOE { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucEOBP_txtGABcode")]
		public IWebElement REPEscrowOfficerGABCode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucEOBP_txtName")]
		public IWebElement REPEscrowOfficerName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucEOBP_cmdFindName")]
		public IWebElement REPEscrowOfficerFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucEOBP_chkEditContactInfo")]
		public IWebElement REPEscrowOfficerEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucEOBP_textBusPhone")]
		public IWebElement REPREscrowOfficerBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_txtName")]
		public IWebElement REPTaxpayersAgentGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_chkEditContactInfo")]
		public IWebElement REPTaxPayersAgentEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_textBusPhone")]
		public IWebElement TCRPERPucBABPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_textBusFax")]
		public IWebElement TCRPERPucBsABPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_textCellPhone")]
		public IWebElement TCRPERPucBBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_textPager")]
		public IWebElement TCRPERPucBsABPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_textEmailAddress")]
		public IWebElement TCRPERPucBextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement FileStatus { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_chkAutoNo")]
		public IWebElement AutoNumber { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_chkExcgange")]
		public IWebElement Exchange { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_cboExcgangeOffice")]
		public IWebElement ExchangeOffice { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_cboExchangeOfficer")]
		public IWebElement ExchangeOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_cboEscrowAssistant")]
		public IWebElement ExchangeAssistant { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_cboBusinessSegment")]
		public IWebElement BusinessSegment { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ddlProduct")]
		public IWebElement Product { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_cboTransType")]
		public IWebElement TransactionType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtDL")]
		public IWebElement DeadLine45thDay { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtDW")]
		public IWebElement DayofWeek45thDay { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtDLT")]
		public IWebElement DaysLeft45thDay { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtCDL")]
		public IWebElement DeadLine180thDay { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtCDW")]
		public IWebElement DayofWeek180thDay { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtCDLT")]
		public IWebElement DaysLeft180thDay { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtFCD")]
		public IWebElement FirstCOEDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtAID")]
		public IWebElement ActualIDDate { get; set; }

        [FindsBy(How = How.Id, Using = "statuschgDateAndTime")]
        public IWebElement StatusDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnNewSrch")]
		public IWebElement TaxPayerNewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnAddNew")]
		public IWebElement TaxPayerAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnRemove")]
		public IWebElement TaxPayerRemove { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnVesting")]
        public IWebElement TaxPayerVesting { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnSignature")]
        public IWebElement TaxPayerSignatures { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtHusName")]
		public IWebElement TaxPayerHusName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtHusMiddle")]
		public IWebElement TaxPayerHusMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtHusLast")]
		public IWebElement TaxPayerHusLast { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtHusSuffix")]
		public IWebElement TaxPayerHusSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtHusSSNTIN")]
		public IWebElement TaxPayerHusSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSpouseName")]
		public IWebElement TaxPayerSpouseName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSpouseMiddle")]
		public IWebElement TaxPayerSpouseMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSpouseLast")]
		public IWebElement TaxPayerSpouseLast { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSpouseSuffix")]
		public IWebElement TaxPayerSpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSpouseSSNTIN")]
		public IWebElement TaxPayerSpouseSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_cboType")]
		public IWebElement TaxPayerType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSt1")]
		public IWebElement TaxPayerAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSt2")]
		public IWebElement TaxPayerAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSt3")]
		public IWebElement TaxPayerAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtSt4")]
		public IWebElement TaxPayerAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtCity")]
		public IWebElement TaxPayerCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_cboState")]
		public IWebElement TaxPayerState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtZIP")]
		public IWebElement TaxPayerZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtCounty")]
		public IWebElement TaxPayerCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_cboCountry")]
		public IWebElement TaxPayerCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtBusPh")]
		public IWebElement TaxPayerBusPh { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtHomePh")]
		public IWebElement TaxPayerHomePh { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtBusFax")]
		public IWebElement TaxPayerBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtCellFax")]
		public IWebElement TaxPayerCellFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtPager")]
		public IWebElement TaxPayerPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtEmail")]
		public IWebElement TaxPayerEmail { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ddlNoteType")]
		public IWebElement NoteType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtNotes")]
		public IWebElement Notes { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_TC_EA")]
		public IWebElement EATAcquisitionTab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_cboPropertyType")]
		public IWebElement EATAcqPropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_txtPropertySt1")]
		public IWebElement EATAcqPropertyAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_txtPropertySt2")]
		public IWebElement EATAcqPropertyAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_txtPropertySt3")]
		public IWebElement EATAcqPropertyAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_txtPropertySt4")]
		public IWebElement EATAcqPropertyAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_txtPropertyCity")]
		public IWebElement EATAcqPropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_cboPropertyState")]
		public IWebElement EATAcqPropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_txtPropertyZIP")]
		public IWebElement EATAcqPropertyZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_cboPropertyCounty")]
		public IWebElement EATAcqPropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_cboPropertyCountry")]
		public IWebElement EATAcqPropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeTerms_txtEscNo")]
		public IWebElement EATAcqTermsEscrowNumber { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeTerms_txtInProp")]
		public IWebElement EATAcqIntinProperty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeTerms_txtSalePrice")]
		public IWebElement EATAcqTermsSalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_txtEstDaystoClose")]
		public IWebElement EATAcqEstDaystoClose { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_txtEstSettleDate")]
		public IWebElement TCEAEEAucEesEstSettleDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_txtCOEDt")]
		public IWebElement EATAcqCOEDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_txtDateOfContractAccpt")]
		public IWebElement EATAcqDateofContractAcceptance { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_txtDtOfCont")]
		public IWebElement EATAcqDateofContract { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_chkPreRec")]
		public IWebElement EATAcqPreliiminaryRecieved { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_chkAgreeRec")]
		public IWebElement EATAcqAgreementReceived { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeDates_chkActCOE")]
		public IWebElement EATAcqActualCOE { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_txtGABcode")]
		public IWebElement EATAcqEscrowOfficerGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_cmdFindName")]
		public IWebElement EATAcqEscrowOfficeFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_txtName")]
		public IWebElement EATAcqEscrowOfficerGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_chkEditContactInfo")]
		public IWebElement EATAcqEscrowOfficerGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_textBusPhone")]
		public IWebElement TCEAEEAucEOBPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_txtExtnPhone")]
		public IWebElement TCEAEEAucEOBPExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_textBusFax")]
		public IWebElement TCEAEEAucEOBPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_textCellPhone")]
		public IWebElement TCEAEEAucEBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_textPager")]
		public IWebElement TCEAEEAucEOBPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucEOBP_textEmailAddress")]
		public IWebElement TCEAEEAucEextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_txtGABcode")]
		public IWebElement EATAcqTaxPayersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_txtName")]
		public IWebElement EATAcqTaxPayersAgentGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_cmdFindName")]
		public IWebElement EATAcqTaxPayersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_chkEditContactInfo")]
		public IWebElement EATAcqTaxPayersAgentGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_textBusPhone")]
		public IWebElement TCEAEEAucTABPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_txtExtnPhone")]
		public IWebElement TCEAEEAucTxABPExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_textBusFax")]
		public IWebElement TCEAEEAucTxABPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_textCellPhone")]
		public IWebElement TCEAEEAucTBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_textPager")]
		public IWebElement TCEAEEAucTxABPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucTxABP_textEmailAddress")]
		public IWebElement TCEAEEAucTextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_txtGABcode")]
		public IWebElement EATAcqSellersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_txtName")]
		public IWebElement EATAcqSellersAgentGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_cmdFindName")]
		public IWebElement EATAcqSellersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_chkEditContactInfo")]
		public IWebElement EATAcqSellersAgentGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_textBusPhone")]
		public IWebElement TCEAEEAucBABPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_txtExtnPhone")]
		public IWebElement TCEAEEAucBsABPExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_textBusFax")]
		public IWebElement TCEAEEAucBsABPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_textCellPhone")]
		public IWebElement TCEAEEAucBBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_textPager")]
		public IWebElement TCEAEEAucBsABPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucBsABP_textEmailAddress")]
		public IWebElement TCEAEEAucBextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnNewSrch")]
		public IWebElement EATAcqSellersNewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnAddNew")]
		public IWebElement EATAcqSellersAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnRemove")]
		public IWebElement EATAcqSellersRemove { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_cboType")]
		public IWebElement EATAcqSellersType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtIndName")]
		public IWebElement EATAcqSellersIndividualFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtIndMiddle")]
		public IWebElement EATAcqSellersIndividualMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtIndLast")]
		public IWebElement EATAcqSellersIndividualLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtIndSuffix")]
		public IWebElement EATAcqSellersIndividualSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtIndSSNTIN")]
		public IWebElement EATAcqSellersIndividualSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtHusName")]
		public IWebElement EATAcqSellersHusbandFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtHusMiddle")]
		public IWebElement EATAcqSellersHusbandMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtHusLast")]
		public IWebElement EATAcqSellersHusbandLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtHusSuffix")]
		public IWebElement EATAcqSellersHusbandSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtHusSSNTIN")]
		public IWebElement EATAcqSellersHusbandSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSpouseName")]
		public IWebElement EATAcqSellersSpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSpouseMiddle")]
		public IWebElement EATAcqSellersSpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSpouseLast")]
		public IWebElement EATAcqSellersSpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSpouseSuffix")]
		public IWebElement EATAcqSellersSpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSpouseSSNTIN")]
		public IWebElement EATAcqSellersSpouseSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtTrustBEName")]
		public IWebElement EATAcqSellersTrustEstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_radTrustBESSN")]
		public IWebElement EATAcqSellersTrustEstSSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_radTrustBETIN")]
		public IWebElement EATAcqSellersTrustEstTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement EATAcqSellersTrustEstSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtTrustBEName")]
		public IWebElement EATAcqSellersBusEntityName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_radTrustBESSN")]
		public IWebElement EATAcqSellersBusEntitySSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_radTrustBETIN")]
		public IWebElement EATAcqSellersBusEntityTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement EATAcqSellersBusEntitySSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSt1")]
		public IWebElement EATAcqAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSt2")]
		public IWebElement EATAcqAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSt3")]
		public IWebElement EATAcqAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtSt4")]
		public IWebElement EATAcqAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtCity")]
		public IWebElement EATAcqSellersCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_cboState")]
		public IWebElement EATAcqSellersState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtZIP")]
		public IWebElement EATAcqSellersZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtBusPh")]
		public IWebElement EATAcqSellersBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtHomePh")]
		public IWebElement EATAcqSellersHomePhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtBusFax")]
		public IWebElement EATAcqSellersBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtCellFax")]
		public IWebElement EATAcqSellersCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtPager")]
		public IWebElement EATAcqSellersPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtCounty")]
		public IWebElement EATAcqSellersCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_cboCountry")]
		public IWebElement EATAcqSellersCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_txtEmail")]
		public IWebElement EATAcqSellersEmail { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_TC_ED")]
		public IWebElement EATDispositionTab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_cboPropertyType")]
		public IWebElement EATDispPropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_txtPropertySt1")]
		public IWebElement EATDispPropertyAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_txtPropertySt2")]
		public IWebElement EATDispPropertyAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_txtPropertySt3")]
		public IWebElement EATDispPropertyAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_txtPropertySt4")]
		public IWebElement EATDispPropertyAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_txtPropertyCity")]
		public IWebElement EATDispPropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_cboPropertyState")]
		public IWebElement EATDispPropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_txtPropertyZIP")]
		public IWebElement EATDispPropertyZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_cboPropertyCounty")]
		public IWebElement EATDispPropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_cboPropertyCountry")]
		public IWebElement EATDispPropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeTerms_txtEscNo")]
		public IWebElement EATDispTermsEscrowNumber { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeTerms_txtSalePrice")]
		public IWebElement EATDispTermsSalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeTerms_txtInProp")]
		public IWebElement EATDispIntinProperty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_txtEstDaystoClose")]
		public IWebElement EATDispEstDaystoClose { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_txtEstSettleDate")]
		public IWebElement TCEDEEDucEesEstSettleDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_txtCOEDt")]
		public IWebElement EATDispCOEDate { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_txtDateOfContractAccpt")]
		public IWebElement EATDispDateofContractAcceptance { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_txtDtOfCont")]
		public IWebElement EATDispDateofContract { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_chkPreRec")]
		public IWebElement EATDispPreliiminaryRecieved { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_chkAgreeRec")]
		public IWebElement EATDispAgreementReceived { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeDates_chkActCOE")]
		public IWebElement EATDispActualCOE { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_txtGABcode")]
		public IWebElement EATDispEscrowOfficerGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_txtName")]
		public IWebElement EATDispEscrowOfficerGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_cmdFindName")]
		public IWebElement EATDispEscrowOfficeFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_chkEditContactInfo")]
		public IWebElement EATDispEscrowOfficerGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_textBusPhone")]
		public IWebElement TCEDEEDucEOBPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_txtExtnPhone")]
		public IWebElement TCEDEEDucEOBPExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_textBusFax")]
		public IWebElement TCEDEEDucEOBPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_textCellPhone")]
		public IWebElement TCEDEEDucEBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_textPager")]
		public IWebElement TCEDEEDucEOBPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucEOBP_textEmailAddress")]
		public IWebElement TCEDEEDucEextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_txtGABcode")]
		public IWebElement EATDispTaxPayersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_txtName")]
		public IWebElement EATDispTaxPayersAgentGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_cmdFindName")]
		public IWebElement EATDispTaxPayersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_chkEditContactInfo")]
		public IWebElement EATDispTaxPayersAgentGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_textBusPhone")]
		public IWebElement TCEDEEDucTABPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_txtExtnPhone")]
		public IWebElement TCEDEEDucTxABPExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_textBusFax")]
		public IWebElement TCEDEEDucTxABPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_textCellPhone")]
		public IWebElement TCEDEEDucTBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_textPager")]
		public IWebElement TCEDEEDucTxABPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucTxABP_textEmailAddress")]
		public IWebElement TCEDEEDucTextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_txtGABcode")]
		public IWebElement EATDispSellersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_txtName")]
		public IWebElement EATDispSellersAgentGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_cmdFindName")]
		public IWebElement EATDispSellersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_chkEditContactInfo")]
		public IWebElement EATDispSellersAgentGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_textBusPhone")]
		public IWebElement TCEDEEDucBABPtextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_txtExtnPhone")]
		public IWebElement TCEDEEDucBsABPExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_textBusFax")]
		public IWebElement TCEDEEDucBsABPtextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_textCellPhone")]
		public IWebElement TCEDEEDucBBPtextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_textPager")]
		public IWebElement TCEDEEDucBsABPtextPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucBsABP_textEmailAddress")]
		public IWebElement TCEDEEDucBextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnNewSrch")]
		public IWebElement EATDispSellersNewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnAddNew")]
		public IWebElement EATDispSellersAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnRemove")]
		public IWebElement EATDispSellersRemove { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_cboType")]
		public IWebElement EATDispSellersType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtIndName")]
		public IWebElement EATDispSellersIndividualFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtIndMiddle")]
		public IWebElement EATDispSellersIndividualMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtIndLast")]
		public IWebElement EATDispSellersIndividualLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtIndSuffix")]
		public IWebElement EATDispSellersIndividualSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtIndSSNTIN")]
		public IWebElement EATDispSellersIndividualSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtHusName")]
		public IWebElement EATDispSellersHusbandFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtHusMiddle")]
		public IWebElement EATDispSellersHusbandMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtHusLast")]
		public IWebElement EATDispSellersHusbandLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtHusSuffix")]
		public IWebElement EATDispSellersHusbandSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtHusSSNTIN")]
		public IWebElement EATDispSellersHusbandSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSpouseName")]
		public IWebElement EATDispSellersSpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSpouseMiddle")]
		public IWebElement EATDispSellersSpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSpouseLast")]
		public IWebElement EATDispSellersSpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSpouseSuffix")]
		public IWebElement EATDispSellersSpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSpouseSSNTIN")]
		public IWebElement EATDispSellersSpouseSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtTrustBEName")]
		public IWebElement EATDispSellersTrustEstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_radTrustBESSN")]
		public IWebElement EATDispSellersTrustEstSSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_radTrustBETIN")]
		public IWebElement EATDispSellersTrustEstTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement EATDispSellersTrustEstSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtTrustBEName")]
		public IWebElement EATDispSellersBusEntityName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_radTrustBESSN")]
		public IWebElement EATDispSellersBusEntitySSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_radTrustBETIN")]
		public IWebElement EATDispSellersBusEntityTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement EATDispSellersBusEntitySSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSt1")]
		public IWebElement EATDispAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSt2")]
		public IWebElement EATDispAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSt3")]
		public IWebElement EATDispAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtSt4")]
		public IWebElement EATDispAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtCity")]
		public IWebElement EATDispSellersCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_cboState")]
		public IWebElement EATDispSellersState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtZIP")]
		public IWebElement EATDispSellersZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtBusPh")]
		public IWebElement EATDispSellersBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtHomePh")]
		public IWebElement EATDispSellersHomePhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtBusFax")]
		public IWebElement EATDispSellersBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtCellFax")]
		public IWebElement EATDispSellersCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtPager")]
		public IWebElement EATDispSellersPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtCounty")]
		public IWebElement EATDispSellersCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_cboCountry")]
		public IWebElement EATDispSellersCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_txtEmail")]
		public IWebElement EATDispSellersEmail { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_TC_PT")]
		public IWebElement PartiesTab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_txtGABcode")]
		public IWebElement ReferredByGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_cmdFindName")]
		public IWebElement ReferredByFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_txtName")]
		public IWebElement ReferredByName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_chkEditContactInfo")]
		public IWebElement ReferredByEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_textBusPhone")]
		public IWebElement ReferredBytBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_txtExtnPhone")]
		public IWebElement TCPTEPTucRrredByExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_textBusFax")]
		public IWebElement ReferredByBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_textCellPhone")]
		public IWebElement ReferredByCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_textPager")]
		public IWebElement ReferredByPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucReferredBy_textEmailAddress")]
		public IWebElement ReferredByEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_txtGABcode")]
		public IWebElement CreditToGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_cmdFindName")]
		public IWebElement CreditToFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_chkEditContactInfo")]
		public IWebElement CreditToEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_textBusPhone")]
		public IWebElement CreditToBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_txtExtnPhone")]
		public IWebElement TCPTEPTucCeditToExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_textBusFax")]
		public IWebElement CreditToBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_textCellPhone")]
		public IWebElement CreditToCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_textPager")]
		public IWebElement CreditToPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucCreditTo_textEmailAddress")]
		public IWebElement CreditTotEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_txtGABcode")]
		public IWebElement TaxPayerRepGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_txtName")]
		public IWebElement TaxpayerRepName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_cmdFindName")]
		public IWebElement TaxPayerRepFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_chkEditContactInfo")]
		public IWebElement TaxPayerRepEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_textBusPhone")]
		public IWebElement TaxPayerRepBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_txtExtnPhone")]
		public IWebElement TCPTEPTucTyerRepExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_textBusFax")]
		public IWebElement TaxPayerRepBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_textCellPhone")]
		public IWebElement TaxPayerRepCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_textPager")]
		public IWebElement TaxPayerRepPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucTaxpayerRep_textEmailAddress")]
		public IWebElement TaxPayerRepEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_txtGABcode")]
		public IWebElement AdvisorCPAGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_txtName")]
		public IWebElement AdvisorCPAName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_cmdFindName")]
		public IWebElement AdvisorCPAFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_chkEditContactInfo")]
		public IWebElement AdvisorCPAEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_textBusPhone")]
		public IWebElement AdvisorCPABusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_txtExtnPhone")]
		public IWebElement TCPTEPTucAsorCPAExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_textBusFax")]
		public IWebElement AdvisorCPABusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_textCellPhone")]
		public IWebElement AdvisorCPACellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_textPager")]
		public IWebElement AdvisorCPAPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorCPA_textEmailAddress")]
		public IWebElement AdvisorCPAEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_txtGABcode")]
		public IWebElement AttorneyGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_txtName")]
		public IWebElement AttorneyGABName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_cmdFindName")]
		public IWebElement AttorneyGABFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_chkEditContactInfo")]
		public IWebElement AttorneyGABEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_textBusPhone")]
		public IWebElement AttorneyGABBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_textBusFax")]
		public IWebElement AttorneyGABBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_textCellPhone")]
		public IWebElement AttorneyGABCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_PT_EPT_ucAdvisorAttorney_textPager")]
		public IWebElement AttorneyGABPager { get; set; }

		///TODO: ADD FindsByAttribute
		//public IWebElement AttorneyGABEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_txtName")]
		public IWebElement REPSellersAgentName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_chkEditContactInfo")]
		public IWebElement REPSellersAgentEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnNewSrch")]
		public IWebElement REPNewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnAddNew")]
		public IWebElement REPAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnRemove")]
		public IWebElement REPSellersRemove { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtIndName")]
		public IWebElement REPSellersIndividualFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtIndMiddle")]
		public IWebElement REPSellersIndividualMidName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtIndLast")]
		public IWebElement REPSellersIndividualLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtIndSuffix")]
		public IWebElement REPSellerIndividualSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtIndSSNTIN")]
		public IWebElement REPSellerIndividualSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtHusName")]
		public IWebElement REPSEllerHusbandFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtHusMiddle")]
		public IWebElement REPSellerHusbandMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtHusSuffix")]
		public IWebElement REPSellerHusbandSuffixName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtHusSSNTIN")]
		public IWebElement REPSEllerHusbandSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSpouseName")]
		public IWebElement REPSellerSpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSpouseMiddle")]
		public IWebElement REPSellerSpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSpouseLast")]
		public IWebElement REPSellerpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSpouseSuffix")]
		public IWebElement REPSellerSpouseSuffixName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSpouseSSNTIN")]
		public IWebElement REPSellerSpouseSSNTINName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtTrustBEName")]
		public IWebElement REPSellerTrustEstateName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_radTrustBESSN")]
		public IWebElement REPSellerTrustEstateSSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_radTrustBETIN")]
		public IWebElement REPSellerTrustEstateTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement REPSellerTrustEstateSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtTrustBEName")]
		public IWebElement REPSellerBusEntityName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_radTrustBESSN")]
		public IWebElement REPSellerBusEntitySSN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_radTrustBETIN")]
		public IWebElement REPSellerBusEntityTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtTrustBESSNTIN")]
		public IWebElement REPSellerBusEntitySSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSt1")]
		public IWebElement REPAddressLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSt2")]
		public IWebElement REPAddressLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSt3")]
		public IWebElement REPAddressLine3 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtSt4")]
		public IWebElement REPAddressLine4 { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtCity")]
		public IWebElement REPSellersCity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_cboState")]
		public IWebElement REPSellersState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtZIP")]
		public IWebElement REPSellersZIP { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtBusPh")]
		public IWebElement REPSellersBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtHomePh")]
		public IWebElement REPSellersHomePhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtBusFax")]
		public IWebElement REPSellersBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtCellFax")]
		public IWebElement REPSellersCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtPager")]
		public IWebElement REPSellersPager { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtCounty")]
		public IWebElement REPSellersCounty { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_cboCountry")]
		public IWebElement REPSellersCountry { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtEmail")]
		public IWebElement REPSellersEmail { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_txtHusLast")]
		public IWebElement TCRPERPucEchangeBSHusLast { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtIndName")]
		public IWebElement TaxpyrIndividualName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtIndMiddle")]
		public IWebElement TaxpyrIndividualMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtIndLast")]
		public IWebElement TaxpyrIndividualLast { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtIndSuffix")]
		public IWebElement TaxpyrIndividualSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtIndSSNTIN")]
		public IWebElement TaxpyrIndividualSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtTrustBEName")]
		public IWebElement TaxPayrTrustEstateName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtTrustBESSNTIN")]
		public IWebElement TaxPayrTrustEstateSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtTrustBEName")]
		public IWebElement TaxPayrBusinessEntityName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_txtTrustBESSNTIN")]
		public IWebElement TaxPayrBusinessEntitySSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_txtTran")]
		public IWebElement RelPropertyTransactionNo { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeTerms_txtSalePrice")]
		public IWebElement RelTermsSalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_txtIndName")]
		public IWebElement RelBuyersIndividualFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_cboPropertyState")]
		public IWebElement REPPropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_cboType")]
		public IWebElement REPSellersType { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucTxABP_txtGABcode")]
		public IWebElement REPTaxpayersAgentGABCode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucTxABP_cmdFindName")]
		public IWebElement REPTaxpayersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_txtGABcode")]
		public IWebElement REPSellersAgentGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucBsABP_cmdFindName")]
		public IWebElement REPSellersAgentFind { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_TC_TS")]
		public IWebElement TransSummarytab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_TS_ETS_btnEdit")]
		public IWebElement TransTabEditbutton { get; set; }

        [FindsBy(How = How.Id, Using = "TC_TS_ETS_btnRemove")]
        public IWebElement TransTabRemove { get; set; }

        [FindsBy(How = How.Id, Using = "TC_TS_ETS_dgTS")]
        public IWebElement TransSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_dgridBuyerSeller")]
		public IWebElement RelBuyerTable { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_dgridBuyerSeller")]
		public IWebElement RepSellerTable { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_dgridBuyerSeller")]
		public IWebElement EATAcqSellerTable { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_dgridBuyerSeller")]
		public IWebElement EATDispBuyerTable { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement RELBusinessEntityViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement RELSpouse1ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnSpouseViewEditSSNTIN")]
		public IWebElement RELSpouse2ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement RELIndividualViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement RELTrustEstateViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement REPIndividualViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement REPTrustEstateViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement REPSpouse1ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnSpouseViewEditSSNTIN")]
		public IWebElement REPSpouse2ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement REPBusinessEntityViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement ACQIndividualViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement ACQSpouse1ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnSpouseViewEditSSNTIN")]
		public IWebElement ACQSpouse2ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement ACQTrustEstateViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_EA_EEA_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement ACQBusinessEntityViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement DISPIndividualViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnIndHusViewEditSSNTIN")]
		public IWebElement DISPSpouse1ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnSpouseViewEditSSNTIN")]
		public IWebElement DISSpouse2ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement DISPTrustEstateViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnTEBEViewEditSSNTIN")]
		public IWebElement DISPBusinessEntityViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_dgridBuyerSeller")]
		public IWebElement DetailsTaxPayerTable { get; set; }
        
		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnTEBEViewEditSSNTIN")]
		public IWebElement TaxPayerBEViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnIndHusViewEditSSNTIN")]
		public IWebElement TaxPayerSpouse1ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnSpouseViewEditSSNTIN")]
		public IWebElement TaxPayerSpouse2ViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnTEBEViewEditSSNTIN")]
		public IWebElement TaxPayerTEViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnIndHusViewEditSSNTIN")]
		public IWebElement TaxPayerIndViewEdit { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RL_ERL_ucExchangeBS_btnSignature")]
		public IWebElement RELSignatures { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_ERP_ucExchangeBS_btnSignature")]
		public IWebElement REPSignatures { get; set; }

		[FindsBy(How = How.Id, Using = "TC_RP_EEA_ucExchangeBS_btnSignature")]
		public IWebElement EATACQSignatures { get; set; }

		[FindsBy(How = How.Id, Using = "TC_ED_EED_ucExchangeBS_btnSignature")]
		public IWebElement EATDispSignatures { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_ucPriTaxpyr_btnSignature")]
		public IWebElement DetailsSignatures { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DT_tab")]
        public IWebElement DetailsTab { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtCustFileNo")]
		public IWebElement FileNo { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtReverserEntity")]
		public IWebElement ReverseEntity { get; set; }

		[FindsBy(How = How.Id, Using = "TC_DT_EDT_txtRelatedTransaction")]
		public IWebElement RelatedTransaction { get; set; }
        
        [FindsBy(How = How.Id, Using = "TC_DT_EDT_chkExchange")]
        public IWebElement Service { get; set; }

      

        #endregion

        #region Dynamic Elements

        public IWebElement Tab(string tabName)
        {
            return WebDriver.FindElement(By.CssSelector("span[title='"+tabName+"']"));
        }

        #endregion

        #region Useful Methods

        public ExchangeFileEntry EnterPartiesTabGABCode(string ReferredByGABCode = null, string CreditToGABCode = null, string TaxPayerRepGABCode = null, string CPAGABCode = null, string AdvisorAttorneyGABCode = null)
        {
            this.ReferredByGABcode.FASetText(ReferredByGABCode);
            this.ReferredByFind.FAClick();
            this.CreditToGABcode.FASetText(CreditToGABCode);
            this.CreditToFind.FAClick();
            this.TaxPayerRepGABcode.FASetText(TaxPayerRepGABCode);
            this.TaxPayerRepFind.FAClick();
            this.AdvisorCPAGABcode.FASetText(CPAGABCode);
            this.AdvisorCPAFind.FAClick();
            this.AttorneyGABcode.FASetText(AdvisorAttorneyGABCode);
            this.AttorneyGABFind.FAClick();
            return this;
        }

        public ExchangeFileEntry EnterRelinquishedTabGABCode(string EscrowOfficerGABCode = null, string TaxPayerAgentGABCode = null, string BuyerAgentGABCode = null)
        {
            this.RelEscrowOfficerGABcode.FASetText(EscrowOfficerGABCode);
            this.RelEscrowOfficeFind.FAClick();
            this.RelTaxPayersAgentGABcode.FASetText(TaxPayerAgentGABCode);
            this.RelTaxPayersAgentFind.FAClick();
            this.RelBuyersAgentGABcode.FASetText(BuyerAgentGABCode);
            this.RelBuyersAgentFind.FAClick();
            return this;
        }

        public ExchangeFileEntry EnterReplacementTabGABCode(string EscrowOfficerGABCode = null, string TaxPayerAgentGABCode = null, string SellerAgentGABCode = null)
        {
            this.REPEscrowOfficerGABCode.FASetText(EscrowOfficerGABCode);
            this.REPEscrowOfficerFind.FAClick();
            this.REPTaxpayersAgentGABCode.FASetText(TaxPayerAgentGABCode);
            this.REPTaxpayersAgentFind.FAClick();
            this.REPSellersAgentGABcode.FASetText(SellerAgentGABCode);
            this.REPSellersAgentFind.FAClick();
            return this;
        }

        public ExchangeFileEntry EnterEATAcquisitionTabGABCode(string EscrowOfficerGABCode = null, string TaxPayerAgentGABCode = null, string SellerAgentGABCode = null)
        {
            this.EATAcqEscrowOfficerGABcode.FASetText(EscrowOfficerGABCode);
            this.EATAcqEscrowOfficeFind.FAClick();
            this.EATAcqTaxPayersAgentGABcode.FASetText(TaxPayerAgentGABCode);
            this.EATAcqTaxPayersAgentFind.FAClick();
            this.EATAcqSellersAgentGABcode.FASetText(SellerAgentGABCode);
            this.EATAcqSellersAgentFind.FAClick();
            return this;
        }

        public ExchangeFileEntry EnterEATDispositionGABCode(string EscrowOfficerGABCode = null, string TaxPayerAgentGABCode = null, string SellerAgentGABCode = null)
        {
            this.EATDispEscrowOfficerGABcode.FASetText(EscrowOfficerGABCode);
            this.EATDispEscrowOfficeFind.FAClick();
            this.EATDispTaxPayersAgentGABcode.FASetText(TaxPayerAgentGABCode);
            this.EATDispTaxPayersAgentFind.FAClick();
            this.EATDispSellersAgentGABcode.FASetText(SellerAgentGABCode);
            this.EATDispSellersAgentFind.FAClick();
            return this;
        }

        public ExchangeFileEntry WaitForTabToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TransSummarytab);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            return this;
        }

        public ExchangeFileEntry WaitForScreenToLoad()
        {
            try
            {
                FastDriver.FileSearch.SwitchToContentFrame();
                if(FastDriver.FileSearch.SkipSearch.Exists()) FastDriver.FileSearch.SkipSearch.FAClick();
            }
            catch { } //SkipSearch screen is configurable
            this.SwitchToContentFrame();
            this.WaitCreation(TransactionType);
            return this;
        }

        public ExchangeFileEntry WaitForScreenLoad(IWebElement element = null, bool skipSearch = true)
        {
            if (skipSearch)
            {
                FastDriver.FileSearch.SwitchToContentFrame();
                FastDriver.FileSearch.WaitCreation(FastDriver.FileSearch.SkipSearch);
                FastDriver.FileSearch.SkipSearch.FAClick();
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? TransactionType);
            }
            else
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? TransactionType);
            }
            return this;
        }

        public ExchangeFileEntry Open()
        {
            FastDriver.LeftNavigation.Navigate<ExchangeFileEntry>(@"Home>Order Entry>1031 Exchange>Exchange File Entry");
            this.WaitForScreenToLoad();
            return this;
        }

        public ExchangeFileEntry ClickTabAndWaitForScreen(IWebElement tabName, IWebElement element)
        {
            tabName.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            this.WaitCreation(element);
            return this;
        }

        public ExchangeFileEntry CreateExchangeFile(string TransType, string Office)
        {
            WaitForScreenLoad();
            TransactionType.FASelectItem(TransType);
            ExchangeOffice.FASelectItem(Office);
            TaxPayerAddNew.FAClick();
            TaxPayerType.FASelectItem("Individual");
            TaxpyrIndividualName.FASetText("John");
            TaxpyrIndividualLast.FASetText("Doe");
            TaxpyrIndividualSSNTIN.FASetText("123456789");
            TaxPayerAddressLine1.FASetText("1 Main St.");
            TaxPayerCity.FASetText("Santa Ana");
            TaxPayerState.FASelectItem("CA");
            TaxPayerZIP.FASetText("92707");
            TaxPayerCounty.FASetText("Orange");
            TaxPayerBusPh.FASetText("9999999999");
            TaxPayerHomePh.FASetText("9999999999");
            TaxPayerCellFax.FASetText("9999999999");
            TaxPayerPager.FASetText("9999999999");
            TaxPayerEmail.FASetText("test@test.net");
            ClickTabAndWaitForScreen(PartiesTab, ReferredByGABcode);
            EnterPartiesTabGABCode("DIRECTEDBY", "CTESTDKEXU", "CTESTYMJCA", "EXCHCPA", "ATNYTITCMP");

            if (FastDriver.ExchangeFileEntry.TransactionType.FAGetSelectedItem().Equals("Delayed"))
            {
                ClickTabAndWaitForScreen(RelinquishedTab, RelEstDaystoClose);
                RelPropertyType.FASelectItem("Single Family Residence");
                RelPropertyAddressLine1.FASetText("1 Main St.");
                RelPropertyCity.FASetText("Santa Ana");
                RelPropertyState.FASelectItem("CA");
                RelPropertyZIP.FASetText("92707");
                RelPropertyCounty.FASelectItem("Orange");
                EnterRelinquishedTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                RelBuyersAddNew.FAClick();
                RelBuyersType.FASelectItem("Individual");
                RelBuyersIndividualFirstName.FASetText("Jane");
                RelBuyersIndividualLastName.FASetText("Doe");
                RelBuyersIndividualSSNTIN.FASetText("123456789");
                RelAddressLine1.FASetText("1 Main St.");
                RelBuyersCity.FASetText("Santa Ana");
                RelBuyersState.FASelectItem("CA");
                RelBuyersZIP.FASetText("92707");
                RelBuyersCounty.FASetText("Orange");
                RelBuyersBusPhone.FASetText("9999999999");
                RelBuyersHomePhone.FASetText("9999999999");
                RelBuyersCellPhone.FASetText("9999999999");
                RelBuyersPager.FASetText("9999999999");
                RelBuyersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            else
            {
                ClickTabAndWaitForScreen(EATAcquisitionTab, EATAcqPropertyType);
                EATAcqPropertyType.FASelectItem("Single Family Residence");
                EATAcqPropertyAddressLine1.FASetText("1 Main St.");
                EATAcqPropertyCity.FASetText("Santa Ana");
                EATAcqPropertyState.FASelectItem("CA");
                EATAcqPropertyZIP.FASetText("92707");
                EATAcqPropertyCounty.FASelectItem("Orange");
                EnterEATAcquisitionTabGABCode("CTESTDKEXU", "CTESTYMJCA", "CTESTYMJCA");
                EATAcqSellersAddNew.FAClick();
                EATAcqSellersType.FASelectItem("Individual");
                EATAcqSellersIndividualFirstName.FASetText("Jane");
                EATAcqSellersIndividualLastName.FASetText("Doe");
                EATAcqSellersIndividualSSNTIN.FASetText("123456789");
                EATAcqAddressLine1.FASetText("1 Main St.");
                EATAcqSellersCity.FASetText("Santa Ana");
                EATAcqSellersState.FASelectItem("CA");
                EATAcqSellersZIP.FASetText("92707");
                EATAcqSellersCounty.FASetText("Orange");
                EATAcqSellersBusPhone.FASetText("9999999999");
                EATAcqSellersHomePhone.FASetText("9999999999");
                EATAcqSellersCellPhone.FASetText("9999999999");
                EATAcqSellersPager.FASetText("9999999999");
                EATAcqSellersEmail.FASetText("test@test.net");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
            }

            return this;

        }

        #endregion
    }
}
