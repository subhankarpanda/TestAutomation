﻿using System;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System.Collections.Generic;
using System.Threading.Tasks;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class ExchangePropertiesLegalDescription : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlProperties")]
        public IWebElement PropertySelection { get; set; }

        [FindsBy(How = How.Id, Using = "txtPropertyType")]
        public IWebElement PropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "txtCmpltComnts")]
        public IWebElement CompleteLegalDescription { get; set; }
        
        [FindsBy(How = How.Id, Using = "cmdCView")]
        public IWebElement View { get; set; }

        [FindsBy(How = How.Id, Using = "cmdCChkSpell")]
        public IWebElement CheckSpelling { get; set; }

        #endregion

        #region Useful Methods

        public ExchangePropertiesLegalDescription Open()
        {
            FastDriver.LeftNavigation.Navigate<ExchangePropertiesLegalDescription>(@"Home>Order Entry>1031 Exchange>Properties Legal Description");
            this.WaitForScreenToLoad();
            return this;
        }

        public ExchangePropertiesLegalDescription WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? CompleteLegalDescription);
            return this;
        }

        #endregion
    }
}
