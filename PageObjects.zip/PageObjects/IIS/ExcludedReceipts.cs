using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ExcludedReceipts : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboBankAccounts")]
		public IWebElement BankAccounts { get; set; }

		[FindsBy(How = How.Id, Using = "txtFromDate")]
		public IWebElement FromDate { get; set; }

		[FindsBy(How = How.Id, Using = "txtToDate")]
		public IWebElement ToDate { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFind")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.LinkText, Using = "Excluded Receipts")]
		public IWebElement lnkExcludedReceipts { get; set; }

		[FindsBy(How = How.LinkText, Using = "Receipts/Deposits")]
		public IWebElement ReceiptsDeposits { get; set; }

		[FindsBy(How = How.Id, Using = "dgExcludedReceipts_dgExcludedReceipts")]
		public IWebElement ExcludedReceiptsTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgExcludedReceipts_0_labelIssDate")]
		public IWebElement ExcludedReceiptDate { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		#endregion

        public ExcludedReceipts Open()
        {
            FastDriver.LeftNavigation.Navigate<ExcludedReceipts>(@"Home>Business Unit Processing>Deposit Slip>Excluded Receipts");
            this.WaitForScreenToLoad();
            return this;
        }
        public ExcludedReceipts WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FindNow);

            return this;
        }

	}
}
