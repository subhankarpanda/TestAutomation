using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ExclusionCommentDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "taComment")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "cBoxUnexclude")]
		public IWebElement Unexclude { get; set; }

		#endregion

        public ExclusionCommentDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? Comments);
            return this;
        }

	}
}
