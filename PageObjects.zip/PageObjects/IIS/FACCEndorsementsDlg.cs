using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class FACCEndorsementsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridEnds_0_chkSelEnd")]
        public IWebElement SelectEndorsement { get; set; }

        [FindsBy(How = How.Id, Using = "dgridEnds_1_chkSelEnd")]
        public IWebElement SelectEndorsement1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridEnds_0_lblEndName")]
        public IWebElement SelectEndorsementName { get; set; }
        
        [FindsBy(How = How.Id, Using = "dgridEnds_dgridEnds")]
        public IWebElement FACCEndorsementsTable { get; set; }

        public IWebElement GetSelectEndorsement(int index = 0)
        {
            return this.WebDriver.FindElement(By.Id("dgridEnds_" + index + "_chkSelEnd"));
        }
        #endregion

        public FACCEndorsementsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FACCEndorsementsTable);
            return this;
        }        
    }
}
