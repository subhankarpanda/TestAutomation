﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class FACCProductsDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "ddlTitleProduct")]
        public IWebElement TitleProductDropDown { get; set; }

        [FindsBy(How = How.Id, Using = "ddlRateTypes")]
        public IWebElement RateTypesDropDown { get; set; }
        #endregion


        public FACCProductsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? TitleProductDropDown);
            return this;
        }
    }
}
