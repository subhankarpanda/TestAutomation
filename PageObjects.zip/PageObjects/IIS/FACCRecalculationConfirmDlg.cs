﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FASTSelenium.PageObjects.IIS
{
    public class FACCRecalculationConfirmDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "FAFDialog_0")]
        public IWebElement Window { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='Table2']/tbody/tr[2]/td/b")]
        public IWebElement MessageText { get; set; }

        [FindsBy(How = How.Id, Using = "btnRecalculate")]
        public IWebElement RecalculateFees { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemoveFees")]
        public IWebElement RemoveFees { get; set; }

        [FindsBy(How = How.Id, Using = "btnRecalculate")]
        public IWebElement Recalculate { get; set; }
        //public IWebElement Recalculate { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemoveFees")]
        public IWebElement Remove { get; set; }

        #endregion WebElements

        public FACCRecalculationConfirmDlg WaitForScreenToLoad(string windowName = "Recalculation Confirmation", IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Cancel);
            return this;
        }

        public bool IsConfirmationDlgPresent()
        {
            try
            {
                return Window.IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void ClickCancel(string windowName = "Recalculation confirmation")
        {
            if (IsConfirmationDlgPresent())
            {
                WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
                this.SwitchToDialogContentFrame();
                this.WaitCreation(Cancel);
                Cancel.Click();
                FastDriver.DialogBottomFrame.ClickDone();
                WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
        }
    }
}
