﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using System;

namespace FASTSelenium.PageObjects.IIS
{
    public class FACCWorkbenchDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "chkallfee")]
        public IWebElement AllFeesCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkalltefee")]
        public IWebElement TitleAndEndorsementFeesCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkallrtfee")]
        public IWebElement RecordingFeesCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelFACCDialog")]
        public IWebElement FACCWorkbenchCancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }
        
        [FindsBy(How = How.Id, Using = "btnNext")]
        public IWebElement Next { get; set; }
        
        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnReset")]
        public IWebElement Reset { get; set; }

        [FindsBy(How = How.Id, Using = "grid1")]
        public IWebElement SiteFilesTable { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//div[@title='State']/following-sibling::Div[1]/div/div/select")]
        public IWebElement StateFilter { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@title='County']/following-sibling::Div[1]/div/div/select")]
        public IWebElement CountyFilter { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@title='City']/following-sibling::Div[1]/div/div/select")]
        public IWebElement CityFilter { get; set; }

        //TODO: Remove this one
        [FindsBy(How = How.XPath, Using = "//div/i[@class='ui-grid-icon-cancel']")]
        public IWebElement RemoveFilter { get; set; }//X image button
        
        //Problem: dynamic element has to be found using WebDriver instead of calling the element from PO
        [FindsBy(How = How.Id, Using = "//div[@title='State']/following-sibling::Div[2]/div/div/div/i[@class='ui-grid-icon-cancel']")]
        public IWebElement RemoveFilterState { get; set; }//X image button

        //Problem: dynamic element has to be found using WebDriver instead of calling the element from PO
        [FindsBy(How = How.Id, Using = "//div[@title='County']/following-sibling::Div[2]/div/div/div/i[@class='ui-grid-icon-cancel']")]
        public IWebElement RemoveFilterCounty { get; set; }//X image button

        //Problem: dynamic element has to be found using WebDriver instead of calling the element from PO
        [FindsBy(How = How.Id, Using = "//div[@title='City']/following-sibling::Div[2]/div/div/div/i[@class='ui-grid-icon-cancel']")]
        public IWebElement RemoveFilterCity { get; set; }//X image button
        
        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lbl1")]
        public IWebElement TransactionInfoUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_Faflabel6")]
        public IWebElement TransactionInfoTransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblState")]
        public IWebElement TransactionInfoState { get; set; }
        
        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblCounty")]
        public IWebElement TransactionInfoCounty { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblCity")]
        public IWebElement TransactionInfoCity { get; set; }
        
        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_Faflabel5")]
        public IWebElement TransactionInfoZipCode { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tCF_tL1_ucTr_pnlTrans > table")]
        public IWebElement TransactionInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_txtAssociatedFileNum")]
        public IWebElement TransactionInfoAssociatedFileNum { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_liabAmnt")]
        public IWebElement TransactionInfoFirstOwnersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblSecondOwnerPolicyLiabilityAmnt")]
        public IWebElement TransactionInfoSecondOwnersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblThirdOwnerPolicyLiabilityAmnt")]
        public IWebElement TransactionInfoThirdOwnersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblFourthOwnerPolicyLiabilityAmnt")]
        public IWebElement TransactionInfoFourthOwnersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblFifthOwnerPolicyLiabilityAmnt")]
        public IWebElement TransactionInfoFifthOwnersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblFirstNewLoan")]
        public IWebElement TransactionInfoFirstLendersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblSecondNewLoanLiabilityAmnt")]
        public IWebElement TransactionInfoSecondLendersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblThirdNewLoanLiabilityAmnt")]
        public IWebElement TransactionInfoThirdLendersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblFourthNewLoanLiabilityAmnt")]
        public IWebElement TransactionInfoFourthLendersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_lblFifthNewLoanLiabilityAmnt")]
        public IWebElement TransactionInfoFifthLendersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tCF_tL2_ucRf_pnlRecords > table")]
        public IWebElement RecordingInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTr_dtEffective")]
        public IWebElement TransactionInformationRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_btnAddTitleProd")]
        public IWebElement TitleFeesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_btnRemoveTitleProd")]
        public IWebElement TitleFeesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_ddlTitlePrdcts1")]
        public IWebElement TitleFeesTitlePolicy { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_ddlRateTypes")]
        public IWebElement TitleFeesRateTypes { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_btnAddEnd")]
        public IWebElement EndorsementsAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_btnRemoveEnd")]
        public IWebElement EndorsementsRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary_2_txtSplitPercntg")]
        public IWebElement SummarySplitPercentage3 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_ddlTitlePrdcts2")]
        public IWebElement EndorsementsTitlePolicy { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_NoTitlePolicyEffectiveDate")]
        public IWebElement EndorsementsRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_grdEnd_0_btnEnd")]
        public IWebElement AddRemoveEndorsement1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucEnd_grdEnd_1_btnEnd")]
        public IWebElement AddRemoveEndorsement2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_btnAddRec")]
        public IWebElement RecordingFeesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_btnRemoveRec")]
        public IWebElement RecordingFeesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_ddlRecords")]
        public IWebElement RecordingFeesRecordingDocument { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_txtPages")]
        public IWebElement RecordingFeesPages { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_txtCAmnt")]
        public IWebElement RecordingFeesConsiderationAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_grdRecords")]
        public IWebElement RecordingTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tCF_tL2_ucRf_grdRecords")]
        public IWebElement QuestionnaireRecordingTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL2_ucTf_grTitlePrdcts")]
        public IWebElement QuestionnaireTitleProductsTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_dtEffective")]
        public IWebElement TitleProductAndEndorsementRateEffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_0_btnEnd")]
        public IWebElement AddEndorsementsButton_Product1 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_2_btnEnd")]
        public IWebElement AddEndorsementsButton_Product2 { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_0_btnProd")]
        public IWebElement AddProduct2Button { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_btnAddEndorsement")]
        public IWebElement AddEndorsementWOProductBtn { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts")]
        public IWebElement TitleFeesTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "tCF_tCS_ucCSFs_grCalcSummary")]
        public IWebElement FACCSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_lbl1")]
        public IWebElement SummaryTransactionInfoUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_Faflabel6")]
        public IWebElement SummaryTransactionInfoTransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_lblState")]
        public IWebElement SummaryTransactionInfoState { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_lblCounty")]
        public IWebElement SummaryTransactionInfoCounty { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_lblCity")]
        public IWebElement SummaryTransactionInfoCity { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_Faflabel5")]
        public IWebElement SummaryTransactionInfoZipCode { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tCF_tCS_ucTr_pnlTrans > table")]
        public IWebElement SummaryTransactionInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_txtAssociatedFileNum")]
        public IWebElement SummaryTransactionInfoAssociatedFileNum { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_liabAmnt")]
        public IWebElement SummaryTransactionInfoFirstOwnersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tCS_ucTr_lblFirstNewLoan")]
        public IWebElement SummaryTransactionInfoFirstLendersPolicyLiabilityAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucTf_grTitlePrdcts_0_chkIsSelected")]
        public IWebElement FirstProductSelectionCheckboxInFACCInitializationPage { get; set; }

        #endregion

        #region PageObjectMethods
        public FACCWorkbenchDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? AllFeesCheckbox);

            return this;
        }

        public void SelectTitlePolicy(string Date, string TitlePolicy, string RateType)
        {
            if (Date != "")
                SelectRateEffectiveDate(Date);
            SelectTitleProduct(TitlePolicy);
            WaitForScreenToLoad(TitleFeesRateTypes);
            SelectRateType(RateType);
            PerformAddTitleProducts();
            WaitForScreenToLoad(AddEndorsementsButton_Product1);
        }
        public void SelectRateEffectiveDate(string Date)
        {
            WaitForScreenToLoad(TitleProductAndEndorsementRateEffectiveDate);
            TitleProductAndEndorsementRateEffectiveDate.FAClick();
            TitleProductAndEndorsementRateEffectiveDate.FASendKeys(Date);
        }
        public void SelectTitleProduct(string TitlePolicy)
        {
            WaitForScreenToLoad(TitleFeesTitlePolicy);
            TitleFeesTitlePolicy.FASelectItemBySendingKeys(TitlePolicy);
        }
        public void SelectRateType(string RateType)
        {
            WaitForScreenToLoad(TitleFeesRateTypes);
            TitleFeesRateTypes.FASelectItemBySendingKeys(RateType);
        }
        public void PerformAddTitleProducts()
        {
            WaitForScreenToLoad(TitleFeesAdd);
            TitleFeesAdd.FAClick();
        }
        public void SelectRecordingFees(string RecordingDoc, string pages, string ConsiderationAmount)
        {
            WaitForScreenToLoad(RecordingFeesRecordingDocument);
            RecordingFeesRecordingDocument.FASelectItem(RecordingDoc);
            RecordingFeesPages.FASetText(pages + FAKeys.Tab);
            RecordingFeesConsiderationAmount.FASetText(ConsiderationAmount + FAKeys.Tab);
            RecordingFeesAdd.FAClick();
        }

        public FACCWorkbenchDlg AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false, bool clickAccept = true)
        {
              string alertText = "";
              try
              {
                    WebDriver.WaitForAlertToExist(5);
                    var alert = WebDriver.SwitchTo().Alert();
                    alertText = alert.Text;
                    if(clickAccept)
                          alert.Accept();
                    else
                          alert.Dismiss();
                    if(SwitchToWindow)
                          WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
              }
              catch(Exception)
              {
                    alertText = "No Alert was Found";
              }
              finally
              {
                    if(CompareWith != null)
                    {
                          SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
                    }

              }
              return this;
        }
        
        #endregion
    }
}
