using System;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using AutoIt;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class FASTClosingfastcs : PageObject
	{
        #region WebElements

        #region Login/Redirect Page
        [FindsBy(How = How.Id, Using = "spanmsg")]
        public IWebElement SuccessfulLogin { get; set; }

        [FindsBy(How = How.XPath, Using = "table[contains(@background, 'background.jpg')]")]
        public IWebElement ScSeBackground { get; set; }
        #endregion

        #region Search Page
        [FindsBy(How = How.Id, Using = "drpRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "FAFdpdSearchForType")]
		public IWebElement SearchFor { get; set; }

		[FindsBy(How = How.Id, Using = "FAFtxtOrderNo")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "txtExtFileNum")]
		public IWebElement ExternalFileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "FAFtxtPropertyAddress")]
		public IWebElement PropertyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "FAFtxtCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Id, Using = "FAFdpdState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "FAFtxtCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "FAFtxtBuyerLname")]
		public IWebElement BuyerLastname { get; set; }

		[FindsBy(How = How.Id, Using = "FAFtxtSellerLname")]
		public IWebElement SellerLastname { get; set; }

        [FindsBy(How = How.Id, Using = "FAFtxtLender")]
        public IWebElement BusinessSource { get; set; }

        [FindsBy(How = How.Id, Using = "FAFtxtOrderDate")]
        public IWebElement FileOpenDate { get; set; }

		[FindsBy(How = How.Id, Using = "Submit1")]
		public IWebElement SearchButton { get; set; }
        #endregion

        #region Details Page
        [FindsBy(How = How.Id, Using = "CSLblOrderNumberFile")]
		public IWebElement DetailsFileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "CSlblRegion")]
		public IWebElement DetailsRegion { get; set; }

		[FindsBy(How = How.Id, Using = "Table7")]
		public IWebElement DetailsTable { get; set; }

		[FindsBy(How = How.Id, Using = "fafdgPartyDetail")]
		public IWebElement PartyDetailTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Buyer/Borrower")]
		public IWebElement PartyDetailPane { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_start.aspx')]")]
        public IWebElement ScheduleNewClosing { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'rescheduleClosing')]")]
        public IWebElement ReschedClosing { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_detail.aspx')]")]
        public IWebElement ClosingDetail { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_closing_history.aspx')]")]
        public IWebElement ClosingHistory { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'do_delete')]")]
        public IWebElement DeleteClosing { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'dailyView')]")]
        public IWebElement DailyView { get; set;}

        #endregion

        #region Nav Bar
        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'usr_logoff.aspx')]")]
		public IWebElement LogOff { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'OrderSearch.aspx')]")]
        public IWebElement SearchLink { get; set; }

        #endregion

        #region Schedule Closing Main
        [FindsBy(How = How.Id, Using = "ScheduleToolbar_dpdlistRegion")]
        public IWebElement RegionList { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_dpdlistOffice")]
        public IWebElement OfficeList { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_todayLink")]
        public IWebElement Today { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_leftarrow")]
        public IWebElement LeftArrowDate { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_rightarrow")]
        public IWebElement RightArrowDate { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_calLink")]
        public IWebElement ScheduleCalendar { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_dpdLstStartTime")]
        public IWebElement ScheduleStartTime { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_dpdlstendTime")]
        public IWebElement ScheduleEndTime { get; set; }

        [FindsBy(How = How.Id, Using = "ScheduleToolbar_cancelLink")]
        public IWebElement CancelSchedule { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@id='clnEvnStart']/table[4]")]
        public IWebElement StartScheduleTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@id='clnEvnEnd']/table[2]")]
        public IWebElement EndScheduleTable { get; set; }
        #endregion

        #region Schedule Closing Daily View
        [FindsBy(How = How.Id, Using = "ScheduleToolbar_dpdListView")]
        public IWebElement ListView { get; set; }
        #endregion

        #region Closing Details
        [FindsBy(How = How.Id, Using = "CSlblOrderNumber")]
        public IWebElement ClosingDetailsFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdClosingOwnerRegion")]
        public IWebElement ClosingOwnerRegion { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdClosingOwnerOffice")]
        public IWebElement ClosingOwnerOffice { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdClosingLocationRegion")]
        public  IWebElement ClosingLocationRegion { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdClosingLocationOffice")]
        public IWebElement ClosingLocationOffice { get; set; }

        [FindsBy(How = How.Id, Using = "FindOffince")]
        public IWebElement FindOffice { get; set; }

        [FindsBy(How = How.Id, Using = "OtherLocation")]
        public IWebElement OtherLocation { get; set; }

        [FindsBy(How = How.Id, Using = "clprepareduid")]
        public IWebElement ClosingPrepared { get; set; }

        [FindsBy(How = How.Id, Using = "FindUser")]
        public IWebElement FindUser { get; set; }

        [FindsBy(How = How.Id, Using = "CStxtClosingPrepared")]
        public IWebElement OrUser { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdClosingType")]
        public IWebElement ClosingType { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdSubClosingType")]
        public IWebElement SubClosingType { get; set; }

        [FindsBy(How = How.Id, Using = "CSdpdCalendarParty")]
        public IWebElement CalendarParty { get; set; }

        [FindsBy(How = How.Id, Using = "CStxtCalendarParty")]
        public IWebElement CalendarParty2 { get; set; }

        [FindsBy(How = How.Id, Using = "CSchkComplete")]
        public IWebElement Complete { get; set; }

        [FindsBy(How = How.Id, Using = "CSTextBox1")]
        public IWebElement Notes { get; set; }

        [FindsBy(How = How.Id, Using = "dgridClosingDetail_0_chkID1")]
        public IWebElement ClosingParty1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridClosingDetail_0_chkID2")]
        public IWebElement ClosingParty2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridClosingDetail_1_chkID1")]
        public IWebElement ClosingParty3 { get; set; }

        [FindsBy(How = How.Id, Using = "btnUpdClosing")]
        public IWebElement UpdateClosingDetails { get; set; }

        [FindsBy(How = How.Id, Using = "btnResClosing")]
        public IWebElement RescheduleClosing { get; set; }

        [FindsBy(How = How.Id, Using = "btnOrderDetail")]
        public IWebElement FileDetail { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelClosing")]
        public IWebElement DeleteClosingRecord { get; set; }

        [FindsBy(How = How.Id, Using = "btnSendAppointment")]
        public IWebElement SendClosingNotice { get; set; }

        [FindsBy(How = How.Id, Using = "FAFlblNotice")]
        public IWebElement ClosingNoticeMsg { get; set; }

        [FindsBy(How = How.Id, Using = "FAFlblmsg")]
        public IWebElement RecordUpdateMsg { get; set; }

        #endregion

        #region SubNav

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_monthly.aspx')]")]
        public IWebElement SubNav_MonthlyView { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_daily.aspx')]")]
        public IWebElement SubNav_DailyView { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_detail.aspx')]")]
        public IWebElement SubNav_ClosingView { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'evn_closing_history.aspx')]")]
        public IWebElement SubNav_ClosingHistory { get; set; }
        #endregion

        #endregion

        #region Useful Methods
        public FASTClosingfastcs WaitForScreenToLoad(IWebElement element = null, bool switchToWindow = true)
        {
            if (switchToWindow)
            {
                Playback.Wait(10000);
                FastDriver.WebDriver.SwitchToWindowByUrl("http://snavnadmfeva101/fastcs/OrderSearch.aspx");
            }
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? FileNumber);
            return this;
        }

        public FASTClosingfastcs LogIn(string username, string passwd)
        {
            AutoItX.WinWait("Windows Security", "", 30);
            AutoItX.WinActivate("Windows Security");
            AutoItX.ControlSetText("Windows Security", "", "[CLASS:Edit; INSTANCE:1]", username);
            AutoItX.ControlSetText("Windows Security", "", "[CLASS:Edit; INSTANCE:2]", passwd);
            AutoItX.ControlClick("Windows Security", "", "[CLASS:Button; INSTANCE:2;]");
            WaitForScreenToLoad();
            return this;
        }

        public FASTClosingfastcs SearchForFile(string fileNum = null, string extFile = null, string propAddress = null, string city = null, string state = null, string county = null, string buyerLastName = null, string sellerLastName = null, string busSource = null, string openDate = null)
        {
            FileNumber.FASetText(fileNum);
            ExternalFileNumber.FASetText(extFile);
            PropertyAddress.FASetText(propAddress);
            City.FASetText(city);
            State.FASelectItem(state);
            County.FASetText(county);
            BuyerLastname.FASetText(buyerLastName);
            SellerLastname.FASetText(sellerLastName);
            BusinessSource.FASetText(busSource);
            FileOpenDate.FASetText(openDate);
            SearchButton.FAClick();
            return this;
        }

        public FASTClosingfastcs CreateScheduledClosing()
        {
            int randomTable = Support.RandomNumber(2, 14);
            IWebElement scheduleTable = FastDriver.WebDriver.FindElement(By.XPath(string.Format("//td[@id='clnEvnStart']/table[{0}]", randomTable)));
            if (!scheduleTable.IsVisible())
            {
                randomTable = Support.RandomNumber(2, 14);
                scheduleTable = FastDriver.WebDriver.FindElement(By.XPath(string.Format("//td[@id='clnEvnStart']/table[{0}]", randomTable)));
            }
            int minRowIndex = Support.RandomNumber(scheduleTable.GetRowCount() - 1);
            bool isRowSelected = scheduleTable.PerformTableAction(minRowIndex, 1, TableAction.GetCell).Element.GetAttribute("class") == "notimeoption";
            while (isRowSelected)
            {
                minRowIndex = Support.RandomNumber(scheduleTable.GetRowCount() - 1);
                isRowSelected = scheduleTable.PerformTableAction(minRowIndex, 1, TableAction.GetCell).Element.GetAttribute("class") == "notimeoption";
            }
            scheduleTable.PerformTableAction(minRowIndex, 1, TableAction.Click); 
            minRowIndex++;
            WaitForScreenToLoad(EndScheduleTable, false);
            int endTime = Support.RandomNumber(minRowIndex, EndScheduleTable.GetRowCount());
            bool isEndTimeSelected = EndScheduleTable.PerformTableAction(endTime, 1, TableAction.GetCell).Element.GetAttribute("class") == "notimeoption";
            while (isEndTimeSelected)
            {
                endTime = Support.RandomNumber(minRowIndex, EndScheduleTable.GetRowCount());
                isEndTimeSelected = EndScheduleTable.PerformTableAction(endTime, 1, TableAction.GetCell).Element.GetAttribute("class") == "notimeoption";
            }
            EndScheduleTable.PerformTableAction(endTime, 1, TableAction.Click);
            return this;
        }

        public bool IsPartyNameUpdated(string filenumber, string partyname)
        {
            return FastDriver.WebDriver.FindElement(By.XPath(string.Format("//td[@id='clnEvnDaily']//td/a[text()='{0}']/..", filenumber))).FAGetAttribute("title").Contains(partyname);
        }
        #endregion

    }
}
