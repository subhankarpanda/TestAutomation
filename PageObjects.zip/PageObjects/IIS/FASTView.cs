using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
	public class FASTView : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "File")]
		public IWebElement File { get; set; }

		[FindsBy(How = How.LinkText, Using = "File Activities")]
		public IWebElement FileActivities { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrow Closing")]
		public IWebElement EscrowClosing { get; set; }

		[FindsBy(How = How.Id, Using = "fileNumber")]
		public IWebElement FileNum { get; set; }

        [FindsBy(How = How.Id, Using = "txtDateFrom1")]
		public IWebElement FromDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtDateTo1")]
		public IWebElement ToDate { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults")]
        public IWebElement SearchResultTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtNumbers")]
        public IWebElement FileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tbContentElement")]
        public IWebElement txtNote { get; set; }
             
		#endregion

        public FASTView WaitForScreenToLoad()
        {
            Playback.Wait(5000);
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(FindNow);            
            return this;
        }
        public FASTView WaitForScreenToLoad(IWebElement element = null )
        {
            Playback.Wait(5000);
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(element ?? FindNow);

            return this;
        }
        
	}
}
