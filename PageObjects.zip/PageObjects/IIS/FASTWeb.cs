using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using FASTSelenium.DataObjects.IIS;

namespace FASTSelenium.PageObjects.IIS
{
	public class FASTWeb : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Name, Using = "SearchMethod")]
		public IWebElement SearchMethod { get; set; }

		[FindsBy(How = How.Id, Using = "SearchString")]
		public IWebElement SearchString { get; set; }

		[FindsBy(How = How.XPath, Using = "//a[contains(@href, 'go button')]")]
		public IWebElement Go { get; set; }

		[FindsBy(How = How.LinkText, Using = "17227630")]
		public IWebElement FileElement { get; set; }

		[FindsBy(How = How.LinkText, Using = "New Order")]
		public IWebElement NewOrder { get; set; }

		[FindsBy(How = How.LinkText, Using = "Order Summary")]
		public IWebElement OrderSummary { get; set; }

		[FindsBy(How = How.LinkText, Using = "Credit")]
		public IWebElement Credit { get; set; }

		[FindsBy(How = How.LinkText, Using = "Title-Escrow/Closing")]
		public IWebElement TitleEscrowClosing { get; set; }

		[FindsBy(How = How.LinkText, Using = "Flood")]
		public IWebElement Flood { get; set; }

		[FindsBy(How = How.LinkText, Using = "Appraisal")]
		public IWebElement Appraisal { get; set; }

		[FindsBy(How = How.LinkText, Using = "Log Off FASTWeb")]
		public IWebElement LogOffFASTWeb { get; set; }

		[FindsBy(How = How.LinkText, Using = "FASTWeb Main Menu")]
		public IWebElement FASTWebMainMenu { get; set; }

		[FindsBy(How = How.Name, Using = "iTransType")]
		public IWebElement TransType { get; set; }

		[FindsBy(How = How.Name, Using = "iRoleType")]
		public IWebElement RoleType { get; set; }

		[FindsBy(How = How.Name, Using = "lCustID")]
		public IWebElement AuthorizedBy { get; set; }

		[FindsBy(How = How.Name, Using = "sOrdTrackingNum")]
		public IWebElement CustRefNo { get; set; }

		[FindsBy(How = How.Name, Using = "yMortgAmt")]
		public IWebElement LoanAmt { get; set; }

		[FindsBy(How = How.Name, Using = "yPurchAmt")]
		public IWebElement SalesPrice { get; set; }

		[FindsBy(How = How.Name, Using = "iPropType")]
		public IWebElement PropType { get; set; }

		[FindsBy(How = How.Name, Using = "iPropUse")]
		public IWebElement PropUse { get; set; }

		[FindsBy(How = How.Name, Using = "sAddress1")]
		public IWebElement Address1 { get; set; }

		[FindsBy(How = How.Name, Using = "sCity")]
		public IWebElement City { get; set; }

		[FindsBy(How = How.Name, Using = "sState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Name, Using = "sZip")]
		public IWebElement Zip { get; set; }

		[FindsBy(How = How.Name, Using = "sapn")]
		public IWebElement APN { get; set; }

		[FindsBy(How = How.Name, Using = "mLegalDesc")]
		public IWebElement LegalDesc { get; set; }

		[FindsBy(How = How.Id, Using = "iEntityType")]
		public IWebElement Borrower1EntityType { get; set; }

		[FindsBy(How = How.Name, Using = "sFirstName")]
		public IWebElement Borrower1FirstName { get; set; }

		[FindsBy(How = How.Name, Using = "sMiddleName")]
		public IWebElement Borrower1MiddleName { get; set; }

		[FindsBy(How = How.Name, Using = "sLastName")]
		public IWebElement Borrower1LastName { get; set; }

		[FindsBy(How = How.Name, Using = "sGeneration")]
		public IWebElement Borrower1Suffix { get; set; }

		[FindsBy(How = How.Name, Using = "sSSN")]
		public IWebElement Borrower1SSN { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseFirstName")]
		public IWebElement Borrower1SpouseFirstName { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseMiddleName")]
		public IWebElement Borrower1SpouseMiddleName { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseLastName")]
		public IWebElement Borrower1SpouseLastName { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseGeneration")]
		public IWebElement Borrower1SpouseSuffix { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseSSN")]
		public IWebElement Borrower1SpouseSSN { get; set; }

		[FindsBy(How = How.Id, Using = "iEntityType")]
		public IWebElement Borrower2EntityType { get; set; }

		[FindsBy(How = How.Name, Using = "sFirstName")]
		public IWebElement Borrower2FirstName { get; set; }

		[FindsBy(How = How.Name, Using = "sMiddleName")]
		public IWebElement Borrower2MiddleName { get; set; }

		[FindsBy(How = How.Name, Using = "sLastName")]
		public IWebElement Borrower2LastName { get; set; }

		[FindsBy(How = How.Name, Using = "sGeneration")]
		public IWebElement Borrower2Suffix { get; set; }

		[FindsBy(How = How.Name, Using = "sSSN")]
		public IWebElement Borrower2SSN { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseFirstName")]
		public IWebElement Borrower2SpouseFirstName { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseMiddleName")]
		public IWebElement Borrower2SpouseMiddleName { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseLastName")]
		public IWebElement Borrower2SpouseLastName { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseGeneration")]
		public IWebElement Borrower2SpouseSuffix { get; set; }

		[FindsBy(How = How.Name, Using = "sSpouseSSN")]
		public IWebElement Borrower2SpouseSSN { get; set; }

		[FindsBy(How = How.XPath, Using = "//img[@alt='Continue']")]
		public IWebElement Continue { get; set; }

		[FindsBy(How = How.Name, Using = "chkOrderTitle")]
		public IWebElement OrderTitle { get; set; }

		[FindsBy(How = How.Name, Using = "chkOrderEscrow")]
		public IWebElement OrderEscrow { get; set; }

		[FindsBy(How = How.Name, Using = "Title_sComment")]
		public IWebElement TitleComment { get; set; }

		[FindsBy(How = How.LinkText, Using = "Add Title Notes")]
		public IWebElement AddTitleNotes { get; set; }

		[FindsBy(How = How.LinkText, Using = "Submit Order")]
		public IWebElement SubmitOrder { get; set; }

		[FindsBy(How = How.Id, Using = "FASTwebNumber")]
		public IWebElement FASTWebOrderNo { get; set; }

		[FindsBy(How = How.XPath, Using = "//img[@name='button_add_borrower']")]
		public IWebElement AddBorrower { get; set; }

		[FindsBy(How = How.XPath, Using = "//a[contains(@href, 'PageName=Participant')]")]
		public IWebElement AddParticipant { get; set; }

		[FindsBy(How = How.XPath, Using = "//a[contains(@href, 'PageName=Seller')]")]
		public IWebElement AddOwner { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@name='OrderSummary']")]
        public IWebElement OrderSummaryTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@name='TitleEscrow']")]
        public IWebElement TitleEscrowTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[text()='Edit']")]
        public IWebElement EditBorrower { get; set; }

		[FindsBy(How = How.Name, Using = "button_add_payoffmortgage")]
		public IWebElement payoffmortgage { get; set; }

		[FindsBy(How = How.Name, Using = "sName")]
		public IWebElement PayoffLenderName { get; set; }

		[FindsBy(How = How.Id, Using = "sAttention")]
		public IWebElement PayoffAttention { get; set; }

		[FindsBy(How = How.Name, Using = "slpAddress1")]
		public IWebElement PayoffAddress1 { get; set; }

		[FindsBy(How = How.Name, Using = "slpAddress2")]
		public IWebElement PayoffAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "slpCity")]
		public IWebElement PayoffCity { get; set; }

		[FindsBy(How = How.Id, Using = "sState")]
		public IWebElement PayoffState { get; set; }

		[FindsBy(How = How.Id, Using = "slpZip")]
		public IWebElement PayoffZip { get; set; }

		[FindsBy(How = How.Name, Using = "iPayoffMethod")]
		public IWebElement PayoffMethod { get; set; }

		[FindsBy(How = How.Id, Using = "sLoanNumber")]
		public IWebElement PayoffLoanNumber { get; set; }

		[FindsBy(How = How.Id, Using = "sLoanAmount")]
		public IWebElement PayoffLoanAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "Cancel")]
		public IWebElement PayoffCancel { get; set; }

		[FindsBy(How = How.LinkText, Using = "Continue")]
		public IWebElement PayoffContinue { get; set; }

		[FindsBy(How = How.LinkText, Using = "View INST-Estimated Settlement Statement")]
		public IWebElement ViewINST_ElementStatement { get; set; }

		[FindsBy(How = How.LinkText, Using = "Escrow: Closing Statements (Adobe Acrobat)")]
		public IWebElement EscrowCloseAdobeAcrobat { get; set; }

		[FindsBy(How = How.LinkText, Using = "Dinesh Processor")]
		public IWebElement DineshProcessor { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'TitleEscrow_Submit_onclick()')]")]
        public IWebElement Submit { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@cellpadding='1']/tbody/tr[4]/td[2]")]
        public IWebElement FastFileNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@href, 'UploadDocs.asp')]")]
        public IWebElement UploadDocs { get; set; }

        [FindsBy(How = How.Name, Using = "UploadedFile")]
        public IWebElement SelectFile { get; set; }

        [FindsBy(How = How.Name, Using = "FileDescription")]
        public IWebElement DocDescription { get; set; }

        [FindsBy(How = How.Name, Using = "DocumentType")]
        public IWebElement DocumentType { get; set; }

        [FindsBy(How = How.Name, Using = "AddDocument")]
        public IWebElement SubmitDoc { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@name='button_back']")]
        public IWebElement Back { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@bgcolor='#cccc99'][1]")]
        public IWebElement TitleDocumentsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@bgcolor='#cccc99'][2]")]
        public IWebElement EscrowDocumentsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//area[@id='Recent_OneHundred']")]
        public IWebElement RecentOrders { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@class='TableStandard']")]
        public IWebElement RecentOrdersTable { get; set; }

        #endregion

        #region Useful Methods
        public FASTWeb WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("FASTWeb", true, 30, false);
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? SearchMethod);
            return this;
        }

        public FASTWeb CreateOrder(FASTWebOrderParameters FastWebOrder)
        {
            LoanAmt.FASetText(FastWebOrder.loanAmt.ToString());
            SalesPrice.FASetText(FastWebOrder.salesPrice.ToString());
            PropType.FASelectItem(FastWebOrder.propertyType);
            PropUse.FASelectItem(FastWebOrder.propertyUse);
            Address1.FASetText(FastWebOrder.street);
            City.FASetText(FastWebOrder.city);
            State.FASelectItem(FastWebOrder.state);
            Zip.FASetText(FastWebOrder.zip);
            APN.FASetText(FastWebOrder.apnTaxNumber);
            LegalDesc.FASetText(FastWebOrder.legalDescription);
            Borrower1EntityType.FASelectItem(FastWebOrder.entityType1);
            Borrower1FirstName.FASetText(FastWebOrder.firstName);
            Borrower1MiddleName.FASetText(FastWebOrder.middleName);
            Borrower1LastName.FASetText(FastWebOrder.lastName);
            Borrower1Suffix.FASetText(FastWebOrder.suffix1);
            Borrower1SSN.FASetText(FastWebOrder.ssn1);
            Continue.FAClick();
            return this;
        }

        public string GetFastFileNumber()
        {
            string fastFileNum = FastFileNumber.FAGetText().Clean().Split(':')[1].TrimStart().Clean();
            return fastFileNum;
        }

        public FASTWeb AddDocument(string path, string docDescription, string docType)
        {
            UploadDocs.FAClick();
            WaitForScreenToLoad(SelectFile);
            SelectFile.FAClick();
            FastDriver.OpenImageDlg.UploadImage(path);
            WaitForScreenToLoad(SelectFile);
            DocDescription.FASetText(docDescription);
            DocumentType.FASetText(docType);
            SubmitDoc.FAClick();
            return this;
        }
        #endregion

    }
}
