using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
	public class FastViewEditor : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboNoteTypes")]
		public IWebElement NoteType { get; set; }

		[FindsBy(How = How.Id, Using = "FontName")]
		public IWebElement FontName { get; set; }

		[FindsBy(How = How.Id, Using = "FontSize")]
		public IWebElement FontSize { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "tbContentElement")]
        public IWebElement txtNote { get; set; }

        [FindsBy(How = How.Id, Using = "CHECKSPELL")]
        public IWebElement CheckSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

		#endregion

        public FastViewEditor WaitForScreenToLoad()
        {
            Playback.Wait(5000);
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(CheckSpelling);
            return this;
        }

        public FastViewEditor AddNote(NewFileNoteParameters note)
        {
            NoteType.FASelectItem(note.NoteType);
            FontSize.FASelectItem(note.FontSize);
            FontName.FASelectItem(note.FontName);
            txtNote.Click();
            txtNote.SendKeys(note.NoteText); // for some reasons FASetText() does not work.
            //txtNote.FASetText(note.NoteText);
            return this;
        }
        public void ClickDone()
        {
            this.SwitchToFastViewBottomFrame();
            this.Done.FAClick();
        }

	}
}
