using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
	public class FastViewFileNotes : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "FAFDDNotesType")]
		public IWebElement NotesType { get; set; }

		[FindsBy(How = How.Id, Using = "btnPrn")]
		public IWebElement Preview { get; set; }

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnEdit")]
		public IWebElement Append { get; set; }

		[FindsBy(How = How.LinkText, Using = "create a new note")]
		public IWebElement createanewnote { get; set; }

		[FindsBy(How = How.LinkText, Using = "Append a new note")]
		public IWebElement Appendanewnote { get; set; }

		[FindsBy(How = How.LinkText, Using = "create a new note")]
		public IWebElement CreatePreview { get; set; }

		[FindsBy(How = How.LinkText, Using = "Append a new note")]
		public IWebElement AppendPreview { get; set; }

		[FindsBy(How = How.Id, Using = "gridPrnPreview_0_NoteType")]
		public IWebElement TitlePreview { get; set; }

		[FindsBy(How = How.Id, Using = "gridPrnPreview_0_Faflabel3")]
		public IWebElement ByPreview { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_1_Note")]
        public IWebElement FileNotesGrid1 { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_0_Note")]
        public IWebElement FileNotes { get; set; }

         [FindsBy(How = How.Id, Using = "gridPrnPreview_1")]
        public IWebElement PreviewDetails { get; set; }
        

		#endregion

        public FastViewFileNotes WaitForScreenToLoad()
        {
            Playback.Wait(2000);
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(New);
            return this;
        }
	}
}
