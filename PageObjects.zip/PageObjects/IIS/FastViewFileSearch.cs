using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class FastViewFileSearch : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnView")]
		public IWebElement View { get; set; }

		[FindsBy(How = How.Id, Using = "btnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "btnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "rblSearchType_0")]
		public IWebElement RadFileSearch { get; set; }

		[FindsBy(How = How.Id, Using = "rblSearchType_1")]
		public IWebElement RadPendingOrderSearch { get; set; }

		[FindsBy(How = How.Id, Using = "txtPrincipals")]
		public IWebElement Principals { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_0")]
		public IWebElement PrincipalBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_1")]
		public IWebElement PrincipalSeller { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_2")]
		public IWebElement PrincipalDebtor { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_3")]
		public IWebElement PrincipalAny1 { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_0")]
		public IWebElement IndividualHusbandWife { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_1")]
		public IWebElement TrustEstate { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_2")]
		public IWebElement BusinessEntity { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_3")]
		public IWebElement PrincipalAny2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtOtherParties")]
		public IWebElement OtherParties { get; set; }

		[FindsBy(How = How.Id, Using = "ddRoleType")]
		public IWebElement RoleType { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropAddress")]
		public IWebElement PropertyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropName")]
		public IWebElement PropertyName { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropLot")]
		public IWebElement PropertyLot { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropTract")]
		public IWebElement PropertyTract { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropParcel")]
		public IWebElement PropertyParcel { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropSubDiv")]
		public IWebElement PropertySubDivision { get; set; }

		[FindsBy(How = How.Id, Using = "txtAPNTaxNo")]
		public IWebElement APNTaxNo { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement PropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "txtCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "comboRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "txtNumbers")]
		public IWebElement Numbers { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_0")]
		public IWebElement Fileno { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_1")]
		public IWebElement PrincipalReferenceNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_2")]
		public IWebElement Extensionno { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_3")]
		public IWebElement EntityReferenceno { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_4")]
		public IWebElement InvoiceNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_5")]
		public IWebElement BusinessSrcRefNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_6")]
		public IWebElement OutsideReferenceNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_7")]
		public IWebElement AnyNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_0")]
		public IWebElement StatusOpen { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_3")]
		public IWebElement StatusClosed { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_1")]
		public IWebElement StatusOpenInError { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_4")]
		public IWebElement StatusAny { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_2")]
		public IWebElement StatusCancelled { get; set; }

		[FindsBy(How = How.Id, Using = "txtDateFrom1")]
		public IWebElement DateFrom { get; set; }

		[FindsBy(How = How.Id, Using = "txtDateTo1")]
		public IWebElement DateTo { get; set; }

		[FindsBy(How = How.Id, Using = "txtMonth")]
		public IWebElement Month { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_0")]
		public IWebElement OpenedDate { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_2")]
		public IWebElement SettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_1")]
		public IWebElement CanclelledDate { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_3")]
		public IWebElement EstSettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmpName")]
		public IWebElement EmployeeName { get; set; }

		[FindsBy(How = How.Id, Using = "ddEmpType")]
		public IWebElement EmployeeType { get; set; }

        [FindsBy(How = How.Id, Using = "fileNumber")]
		public IWebElement FileNumberLabel { get; set; }

        [FindsBy(How = How.Id, Using = "rblNumbers_8")]
        public IWebElement PolicyNo { get; set; }

        
		#endregion

        public FastViewFileSearch WaitForMessagePaneToLoad(IWebElement element = null)
        {
            try
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitCreation(element ?? FileNumberLabel);
            }
            catch
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitCreation(element ?? FileNumberLabel);
            }
            return this;
        }

        public FastViewFileSearch WaitForScreenToLoad(IWebElement element = null, int timeout = 60)
        {
            try
            {
                FastDriver.DialogBottomFrame.SwitchToFastViewContentFrame();
                this.WaitCreation(element ?? Numbers);
            }
            catch
            {
                //FastDriver.WebDriver.WaitForWindowAndSwitch("FAST v9.0");
                FastDriver.DialogBottomFrame.SwitchToFastViewContentFrame();
                this.WaitCreation(element ?? Numbers);
            }
            return this;
        }

        public void Maximize(IWebElement element = null, int timeout = 60)
        {
            FastDriver.WebDriver.Manage().Window.Maximize();
        }
	}
}
