﻿using System;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.IIS;

namespace FASTSelenium.PageObjects.IIS
{
    public class FastViewFileSearchDialog : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "File")]
        public IWebElement File { get; set; }

        [FindsBy(How = How.LinkText, Using = "File Activities")]
        public IWebElement FileActivities { get; set; }

        [FindsBy(How = How.LinkText, Using = "Escrow Closing")]
        public IWebElement EscrowClosing { get; set; }

        [FindsBy(How = How.Id, Using = "fileNumber")]
        public IWebElement FileNum { get; set; }

        [FindsBy(How = How.Id, Using = "txtDateFrom1")]
        public IWebElement FromDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtDateTo1")]
        public IWebElement ToDate { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults")]
        public IWebElement SearchResultTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtNumbers")]
        public IWebElement Number { get; set; }

        [FindsBy(How = How.Id, Using = "tbContentElement")]
        public IWebElement txtNote { get; set; }

        [FindsBy(How = How.Id, Using = "-menu-cache-5")]
        public IWebElement Menu { get; set; }

        [FindsBy(How = How.Id, Using = "fraApp")]
        public IWebElement MainIframe { get; set; }

        [FindsBy(How = How.Id, Using = "fraPageWin")]
        public IWebElement MainTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "tbContent")]
        public IWebElement TableContent { get; set; }

        [FindsBy(How = How.CssSelector, Using = ".tbContent")]
        public IWebElement TContent { get; set; }

        [FindsBy(How = How.Id, Using = "tbTitleEscrowCharges")]
        public IWebElement TableSubcontent { get; set; }

        [FindsBy(How = How.CssSelector, Using = ".tdSubTotals")]
        public IWebElement TableSubTotals { get; set; }

        [FindsBy(How = How.CssSelector, Using = ".middle")]
        public IWebElement btnEscrowClosing { get; set; }


        #endregion

        public FastViewFileSearchDialog WaitForScreenToLoad(string ScreenName)
        {
            
            WebDriver.WaitForWindowAndSwitch(ScreenName, true, 20);
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(Number);
            return this;
        }

        public FastViewFileSearchDialog WaitForViewSettlementStatementScreenToLoad()
        {

            WebDriver.WaitForWindowAndSwitch("View Settlement Statement", true, 20);
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(TableSubTotals);
            return this;
        }

    }

}
