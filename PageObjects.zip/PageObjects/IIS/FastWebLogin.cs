using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class FastWebLogin : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Name, Using = "sUserName")]
		public IWebElement UserName { get; set; }

		[FindsBy(How = How.Name, Using = "sPassword")]
		public IWebElement Password { get; set; }

		[FindsBy(How = How.Id, Using = "image1")]
		public IWebElement Login { get; set; }

        #endregion

        #region
        public FastWebLogin WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(AutoConfig.FASTWebURL, true, 15, false);
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? UserName);
            return this;
        }

        public FastWebLogin EnterCredentials()
        {
            var credentials = new Credentials()
            {
                UserName = "fast_notify",
                Password = "84sc6Cyv2mB54lyINWrm7Q=="
            };
            WaitForScreenToLoad();
            UserName.FASetText(credentials.UserName);
            Password.FASetText(Support.Decrypt(credentials.Password), isPassword: true);
            Login.FAClick();
            return this;
        }
        #endregion


    }
}
