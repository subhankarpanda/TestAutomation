using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class FaxDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnFax")]
        public IWebElement FAX { get; set; }

        [FindsBy(How = How.Id, Using = "btnFrom")]
        public IWebElement Frombutton { get; set; }

        [FindsBy(How = How.Id, Using = "txtFrom")]
        public IWebElement From { get; set; }

        [FindsBy(How = How.Id, Using = "btnInsert")]
        public IWebElement Insert { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@title='Name']/span[@class='cGVCell']/input[@type='text']")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@title='ATTN:']/span[@class='cGVCell']/input[@type='text']")]
        public IWebElement Attn { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@title='FAX Number:']/span[@class='cGVCell']/input[@type='text']")]
        public IWebElement FAXNumber { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Name2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Attn2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement FAXNumber2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Name3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Attn3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement FAXNumber3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMessage")]
        public IWebElement Message { get; set; }

        [FindsBy(How = How.Id, Using = "imgDocument")]
        public IWebElement imageDocument { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
        public IWebElement BuyerSignature { get; set; }

        [FindsBy(How = How.Id, Using = "pubDocument")]
        public IWebElement publishDocument { get; set; }

        [FindsBy(How = How.Id, Using = "chkSeller")]
        public IWebElement SellerSignature { get; set; }

        [FindsBy(How = How.Id, Using = "markDraft")]
        public IWebElement markDraft { get; set; }

        [FindsBy(How = How.Id, Using = "chkMisc")]
        public IWebElement MiscSignature { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.LinkText, Using = "FAX Number:")]
        public IWebElement FaxNameTableCell { get; set; }

        [FindsBy(How = How.Id, Using = "idGVTableBody")]
        public IWebElement tblFaxRecipientsTable { get; set; }

        //SRT
        [FindsBy(How = How.Id, Using = "btnMsgSpellCheck")]
        public IWebElement checkSpell { get; set; }

        #endregion

        public FaxDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogBottomFrame();
            this.WaitCreation(Insert);
            return this;
        }

        // TODO: there should be only 1 WaitForScreenToLoad
        public FaxDlg WaitForScreenToLoad1()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Insert);
            return this;
        }

        public FaxDlg FaxRecipientsTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "")
        {
            this.WaitCreation(tblFaxRecipientsTable);
            tblFaxRecipientsTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value);
            return this;
        }


        public void SendFax()
        {
            Reports.TestStep = "Add recipient details and send fax";
            this.Insert.FAClick();
            this.FaxRecipientsTable(1, "", 1, TableAction.SetText, "Testing Fax");
            this.FaxRecipientsTable(1, "Testing Fax", 3, TableAction.SetText, AutoConfig.DeliverFaxTo);
            this.FAX.FAClick();
        }


    }
}
