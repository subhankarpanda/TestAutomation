using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class FeePaymentDetailsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtDesc")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "txtTotalCharge")]
        public IWebElement TotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtAdditionalDesc")]
        public IWebElement AdditionalDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtPaTo")]
        public IWebElement PayTo { get; set; }

        [FindsBy(How = How.Id, Using = "txtGfeThirdPartyNameDefault")]
        public IWebElement ThirdPartyNameDefault { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "selGfeEntryTypeCdID")]
        public IWebElement GfeEntryType { get; set; }

        [FindsBy(How = How.Id, Using = "chkGfeLenderDirectedFlag")]
        public IWebElement GfeLenderDirected { get; set; }

        [FindsBy(How = How.Id, Using = "chkGfePOBOBFlag")]
        public IWebElement GfePOBOB { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyer")]
        public IWebElement PaidbyBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyLender")]
        public IWebElement BuyerPaidbyLender { get; set; }

        [FindsBy(How = How.Id, Using = "selBuyPayMethod")]
        public IWebElement BuyerPaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyMB")]
        public IWebElement BuyerPaidbyMortBroker { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerCharge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbySeller")]
        public IWebElement PaidbySeller { get; set; }

        [FindsBy(How = How.Id, Using = "selsellerPayMethod")]
        public IWebElement sellerPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbyLender")]
        public IWebElement SellerPaidbyLender { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbyMB")]
        public IWebElement SellerPaidbyMortBroker { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerAtClosing")]
        public IWebElement BuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerAtClosing")]
        public IWebElement SellerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtLoanEstimatedDesc")]
        public IWebElement LoanEstimatedDesc { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(.,'Asterisk for SS')]")]
        public IWebElement AsteriskForSS { get; set; }

        [FindsBy(How = How.XPath, Using = "//label[contains(.,'Section B, Did Not Shop For')]")]
        public IWebElement SectionBtext { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(.,'Section C, Did Shop For')]")]
        public IWebElement SectionCtext { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(.,'Section H, Other Costs')]")]
        public IWebElement SectionHtext { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(.,'Primary Policy')]")]
        public IWebElement PrimaryPolicyText { get; set; }

        [FindsBy(How = How.ClassName, Using = "HtmlTable")]
        public IWebElement FeePDDTable { get; set; }

        #endregion

        public FeePaymentDetailsDlg WaitForScreenToLoad()
        {
            WebDriver.WaitForWindowAndSwitch("Payment Details", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Description);

            return this;
        }

    }
}
