using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Windows.Input;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.ObjectModel;
using System.Collections.Generic;


namespace FASTSelenium.PageObjects.IIS
{
    public class FileFees : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkFACCUW")]
        public IWebElement FACCUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "rdHUD")]
        public IWebElement HUD { get; set; }

        [FindsBy(How = How.Id, Using = "rdLegacy")]
        public IWebElement Legacy { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement DeliverMethod { get; set; }

        [FindsBy(How = How.Id, Using = "imgSplitFlag")]
        public IWebElement IssuedImage { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOCMB")]
        public IWebElement POCMBPane { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOCL")]
        public IWebElement POCLPane { get; set; }

        [FindsBy(How = How.Id, Using = "chkAll")]
        public IWebElement AllFees { get; set; }

        [FindsBy(How = How.Id, Using = "chkTitle")]
        public IWebElement TitleRates { get; set; }

        [FindsBy(How = How.Id, Using = "chkEnd")]
        public IWebElement Endorsements { get; set; }

        [FindsBy(How = How.Id, Using = "chkRec")]
        public IWebElement RecordingFees { get; set; }

        [FindsBy(How = How.Id, Using = "btnCalcFees")]
        public IWebElement CalculateFees { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@class,'TabHorizontal_Header') and .//text()='Title and Escrow']")]
        public IWebElement TitleandEscrow { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@class,'TabHorizontal_Header') and .//text()='Recording and Tax']")]
        public IWebElement RecordingandTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtRecordingLoanEstUnrounded")]
        public IWebElement RecordingLoanEstUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtRecordingLoanEstRounded")]
        public IWebElement RecordingLoanEstRounded { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_GTaxBrokenImage")]
        public IWebElement GTaxBrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_TTaxBrokenImage")]
        public IWebElement TTaxBrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtTranTaxLoanEstUnrounded")]
        public IWebElement TranTaxLoanEstUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtTranTaxLoanEstRounded")]
        public IWebElement TranTaxLoanEstRounded { get; set; }

        [FindsBy(How = How.Id, Using = "btnUnderwriterAgentDetail")]
        public IWebElement UnderwriterAgentDetail { get; set; }

        [FindsBy(How = How.Id, Using = "btnCDUnderwriterAgentDetail")]
        public IWebElement CDUnderwriterAgentDetail { get; set; }

        [FindsBy(How = How.Id, Using = "tCF_tL1_ucRf_ddlRecords")]
        public IWebElement RecordingDocument { get; set; }
        [FindsBy(How = How.Id, Using = "tFF_tF1_lblTSBuyer")]
        public IWebElement TitleServicesLenderTitleInsBuyerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtlenderAdjAmnt")]
        public IWebElement LenderAdjustmentAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblOTBuyer")]
        public IWebElement OwnersTitleInsuranceBuyerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtTSGFEAmount")]
        public IWebElement TitleServices_LenderTitleInsGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_chkGFE4LSPFlag")]
        public IWebElement LenderSelectedProviderGroupGFE4 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tFF_tF1_lblLSPFlag > img")]
        public IWebElement ScissorsIcon { get; set; }

        [FindsBy(How = How.Id, Using = "Button1")]
        public IWebElement SplitLSP { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtOTGFEAmount")]
        public IWebElement OwnersTitleInsuranceGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_chkGFE5LSPFlag")]
        public IWebElement LenderSelectedProviderGroupGFE5 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_11_chkSelect")]
        public IWebElement NewHomeRateTitleOnly { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_11_tbc")]
        public IWebElement NewHomeRateBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_11_tsc")]
        public IWebElement NewHomeRateSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_radio1")]
        public IWebElement All { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_radio2")]
        public IWebElement None { get; set; }

        [FindsBy(How = How.Id, Using = "tFF$tF1$gT$ctl04")]
        public IWebElement TitleAndEscrowTableColumns { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_gT")]
        public IWebElement TitleandescrowTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@name='tFF_tF1_gT_gT']")]
        public IWebElement TitleandEscrowTable { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_chkMBFees")]
        public IWebElement AddPOC_MBFeestoProjectedLoanFunding { get; set; }

        [FindsBy(How = How.Id, Using = "btnSalesTaxOverride")]
        public IWebElement SalesTaxOverride { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddTitleEscrowFees")]
        public IWebElement AddFees { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_chkSelect")]
        public IWebElement SelectCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_chkSelect")]
        public IWebElement SelectCheckbox1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_chkSelect")]
        public IWebElement SelectCheckbox2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_3_chkSelect")]
        public IWebElement SelectCheckbox3 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_4_chkSelect")]
        public IWebElement SelectCheckbox4 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tFF_tF1_gT_0_txtFeeDesc, #tFF_tF1_gT_0_txFDes")]
        public IWebElement FeeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_txFDes")]
        public IWebElement FeeDescription_1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_txtFeeDesc")]
        public IWebElement FeeDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_txtFeeDesc")]
        public IWebElement FeeDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_3_txtFeeDesc")]
        public IWebElement FeeDescription3 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_4_txtFeeDesc")]
        public IWebElement FeeDescription4 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_btnFeeDetails")]
        public IWebElement FeeDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_btnFeeDetails")]
        public IWebElement FeeDetails1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_btnFeeDetails")]
        public IWebElement FeeDetails2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tbc")]
        public IWebElement buyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_txtBuyerCharge")]
        public IWebElement buyercharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_3_txtBuyerCharge")]
        public IWebElement buyercharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_4_tbc")]
        public IWebElement buyercharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_tbc")]
        public IWebElement buyercharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tbs")]
        public IWebElement BuyerSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tsc")]
        public IWebElement Sellercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_txtSellerCharge")]
        public IWebElement sellercharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_txtSellerCharge")]
        public IWebElement sellercharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tsST")]
        public IWebElement SellerSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_txTC")]
        public IWebElement TotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_4_tsc")]
        public IWebElement Sellercharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tbc")]
        public IWebElement tFFtF1gT0BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_txtBuyerCharge")]
        public IWebElement rtBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tsc")]
        public IWebElement HUD1linenumber1103 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_txtFeeDesc")]
        public IWebElement STCFee { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalFees")]
        public IWebElement TotalFees { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_gR")]
        public IWebElement RecordingTable { get; set; }

        [FindsBy(How = How.Name, Using = "tFF_rF1_gR_gR")]
        public IWebElement RecordingandTaxTable { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtGRCFEAmount")]
        public IWebElement GovernmentRecordingChargesGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtTTXGFEAmount")]
        public IWebElement TransferTaxGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_txtTolCureAmt")]
        public IWebElement ToleranceCureAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_ddlTolCurePayMthd")]
        public IWebElement ToleranceCureMethod { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_radio1")]
        public IWebElement RecordingandTaxAll { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_radio2")]
        public IWebElement RecordingandTaxNone { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_btnPayRecordingTax")]
        public IWebElement PayRecordingTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_btnAddFeesTax")]
        //[FindsBy(How = How.LinkText, Using = "Add Fees/Tax")]
        public IWebElement AddFeesTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_chkSelect")]
        public IWebElement SelectRecording { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_1_chkSelect")]
        public IWebElement SelectRecording1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_2_chkSelect")]
        public IWebElement SelectRecording2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_txFDes")]
        public IWebElement FeeDescriptionRecording { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_1_txFDes")]
        public IWebElement FeeDescriptionRecording1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_2_txFDes")]
        public IWebElement FeeDescriptionRecording2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_btnFeeDetails")]
        public IWebElement RecordingTaxFeeDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_txtBuyerCharge")]
        public IWebElement BuyerChargeRecording1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_4_tbc")]
        public IWebElement BuyerChargeRecording { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_tsc")]
        public IWebElement SellerChargeRecording { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_1_tsc")]
        public IWebElement SellerChargeRecording1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_2_tsc")]
        public IWebElement SellerChargeRecording2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtOwnerLoanEstmt")]
        public IWebElement OwnerLoanEstimateUnroundedAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblBifurcatedTransaction")]
        public IWebElement FeeBifurcatedTransaction { get; set; }

        //[FindsBy(How = How.Id, Using = "tFF_rF1_gR_0_tbc")]
        //public IWebElement BuyerChargeRecording1A { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_1_tbc")]
        public IWebElement BuyerChargeRecording2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_2_tbc")]
        public IWebElement BuyerChargeRecording3 { get; set; }



        [FindsBy(How = How.Id, Using = "tFF_rF1_gR_4_txTC")]
        public IWebElement TotalChargeRecording { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "lstSearchFeeTypes")]
        public IWebElement FeeSearchFeeTypes { get; set; }

        [FindsBy(How = How.Id, Using = "txtSearchFeeDesc")]
        public IWebElement FeeSearchFeeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "grdResults_0_chkFeeSelect")]
        public IWebElement FeeSearchFeeSelect { get; set; }

        [FindsBy(How = How.Id, Using = "grdResults_1_chkFeeSelect")]
        public IWebElement FeeSearchFeeSelect1 { get; set; }
        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement CancelQ { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSplitAmount")]
        public IWebElement SplitFees { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSplitAmount")]
        public IWebElement SplitFee { get; set; }

        [FindsBy(How = How.Id, Using = "grdResults_grdResults")]
        public IWebElement AddFeeTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSplitAmount")]
        public IWebElement SplitFeeAmt { get; set; }

        [FindsBy(How = How.LinkText, Using = "Title")]
        public IWebElement FeesTypes { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSplitAmount")]
        public IWebElement Splitamt { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOC")]
        public IWebElement PocAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalInvFees")]
        public IWebElement TotalInvFee { get; set; }

        [FindsBy(How = How.Id, Using = "lblServiceFees")]
        public IWebElement ServiceFee { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOCL")]
        public IWebElement POCL { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOCMB")]
        public IWebElement POCMB { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_btnDescr")]
        public IWebElement ToleranceCureDescriptionButton { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_chkMBFees")]
        public IWebElement AddPOCMBLoanFunding { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtlenderAdjAmnt")]
        public IWebElement lenderAdjAmnt { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtSimPolicyAdjAmt")]
        public IWebElement SPA { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_FAFCBShowOnCD")]
        public IWebElement ShowOnCD { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtOwnerAdjAmnt")]
        public IWebElement OwnerAdjAmnt { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_FAFCBAggLPolicy")]
        public IWebElement AggregateLPAndEndorsementsOnCD { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_btnBS")]
        public IWebElement BSSplitButton { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_btnLenderBS")]
        public IWebElement BSSplitButtonLender { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblSeller")]
        public IWebElement BSSplitSellerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblBuyer")]
        public IWebElement BSSplitBuyerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblLenderSeller")]
        public IWebElement LenderBSSplitSellerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblLenderBuyer")]
        public IWebElement LenderBSSplitBuyerPercentage { get; set; }
        
        [FindsBy(How = How.Id, Using = "tFF_tF1_tblTitlePolicyCalc")]
        public IWebElement TitlePolicyCalculationsforCD { get; set; }

        [FindsBy(How = How.Id, Using = "Td1")]
        public IWebElement TitlePolicyCalculationsforCDButton { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table.displayToggle")]
        public IWebElement TitlePolicyCalcForCD { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_lblGFEAmount")]
        public IWebElement lblGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_lblGRC")]
        public IWebElement lblGRC { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_lblTTax")]
        public IWebElement lblTTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblLoanEstmt")]
        public IWebElement lblLEUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtLenderLoanEstmt")]
        public IWebElement LenderLoanEstimateAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_txtOwnerLoanEstmt")]
        public IWebElement OwnerLoanEstimateAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_tblRecordingFees")]
        public IWebElement RecordingFeesAndTransferTaxes { get; set; }

        [FindsBy(How = How.Id, Using = "cBntExp")]
        public IWebElement RecordingFeesAndTransferTaxesButton { get; set; }
        
        [FindsBy(How = How.Id, Using = "rdCD")]
        public IWebElement CD { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_tblTileEscrowFees")]
        public IWebElement TitlePolicyCalculationsforHUD { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblOwnerPlcName")]
        public IWebElement TitleOwnerPolicyName { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_lblLenderPlcName")]
        public IWebElement TitleLenderPolicyName { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_ddlSalesTaxOnCD")]
        public IWebElement DisplaySalesTaxOnCD { get; set; }

        [FindsBy(How = How.Id, Using = "grdResults_0_lblFeeDescr")]
        public IWebElement SearchResultsFeeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "btnMscEscrEdit")]
        public IWebElement MiscEscrowEdit { get; set; }

        [FindsBy(How = How.Id, Using = "grdResults_0_lblFeeDescr")]
        public IWebElement FirstFeesDesc { get; set; }
        [FindsBy(How = How.Id, Using = "grdResults_1_lblFeeDescr")]
        public IWebElement SecondFeesDesc { get; set; }

        [FindsBy(How = How.Id, Using = "SearchResultsTable")]
        public IWebElement SearchResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalEscrowFees")]
        public IWebElement TotalEscrowFees { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalOtherFees")]
        public IWebElement TotalOtherFees { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSalesTax")]
        public IWebElement TotalSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRecordingFees")]
        public IWebElement TotalRecordingFees { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalDocTransferTaxFees")]
        public IWebElement TotalTransferTaxFees { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalTitleFees")]
        public IWebElement TotalTitleFees { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalExciseTax")]
        public IWebElement TotalExciseTax { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_lblGRCBuyer")]
        public IWebElement RecordingFeesAndFutureRecordingFeesBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_txTC")]
        public IWebElement TotalCharge2row { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_rF1_lblTTXBuyer")]
        public IWebElement TransferTaxesBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tbc")]
        public IWebElement AddedFeeBuyerCharge0 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_tbc")]
        public IWebElement AddedFeeBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_tbc")]
        public IWebElement AddedFeeBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_3_tbc")]
        public IWebElement AddedFeeBuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_0_tsc")]
        public IWebElement AddedFeeSellerCharge0 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_1_tsc")]
        public IWebElement AddedFeeSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_2_tsc")]
        public IWebElement AddedFeeSellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_gT_3_tsc")]
        public IWebElement AddedFeeSellerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_BrokenImage")]
        public IWebElement TPABrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "tFF_tF1_BrokenImage")]
        public IWebElement SPABrokenImage { get; set; }


        // SRT- Senthil

        [FindsBy(How = How.Id, Using = "tblEFee")]
        public IWebElement ExchangeFeeSelectTbl { get; set; }

        //SRT - tushar - R10
        [FindsBy(How = How.Id, Using = "SpanPOC_CD_BB")]
        public IWebElement RecapBuyerBroker { get; set; }

        [FindsBy(How = How.Id, Using = "SpanPOC_CD_L")]
        public IWebElement RecapLender { get; set; }

        [FindsBy(How = How.Id, Using = "SpanPOC_CD_MB")]
        public IWebElement RecapMortgageB { get; set; }

        [FindsBy(How = How.Id, Using = "SpanPOC_CD_SB")]
        public IWebElement RecapSeller { get; set; }

        [FindsBy(How = How.Id, Using = "divGridBody")]
        public IWebElement FeesTableGrid { get; set; }

        #endregion

        public string randomFeeCheckBoxSelector()
        {
            Random idrange = new Random();
            int FeeCBID = idrange.Next(0, (FastDriver.FileFees.AddFeeTable.GetRowCount() - 1));
            string FeeCB = "grdResults_" + FeeCBID + "_chkFeeSelect";
            return FeeCB;
        }

        public FileFees Open()
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry");
            this.WaitForFeeScreen();

            return this;
        }

        public FileFees WaitForFeeScreen(IWebElement e = null, int timeout = 120)
        {
            e = e ?? TitleandescrowTable;
            this.SwitchToContentFrame();
            this.WaitCreation(e);
            return this;
        }

        public FileFees WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? CalculateFees);

            return this;
        }

        public FileFees WaitForScreenToLoadAfterFormTypeChangesToHUD()
        {
            WebDriverWait waiting = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(30));

            waiting.Until(d =>
            {
                try
                {
                    FastDriver.FileFees.SwitchToContentFrame();
                    return FastDriver.FileFees.TitleServices_LenderTitleInsGFEAmount.IsDisplayed();
                }
                catch (NoSuchElementException)
                {
                    return false;
                }

            });

            return this;
        }

        public FileFees WaitForScreenToLoadAfterFormTypeChangesToCD()
        {
            WebDriverWait waiting = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(30));

            waiting.Until(d =>
            {
                try
                {
                    FastDriver.FileFees.SwitchToContentFrame();
                    return FastDriver.FileFees.DisplaySalesTaxOnCD.IsDisplayed();
                }
                catch (NoSuchElementException)
                {
                    return false;
                }

            });

            return this;
        }

        #region SELECT AND VERIFY PARTICULAR FEE ON FEE ENTRY SCREEN
        // Fix according to code review 590479
        public void SelectAndVerifyParticularFeeOnFeeEntryScreen(string FeeDesc)
        {
            try
            {
                this.WaitCreation(FastDriver.FileFees.AddFees);
                this.AddFees.FAClick();
                this.SwitchToContentFrame();
                this.FeeSearchFeeTypes.FASelectItem("All");
                this.SwitchToContentFrame();
                this.FeeSearchFeeDescription.FASetText(FeeDesc);
                this.FindNow.FAClick();
                this.SwitchToContentFrame();
                this.AddFeeTable.PerformTableAction("#2", FeeDesc, "#1", TableAction.Click);
                FastDriver.BottomFrame.Done();

                this.NavigateToFeeEntry();
                this.WaitCreation(FastDriver.FileFees.TitleandescrowTable);

                //if (FastDriver.FileFees.SelectCheckbox.FAGetValue().ToString().Equals("on"))
                if (this.SelectCheckbox.Selected)
                {
                    Reports.TestStep = "Provided Fee: " + FeeDesc + " Got selected and Presented on the Fee entry screen.";
                    Reports.StatusUpdate("Provided Fee Got selected and Presented on the Fee entry screen.", true);
                }
                else
                {
                    Reports.TestStep = "Provided fee: " + FeeDesc + " did not get selected.";
                    Reports.StatusUpdate("Provided fee did not got selected.", false);
                }
            }
            catch (Exception ex)
            {
                Reports.TestStep = "The system not able to perform the selection of fee due to the following reason : " + ex.Message.ToString();
                Reports.StatusUpdate("The system not able to perform the selection of fee due to the following reason : " + ex.Message.ToString(), false);
            }
        }
        #endregion

        #region PROVIDE THE DATA ON FEE ENTRY SCREEN
        public void ProvideTheDataOnFeeEntryScreen(string Charge_Desc, string ColumnName, string SetValue, string Action = "SET")
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", Charge_Desc, ColumnName, TableAction.SetText, SetValue);
            FastDriver.BottomFrame.Done();
            FastDriver.FileFees.SwitchToContentFrame();

        }
        #endregion

        #region NAVIGATE TO FEE ENTRY
        public void NavigateToFeeEntry()
        {
            Reports.TestStep = "Navigate to Fee Entry screen";
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.SwitchToContentFrame();
        }
        #endregion

        #region SELECT TITLE AND ENDORSEMENT FEES CHECKBOX
        public void SelectTitleAndEndorsementFees()
        {
            Reports.TestStep = "Select Title And Endorsement Option";
            TitleRates.FASetCheckbox(true);
        }
        #endregion

        #region CLICK ON CALCULATE FEES BUTTON ONCE DONE
        public void PerformCalculateFees()
        {
            Reports.TestStep = "Click on Calculate Fees button";
            CalculateFees.FAClick();
        }
        #endregion

        public void AddNonFACCRecordingFeeTax(string FeeType, string FeeDescription, string FeeCode = null)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.RecordingandTax.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeesTax);
            FastDriver.FileFees.AddFeesTax.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(FeeType);
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.FeeSearchFeeDescription.FASetText(FeeDescription);
            FastDriver.FileFees.FindNow.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();

            //Search By FeeCode
            if (FeeCode != null)
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#3", FeeCode, "#1", TableAction.On);
            else
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", FeeDescription, "#1", TableAction.On);

            FastDriver.BottomFrame.Done();
            FastDriver.BottomFrame.Done();

        }

        public void EnterBuyerandSellerAmountUsingPDD(string Description, double? ByrAtClosing, double? ByrBfrClosing, double? ByrPdOthrs, string ByrPaidByOthrsPymtmthd, double? SellerPaidAtClosing, double? SellerPaidBeforeClosing, double? SellerPaidbyOthers, string SellerPaidbyOtherPaymentMthd, bool display_L_Buyer, bool display_L_Seller, bool LenderAffialite = false, bool RemoveLenderAffialite = false)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry");
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Description, 3, TableAction.Click);
            FastDriver.PaymentDetails.WaitForScreenToLoad();
            FastDriver.PaymentDetails.SwitchToDialogContentFrame();
            string Runtime_Description = FastDriver.PaymentDetails.Desc.FAGetValue();
            if (Runtime_Description.Contains(Description))
            {
                if (ByrAtClosing.HasValue)
                {
                    FastDriver.PaymentDetails.BuyerAtClosing.FASetText(ByrAtClosing.ToString());
                }
                if (ByrBfrClosing.HasValue)
                {
                    FastDriver.PaymentDetails.BuyerBeforeClosing.FASetText(ByrBfrClosing.ToString());
                }
                if (ByrPdOthrs.HasValue)
                {
                    FastDriver.PaymentDetails.BuyerPaidByOthers.FASetText(ByrPdOthrs.ToString());
                }

                double? TotalBuyerCharge;
                TotalBuyerCharge = ByrAtClosing + ByrBfrClosing + ByrPdOthrs;
                FastDriver.PaymentDetails.BuyerCharge.FASetText(TotalBuyerCharge.ToString());
                if (ByrPaidByOthrsPymtmthd != string.Empty)
                {
                    FastDriver.PaymentDetails.BuyerPaidbyOthersPayMethod.FASelectItemBySendingKeys(ByrPaidByOthrsPymtmthd);
                }

                if (display_L_Buyer)
                {
                    do
                    {
                        FastDriver.PaymentDetails.BuyerDisplayL.FASetCheckbox(true);
                    } while (!FastDriver.PaymentDetails.BuyerDisplayL.Enabled);
                }
                else
                {
                    FastDriver.PaymentDetails.BuyerDisplayL.FASetCheckbox(false);
                }

                if (SellerPaidAtClosing.HasValue)
                {
                    FastDriver.PaymentDetails.SellerAtClosing.FASetText(SellerPaidAtClosing.ToString());
                }
                if (SellerPaidBeforeClosing.HasValue)
                {
                    FastDriver.PaymentDetails.SellerBeforeClosing.FASetText(SellerPaidBeforeClosing.ToString());
                }
                if (SellerPaidbyOthers.HasValue)
                {
                    FastDriver.PaymentDetails.SellerPaidbyOthers.FASetText(SellerPaidbyOthers.ToString());
                }
                if (SellerPaidbyOtherPaymentMthd != string.Empty)
                {
                    FastDriver.PaymentDetails.SellerPaidbyOthersPayMethod.FASelectItemBySendingKeys(SellerPaidbyOtherPaymentMthd.ToString());
                }

                if (display_L_Seller)
                {
                    do
                    {
                        FastDriver.PaymentDetails.SellerDisplayL.FASetCheckbox(true);
                    } while (!FastDriver.PaymentDetails.SellerDisplayL.Enabled);
                }

                if (LenderAffialite)
                {
                    FastDriver.PaymentDetails.LenderAffiliate.FASetCheckbox(true);
                }

                if (RemoveLenderAffialite)
                {
                    if (FastDriver.PaymentDetails.LenderAffiliate.Enabled.ToString().Equals("True"))
                    {
                        FastDriver.PaymentDetails.LenderAffiliate.FASetCheckbox(false);
                    }
                }
                double? TotalSellerCharge;
                TotalSellerCharge = SellerPaidAtClosing + SellerPaidBeforeClosing + SellerPaidbyOthers;
                FastDriver.PaymentDetails.SellerCharge.FASetText(TotalSellerCharge.ToString());
                FastDriver.DialogBottomFrame.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.btnDone.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.BottomFrame.Done();
            }
            else
            {
                Reports.StatusUpdate("Wrong PDD has been Opened", false);
            }
        }

        public void AddTitleAndScrowFee(string FeeType, string FeeDescription, string FeeCode = null)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);
            FastDriver.FileFees.AddFees.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(FeeType);
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.FeeSearchFeeDescription.FASetText(FeeDescription);
            FastDriver.FileFees.FindNow.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();

            //Search By FeeCode
            if (FeeCode != null)
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#3", FeeCode, "#1", TableAction.On);
            else
                FastDriver.FileFees.AddFeeTable.PerformTableAction("#2", FeeDescription, "#1", TableAction.On);

            FastDriver.BottomFrame.Done();
            FastDriver.BottomFrame.Done();

        }

        public void VerifyFieldsInTCPSection()
        {

            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            Support.AreEqual(true.ToString(), FastDriver.FileFees.TitlePolicyCalculationsforCD.Text.Contains("Title Policy Calculations for Closing Disclosure").ToString());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.TitlePolicyCalculationsforCD.Text.Contains("Full Loan Premium").ToString());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.TitlePolicyCalculationsforCD.Text.Contains("Disclosed Owner Premium").ToString());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.TitlePolicyCalculationsforCD.Text.Contains("Loan Estimate - Unrounded").ToString());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.lenderAdjAmnt.Enabled.ToString());
            Support.AreEqual(false.ToString(), FastDriver.FileFees.OwnerAdjAmnt.Enabled.ToString());
            Support.AreEqual("$0.00", FastDriver.FileFees.OwnerAdjAmnt.FAGetValue());
            Support.AreEqual("$0.00", FastDriver.FileFees.OwnerAdjAmnt.FAGetValue());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.LenderLoanEstimateAmount.Enabled.ToString());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.OwnerLoanEstimateAmount.Enabled.ToString());
            Support.AreEqual("$0.00", FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue());
            Support.AreEqual("$0.00", FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue());
            Support.AreEqual(false.ToString(), FastDriver.FileFees.BSSplitButton.Enabled.ToString());
        }

        public void VerifyRecordingTransferTaxSection()
        {

            FastDriver.FileFees.WaitForFeeScreen();
            FastDriver.FileFees.RecordingandTax.FAClick();
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFeesTax);
            Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFeesAndTransferTaxes.Text.Contains("Recording Fees & Transfer Taxes").ToString());
            Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingFeesAndTransferTaxes.Text.Contains("Recording Fees and Future Recording Fees").ToString());

            Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingLoanEstUnrounded.Enabled.ToString());
            Support.AreEqual("$0.00", FastDriver.FileFees.RecordingLoanEstUnrounded.FAGetValue());

            Support.AreEqual(true.ToString(), FastDriver.FileFees.RecordingLoanEstRounded.Enabled.ToString());
            Support.AreEqual("$0.00", FastDriver.FileFees.RecordingLoanEstRounded.FAGetValue());

            Support.AreEqual(false.ToString(), FastDriver.FileFees.GTaxBrokenImage.Displayed.ToString());

            Support.AreEqual(true.ToString(), FastDriver.FileFees.TranTaxLoanEstUnrounded.Enabled.ToString());
            Support.AreEqual("$0.00", FastDriver.FileFees.TranTaxLoanEstUnrounded.FAGetValue());

            Support.AreEqual(true.ToString(), FastDriver.FileFees.TranTaxLoanEstRounded.Enabled.ToString());
            Support.AreEqual("$0.00", FastDriver.FileFees.TranTaxLoanEstRounded.FAGetValue());
        }

        public void AddFirstMatchingTitleAndScrowFee(string FeeDescription, string feeType = "All")
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            bool feeExistsOnTable = false;
            IEnumerable<IWebElement> feeDescs = FastDriver.FileFees.TitleandescrowTable.FAFindElements(ByLocator.CssSelector, "tr td:nth-child(2)");

            foreach ( IWebElement feeDesc in feeDescs)
            {
                if(feeDesc.Text.Trim() == FeeDescription)
                {
                    feeExistsOnTable = true;
                    break;
                }
            }

            if (!feeExistsOnTable)
            {
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(feeType);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(FeeDescription);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                ReadOnlyCollection<IWebElement> TableCells = FastDriver.FileFees.AddFeeTable.FindElements(By.CssSelector("td"));


                for (int CellCount = 0; CellCount < TableCells.Count; CellCount++)
                {

                    if (TableCells[CellCount].FAGetText().Trim() == FeeDescription)
                    {
                        TableCells[CellCount - 1].FindElement(By.CssSelector("input[type='checkbox']")).FAClick();
                        break;
                    }
                }
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(this.TitleandescrowTable);
            }
            else
            {
                Reports.StatusUpdate("Fee is already available at table.No Need to add through add fee.", true);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDescription, 1, TableAction.On);
                FastDriver.FileFees.WaitForScreenToLoad(this.TitleandescrowTable);
            }
        }

        public void AddFirstMatchingRecordingFee(string FeeDescription)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.RecordingandTax.FAClick();
            FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
            string tableContent = FastDriver.FileFees.RecordingTable.FAGetText();
            if (!tableContent.Contains(FeeDescription))
            {
                FastDriver.FileFees.AddFeesTax.FAClick();

                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("All");
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(FeeDescription);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();

                ReadOnlyCollection<IWebElement> TableCells = FastDriver.FileFees.AddFeeTable.FindElements(By.CssSelector("td"));


                for (int CellCount = 0; CellCount < TableCells.Count; CellCount++)
                {

                    if (TableCells[CellCount].Text.Contains(FeeDescription))
                    {
                        TableCells[CellCount - 1].FindElement(By.CssSelector("input[type='checkbox']")).FAClick();
                        break;
                    }
                }
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForScreenToLoad(this.RecordingTable);
            }
            else
            {
                Reports.StatusUpdate("Recording fee is already available in table. No Need to add from Add fee button.", true);
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, FeeDescription, 1, TableAction.On);
                FastDriver.FileFees.WaitForScreenToLoad(this.RecordingTable);
            }
        }


        public string DeselectTitleScrowFee(string FeeDescription)
        {
            FastDriver.LeftNavigation.Navigate<FileFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForFeeScreen();
            FastDriver.FileFees.WaitCreation(FastDriver.FileFees.AddFees);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDescription, 1, TableAction.Off);
            //To handle pop up which appears when invoiced fees is removed
            string Message = FastDriver.WebDriver.HandleDialogMessage(true, true);
            FastDriver.BottomFrame.Done();
            return Message;
        }

        public string CalculateAndGetPOD(string LenderFeeDescription, string OwnerFeeDescription)
        {

            this.WaitForFeeScreen();
            string LenderSellerChargeTableValue = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, LenderFeeDescription, 7, TableAction.GetAttribute, "value").Message;
            string LenderBuyerChargeTableValue = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, LenderFeeDescription, 4, TableAction.GetAttribute, "value").Message;
            string OwnerSellerChargeTableValue = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, OwnerFeeDescription, 7, TableAction.GetAttribute, "value").Message;
            string OwnerBuyerChargeTableValue = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, OwnerFeeDescription, 4, TableAction.GetAttribute, "value").Message;

            double LenderSellerCharge = Convert.ToDouble(LenderSellerChargeTableValue != "" ? LenderSellerChargeTableValue : "0.00");
            double LenderBuyerCharge = Convert.ToDouble(LenderBuyerChargeTableValue != "" ? LenderBuyerChargeTableValue : "0.00");
            double OwnerSellerCharge = Convert.ToDouble(OwnerSellerChargeTableValue != "" ? OwnerSellerChargeTableValue : "0.00");
            double OwnerBuyerCharge = Convert.ToDouble(OwnerBuyerChargeTableValue != "" ? OwnerBuyerChargeTableValue : "0.00");

            double LenderTotalCharge = LenderBuyerCharge + LenderSellerCharge;
            double OwnerTotalCharge = OwnerSellerCharge + OwnerBuyerCharge;
            double LenderAdjAmt = Convert.ToDouble(lenderAdjAmnt.FAGetValue().Replace("$", ""));

            double DOP = LenderTotalCharge + OwnerTotalCharge - LenderAdjAmt;

            if (OwnerSellerCharge == 0.00 & OwnerBuyerCharge == 0.00)
            {
                Support.AreEqual("$0.00", this.OwnerAdjAmnt.FAGetValue().Trim());
            }
            else
            {
                Support.AreEqual(DOP.ToString().FormatAsMoney(true), this.OwnerAdjAmnt.FAGetValue().Trim());
            }

            return DOP.ToString().FormatAsMoney();

        }

        public string CalculateVerifyAndGetTPA(string FeeDesc, string SplitPercentage)
        {

            double SplitPercentageNum = Convert.ToDouble(SplitPercentage);
            string BuyerChargeTableValue = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc, 4, TableAction.GetAttribute, "value").Message;
            string SellerChargeTableValue = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, FeeDesc, 7, TableAction.GetAttribute, "value").Message;

            double BuyerCharge = Convert.ToDouble(BuyerChargeTableValue != "" ? BuyerChargeTableValue : "0.00");
            double SellerCharge = Convert.ToDouble(SellerChargeTableValue != "" ? SellerChargeTableValue : "0.00");


            double LenderAdjAmnt = Convert.ToDouble(lenderAdjAmnt.FAGetValue().Replace("$", ""));
            double TPA = ((LenderAdjAmnt - (BuyerCharge + SellerCharge)) * SplitPercentageNum / 100);
            string TitlePremiumAmount = TPA.ToString().FormatAsMoney(true);
            Support.AreEqual(TitlePremiumAmount, this.SPA.FAGetValue().Trim());

            return TitlePremiumAmount;

        }

        public void EnterAmount(string FeeDesc, bool TitleEscrowTable, string Buyer_Amt, string Seller_Amt)
        {
            Reports.TestStep = "Enter Buyer Charge and Seller Charge for " + FeeDesc + ".";
            if (TitleEscrowTable)
            {
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.TitleandescrowTable);
                if (Buyer_Amt != "")
                {
                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDesc, "Buyer Charge", TableAction.SetText, Buyer_Amt);
                }
                if (Seller_Amt != "")
                {
                    FastDriver.FileFees.TitleandescrowTable.PerformTableAction("#2", FeeDesc, "Seller Charge", TableAction.SetText, Seller_Amt);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(this.TitleandescrowTable);
            }
            else//Recording Table
            {
                FastDriver.FileFees.WaitCreation(FastDriver.FileFees.RecordingTable);
                if (Buyer_Amt != "")
                {
                    FastDriver.FileFees.RecordingTable.PerformTableAction("#2", FeeDesc, "Buyer Charge", TableAction.SetText, Buyer_Amt);
                }
                if (Seller_Amt != "")
                {
                    FastDriver.FileFees.RecordingTable.PerformTableAction("#2", FeeDesc, "Seller Charge", TableAction.SetText, Seller_Amt);
                }
                FastDriver.BottomFrame.Done();
                FastDriver.FileFees.WaitForFeeScreen(this.RecordingTable);
            }
        }

        public void VerifythePolicyNameinTPCsection(string FeeType, string Desc)
        {
            if (FeeType == "Lender")
            {
                Reports.TestStep = "VERIFY THE LENDER POLICY NAME IN TPC SECTION";
                Support.AreEqual(this.TitleLenderPolicyName.FAGetValue(), Desc);
            }
            else
            {
                Reports.TestStep = "VERIFY THE OWNER POLICY NAME IN TPC SECTION";
                Support.AreEqual(this.TitleOwnerPolicyName.FAGetValue(), Desc);
            }
        }

        public void PerformDelivery(string deliveryMethod)
        {
            Reports.TestStep = "Perfom the " + deliveryMethod + " delivery method.";
            FastDriver.FileFees.DeliverMethod.FASelectItem(deliveryMethod);
            FastDriver.FileFees.Deliver.FAClick();
        }

        public FileFees SearchFees(string feeType = null, string feeDescription = null)
        {
            WaitForScreenToLoad(FeeSearchFeeTypes);
            FeeSearchFeeTypes.FASelectItem(feeType);
            FeeSearchFeeDescription.FASetText(feeDescription);
            FindNow.FAClick();

            return this;
        }

        public string SelectFirstFromFeeResultsTable()
        {
            WaitForScreenToLoad(FeeSearchFeeSelect);
            FeeSearchFeeSelect.FASetCheckbox(true);

            return FirstFeesDesc.Text;
        }

        public void PullFeeonFileFee(string Section_C_Fee_Des, String BuyerCharge, String SellerCharge, string FeeType = "Escrow Fee")
        {
            Reports.TestStep = @"Pull the C section Fees created in ADM.";
            FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            FastDriver.FileFees.AddFees.FAClick();
            FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
            FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(FeeType);
            FastDriver.FileFees.FeeSearchFeeDescription.FASetText(Section_C_Fee_Des);
            FastDriver.FileFees.FindNow.FAClick();
            FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FirstFeesDesc);
            FastDriver.FileFees.FeeSearchFeeSelect.FASetCheckbox(true);
            FastDriver.FileFees.FindNow.FAClick();
            FastDriver.BottomFrame.Done();
            FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", Section_C_Fee_Des, "Buyer Charge", TableAction.SetText, BuyerCharge);
            FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description", Section_C_Fee_Des, "Seller Charge", TableAction.SetText, SellerCharge);
            FastDriver.BottomFrame.Done();
        }

        public bool VerifyAllCheckboxesAreSelected()
        {
            ReadOnlyCollection<IWebElement> TableRows = TitleandescrowTable.FindElements(By.CssSelector("tr"));

            for (int CellCount = 1; CellCount < TableRows.Count; CellCount++)
            {
                if (!TableRows[CellCount].FindElement(By.CssSelector("input[type='checkbox']")).Selected)
                {
                    return false;
                }
            }
            return true;
        }

        public bool VerifyAllCheckboxesAreNotSelected()
        {
            ReadOnlyCollection<IWebElement> TableRows = TitleandescrowTable.FindElements(By.CssSelector("tr"));

            for (int CellCount = 1; CellCount < TableRows.Count; CellCount++)
            {
                if (TableRows[CellCount].FindElement(By.CssSelector("input[type='checkbox']")).Selected)
                {
                    return false;
                }
            }
            return true;
        }

        public bool IsCellEnabledOnTitleEscrowFeesTable(string Description, string CSSSelector)
        {
            try
            {
                /*
                 *Sel - 1
                 *Description - 2
                 *Det - 3
                 *Buyer Charge - 4
                 *Sales Tax - 5
                 *Seller Charge - 6
                 *Sales Tax - 7 
                 *Total Charge - 8
                 *Loan Estimate Unrounded - 9
                 *Inv - 10
                 * */
                return this.TitleandescrowTable.PerformTableAction(2, Description, 4, TableAction.GetCell).Element.FindElement(By.CssSelector(CSSSelector)).IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsCellEnabledOnRecordingTaxFeesTable(string Description, string CSSSelector)
        {
            try
            {
                /*
                 *Sel - 1
                 *Description - 2
                 *Det - 3
                 *Buyer Charge - 4
                 *Seller Charge - 5
                 *Total Charge - 6
                 *Loan Estimate Unrounded - 7
                 *Inv - 8
                 * */
                return this.RecordingTable.PerformTableAction(2, Description, 4, TableAction.GetCell).Element.FindElement(By.CssSelector(CSSSelector)).IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsCellReadOnlyOnTitleEscrowFeesTable(string Description, string CSSSelector)
        {
            try
            {
                /*
                 *Sel - 1
                 *Description - 2
                 *Det - 3
                 *Buyer Charge - 4
                 *Sales Tax - 5
                 *Seller Charge - 6
                 *Sales Tax - 7 
                 *Total Charge - 8
                 *Loan Estimate Unrounded - 9
                 *Inv - 10
                 * */
                return this.TitleandescrowTable.PerformTableAction(2, Description, 4, TableAction.GetCell).Element.FindElement(By.CssSelector(CSSSelector)).IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsCellReadOnlyOnRecordingTaxFeesTable(string Description, string CSSSelector)
        {
            try
            {
                /*
                 *Sel - 1
                 *Description - 2
                 *Det - 3
                 *Buyer Charge - 4
                 *Seller Charge - 5
                 *Total Charge - 6
                 *Loan Estimate Unrounded - 7
                 *Inv - 8
                 * */
                return this.RecordingTable.PerformTableAction(2, Description, 4, TableAction.GetCell).Element.FindElement(By.CssSelector(CSSSelector)).IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool ValidateTitleEscrowFeesAreAlphabeticallyOrdered()
        {
            try
            {
                List<string> UnorderedCheckedFeesList = new List<string>();
                List<string> UnorderedUncheckedFeesList = new List<string>();
                List<string> OrderedCheckedFeesList = new List<string>();
                List<string> OrderedUncheckedFeesList = new List<string>();

                ReadOnlyCollection<IWebElement> TableRows = FastDriver.FileFees.TitleandescrowTable.FindElements(By.CssSelector("tr:nth-child(n+2)"));
                foreach (IWebElement TableRow in TableRows)
                {
                    string FeeDescription = TableRow.FindElement(By.CssSelector("td:nth-child(2) textarea")).FAGetValue();
                    if (TableRow.FindElement(By.CssSelector("input[type=\"checkbox\"]")).IsSelected())
                    {

                        OrderedCheckedFeesList.Add(FeeDescription);
                        UnorderedCheckedFeesList.Add(FeeDescription);
                    }
                    else
                    {
                        OrderedUncheckedFeesList.Add(FeeDescription);
                        UnorderedUncheckedFeesList.Add(FeeDescription);
                    }

                }

                OrderedCheckedFeesList.Sort();
                OrderedUncheckedFeesList.Sort();

                int FeeCount = 0;
                foreach (string Fee in OrderedCheckedFeesList)
                {
                    if (UnorderedCheckedFeesList.IndexOf(Fee) != FeeCount)
                    {
                        return false;
                    }
                    ++FeeCount;
                }

                FeeCount = 0;
                foreach (string Fee in OrderedUncheckedFeesList)
                {
                    if (UnorderedUncheckedFeesList.IndexOf(Fee) != FeeCount)
                    {
                        return false;
                    }
                    ++FeeCount;
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }




        public void VerifyTPACalculation(string TitleLenderPolicyDesc, string TitleOwnerPolicyDesc)
        {

            try
            {


                Reports.TestStep = "Verify the Title Premium Ajustment Value based on the Formula :--> Title Premium Adjustment =(Buyer Disclosed LP + Buyer Disclosed OP) - (Buyer Actual LP + Buyer Actual OP)";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitlePolicyCalcForCD);
                FastDriver.FileFees.BSSplitButtonLender.Click();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                string DLPBuyerSplitVal = FastDriver.BuyerSellerSplitDlg.BuyerCharge.FAGetValue();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitlePolicyCalculationsforCD);
                FastDriver.FileFees.BSSplitButton.Click();
                FastDriver.BuyerSellerSplitDlg.WaitForScreenToLoad();
                string DOPBuyerSplitVal = FastDriver.BuyerSellerSplitDlg.BuyerCharge.FAGetValue();
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                string BuyerFeeLoanPolicy = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyDesc, 4, TableAction.GetInputValue).Message;
                if (BuyerFeeLoanPolicy == "")
                    BuyerFeeLoanPolicy = "0.00";

                string BuyerFeeOwnerPolicy = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleOwnerPolicyDesc, 4, TableAction.GetInputValue).Message;
                if (BuyerFeeOwnerPolicy == "")
                    BuyerFeeOwnerPolicy = "0.00";

                string TitlePremiumAjustment = FastDriver.FileFees.SPA.FAGetValue();
                TitlePremiumAjustment = TitlePremiumAjustment.Replace("$", "");
                decimal TitlePremiumAjustmentD = Convert.ToDecimal(TitlePremiumAjustment);
                string TitlePremiumAjustmentF = TitlePremiumAjustmentD.ToString("F");

                Reports.TestStep = "Calculate the TPA based on Formula = Title Premium Adjustment = " + TitlePremiumAjustmentF + " = ( Buyer Disclosed LP = " + DLPBuyerSplitVal + "+ Buyer Disclosed OP = " + DOPBuyerSplitVal + ") - (Buyer Actual LP = " + BuyerFeeLoanPolicy + "+ Buyer Actual OP = " + BuyerFeeOwnerPolicy + ")";

                decimal DLPBuyerSplitVald = Convert.ToDecimal(DLPBuyerSplitVal);
                decimal DOPBuyerSplitVald = Convert.ToDecimal(DOPBuyerSplitVal);

                decimal BuyerFeeLoanPolicyd = Convert.ToDecimal(BuyerFeeLoanPolicy);
                decimal BuyerFeeOwnerPolicyd = Convert.ToDecimal(BuyerFeeOwnerPolicy);

                decimal TPA = (DLPBuyerSplitVald + DOPBuyerSplitVald) - (BuyerFeeLoanPolicyd + BuyerFeeOwnerPolicyd);
                string TPAs = TPA.ToString("F");

                if (TPAs == TitlePremiumAjustmentF)
                    Support.AreEqual(TPA.ToString(), TitlePremiumAjustmentF.ToString(), "Title Premium Adjustment displayed is Matching With the Formula Calculation");
                else
                    Reports.StatusUpdate("Title Premium Adjustment displayed is Mismatching With the Formula Calculation", false);


            }
            catch { }

        }


        public void VerifyDOPCalculation(string TitleLenderPolicyDesc, string TitleOwnerPolicyDesc)
        {
            try
            {

                Reports.TestStep = "Verify the Disclosed Owner Premium Value based on the Formula :--> DOP =(Actual Lender (Buyer + Seller) + Actual Owner (Buyer + Seller)) - (Disclosed Loan Premium)";


                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                string LenderBuyerCharge = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyDesc, 4, TableAction.GetInputValue).Message;
                if (LenderBuyerCharge == "")
                    LenderBuyerCharge = "0.00";

                string LenderSellerCharge = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleLenderPolicyDesc, 7, TableAction.GetInputValue).Message;
                if (LenderSellerCharge == "")
                    LenderSellerCharge = "0.00";


                string OwnerBuyerCharge = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleOwnerPolicyDesc, 4, TableAction.GetInputValue).Message;
                if (OwnerBuyerCharge == "")
                    OwnerBuyerCharge = "0.00";

                string OwnerSellerCharge = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TitleOwnerPolicyDesc, 7, TableAction.GetInputValue).Message;
                if (OwnerSellerCharge == "")
                    OwnerSellerCharge = "0.00";


                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.lenderAdjAmnt);
                string DisclosedLoanPrem = FastDriver.FileFees.lenderAdjAmnt.FAGetValue();
                DisclosedLoanPrem = DisclosedLoanPrem.Replace("$", "");
                decimal DisclosedLoanPremD = Convert.ToDecimal(DisclosedLoanPrem);
                string DisclosedLoanPremDF = DisclosedLoanPremD.ToString("F");

                string DisclosedOwnerPrem = FastDriver.FileFees.OwnerAdjAmnt.FAGetValue();
                DisclosedOwnerPrem = DisclosedOwnerPrem.Replace("$", "");
                decimal TDisclosedOwnerPremD = Convert.ToDecimal(DisclosedOwnerPrem);
                string TDisclosedOwnerPremDF = TDisclosedOwnerPremD.ToString("F");

                Reports.TestStep = "Calculate the DOP based on Formula = Disclosed Owner Premium = " + TDisclosedOwnerPremDF + " = ( Buyer Charge LP = " + LenderBuyerCharge + " + Seller Charge LP = " + LenderSellerCharge + " + Buyer Charge OP = " + OwnerBuyerCharge + " + Seller Charge OP = " + OwnerSellerCharge + ") - (Disclosed Loan Premium = " + DisclosedLoanPremDF + ")";

                decimal LenderBuyerChargeVal = Convert.ToDecimal(LenderBuyerCharge);
                decimal LenderSellerChargeVal = Convert.ToDecimal(LenderSellerCharge);
                decimal OwnerBuyerChargeVal = Convert.ToDecimal(OwnerBuyerCharge);
                decimal OwnerSellerChargeVal = Convert.ToDecimal(OwnerSellerCharge);

                decimal DOP = (LenderBuyerChargeVal + LenderSellerChargeVal + OwnerBuyerChargeVal + OwnerSellerChargeVal) - (DisclosedLoanPremD);
                string DOPs = DOP.ToString("F");

                if (DOPs == TDisclosedOwnerPremDF)
                    Support.AreEqual(DOP.ToString(), TDisclosedOwnerPremDF.ToString(), "Disclosed Owner Premium displayed is Matching With the Formula Calculation");
                else
                    Reports.StatusUpdate("Disclosed Owner Premium displayed is Mismatching With the Formula Calculation", false);
            }
            catch { }

        }


     public bool IsTitlePolicyCalculationsSectionCollapsed()
        {
            try
            {
                return FastDriver.FileFees.TitlePolicyCalculationsforCDButton.FAGetAttribute("class").Contains("cButtonExpandFalse");
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsRecordingFeesAndTransferTaxesSectionCollapsed()
        {
            try
            {
                return FastDriver.FileFees.RecordingFeesAndTransferTaxesButton.FAGetAttribute("class").Contains("cButtonExpandFalse");
            }
            catch (Exception)
            {
                return false;
            }
        }
    }


    public class MiscEscrowEditDlg : PageObject
    {
        [FindsBy(How = How.Id, Using = "txtHUD1107")]
        public IWebElement HUD1107 { get; set; }

        [FindsBy(How = How.Id, Using = "txtHUD1108")]
        public IWebElement HUD1108 { get; set; }

        public MiscEscrowEditDlg WaitForScreenToLoad()
        {
            WebDriver.WaitForWindowAndSwitch("Payment Details", true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(HUD1107);

            return this;
        }

    }
    
}
