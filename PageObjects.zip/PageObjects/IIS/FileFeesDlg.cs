using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileFeesDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "lstSearchFeeTypes")]
        public IWebElement lstSearchFeeTypes { get; set; }

        [FindsBy(How = How.Id, Using = "txtSearchFeeDesc")]
        public IWebElement SearchFeeDesc { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "grdResults_grdResults")]
        public IWebElement FeesTable { get; set; }

        #endregion

        public FileFeesDlg WaitForScreenToLoad(IWebElement element = null)
        {
         //   WebDriver.WaitForWindowAndSwitch("Add Fee Dialog", true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? lstSearchFeeTypes);

            return this;
        }

        public FileFeesDlg ClickOnFeeResultCheckbox(int index)
        {
            FastDriver.FileFeesDlg.FeeResult(index).FindElement(By.CssSelector("input[type=\"checkbox\"]")).FAClick();
            return this;
        }

        #region Dynamic WebElements

        public IWebElement FeeResult(int index)
        {
            if (!this.WaitCreation(FastDriver.WebDriver.FindElement(By.Id("grdResults_" + index)), continueOnFailure: true))
                throw new ElementNotVisibleException();
            return WebDriver.FindElement(By.Id("grdResults_" + index));
        }

        #endregion
    }
}
