﻿using System;
using System.Threading;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileHomepage : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlPolicyIssuer")]
        public IWebElement PolicyIssuedBy { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNum")]
        public IWebElement txtFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTransType")]
        public IWebElement txtTransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOfficeLN")]
        public IWebElement OfficeLicense { get; set; }

        [FindsBy(How = How.Id, Using = "rdCD")]
        public IWebElement FormTypeCD { get; set; }

        [FindsBy(How = How.Id, Using = "rdHUD")]
        public IWebElement FormTypeHUD { get; set; }

        //Added as part of FMUC0086
        [FindsBy(How = How.Id, Using = "BPSRC_tdButtonExpand")]
        public IWebElement BusinessPartyContactExpand { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkEditAttentionContactInfo")]
        public IWebElement BusinessPartyEditContact { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_imgAdHocFlag")]
        public IWebElement DirectedByGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_imgAdHocFlag")]
        public IWebElement NewLenderGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_imgAdHocFlag")]
        public IWebElement AssociateLenderGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_labelIdcode")]
        public IWebElement NewLenderBusinessPartyIDcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtBusOrgNMLS")]
        public IWebElement NMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_ddlBusOrgStateLicense")]
        public IWebElement STLicense { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_cboUWEmployees")]
        public IWebElement TitleOwnOfficeUWEmployees { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtBusOrgNMLS")]
        public IWebElement NewLenderNMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_ddlBusOrgStateLicense")]
        public IWebElement NewLenderSTLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkEditAttentionContactInfo")]
        public IWebElement DirectedByEditContact { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkContactWeeklyEmailStatus")]
        public IWebElement DirectedByContactStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textContactBusPhone")]
        public IWebElement DirectedByContactBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtContactExtnPhone")]
        public IWebElement DirectedByContactPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textContactBusFax")]
        public IWebElement DirectedByContactBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textContactCellPhone")]
        public IWebElement DirectedByContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textContactEmailAddress")]
        public IWebElement DirectedByContactEmailAddress { get; set; }
        
        #endregion

        #region WebElements Converted from CodedUI object map

        [FindsBy(How = How.Id, Using = "BPSRC_chkContactWeeklyEmailStatus")]
        public IWebElement BSStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_labelName")]
        public IWebElement DirectedByNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_labelIdcode")]
        public IWebElement DirectedByIDCodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtGABcode")]
        public IWebElement BusinessPartyGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_cmdFindName")]
        public IWebElement BussinessPartyFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtName")]
        public IWebElement BusinessPartyName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelIdcode")]
        public IWebElement BusinessPartyIDCodeField { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelName")]
        public IWebElement BusinessPartyNameField { get; set; }
        
        [FindsBy(How = How.Id, Using = "BPSRC_tblAddr")]
        public IWebElement BusinessPartyAddress { get; set; }
       
        [FindsBy(How = How.Id, Using = "BPSRC_chkEditContactInfo")]
        public IWebElement BusinessPartyEditCont { get; set; }

        [FindsBy(How = How.Name, Using = "BPSRC$chkEditContactInfo")]
        public IWebElement BusinessPartyElctAddEdit { get; set; }

        [FindsBy(How = How.Name, Using = "BPSRC$chkEditAttentionContactInfo")]
        public IWebElement BusinessPartyBusorgEditchkbx { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textBusPhone")]
        public IWebElement BusinessPartyBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtExtnPhone")]
        public IWebElement BusinessPartyBusPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textBusFax")]
        public IWebElement BusinessPartyBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textCellPhone")]
        public IWebElement BusinessPartyCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textPager")]
        public IWebElement BusinessPartyPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textEmailAddress")]
        public IWebElement BusinessPartyEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkWeeklyEmailStatus")]
        public IWebElement BusinessPartyWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboAttention")]
        public IWebElement BusinessPartyAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkEdit")]
        public IWebElement BusinessPartyEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textName")]
        public IWebElement BusinessPartyEditName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboSalesRep1")]
        public IWebElement BusinessPartySalesRep1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@name='BPSRC$chkEdit']")]
        public IWebElement BusinessPartyEditNamechkbx { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboSalesRep2")]
        public IWebElement BusinessPartySalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textReference")]
        public IWebElement BusinessPartyReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboAddtionalRole")]
        public IWebElement BusinessPartyAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelContactName")]
        public IWebElement BusinessPartyContactName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactBusPhone")]
        public IWebElement BusinessPartyContactBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtContactExtnPhone")]
        public IWebElement BusinessPartyContactPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactBusFax")]
        public IWebElement BusinessPartyContactBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactCellPhone")]
        public IWebElement BusinessPartyContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactPager")]
        public IWebElement BusinessPartyContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactEmailAddress")]
        public IWebElement BusinessPartyContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtPercent")]
        public IWebElement BusinessPartyPercent { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtAmount")]
        public IWebElement BusinessPartyAmount { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtGABcode")]
        public IWebElement DirectedByGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_cmdFindName")]
        public IWebElement DirectedByFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtName")]
        public IWebElement DirectedByName { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkEditContactInfo")]
        public IWebElement DirectedByEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textBusPhone")]
        public IWebElement DirectedByBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textBusFax")]
        public IWebElement DirectedByBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textCellPhone")]
        public IWebElement DirectedByCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textPager")]
        public IWebElement DirectedByPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textEmailAddress")]
        public IWebElement DirectedByEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkWeeklyEmailStatus")]
        public IWebElement DirectedByWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboAttention")]
        public IWebElement DirectedBycomboAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkEdit")]
        public IWebElement DirectedByEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textName")]
        public IWebElement DirectedByEditName { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboSalesRep1")]
        public IWebElement DirectedBySalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboSalesRep2")]
        public IWebElement DirectedBySalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textReference")]
        public IWebElement DirectedByReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboAddtionalRole")]
        public IWebElement DirectedByAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtPercent")]
        public IWebElement DirectedByPercent { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtAmount")]
        public IWebElement DirectedByAmount { get; set; }

        [FindsBy(How = How.Id, Using = "btnCOO")]
        public IWebElement ChangeOO { get; set; }

        [FindsBy(How = How.Id, Using = "btnHistory")]
        public IWebElement EventLog { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceTitle")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceEsrw")]
        public IWebElement Escrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceSubEsrw")]
        public IWebElement SubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBusSegment")]
        public IWebElement BusinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "chkAutoNum")]
        public IWebElement AutoNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNumPrx")]
        public IWebElement FileNumPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNum")]
        public IWebElement FileNum { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNumbSfx")]
        public IWebElement FileNumSufix { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTransType")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "chkUseAsMstr")]
        public IWebElement UseAsMasterFile { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProgramType")]
        public IWebElement ProgramType { get; set; }

        [FindsBy(How = How.Id, Using = "chkProgTypeOverRide")]
        public IWebElement ProgramTypeOverride { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOffice")]
        public IWebElement EscrowOwningOfficeOffice { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOfficer")]
        public IWebElement EscrowOwningOfficeOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlAssistant")]
        public IWebElement EscrowOwningOfficeAssistant { get; set; }

        //Misleading naming convention
        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_btnRemove")]
        public IWebElement AddRemoveEscOff { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_btnRemove")]
        public IWebElement AddRemoveEscrowProdOffice { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlOffice")]
        public IWebElement TitleOwningOfficeOffice { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlOfficer")]
        public IWebElement TitleOwningOfficeOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlAssistant")]
        public IWebElement TitleOwningOfficeAssistant { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlUndrwriter")]
        public IWebElement TitleOwningOfficeUndrwriter { get; set; }

        //Misleading naming convention
        [FindsBy(How = How.Id, Using = "TitleOwnOffice_btnRemove")]
        public IWebElement AddRemoveOwningOff { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_btnRemove")]
        public IWebElement AddRemoveTitleProdOffice { get; set; }

        [FindsBy(How = How.Id, Using = "BusPrgrms_btnHistory")]
        public IWebElement History { get; set; }

        [FindsBy(How = How.Id, Using = "BusPrgrms_btnRemove")]
        public IWebElement AddRemoveBusPrograms { get; set; }

        [FindsBy(How = How.Id, Using = "Products_btnRemove")]
        public IWebElement AddRemoveProducts { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds_0_cpt")]
        public IWebElement Products { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_ddlSearchType")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_btnRemove")]
        public IWebElement AddRemoveInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_txtInstructions")]
        public IWebElement SearchInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_txtAddInstruction")]
        public IWebElement AddInstruction { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtSlsPrie")]
        public IWebElement TermsDatesPrice { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtLibltyAmnt")]
        public IWebElement TermsDatesLiabilityAmnt { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtNewLoanAmnt")]
        public IWebElement TermsDatesNewLoanAmnt { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtNewLoanLiblty")]
        public IWebElement TermsDatesNewLoanLiability { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtEstDaysToCls")]
        public IWebElement TermsDatesEstDaysToClose { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtEstSetlDate")]
        public IWebElement TermsDatesEstSettlementDate { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropName")]
        public IWebElement PropertyName { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_ddlPropType")]
        public IWebElement PropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropLotName")]
        public IWebElement PropertyLotName { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBlock")]
        public IWebElement PropertyBlock { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropUnit")]
        public IWebElement PropertyUnit { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTRact")]
        public IWebElement PropertyTRact { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropFee")]
        public IWebElement PropertyFee { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBuilding")]
        public IWebElement PropertyBuilding { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBook")]
        public IWebElement PropertyBook { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropPage")]
        public IWebElement PropertyPage { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropSection")]
        public IWebElement PropertySection { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTownShip")]
        public IWebElement PropertyTownShip { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropRange")]
        public IWebElement PropertyRange { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropParcel")]
        public IWebElement PropertyPropParcel { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropSubDivCondo")]
        public IWebElement PropertyPropSubDivCondo { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_ddlEstateType")]
        public IWebElement PropertyEstateType { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxAPN1")]
        public IWebElement PropertyPropTaxAPN1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxYear1")]
        public IWebElement PropertyPropTaxYear1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxAPN2")]
        public IWebElement PropertyPropTaxAPN2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxYear2")]
        public IWebElement PropertyPropTaxYear2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine1")]
        public IWebElement PropertyBookAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine2")]
        public IWebElement PropertyBookAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine3")]
        public IWebElement PropertyBookAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine4")]
        public IWebElement PropertyBookAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtCity")]
        public IWebElement PropertyAddressBookCity { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboState")]
        public IWebElement PropertyState { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtZip")]
        public IWebElement PropertyZip { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtCounty")]
        public IWebElement PropertyCounty { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboCountry")]
        public IWebElement PropertyCountry { get; set; }

        [FindsBy(How = How.Id, Using = "ddlB11Type")]
        public IWebElement Buyer1Type { get; set; }

        [FindsBy(How = How.Id, Using = "txtB11FName")]
        public IWebElement Buyer1FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB11MName")]
        public IWebElement Buyer1MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB11LName")]
        public IWebElement Buyer1LastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB11Suffix")]
        public IWebElement Buyer1suffix { get; set; }

        [FindsBy(How = How.Id, Using = "ddlB21Type")]
        public IWebElement Buyer2Type { get; set; }

        [FindsBy(How = How.Id, Using = "txtB21FName")]
        public IWebElement Buyer2FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB21MName")]
        public IWebElement Buyer2MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB21LName")]
        public IWebElement Buyer2LastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB21Suffix")]
        public IWebElement Buyer2suffix { get; set; }

        [FindsBy(How = How.Id, Using = "txtB22FName")]
        public IWebElement Buyer2SpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB22MName")]
        public IWebElement Buyer2SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB22LName")]
        public IWebElement Buyer2SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtB22Suffix")]
        public IWebElement Buyer2SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "ddlL11Type")]
        public IWebElement Seller1Type { get; set; }

        [FindsBy(How = How.Id, Using = "txtL11FName")]
        public IWebElement Seller1FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL11MName")]
        public IWebElement Seller1MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL11LName")]
        public IWebElement Seller1LastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL11Suffix")]
        public IWebElement Seller1suffix { get; set; }

        [FindsBy(How = How.Id, Using = "ddlL22Type")]
        public IWebElement Seller2Type { get; set; }

        [FindsBy(How = How.Id, Using = "txtL21FName")]
        public IWebElement Seller2FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL21MName")]
        public IWebElement Seller2MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL21LName")]
        public IWebElement Seller2LastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL21Suffix")]
        public IWebElement Seller2suffix { get; set; }

        [FindsBy(How = How.Id, Using = "txtL22FName")]
        public IWebElement Seller2SpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL22MName")]
        public IWebElement Seller2SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL22LName")]
        public IWebElement Seller2SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "txtL22Suffix")]
        public IWebElement Seller2SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtGABcode")]
        public IWebElement BusinessPartyLenderGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_cmdFindName")]
        public IWebElement BusinessPartyLenderFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtName")]
        public IWebElement BusinessPartyLenderName { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_chkEditContactInfo")]
        public IWebElement BusinessPartyLenderEditcont { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textBusPhone")]
        public IWebElement BusinessPartyLenderBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textBusFax")]
        public IWebElement BusinessPartyLenderBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textCellPhone")]
        public IWebElement BusinessPartyLenderSellerCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textPager")]
        public IWebElement BusinessPartyLenderSellerPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textEmailAddress")]
        public IWebElement BusinessPartyLenderSellerEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_chkWeeklyEmailStatus")]
        public IWebElement BusinessPartyLenderWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_comboAttention")]
        public IWebElement BusinessPartyLenderAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_chkEdit")]
        public IWebElement BusinessPartyLenderEditName { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textName")]
        public IWebElement BusinessPartyLenderSellerName { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_comboSalesRep1")]
        public IWebElement BusinessPartyLenderSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_comboSalesRep2")]
        public IWebElement BusinessPartyLenderSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textReference")]
        public IWebElement BusinessPartyLenderReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtGABcode")]
        public IWebElement AssociateBusinessPartyGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_cmdFindName")]
        public IWebElement AssociateBusinessPartyFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtName")]
        public IWebElement AssociateBusinessPartyName { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_chkEditContactInfo")]
        public IWebElement AssociateBusinessPartyEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textBusPhone")]
        public IWebElement AssociateBusinessPartyBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textBusFax")]
        public IWebElement AssociateBusinessPartyBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textCellPhone")]
        public IWebElement AssociateBusinessPartyCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textPager")]
        public IWebElement AssociateBusinessPartyPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textEmailAddress")]
        public IWebElement AssociateBusinessPartyEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_chkWeeklyEmailStatus")]
        public IWebElement AssociateBusinessPartyWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboAttention")]
        public IWebElement AssociateBusinessPartyAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_chkEdit")]
        public IWebElement AssociateBusinessPartyEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textName")]
        public IWebElement AssociateBusinessPartyEidtName { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboSalesRep1")]
        public IWebElement AssociateBusinessPartySalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboSalesRep2")]
        public IWebElement AssociateBusinessPartySalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textReference")]
        public IWebElement AssociateBusinessPartyReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboAddtionalRole")]
        public IWebElement AssociateBusinessPartyAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtPercent")]
        public IWebElement AssociateBusinessPartyPercent { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtAmount")]
        public IWebElement AssociateBusinessPartyAmount { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement NewEscrowProdOff { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement NewTitleProdOff { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_grdProdOffice")]
        public IWebElement EscrowProdOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_grdProdOffice")]
        public IWebElement TitleProdOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_labelName")]
        public IWebElement DirectedByLabelName { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds")]
        public IWebElement ProductSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_imgAdHocFlag")]
        public IWebElement Globalicon { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_imgAdHocFlag")]
        public IWebElement Adhocicon { get; set; }

        [FindsBy(How = How.LinkText, Using = "The following production office(s) cannot be removed from the file because tasks are assigned to the office(s).Title production office(s):4108 - GemCounty - Title (BUID 1573) -- Northwest (1573)")]
        public IWebElement WorkflowMessage { get; set; }

        [FindsBy(How = How.Id, Using = "BusPrgrms_grdBusProg")]
        public IWebElement BusinessPrograms { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelAddress")]
        public IWebElement BusSourceAddress1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelName")]
        public IWebElement BusSrceName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelAddress")]
        public IWebElement BusSrceAdd1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelAddress2")]
        public IWebElement BusSrceAdd2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelStateAndZip")]
        public IWebElement BusSrceAdd3 { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_lblOpenDate")]
        public IWebElement OpenDate { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds")]
        public IWebElement ProductsTable { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds_0_lpn")]
        public IWebElement ProductLabel { get; set; }
        
        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_lblAdres")]
        public IWebElement EscrowOOAddress { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_lblAdres")]
        public IWebElement TitleOOAddress { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_lblAdres")]
        public IWebElement EscrowOwningOfficeAddress { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_lblAdres")]
        public IWebElement TitleOwningOfficeAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BusPrgrms_grdBusProg")]
        public IWebElement BusinessProgramsTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblSrvOrdrSrce")]
        public IWebElement OrderSource { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tblOrderSourceInfo']/tbody/tr/td/table/tbody/tr/td[@class='cButtonExpandFalse']")]
        public IWebElement OrderSourceInfoExpandIcon { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='spnOrderSource']/img")]
        public IWebElement OrderSourceIconOnTitleBar { get; set; }

        [FindsBy(How = How.Id, Using = "lblExtNum")]
        public IWebElement ExternalNo { get; set; }

        [FindsBy(How = How.Id, Using = "lblExtNum")]
        public IWebElement ExternalFileNo { get; set; }

        [FindsBy(How = How.Id, Using = "chkMyFastNCS")]
        public IWebElement ProjectFile { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Errormessage { get; set; }

        [FindsBy(How = How.Name, Using = "BusinessSourceType$txtBusinessSourceType")]
        public IWebElement BusinessSourceType { get; set; }

        ////TODO: ADD FindsByAttribute
        //public IWebElement TermsAndDates { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecondOrderSource")]
        public IWebElement SecondOrderSource { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecondExternalNumber")]
        public IWebElement SecondExternalNumber { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelName2")]
        public IWebElement BusinessPartyNameField2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tblOrderSourceInfo .cButtonExpandFalse")]
        public IWebElement OrderSourceExpand { get; set; }

        [FindsBy(How = How.Id, Using = "lblExtNumTxt")]
        public IWebElement ExternalID { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_labelIdcode")]
        public IWebElement AssociateBusinessPartyIDcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_labelName")]
        public IWebElement AssociateBusinessPartyNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_labelAddress")]
        public IWebElement AssociateBusinessPartyAddressLabel { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds_0_cpt")]
        public IWebElement ProductCheckbx { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds_0_lpn")]
        public IWebElement ProductName { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_labelIdcode")]
        public IWebElement DirectedByIDCodeField { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_labelContactName")]
        public IWebElement DirectedByContactName { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtExtnPhone")]
        public IWebElement DirectedByBusPhoneExtn { get; set; }

        [FindsBy(How = How.Name, Using = "BPDIRBY$chkEdit")]
        public IWebElement DirectedByEditChkbx { get; set; }

        //This element only visible when GAB's contact has AgentFirst as external customer setup on ADM side
        [FindsBy(How = How.Id, Using = "btnPublshFile")]
        public IWebElement PublishFile { get; set; }
        [FindsBy(How = How.Id, Using = "TitleOwnOffice_lblBusPhone")]
        public IWebElement TitleBusiPhoneNo { get; set; }

        public class ProductListDlg : PageObject
        {
            #region WebElements

            [FindsBy(How = How.Id, Using = "dgridProducts_dgridProducts")]
            public IWebElement ProductLstTable { get; set; }

            #endregion

        }

        #endregion

        #region Dynamic WebElements

        public IWebElement ProductCheckbox(int checkboxIndex){

            return WebDriver.FindElement(By.Id("Products_grdProds_" + checkboxIndex + "_cpt"));
        }
        
        #endregion

        public string GetFileNumber()
        {
            string fileNumber = "";
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(txtFileNumber);
                fileNumber = txtFileNumber.FAGetValue();
                if(fileNumber==string.Empty)
                {
                    this.SwitchToContentFrame();
                    fileNumber = txtFileNumber.FAGetValue();
                }
            }
            catch
            {
                this.SwitchToContentFrame();
                fileNumber = txtFileNumber.FAGetValue();
            }
            return fileNumber;
        }

        public string GetUrl()
        {
            // Check if file is loaded
            try
            {
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
            }
            catch (TimeoutException)
            {
                return "File is not loaded";
            }

            this.SwitchToContentFrame();
            this.WaitCreation(txtTransactionType); //just to check if the page is loaded

            return WebDriver.Url.ToString();
        }

        public FileHomepage AddFileProduct(string ProductName)
        {

            Reports.TestStep = "Navigate to File Homepage Screen and add file product " + ProductName;
            FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();
            FastDriver.FileHomepage.AddRemoveProducts.FAClick();

            FastDriver.ProductListDlg.WaitScreenToLoad();
            var checkbox =  FastDriver.ProductListDlg.Table.PerformTableAction(2, ProductName, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.CssSelector, "input[type=\"checkbox\"");
            if (!checkbox.IsSelected())
            {
                checkbox.GiveFocus();
                checkbox.FASendKeys(FAKeys.Space);
            }
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);

            FastDriver.FileHomepage.WaitForScreenToLoad();
            FastDriver.BottomFrame.Done();
            FastDriver.FileHomepage.WaitForScreenToLoad();
            return this;
        }

        public FileHomepage WaitForScreenToLoad(IWebElement element=null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? BusinessPartyGABcode);

            return this;
        }

        public void VerifyBusinessProgramTableOrder()
        {
            List<string> sortedList = new List<string>();
            List<string> tempList = new List<string>();
            foreach (var row in BusinessProgramsTable.FAFindElements(ByLocator.TagName, "tr").Where(i => i.GetAttribute("id").Contains("BusPrgrms_grdBusProg_")))
            {
                sortedList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Sorting the List
            sortedList.Sort();

            //System list
            foreach (var row in BusinessProgramsTable.FAFindElements(ByLocator.TagName, "tr").Where(i => i.GetAttribute("id").Contains("BusPrgrms_grdBusProg_")))
            {
                tempList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Verify whether the elements are sorted
            for (int i = 0; i < sortedList.Count; i++)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(sortedList.ElementAt(i), tempList.ElementAt(i));
            }

        }

        public FileHomepage AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false, int Timeout = 5)
        {
            string alertText = "";
            alertText = WebDriver.HandleDialogMessage(switchBackToFastWindow: SwitchToWindow, clickAcceptButton: true, timeout: Timeout); 
            //waits for the alert to show up, clicks Accept button, switches back to FAST window and returns the text of the alert message.
            if (CompareWith != null)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
            }
            
            return this;
        }

        public Dictionary<string, string> GetSelrDtlsOnFhp
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Seller1Type", Seller1Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Seller1FirstName", Seller1FirstName.FAGetValue().Trim());
                AllDetails.Add("Seller1LastName", Seller1LastName.FAGetValue().Trim());
                AllDetails.Add("Seller2Type", Seller2Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Seller2FirstName", Seller2FirstName.FAGetValue().Trim());
                AllDetails.Add("Seller2SpouseFirstName", Seller2SpouseFirstName.FAGetValue().Trim());
                AllDetails.Add("Seller2SpouseLastName", Seller2SpouseLastName.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetByrDtlsOnFhp
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Buyer1Type", Buyer1Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Buyer1FirstName", Buyer1FirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer1LastName", Buyer1LastName.FAGetValue().Trim());
                AllDetails.Add("Buyer2Type", Buyer2Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Buyer2FirstName", Buyer2FirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer2SpouseFirstName", Buyer2SpouseFirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer2SpouseLastName", Buyer2SpouseLastName.FAGetValue().Trim());                
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetPropDetails
        {
            get
            {
                Dictionary<string, string> PropAdrDetails = new Dictionary<string, string>();
                PropAdrDetails.Add("PropertyName", PropertyName.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyType", PropertyType.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyEstateType", PropertyEstateType.FAGetSelectedItem());                 
                PropAdrDetails.Add("PropertyLotName", PropertyLotName.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBlock", PropertyBlock.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyUnit", PropertyUnit.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyTRact", PropertyTRact.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyFee", PropertyFee.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBuilding", PropertyBuilding.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBook", PropertyBook.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPage", PropertyPage.FAGetValue().Trim());
                PropAdrDetails.Add("PropertySection", PropertySection.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxAPN1", PropertyPropTaxAPN1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxAPN2", PropertyPropTaxAPN2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxYear1", PropertyPropTaxYear1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxYear2", PropertyPropTaxYear2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine1", PropertyBookAddressLine1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine2", PropertyBookAddressLine2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine3", PropertyBookAddressLine3.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine4", PropertyBookAddressLine4.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyAddressBookCity", PropertyAddressBookCity.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyCity", PropertyAddressBookCity.FAGetValue());
                PropAdrDetails.Add("PropertyState", PropertyState.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyCountry", PropertyCountry.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyZip", PropertyZip.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyCounty", PropertyCounty.FAGetValue().Trim());
                PropAdrDetails.Add("TransactionType", TransactionType.FAGetSelectedItem().Trim());
                PropAdrDetails.Add("TermsDatesPrice", TermsDatesPrice.FAGetValue().Trim());
                return PropAdrDetails;
            }

        }

        public Dictionary<string, string> GetAssociateBusinessPartyDtlsOnFhp
        {
            get
            {
                Dictionary<string, string> AssociateBusinessPartyDtls = new Dictionary<string, string>();
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyName", AssociateBusinessPartyName.FAGetValue().Trim());
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyBusPhone", AssociateBusinessPartyBusPhone.FAGetValue().Trim());
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyBusFax", AssociateBusinessPartyBusFax.FAGetValue().Trim());
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyCellPhone", AssociateBusinessPartyCellPhone.FAGetValue().Trim());
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyPager", AssociateBusinessPartyPager.FAGetValue().Trim());
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyEmailAddress", AssociateBusinessPartyEmailAddress.FAGetValue().Trim());
                AssociateBusinessPartyDtls.Add("AssociateBusinessPartyAttention", AssociateBusinessPartyAttention.FAGetSelectedItem().Trim());
                return AssociateBusinessPartyDtls;
            }
        }

        public Dictionary<string, string> GetBusinessPartyDtlsOnFhp
        {
            get
            {
                Dictionary<string, string> BusinessPartyDtls = new Dictionary<string, string>();
                BusinessPartyDtls.Add("BusinessPartyIDCodeField", BusinessPartyIDCodeField.FAGetText().Trim());
                BusinessPartyDtls.Add("BusinessPartyNameField", BusinessPartyNameField.FAGetText().Trim());
                BusinessPartyDtls.Add("BusinessPartyNameField2", BusinessPartyNameField2.FAGetText().Trim());
                BusinessPartyDtls.Add("BusSrceAdd1", BusSrceAdd1.FAGetText().Trim());
                BusinessPartyDtls.Add("BusSrceAdd2", BusSrceAdd2.FAGetText().Trim());
                BusinessPartyDtls.Add("BusSrceAdd3", BusSrceAdd3.FAGetText().Trim());
                return BusinessPartyDtls;
            }
        }

        public FileHomepage Open()
        {
            FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage");
            this.WaitForScreenToLoad();
            return this;
        }

        public FileHomepage SelectTransType(int ItemIndex)
        {
            BrowserWindow bwin = new BrowserWindow();
            bwin.SearchProperties["ClassName"] = "IEFrame";
            HtmlDocument sDoc = new HtmlDocument(bwin);
            sDoc.SearchProperties[HtmlDocument.PropertyNames.Title] = "File Homepage";

            HtmlComboBox cmb = new HtmlComboBox(sDoc);
            cmb.SearchProperties.Add("Id", "ddlTransType", PropertyExpressionOperator.EqualTo);
            Mouse.Click(cmb);            
            Mouse.Click(cmb.Items[ItemIndex]);
            return this;
        }

        public FileHomepage FindBusPartyGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }

            BusinessPartyGABcode.FASetText(GABCode);
            BusinessPartyName.FASetText(GABName);
            BussinessPartyFind.FAClick();
            return this;
        }

        public FileHomepage FindDirectedByGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }

            DirectedByGABcode.FASetText(GABCode);
            DirectedByName.FASetText(GABName);
            DirectedByFind.FAClick();
            return this;
        }

        public FileHomepage FindAssocBusPartyGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }
            AssociateBusinessPartyGABcode.FASetText(GABCode);
            AssociateBusinessPartyName.FASetText(GABName);
            AssociateBusinessPartyFind.FAClick();
            return this;
        }

        public FileHomepage RemoveAllFileProductsBut(string ProductName)
        {
            Reports.TestStep = "Navigate to File Homepage Screen and add file product " + ProductName;
            FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").SwitchToContentFrame();

            int SkipRow = FastDriver.FileHomepage.ProductsTable.PerformTableAction(2, ProductName, 1, TableAction.GetCell).CurrentRow;
            int RowCount =  FastDriver.FileHomepage.ProductsTable.GetRowCount();
            for (int rowCounter = 1; rowCounter < RowCount; rowCounter++) {
                if (rowCounter != SkipRow) { 
                    this.ProductCheckbox(rowCounter-1).FASetCheckbox(false);
                }
            }
            FastDriver.BottomFrame.Done();
            this.WaitForScreenToLoad();
            return this;
        }

        /// <summary>
        /// This function clicks on the change oo button of the file homepage.
        /// </summary>
        public void ClickChangeOO()
        {
            Reports.TestStep = "Click on the Change OO button.";
            this.ChangeOO.FAClick();
            FastDriver.ChangeOwningOfficeRemoveServiceType.WaitForScreenToLoad();
        }
    }
}
