using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileNotes : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "FAFDDNotesType")]
        public IWebElement NotesType { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrn")]
        public IWebElement Preview { get; set; }

        //Osama
        [FindsBy(How = How.Id, Using = "gridFNotesComment_0_NoteC")]
        public IWebElement TaskComment1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Append { get; set; }

        [FindsBy(How = How.LinkText, Using = "create a new note")]
        public IWebElement createanewnote { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes")]
        public IWebElement Table { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement NewNote { get; set; }

        [FindsBy(How = How.LinkText, Using = "Append a new note")]
        public IWebElement Appendanewnote { get; set; }

        [FindsBy(How = How.LinkText, Using = "Creating a new note from QFE")]
        public IWebElement newnoteQFE { get; set; }

        [FindsBy(How = How.LinkText, Using = "gridFNotesComment_1_ProcessTaskC")]
        public IWebElement ProcessName { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotesComment_0_imgIdC")]
        public IWebElement Image { get; set; }

        [FindsBy(How = How.LinkText, Using = "Published Task Comment")]
        public IWebElement PublishedTaskComment { get; set; }

        [FindsBy(How = How.LinkText, Using = "Non-Published Task Comment")]
        public IWebElement Non_PublishedTaskComment { get; set; }

        [FindsBy(How = How.LinkText, Using = "New Spelling note")]
        public IWebElement NewSpellingNote { get; set; }

        [FindsBy(How = How.LinkText, Using = "Reg Spelling notezz")]
        public IWebElement RegSpellingnote { get; set; }

        [FindsBy(How = How.LinkText, Using = "Note For FMUC0010 Review.")]
        public IWebElement NoteForFMUC0010Review { get; set; }

        [FindsBy(How = How.LinkText, Using = "Comment For AXE Script.")]
        public IWebElement CommentForAXEScript { get; set; }

        [FindsBy(How = How.LinkText, Using = "Internal Comment For AXE Script.")]
        public IWebElement InternalComment { get; set; }

        [FindsBy(How = How.LinkText, Using = "create a new note")]
        public IWebElement CreatePreview { get; set; }

        [FindsBy(How = How.LinkText, Using = "Append a new note")]
        public IWebElement AppendPreview { get; set; }

        [FindsBy(How = How.Id, Using = "gridPrnPreview_0_NoteType")]
        public IWebElement TitlePreview { get; set; }

        [FindsBy(How = How.Id, Using = "gridPrnPreview_0_Faflabel3")]
        public IWebElement ByPreview { get; set; }

        [FindsBy(How = How.LinkText, Using = "Enter a new note")]
        public IWebElement Enteranewnote { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotesComment_0_ProcessTaskC")]
        public IWebElement TaskComment { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_1_Note")]
        public IWebElement TaskNotes { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_0_Note")]
        public IWebElement FileNotesGrid { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_1_Note")]
        public IWebElement FileNotesGrid1 { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_1")]
        public IWebElement FileNotesGridRow1 { get; set; }

        [FindsBy(How = How.Id, Using = "gridFNotes_0")]
        public IWebElement FileNotesGridRow0 { get; set; }

        [FindsBy(How = How.Id, Using = "gridPrnPreview_0_Faflabel4")]
        public IWebElement NotePreviewGrid1 { get; set; }

        #endregion

        public FileNotes WaitForScreenToLoad(IWebElement element = null)
        {
            try
            {
                Playback.Wait(5000);
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? Table);
             
            }
            catch (Exception e) // try again after wait for 1 second
            {
                Playback.Wait(1000);
                Report.UpdateLog(FastDriver.FileNotes.Table, "Failed to wait for table, second attemp", e.Message, e.InnerException.ToString(), () =>
                {
                    FastDriver.FileNotes.SwitchToContentFrame();
                    FastDriver.FileNotes.WaitCreation(element ?? Table);
                });
            }
            return this;
        }
        public FileNotes Open()
        {
            FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes");
            return WaitForScreenToLoad();
        }

    }
}
