using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileNotesEditor : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboNoteTypes")]
        public IWebElement NoteType { get; set; }

        [FindsBy(How = How.Id, Using = "FontName")]
        public IWebElement FontName { get; set; }

        [FindsBy(How = How.Id, Using = "FontSize")]
        public IWebElement FontSize { get; set; }

        [FindsBy(How = How.Id, Using = "textDetail")]
        public IWebElement Detail { get; set; }

        //[FindsBy(How = How.Id, Using = "CHECKSPELL")]
        [FindsBy(How = How.XPath, Using = "//div[@id='CHECKSPELL']/table/tbody/tr/td")]
        public IWebElement CheckSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "tbContentElement")]
        public IWebElement txtNote { get; set; }

        #endregion
        
        public FileNotesEditor AddNote(string note)
        {
            
            this.SwitchToContentFrame();
            this.WaitCreation(txtNote);
            this.txtNote.Click();
            this.txtNote.SendKeys(note);    // for some reasons FASetText() does not work.
            
            return this;
        }

        public FileNotesEditor AddNote(NewFileNoteParameters note)
        {
            
            this.SwitchToContentFrame();
            this.WaitCreation(txtNote);

            NoteType.FASelectItem(note.NoteType);
            FontSize.FASelectItem(note.FontSize);
            FontName.FASelectItem(note.FontName);
            txtNote.Click();
            txtNote.SendKeys(note.NoteText); // for some reasons FASetText() does not work.
            //txtNote.FASetText(note.NoteText);

            return this;
        }

        public FileNotesEditor WaitForScreeToLoad(IWebElement element = null)
        {

            Playback.Wait(5000);
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? NoteType);
            return this;
        }

    }
}
