using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Reflection;

namespace FASTSelenium.PageObjects.IIS
{
	public class FileNumberSearchSelectionDlg : PageObject
	{
        int waitTime = Convert.ToInt32(AutoConfig.WaitTime);
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "33861")]
		public IWebElement SelectFileNo { get; set; }

		[FindsBy(How = How.Id, Using = "dgSearchResults")]
		public IWebElement SearchResults { get; set; }

        [FindsBy(How = How.Id, Using = "lblResultCount")]
        public IWebElement FileCount { get; set; }


		#endregion

        public FileNumberSearchSelectionDlg WaitForScreenToLoad(int timeout = 60)
        {
            WebDriver.WaitForWindowAndSwitch("File Number Search Selection", true, timeout);
            this.SwitchToDialogContentFrame();

            return this;
        }

        public int SelectTheSpecifiedFileInTheDialog(string fileNumber, bool doubleClick=false)
        {
            int returnValue = -1;
            FastDriver.FileNumberSearchSelectionDlg.WaitForScreenToLoad();
            FastDriver.FileNumberSearchSelectionDlg.SwitchToDialogContentFrame();
            if(!doubleClick)
                returnValue = FastDriver.FileNumberSearchSelectionDlg.SearchResults.PerformTableAction(1, fileNumber, 1, TableAction.Click).CurrentRow;
            if(doubleClick)
            {
                FastDriver.FileNumberSearchSelectionDlg.SearchResults.PerformTableAction(1, fileNumber, 1, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                this.SwitchToContentFrame();
            }
            return returnValue;
        }

        public void OpenNextFileFromTheRow(int rowIndex,bool isExchange = false)
        {
            FastDriver.FileNumberSearchSelectionDlg.WaitForScreenToLoad();
            FastDriver.FileNumberSearchSelectionDlg.SwitchToDialogContentFrame();

            FastDriver.FileNumberSearchSelectionDlg.SearchResults.PerformTableAction(rowIndex + 1, 1, TableAction.Click);
            string fileNoToOpen = FastDriver.FileNumberSearchSelectionDlg.SearchResults.PerformTableAction(rowIndex + 1, 1, TableAction.GetText).Message;
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            FastDriver.ExchangeFileEntry.SwitchToContentFrame();
            if(isExchange)
                Support.AreEqual(fileNoToOpen, FastDriver.ExchangeFileEntry.FileNo.FAGetValue());
            else
                Support.AreEqual(fileNoToOpen, FastDriver.FileHomepage.GetFileNumber());
        }

        public void CheckTheFileCountIsNotBelowTheSpecifiedValue(int refFileCount, int timeOutValue=20)
        {
            WaitForScreenToLoad(Convert.ToInt32(AutoConfig.WaitTime));
            try
            {
                FastDriver.WebDriver.HandleDialogMessage(false, true, timeOutValue);
                var actualFileCount = Convert.ToInt32(FileCount.FAGetText());
                if(actualFileCount >= refFileCount)
                {
                    Reports.StatusUpdate("Actual file count is:"+actualFileCount+ "Reference count is :"+refFileCount, true);
                    if (!FastDriver.FileSearch.Has100RecordsFoundAlertAppeared && actualFileCount >= 100)
                    {
                        Reports.StatusUpdate("Number of records found are >= 100. But the required alert did not appear !", false);
                    }
                    return;
                }
                Reports.StatusUpdate("Actual file count is:" + actualFileCount + "Reference count is :" + refFileCount, false);
            }

            catch(Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while invoking :"+MethodBase.GetCurrentMethod().Name+"\r\n"+" Details:"+ex.Message, false);
            }

        }

	}
}
