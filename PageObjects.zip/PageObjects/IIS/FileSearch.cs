using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Interactions;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class FileSearch : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnView")]
		public IWebElement View { get; set; }

		[FindsBy(How = How.Id, Using = "btnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "btnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "rblSearchType_0")]
		public IWebElement _FileSearch { get; set; }

		[FindsBy(How = How.Id, Using = "rblSearchType_1")]
		public IWebElement PendingOrderSearch { get; set; }

		[FindsBy(How = How.Id, Using = "txtPrincipals")]
		public IWebElement Principals { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_0")]
		public IWebElement Buyer { get; set; }

        [FindsBy(How = How.Id, Using = "rblExchgPrinPal1_0")]
		public IWebElement BuyerExchange { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_1")]
		public IWebElement Seller { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_2")]
		public IWebElement Debtor { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_3")]
		public IWebElement AnyPrincipals1 { get; set; }

        [FindsBy(How = How.Id, Using = "rblExchgPrinPal1_4")]
		public IWebElement AnyPrincipals1Exchange { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_0")]
		public IWebElement IndividualHusband { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_1")]
		public IWebElement TrustEstate { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_2")]
		public IWebElement BussinessEntity { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_3")]
		public IWebElement AnyPrincipals2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtOtherParties")]
		public IWebElement OtherParties { get; set; }

		[FindsBy(How = How.Id, Using = "ddRoleType")]
		public IWebElement RoleType { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropAddress")]
		public IWebElement PropertyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropName")]
		public IWebElement PropertyName { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropLot")]
		public IWebElement PropertyLot { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropTract")]
		public IWebElement PropertyTract { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropParcel")]
		public IWebElement PropertyParcel { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropSubDiv")]
		public IWebElement PropertySubDiv { get; set; }

		[FindsBy(How = How.Id, Using = "txtAPNTaxNo")]
		public IWebElement APNTaxNo { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "txtCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "comboRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "txtNumbers")]
		public IWebElement Numbers { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_0")]
		public IWebElement FileNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_1")]
		public IWebElement PrincipalsReg { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_2")]
		public IWebElement ExtNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_3")]
		public IWebElement EntityRef { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_4")]
		public IWebElement InvoiceNo { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_5")]
		public IWebElement BussinessSource { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_6")]
		public IWebElement OutsideRef { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_7")]
		public IWebElement AnyNumbers { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_0")]
		public IWebElement Open { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_3")]
		public IWebElement Closed { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_1")]
		public IWebElement OpeninError { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_4")]
		public IWebElement AnyStatus { get; set; }

        [FindsBy(How = How.Id, Using = "rblExchgStatus_4")]
		public IWebElement AnyStatusExchg { get; set; }

		[FindsBy(How = How.Id, Using = "rblStatus_2")]
		public IWebElement Cancelled { get; set; }

		[FindsBy(How = How.Id, Using = "txtDateFrom1")]
		public IWebElement DateFrom1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtDateTo1")]
		public IWebElement DateTo1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtMonth")]
		public IWebElement Month { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_0")]
		public IWebElement OpenDate { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_2")]
		public IWebElement SettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_1")]
		public IWebElement CancelledDate { get; set; }

		[FindsBy(How = How.Id, Using = "rblDates_3")]
		public IWebElement EstSettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmpName")]
		public IWebElement EmployeeName { get; set; }

		[FindsBy(How = How.Id, Using = "ddEmpType")]
		public IWebElement EmployeeType { get; set; }

        [FindsBy(How = How.Id, Using = "ddExchgEmpType")]
        public IWebElement EmployeeTypeExchg { get; set; }

        [FindsBy(How = How.Id, Using = "dgSearchResults")]
		public IWebElement SearchResultTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridExchgResult")]
		public IWebElement SearchResultTableExchange { get; set; }

		[FindsBy(How = How.Id, Using = "dgSearchResults_0_labelStatus")]
		public IWebElement FileStatus { get; set; }

		[FindsBy(How = How.Id, Using = "txtEdit")]
		public IWebElement MRUFileSearch { get; set; }

		[FindsBy(How = How.Id, Using = "lblNote")]
		public IWebElement Note { get; set; }

		[FindsBy(How = How.Id, Using = "rblNumbers_8")]
		public IWebElement PolicyNumber { get; set; }

		[FindsBy(How = How.Id, Using = "lblfilenumber")]
		public IWebElement Number { get; set; }

        [FindsBy(How = How.Id, Using = "btnskipsearch")]
        public IWebElement SkipSearch { get; set; }

		#endregion

        public bool Has100RecordsFoundAlertAppeared { get; set; }

        public FileSearch WaitForScreenToLoad(IWebElement element = null, int timeout = 60)
        {
            //element = Principals;
            
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? SearchResultTable);
            }
            catch(Exception e)
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                this.SwitchToContentFrame();
            }

            return this;
        }

        public bool WaitForEnabled(IWebElement element = null)
        {
            //element = Principals;
            try
            {
                this.SwitchToContentFrame();
                element = element ?? FindNow;
                this.WaitCreation(element ?? FindNow);
                this.Wait.Until(dr =>
                {
                        return element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }


        public bool WaitForDisabled(IWebElement element = null)
        {
            //element = Principals;
            try
            {
                this.SwitchToContentFrame();
                element = element ?? FindNow;
                this.WaitCreation(element ?? FindNow);
                this.Wait.Until(dr =>
                {
                    return !element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }


        public void VerifyTheStateOfFields()
        {
            this.SwitchToContentFrame();
            Support.AreEqual(string.Empty, FastDriver.FileSearch.Principals.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.OtherParties.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.RoleType.FAGetSelectedItem());

            Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyAddress.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyName.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyLot.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyTract.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertyParcel.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.PropertySubDiv.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.APNTaxNo.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.State.FAGetSelectedItem());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.County.FAGetValue());
            Support.AreEqual("USA", FastDriver.FileSearch.Country.FAGetSelectedItem());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.Numbers.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.DateFrom1.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.DateTo1.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.EmployeeName.FAGetValue());
            Support.AreEqual(string.Empty, FastDriver.FileSearch.EmployeeType.FAGetSelectedItem());
            FastDriver.FileSearch.Principals.FASetText("1");
            FastDriver.FileSearch.Principals.FASetText(string.Empty);
            Support.AreEqual("True", FastDriver.FileSearch.FindNow.Enabled.ToString());
            Support.AreEqual("False", FastDriver.FileSearch.View.Enabled.ToString());
            Support.AreEqual("True", FastDriver.FileSearch.NewSearch.Enabled.ToString());
            Support.AreEqual("False", FastDriver.FileSearch.Select.Enabled.ToString());
        }

        public void SetFileNumber(string fileNumber="", bool IsNonExistingFile=false)
        {
            this.SwitchToContentFrame();
            if(IsNonExistingFile)
                FastDriver.FileSearch.Numbers.FASetText((Convert.ToInt32(fileNumber) + 10000).ToString());
            if (!IsNonExistingFile)
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);

        }
        
        public void VerifyIfNoMatchFoundMessageAppears()
        {
            //this.SwitchToContentFrame();
            Support.AreEqual("No match found.", FastDriver.WebDriver.HandleDialogMessage(true,true,60));
            
        }

        //public void SearchAndVerifyIfTheAppropriateFileIsOpen(string fileNumber)
        public void PerformExactSearchAndVerifyIfTheFileIsOpened(string fileNumber)
        {
            bool IsNumberTyped = false;   
            this.SwitchToContentFrame();
            FastDriver.FileSearch.Country.FASelectItem("USA");
            Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
            this.WaitForScreenToLoad(Numbers);
            this.SwitchToContentFrame();            
            if(CanTypeInTextBox(Numbers))
            {
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);
                RetryFileSearch();
                Support.AreEqual(fileNumber, FastDriver.FileHomepage.GetFileNumber());
                IsNumberTyped = true;
            }
            if(!IsNumberTyped)
            {
                Reports.StatusUpdate("Could not interact with Numbers Text Box !", false);
            }
        }

        public void PerformExactSearchAndVerifyIfTheFileIsOpenedExchange(string fileNumber)
        {
            bool IsNumberTyped = false;
            this.SwitchToContentFrame();
            FastDriver.FileSearch.Country.FASelectItem("USA");
            Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
            this.WaitForScreenToLoad(Numbers);
            this.SwitchToContentFrame();
            if (CanTypeInTextBox(Numbers))
            {
                FastDriver.FileSearch.Numbers.FASetText(fileNumber);
                RetryFileSearch();
                FastDriver.ExchangeFileEntry.SwitchToContentFrame();
                FastDriver.ExchangeFileEntry.WaitCreation(FastDriver.ExchangeFileEntry.TransactionType);
                Support.AreEqual(fileNumber, FastDriver.ExchangeFileEntry.FileNo.FAGetValue());
                IsNumberTyped = true;
            }
            if (!IsNumberTyped)
            {
                Reports.StatusUpdate("Could not interact with Numbers Text Box !", false);
            }
        }

        public bool CanTypeInTextBox(IWebElement element)
        {
            bool result = false;
            try
            {
                WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(60));
                wait.Until(d =>
                {
                    try
                    {
                        element.SendKeys("");
                        result = true;
                        return true;
                    }
                    catch (StaleElementReferenceException)
                    {
                       return false;
                    }
                    catch (NoSuchElementException)
                    {
                        return false;
                    }
                });
                return result;
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        public void PerformExactSearchOfInvoiceNoAndVerifyTheFileIsOpened(string fileNumber)
        {
            bool IsFileSearchSuccess = false;
            this.SwitchToContentFrame();
            this.WaitForScreenToLoad(Country);
            FastDriver.FileSearch.Country.FASelectItem("USA");
            Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
            this.WaitForScreenToLoad(Numbers);
            InvoiceNo.FAClick();
            FastDriver.FileSearch.Numbers.FASetText(fileNumber.Trim());
            //FastDriver.FileSearch.FindNow.FAClick();
            if (RetryFileSearch())
            {
                FastDriver.InvoiceFees.WaitForScreenToLoad();
                string actualInvoiceNo = FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                Reports.UpdateDebugLog("Invoice No on Invocie Fees", "TableCell/Span/Span", "File Search ==> " + MethodBase.GetCurrentMethod().Name, "Text", fileNumber, actualInvoiceNo, Reports.Result(fileNumber == actualInvoiceNo), "");
                IsFileSearchSuccess = true;
            }
            if (!IsFileSearchSuccess)
            {
                Reports.StatusUpdate("The Invoice No. could not be opened!", false);
                return;
            }
        }

        public void SetValues(bool isExchange = false)
        {
            this.SwitchToContentFrame();
            Country.FASelectItem("USA");
            Playback.Wait(3000); // to avoid throwing exception due to screen refresh multiple times upon selecting an option from the Country dropdown.
            this.WaitForScreenToLoad(Numbers);
            this.SwitchToContentFrame();

            Principals.FASetText("Principals");
            OtherParties.FASetText("OtherParties");
            RoleType.FASelectItemByIndex(1);
            PropertyAddress.FASetText("PropertyAddress");
            PropertyName.FASetText("J305");
            PropertyLot.FASetText("Lot1");
            PropertyTract.FASetText("Tract1");
            PropertyParcel.FASetText("PropertyParcel");
            PropertySubDiv.FASetText("PropertySubDiv");
            APNTaxNo.FASetText("APNTaxNo1");
            State.FASelectItemByIndex(3);
            County.FASetText("County");
            Numbers.FASetText("112233445566");
            DateFrom1.FASetText(@"06-30-2015");
            DateTo1.FASetText(@"07-30-2015");
            EmployeeName.FASetText("QA07");
            if(isExchange)
                EmployeeTypeExchg.FASelectItemByIndex(2);
            else
                EmployeeType.FASelectItemByIndex(2);
        }

        public void HandleMoreThan100RecordsFoundAlert(int timeOutValue=10)
        {
            string alertText = FastDriver.WebDriver.HandleDialogMessage(timeout:timeOutValue);
            if (alertText != "No dialog present" && alertText != "")
            {
                Support.AreEqual("More than 100 records were found. The system has displayed a maximum of 100 records.", FastDriver.WebDriver.HandleDialogMessage());
                Has100RecordsFoundAlertAppeared = true;
            }

            if (alertText.Contains("No dialog present"))
            {
                Reports.StatusUpdate("'More than 100 records found' alert hasn't appeared !", true);
                Has100RecordsFoundAlertAppeared = false;
            }
        }


        public void VerifyIfTheFileCreationDateIsWithinTheMonthCriterion(int month,bool isExchange = false)
        {
            DateTime today = DateTime.Today;
            string calculatedLeastDateValue = today.AddMonths(-month).ToString("MM/dd/yyyy");
            string actualLeastDateValue = null;
            if(!isExchange) actualLeastDateValue = SearchResultTable.PerformTableAction(SearchResultTable.GetRowCount(), 6, TableAction.GetText).Message;
            else actualLeastDateValue = SearchResultTableExchange.PerformTableAction(100, 5, TableAction.GetText).Message;

            Reports.UpdateDebugLog("VerifyIfTheFileCreationDateIsWithinTheMonthCriterion", "", "", "", calculatedLeastDateValue, actualLeastDateValue, Reports.Result(Convert.ToDateTime(actualLeastDateValue) >= Convert.ToDateTime(calculatedLeastDateValue)),"");
        }

        public void VerifyMoreThan100RecordsFoundNote()
        {
            //if(Note.FAGetText() != "Note: More than 100 records were found. The system has displayed a maximum of 100 records.")
            //{

            //}
            Support.AreEqual("Note: More than 100 records were found. The system has displayed a maximum of 100 records.", Note.FAGetText());
        }

        public void VerifyAllItemsInRoleTypeDropdown(List<string> userDefinedRoleTypes)
        {
            if (userDefinedRoleTypes == null)
            {
                return;
            }
            //string[] actualRoleTypesArray = RoleType.FAGetAllOptionsFromSelectList().Split('|');
            //List<string> actualRoles = new List<string>(actualRoleTypesArray);
            List<string> actualRoles = RoleType.FAGetDropdownOptions().ToListString();
            bool matchFound = false;
            //string userValue = "",actualValue="";

            userDefinedRoleTypes.ForEach(userItem =>
            {
                matchFound = false;
                actualRoles.ForEach(actualItem =>
                {
                    if (userItem.Equals(actualItem) || (userItem==actualItem))
                    {
                        matchFound = true;
                        Reports.UpdateDebugLog("Role Type", "", "Compare Dropdown Items", "", userItem, actualItem, Reports.Result(userItem == actualItem), "");
                    }
                });
                if (!matchFound)
                {
                    actualRoles.ForEach(actualItem =>
                    {
                        var charActual = actualItem.ToCharArray();
                        var charUserItems = userItem.ToCharArray();
                        bool tmp = charUserItems.SequenceEqual(charActual);
                        if (charUserItems.SequenceEqual(charActual))
                        {
                            Reports.UpdateDebugLog("Role Type", "", "Compare Dropdown Items", "", userItem, actualItem, Reports.Result(true), "");
                            matchFound = true;
                        }
                    });

                    if (!matchFound)
                    {
                        Reports.UpdateDebugLog("Role Type", "", "Compare Dropdown Items", "", userItem, "", Reports.Result(false), "");
                    }
                }
            });
        }

        

        public FileSearch WaitForFileSearchScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(FindNow);

            return this;
        }

        

        public FileSearch WaitForWindowToLoad(IWebElement element = null, int timeout = 10)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FindNow, timeout);

            return this;
        }

        public FileSearch SendControlShift(string key)
        {
                Keyboard.PressModifierKeys(System.Windows.Input.ModifierKeys.Control); 
                Keyboard.PressModifierKeys(System.Windows.Input.ModifierKeys.Shift);
                Keyboard.SendKeys(key);
                Playback.Wait(500); 
                Keyboard.ReleaseModifierKeys(System.Windows.Input.ModifierKeys.Control); 
                Keyboard.ReleaseModifierKeys(System.Windows.Input.ModifierKeys.Shift); 

            return this;
        }

        public FileSearch NavigateTo()
        {
            FastDriver.LeftNavigation.Navigate<FileSearch>("Home>Order Entry>File Search");
            this.WaitForFileSearchScreenToLoad();
            return this;
        }


        public bool RetryFileSearch(string fileNumber = "", IWebElement element = null)
        {
            int retryCount = 1;
            string alertMessage = "";
            bool result = false;
            while (retryCount <= 15)
            {
                if (retryCount == 1)
                {
                    Reports.TestStep = "Click Find Now button.";
                }
                try
                {
                    FindNow.FAClick();
                }
                catch(Exception)
                {
                    Playback.Wait(2000);
                    FindNow.FAClick();
                }
                if (retryCount == 1)
                {
                    Reports.TestStep = "Handle 'No match found' alert, if appears.";
                }
                alertMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 30);

                if (alertMessage.Equals("No match found."))
                {
                    System.Threading.Thread.Sleep(10000);
                    Reports.StatusUpdate("Retrying for file search after waiting for 10 seconds :" + retryCount++, true);
                    this.SwitchToContentFrame();
                    continue;
                }

                if (!alertMessage.Equals("No match found."))
                {
                    FastDriver.FileSearch.SwitchToContentFrame();
                    if (element != null)
                    {
                        if (FastDriver.FileSearch.SearchResultTable.IsVisible(60000))
                        {
                            if (!string.IsNullOrEmpty(fileNumber) && !FastDriver.FileSearch.SearchResultTable.FAGetText().Contains(fileNumber))
                            {
                                System.Threading.Thread.Sleep(10000);
                                Reports.StatusUpdate("Retrying search from the Search Results Grid after waiting for 10 seconds :" + retryCount++, true);
                                this.SwitchToContentFrame();
                                continue;
                            }
                        }
                    }
                    result = true;
                    break;
                }
            }
            return result;
        }

        public FileSearch SearchFileNumber(string fileNumber, FileSearchType searchType)
        {
            WaitForFileSearchScreenToLoad();
            Numbers.FASetText(fileNumber);
            GetFileSearchType(searchType).FAClick();
            FindNow.FAClick();
            return this;
        }

        private IWebElement GetFileSearchType(FileSearchType searchType)
        {
            switch(searchType)
            {
                case FileSearchType.FileNo:
                    return FileNo;
                case FileSearchType.ExternalNo:
                    return ExtNo;
                case FileSearchType.InvoiceNo:
                    return InvoiceNo;
                case FileSearchType.OutsideRefNo:
                    return OutsideRef;
                case FileSearchType.PolicyNo:
                    return PrincipalsReg;
                case FileSearchType.EntityRefNo:
                    return EntityRef;
                case FileSearchType.BusSourceRefNo:
                    return BussinessSource;
                case FileSearchType.Any:
                    return AnyNumbers;
                default:
                    throw new ArgumentException("No such option exists.");

            }
        }
	}
}
