using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class FileSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "Basic Details")]
		public IWebElement BasicDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Business Parties")]
		public IWebElement BusinessParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Loan/Disbursement")]
		public IWebElement LoanDisbursement { get; set; }

		[FindsBy(How = How.Id, Using = "btn")]
		public IWebElement Print { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPList")]
		public IWebElement BusinesspartiesTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel9")]
		public IWebElement PropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel11")]
		public IWebElement TranType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel16")]
		public IWebElement ServiceType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel12")]
		public IWebElement BuSegment { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel57")]
		public IWebElement PropertyAdd { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_idLPSGrid_0_labelLenderName")]
		public IWebElement LenderName { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel59")]
		public IWebElement Loanamt { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblByrSlrAmt")]
		public IWebElement BuyerSellerAmounts { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_idLPSGrid")]
		public IWebElement NewLoanRecapTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Faflabel76")]
		public IWebElement ExternalNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Faflabel68")]
        public IWebElement ContractAccDate { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel78")]
		public IWebElement ContractDate { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel77")]
		public IWebElement EarnestMoney { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel75")]
		public IWebElement HeldBy { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel6")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel15")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel7")]
		public IWebElement APN1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel10")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel74")]
		public IWebElement OrderSource { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel13")]
		public IWebElement LoanAmount { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel14")]
		public IWebElement SalesPrice { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel79")]
		public IWebElement EstateType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel17")]
		public IWebElement OpeningDate { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel18")]
		public IWebElement EstSettlemetDate { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel20")]
		public IWebElement BusinessSourceName { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel49")]
		public IWebElement BusinessSourceAddress1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel50")]
		public IWebElement BusinessSourceAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel52")]
		public IWebElement BusinessSourceAddress3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel53")]
		public IWebElement BusinessSourceCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel55")]
		public IWebElement BusinessSourceBusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel54")]
		public IWebElement BusinessSourceFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel56")]
		public IWebElement BusinessSourceEmail { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel5")]
		public IWebElement EscrowOOAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel4")]
		public IWebElement EscrowOOCode { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel1")]
		public IWebElement EscrowOO { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel21")]
		public IWebElement EscrowOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel24")]
		public IWebElement EscrowAssistant { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel3")]
		public IWebElement TitleOO { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel27")]
		public IWebElement TitleOOCode { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel28")]
		public IWebElement TitleOOAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel29")]
		public IWebElement TitleOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel32")]
		public IWebElement TitleAssistant { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ProductsExpandIcon { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ShortLegalDescExpandIcon { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement EscrowProductionOfficeExpandIcon { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement TitleProductionOfficeExpandIcon { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel36")]
		public IWebElement Unit { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel37")]
		public IWebElement Lot { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel38")]
		public IWebElement Tract { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel41")]
		public IWebElement Block { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel44")]
		public IWebElement Parcel { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel47")]
		public IWebElement Range { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel46")]
		public IWebElement Towns { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel43")]
		public IWebElement Building { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel40")]
		public IWebElement Page { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel48")]
		public IWebElement Subdivision { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel45")]
		public IWebElement Sec { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel42")]
		public IWebElement Fees { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel39")]
		public IWebElement Book { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid1")]
		public IWebElement TitleProductionOfficeTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid11")]
		public IWebElement EscrowProductionOfficeTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPartiesList")]
		public IWebElement ProductsTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel60")]
		public IWebElement SalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel69")]
		public IWebElement SalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid2")]
		public IWebElement PayOffLoanTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPList_1_lblFax")]
		public IWebElement BusPartyFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPList_1_lblPhone")]
		public IWebElement BusPartyBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPList_1_lblAddress")]
		public IWebElement BusPartyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblB_FHAC")]
		public IWebElement BuyerFundsHeld { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblS_FHAC")]
		public IWebElement SellerFundsHeld { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblB_FundsDue")]
		public IWebElement BuyerFundsDue { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblS_FundsDue")]
		public IWebElement SellerFundsDue { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblB_NetCheck")]
		public IWebElement BuyerNetCheck { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_lblS_NetCheck")]
		public IWebElement SellerNetCheck { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel58")]
		public IWebElement NetTotalDeposits { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel59")]
		public IWebElement NetTotalDisbursements { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPList_2_lblPhone")]
		public IWebElement BusPhone2 { get; set; }

        [FindsBy(How = How.Id, Using = "btnFBS")]
        public IWebElement PrintBtn { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_lblBuyer")]
        public IWebElement BuyerSellerLabel { get; set; }

        [FindsBy(How = How.Id, Using = "btnFBP")]
        public IWebElement PrintFBP { get; set; }


        [FindsBy(How = How.Id, Using = "btnFBS")]
        public IWebElement PrintLoanDisbursement { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid2_0_Faflabel64")]
        public IWebElement PayOffLoanPrincipalBalance { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid2_0_Faflabel65")]
        public IWebElement PayOffLoanTotalCharges { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid2_0_Faflabel66")]
        public IWebElement PayOffLoanPayoffAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Fafdatagrid2_0_Faflabel72")]
        public IWebElement PayOffLoanCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Faflabel200")]
        public IWebElement TittleOO_UWEmployee { get; set; }
		#endregion

        public FileSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>File Summary");
            this.WaitForScreenToLoad();

            return this;
        }

        public FileSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(BasicDetails, 20);

            return this;
        }

        public FileSummary WaitForMyFastTodayScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(BasicDetails, 20);

            return this;
        }

        public FileSummary WaitForFastViewScreenToLoad(IWebElement element = null)
        {
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(element ?? BasicDetails);

            return this;
        }

        public FileSummary WaitForBusPartiesScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(BusinesspartiesTable, 20);

            return this;
        }

        public FileSummary WaitForFastViewBusPartiesScreenToLoad()
        {
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(BusinesspartiesTable, 20);

            return this;
        }

        public FileSummary WaitForLoanDisScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PrintBtn, 20);

            return this;
        }

        public FileSummary WaitForFastViewLoanDisScreenToLoad()
        {
            this.SwitchToFastViewContentFrame();
            this.WaitCreation(PrintBtn, 20);

            return this;
        }
	}
}
