using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class FileSummaryDlg : PageObject
	{
        int waitTime = Convert.ToInt32(AutoConfig.WaitTime);
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "Basic Details")]
		public IWebElement BasicDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Business Parties")]
		public IWebElement BusinessParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Loan/Disbursement")]
		public IWebElement LoanDisbursement { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_btnContinue")]
		public IWebElement Continue { get; set; }

		[FindsBy(How = How.Id, Using = "btn")]
		public IWebElement Print { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_dgFBPList")]
		public IWebElement BusinesspartiesTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel9")]
		public IWebElement PropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel11")]
		public IWebElement TranType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel16")]
		public IWebElement ServiceType { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel12")]
		public IWebElement BuSegment { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel57")]
		public IWebElement PropertyAdd { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_idLPSGrid_0_labelLenderName")]
		public IWebElement LenderName { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel59")]
		public IWebElement Loanamt { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel6")]
		public IWebElement FileNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabOffice_Faflabel17")]
		public IWebElement OpenedDate { get; set; }

        [FindsBy(How = How.Id, Using = "TC_DT_EDT_lblOpenDate")]
		public IWebElement OpenedDateExchange { get; set; }
        
		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel18")]
		public IWebElement EstSettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel14")]
		public IWebElement SalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_Faflabel7")]
		public IWebElement APN1 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement TitleOwneroffice { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement EscrowOwneroffice { get; set; }

		[FindsBy(How = How.Id, Using = "tabOffice_idLPSGrid_0_labelLoanAmounts")]
		public IWebElement Loanamt1 { get; set; }

		[FindsBy(How = How.Id, Using = "lblBusSrc")]
		public IWebElement BusinessSourcePane { get; set; }

		#endregion


        public FileSummaryDlg WaitForScreenToLoad(string windowName = "File Summary")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, waitTime);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Continue);

            return this;
        }

        public void CheckTheOpenedDateInFileSummaryDialog(string fromDate)
        {
            WaitForScreenToLoad();
            //FastDriver.WebDriver.WaitForWindowAndSwitch("File Summary Dialog", true, 60);
            //FastDriver.FileSummaryDlg.SwitchToDialogContentFrame();
            Reports.StatusUpdate("Check that the Opened Date falls within the From Date entered", Convert.ToDateTime(fromDate) <= Convert.ToDateTime(FastDriver.FileSummaryDlg.OpenedDate.FAGetText()));
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            this.SwitchToContentFrame();
        }

	}
}
