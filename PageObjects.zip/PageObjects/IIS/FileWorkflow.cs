using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Configuration;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using FASTSelenium.DataObjects.ADM;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileWorkflow : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgAlerts_dgAlerts")]
        public IWebElement ActiveAlertsAndRemindersTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnEventLog")]
        public IWebElement EventLog { get; set; }

        [FindsBy(How = How.Id, Using = "btnFileInfo")]
        public IWebElement FileInfo { get; set; }

        [FindsBy(How = How.Id, Using = "chkClpsAll")]
        public IWebElement CollapseAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkActiveOnly")]
        public IWebElement ActiveOnly { get; set; }

        [FindsBy(How = How.Id, Using = "cboProcessCategory")]
        public IWebElement ProcessCategory { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddProcess")]
        public IWebElement AddProcess { get; set; }

        [FindsBy(How = How.Id, Using = "btnUp")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "btnDown")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddTask")]
        public IWebElement AddTask { get; set; }

        [FindsBy(How = How.Id, Using = "btnTaskRemove")]
        public IWebElement RemoveTask { get; set; }

        [FindsBy(How = How.Id, Using = "btnDetails")]
        public IWebElement Details { get; set; }

        [FindsBy(How = How.Id, Using = "chkHideWaive")]
        public IWebElement HideWaive { get; set; }

        [FindsBy(How = How.Id, Using = "chkHideComplete")]
        public IWebElement HideComplete { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_chkWaive")]
        public IWebElement Waive { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT_1_chkStart")]
        public IWebElement StartTaskCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelRem")]
        public IWebElement RemoveRemainder { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_0_cboVisibility")]
        public IWebElement Visibility { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_0_txtNotify")]
        public IWebElement NotifyDate { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_0_txtN")]
        public IWebElement Note { get; set; }

        [FindsBy(How = How.Id, Using = "imgWaive")]
        public IWebElement Waivedimage { get; set; }

        [FindsBy(How = How.LinkText, Using = "A NEW NOTE")]
        public IWebElement AddNote { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT")]
        public IWebElement Process { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_1_dgT")]
        public IWebElement Process1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgAlerts")]
        public IWebElement MessagesTable { get; set; }

        [FindsBy(How = How.Id, Using = "imgComment")]
        public IWebElement AddComment { get; set; }

        [FindsBy(How = How.Id, Using = "cboWG")]
        public IWebElement SelWorkgrp { get; set; }

        [FindsBy(How = How.Id, Using = "cboATO")]
        public IWebElement SelAssgTo { get; set; }

        [FindsBy(How = How.Id, Using = "imgATO")]
        public IWebElement SelAssgToImage { get; set; }

        [FindsBy(How = How.Id, Using = "divStatus")]
        public IWebElement ProcessActiveStatus { get; set; }

        [FindsBy(How = How.Id, Using = "divStatus")]
        public IWebElement ProcessWaiveStatus { get; set; }

        [FindsBy(How = How.LinkText, Using = "MiscTaskTest")]
        public IWebElement MiscPane { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Ten99sAlert { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem")]
        public IWebElement PendingReminderTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "2/25/2013")]
        public IWebElement DatePane { get; set; }

        [FindsBy(How = How.Id, Using = "imgCal_dgRem_0_txtNotify")]
        public IWebElement RemCal { get; set; }

        [FindsBy(How = How.Id, Using = "dgAlerts_0_chkDel")]
        public IWebElement Del { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT")]
        public IWebElement ActiveAlertsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_chkPriorityProcess")]
        public IWebElement PriorityProcess { get; set; }

        [FindsBy(How = How.XPath, Using = "//table/tbody/tr/td/span[@style='width: 20px; display: inline-block;']/input")]
        public IWebElement PriorityProcessCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "imgWG")]
        public IWebElement Workgrpsel { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "btnImport")]
        public IWebElement Import { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/FastNetApp3/images/Status_Started.gif")]
        public IWebElement StartImage { get; set; }

        [FindsBy(How = How.Id, Using = "imgComplete")]
        public IWebElement Completeimage { get; set; }

        [FindsBy(How = How.Id, Using = "pExpCol")]
        public IWebElement ExpandButton { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_1 #pExpCol")]
        public IWebElement Process1_ExpandButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc")]
        public IWebElement ProcessTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "divStatus")]
        public IWebElement ProcessStartedStatus { get; set; }
        
        [FindsBy(How = How.Id, Using = "dgProc_0_lblPN")]
        public IWebElement ProcessName { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_1_lblPN")]
        public IWebElement ProcessName1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_0_lblCreator")]
        public IWebElement Creator { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT_0_lblTN")]
        public IWebElement TaskName1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT_0_lblTO")]
        public IWebElement TaskOffice1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT_1_lblTO")]
        public IWebElement taskOffice1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_1_dgT_0_lblTN")]
        public IWebElement TaskName2ndTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc_0_dgT_1_lblTN")]
        public IWebElement ProcessTask1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgProc")]
        public IWebElement MainTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblProc")]
        public IWebElement tblProcessActiveTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_1_dgT_2 #imgComplete")]
        public IWebElement Process1_TaskCompleteIndicator { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_1_dgT_1 #imgStart")]
        public IWebElement Process1_TaskStartedIndicator2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_1_dgT_0 #imgStart")]
        public IWebElement Process1_TaskStartedIndicator1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_1_dgT_3 #imgWaive")]
        public IWebElement Process1_TaskWaivedIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "imgStart")]
        public IWebElement Img_TaskStartedIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "imgWaive")]
        public IWebElement Img_TaskWaivedIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "imgComplete")]
        public IWebElement Img_TaskCompletedIndicator { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_0_dgT_2 #imgComplete")]
        public IWebElement Process_TaskCompleteIndicator { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_0_dgT_1 #imgStart")]
        public IWebElement Process_TaskStartedIndicator2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_0_dgT_0 #imgStart")]
        public IWebElement Process_TaskStartedIndicator1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#dgProc_0_dgT_3 #imgWaive")]
        public IWebElement Process_TaskWaivedIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_1_cboVisibility")]
        public IWebElement Visibility2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_1_lblCreator")]
        public IWebElement Creator2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_1_txtNotify")]
        public IWebElement NotifyDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgRem_1_txtN")]
        public IWebElement Note2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Process Started')]")]
        public IWebElement ProcessStarted { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(text(),'Process Completed')]")]
        public IWebElement ProcessCompleted { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='QA07, FAST']")]
        public IWebElement QA07_FAST { get; set; }

        #endregion

        public FileWorkflow WaitForScreenToLoad(IWebElement element = null)
        {
            Playback.Wait(1000);
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? EventLog);
            return this;
        }

        public FileWorkflow ProcessActiveTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(this.tblProcessActiveTable);
            IWebElement processActiveTable = FastDriver.FileWorkflow.tblProcessActiveTable.FindElement(By.TagName("table"));
            OperationResult result = processActiveTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value);

            return this;
        }

        public FileWorkflow AssignUserToTheFirstActiveTask()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(this.MainTable);
            FastDriver.FileWorkflow.MainTable.FindElements(By.XPath(".//tr[not(contains(@style,'display: none') or contains(@style,'display:none'))]/td[1]/input"))[0].Click();
            FastDriver.FileWorkflow.MainTable.FindElements(By.XPath(".//tr[not(contains(@style,'display: none') or contains(@style,'display:none'))]/td[11]/img"))[0].Click();
            this.SelAssgTo.FASelectItemBySendingKeys("QA07, FAST");
            FastDriver.BottomFrame.Apply();

            return this;
        }

        public string GetWorkFlowTableID(string templateName, bool getParentTable = false)
        {
            FastDriver.FileWorkflow.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + templateName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();

                return getParentTable ? "dgProc_" + id[1] : "dgProc_" + id[1] + "_dgT";
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string CheckPriorityWaive_Process(string processName, bool checkPriority = true, bool checkWaive = false)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + processName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();

                if (checkPriority)
                    ProcessTable.FAFindElement(ByLocator.Id, "dgProc_" + id[1] + "_chkPriorityProcess").FASetCheckbox(true);
                if (checkWaive)
                    ProcessTable.FAFindElement(ByLocator.Id, "dgProc_" + id[1] + "_chkWaive").FASetCheckbox(true);

                return "dgProc_" + id[1] + "_dgT";
            }
            catch (Exception)
            {
                return null;
            }
        }

        public bool IsPriorityProcessChecked(string processName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + processName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();
                return ProcessTable.FAFindElement(ByLocator.Id, "dgProc_" + id[1] + "_chkPriorityProcess").IsSelected();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsPriorityProcess(string processName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + processName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();
                return ProcessTable.FAFindElement(ByLocator.Id, "dgProc_" + id[1] + "_chkPriorityProcess").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsPriorityProcessEnabled(string processName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + processName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();
                return ProcessTable.FAFindElement(ByLocator.Id, "dgProc_" + id[1] + "_chkPriorityProcess").IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool IsProcessCollapsed(string processName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FindElement(By.XPath("//span[contains(text(),'" + processName + "')]/../preceding-sibling::*[1]"));

                if (element.GetAttribute("class") == "cButtonExpandFalse")
                    return true;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool GetWaiveStatus()
        {
            this.SwitchToContentFrame();
            bool status = false;
            try
            {
                status = Waive.Selected;
            }
            catch (NoSuchElementException)
            {
                status = false;
            }

            return status;
        }

        public bool IsTaskDisabled(string taskName)
        {
            this.WaitForScreenToLoad();
            string value = "";

            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName)));
                value = taskTable.PerformTableAction(5, taskName, 1, TableAction.GetCell).Element.FindElement(By.XPath(".//input")).GetAttribute("disabled");

                if (value == "true")
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
            
        }

        public OperationResult PeformActionOnTask(string taskName, TableAction action, int column, int startRow = 1)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                return taskTable.PerformTableAction(5, taskName, column, action, startOffRow: startRow);
            }
            catch
            {
                Reports.StatusUpdate("Can't find task", false);
                return new OperationResult();
            }
        }
        public bool IsTaskStarted(string taskName)
        {
            this.WaitForScreenToLoad();
            string value = "";

            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                value = taskTable.PerformTableAction(5, taskName, 1, TableAction.GetCell).Element.FindElement(By.XPath(".//img")).GetAttribute("src");
                
                if (value.Contains("Status_Started.gif"))
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
            
        }

        public bool IsTaskCompleted(string taskName)
        {
            this.WaitForScreenToLoad();
            string value = "";

            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                value = taskTable.PerformTableAction(5, taskName, 2, TableAction.GetCell).Element.FindElement(By.XPath(".//img")).GetAttribute("src");

                if (value.Contains("Status_Complete.gif"))
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsTaskWaived(string taskName)
        {
            this.WaitForScreenToLoad();
            string value = "";

            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                value = taskTable.PerformTableAction(5, taskName, 3, TableAction.GetCell).Element.FindElement(By.XPath(".//img")).GetAttribute("src");

                if (value.Contains("Status_Waived.gif"))
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }
        }
        public string GetAssignedToUser(string taskName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                return taskTable.PerformTableAction(5, taskName, 10, TableAction.GetCell).Element.FindElement(By.XPath(".//span/span")).Text;
            }
            catch
            {
                return "Can't find assigned user";
            }
        }

        public string GetAssignedTaskOffice(string taskName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                return taskTable.PerformTableAction(5, taskName, 6, TableAction.GetCell).Element.FindElement(By.XPath(".//span/span")).Text;
            }
            catch
            {
                return "Can't find task office";
            }
        }

        public string GetAssignedWorkgroup(string taskName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                return taskTable.PerformTableAction(5, taskName, 8, TableAction.GetCell).Element.FindElement(By.XPath(".//span")).GetAttribute("title");
            }
            catch
            {
                return "Can't find assigned workgroup";
            }
        }

        public void AssignedTaskOfficeToTask(string taskName, string officeName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                taskTable.PerformTableAction(5, taskName, 7, TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction(3, officeName, 3, TableAction.Click);
                FastDriver.TaskOfficeSelectionDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
            }
            catch
            {
                Reports.StatusUpdate("Something went wrong!", false);
            }
        }
        public void AssignedWorkgroupToTask(string taskName, string workgroupName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                taskTable.PerformTableAction(5, taskName, 9, TableAction.Click);
                Thread.Sleep(2000);
                SelWorkgrp.FASelectItemBySendingKeys("++View More Workgroups...");
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.SelectWorkgroup.FASelectItem(workgroupName);
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
            }
            catch
            {
                Reports.StatusUpdate("Something went wrong!", false);
            }
        }

        public void AssignedEmployeeToTask(string taskName, string officeName, string employeeName)
        {
            this.WaitForScreenToLoad();
            try
            {
                IWebElement taskTable = FastDriver.WebDriver.FindElement(By.Id(GetWorkFlowTableID(taskName))); //find the right table for the task
                taskTable.PerformTableAction(5, taskName, 11, TableAction.Click);
                Thread.Sleep(2000);
                SelAssgTo.FASelectItemBySendingKeys("++View Offices...");
                FastDriver.EmployeeSelectionbyOfficeDlg.WaitForScreenToLoad();
                FastDriver.EmployeeSelectionbyOfficeDlg.SelectOffice.FASelectItem(officeName);
                Thread.Sleep(2000);
                FastDriver.EmployeeSelectionbyOfficeDlg.EmployeeList.FASelectItem(employeeName);
                FastDriver.EmployeeSelectionbyOfficeDlg.Select.FAClick();
                FastDriver.FileWorkflow.WaitForScreenToLoad();
            }
            catch
            {
                Reports.StatusUpdate("Something went wrong!", false);
            }
        }

        public bool ClickCompleteTaskCheckboxForTask(string ProcessName, string TaskName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    IndividualProcessTable.PerformTableAction(i, 2, TableAction.On);
                                    return true;
                                }
                            }
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
        //

        //Experimental -DO NOT USE
        //public FileWorkflow SelectTask(string process, string task)
        //{
        //    this.SwitchToContentFrame();
        //    var pro = ProcessTable.FindElements(By.TagName("tr")).FirstOrDefault(row => row.Text.Contains(process));

        //    pro.FindElement(By.Id("pExpCol")).FAClick();

        //    var ta = ProcessTable.FindElements(By.TagName("tr")).FirstOrDefault(row => row.Text.Contains(task));

        //    ta.FindElement(By.CssSelector("td[title='Category: Escrow'")).FAClick();
        //    return this;
        //}

        public FileWorkflow Open()
        {
            FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow");
            this.WaitForScreenToLoad();

            return this;
    }
        //
        public bool CheckIfProcessIsPulled(string ProcessName)
        {
            this.WaitForScreenToLoad();
            int RowCount = FastDriver.FileWorkflow.ProcessTable.GetRowCount(thisTableOnly: true); //Only count rows from the main table not the descendent tables
            IWebElement ProcessPane = null;
            for (int i = 0; i < RowCount; i++)
            {
                try
                {
                    ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + i + "_lblPN"));
                }
                catch (NoSuchElementException)
                {
                    break;
                }

                if (ProcessPane.FAGetText().Equals(ProcessName, StringComparison.CurrentCultureIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }
        public void ClickApply()
        {
                FastDriver.BottomFrame.Apply();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Applying Changes...", toExist: false, timeoutSeconds: 20);
                Thread.Sleep(2000);
        }
        //
        public void CreateNewAlertOrReminder(string AlertMessage, bool isAlert = true, string NotifyDate = "", bool ClickApply = true)
        {
            this.WaitForScreenToLoad();
            this.New.FAClick();
            Thread.Sleep(2000);
            if (isAlert)
                this.Visibility.FASelectItem(@"Alert");
            else
            this.Visibility.FASelectItem(@"Reminder");
            Reports.TestStep = "Create New alert or reminder";
            if (string.IsNullOrEmpty(NotifyDate))
            NotifyDate = DateTime.UtcNow.AddHours(-8).ToDateString();
           this.NotifyDate.FASetText(NotifyDate);
            FastDriver.FileWorkflow.Note.FASetText(AlertMessage);
            if (ClickApply)
            {
                Reports.TestStep = "Click On Apply Button.";
                FastDriver.FileWorkflow.ClickApply();
            }
        }
        //
        public void DeleteAlertOrReminder(string AlertMessage)
        {
            this.WaitForScreenToLoad();
            this.MessagesTable.PerformTableAction("Message", AlertMessage, @"Del?", TableAction.On);
            Reports.TestStep = "Click apply to delete alert.";
            FastDriver.FileWorkflow.ClickApply();
        }
        //
        public bool ClickStartTaskCheckboxForTask(string ProcessName, string TaskName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    IndividualProcessTable.PerformTableAction(i, 1, TableAction.On);
                                    return true;
                                }
                            }
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }

        public bool ClickWaiveTaskCheckboxForTask(string ProcessName, string TaskName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    IndividualProcessTable.PerformTableAction(i, 3, TableAction.On);
                                    return true;
                                }
                            }
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }

        public string GetAssignedOffice(string ProcessName, string TaskName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    return IndividualProcessTable.PerformTableAction(i, 6, TableAction.GetText).Message.Clean();
                                }
                            }
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return "Process is not pulled";
                    }
                }
                return "Process is not pulled";
            }
            catch
            {
                throw;
            }
        }

        //
        //
        public bool SelectTask(string ProcessName, string TaskName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Applying Changes...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    IndividualProcessTable.PerformTableAction(i, 5, TableAction.Click);
                                    return true;
                                }
                            }
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
        //
        public bool SelectFirstTask(string ProcessName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Applying Changes...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                                    IndividualProcessTable.PerformTableAction(1, 5, TableAction.Click);
                                    return true;
                                
                            
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
        public void AddMiscTaskToProcess(string ProcessName, string TaskName)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(@"One Moment please...", false);
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(@"One Moment please...", false);
                SelectFirstTask(ProcessName);
                this.AddTask.Click();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.AddMiscTask(TaskName, selectTask: true);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }


        }
        //
        public void AddProcessToFileWorkFlow(string ProcessType)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                this.AddProcess.FAClick();
                FastDriver.AddProcessToFileWorkflowDlg.WaitForScreenToLoad();
                FastDriver.AddProcessToFileWorkflowDlg.AddProcessTable.PerformTableAction(@"#1", ProcessType, "#1", TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }


        }
        //
        //
        public bool AssignTaskTo(string ProcessName, string TaskName, string AssignTo)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                }
                this.WaitForScreenToLoad();
                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    IndividualProcessTable.PerformTableAction(i, 5, TableAction.Click);
                                    IWebElement img = IndividualProcessTable.PerformTableAction(i, 11, TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgATO");
                                    img.FAClick();
                                    Thread.Sleep(3000);
                                    this.WaitForScreenToLoad();
                                    IWebElement select = FastDriver.WebDriver.FindElement(By.XPath("//select[@id='cboATO']"));
                                    select.FASelectItem(AssignTo);
                                    return true;
                                }
                            }
                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);
                        return false;
                    }
                }
                return false;
            }
            catch
            {
                throw;
            }
        }
        //
        public bool OpenTaskCommentDlgForTask(string ProcessName, string TaskName, string FileNumber)
        {
            try
            {
                this.WaitForScreenToLoad();
                if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
                {
                    FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }
                if (!FastDriver.FileWorkflow.ActiveOnly.IsSelected())
                {
                    FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(true);
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
                }

                for (int j = 0; j < 5; j++)
                {
                    IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                    if (ProcessPane.Exists())
                    {
                        if (ProcessPane.FAGetText().Contains(ProcessName))
                        {
                            IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                            for (int i = 1; i <= IndividualProcessTable.GetRowCount(); i++)
                            {
                                if (IndividualProcessTable.PerformTableAction(i, 5, TableAction.GetCell).Element.FAGetText().Contains(TaskName))
                                {
                                    //IWebElement TaskComment = IndividualProcessTable.PerformTableAction(4, TaskName, 11, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG");
                                    IWebElement TaskComment = IndividualProcessTable.PerformTableAction(i, 12, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG");
                                   // imgComment
                                    TaskComment.FAClick();
                                    for (int k = 0; k < 5; k++)
                                    {
                                        try
                                        {
                                            FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                                            return true;
                                        }
                                        catch
                                        {
                                            TaskComment.FAClick();
                                            continue;
                                        }
                                    }
                                }
                            }

                        }
                    }
                    else
                    {
                        Reports.StatusUpdate("Process is not pulled", false);     
                    }

                }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        //
        public void AddTaskToProcess(string ProcessName, TaskTemplateParameters TaskParams)
        {
            this.WaitForScreenToLoad();
            if (FastDriver.FileWorkflow.CollapseAll.IsSelected())
            {
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
            }
            if (FastDriver.FileWorkflow.ActiveOnly.IsSelected())
            {
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
            }
            //
            for (int j = 0; j < 5; j++)
            {
                IWebElement ProcessPane = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_lblPN"));
                if (ProcessPane.Exists())
                {
                    if (ProcessPane.FAGetText().Contains(ProcessName))
                    {
                        IWebElement IndividualProcessTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id("dgProc_" + j + "_dgT"));
                        IndividualProcessTable.PerformTableAction(1, 5, TableAction.GetCell).Element.FAClick();
                        this.AddTask.FAClick();
                        FastDriver.AddTasksfromProcessTemplateScreenDlg.WaitForScreenToLoad();
                        FastDriver.AddTasksfromProcessTemplateScreenDlg.ViewMore.FAClick();
                        FastDriver.TaskTemplateSelectionDlg.AddExistingTask(TaskParams);
                        break;
                        
                    }
                }
                else
                {
                    Reports.StatusUpdate("Process is not pulled", false);
                }
            }
        }

    }
    public class TaskOfficeSelectionDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "grdTskOffice_grdTskOffice")]
        public IWebElement TaskOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdMultiSelect_grdMultiSelect")]
        public IWebElement SelectTaskOfficesTable { get; set; }

        #endregion

        #region Useful Methods
        public TaskOfficeSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Task Office Selection");
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? Select);
            return this;
        }
        #endregion

    }
    public class AddProcessToFileWorkflowDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "idGVTableBody")]
        public IWebElement AddProcessTable { get; set; }

        #endregion

        #region Useful Methods
        public AddProcessToFileWorkflowDlg WaitForScreenToLoad(string windowName = "Add Process To File Workflow")
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, timeoutSeconds: 20);
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(AddProcessTable);
            return this;
        }
        #endregion

    }
    public class AddTasksfromProcessTemplateScreenDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "grdTaskTmplte_15_chkSel")]
        public IWebElement SelTask15 { get; set; }

        [FindsBy(How = How.Id, Using = "btnViewMore")]
        public IWebElement ViewMore { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement Select { get; set; }

        [FindsBy(How = How.Id, Using = "grdTaskTmpe_grdTaskTmplte")]
        public IWebElement SummaryTab { get; set; }

        [FindsBy(How = How.Id, Using = "grdTaskTmplte_0_chkSel")]
        public IWebElement SelTask1 { get; set; }

        [FindsBy(How = How.Id, Using = "grdTaskTmplte_2_chkSel")]
        public IWebElement SelTask2 { get; set; }

        [FindsBy(How = How.Id, Using = "TaskTmplte")]
        public IWebElement Table { get; set; }

        [FindsBy(How = How.Id, Using = "grdTaskTmplte_grdTaskTmplte")]
        public IWebElement SelectTasksFromProcessTemplateTable { get; set; }

        #endregion

        public AddTasksfromProcessTemplateScreenDlg WaitForScreenToLoad(string WindowTitle = "Add Tasks from Process Template Screen", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(WindowTitle, timeoutSeconds: 30);
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? ViewMore);
            return this;
        }
    }
    
    public class AddNewMiscellaneousTaskDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        #endregion
        public AddNewMiscellaneousTaskDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(WindowTitle, timeoutSeconds: 30);
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? Name);
            return this;
        }

    }
    public class SelectSuccessorTaskDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgSelctTask_1_lblTaskName")]
        public IWebElement Task { get; set; }

        [FindsBy(How = How.Id, Using = "dgSelctTask")]
        public IWebElement SelTaskTable { get; set; }

        #endregion

        public SelectSuccessorTaskDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(SelTaskTable);
            return this;
        }
    }
}
