using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class FilterSelectionCriteriaDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "ddlService")]
		public IWebElement Service { get; set; }

		[FindsBy(How = How.Id, Using = "lstTransType")]
		public IWebElement TransType { get; set; }

		[FindsBy(How = How.Id, Using = "lstBusSeg")]
		public IWebElement BusSeg { get; set; }

		[FindsBy(How = How.Id, Using = "btnProdType")]
		public IWebElement AddRemoveProdtype { get; set; }

		[FindsBy(How = How.Id, Using = "btnEscrowOwningOffice")]
		public IWebElement AddRemoveEscrowowning { get; set; }

		[FindsBy(How = How.Id, Using = "btnTitleOwningOffice")]
		public IWebElement AddRemoveTitleowning { get; set; }

		[FindsBy(How = How.Id, Using = "lstCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "lstState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "lstCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "ddlEmpRole")]
		public IWebElement EmpRole { get; set; }

		[FindsBy(How = How.Id, Using = "ddlEmpName")]
		public IWebElement EmpName { get; set; }

		#endregion

        public FilterSelectionCriteriaDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? BusSeg);
            return this;
        }
	}
}
