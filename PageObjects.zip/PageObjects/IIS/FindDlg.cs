using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class FindDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtFind")]
		public IWebElement TextToFind { get; set; }

		[FindsBy(How = How.Id, Using = "btnFindNext")]
		public IWebElement FindNext { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "chkWholeWord")]
        public IWebElement MatchWholeWord { get; set; }

        [FindsBy(How = How.Id, Using = "rdUp")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "rdDown")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "chkMatchCase")]
        public IWebElement MatchCase { get; set; }

        #endregion

        public FindDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? FindNext);

            return this;
        }

        public FindDlg SearchText(string searchText, bool findText = true)
        {
            WaitForScreenToLoad();
            TextToFind.FASetText(searchText);
            if (findText)
            {
                FindNext.FAClick();
            }
            return this;
        }
	}
}
