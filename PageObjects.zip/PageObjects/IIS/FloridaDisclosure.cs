using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Windows.Input;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using FASTSelenium.ImageRecognition;
using FASTWCFHelpers.FastEscrowService;

namespace FASTSelenium.PageObjects
{
    public class FloridaDisclosure : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "divFDHeading")]
        public IWebElement Heading_Table { get; set; }

        //[FindsBy(How = How.Id, Using = "tblTDHeaderSec")]
        //public IWebElement Information_Table { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerBorrowerAuthorization")]
        public IWebElement SellerBorrowerAuthorization { get; set; }

        [FindsBy(How = How.Id, Using = "lblSettlementAgentCertification")]
        public IWebElement SettlementAgentCertification { get; set; }

        #endregion


        #region Services

        public FloridaDisclosure WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Heading_Table);
            return this;
        }

        public FloridaDisclosure Open()
        {
            FastDriver.LeftNavigation.Navigate<FloridaDisclosure>("Home>Order Entry>Escrow Closing>Florida Disclosure");
            this.WaitForScreenToLoad();

            return this;
        }
    
      
       
        public void NavigateToFloridaDisclosure()
        {
            Reports.TestStep = "Navigate to Texas Disclosure screen";
            FastDriver.LeftNavigation.Navigate<FloridaDisclosure>("Home>Order Entry>Escrow Closing>Florida Disclosure").WaitForScreenToLoad();
            this.SwitchToContentFrame();
        }
        
        #endregion
    }

   
}