using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
    public class GABEntryRequestDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboBSType")]
        public IWebElement BuyerSellerType { get; set; }

        [FindsBy(How = How.Id, Using = "cboET")]
        public IWebElement EntityType { get; set; }

        [FindsBy(How = How.Id, Using = "cboGrade")]
        public IWebElement Grade { get; set; }

        [FindsBy(How = How.Id, Using = "txtIDCode")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "txtName1")]
        public IWebElement Name1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtName2")]
        public IWebElement Name2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtLocDesc")]
        public IWebElement LocDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtTaxIDNum")]
        public IWebElement TaxIDNumber { get; set; }

        [FindsBy(How = How.Id, Using = "cboTAT")]
        public IWebElement TitleAgentType { get; set; }

        [FindsBy(How = How.Id, Using = "txtBOComments")]
        public IWebElement BusOrgComments { get; set; }

        [FindsBy(How = How.Id, Using = "txtLicNum")]
        public IWebElement LicenseNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtGABEI")]
        public IWebElement EntryInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "ddlLicType")]
        public IWebElement LicenseType { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnNew")]
        public IWebElement LicenseInformationNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnEdit")]
        public IWebElement LicenseInformationEdit { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnViewChangeStatus")]
        public IWebElement LicenseInformationStatus { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_btnViewChangeHistory")]
        public IWebElement LicenseInfoHistory { get; set; }

        [FindsBy(How = How.Id, Using = "ucLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement LicenseInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_chkEmailStatus")]
        public IWebElement PhonesStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_cmdAddPhoneType")]
        public IWebElement PhonesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_cmdDeletePhoneEntry")]
        public IWebElement PhonesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_comboPhoneType")]
        public IWebElement BusinessPhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_textNumber")]
        public IWebElement BusinessPhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_textExtension")]
        public IWebElement BusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_0_textComments")]
        public IWebElement BusinessPhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_comboPhoneType")]
        public IWebElement BusinessFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_textNumber")]
        public IWebElement BusinessFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_textExtension")]
        public IWebElement BusinessFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_1_textComments")]
        public IWebElement BusinessFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_2_comboPhoneType")]
        public IWebElement EmailType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_2_textNumber")]
        public IWebElement EmailNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_2_textComments")]
        public IWebElement EmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_comboPhoneType")]
        public IWebElement PagerType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_textNumber")]
        public IWebElement PagerNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_textExtension")]
        public IWebElement PagerExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_3_textComments")]
        public IWebElement PagerComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_comboPhoneType")]
        public IWebElement CellularType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_textNumber")]
        public IWebElement CellularNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_textExtension")]
        public IWebElement CellularExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_4_textComments")]
        public IWebElement CellularComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_comboPhoneType")]
        public IWebElement HomePhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_textNumber")]
        public IWebElement HomePhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_textExtension")]
        public IWebElement HomePhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_5_textComments")]
        public IWebElement HomePhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_comboPhoneType")]
        public IWebElement HomeFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_textNumber")]
        public IWebElement HomeFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_textExtension")]
        public IWebElement HomeFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucEleAddr_dgridPhoneTypes_6_textComments")]
        public IWebElement HomeFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textAddrLine1")]
        public IWebElement MailingAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textAddrLine2")]
        public IWebElement MailingAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textAddrLine3")]
        public IWebElement MailingAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textAddrLine4")]
        public IWebElement MailingAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textCity")]
        public IWebElement MailingAddressCity { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_comboState")]
        public IWebElement MailingAddressState { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textZip")]
        public IWebElement MailingAddressZip { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_textCounty")]
        public IWebElement MailingAddressCounty { get; set; }

        [FindsBy(How = How.Id, Using = "ucMAD_comboCountry")]
        public IWebElement MailingAddressCountry { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine1")]
        public IWebElement BillingAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine2")]
        public IWebElement BillingAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine3")]
        public IWebElement BillingAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textAddrLine4")]
        public IWebElement BillingAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textCity")]
        public IWebElement BillingAddressCity { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_comboState")]
        public IWebElement BillingAddressState { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textZip")]
        public IWebElement BillingAddressZip { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_textCounty")]
        public IWebElement BillingAddressCounty { get; set; }

        [FindsBy(How = How.Id, Using = "ucBIAD_comboCountry")]
        public IWebElement BillingAddressCountry { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine1")]
        public IWebElement BusinessAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine2")]
        public IWebElement BusinessAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine3")]
        public IWebElement BusinessAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textAddrLine4")]
        public IWebElement BusinessAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textCity")]
        public IWebElement BusinessAddressCity { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_comboState")]
        public IWebElement BusinessAddressState { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textZip")]
        public IWebElement BusinessAddressZip { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_textCounty")]
        public IWebElement BusinessAddressCounty { get; set; }

        [FindsBy(How = How.Id, Using = "ucBUAD_comboCountry")]
        public IWebElement BusinessAddressCountry { get; set; }

        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement ContactsAdd { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement ContactsRemove { get; set; }

        [FindsBy(How = How.Id, Using = "txtFN")]
        public IWebElement ContactsFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "txtLN")]
        public IWebElement ContactsLastName { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_chkEmailStatus")]
        public IWebElement ContactsStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_cmdAddPhoneType")]
        public IWebElement ContactsPhonesAdd { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_cmdDeletePhoneEntry")]
        public IWebElement ContactsPhonesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_comboPhoneType")]
        public IWebElement ContactsPhonesBusinessPhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_textNumber")]
        public IWebElement ContactsPhonesBusinessPhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_textExtension")]
        public IWebElement ContactsPhonesBusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_0_textComments")]
        public IWebElement ContactsPhonesBusinessPhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_comboPhoneType")]
        public IWebElement ContactsPhonesBusinessFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_textNumber")]
        public IWebElement ContactsPhonesBusinessFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_textExtension")]
        public IWebElement ContactsPhonesBusinessFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_1_textComments")]
        public IWebElement ContactsPhonesBusinessFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_2_comboPhoneType")]
        public IWebElement ContactsPhonesEmailType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_2_textNumber")]
        public IWebElement ContactsPhonesEmailNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_2_textComments")]
        public IWebElement ContactsPhonesEmailComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_comboPhoneType")]
        public IWebElement ContactsPhonesPagerType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_textNumber")]
        public IWebElement ContactsPhonesPagerNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_textExtension")]
        public IWebElement ContactsPhonesPagerExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_3_textComments")]
        public IWebElement ContactsPhonesPagerComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_comboPhoneType")]
        public IWebElement ContactsPhonesCellularType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_textNumber")]
        public IWebElement ContactsPhonesCellularNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_textExtension")]
        public IWebElement ContactsPhonesCellularExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_4_textComments")]
        public IWebElement ContactsPhonesCellularComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_comboPhoneType")]
        public IWebElement ContactsPhonesHomePhoneType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_textNumber")]
        public IWebElement ContactsPhonesHomePhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_textExtension")]
        public IWebElement ContactsPhonesHomePhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_5_textComments")]
        public IWebElement ContactsPhonesHomePhoneComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_comboPhoneType")]
        public IWebElement ContactsPhonesHomeFaxType { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_textNumber")]
        public IWebElement ContactsPhonesHomeFaxNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_textExtension")]
        public IWebElement ContactsPhonesHomeFaxExtension { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctEleAddr_dgridPhoneTypes_6_textComments")]
        public IWebElement ContactsPhonesHomeFaxComments { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_chkCopyBOAddr")]
        public IWebElement SameAsBusOrgMailingAddress { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine1")]
        public IWebElement AddressDetailAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine2")]
        public IWebElement AddressDetailAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine3")]
        public IWebElement AddressDetailAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textAddrLine4")]
        public IWebElement AddressDetailAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textCity")]
        public IWebElement AddressDetailCity { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_comboState")]
        public IWebElement AddressDetailState { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textZip")]
        public IWebElement AddressDetailZip { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_textCounty")]
        public IWebElement AddressDetailCounty { get; set; }

        [FindsBy(How = How.Id, Using = "ucCnctPhyAddr_comboCountry")]
        public IWebElement AddressDetailCountry { get; set; }

        [FindsBy(How = How.Id, Using = "dgridContacts_dgridContacts")]
        public IWebElement ContactsTable { get; set; }

        [FindsBy(How = How.Id, Using = "ucContactLicenseInfo_dgridLicenseInfo_dgridLicenseInfo")]
        public IWebElement ContactsLicenseInfoTable { get; set; }

        [FindsBy(How = How.Id, Using = "ucContactLicenseInfo_btnNew")]
        public IWebElement ContactsLicenseInfoNew { get; set; }

        [FindsBy(How = How.Id, Using = "ucContactLicenseInfo_btnEdit")]
        public IWebElement ContactsLicenseInfoEdit { get; set; }

        #endregion

        public GABEntryRequestDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Request GAB Entry", timeoutSeconds: 15);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? EntityType);
            return this;
        }

        public GABEntryRequestDlg CreateGAB(string _entityType = null, string _name1 = null, string _name2 = null, string _address1 = null, string _city = null, string _zipCode = null, string _addressState = null, bool clickDone = true)
        {
            if (String.IsNullOrEmpty(_entityType) || String.IsNullOrEmpty(_name1) || String.IsNullOrEmpty(_name2) || String.IsNullOrEmpty(_addressState) || String.IsNullOrEmpty(_city) ||
                String.IsNullOrEmpty(_address1) || String.IsNullOrEmpty(_zipCode))
            {
                throw new ArgumentNullException("Please provide required information to create GAB");
            }

            WaitForScreenToLoad();
            EntityType.FASelectItem(_entityType);
            Name1.FASetText(_name1);
            Name2.FASetText(_name2);
            MailingAddressLine1.FASetText(_address1);
            MailingAddressCity.FASetText(_city);
            MailingAddressZip.FASetText(_zipCode);
            MailingAddressState.FASelectItem(_addressState);

            if (clickDone)
                FastDriver.DialogBottomFrame.ClickDone();

            return this;
        }

        public GABEntryRequestDlg WaitForDialogToLoad(IWebElement Element = null)
        {
            Element = Element ?? EntityType;
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                try
                {
                    //WebDriver.WaitForWindowAndSwitch("Request GAB Entry", timeoutSeconds: 10);
                    this.SwitchToDialogContentFrame();
                    return Element.Displayed;
                }
                catch (NoSuchWindowException e)
                {
                    return false;
                }
                catch (NoSuchElementException e)
                {
                    return false;
                }
                catch (StaleElementReferenceException e)
                {
                    return false;
                }

            });
            return this;
        }
        //
        //public void NewGabRequestWithDefaultData(string EntityType = "Corporate")
        //{
        //    this.WaitForDialogToLoad();
        //     this.EntityType.FASelectItem(EntityType);
        //     Random randomNum = new Random();
        //     int num = randomNum.Next(123456);
        //     this.Name1.FASetText(@"Name 1" + num);
        //     this.Name2.FASetText(@"Name 2" + randomNum.Next());
        //    this.LocDescription.FASetText(@"Loc Descscription");
        //    this.TaxIDNumber.FASetText(@"1111111111");
        //    this.BusOrgComments.FASetText(@"Bus Org Comments");
        //    this.EntryInstructions.FASetText(@"Entity Instruction");
        //    this.MailingAddressLine1.FASetText(@"1 First American Way");
        //    this.MailingAddressCity.FASetText(@"Santa Ana");
        //    this.MailingAddressState.FASelectItem(@"CA");
        //    this.MailingAddressZip.FASetText(@"92707");
        //    //this.MailingAddressCounty.FASetText(@"Orange");
        //    FastDriver.DialogBottomFrame.ClickDone();
        //    FastDriver.QuickFileEntry.WaitForScreenToLoad();
        //}
        //
        //
        public void AddMailingAddress(string addrLine1, string city, string state, string zipCode, 
            string county, string country = null, string addrLine2 = null, string addrLine3 = null, string addrLine4 = null)
        {

            FastDriver.GABEntryRequestDlg.MailingAddressLine1.FASetText(addrLine1);
            FastDriver.GABEntryRequestDlg.MailingAddressLine2.FASetText(addrLine2);
            FastDriver.GABEntryRequestDlg.MailingAddressLine3.FASetText(addrLine3);
            FastDriver.GABEntryRequestDlg.MailingAddressLine4.FASetText(addrLine4);
            FastDriver.GABEntryRequestDlg.MailingAddressCity.FASetText(city);
            FastDriver.GABEntryRequestDlg.MailingAddressState.FASelectItem(state);
            FastDriver.GABEntryRequestDlg.MailingAddressZip.FASetText(zipCode);
            FastDriver.GABEntryRequestDlg.MailingAddressCounty.FASetText(county);
            FastDriver.GABEntryRequestDlg.MailingAddressCountry.FASelectItem(country);
        }

        public void NewGabRequest(string City,string State,string Zip,string EntityType = "Corporate")
        {
            try
            {
                this.WaitForDialogToLoad();
                this.EntityType.FASelectItem(EntityType);
                Random randomNum = new Random();
                int num = randomNum.Next(123456);
                this.Name1.FASetText(@"Name 1" + num);
                this.Name2.FASetText(@"Name 2" + randomNum.Next());
                this.LocDescription.FASetText(@"Loc Descscription");
                this.TaxIDNumber.FASetText(@"1111111111");
                this.BusOrgComments.FASetText(@"Bus Org Comments");
                this.EntryInstructions.FASetText(@"Entity Instruction");
                this.MailingAddressLine1.FASetText(@"Address Line 1");
                this.MailingAddressCity.FASetText(City);
                this.MailingAddressState.FASelectItem(State);
                this.MailingAddressZip.FASetText(Zip);
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch
            {
                throw;
            }
        }

        public GABEntryRequestDlg AddContact(string firstName, string lastName)
        {
            WaitForScreenToLoad(ContactsAdd);
            ContactsAdd.FAClick();
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                return ContactsFirstName.Displayed;
            }, timeout: 20);
            ContactsFirstName.FASetText(firstName);
            ContactsLastName.FASetText(lastName);

            return this;
        }

    }
}
