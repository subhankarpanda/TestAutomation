using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class GFEEntryLoanTerms : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tGFE_tLT")]
        public IWebElement LoanTermsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tGFE_tGC")]
        public IWebElement GFEtab { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_lblInitialLoanAmt")]
        public IWebElement InitialLoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtLoanTerm")]
        public IWebElement LoanTerm { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtInitialIntRate")]
        public IWebElement InitialInterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtInitialMonthlyAmt")]
        public IWebElement InitialMonthlyAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkInitialMonthlyPrn")]
        public IWebElement Principal { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkInitialMonthlyInt")]
        public IWebElement Interesterest { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkInitialMonthlyMInsAmt")]
        public IWebElement MortgageInsurance { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbIntRateIncrNo")]
        public IWebElement RateIncrementRiseNo { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbIntRateIncrYes")]
        public IWebElement RateIncrementRiseYes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtMaxIntRate")]
        public IWebElement MaxInterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtIntRateChangeDate")]
        public IWebElement InterestRateChangeDate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtIntRateBeforePeriod")]
        public IWebElement InterestRateBeforePeriod { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtIntRateAfterPeriod")]
        public IWebElement InterestRateAfterPeriod { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtChangedIntRate")]
        public IWebElement ChangedInterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtLowerIntRate")]
        public IWebElement LowerInterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtHigherIntRate")]
        public IWebElement HigherInterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbLoanBalIncrNo")]
        public IWebElement LoanBalanceRiseNo { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbLoanBalIncrYes")]
        public IWebElement LoanBalanceRiseYes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtLoanBalMaxAmt")]
        public IWebElement LoanBalanceMaxAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbMonthlyAmtIncrNo")]
        public IWebElement MonthlyAmountRiseNo { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbMonthlyAmtIncrYes")]
        public IWebElement MonthlyAmountRiseYes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtMonthlyAmtChangeDate")]
        public IWebElement MonlyAmountChangeDate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtMonthlyIncrAmt")]
        public IWebElement MonthlyIncrementAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtMonthlyMaxAmt")]
        public IWebElement MonthlyMaxAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbPrePaymentNo")]
        public IWebElement PrePaymentNo { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbPrePaymentYes")]
        public IWebElement PrePaymentYes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtPrePaymentMaxAmt")]
        public IWebElement PrePaymentMaxAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbBalloonPaymentNo")]
        public IWebElement BalanceloonPaymentNo { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbBalloonPaymentYes")]
        public IWebElement BalanceloonPaymentYes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtBalloonPaymentMaxAmt")]
        public IWebElement BalanceloonPaymentMaxAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtBalloonPaymentDuePeriod")]
        public IWebElement BalancelonPaymentDuePeriod { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtBalloonPaymentDueDate")]
        public IWebElement BalancelonPaymentDueDate { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbTotalMonthlyAmtNo")]
        public IWebElement EscrowAccountMonthlyAmountNo { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_rbTotalMonthlyAmtYes")]
        public IWebElement EscrowAccountMonthlyAmountYes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtAddlMonthlyEscrowAmt")]
        public IWebElement AdditionalMonthlyEscrowAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtTotalInitialMonthlyAmt")]
        public IWebElement AdditionalTotalMonthlyAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_lblPaid")]
        public IWebElement Additionaltext { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem1")]
        public IWebElement Propertytaxes { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem2")]
        public IWebElement Homeownersinsurance { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem3")]
        public IWebElement FloodInsurance { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem4")]
        public IWebElement PaymentItem4 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription4")]
        public IWebElement Description4 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem5")]
        public IWebElement PaymentItem5 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription5")]
        public IWebElement Description5 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem6")]
        public IWebElement PaymentItem6 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription6")]
        public IWebElement Description6 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem7")]
        public IWebElement PaymentItem7 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription7")]
        public IWebElement Description7 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem8")]
        public IWebElement PaymentItem8 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription8")]
        public IWebElement Description8 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem9")]
        public IWebElement PaymentItem9 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription9")]
        public IWebElement Description9 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_chkPaymentItem10")]
        public IWebElement PaymentItem10 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement InterestRaterise { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Loanbalancerise { get; set; }

         [FindsBy(How = How.Id, Using = "tGFE_tLT_pnlLoanTermsDetail")]
          public IWebElement LoanTermsTable { get; set; }
        //TODO: ADD FindsByAttribute
        public IWebElement MonthlyAmountRise { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tLT_txtDescription10")]
        public IWebElement Description10 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement prepaymentpenalty { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Balloonpayment { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement MonthlyAmountOwed { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement PIM { get; set; }

        #endregion

        public GFEEntryLoanTerms WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(InitialInterestRate, 10);
            
            return this;
        }

        /// <summary>
        /// Loan Terms Click
        /// </summary>
        public void LoanTermsClick()
        {
            LoanTermsTab.FAClick();
        }


        /// <summary>
        /// Set Loan Term Amount
        /// </summary>
        public void LoanTermSet(string Loanterms)
        {
           

            LoanTerm.FASetText(Loanterms);
        }

        
        /// <summary>
        /// Set Initial Interest Rate
        /// </summary>
        public void InitialInterestRateSet(string InitialInterest)
        {

            InitialInterestRate.FASetText(InitialInterest);
        }

       
        /// <summary>
        /// Set initial monthly amount owed for principal, interest and any mortgage insurance: 
        /// </summary>
        public void InitiaMonthlyAmtSet(string InitiaMonthlyAmt)
        {
            InitialMonthlyAmount.FASetText(InitiaMonthlyAmt);
            Principal.FAClick();
            Interesterest.FAClick();
            MortgageInsurance.FAClick();
        }

        /// <summary>
        ///Verify the entered data under Can Interest Rate rise? fields
        /// </summary>
        public void VerifyCanInterestRateRiseYes(string MaxInt, string IntChgDate, string IntBeforePeriod, string IntAfterPeriod, string ChangedIntRate, string LowInt, string HigherInt)
        {

            Support.AreEqual(MaxInt, MaxInterestRate.FAGetValue());
            Support.AreEqual(IntChgDate, InterestRateChangeDate.FAGetValue());
            Support.AreEqual(IntBeforePeriod, InterestRateBeforePeriod.FAGetValue());
            Support.AreEqual(IntAfterPeriod, InterestRateAfterPeriod.FAGetValue());
            Support.AreEqual(ChangedIntRate, ChangedInterestRate.FAGetValue());
             Support.AreEqual(LowInt, LowerInterestRate.FAGetValue());
             Support.AreEqual(HigherInt, HigherInterestRate.FAGetValue());
        }
        /// <summary>
        ///�Can Interest Rate rise?�  user selects �Yes�, then the User able to enter corresponding fields. 
        /// </summary>
        public void CanInterestRateRiseYes(string MaxInt,string IntChgDate,string IntBeforePeriod,string IntAfterPeriod,string ChangedIntRate,string LowInt,string HigherInt)
        {
            
            RateIncrementRiseYes.FAClick();
            MaxInterestRate.FASetText(MaxInt);
            InterestRateChangeDate.FASetText(IntChgDate);
            InterestRateBeforePeriod.FASetText(IntBeforePeriod);
            InterestRateAfterPeriod.FASetText(IntAfterPeriod);
            ChangedInterestRate.FASetText(ChangedIntRate);
            LowerInterestRate.FASetText(LowInt);
            HigherInterestRate.FASetText(HigherInt);

        }

       
        /// <summary>
        ///�Can Loan Balance Rate rise?�  user selects �Yes�, then the User able to enter corresponding fields. 
        /// </summary>
        public void LoanBalanceRisedYes(string LoanBal)
        {

             LoanBalanceRiseYes.FAClick();
             LoanBalanceMaxAmt.FASetText(LoanBal);

        }

       

        /// <summary>
        ///�Monthly Amount Owed�  user selects �Yes�, then the User able to enter corresponding fields. 
        /// </summary>
        public void MonthlyAmtOwedYes(string MonthlyAmtChangeDate, string MonthlyIncrement, string MonthlyMax)
        {

            MonthlyAmountRiseYes.FAClick();
            MonlyAmountChangeDate.FASetText(MonthlyAmtChangeDate);
            MonthlyIncrementAmt.FASetText(MonthlyIncrement);
            MonthlyMaxAmount.FASetText(MonthlyMax);

        }

        /// <summary>
        ///�Pre Payment Penalty�  user selects �Yes�, then the User able to enter corresponding fields. 
        /// </summary>
        public void PrePaymentPenaltyYes(string PrePaymentAmt)
        {

            PrePaymentYes.FAClick();
            PrePaymentMaxAmount.FASetText(PrePaymentAmt);

        }

        /// <summary>
        ///�Baloon Payment  user selects �Yes�, then the User able to enter corresponding fields. 
        /// </summary>
        public void BalancePaymentYes(string BalanceAmtMax, string BalancePayDuePeriod)
        {
            BalanceloonPaymentYes.FAClick();
            BalanceloonPaymentMaxAmount.FASetText(BalanceAmtMax);
            BalancelonPaymentDuePeriod.FASetText(BalancePayDuePeriod);

        }     

        /// <summary>
        ///�Total Monthly Amount   user selects �Yes�, then the User able to enter corresponding fields. 
        /// </summary>
        public void TotalMonthlyAmountYes(string AdditionalMonthlyAmt, string AdditionalTotalMonthlyAmount)
        {

             EscrowAccountMonthlyAmountYes.FAClick();
             AdditionalMonthlyEscrowAmount.FASetText(AdditionalMonthlyAmt);
             AdditionalTotalMonthlyAmt.FASetText(AdditionalTotalMonthlyAmount);
            Propertytaxes.FAClick();


        }


        /// <summary>
        ///�Can Interest Rate rise?�  user selects �No�, then the corresponding fields are blank and disabled. 
        /// </summary>
        public bool CanInterestRateRiseNO
        {
            get
            {
                Reports.TestStep = "�Can Interest Rate rise?�  user selects �No�, then the corresponding fields are blank and disabled.";
                RateIncrementRiseNo.FAClick();
                if ((MaxInterestRate.Enabled.ToString() == "False") && (InterestRateChangeDate.Enabled.ToString() == "False")
                     && (InterestRateBeforePeriod.Enabled.ToString() == "False") && (InterestRateAfterPeriod.Enabled.ToString() == "False")
                     && (ChangedInterestRate.Enabled.ToString() == "False") && (LowerInterestRate.Enabled.ToString() == "False") && (HigherInterestRate.Enabled.ToString() == "False"))
                {
                    return false;
                }
                return true;
            }
        }
        public bool LoanBalanceRiseNO
        {
            get
            {
                Reports.TestStep = "�Can Loan Balance rise?�  user selects �No�, then the corresponding fields are blank and disabled.";
                LoanBalanceRiseNo.FAClick();
                if ((LoanBalanceMaxAmt.Enabled.ToString() == "False"))
                {
                    return false;
                }
                return true;
            }
        }

        public bool CanMonthlyAmtOwedNO
        {
            get
            {
                Reports.TestStep = "��Monthly Amount Owed�  user selects �No�, then the corresponding fields are blank and disabled.";
                MonthlyAmountRiseNo.FAClick();
                if ((MonlyAmountChangeDate.Enabled.ToString() == "False") && (MonthlyIncrementAmt.Enabled.ToString() == "False")
                     && (MonthlyMaxAmount.Enabled.ToString() == "False"))
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        ///�Pre Payment Penalty�  user selects �No�, then the corresponding fields are blank and disabled. 
        /// </summary>
        public bool PrePaymentPenaltyNO
        {
            get
            {
               Reports.TestStep = "�Pre Payment Penalty�  user selects �No�, then the corresponding fields are blank and disabled.";
                PrePaymentNo.FAClick();
                if ((PrePaymentMaxAmount.Enabled.ToString() == "False"))
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        ///�Baloon Payment  user selects �No�, then the corresponding fields are blank and disabled. 
        /// </summary>
        public bool BaloonPaymentNO
        {
            get
            {
                Reports.TestStep = "Baloon Payment  user selects �No�, then the corresponding fields are blank and disabled.";
                BalanceloonPaymentNo.FAClick();
                if ((BalanceloonPaymentMaxAmount.Enabled.ToString() == "False") && (BalancelonPaymentDuePeriod.Enabled.ToString() == "False")
                    && (BalancelonPaymentDueDate.Enabled.ToString() == "False"))
                {
                    return false;
                }
                return true;
            }

        }

        /// <summary>
        ///�Total Monthly Amount"  user selects �No�, then the corresponding fields are blank and disabled. 
        /// </summary>
        public bool TotalMonthlyAmountNO
        {
            get
            {
                Reports.TestStep = "Total Monthly Amount user selects �No�, then the corresponding fields are blank and disabled.";
                EscrowAccountMonthlyAmountNo.FAClick();
                if ((AdditionalMonthlyEscrowAmount.Enabled.ToString() == "False") && (AdditionalTotalMonthlyAmt.Enabled.ToString() == "False")
                    && (Propertytaxes.Enabled.ToString() == "False") && (Homeownersinsurance.Enabled.ToString() == "False")
                    && (FloodInsurance.Enabled.ToString() == "False"))
                {
                    return false;
                }
                return true;
            }
        }
    }
    public class GFEEntryGFE : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tGFE_tGC")]
        public IWebElement GFEtab { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbOriginationCredit")]
        public IWebElement OriginationCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbOriginationCharge")]
        public IWebElement OriginationCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbOriginationZero")]
        public IWebElement OriginationZero { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox2")]
        public IWebElement GFE1 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbPointsCredit")]
        public IWebElement PointsCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbPointsCharge")]
        public IWebElement PointsCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbPointsZero")]
        public IWebElement PointsZero { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox3")]
        public IWebElement GFE2 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFLabel1")]
        public IWebElement AdjustedOriginationCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFDropDownList1")]
        public IWebElement GFE3ChgProcessType { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox4")]
        public IWebElement GFE4 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox5")]
        public IWebElement GFE5 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFLabel2")]
        public IWebElement GFE3total { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFDropDownList2")]
        public IWebElement GFE6ChgProcessType { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_grdGFE6_grdGFE6")]
        public IWebElement GFE6Table { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_grdGFE3_grdGFE3")]
        public IWebElement GFE3Table { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFLabel3")]
        public IWebElement GFE6total { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox6")]
        public IWebElement GFE7 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox7")]
        public IWebElement GFE8 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox8")]
        public IWebElement GFE9 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbInterestCredit")]
        public IWebElement InterestCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbInterestCharge")]
        public IWebElement InterestCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_rbInterestZero")]
        public IWebElement InterestZero { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_Faftextbox9")]
        public IWebElement GFE10 { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFDropDownList3")]
        public IWebElement GFE11ChgProcessType { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_FAFLabel4")]
        public IWebElement GFE11total { get; set; }

        [FindsBy(How = How.Id, Using = "tGFE_tGC_grdGFE11_grdGFE11")]
        public IWebElement GFE11table { get; set; }

        #endregion

       
        public GFEEntryGFE WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GFE4, 10);
            return this;
        }

        /// <summary>
        /// Click on GFE Tab
        /// </summary>
        public void GFETabClick()
        {
            GFEtab.FAClick();
        }

        /// <summary>
        ///  GFE 1 Set
        /// </summary>
        public void GFE1Set(string GFE1Charge)
        {
            
                OriginationCredit.FAClick();
                GFE1.FASetText(GFE1Charge);
        }

        /// <summary>
        ///  GFE 2 Set
        /// </summary>
        public void GFE2Set(string GFE2Charge)
        {
            
                PointsCredit.FAClick();
                GFE2.FASetText(GFE2Charge);
          
        }

        /// <summary>
        /// Verify GFE A 
        /// </summary>
        public bool VerifyGFEA
        {
            get
            {
               
                float originalcharges = float.Parse(AdjustedOriginationCharge.FAGetText().ToString());
                float GFE1Charge = float.Parse(GFE1.FAGetValue().ToString());
                float GFE2Charge = float.Parse(GFE2.FAGetValue().ToString());
                return (originalcharges == GFE1Charge + GFE2Charge);
            }

        }

        /// <summary>
        /// Select GFE3 Process Type 
        /// </summary>
        public void GFE3ChargeProcessType(string GFE3Charge)
        {
            GFE3ChgProcessType.FASetText(GFE3Charge);

        }

        /// <summary>
        /// Select GFE6 Process Type 
        /// </summary>
        public void GFE6ChargeProcessType(string GFE6Charge)
        {
            GFE6ChgProcessType.FASetText(GFE6Charge);

        }

        /// <summary>
        /// Select GFE6 Process Type 
        /// </summary>
        public void GFE11ChargeProcessType(string GFE11Charge)
        {
            GFE11ChgProcessType.FASetText(GFE11Charge);

        }

        /// <summary>
        /// Set GFE4 and GFE5  
        /// </summary>
        public void GFE4andGFE5Set(string GFE4Charge, string GFE5Charge)
        {
            GFE4.FASetText(GFE4Charge);
            GFE5.FASetText(GFE5Charge);

        }


        /// <summary>
        /// Set GFE7,GFE8 and GFE9  
        /// </summary>
        public void GFE7GE8andGFE9Set(string GFE7Charge, string GFE8Charge, string GFE9Charge, string GFE10Charge)
        {
            GFE7.FASetText(GFE7Charge);
            GFE8.FASetText(GFE8Charge);
            GFE9.FASetText(GFE9Charge);
             GFE10.FASetText(GFE10Charge);
        }

        /// <summary>
        ///Verify the entered data under Can Interest Rate rise? fields
        /// </summary>
        public void VerifyGFE7GE8andGFE9Set(string GFE7Charge, string GFE8Charge, string GFE9Charge, string GFE10Charge)
        {

            Support.AreEqual(GFE7Charge, GFE7.FAGetValue());
            Support.AreEqual(GFE8Charge, GFE8.FAGetValue());
            Support.AreEqual(GFE9Charge, GFE9.FAGetValue());
            Support.AreEqual(GFE10Charge, GFE10.FAGetValue());
        }
        public void SetInsuranceDetails(string WndName,string Gab,string ChargeAmt)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(WndName, true, 500);
            FastDriver.FireInsuranceDlg.SwitchToDialogContentFrame();
            FastDriver.FireInsuranceDlg.InsuranceAgentGABcode.FASetText(Gab);
            FastDriver.FireInsuranceDlg.InsuranceAgentFind.FAClick(); 
            FastDriver.FireInsuranceDlg.InsurChargeGfeAmount.FASetText(ChargeAmt);
            FastDriver.FireInsuranceDlg.SwitchToDialogBottomFrame();
            FastDriver.DialogBottomFrame.ClickDone();
        }
    }
    public class GFEEntry : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tGFE_tTS")]
        public IWebElement ToleranceSummary { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement ToleranceSummaryComparisonGFE { get; set; }

        #endregion

        public GFEEntry WaitForScreenToLoad()
        {
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            this.SwitchToContentFrame();
            this.WaitCreation(ToleranceSummary, 10);
            return this;
        }

        public GFEEntry Open()
        {
            FastDriver.LeftNavigation.Navigate<GFEEntry>("Home>Order Entry>GFE Entry");
            this.WaitForScreenToLoad();
            return this;
        }
    }

    public class GFEToleranceSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tGFE_tTS")]
        public IWebElement ToleranceSummaryTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tGFE_tTS_lblTolSum']/table/tbody/tr[1]/td/table")]
        public IWebElement GFEHUDChargesTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tGFE_tTS_lblTolSum']/table/tbody/tr[2]/td/table")]
        public IWebElement ChargesNoIncreaseTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tGFE_tTS_lblTolSum']/table/tbody/tr[3]/td/table")]
        public IWebElement TotalIncreaseTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='tGFE_tTS_lblTolSum']/table/tbody/tr[4]/td/table")]
        public IWebElement ChargesCanChangeTable { get; set; }

        #endregion

        public GFEToleranceSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GFEHUDChargesTable);
            return this;
        }

        public GFEToleranceSummary ToleranceSummaryTabClick()
        {
            ToleranceSummaryTab.FAClick();
            this.WaitForScreenToLoad();
            return this;
        }
    }

    public class InspectionRepairDetailDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement GABName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement EditCont { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "comboFurnishedBy")]
        public IWebElement FurnishedBy { get; set; }

        [FindsBy(How = How.Id, Using = "textWithinDays")]
        public IWebElement WithinDays { get; set; }

        [FindsBy(How = How.Id, Using = "textOrderDate")]
        public IWebElement OrderDate { get; set; }

        [FindsBy(How = How.Id, Using = "textDueDate")]
        public IWebElement DueDate { get; set; }

        [FindsBy(How = How.Id, Using = "textFollowUpDate")]
        public IWebElement FollowUpDate { get; set; }

        [FindsBy(How = How.Id, Using = "textCompleteDate")]
        public IWebElement CompleteDate { get; set; }

        [FindsBy(How = How.Id, Using = "textReportDate")]
        public IWebElement ReportDate { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement GFE6Amount { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement GFE3Amount { get; set; }

        #endregion
       
        public InspectionRepairDetailDlg WaitForScreenToLoad(string windowName)
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 500);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(GABcode);

            return this;
        }
    }
    public class FireInsuranceDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement InsuranceAgentCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement InsuranceAgentGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement InsuranceAgentFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement InsuranceAgentGAbName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement InsuranceAgentEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement InsuranceAgentPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement InsuranceAgentFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement InsuranceAgentCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement InsuranceAgentPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement InsuranceAgentEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement InsuranceAgentWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement InsuranceAgentcomboAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement InsuranceAgentEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement InsuranceAgenttextName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement InsuranceAgentReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement UnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement UnderWriterGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement UnderWriterFind { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement UnderWriterGABName { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement UnderWriterEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement UnderWriterBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement UnderWriterBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement UnderWriterCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement UnderWriterPager { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement UnderWriterEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement UnderWriterWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement UnderWriterAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement UnderWriterEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement UnderWriterName { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement UnderWriterReference { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement optIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement optIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement Premium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement Impound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement Term { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement optYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement optMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement InsurChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement InsurChargeBuyCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement InsurChargeSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement InsurChargeGfeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement UnderWriterCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement DayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement ProrationAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement Proration1FromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement Inclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement fromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement BasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement Per { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement ToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement toInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement toProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement ProrationDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement ProrationBuyCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement ProrationBuyCredit { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement ProrationSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement ProrationSellerCredit { get; set; }

        #endregion

    }
    public class SurveyDetailDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement GABName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "txtSurveyDetail")]
        public IWebElement SurveyDetail { get; set; }

        [FindsBy(How = How.Id, Using = "cg_btnPayment")]
        public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "cg_dcs_0_tdsc")]
        public IWebElement ChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "cg_dcs_0_tbc")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cg_dcs_0_tsc")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cg_dcs_0_tga")]
        public IWebElement GFE6Amount { get; set; }

        #endregion

    }
    public class InsurancefloodDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement FloodGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement FloodGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement FloodFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement FloodName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement FloodEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement FloodBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement FloodBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement FloodCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement FloodPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement FloodEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement FloodEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement FloodAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement FloodEditNamecheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement FloodEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement FloodReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement FloodUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement FloodGABcodeunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement FloodFindunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement FloodNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement FloodEditnameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement FloodBusPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement FloodBusFaxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement FloodCellPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement FloodPagerunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement FloodEmailAddressunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement FloodEmailStatusunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement FloodAttentionunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement FloodEditNameCheckboxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement FloodEditNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement FloodReferenceunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement FloodoptIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement FloodoptIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement FloodPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement FloodImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement FloodtextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement FloodoptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement FloodoptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement FloodPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement FloodDescriptionInsuranceCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement FloodBuyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement FloodSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement FloodGFE11 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement FloodCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement FloodDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement FloodAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement FloodFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement FloodInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement FloodfromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement FloodBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement FloodPer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement FloodToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement FloodtoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement FloodtoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement FloodDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement FloodBuyercharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement FloodBuyercredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement FloodSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement FloodSellerCredit1 { get; set; }

        #endregion

    }
    public class InsuranceWindDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement WindGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement WindGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement WindFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement WindName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement WindEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement WindBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement WindBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement WindPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement WindPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement WindEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WindEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement WindAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement WindEditNamecheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement WindEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement WindReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement WindUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement WindGABcodeUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement WindFindUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement WindNameUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement WindEditUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement WindBusPhoneUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement WindBusFaxUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement WindCellPhoneUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement WindPagerUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement WindEmailAddressUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement WindEmailStatusUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement WindAttentionUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement WindEditNamecheckboxUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement WindEditNameUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement WindReferenceUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement WindoptIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement WindoptIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement WindtextPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement WindImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement WindtextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement WindoptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement WindoptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement WindPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement WindInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement WindBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement WindBuyerCREDIT { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement WindInsurChargeGfeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement WindCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement WindDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement WindAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement WindFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement WindfromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement WindfromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement WindBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement WindPer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement WindToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement WindtoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement WindtoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement WindDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement WindBuyercharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement Windbuyercredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement WindSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement WindSellerCredit1 { get; set; }

        #endregion

    }
    public class InsuranceEarthDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement EarthGabCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement EarthGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement EarthFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement EarthName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement EarthEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement EarthBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement EarthBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement EarthCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement EarthPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EarthEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement EarthEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement EarthAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EarthEditNamecheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement EarthEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement EarthReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement EarthUnderwriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement EarthGABcodeunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement EarthFindunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement EarthNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement EarthEditunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement EarthBusinessPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement EarthBusinessFaxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement EarthCellPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement EarthPagerunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement EarthEmailAddressunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement EarthEmailStatusunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement EarthAttentionunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement EarthEditNamecheckboxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement EarthEditNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement EarthReferenceunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement EarthIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement EarthIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement EarthtextPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement EarthImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement EarthtextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement EarthYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement EarthMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement EarthPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement EarthInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement EarthBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement EarthSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement EarthInsurChargeGfeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement EarthCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement EarthDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement EarthCalculateAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement EarthCalculateFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement EarthCalculatefromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement EarthCalculatefromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement EarthCalculateBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement EarthCalculatePer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement EarthCalculateToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement EarthCalculatetoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement EarthCalculatetoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement EarthCalculateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement EarthBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement EarthBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement EarthSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement EarthSellerCredit1 { get; set; }

        #endregion

    }
    public class InsuranceOtherDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement OtherGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement OtherGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement OtherFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement OtherName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement OtherEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement OtherBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement OtherBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement OtherCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement OtherPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement OtherEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement OtherEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement OtherAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement OtherEditNamecheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement OtherEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement OthertextReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement OtherUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement OtherGABcodeUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement OtherFindUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement OtherNameUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement OtherEditUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement OtherBusPhoneUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement OtherBusinessFaxUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement OtherCellPhoneUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement OtherPagerUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement OtherEmailAddressUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement OtherEmailStatusUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement OtherAttentionUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement OtherEditNamecheckboxUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement OtherEditNameUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement OtherReferenceUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement OtheroptIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement OtheroptIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement OthertextPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement OtherImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement OthertextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement OtheroptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement OtheroptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement OtherPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement OtherInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement OtherBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement OtherSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement OtherInsurChargeGfeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement OtherCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement OtherDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement OtherAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement OtherFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement OtherfromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement OtherfromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement OtherBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement OtherPer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement OtherToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement OthertoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement OthertoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement OtherDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement OtherBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement OtherBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement OtherSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement OtherSellerCredit1 { get; set; }

        #endregion

    }
    public class InsuranceSummaryDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridOtherInsurance")]
        public IWebElement OtherInsuranceSummaryDlg { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement SummaryEdit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement SummaryRemove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement SummaryNew { get; set; }

        [FindsBy(How = How.Id, Using = "cmdOtherEdit")]
        public IWebElement SummaryEditOther { get; set; }

        [FindsBy(How = How.Id, Using = "cmdOtherDelete")]
        public IWebElement SummaryRemoveOther { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance_7_labelName")]
        public IWebElement Insurancerows { get; set; }

        #endregion

    }
}
