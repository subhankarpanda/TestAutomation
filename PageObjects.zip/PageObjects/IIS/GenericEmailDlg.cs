using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class GenericEmailDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Close { get; set; }

		[FindsBy(How = How.Id, Using = "btnEmail")]
		public IWebElement Forward { get; set; }

        //SRT 08 -  Tushar Shankar
        [FindsBy(How = How.Id, Using = "txtMessage")]
        public IWebElement Message { get; set; }

		#endregion
        public GenericEmailDlg WaitForDialogToLoad(int timeout = 10)
        {
            //WebDriver.WaitForWindowAndSwitch("Generic Email", timeoutSeconds: timeout);
            this.SwitchToDialogContentFrame(switchToFraPageWin:false);
            this.WaitCreation(Forward);

            return this;
        }
	}
}
