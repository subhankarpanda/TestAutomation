using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
namespace FASTSelenium.PageObjects.IIS
{
	public class HUD1PrintOptions : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ucStatmnt_optHUD1")]
		public IWebElement RadiobuttonHUD1 { get; set; }


            [FindsBy(How = How.Id, Using = "ucStatmnt_chkCmbned")]
		public IWebElement CheckBoxCombined { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_optHUD1A")]
		public IWebElement RadiobuttonHUD1A { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_btnTrDates")]
		public IWebElement TermsDates { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkEst")]
		public IWebElement Estimated { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkFinal")]
		public IWebElement Final { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkAmnd")]
		public IWebElement Amended { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkRvised")]
		public IWebElement RevisedAfterSettlement { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkCmbned")]
		public IWebElement Combined { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_ddlCmbned")]
		public IWebElement NumberofCopies { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkSgnCmbned")]
		public IWebElement Signatures { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_btnCS")]
		public IWebElement CheckSpelling { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkEM")]
		public IWebElement HUD1HUD1ASupplementalPageComments { get; set; }

		[FindsBy(How = How.LinkText, Using = "Notice � This Estimated HUD 1 Settlement Statement is subject to changes, corrections or additions at the time of final computation of the HUD 1 Settlement Statement. ")]
		public IWebElement Notice { get; set; }

		[FindsBy(How = How.Id, Using = "ddlLoanType")]
		public IWebElement LoanType { get; set; }

		[FindsBy(How = How.Id, Using = "txtBorrower")]
		public IWebElement BorrowerName { get; set; }

		[FindsBy(How = How.Id, Using = "btnBrwrRfsh")]
		public IWebElement Refresh { get; set; }

		[FindsBy(How = How.Id, Using = "rbCurrAddr")]
		public IWebElement UseCurrentAddress { get; set; }

		[FindsBy(How = How.Id, Using = "rbFwdAddr")]
		public IWebElement UseForwardingAddress { get; set; }

		[FindsBy(How = How.Id, Using = "txtBrrAddr")]
		public IWebElement AddressOfBorrower { get; set; }

		[FindsBy(How = How.Id, Using = "txtSeller")]
		public IWebElement SellerName { get; set; }

		[FindsBy(How = How.Id, Using = "txtSllrAddr")]
		public IWebElement AddressOfSeller { get; set; }

		[FindsBy(How = How.Id, Using = "txtLender")]
		public IWebElement Lender { get; set; }

		[FindsBy(How = How.Id, Using = "btnLndrSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropLoc")]
		public IWebElement PropLocation { get; set; }

		[FindsBy(How = How.Id, Using = "txtStlmntAgnt")]
		public IWebElement SettlementAgent { get; set; }

		[FindsBy(How = How.Id, Using = "txtAgntPhn")]
		public IWebElement SettlementAgentsPhoneNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtSetPlace")]
		public IWebElement PlaceofSettlement { get; set; }

		[FindsBy(How = How.Id, Using = "chkLender801")]
		public IWebElement Line801PrintNewLoanLender { get; set; }

		[FindsBy(How = How.Id, Using = "chkMB801")]
		public IWebElement Line801PrintNewMortgageBroker { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkBuyer")]
		public IWebElement BuyerOnly { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_ddlBuyer")]
		public IWebElement BuyerOnlyNoOfcopies { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkSgnBuyer")]
		public IWebElement BuyerOnlySignature { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkSeller")]
		public IWebElement SellerOnly { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_ddlSeller")]
		public IWebElement SellerOnlyNoOfcopies { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkSgnSeller")]
		public IWebElement SellerOnlySignature { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_ckbCertifSgn")]
		public IWebElement PrintCertigicationSignature { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_ckbEsrwOfcerSgn")]
		public IWebElement PrintCertigicationEscorw { get; set; }

        [FindsBy(How = How.Id, Using = "ucStatmnt_ckbEsrwOfcerSgnImg")]
        public IWebElement PrintCertificationEscorwSgnImg { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chk1100")]
		public IWebElement IncludeSec10001200Itemization { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chk1100Only")]
		public IWebElement Section110ItemizationOnly { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_lblSSMainHeader")]
		public IWebElement HUD_1SettlementStatementSelectionHeader { get; set; }

        [FindsBy(How = How.Id, Using = "ucStatmnt_lblSSCommentHeader")]
		public IWebElement HUD_1SupplementPagecommentHeader { get; set; }

        [FindsBy(How = How.Id, Using = "idTitle")]
		public IWebElement HUD_1HUD_1AHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "New Loan Lenders")]
		public IWebElement NewLoanLendersHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Location")]
		public IWebElement PropertyLocationHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Settlement Agent")]
		public IWebElement SettlementAgentHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Settlement Agent's Phone No.")]
		public IWebElement SettlementAgentsPhoneNoHeader { get; set; }

		[FindsBy(How = How.LinkText, Using = "Place of Settlement")]
		public IWebElement PlaceofSettlementHeader { get; set; }

		[FindsBy(How = How.Id, Using = "btnExpNL")]
		public IWebElement NewLoanLenderHeaderArrow { get; set; }

		[FindsBy(How = How.Id, Using = "Td1")]
		public IWebElement PropertyLocationHeaderArrow { get; set; }

		[FindsBy(How = How.Id, Using = "Td3")]
		public IWebElement SettlementAgentsPhoneNoHeaderArrow { get; set; }

		[FindsBy(How = How.Id, Using = "Td5")]
		public IWebElement PlaceofSettlementHeaderArrow { get; set; }

		[FindsBy(How = How.Id, Using = "dgLoan_0_lblName")]
		public IWebElement NewLoanLenderName { get; set; }

		[FindsBy(How = How.Id, Using = "dgPropLoc_0_lblLine1")]
		public IWebElement PropertyLocationLine1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgSetllPhone_0_lblSAPFileParty")]
		public IWebElement SettlementAgentsPhoneNoFileParty { get; set; }

		[FindsBy(How = How.Id, Using = "dgSetllPhone_0_lblSAPPhone")]
		public IWebElement SettlementAgentsPhoneNoPhNo { get; set; }

		[FindsBy(How = How.Id, Using = "dgPOS_0_lblPOSFileParty")]
		public IWebElement PlaceOfSettlementFirstFileParty { get; set; }

		[FindsBy(How = How.Id, Using = "dgPOS_0_lblPOSName")]
		public IWebElement PlaceOfSettlementFirstFileParty_Name { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkFM")]
		public IWebElement PrintMemoFinal { get; set; }

		[FindsBy(How = How.Id, Using = "cBntExp")]
		public IWebElement HUD1HUD1ASupplPgCmntsexpand { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_chkEM")]
		public IWebElement PrintMemoEstimated { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_lblEStmtDate")]
		public IWebElement EstsettlementDatepane { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_lblStmtDate")]
		public IWebElement SettlementDatepane { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_lblDsbrmtDate")]
		public IWebElement DisbursementDatepane { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_lblBuyer")]
		public IWebElement BorrowerOnlytext { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_txtEM")]
		public IWebElement PrintEstimatedmemotxt { get; set; }

		[FindsBy(How = How.Id, Using = "ucStatmnt_txtFM")]
		public IWebElement PrintFinalmemotxt { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement NewLoanLendersExp { get; set; }

		[FindsBy(How = How.Id, Using = "dgLoan")]
		public IWebElement NewLoanLendersTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnBrrAddrRfsh")]
		public IWebElement BrrwraddrssRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnSlrRfsh")]
		public IWebElement SellerRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "rbSlrCurAddr")]
		public IWebElement SellerCurrentaddress { get; set; }

		[FindsBy(How = How.Id, Using = "rbSlrFwdAddr")]
		public IWebElement Sellerforwardaddress { get; set; }

		[FindsBy(How = How.Id, Using = "btnSllrAddrRfsh")]
		public IWebElement SellerAddrRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnLndrRfsh")]
		public IWebElement LenderrAddrRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnPropLocRfsh")]
		public IWebElement ProplocRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnPropLocSelect")]
		public IWebElement ProplocSelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgPropLoc")]
		public IWebElement ProplocTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnStlmntAgntSelect")]
		public IWebElement SettlementagentSelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgSettlAgent")]
		public IWebElement SettlementagentTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnSAgentRefrsh")]
		public IWebElement SettlementagentRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnAgentPhoneSelect")]
		public IWebElement SettlmntagntphoneSelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgSetllPhone")]
		public IWebElement SettlementagentPhoneTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnAgentPhoneRefresh")]
		public IWebElement SettlementagentPhoneRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnSetPlaceSelect")]
		public IWebElement PlaceofstlmntSelect { get; set; }

		[FindsBy(How = How.Id, Using = "dgPOS")]
		public IWebElement PlaceofstlmntTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnSetPlaceRefresh")]
		public IWebElement PlaceofstlmntRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement _Method { get; set; }

        [FindsBy(How = How.Id, Using = "ucStatmnt_lblAmndDateTime")]
        public IWebElement AmndDateTime { get; set; }

		#endregion

        public HUD1PrintOptions WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TermsDates);
            return this;
        }

        public HUD1PrintOptions Delivery(string method = "Print")
        {
            this.SwitchToContentFrame();
            Method.FASelectItem(method);
            Deliver.FAClick();
            return this;
        }

        public bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }

        public void Open()
        {
            FastDriver.LeftNavigation.Navigate<HUD1PrintOptions>(@"Home>Order Entry>Escrow Closing>HUD-1 Statement").WaitForScreenToLoad();
        }

        /// <summary>
        /// Selects the SS type for delivery.Provide value null for unchecking all options.
        /// </summary>
        /// <param name="SettlementStatementType"></param>
        public void SettlementStatementTypeSelection(string SettlementStatementType)
        {
            if (string.IsNullOrEmpty(SettlementStatementType))
            {
                Reports.TestStep = "Selecting the SS statement type of: " + SettlementStatementType;
            }
            else
            {
                Reports.TestStep = "Unchecking the SS statement type options.";
            }
            this.WaitForScreenToLoad();
            switch (SettlementStatementType)
                {
                case "Final":
                     this.Final.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     break;
                case "Estimated":
                     this.Estimated.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     break; 
                case "FinalWithAmended":
                     this.Final.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     this.Amended.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     break;
                case "EstimatedWithAmended":
                     this.Estimated.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     this.Amended.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     break;
                case "FinalWithRevised":
                     this.Final.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     this.RevisedAfterSettlement.FASetCheckbox(true);
                     this.WaitForScreenToLoad();
                     break;
                default:
                     this.Final.FASetCheckbox(false);
                     this.Estimated.FASetCheckbox(false);
                     this.Amended.FASetCheckbox(false);
                     if (this.RevisedAfterSettlement.IsEnabled())
                         this.RevisedAfterSettlement.FASetCheckbox(false);
                     break;
                }
        }

        public void ClientFormat(bool Combined,bool buyer=false,bool seller=false)
        {
            this.WaitForScreenToLoad();
            this.CheckBoxCombined.FASetCheckbox(Combined);
            this.BuyerOnly.FASetCheckbox(buyer);
            this.SellerOnly.FASetCheckbox(seller);
            
        }
    }
}
