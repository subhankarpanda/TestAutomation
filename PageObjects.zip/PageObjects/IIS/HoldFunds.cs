using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
namespace FASTSelenium.PageObjects.IIS
{
	public class HoldFunds : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "lblSellerRemaining")]
        public IWebElement SellerRemaining { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerTotal")]
        public IWebElement BuyerCurrentHeldTotal { get; set; }

		[FindsBy(How = How.Id, Using = "lblBuyerTotalReleased")]
		public IWebElement SellerCurrentHeldAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "4.00")]
		public IWebElement TotalReleaseForSeller { get; set; }

		[FindsBy(How = How.Id, Using = "txtReason")]
		public IWebElement Reason { get; set; }

		[FindsBy(How = How.Id, Using = "dtDate")]
		public IWebElement Date { get; set; }

		[FindsBy(How = How.Id, Using = "txtDays")]
		public IWebElement ReleaseinDays { get; set; }

		[FindsBy(How = How.Id, Using = "dtDaysOn")]
		public IWebElement DateDaysOn { get; set; }

		[FindsBy(How = How.Id, Using = "idRdbtnBuyer")]
		public IWebElement RadbtnBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "idRdbtnSeller")]
		public IWebElement RadbtnSeller { get; set; }

		[FindsBy(How = How.Id, Using = "chkAgreement")]
		public IWebElement Agreement { get; set; }

		[FindsBy(How = How.Id, Using = "txtBuyerCharge")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "txtSellerCharge")]
		public IWebElement SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "lblActualReleaseDate")]
		public IWebElement ReleaseDate { get; set; }

		[FindsBy(How = How.Id, Using = "btnNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgdHoldFunds")]
		public IWebElement HoldFundTable { get; set; }

        [FindsBy(How = How.Id, Using = "lblS_FHAC")]
        public IWebElement SellerFundsHeld { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement RemainingPane { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_txtGABcode")]
		public IWebElement HoldFundBusPartyGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_cmdFindName")]
		public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "HFBusParty_labelName")]
        public IWebElement GABName { get; set; }

        [FindsBy(How = How.Id, Using = "HFBusParty_labelIdcode")]
        public IWebElement GABCode { get; set; }

        [FindsBy(How = How.Id, Using = "HFBusParty_labelName2")]
        public IWebElement GABNameLine2 { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_txtName")]
		public IWebElement HoldFundBusPartyName { get; set; }

        [FindsBy(How = How.Id, Using = "HFBusParty_txtEnterpriseNum")]
        public IWebElement HoldFundBusEnterpriseNum { get; set; }
        
		[FindsBy(How = How.Id, Using = "HFBusParty_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textBusPhone")]
		public IWebElement HoldFundBusPartytextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_txtExtnPhone")]
		public IWebElement HoldFundBusPartyExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textBusFax")]
		public IWebElement HoldFundBusPartytextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textCellPhone")]
		public IWebElement HoldFundBusPartytextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textPager")]
		public IWebElement HoldFundBusPartytextPager { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textEmailAddress")]
		public IWebElement HoldFundBusPartyextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_chkWeeklyEmailStatus")]
		public IWebElement HoldFundBusPartyeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_comboAttention")]
		public IWebElement HoldFundBusPartycomboAttention { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_chkEdit")]
		public IWebElement HoldFundEditName { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textName")]
		public IWebElement HoldFundBusPartytextName { get; set; }

		[FindsBy(How = How.Id, Using = "HFBusParty_textReference")]
		public IWebElement HoldFundBusPartytextReference { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_btnAdd")]
		public IWebElement HoldFundNewLine { get; set; }

        [FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges")]
        public IWebElement HoldFundChargesTable { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_0_txtDescription")]
		public IWebElement HoldFundChargesDescription1 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_0_txtBuyerCharge")]
		public IWebElement HoldFundBuyerCharge1 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_0_txtSellerCharge")]
		public IWebElement HoldFundSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerTotalReleased")]
        public IWebElement TotalReleasedForSeller { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerTotal")]
        public IWebElement SellerCurrentHeldTotal { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerTotalReleased")]
        public IWebElement TotalReleasedForBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_1_txtDescription")]
		public IWebElement HoldFundChargeDescription2 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_1_txtBuyerCharge")]
		public IWebElement HoldFundBuyerCharge2 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_1_txtSellerCharge")]
		public IWebElement HoldFundSellerCharge2 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_2_txtDescription")]
		public IWebElement HoldFundChargeDescription3 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_2_txtBuyerCharge")]
		public IWebElement HoldFundBuyerCharge3 { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_dgridCharges_2_txtSellerCharge")]
		public IWebElement HoldFundSellerCharge3 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement CheckIssuedImage { get; set; }

		[FindsBy(How = How.LinkText, Using = "HeldAmount: Held Amount is Required")]
		public IWebElement HeldAmountIsRequired { get; set; }

		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement BusOrgIDBussPartyrequired { get; set; }

		[FindsBy(How = How.Id, Using = "HFChargeGrid_lblFooter")]
		public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='__FAFErrorMessageList']/ul/li")]
        public IWebElement MessagePanel { get; set; }

		#endregion

        public HoldFunds Open()
        {
            FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds");
            this.WaitForScreenToLoad();

            return this;
        }

        public HoldFunds WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Reason);

            return this;
        }

        public HoldFunds WaitForDisbursementScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(HoldFundBusPartyGABcode);

            return this;
        }

        public HoldFunds FindGABCode(string gab = "boa")
        {
            this.SwitchToContentFrame();
            HoldFundBusPartyGABcode.FASetText(gab + FAKeys.Tab);
            Find.FAClick();

            return this;
        }

        public HoldFunds AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            return this;
        }

        public HoldFunds UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public HoldFunds EnterDataInSectionHHoldFund()
        {
            SeleniumInternalHelpersSupportLibrary.Reports.TestStep = "Enter Hold Funds";
            FastDriver.HoldFunds.Open();
            FastDriver.HoldFunds.Reason.FASetText("Reason to Hold Fund");
            FastDriver.HoldFunds.ReleaseinDays.FASetText("7");
            FastDriver.HoldFunds.DateDaysOn.FAClick();

            try
            {
                FastDriver.WebDriver.WaitForWindowAndSwitch("Weekend Warning");
                FastDriver.WeekendWarning.SwitchToDialogBottomFrame();
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception)
            {
                Reports.StatusUpdate("No Dialog for Weekend Warning-Continue Test Normally", true);
            }

            FastDriver.HoldFunds.SwitchToContentFrame();
            FastDriver.HoldFunds.WaitForScreenToLoad();
            FastDriver.HoldFunds.RadbtnBuyer.FAClick();
            FastDriver.HoldFunds.BuyerCharge.FASetText("10.99");
            FastDriver.HoldFunds.WaitForScreenToLoad(FastDriver.HoldFunds.New);
            FastDriver.HoldFunds.New.FAClick();
            FastDriver.HoldFunds.FindGABCode("HOLDFUNDS");
            FastDriver.HoldFunds.HoldFundChargesDescription1.FASetText("ChargesFromHoldFund");
            FastDriver.HoldFunds.WaitForScreenToLoad(FastDriver.HoldFunds.HoldFundBuyerCharge1);
            FastDriver.HoldFunds.HoldFundBuyerCharge1.Clear();
            FastDriver.HoldFunds.HoldFundBuyerCharge1.FASetText("5.99");
            FastDriver.BottomFrame.Done();


            return this;
        }
        public HoldFunds NewBtnClick()
        {
            New.FAClick();
            this.WaitForScreenToLoad().WaitCreation(Find);

            return this;
        }
        
	}
}
