using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class HoldFundsSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgGridHoldFunds")]
		public IWebElement SummaryTable { get; set; }

		#endregion

        public HoldFundsSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<HoldFunds>("Home>Order Entry>Escrow Charge Processes>Hold Funds");
            this.WaitForScreenToLoad();

            return this;
        }
        public HoldFundsSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryTable);

            return this;
        }
	}
}
