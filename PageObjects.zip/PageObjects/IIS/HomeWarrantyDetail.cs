using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class HomeWarrantyDetail : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement IDCodeText { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bp_imgRefreshGAB")]
        public IWebElement RefreshGAB { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement EditCont { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
        public IWebElement BusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "txtpaidSeller")]
        public IWebElement paidSeller { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerBroker")]
        public IWebElement PaidBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtPolicyCharge")]
        public IWebElement PolicyCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerBroker")]
        public IWebElement BuyerBroker { get; set; }

        [FindsBy(How = How.Id, Using = "CG1_btnPayment")]
        public IWebElement PaymentDetailsHomeWarrantyCharges { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#CG1_dcs_0_tdsc")]
        public IWebElement HomeWarrantyChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG1_dcs_0_tbc")]
        public IWebElement HomeWarrantyBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG1_dcs_0_tsc")]
        public IWebElement HomeWarrantySellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "btnPayment")]
        public IWebElement PaymentDetailsYearlyCoverage { get; set; }

        [FindsBy(How = How.Id, Using = "btnPayment")]
        public IWebElement PaymentDetailsEarlyCoverage { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbySellerAtClosing")]
        public IWebElement ECBPbySellerAtClosing { get; set; }

        [FindsBy(How=How.Id,Using="txtOthersSeller")]
        public IWebElement ECOtherSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerOthers")]
        public IWebElement DropdownECOtherSeller { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement PPDDone { get; set; }

        [FindsBy(How = How.Id, Using = "txtAmount")]
        public IWebElement Amount { get; set; }

        [FindsBy(How = How.Id, Using = "txtFromDate")]
        public IWebElement FromDate { get; set; }

        [FindsBy(How = How.Id, Using = "chkbxfromInclusive")]
        public IWebElement InclusiveFrom { get; set; }

        [FindsBy(How = How.Id, Using = "txtToDate")]
        public IWebElement ToDate { get; set; }

        [FindsBy(How = How.Id, Using = "chkbxtoInclusive")]
        public IWebElement InclusiveTo { get; set; }

        [FindsBy(How = How.Id, Using = "CG2_dcs_0_tdsc")]
        public IWebElement EarlyCoverageChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG2_dcs_0_tbc")]
        public IWebElement EarlyCoverageBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG2_dcs_0_tsc")]
        public IWebElement EarlyCoverageSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EditNameChk { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusOrgID: Business Party required")]
        public IWebElement BusOrgIDBussPartyrequired { get; set; }

        [FindsBy(How = How.Id, Using = "lblhwChkamount")]
        public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/Images2/ico_checkissued.gif")]
        public IWebElement CheckIssuedImage { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GABIdno { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement GABname { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement GABname2 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress")]
        public IWebElement GABAddress { get; set; }

        [FindsBy(How = How.Id, Using = "CG1_dcs_0_tga")]
        public IWebElement HomeWarrantyLoanEstimateCharge { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#lblhwChkamount img")]
        public IWebElement CheqImage { get; set; }

        [FindsBy(How = How.Id, Using = "CG1_dcs")]
        public IWebElement HomeWarrantyChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG2_dcs")]
        public IWebElement EarlyCoverageWarrantyTable { get; set; }
        #endregion

        public HomeWarrantyDetail WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode, 10);
            return this;
        }

        public HomeWarrantyDetail AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public HomeWarrantyDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public void FindGABCode(string gabcode)
        {
            this.GABcode.FASetText(gabcode);
            this.Find.FAClick();
        }

        public HomeWarrantyDetail SaveAndReloadScreen()
        {
            this.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            this.WaitForScreenToLoad();
            return this;
        }

        public string getHWfullName
        {
            get
            {
                string fullName = (this.GABname.FAGetText() + " " + this.GABname2.FAGetText()).Trim();
                return fullName;
            }
        }

        public HomeWarrantyDetail Open()
        {
            FastDriver.LeftNavigation.Navigate<HomeWarrantyDetail>(@"Home>Order Entry>Escrow Charge Processes>Home Warranty").WaitForScreenToLoad();
            return this;
        }

        public void EnterDataInSectionHHomeWarranty()
        {
            Reports.TestStep = "Enter charge in Home warranty Home Warranty Charges and Early Coverage Charges table.";
            Open();
            FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
            FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", 2000.00, null, 3000.00, null, 444);
            FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", 2000.00, null, 3000.00, null, 222);
            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionHHomeWarranty_HUD()
        {
            Reports.TestStep = "HUD Statement-Enter charge in Home warranty Home Warranty Charges and Early Coverage Charges table.";
            Open();
            FastDriver.HomeWarrantyDetail.FindGABCode("HW1");
            FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.HomeWarrantyChargesTable, "Home Warranty", 2000.00, null, 3000.00, null);
            FastDriver.HomeWarrantyDetail.UpdateCharge(FastDriver.HomeWarrantyDetail.EarlyCoverageWarrantyTable, "Home Warranty - Early Coverage", 2000.00, null, 3000.00, null);
            FastDriver.BottomFrame.Done();
        }
    }
}
