using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class HomeWarrantySummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgHWSummary")]
		public IWebElement SummaryTable { get; set; }

		#endregion

        #region Useful Methods

        public HomeWarrantySummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(New, 10);
            return this;
        }
        #endregion
    }
}
