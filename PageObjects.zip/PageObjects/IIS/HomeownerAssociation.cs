using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Collections.Generic;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class HomeownerAssociation : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement HOA_LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement HOA_LenderName1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#scriptletProration #Table1")]
        public IWebElement HOALienPayoffTable { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdMgmtCoCheck")]
		public IWebElement ManagementCompanyCheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtGABcode")]
		public IWebElement GABcode { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdFindName")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "bp_labelIdcode")]
		public IWebElement IDCodeText { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
		public IWebElement EditCont { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusPhone")]
		public IWebElement BusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusFax")]
		public IWebElement BusFax { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
		public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
		public IWebElement WeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "bp_comboAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textName")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "tblBusPartyDetails")]
		public IWebElement NameText { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "txtAmountDues")]
		public IWebElement AmountDues { get; set; }

		[FindsBy(How = How.Id, Using = "cboPerDie")]
		public IWebElement PerDiem { get; set; }

		[FindsBy(How = How.Id, Using = "cga_btnPayment")]
		public IWebElement AssociationChargePaymentDetails { get; set; }

		[FindsBy(How = How.Id, Using = "cga_dcs_0_tdsc")]
		public IWebElement AssociationChargeDescription { get; set; }

		[FindsBy(How = How.Id, Using = "cga_dcs_0_tbc")]
		public IWebElement AssociationChargeBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_1_tbc")]
        public IWebElement AssociationChargeBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_2_tbc")]
        public IWebElement AssociationChargeBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_3_tbc")]
        public IWebElement AssociationChargeBuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_4_tbc")]
        public IWebElement AssociationChargeBuyerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_5_tbc")]
        public IWebElement AssociationChargeBuyerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_6_tbc")]
        public IWebElement AssociationChargeBuyerCharge6 { get; set; }

		[FindsBy(How = How.Id, Using = "cga_dcs_0_tsc")]
		public IWebElement AssociationChargeSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_1_tsc")]
        public IWebElement AssociationChargeSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_2_tsc")]
        public IWebElement AssociationChargeSellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_3_tsc")]
        public IWebElement AssociationChargeSellerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_4_tsc")]
        public IWebElement AssociationChargeSellerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_5_tsc")]
        public IWebElement AssociationChargeSellerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_6_tsc")]
        public IWebElement AssociationChargeSellerCharge6 { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_btnPayment")]
		public IWebElement ManagementCompanyPaymentDetails { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tdsc")]
		public IWebElement ManagementCompanyChargeDescription { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tbc")]
		public IWebElement ManagementCompanyBuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tsc")]
		public IWebElement ManagementCompanySellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cgHOA_dcs")]
        public IWebElement HOALienPayOffTable { get; set; }

        [FindsBy(How = How.Id, Using = "cgHOA_dcs_0_tbc")]
		public IWebElement HOALienPayoffBuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cgHOA_btnPayment")]
		public IWebElement ProrationPaymentDetails { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
		public IWebElement CreditSeller { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement DayofClosePaidbySeller { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
		public IWebElement ProrationAmount { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
		public IWebElement FromDate { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
		public IWebElement fromInclusive { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
		public IWebElement fromProrate { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
		public IWebElement BasedOn { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
		public IWebElement Per { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
		public IWebElement ToDate { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
		public IWebElement toInclusive { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
		public IWebElement toProrateDate { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
		public IWebElement ProrationDescription { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
		public IWebElement ProrationBuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
		public IWebElement ProrationBuyerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
		public IWebElement ProrationSellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
		public IWebElement ProrationSellerCredit { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src=\"../images/ico_write.gif\"")]
		public IWebElement imagepencil { get; set; }

        [FindsBy(How = How.Id, Using = "cga_lblFooter")]
		public IWebElement CheckAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "A wire has been created for this Payee. The Payee name cannot be changed.")]
		public IWebElement WireIssuedCantchangeBusinessParty { get; set; }

        [FindsBy(How = How.Id, Using = "txtPBbyBuyerAtClosing")]
        public IWebElement AssociationCharge1PBbyBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyOthers")]
        public IWebElement AssociationBuyerCharge1PBbyOther { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOthersBuyer")]
        public IWebElement AssociationBuyerCharge1PBotherDropdown { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement PPDDone { get; set; }

		//TODO: ADD FindsByAttribute
        [FindsBy(How = How.Id, Using = "cgHOA_cBntExp3")]
		public IWebElement HOALienCollapse { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs_0_tga")]
        public IWebElement AssociationChargeLoanEstimate { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cga_lblFooter img")]
        public IWebElement CheckImage { get; set; }

        [FindsBy(How = How.Id, Using = "cga_dcs")]
        public IWebElement AssociationChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs")]
        public IWebElement ManagementCompanyChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessageList { get; set; }

        [FindsBy(How = How.Id, Using = "cga_lblFooter")]
        public IWebElement AssociationChargeCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_lblFooter")]
        public IWebElement ManagementCompanyCheckAmount { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='scriptletProration']/.//table[@id='Table1']")]
        public IWebElement ProrationTable { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtgfeAmount")]
        public IWebElement ProrationLE { get; set; }
        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement LienPayoffBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement LienPayoffSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement HomeOwnerName1 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement HomeOwnerName2 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress")]
        public IWebElement HomeOwnerAddress1 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress2")]
        public IWebElement HomeOwnerAddress2 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelStateAndZip")]
        public IWebElement HomeOwnerAddress3 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        #endregion

        public HomeownerAssociation Open()
        {
            FastDriver.LeftNavigation.Navigate<HomeownerAssociation>("Home>Order Entry>Escrow Charge Processes>Homeowner Association");
            this.WaitForScreenToLoad();

            return this;
        }

        public HomeownerAssociation WaitForScreenToLoad(IWebElement e = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(e ?? GABcode);
            return this;
        }

        public HomeownerAssociation SaveAndReloadScreen()
        {
            FastDriver.BottomFrame.Done();
            FastDriver.HomeownerAssociation.WaitForScreenToLoad();
            return this;
        }

        public HomeownerAssociation FindGABCode(string GABCode, bool WaitForGabCodeLabel = true)
        {
            this.SwitchToContentFrame();
            GABcode.FASetText(GABCode);
            Find.FAClick();
            if(WaitForGabCodeLabel)
                this.WaitForValue(IDCodeText, GABCode);
            return this;
        }

        public void EnterDataInSectionHHOA()
        {
            Reports.TestStep = "Enter charge in Outside Escrow Company Association Charges and Management Company Charges table.";
            Open();
            FastDriver.HomeownerAssociation.FindGABCode("HUDOUTESC1");
            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", 2000.00, null, 3000.00, null, 444);
            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Association Dues", 2000.00, null, 3000.00, null, 333);
            FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Association HOA ADhoc Charges", 2000.00, null, 3000.00, null, 333);

            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", 2000.00, null, 3000.00, null, 222);
            FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Management  HOA Adhoc", 2000.00, null, 3000.00, null, 222);

            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionHHOA_HUD()
        {
            Reports.TestStep = "HUD Statement-Enter charge in Outside Escrow Company Association Charges and Management Company Charges table.";
            Open();
            FastDriver.HomeownerAssociation.FindGABCode("HUDOUTESC1");
            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Transfer Fee", 2000.00, null, 3000.00, null);
            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Association Dues", 2000.00, null, 3000.00, null);
            FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.AssociationChargesTable, "Association HOA ADhoc Charges", 2000.00, null, 3000.00, null);

            FastDriver.HomeownerAssociation.UpdateCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Document Fee", 2000.00, null, 3000.00, null);
            FastDriver.HomeownerAssociation.AddCharge(FastDriver.HomeownerAssociation.ManagementCompanyChargesTable, "Management  HOA Adhoc", 2000.00, null, 3000.00, null);

            FastDriver.BottomFrame.Done();
        }

        public void SetProrarion(ProrationData p)
        {
            this.WaitForScreenToLoad();
            this.CreditSeller.FASetCheckbox(p.CreditSeller);
            this.DayofClosePaidbySeller.FASetCheckbox(p.DayofClosePaidbySeller);
            this.ProrationAmount.FASetText(((Decimal)p.ProrationAmount).ToString("N2"));
            this.FromDate.FASetText(p.FromDate);
            this.fromInclusive.FASetCheckbox(p.fromInclusive);
            this.fromProrate.FASetCheckbox(p.fromProrateDate);
            this.BasedOn.FASelectItem(p.BasedOn);
            this.Per.FASelectItem(p.Per);
            this.ToDate.FASetText(p.ToDate);
            this.toInclusive.FASetCheckbox(p.toInclusive);
            if (p.toInclusive)
            {
                this.WebDriver.HandleDialogMessage(true, true);
                this.WaitForScreenToLoad();
            }
            this.toProrateDate.FASetCheckbox(p.toProrateDate);
            this.ProrationBuyerCharge.FASetText(((Decimal)p.ProrationBuyerCharge).ToString("N2"));
            this.ProrationBuyerCredit.FASetText(((Decimal)p.ProrationBuyerCredit).ToString("N2"));
            this.ProrationSellerCharge.FASetText(((Decimal)p.ProrationSellerCharge).ToString("N2"));
            this.ProrationSellerCredit.FASetText(((Decimal)p.ProrationSellerCredit).ToString("N2"));
            this.ProrationLE.FASetText(((Decimal)p.ProrationUtilityLE).ToString("N2"));
        }

        public Dictionary<string, string> GetAssociateBusinessPartyDtlsOnHOA
        {
            get
            {
                Dictionary<string, string> AssociateBusinessPartyDtlsHOA = new Dictionary<string, string>();
                AssociateBusinessPartyDtlsHOA.Add("BusPhoneHOA", BusPhone.FAGetValue().Trim());
                AssociateBusinessPartyDtlsHOA.Add("BusFaxHOA", BusFax.FAGetValue().Trim());
                AssociateBusinessPartyDtlsHOA.Add("CellPhoneHOA", CellPhone.FAGetValue().Trim());
                AssociateBusinessPartyDtlsHOA.Add("PagerHOA", Pager.FAGetValue().Trim());
                AssociateBusinessPartyDtlsHOA.Add("EmailAddressHOA", EmailAddress.FAGetValue().Trim());
                return AssociateBusinessPartyDtlsHOA;
            }
        }

        public Dictionary<string, string> GetBusinessPartyDtlsOnHOA
        {
            get
            {
                Dictionary<string, string> BusinessPartyDtls = new Dictionary<string, string>();
                BusinessPartyDtls.Add("IDCodeText", IDCodeText.FAGetText().Trim());
                BusinessPartyDtls.Add("HomeOwnerName1", HomeOwnerName1.FAGetText().Trim());
                BusinessPartyDtls.Add("HomeOwnerName2", HomeOwnerName2.FAGetText().Trim());
                BusinessPartyDtls.Add("HomeOwnerAddress1", HomeOwnerAddress1.FAGetText().Trim());
                BusinessPartyDtls.Add("HomeOwnerAddress2", HomeOwnerAddress2.FAGetText().Trim());
                BusinessPartyDtls.Add("HomeOwnerAddress3", HomeOwnerAddress3.FAGetText().Trim());
                return BusinessPartyDtls;
            }
        }

        #region - Useful Methods
        public HomeownerAssociation EditTableCharge(IWebElement table, string chargeDescription, double? buyerCharge = null, double? sellerCharge = null, double? loanEstimate = null, string newDescription = null, bool addNewRow = false)
        {
            
            if (addNewRow)
            {
                table.PerformTableAction(table.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                var chargeElement = table.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                chargeElement.Click();
                chargeElement.FASetText(FAKeys.Tab);
                chargeElement.FASetText(buyerCharge.ToString() + FAKeys.Tab);
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                var chargeElement = table.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                chargeElement.Click();
                chargeElement.FASetText(FAKeys.Tab);
                chargeElement.FASetText(sellerCharge.ToString() + FAKeys.Tab);
                //table.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                //    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                var chargeElement = table.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                chargeElement.Click();
                chargeElement.FASetText(FAKeys.Tab);
                chargeElement.FASetText(loanEstimate.ToString() + FAKeys.Tab);
                //table.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                //    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (newDescription != null)
            {
                table.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, newDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            return this;

        }

        public HomeownerAssociation AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public HomeownerAssociation UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public HomeownerAssociation HOAProrationDetails(string GabCode, HOAProration ProData)
        {
            FastDriver.HomeownerAssociation.Open();
            FastDriver.HomeownerAssociation.FindGABCode(GabCode);
            FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(ProData.CreditSeller);
            FastDriver.HomeownerAssociation.DayofClosePaidbySeller.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.HomeownerAssociation.ProrationAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.HomeownerAssociation.FromDate.FASetText(ProData.FromDate);
            FastDriver.HomeownerAssociation.fromInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.HomeownerAssociation.ToDate.FASetText(ProData.ToDate);
            FastDriver.HomeownerAssociation.toInclusive.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.HomeownerAssociation.WaitForScreenToLoad();
            FastDriver.HomeownerAssociation.fromInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.BottomFrame.Done();


            return this;
        }

        public HomeownerAssociation HOAProrationDetailsMSection(string GabCode, HOAProration ProData)
        {
            FastDriver.HomeownerAssociation.Open();
            FastDriver.HomeownerAssociation.FindGABCode(GabCode);
            FastDriver.HomeownerAssociation.CreditSeller.FASetCheckbox(ProData.CreditSeller);
            FastDriver.HomeownerAssociation.DayofClosePaidbySeller.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.HomeownerAssociation.ProrationAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.HomeownerAssociation.FromDate.FASetText(ProData.FromDate);
            FastDriver.HomeownerAssociation.fromInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.HomeownerAssociation.ToDate.FASetText(ProData.ToDate);
            FastDriver.HomeownerAssociation.toInclusive.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.HomeownerAssociation.WaitForScreenToLoad();
            //FastDriver.HomeownerAssociation.fromInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.HomeownerAssociation.WaitForScreenToLoad();
            FastDriver.HomeownerAssociation.ProrationBuyerCharge.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.HomeownerAssociation.ProrationSellerCharge.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.HomeownerAssociation.ProrationBuyerCredit.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.HomeownerAssociation.ProrationSellerCredit.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();


            return this;
        }

        #endregion
    }

    public class HOAProration
    {
        public string Description = "Association Dues";
        public string prorationType = "NONE";
        public bool CreditSeller;
        public bool DayofClosePaidbySeller;
        public decimal ProrationAmount;
        public string FromDate;
        public bool fromInclusive;
        public bool fromProrateDate;
        public string BasedOn;
        public string Per;
        public string ToDate;
        public bool toInclusive;
        public bool toProrateDate;
        public decimal ProrationBuyerCharge;
        public decimal ProrationBuyerCredit;
        public decimal ProrationSellerCharge;
        public decimal ProrationSellerCredit;
        public decimal ProrationUtilityLE;
    }
}
