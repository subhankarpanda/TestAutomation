using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class HomeownerAssociationSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgHOASummary")]
		public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgHOASummary_1_labelSno")]
        public IWebElement TableRow { get; set; }

		#endregion

        public HomeownerAssociationSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(TableRow, 5);
            return this;
        }

	}
}
