using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class IBAProductTypeInformationDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "lblIBAProductInfo")]
        public IWebElement ProductDescription { get; set; }

        #endregion


        public IBAProductTypeInformationDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ProductDescription);

            return this;
        }

    }
}
