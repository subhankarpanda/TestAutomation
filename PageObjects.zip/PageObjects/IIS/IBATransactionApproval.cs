using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;

namespace FASTSelenium.PageObjects.IIS
{
	public class IBATransactionApproval : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "rblSelect_0")]
		public IWebElement Select_All { get; set; }

		[FindsBy(How = How.Id, Using = "rblSelect_1")]
		public IWebElement Select_None { get; set; }

		[FindsBy(How = How.Id, Using = "btnApprove")]
		public IWebElement Approve { get; set; }

        [FindsBy(How = How.Id, Using = "dgIBAApproval_0_flgApprove")]
		public IWebElement IBAApproval { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAApproval_1_flgApprove")]
		public IWebElement IBAApproval_Next { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAApproval_7_txtAccountBalance")]
		public IWebElement IBAApprovalAccountBalance { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAApproval")]
		public IWebElement TransactionTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAApproval_0_lblTransaction")]
		public IWebElement Transaction { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAApproval_1_lblTransaction")]
		public IWebElement Transaction_NextRowForOpenIBA { get; set; }

		[FindsBy(How = How.Id, Using = "dgIBAApproval_0_lblFileNumber")]
		public IWebElement FileNumber { get; set; }

		#endregion

        public void CheckTransactionaApproval()
        {
            ReadOnlyCollection<IWebElement> tblCells = FastDriver.IBATransactionApproval.TransactionTable.FindElements(By.CssSelector("tr>td>span>span>input"));

            if (tblCells.Count > 0)
            {
                foreach (IWebElement CheckBox in tblCells)
                {
                    if (CheckBox.Displayed)
                    {
                        CheckBox.Click();
                        break;
                    }

                }
            }            
        }
        public IBATransactionApproval WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Select_All);

            return this;
        }
        public IBATransactionApproval Open()
        {
            FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Approval");
            this.WaitForScreenToLoad();
            return this;
        }

        public void WaitForApproveEnabled()
        {

            WebDriverWait Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(10));
            Wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return Approve.Enabled;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }

            });
        
        }

        public void CancelAlert() {
            try
            {
                WebDriver.WaitForAlertToExist(15);
                var alert = WebDriver.SwitchTo().Alert();
                alert.Dismiss();
                WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            }
            catch (Exception)
            {
            }
        }
        public bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
	}
}
