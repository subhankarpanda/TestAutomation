﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class IBATransactionPastBankCutoffTimeDlg : PageObject
    {

        
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgIBACutoffTransactions")]
		public IWebElement TransactionsTable { get; set; }

        #endregion

        public IBATransactionPastBankCutoffTimeDlg WaitForScreenToLoad(string windowName = "IBA Transaction Past Bank Cutoff Time")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(TransactionsTable, 20);

            return this;
        }

        public bool IsDisplayed(string windowName = "IBA Transaction Past Bank Cutoff Time")
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            try
            {
                var WebElement = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".ui-dialog-title");
                var isDisplayed = WebElement.IsDisplayed() && WebElement.FAGetText().Contains(windowName);
                WaitForScreenToLoad();
                return isDisplayed;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
             
        }

    }
}

