using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class IBATransactionStatusDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "lblTransactionStatus")]
		public IWebElement lblTransactionStatus { get; set; }

		#endregion

        public IBATransactionStatusDlg WaitForScreenToLoad(string windowName = "IBA Transaction Status")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(lblTransactionStatus, 20);
            return this;
        }

	}
}
