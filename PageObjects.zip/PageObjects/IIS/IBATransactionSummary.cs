using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class IBATransactionSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtIssueFromDate")]
		public IWebElement IssueFromDate { get; set; }

		[FindsBy(How = How.Id, Using = "txtIssueToDate")]
		public IWebElement IssueToDate { get; set; }

		[FindsBy(How = How.Id, Using = "txtRequestor")]
		public IWebElement Requestor { get; set; }

		[FindsBy(How = How.Id, Using = "comboTransStatus")]
		public IWebElement TransactionStatus { get; set; }

		[FindsBy(How = How.Id, Using = "txtFromAmount")]
		public IWebElement FromAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtToAmount")]
		public IWebElement ToAmount { get; set; }

		[FindsBy(How = How.Id, Using = "txtApprover")]
		public IWebElement Approver { get; set; }

		[FindsBy(How = How.Id, Using = "comboTransType")]
		public IWebElement TransactionType { get; set; }

		[FindsBy(How = How.Id, Using = "txtBeneficiary")]
		public IWebElement Beneficiary { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileNo")]
		public IWebElement FileNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtIBABank")]
		public IWebElement IBABank { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.LinkText, Using = "File #")]
		public IWebElement File { get; set; }

		[FindsBy(How = How.LinkText, Using = "Acct#")]
		public IWebElement Account { get; set; }

		[FindsBy(How = How.LinkText, Using = "Transaction")]
		public IWebElement Transaction { get; set; }

		[FindsBy(How = How.Id, Using = "dgridIBASummary_FAFDatagridHeader1_03")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.LinkText, Using = "Status Date")]
		public IWebElement StatusDate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Amount")]
		public IWebElement Amount { get; set; }

		[FindsBy(How = How.LinkText, Using = "IBA Bank")]
		public IWebElement IBABank_2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridIBASummary_dgridIBASummary")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "dgridIBASummary_0_lblTransactionStatus")]
		public IWebElement CompletedElt { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Completed']")]
        public IWebElement StatusCompleted { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement DeliveryMethod { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        #endregion


        public IBATransactionSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<IBATransactionApproval>("Home>Business Unit Processing>IBA Interface>IBA Transaction Summary");
            this.SwitchToContentFrame();
            return this;
        }
        public IBATransactionSummary WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30); //on some slow environment this dialog stay open for a while need to handle it.

            this.SwitchToContentFrame();
            this.WaitCreation(element ?? IssueFromDate);
            return this;
        }

        public IBATransactionSummary WaitForTransactionTableResults() {
            WebDriverWait Wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(20));
            Wait.Until(d =>{
                this.SwitchToContentFrame();
                return Table.FAGetText().Trim().Replace(" ", "") != "";
            });
            return this;
        }

        public IBATransactionSummary SearchTransactions(string fileNumber = null, string amount = null, string transactionStatus = null, string transactionType = null)
        {
            WaitForScreenToLoad();
            FileNo.FASetText(fileNumber);
            Amount.FASetText(amount);
            TransactionStatus.FASetText(transactionStatus);
            TransactionType.FASetText(transactionType);
            FindNow.FAClick();
            return this;
        }
	}
}
