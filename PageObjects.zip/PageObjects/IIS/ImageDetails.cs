using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ImageDetails : PageObject
	{
		#region WebElements

		//TODO: ADD FindsByAttribute
         [FindsBy(How = How.Id, Using = "pnlImgDetails")]
        public IWebElement Table { get; set; }
        
		#endregion

        public ImageDetails WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            if (Table.IsDisplayed() && Table.Exists())
                this.WaitCreation(element ?? Table);
            return this;
        }
	}
}
