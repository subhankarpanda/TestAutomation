using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class ImageDocDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnImage")]
		public IWebElement ImageDoc { get; set; }

		[FindsBy(How = How.Id, Using = "pubDocument")]
		public IWebElement publishDocument { get; set; }

		[FindsBy(How = How.Id, Using = "chkBuyer")]
		public IWebElement BuyerSignature { get; set; }

		[FindsBy(How = How.Id, Using = "markDraft")]
		public IWebElement markDraft { get; set; }

		[FindsBy(How = How.Id, Using = "chkSeller")]
		public IWebElement SellerSignature { get; set; }

		[FindsBy(How = How.Id, Using = "AddQCClosingReport")]
		public IWebElement AddQCClosingReport { get; set; }

		[FindsBy(How = How.Id, Using = "chkMisc")]
		public IWebElement MiscSignature { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		#endregion

        public ImageDocDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //this.WebDriver.WaitForWindowAndSwitch("Image Doc", true, 15);
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? ImageDoc);

            return this;
        }

        public void Deliver()
        {
            this.WaitForScreenToLoad();
            this.ImageDoc.FAClick();
        }
	}
}
