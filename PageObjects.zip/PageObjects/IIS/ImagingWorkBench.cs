using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Interactions;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System.Drawing;
using AutoIt;
using System;
using FASTSelenium.ImageRecognition;

namespace FASTSelenium.PageObjects.IIS
{
    public class ImagingWorkBench : PageObject
    {
        public ImagingWorkBench()
            : base()
        {
            IRHelpers.InitElements<ImagingWorkBench>(this);
        }

        #region IR Elements | Deployment Items from "ImageRecognition\Media\ImagingWorkbench\"

        [IRFindsBy(URI = "IW_Button_Open.BMP", Width = 100, Height = 100, Text = "Open")]
        public IRButton IROpen { get; set; }

        [IRFindsBy(URI = "IW_Button_Open.BMP", Width = 100, Height = 100, OffsetLeft = 189, OffsetTop = 76, Text = "Open")]
        public IRButton IROpen2 { get; set; }

        [IRFindsBy(URI = "IW_Button_RotateRight.BMP", Width = 100, Height = 100, Text = "Rotate Right")]
        public IRButton IRRotateRight { get; set; }
        
        [IRFindsBy(URI = "IW_Button_RotateRight.BMP", Width = 100, Height = 100, OffsetLeft = 189, OffsetTop = 140, Text = "Rotate Right")]
        public IRButton IRRotateRight2 { get; set; }

        #endregion

        #region WebElements

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Open { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Cut { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement RotateRight { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Move { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement SelectScanner { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement ThumbnailView { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement RotateLeft { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement InvertPage { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Next { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Previous { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement PageView { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement ZoomIn { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement ZoomOut { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement ZoomtoSelection { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement FitToPage { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement RotateCustom { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement SelectDirectory { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Paste { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement Copy { get; set; }

        [FindsBy(How = How.Id, Using = "ImageLib1")]
        public IWebElement ImagingWorkbench { get; set; }


        #endregion

        public ImagingWorkBench WaitForWindowToLoad(IWebElement element = null)
        {
            Playback.Wait(20000);                                                                           //using static wait
            this.SwitchToContentFrame();
            this.WaitForFrameAndSwitch("frmWorkbench");
            this.WaitCreation(element ?? ImagingWorkbench);
            return this;
        }

        public void ClickOpen()
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var firstFrameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;                 // get location of "fraView" frame 
            FastDriver.ImagingWorkBench.WaitForFrameAndSwitch("fraView");
            var secondFrameLoc = FastDriver.WebDriver.FindElement(By.Id("fraPageWin")).Location;              // get location of "fraPageWin" frame
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var thirdFrameLoc = FastDriver.WebDriver.FindElement(By.Id("frmWorkbench")).Location;               // get location of "frmWorkbench" frame
            var OpenButton = new Point(firstFrameLoc.X + secondFrameLoc.X + thirdFrameLoc.X + 28, firstFrameLoc.Y + secondFrameLoc.Y + thirdFrameLoc.Y + 44); // Open button's approximate location 
                       
            Mouse.Move(OpenButton);
            Mouse.Click(OpenButton);                                                                    // click on Open button

            // These code somehow doesn't work, need to look into it later
            //Actions builder = new Actions(FastDriver.WebDriver);
            //builder.MoveToElement(FastDriver.WebDriver.FindElement(By.Id("frmWorkbench")), 23, 44).Click().Build().Perform();

            #region old implementation using IJavaScriptExecutor
            //#region Workaround to click the Open button
            //FastDriver.WebDriver.SwitchTo().DefaultContent();
            //var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;                 // get location of content frame
            //FastDriver.ImagingWorkBench.SwitchToContentFrame();
            //var OpenButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 22, GetImagingWorkBenchTopAbsolutePosition() + 48);
            //Mouse.Move(OpenButton);                                                                    // click on Open button
            //Mouse.Click(OpenButton);                                                                    // click on Open button
            //#endregion
            //Report.UpdateLog(WebDriver, "Click 'Open' Button", "", () =>
            //{
            //    AutoItX.WinActivate("FAST");
            //    AutoItX.ControlClick("[REGEXPTITLE:(.* FAST .*)]", "", "[CLASS:ToolbarWindow32;INSTANCE:7]", "left", 1, 12);
            //});
            #endregion
        }

        public void ClickOpenAutoItx()
        {
            Playback.Wait(3000);
            AutoItX.ControlClick("[REGEXPTITLE:(.* FAST .*)]", "", "[CLASS:ToolbarWindow32; INSTANCE:8]", "left", 1, 5, 5);
            AutoItX.ControlCommand("[REGEXPTITLE:(.* FAST .*)]", "", "[CLASS:ToolbarWindow32; INSTANCE:8]", "SendCommandID", "101");
            AutoItX.ControlClick("[regexptitle:(.* fast .*)]", "", "[class:toolbarwindow32; instance:8]", "left", 1, 5, 230);
            Playback.Wait(3000);
        }

        public void ClickRotateRight()
        {
            #region Workaround to click the RotateRight button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var RotateRightButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 26, GetImagingWorkBenchTopAbsolutePosition() + 110);
            Mouse.Move(RotateRightButton);
            Mouse.Click(RotateRightButton);
            #endregion
        }

        public void ClickMoveFile()
        {
            #region Workaround to click the MoveFile button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var MoveFileButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 284, GetImagingWorkBenchTopAbsolutePosition() + 48);
            Mouse.Move(MoveFileButton);
            Mouse.Click(MoveFileButton);
            #endregion
        }

        public void ClickRotateLeft()
        {
            #region Workaround to click the RotateLeft button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var RotateLeftButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 26, GetImagingWorkBenchTopAbsolutePosition() + 70);
            Mouse.Move(RotateLeftButton);
            Mouse.Click(RotateLeftButton);
            #endregion
        }

        public void ClickInvertPage()
        {
            #region Workaround to click the InvertPage button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var InvertPageButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 26, GetImagingWorkBenchTopAbsolutePosition() + 130);
            Mouse.Move(InvertPageButton);
            Mouse.Click(InvertPageButton);
            #endregion
        }
        
        public int GetImagingWorkBenchTopAbsolutePosition() {

            try
            {
                IJavaScriptExecutor Executer = (IJavaScriptExecutor)WebDriver;
                WebDriver.SwitchTo().DefaultContent();
                object TopOffset = (object)Executer.ExecuteScript("return window.document.getElementById('fraView').getBoundingClientRect().top + window.frames['fraView'].document.getElementById('fraPageWin').getBoundingClientRect().top");
                //object TopOffse2 = (object)Executer.ExecuteScript("return window.document.getElementById('fraView').getBoundingClientRect().top + window.frames['fraView'].document.getElementById('fraPageWin').getBoundingClientRect().top + window.frames['fraView'].frames['fraPageWin'].document.getElementById('frmWorkbench').getBoundingClientRect().top;");
                return Convert.ToInt32(TopOffset);
            }
            catch (InvalidOperationException)
            {
                Support.Fail("Could not get Absolute Top Position on Imaging Workbench screen");
                FastDriver.WebDriver.Quit();
                Support.CloseAllProcessStartingWith("AcroRd"); //close all instances of Adobe Reader
                return -1;
            }

        }

        public int GetImagingWorkBenchLeftAbsolutePosition()
        {
            try
            {
                IJavaScriptExecutor Executer = (IJavaScriptExecutor)WebDriver;
                WebDriver.SwitchTo().DefaultContent();
                object LeftOffset = (object)Executer.ExecuteScript("return window.document.getElementById('fraView').getBoundingClientRect().left + window.frames['fraView'].document.getElementById('fraPageWin').getBoundingClientRect().left");
                //object LeftOffset = (object)Executer.ExecuteScript("return window.document.getElementById('fraView').getBoundingClientRect().left + window.frames['fraView'].document.getElementById('fraPageWin').getBoundingClientRect().left + window.frames['fraView'].frames['fraPageWin'].document.getElementById('frmWorkbench').getBoundingClientRect().left;");
                return Convert.ToInt32(LeftOffset) + 10; //Adding 10 considering the new margin introduced in ~10.3
            }
            catch (InvalidOperationException)
            {
                Support.Fail("Could not get Absolute Left Position on Imaging Workbench screen");
                FastDriver.WebDriver.Quit();
                Support.CloseAllProcessStartingWith("AcroRd"); //close all instances of Adobe Reader
                return -1;
            }
        }

        public void ClickSelectScanner()
        {
            #region Workaround to click the Select Scanner button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var SelectScannerButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 239, GetImagingWorkBenchTopAbsolutePosition() + 45);
            Mouse.Move(SelectScannerButton);
            Mouse.Click(SelectScannerButton);
            #endregion
        }

        public void ClickThumbnailView()
        {
            #region Workaround to click the ClickThumbnailView button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var ThumbnailViewButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 26, GetImagingWorkBenchTopAbsolutePosition() + 268);
            Mouse.Move(ThumbnailViewButton);
            Mouse.Click(ThumbnailViewButton);
            #endregion
        }

        public void ClickCut()
        {
            #region Workaround to click the ClickCut button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var CutButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 49, GetImagingWorkBenchTopAbsolutePosition() + 45);
            Mouse.Move(CutButton);
            Mouse.Click(CutButton);
            #endregion
        }

        public void ClickRotateCustom(string angle)
        {
            #region Workaround to click the RotateLeft button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var RotateCustomButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 26, GetImagingWorkBenchTopAbsolutePosition() + 88);
            Mouse.Move(RotateCustomButton);
            Mouse.Click(RotateCustomButton);

            AutoItX.WinWait("Rotate Custom", "", 10);
            AutoItX.WinActivate("Rotate Custom", "");
            
            AutoItX.ControlSetText("Rotate Custom", "", "[CLASS:ThunderRT6TextBox;INSTANCE:1]", angle);
            AutoItX.ControlClick("Rotate Custom", "", "[CLASS:ThunderRT6CommandButton;TEXT:OK]", "left", 1,1,1);
            
            #endregion
    }

        public void ClickCopy()
        {
            #region Workaround to click the ClickCut button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var CopyButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 80, GetImagingWorkBenchTopAbsolutePosition() + 45);
            Mouse.Move(CopyButton);
            Mouse.Click(CopyButton);
            #endregion
        }

        public void ClickPasteReplace()
        {
            #region Workaround to click the ClickCut button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var PasteButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 105, GetImagingWorkBenchTopAbsolutePosition() + 45);
            Mouse.Move(PasteButton);
            Mouse.Click(PasteButton);
            Keyboard.SendKeys("{DOWN}");
            Keyboard.SendKeys("{ENTER}");
            #endregion
        }

        public void ClickPasteAppend()
        {
            #region Workaround to click the ClickCut button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var PasteButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 105, GetImagingWorkBenchTopAbsolutePosition() + 45);
            Mouse.Move(PasteButton);
            Mouse.Click(PasteButton);
            Keyboard.SendKeys("{DOWN}");
            Keyboard.SendKeys("{DOWN}");
            Keyboard.SendKeys("{ENTER}");
            #endregion
        }

        public void ClickPasteInsert()
        {
            #region Workaround to click the ClickCut button
            Playback.Wait(20000);                                   //using static wait
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            var frameLoc = FastDriver.WebDriver.FindElement(By.Id("fraView")).Location;
            FastDriver.ImagingWorkBench.SwitchToContentFrame();
            var PasteButton = new Point(GetImagingWorkBenchLeftAbsolutePosition() + 105, GetImagingWorkBenchTopAbsolutePosition() + 45);
            Mouse.Move(PasteButton);
            Mouse.Click(PasteButton);
            Keyboard.SendKeys("{DOWN}");
            Keyboard.SendKeys("{DOWN}");
            Keyboard.SendKeys("{DOWN}");
            Keyboard.SendKeys("{ENTER}");
            #endregion
        }
    }

    public class OpenImageDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Name, Using = "File name:")]
        public IWebElement FileName { get; set; }

        [FindsBy(How = How.Name, Using = "Open")]
        public IWebElement Open { get; set; }

        #endregion

        public OpenImageDlg OpenImage(string fileName)
        {
            Reports.StatusUpdate("Selecting the file in Open Image File Window", true);
            Playback.Wait(3000);
            AutoItX.WinWaitActive(title: "Open Image File", text: "", timeout: 30);
            AutoItX.WinActivate("Open Image File", "");
            AutoItX.ControlSetText("Open Image File", "", "[CLASS:Edit;INSTANCE:1]", fileName);
            AutoItX.ControlClick("Open Image File", "", "[CLASS:Button;TEXT:&Open]");
            AutoItX.WinWaitClose("Open Image File", "", 10);

            return this;
        }

        public OpenImageDlg UploadImage(string fileName)
        {
            Reports.StatusUpdate("Selecting the file in Open Image File Window", true);
            Playback.Wait(1000);
            AutoItX.WinActivate("Choose File to Upload", "");
            AutoItX.ControlSetText("Choose File to Upload", "", "[CLASS:Edit;INSTANCE:1]", fileName);
            Playback.Wait(1000);
            AutoItX.ControlClick("Choose File to Upload", "", "[CLASS:Button;TEXT:&Open]");
            Playback.Wait(1000);
            AutoItX.WinWaitClose("Choose File to Upload", "", 10);
            if (AutoItX.WinActivate("Choose File to Upload", "") != 0) {
                Playback.Wait(1000);
                AutoItX.ControlClick("Choose File to Upload", "", "[CLASS:Button;TEXT:Cancel]");
                AutoItX.WinWaitClose("Choose File to Upload", "", 10);
            }
            return this;
        }
        public OpenImageDlg CancelImage(string fileName)
        {
            Reports.StatusUpdate("Cancelling the Open Image File Window", true);
            Playback.Wait(500);
            AutoItX.WinActivate("Open Image File", "");
            AutoItX.ControlSetText("Open Image File", "", "[CLASS:Edit;INSTANCE:1]", fileName);
            AutoItX.ControlClick("Open Image File", "", "[CLASS:Button;TEXT:Cancel]");
            AutoItX.WinWaitClose("Open Image File", "", 10);

            return this;
        }
    }

    public class SelectScannerDialog : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Name, Using = "Sources:")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Name, Using = "Cancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Name, Using = "Select")]
        public IWebElement Select { get; set; }

        #endregion

    }

    public class RotateCustom : PageObject
    {
        #region WebElements

        [FindsBy(How = How.ClassName, Using = "ThunderRT6TextBox")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Name, Using = "OK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Name, Using = "Cancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "txtRotateBy")]
        public IWebElement RotateTo { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@role='button']//span[text()='OK']")]
        public IWebElement OkButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@role='button']//span[text()='Cancel']")]
        public IWebElement CancelButton { get; set; }

        #endregion

        public RotateCustom WaitForScreenToLoad(IWebElement element = null)
        {
            this.WaitCreation(element ?? RotateTo);
            return this;
        }

    }

    public class ScanFolder : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Name, Using = "Ok")]
        public IWebElement Ok { get; set; }

        [FindsBy(How = How.Name, Using = "Cancel")]
        public IWebElement Cancel { get; set; }

        #endregion

    }

    public class Paste : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Name, Using = "Paste Replace")]
        public IWebElement PasteReplace { get; set; }

        [FindsBy(How = How.Name, Using = "Paste Append")]
        public IWebElement PasteAppend { get; set; }

        [FindsBy(How = How.Name, Using = "Paste Insert")]
        public IWebElement PasteInsert { get; set; }

        #endregion

    }
}
