using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using AutoIt;
using System;
using System.Collections.ObjectModel;

namespace FASTSelenium.PageObjects.IIS
{
    public class ImagingWorkBenchNonActiveX : PageObject
    {

        #region WebElements

        #region File
        [FindsBy(How = How.XPath, Using = "//img[@src='../images/scanner_2.png']")]
        public IWebElement NewScan { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.LoadScanners();']")]
        public IWebElement Source { get; set; }

        [FindsBy(How = How.Id, Using = "openFileImage")]
        public IWebElement Open { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.SaveTiff()']")]
        public IWebElement Save { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.Delete()']")]
        public IWebElement Delete { get; set; }
        #endregion

        #region Zoom
        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.ZoomInOut(true);']")]
        public IWebElement ZoomIn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.ZoomInOut(false);']")]
        public IWebElement ZoomOut { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.FitToPage();']")]
        public IWebElement FitToPage { get; set; }
        #endregion

        #region Pages

        [FindsBy(How = How.Id, Using = "txtMoveToPage")]
        public IWebElement MoveToPageNumber { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtMoveToPage']/parent::")]
        public IWebElement MoveToPageButton { get; set; }

        [FindsBy(How = How.Id, Using = "imgCurrentPage")]
        public IWebElement CurrentPage { get; set; }

        [FindsBy(How = How.Id, Using = "imgTotalPage")]
        public IWebElement TotalPage { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@onclick='ScanManager.MoveTo(false,this)']")]
        public IWebElement MoveToPrev { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[@onclick='ScanManager.MoveTo(true,this)']")]
        public IWebElement MoveToNext { get; set; }

        #endregion

        #region Rotate

        [FindsBy(How = How.XPath, Using = "//div[contains(@onclick, 'Rotate')]")]
        public IWebElement Rotate90Degrees { get; set; }

        [FindsBy(How = How.Id, Using = "rotateCustomDialog")]
        public IWebElement RotateCustom { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@onclick, 'FlipHorizontal')]")]
        public IWebElement FlipHorizontal { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@onclick, 'FlipVertical')]")]
        public IWebElement FlipVertical { get; set; }

        #endregion

        #region Edit
        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.InvertImage()']")]
        public IWebElement InvertImage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.RemoveBorder()']")]
        public IWebElement RemoveBorder { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.SetFrom(false)']")]
        public IWebElement Cut { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.SetFrom(true)']")]
        public IWebElement Copy { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.Paste()']")]
        public IWebElement Paste { get; set; }
        #endregion

        #region Views
        [FindsBy(How = How.XPath, Using = "//div[contains(@onclick, 'Standard')]")]
        public IWebElement StandardView { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@onclick, 'Thumbnail')]")]
        public IWebElement ThumbnailView { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@onclick, 'Canvas')]")]
        public IWebElement CanvasView { get; set; }
        #endregion

        #region Print
        [FindsBy(How = How.XPath, Using = "//div[@onclick='ScanManager.PrintTiff()']")]
        public IWebElement Print { get; set; }
        #endregion

        [FindsBy(How = How.CssSelector, Using = "#scanPreviewArea")]
        public IWebElement PreviewDocumnetList { get; set; }

        [FindsBy(How = How.Id, Using = "scanPreviewArea")]
        public IWebElement PreviewArea { get; set; }
        #endregion

        public ImagingWorkBenchNonActiveX WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToImageWorkbenchFrame();
            this.WaitCreation(element ?? Open);
            return this;
        }
      
        public ImagingWorkBenchNonActiveX OpenImage(string fileName)
        {
            Reports.StatusUpdate("Selecting the file in Open Image File Window", true);
            Playback.Wait(3000);
            AutoItX.WinWaitActive(title: "Choose File to Upload", text: "", timeout: 30);
            AutoItX.WinActivate("Choose File to Upload", "");
            AutoItX.ControlSetText("Choose File to Upload", "", "[CLASS:Edit;INSTANCE:1]", fileName);
            AutoItX.ControlClick("Choose File to Upload", "", "[CLASS:Button;TEXT:&Open]");
            AutoItX.WinWaitClose("Choose File to Upload", "", 10);

            return this;
        }

        public IWebElement GetThumbnail(int pageNumber)
        {
            try
            {
                return FastDriver.WebDriver.FAFindElement(ByLocator.XPath, string.Format("//ul[@id='scanPreviewArea']//span[text()='{0}']/../img", pageNumber));

            }
            catch
            {
                throw new Exception(string.Format("A thumbnail with page number {0} could not be found.", pageNumber));
            }
            
        }

        public int GetPageCount()
        {
            ReadOnlyCollection<IWebElement> thumbnails = PreviewArea.FindElements(By.XPath("//ul[@id='scanPreviewArea']//span"));
            return thumbnails.Count;
        }

        public bool IsDocumentLoaded() {
            return GetPageCount() != 0;
        }
    }
}





