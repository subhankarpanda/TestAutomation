using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class IncomingWires : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboBankAccounts")]
		public IWebElement Select_BankAcct { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Select_Method { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "IssueDateFrom")]
		public IWebElement IssueDateFrom { get; set; }

		[FindsBy(How = How.Id, Using = "IssueDateTo")]
		public IWebElement IssueDateTo { get; set; }

		[FindsBy(How = How.Id, Using = "cboStatus")]
		public IWebElement Select_Status { get; set; }

        [FindsBy(How = How.Id, Using = "cboIWType")]
		public IWebElement Select_ItemType { get; set; }

		[FindsBy(How = How.Id, Using = "AmountFrom")]
		public IWebElement AmountFrom { get; set; }

		[FindsBy(How = How.Id, Using = "AmountTo")]
		public IWebElement AmountTo { get; set; }

		[FindsBy(How = How.Id, Using = "btnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "btnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "btnViewDetails")]
		public IWebElement ViewDetails { get; set; }

		[FindsBy(How = How.Id, Using = "btnExclude")]
		public IWebElement ExcludeRecover { get; set; }

		[FindsBy(How = How.Id, Using = "btnReceiptToFile")]
		public IWebElement ReceiptToFile { get; set; }

		[FindsBy(How = How.Id, Using = "btnTransfer")]
		public IWebElement Transfer { get; set; }

		[FindsBy(How = How.Id, Using = "btnReturnWire")]
		public IWebElement ReturnWire { get; set; }

		[FindsBy(How = How.Id, Using = "dgIncomingWire_dgIncomingWire")]
		public IWebElement SearchResults { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@name='dgIncomingWire_dgIncomingWire']/tbody/tr/td/table")]
        public IWebElement SearchResultsHeader { get; set; }

		#endregion

        #region Recursive Methods

        public IncomingWires WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SearchResults);
            return this;
        }
        #endregion

    }
}
