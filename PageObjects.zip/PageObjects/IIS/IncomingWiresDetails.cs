using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class IncomingWireViewDetails : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Method { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "tblIncomingWireDetail")]
		public IWebElement ViewDetailsTable { get; set; }

		#endregion

        #region Useful Methods
        public IncomingWireViewDetails WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Deliver);
            return this;
        }
        #endregion
    }
}
