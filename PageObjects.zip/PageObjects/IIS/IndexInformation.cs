using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class IndexInformation : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtFileNum")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileNum")]
		public IWebElement FileNumber1 { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileNum")]
		public IWebElement FileNumber2 { get; set; }

        [FindsBy(How = How.Id, Using = "btnLookup")]
        public IWebElement Lookup { get; set; }

		[FindsBy(How = How.Id, Using = "btnOK")]
		public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement CancelQ { get; set; }

        [FindsBy(How = How.ClassName, Using = "cError")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.LinkText, Using = "44577")]
		public IWebElement FileNumberDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Buyer1Firstname Buyer1Lastname")]
		public IWebElement BuyerNameDetails { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement SellerNameDetails { get; set; }

		//TODO: ADD FindsByAttribute
        [FindsBy(How = How.TagName, Using = "TABLE")]
		public IWebElement IndexInfoTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@id='tblFileInfo']/table")]
        public IWebElement FileInfoTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@id='tblError']/table/tbody/tr/td")]
        public IWebElement ErrorMsg { get; set; }

		#endregion

        #region services

        public IndexInformation WaitForWindowToLoad()
        {
            try
            {
                WebDriver.WaitForWindowAndSwitch("Index Information", true, 5);
                this.SwitchToDialogContentFrame();
                FastDriver.WebDriver.SwitchTo().Frame(0);
                this.WaitCreation(FileNumber,true);
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return this;
        }

        public IndexInformation WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FileNumber);
            return this;
        }

        public void VerifyFileNumberAndMove(string fileName,bool FileDetailsAvailable = false)
        {
            try
            {
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                WebDriver.WaitForWindowAndSwitch("Index Information", true, 5);
                this.SwitchToDialogContentFrame();
                FastDriver.WebDriver.SwitchTo().Frame(0);
                FileNumber.FASetText(fileName);
                Lookup.SendKeys(Keys.Return);
                this.WaitCreation(FileNumber, true);
                Playback.Wait(10000);
                if(ErrorMessage.IsVisible())
                {
                    Reports.Equals(ErrorMessage.Text, "Invalid File Number");
                    Reports.StatusUpdate("Invalid File Number. Clicking Cancel.", true);
                    CancelQ.SendKeys(Keys.Return);
                }
                else
                {
                    Reports.StatusUpdate("Valid File Number. Moving the image to " + fileName, true);
                    if (FileDetailsAvailable)
                    {
                        Reports.StatusUpdate("Validating the File no, Buyer, Seller and Property Details", true);
                        Support.AreEqual(fileName, IndexInfoTable.PerformTableAction(4, 2, TableAction.GetCell).Element.Text, "File No");
                        Support.AreEqual("MoveFileBuyer1FN MoveFileBuyer1LN", IndexInfoTable.PerformTableAction(6, 2, TableAction.GetCell).Element.Text, "Buyer Name");
                        Support.AreEqual("MoveFileSeller1FN MoveFileSeller1LN", IndexInfoTable.PerformTableAction(7, 2, TableAction.GetCell).Element.Text, "Seller Name");
                        Support.AreEqual("MoveFileJ305\r\nMoveFileJJEJAMQ\r\nMoveFileJJEJAMQ\r\nALBANY, CA", IndexInfoTable.PerformTableAction(8, 2, TableAction.GetCell).Element.Text, "Property Details");
                    }
                    OK.FAClick();
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message,false);
                OK.FAClick();
            }
        }

        public IndexInformation LookUpFile(string filenum)
        {
            WaitForScreenToLoad();
            FileNumber.FASetText(filenum);
            Lookup.FAClick();
            return this;
        }

        public IndexInformation VerifyFileAndMove(string fileNum)
        {
            LookUpFile(fileNum);
            if (ErrorMsg.IsDisplayed())
            {
                Reports.StatusUpdate(string.Format("Search returned: {0}.", ErrorMsg.FAGetText()), true);
            }
            else
            {
                Support.AreEqual(true, FileInfoTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean().Equals(fileNum), string.Format("Verifying if file number {0} was found.", fileNum));
                OK.FAClick();
            }
            

            return this;
        }

        #endregion

    }
}
