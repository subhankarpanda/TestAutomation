using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;

namespace FASTSelenium.PageObjects.IIS
{
	public class InspectionRepairSeptic : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtGABcode")]
		public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusPhone")]
		public IWebElement BusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusFax")]
		public IWebElement BusinessFax { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
		public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
		public IWebElement EmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "bp_comboAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEdit")]
		public IWebElement EditNameCheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textName")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "comboFurnishedBy")]
		public IWebElement FurnishedBy { get; set; }

		[FindsBy(How = How.Id, Using = "textWithinDays")]
		public IWebElement WithinDays { get; set; }

		[FindsBy(How = How.Id, Using = "textOrderDate")]
		public IWebElement OrderDate { get; set; }

		[FindsBy(How = How.Id, Using = "textDueDate")]
		public IWebElement DueDate { get; set; }

		[FindsBy(How = How.Id, Using = "textFollowUpDate")]
		public IWebElement FollowUpDate { get; set; }

		[FindsBy(How = How.Id, Using = "textCompleteDate")]
		public IWebElement CompleteDate { get; set; }

		[FindsBy(How = How.Id, Using = "textReportDate")]
		public IWebElement ReportDate { get; set; }

		[FindsBy(How = How.Id, Using = "CG_btnPayment")]
		public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "txtPBbyBuyerAtClosing")]
        public IWebElement SepticPBbyBuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyOthers")]
        public IWebElement SepticBPbyOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOthersBuyer")]
        public IWebElement DropdownSepticOtherBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement SepticPPDdone { get; set; }

		[FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
		public IWebElement description { get; set; }

		[FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
		public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_1_tbc")]
        public IWebElement buyerCharge1 { get; set; }

		[FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
		public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement LEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
		public IWebElement Non_GFEcharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement InspectionRepairSepticChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement INSP_Septic_LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement INSP_Septic_LenderName1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_lblFooter")]
        public IWebElement CheckAmount { get; set; }

		#endregion

        public InspectionRepairSeptic Open()
        {
            FastDriver.LeftNavigation.Navigate<InspectionRepairOther>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic");
            this.WaitForScreenToLoad();

            return this;
        }

        public InspectionRepairSeptic FindGAB(string gabCode)
        {
            this.GABcode.FASetText(gabCode);
            this.Find.Click();
            this.WaitCreation(GABcodeLabel);

            return this;
        }

        public InspectionRepairSeptic AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public InspectionRepairSeptic UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }


        [FindsBy(How = How.CssSelector, Using = "img[src='../images/ico_write.gif']")]
        public IWebElement PencilIcon { get; set; }

        public InspectionRepairSeptic WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode);
            return this;
        }
        public InspectionRepairSeptic EnterHSectionCharges()
        {
            FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic");
            this.WaitForScreenToLoad();
            FastDriver.InspectionRepairSeptic.FindGAB("HUDPEST001");
            FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, "Septic Inspection", 500.00, null, 600.00, null, 750.00);

            return this;
        }

        public InspectionRepairSeptic EnterHSectionCharges_HUD()
        {
            FastDriver.LeftNavigation.Navigate<InspectionRepairSeptic>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Septic");
            this.WaitForScreenToLoad();
            FastDriver.InspectionRepairSeptic.FindGAB("HUDPEST001");
            FastDriver.InspectionRepairSeptic.UpdateCharge(FastDriver.InspectionRepairSeptic.InspectionRepairSepticChargesTable, "Septic Inspection", 500.00, null, 600.00, null);

            return this;
        }
	}
}
