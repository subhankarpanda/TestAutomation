using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class InspectionRepairSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridInspectionRepair")]
		public IWebElement SummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.LinkText, Using = "#")]
		public IWebElement NO { get; set; }

		[FindsBy(How = How.LinkText, Using = "Name")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.LinkText, Using = "Contact")]
		public IWebElement Contact { get; set; }

		[FindsBy(How = How.LinkText, Using = "Business Phone")]
		public IWebElement BusinessPhone { get; set; }

		[FindsBy(How = How.LinkText, Using = "Business Fax")]
		public IWebElement BusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "labelTitleCount")]
        public IWebElement InstanceCount { get; set; }


        #endregion

        public InspectionRepairSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryTable);
            return this;
        }
	}
}
