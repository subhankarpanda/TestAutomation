using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;

namespace FASTSelenium.PageObjects.IIS
{
	public class Title : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement InspectionRepair_Pest1 { get; set; }

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement InspectionRepair_PestNew { get; set; }

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement Insurance { get; set; }

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement DFSearchResults { get; set; }

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement FileHomepage { get; set; }

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement FASTTransactionSystem { get; set; }

		[FindsBy(How = How.LinkText, Using = "FastWeb")]
		public IWebElement FastWeb { get; set; }

		[FindsBy(How = How.LinkText, Using = "Wintrack")]
		public IWebElement Wintrack { get; set; }

		#endregion

        public void WaitForScreenToLoad()
        {
            FastDriver.WebDriver.SwitchTo().DefaultContent();
        }

        public bool VerifyIfImgExist(string imgName)
        {
            try
            {
                this.WaitForScreenToLoad();
                FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(i => i.Displayed && i.FAGetAttribute("src").Contains(imgName)).Highlight();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

	}
}
