using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;

namespace FASTSelenium.PageObjects.IIS
{
    public class InsuranceSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = "//span[.='TrusteeName 1']")]
        public IWebElement TrusteeName1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Insurance CompanyName 1']")]
        public IWebElement InsuranceCompanyName1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Ronald M. Hankin']")]
        public IWebElement RonaldHankin { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Lenders Advantage']")]
        public IWebElement LendersAdvantage { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Insurance CompanyNam']")]
        public IWebElement InsuranceCompany { get; set; }

        [FindsBy(How = How.Id, Using = "dgridOtherInsurance")]
        public IWebElement OtherInsuranceSummary { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement AgentGabName { get; set; }
        
        [FindsBy(How = How.Id, Using = "bph_labelName")]
        public IWebElement UnderwriterGabName { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement SummaryEdit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement SummaryRemove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement SummaryNew { get; set; }

        [FindsBy(How = How.Id, Using = "cmdOtherEdit")]
        public IWebElement SummaryEditOther { get; set; }

        [FindsBy(How = How.Id, Using = "cmdOtherDelete")]
        public IWebElement SummaryRemoveOther { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance_7_labelName")]
        public IWebElement Insurancerows { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance")]
        public IWebElement FireSummary { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance_5_labelName")]
        public IWebElement Wind { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance_7_labelName")]
        public IWebElement EarthQuake { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance_3_labelName")]
        public IWebElement Flood { get; set; }

        [FindsBy(How = How.Id, Using = "dgridInsurance_1_labelName")]
        public IWebElement Fire { get; set; }

        #endregion

        public InsuranceSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SummaryEdit);
            return this;
        }
        public InsuranceSummary InsuranceSummaryTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "")
        {
            this.WaitCreation(OtherInsuranceSummary);
            OtherInsuranceSummary.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value);
            return this;
        }
        public InsuranceSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance");
            this.WaitForScreenToLoad();

            return this;
        }

        public void VerifyChargeDescription(string InsuranceName, string ChargeDescription, string editorverify)
        {

            switch (InsuranceName.ToUpper())
            {
                case "FIRE":
                    FastDriver.InsuranceFire.Open();
                    if (editorverify.ToUpper() == "VERIFY")
                        Support.AreEqual(ChargeDescription, FastDriver.InsuranceFire.FireDescription.FAGetValue());
                    if (editorverify.ToUpper() == "EDIT")
                    {
                        FastDriver.InsuranceFire.FireDescription.FAClick();
                        FastDriver.InsuranceFire.FireDescription.FASendKeys(ChargeDescription);
                    }
                    break;
                case "EARTHQUAKE":
                    FastDriver.InsuranceEarth.Open();
                    if (editorverify.ToUpper() == "VERIFY")
                        Support.AreEqual(ChargeDescription, FastDriver.InsuranceEarth.EarthCalculateDescription.FAGetValue());
                    if (editorverify.ToUpper() == "EDIT")
                    {
                        FastDriver.InsuranceEarth.EarthCalculateDescription.FAClick();
                        FastDriver.InsuranceEarth.EarthCalculateDescription.FASendKeys(ChargeDescription);
                    }
                    break;
                case "WIND":
                    FastDriver.InsuranceWind.Open();
                    if (editorverify.ToUpper() == "VERIFY")
                        Support.AreEqual(ChargeDescription, FastDriver.InsuranceWind.WindDescription.FAGetValue());
                    if (editorverify.ToUpper() == "EDIT")
                    {
                        FastDriver.InsuranceWind.WindDescription.FAClick();
                        FastDriver.InsuranceWind.WindDescription.FASendKeys(ChargeDescription);
                    }
                    break;
                case "FLOOD":
                    FastDriver.Insuranceflood.Open();
                    if (editorverify.ToUpper() == "VERIFY")
                        Support.AreEqual(ChargeDescription, FastDriver.Insuranceflood.FloodDescription.FAGetValue());
                    if (editorverify.ToUpper() == "EDIT")
                    {
                        FastDriver.Insuranceflood.FloodDescription.FAClick();
                        FastDriver.Insuranceflood.FloodDescription.FASendKeys(ChargeDescription);
                    }
                    break;
            }


        }
    }

    public class InsuranceFire : PageObject
    {
        public InsuranceFire Open()
        {
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance");
            FastDriver.InsuranceSummary.Fire.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            this.WaitForScreenToLoad();

            return this;
        }

        public InsuranceFire WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FireGABcode);
            return this;
        }

        public InsuranceFire FindGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify either a GAB code or a GAB name to search for a GAB");
            }
            FireGABcode.FASetText(GABCode);
            FireName.FASetText(GABName);
            FireFind.FAClick();
            return this;
        }

        public InsuranceFire FindUnderwriterGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify either a GAB code or a GAB name to search for a GAB");
            }
            FireGABcodeunderwriter.FASetText(GABCode);
            FireNameunderwriter.FASetText(GABName);
            FireFindunderwriter.FAClick();
            return this;
        }

        public void FireProrationDetails(Insurance ProData)
        {
            FastDriver.InsuranceFire.Open();
            FastDriver.InsuranceFire.FindGAB("FIREINSURE");
            FastDriver.InsuranceFire.WaitForScreenToLoad();
            FastDriver.InsuranceFire.FireCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.InsuranceFire.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.InsuranceFire.FireAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.InsuranceFire.FireFromDate.FASetText(ProData.FromDate);
            FastDriver.InsuranceFire.FirefromInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.InsuranceFire.FireToDate.FASetText(ProData.ToDate);
            FastDriver.InsuranceFire.FiretoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.InsuranceFire.WaitForScreenToLoad();
            FastDriver.InsuranceFire.FiretoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.InsuranceFire.FireBuyerCharge1.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.InsuranceFire.FireSellerCharge1.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.InsuranceFire.FireBuyerCredit1.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.InsuranceFire.FireSellerCredit1.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();

        }

        #region WebElements

        [FindsBy(How = How.Id, Using = "Table1")]
        public IWebElement FireProrationTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG_lblFooter")]
        public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "bph_labelAddress")]
        public IWebElement FireUnderwriterAddressLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bph_labelName")]
        public IWebElement FireUnderwriterNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bph_labelIdcode")]
        public IWebElement FireUnderwriterIDCodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement FireAgentNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress")]
        public IWebElement FireAgentAddressLabel { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement InsuranceChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement FireGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement FireGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement FireFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement FireName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement FireEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement FireGABLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement FireBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement FireBusinesFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement FireCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement FirePager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement FireEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement FireEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement FireAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement FireEditNameCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement FireEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement FireReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement FireUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement FireGABcodeunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement FireFindunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement FireNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement FireEditnameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement FireBusinessPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement FireBusinessFaxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement FireCellPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement FirePagerunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement FireEmailAddressunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement FireEmailStatusunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement FireAttentionunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement FireEditNamecheckboxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement FireEditNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement FireReferenceUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement FireIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement FireIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement FirePremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement FireImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement FiretextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement FireoptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement FireoptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement FirePaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement FireInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement FireBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement FireSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement FireGFE11 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement FireCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement FireDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement FireAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement FireFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement FirefromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement FirefromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement FireBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement FirePer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement FireToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement FiretoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement FiretoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement FireDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement FireBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement FireBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement FireSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement FireSellerCredit1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='scriptletProration']/.//table[@id='Table1']")]
        public IWebElement ProrationTable { get; set; }

        #endregion

        public InsuranceFire AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys("{TAB}");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            return this;
        }

        public InsuranceFire UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

    }

    public class Insuranceflood : PageObject
    {
        public Insuranceflood Open()
        {
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance");
            FastDriver.InsuranceSummary.Flood.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            this.WaitForScreenToLoad();

            return this;
        }

        public Insuranceflood WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FloodGABcode);
            return this;
        }

        public Insuranceflood FindGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }
            FloodGABcode.FASetText(GABCode);
            FloodName.FASetText(GABName);
            FloodFind.FAClick();
            return this;
        }

        public Insuranceflood FindUnderwriterGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }
            FloodGABcodeunderwriter.FASetText(GABCode);
            FloodNameunderwriter.FASetText(GABName);
            FloodFindunderwriter.FAClick();
            return this;
        }

        public Insuranceflood UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public void FloodProrationDetails(Insurance ProData)
        {
            FastDriver.Insuranceflood.Open();
            FastDriver.Insuranceflood.FindGAB("FLOODINSUR");
            FastDriver.Insuranceflood.WaitForScreenToLoad();
            FastDriver.Insuranceflood.FloodCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.InsuranceFire.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.Insuranceflood.FloodAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.Insuranceflood.FloodFromDate.FASetText(ProData.FromDate);
            FastDriver.Insuranceflood.FloodInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.Insuranceflood.FloodToDate.FASetText(ProData.ToDate);
            FastDriver.Insuranceflood.FloodtoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.Insuranceflood.WaitForScreenToLoad();
            FastDriver.Insuranceflood.FloodtoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.Insuranceflood.FloodBuyercharge1.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.Insuranceflood.FloodSellerCharge1.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.Insuranceflood.FloodBuyercredit1.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.Insuranceflood.FloodSellerCredit1.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();
        }

        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement NameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement FloodGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement FloodGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement FloodFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement FloodGABLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement FloodName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement FloodEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement FloodBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement FloodBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement FloodCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement FloodPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement FloodEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement FloodEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement FloodAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement FloodEditNamecheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement FloodEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement FloodReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement FloodUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement FloodGABcodeunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement FloodFindunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement FloodNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement FloodEditnameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement FloodBusPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement FloodBusFaxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement FloodCellPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement FloodPagerunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement FloodEmailAddressunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement FloodEmailStatusunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement FloodAttentionunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement FloodEditNameCheckboxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement FloodEditNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement FloodReferenceunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement FloodoptIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement FloodoptIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement FloodPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement FloodImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement FloodtextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement FloodoptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement FloodoptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement FloodPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement FloodChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement FloodDescriptionInsuranceCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement FloodBuyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement FloodSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement FloodGFE11 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement FloodCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement FloodDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement FloodAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement FloodFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement FloodInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement FloodfromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement FloodBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement FloodPer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement FloodToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement FloodtoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement FloodtoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement FloodDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement FloodBuyercharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement FloodBuyercredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement FloodSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement FloodSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtgfeAmount")]
        public IWebElement FloodLoanEstimateUnroundedAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement InsuranceChargesTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='scriptletProration']/.//table[@id='Table1']")]
        public IWebElement ProrationTable { get; set; }

        #endregion

    }

    public class InsuranceWind : PageObject
    {
        public InsuranceWind Open()
        {
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance");
            FastDriver.InsuranceSummary.Wind.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            this.WaitForScreenToLoad();

            return this;
        }

        public InsuranceWind WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? WindGABcode);
            return this;
        }

        public InsuranceWind FindGAB(string GABCode = null, string GABName = null)
    {
      if (GABCode == null && GABName == null)
      {
        throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
      }
      WindGABcode.FASetText(GABCode);
      WindName.FASetText(GABName);
      WindFind.FAClick();
      return this;
    }

        public InsuranceWind FindUnderwriterGAB(string GABCode = null, string GABName = null)
    {
      if (GABCode == null && GABName == null)
        {
            throw new ArgumentNullException("Must specify either a GAB name or a GAB code to search for GAB");
        }
        WindGABcodeUnderWriter.FASetText(GABCode);
        WindNameUnderWriter.FASetText(GABName);
        WindFindUnderWriter.FAClick();
        return this;
    }

        public InsuranceWind UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public void WindProrationDetails(Insurance ProData)
        {
            FastDriver.InsuranceWind.Open();
            FastDriver.InsuranceWind.FindGAB("HUDFLINSR1");
            FastDriver.InsuranceWind.WaitForScreenToLoad();
            FastDriver.InsuranceWind.WindCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.InsuranceFire.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.InsuranceWind.WindAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.InsuranceWind.WindFromDate.FASetText(ProData.FromDate);
            FastDriver.InsuranceWind.WindfromInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.InsuranceWind.WindToDate.FASetText(ProData.ToDate);
            FastDriver.InsuranceWind.WindtoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.InsuranceWind.WaitForScreenToLoad();
            FastDriver.InsuranceWind.WindtoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.InsuranceWind.WindBuyercharge1.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.InsuranceWind.WindSellerCharge1.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.InsuranceWind.WindBuyerCREDIT.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.InsuranceWind.WindSellerCredit1.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();
        }

        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement WindGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement WindGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement WindFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement WindGABLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement WindName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement WindEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement WindBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement WindBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement WindPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement WindPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement WindEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement WindEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement WindAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement WindEditNamecheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement WindEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement WindReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement WindUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement WindGABcodeUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement WindFindUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement WindNameUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement WindEditUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement WindBusPhoneUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement WindBusFaxUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement WindCellPhoneUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement WindPagerUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement WindEmailAddressUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement WindEmailStatusUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement WindAttentionUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement WindEditNamecheckboxUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement WindEditNameUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement WindReferenceUnderWriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement WindoptIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement WindoptIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement WindtextPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement WindImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement WindtextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement WindoptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement WindoptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement WindPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "txtPBbyBuyerAtClosing")]
        public IWebElement WindPBbyBuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyOthers")]
        public IWebElement WindBPbyOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOthersBuyer")]
        public IWebElement DropdownWind { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement PPDDone { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement WindChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement WindInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement WindBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement WindSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement WindBuyerCREDIT { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement WindGFE11 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement WindCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement WindDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement WindAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement WindFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement WindfromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement WindfromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement WindBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement WindPer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement WindToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement WindtoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement WindtoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement WindDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement WindBuyercharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement Windbuyercredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement WindSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement WindSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement InsuranceChargesTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='scriptletProration']/.//table[@id='Table1']")]
        public IWebElement ProrationTable { get; set; }


        #endregion

    }
    public class InsuranceEarth : PageObject
    {
        public InsuranceEarth Open()
        {
            FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance");
            FastDriver.InsuranceSummary.EarthQuake.FAClick();
            FastDriver.InsuranceSummary.SummaryEdit.FAClick();
            this.WaitForScreenToLoad();

            return this;
        }

        public InsuranceEarth WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? EarthGABcode);
            return this;
        }

        public InsuranceEarth FindGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }

            EarthGABcode.FASetText(GABCode);
            EarthName.FASetText(GABName);
            EarthFind.FAClick();
            return this;
        }

        public InsuranceEarth FindUnderwriterGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify either a GAB name or a GAB code to search for GAB");
            }
            EarthGABcodeunderwriter.FASetText(GABCode);
            EarthNameunderwriter.FASetText(GABName);
            EarthFindunderwriter.FAClick();
            return this;
        }

        public InsuranceEarth UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        





        public void EarthQuakeProrationDetails( Insurance ProData)
        {
            FastDriver.InsuranceEarth.Open();
            FastDriver.InsuranceEarth.FindGAB("STARTINCO");
            FastDriver.InsuranceEarth.WaitForScreenToLoad();
            FastDriver.InsuranceEarth.EarthCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.InsuranceFire.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.InsuranceEarth.EarthCalculateAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.InsuranceEarth.EarthCalculateFromDate.FASetText(ProData.FromDate);
            FastDriver.InsuranceEarth.EarthCalculatefromInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.InsuranceEarth.EarthCalculateToDate.FASetText(ProData.ToDate);
            FastDriver.InsuranceEarth.EarthCalculatetoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.InsuranceEarth.WaitForScreenToLoad();
            FastDriver.InsuranceEarth.EarthCalculatetoInclusive.FASetCheckbox(ProData.toInclusive);

            FastDriver.InsuranceEarth.EarthBuyerCharge1.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.InsuranceEarth.EarthSellerCharge1.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.InsuranceEarth.EarthBuyerCredit1.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.InsuranceEarth.EarthSellerCredit1.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();
        }


        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement gabLabelName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement gabLabelName1 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement EarthGabCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement EarthGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement EarthFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement EarthGABLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement EarthName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement EarthEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement EarthBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement EarthBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement EarthCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement EarthPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EarthEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement EarthEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement EarthAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EarthEditNamecheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement EarthEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement EarthReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement EarthUnderwriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement EarthGABcodeunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement EarthFindunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement EarthNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement EarthEditunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement EarthBusinessPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement EarthBusinessFaxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement EarthCellPhoneunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement EarthPagerunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement EarthEmailAddressunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement EarthEmailStatusunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement EarthAttentionunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement EarthEditNamecheckboxunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement EarthEditNameunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement EarthReferenceunderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement EarthIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement EarthIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement EarthtextPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement EarthImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement EarthtextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement EarthYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement EarthMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement EarthPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement EarthChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement EarthInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement EarthBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement EarthSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement EarthGFE11 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement EarthCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement EarthDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement EarthCalculateAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement EarthCalculateFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement EarthCalculatefromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement EarthCalculatefromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement EarthCalculateBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement EarthCalculatePer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement EarthCalculateToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement EarthCalculatetoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement EarthCalculatetoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement EarthCalculateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement EarthBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement EarthBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement EarthSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement EarthSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement InsuranceChargesTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='scriptletProration']/.//table[@id='Table1']")]
        public IWebElement ProrationTable { get; set; }

        #endregion

    }

    public class Insurance
    {
        public string Description = "Assumption Loan Interest Proration";
        public string prorationType = "NONE";
        public bool CreditSeller;
        public bool DayofClosePaidbySeller;
        public decimal ProrationAmount;
        public string FromDate;
        public bool fromInclusive;
        public bool fromProrateDate;
        public string BasedOn;
        public string Per;
        public string ToDate;
        public bool toInclusive;
        public bool toProrateDate;
        public decimal ProrationBuyerCharge;
        public decimal ProrationBuyerCredit;
        public decimal ProrationSellerCharge;
        public decimal ProrationSellerCredit;
        public decimal ProrationUtilityLE;
    }

    public class InsuranceOther : PageObject
    {
        public InsuranceOther Open(int index = 0)
        {
            FastDriver.InsuranceSummary.Open();
            FastDriver.WebDriver.FindElement(By.Id("dgridOtherInsurance_" + index)).FAClick();
            FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
            this.WaitForScreenToLoad();

            return this;
        }

        public InsuranceOther WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? OtherGABcode);
            return this;
        }

        public InsuranceOther FindGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }
                
            OtherGABcode.FASetText(GABCode);
            OtherName.FASetText(GABName);
            OtherFind.FAClick();
            return this;
        }

        public InsuranceOther FindUnderwriterGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify either a GAB name or a GAB code to search for GAB");
            }
            OtherGABcodeUnderwriter.FASetText(GABCode);
            OtherNameUnderwriter.FASetText(GABName);
            OtherFindUnderwriter.FAClick();
            return this;
        }

        public InsuranceOther UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public void OtherProrationDetails(Insurance ProData)
        {
            FastDriver.InsuranceOther.FindGAB("FIREINSURE");
            FastDriver.InsuranceOther.WaitForScreenToLoad();
            FastDriver.InsuranceOther.OtherCreditSeller.FASetCheckbox(ProData.CreditSeller);
            //FastDriver.InsuranceFire.cl.FASetCheckbox(ProData.DayofClosePaidbySeller);
            FastDriver.InsuranceOther.OtherAmount.FASetText(ProData.ProrationAmount.ToString());
            FastDriver.InsuranceOther.OtherFromDate.FASetText(ProData.FromDate);
            FastDriver.InsuranceOther.OtherfromInclusive.FASetCheckbox(ProData.fromInclusive);
            FastDriver.InsuranceOther.OtherToDate.FASetText(ProData.ToDate);
            FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.InsuranceOther.WaitForScreenToLoad();
            FastDriver.InsuranceOther.OthertoInclusive.FASetCheckbox(ProData.toInclusive);
            FastDriver.InsuranceOther.OtherBuyerCharge1.FASetText(ProData.ProrationBuyerCharge.ToString());
            FastDriver.InsuranceOther.OtherSellerCharge1.FASetText(ProData.ProrationSellerCharge.ToString());
            FastDriver.InsuranceOther.OtherBuyerCredit1.FASetText(ProData.ProrationBuyerCredit.ToString());
            FastDriver.InsuranceOther.OtherSellerCredit1.FASetText(ProData.ProrationSellerCredit.ToString());

            FastDriver.BottomFrame.Done();

        }

        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement OtherGABCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement OtherGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement OtherFind { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement OtherName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement OtherEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement OtherBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement OtherBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement OtherCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement OtherPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement OtherEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement OtherEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement OtherAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement OtherEditNamecheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement OtherEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement OthertextReference { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdCheckDetails")]
        public IWebElement OtherUnderWriterCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtGABcode")]
        public IWebElement OtherGABcodeUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_cmdFindName")]
        public IWebElement OtherFindUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement OtherGABLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bph_txtName")]
        public IWebElement OtherNameUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEditContactInfo")]
        public IWebElement OtherEditUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusPhone")]
        public IWebElement OtherBusPhoneUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textBusFax")]
        public IWebElement OtherBusinessFaxUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textCellPhone")]
        public IWebElement OtherCellPhoneUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textPager")]
        public IWebElement OtherPagerUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textEmailAddress")]
        public IWebElement OtherEmailAddressUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkWeeklyEmailStatus")]
        public IWebElement OtherEmailStatusUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_comboAttention")]
        public IWebElement OtherAttentionUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_chkEdit")]
        public IWebElement OtherEditNamecheckboxUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textName")]
        public IWebElement OtherEditNameUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "bph_textReference")]
        public IWebElement OtherReferenceUnderwriter { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck1")]
        public IWebElement OtheroptIssuecheck1 { get; set; }

        [FindsBy(How = How.Id, Using = "optIssuecheck2")]
        public IWebElement OtheroptIssuecheck2 { get; set; }

        [FindsBy(How = How.Id, Using = "textPremium")]
        public IWebElement OthertextPremium { get; set; }

        [FindsBy(How = How.Id, Using = "chkImpound")]
        public IWebElement OtherImpound { get; set; }

        [FindsBy(How = How.Id, Using = "textTerm")]
        public IWebElement OthertextTerm { get; set; }

        [FindsBy(How = How.Id, Using = "optYears")]
        public IWebElement OtheroptYears { get; set; }

        [FindsBy(How = How.Id, Using = "optMonths")]
        public IWebElement OtheroptMonths { get; set; }

        [FindsBy(How = How.Id, Using = "CG_btnPayment")]
        public IWebElement OtherPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement OtherInsuranceChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tbc")]
        public IWebElement OtherBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tsc")]
        public IWebElement OtherSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tga")]
        public IWebElement OtherGFE11 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement OtherCreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement OtherDayofClose { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement OtherAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement OtherFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement OtherfromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement OtherfromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement OtherBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement OtherPer { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement OtherToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement OthertoInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement OthertoProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement OtherDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement OtherBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement OtherBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement OtherSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement OtherSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "CG_lblFooter")]
        public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#CG_lblFooter img")]
        public IWebElement IssuedCheckImage { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement PencilIcon { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GabCodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs_0_tdsc")]
        public IWebElement InsuranceChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CG_dcs")]
        public IWebElement InsuranceChargesTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='scriptletProration']/.//table[@id='Table1']")]
        public IWebElement ProrationTable { get; set; }

        #endregion

    }
}
