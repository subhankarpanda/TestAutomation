using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class InterestBearingAccounts : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.LinkText, Using = "Details")]
        public IWebElement Details { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[@title='Transactions']")]
        public IWebElement Transactions { get; set; }

        [FindsBy(How = How.LinkText, Using = "Rates")]
        public IWebElement Rates { get; set; }

        [FindsBy(How = How.Id, Using = "imgCal_tabIBADetails_details_txtFileAlert")]
        public IWebElement Calendar { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_cmdBeneficiary")]
        public IWebElement Beneficiary { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_optSSN")]
        public IWebElement SSN { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_optTIN")]
        public IWebElement TIN { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_txtSSNTIN")]
        public IWebElement SSNTIN { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_btnViewEditSSNTIN")]
        public IWebElement ViewEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_cmdIBABank")]
        public IWebElement IBABank { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_cboIBAType")]
        public IWebElement IBAType { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_cmdProductInfo")]
        public IWebElement ProductInfo { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_txtProductName")]
        public IWebElement ProductName { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_txtAPY")]
        public IWebElement detailsAPY { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_txtFileAlert")]
        public IWebElement DetailsFileAlert { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_chkUpdateTrans")]
        public IWebElement UpdateTransactiontoFSB { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_cmdAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_cmdRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblTransID")]
        public IWebElement TransactionID { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblDocNum")]
        public IWebElement TransactionDocNum { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_txtAmount")]
        public IWebElement TransactionAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_cmdShowStatus")]
        public IWebElement TransactionStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblBeneficiaryName")]
        public IWebElement Buyer1FirseBuyer1Lastname { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblStatus")]
        public IWebElement TransactionStatusComplete { get; set; }

        [FindsBy(How = How.Id, Using = "dgridIBASummary_0_lblStatus")]
        public IWebElement SummaryIBAStatus { get; set; }

        [FindsBy(How = How.Id, Using = "dgridIBASummary_0_lblIBABalance")]
        public IWebElement SummaryIBABalance { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblStatus")]
        public IWebElement TransactionTransactionStatusPane { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblOpenIBADeposit")]
        public IWebElement DetailsOpenIBADeposit { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblTransactionType")]
        public IWebElement Transaction { get; set; }

        // Element might require switching to content frame
        [FindsBy(How = How.XPath, Using = "//div[@id='pnlIBADetails']/div[@id='tabIBADetails_FAFTabContainer']/div[@class='TabControl']/a[@title='Transactions']")]
        public IWebElement TransactionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblBeneficiaryName")]
        public IWebElement DetailsIBABeneficiaryName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridIBASummary_0_lblSNo")]
        public IWebElement SummarySeq { get; set; }

        [FindsBy(How = How.Id, Using = "dgridIBASummary_0_lblBeneficiaryName")]
        public IWebElement SummaryIBABeneficiaryname { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblBankName")]
        public IWebElement DetailsIBABank { get; set; }

        [FindsBy(How = How.Id, Using = "dgridIBASummary_0_lblIBABank")]
        public IWebElement SummaryIBABank { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblBeneficiaryAddress")]
        public IWebElement DetailsBeneficiaryaddressline { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblBeneficiaryCityStateZip")]
        public IWebElement DetailsBeneficiarycitystatezip { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblFileAvailableFund")]
        public IWebElement DetailsFileCurrentavlbfunds { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_details_lblTotalIBADeposits")]
        public IWebElement DetailsTotalIBADeposits { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblNewBalance")]
        public IWebElement TransactionNewBalance { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_0_lblAmount")]
        public IWebElement Amount { get; set; }

        [FindsBy(How = How.Id, Using = "dgridIBASummary_dgridIBASummary")]
        public IWebElement RecordSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_dgridTransactions")]
        public IWebElement TransactionTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_transactions_dgridTransactions_1_txtAmount")]
        public IWebElement PartialWithdrawnAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tabIBADetails_rates_dgridBanks_0_dgridProducts_0_dgridRates")]
        public IWebElement FASTTieredRateProductTable { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement DeliveryMethod { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        #endregion

        public InterestBearingAccounts Open()
        {
            FastDriver.LeftNavigation.Navigate<InterestBearingAccounts>("Home>Order Entry>Escrow Closing>Interest Bearing Accounts");
            this.WaitForScreenToLoad();

            return this;
        }

        public InterestBearingAccounts WaitForScreenToLoad(IWebElement element = null, int timeout = 15)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);

            return this;
        }

        public InterestBearingAccounts clickOnDetailsTab()
        {
            this.SwitchToContentFrame();
            Details.FAClick();
            this.SwitchToContentFrame();

            return this;
        }

        public InterestBearingAccounts clickOnTransactionsTab()
        {
            this.SwitchToContentFrame();
            Transactions.FAClick();
            this.SwitchToContentFrame();

            return this;
        }

        public InterestBearingAccounts clickOnRatesTab()
        {
            this.SwitchToContentFrame();
            Rates.FAClick();
            this.SwitchToContentFrame();

            return this;
        }

        public InterestBearingAccounts WaitForDetailsTabToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Beneficiary, 10);
            return this;
        }

        public InterestBearingAccounts WaitForTransactionsTabToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(TransactionTable, 10);
            return this;
        }

        public InterestBearingAccounts WaitForRatesTabToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(FASTTieredRateProductTable, 10);
            return this;
        }
              
        public InterestBearingAccounts WaitForTransactionCompleted()
        {
            WebDriverWait Wait = new WebDriverWait(WebDriver, TimeSpan.FromMinutes(20));
            try
            {
                Wait.Until(d =>
                {
                    Open();
                    TransactionTab.FAClick();
                    WaitForTransactionsTabToLoad();
                    return FastDriver.InterestBearingAccounts.Add.Enabled;

                });
            }
            catch (WebDriverTimeoutException) {
                Support.Fail("Transaction wasn't marked as completed therefore Add button wasn't enabled, please verify Service.");
            }           

            return this;
        }

        #region Services

        public InterestBearingAccounts VerifyNewButton()
        {
            this.SwitchToContentFrame();

            Report.UpdateLog(New, "Verify", "Exists", "", () =>
            {
                this.WaitCreation(New, 30); //custom wait timeout, to solve the problem when FAST takes too long to load
            });

            return this;
        }
        
        #endregion

    }
}
