using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
	public class InvoiceCommentDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtComment")]
		public IWebElement Comment { get; set; }

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		#endregion

        public InvoiceCommentDlg WaitForDialogToLoad(IWebElement Element = null, string WinName = "Invoice Comment")
        {
            Element = Element ?? Comment;
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                try
                {
                    WebDriver.WaitForWindowAndSwitch(WinName, timeoutSeconds: 120);
                    this.SwitchToDialogContentFrame();
                    return Element.Displayed;
                }
                catch (NoSuchWindowException)
                {
                    return false;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }

            });
            return this;
        }

	}
}
