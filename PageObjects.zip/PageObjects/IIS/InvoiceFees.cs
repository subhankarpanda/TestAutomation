using System;
using System.Threading;
using System.Collections.Generic;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITest.Input;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Windows.Input;
using System.Linq;
using System.Collections.Generic;


namespace FASTSelenium.PageObjects.IIS
{
	public class InvoiceFees : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkFormat")]
		public IWebElement Format { get; set; }

		[FindsBy(How = How.Id, Using = "chkShowAddress")]
		public IWebElement ShowAddress { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdHistory")]
		public IWebElement History { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFinal")]
		public IWebElement Final { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRemove")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEstimate")]
		public IWebElement Estimate { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAddrDetails")]
		public IWebElement AddressDetails { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_0_chkFee")]
		public IWebElement FeeSummarygrid { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_1_chkFee")]
		public IWebElement FeeSummary1Fee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_0_chkFee")]
		public IWebElement Invoicetosummary { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_dgridInvoiceSummary")]
		public IWebElement InvoicetosummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement cboMethod { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_0_lblStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_2_chkFee")]
		public IWebElement FeeSummary2Fee { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary")]
		public IWebElement InvoiceFeeListTable { get; set; }

		[FindsBy(How = How.Id, Using = "tdNotAlloc")]
		public IWebElement InvoiceFeeList { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_0_lblInvoiceAmount")]
		public IWebElement InvoiceTotal { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_0_lblExportDate")]
		public IWebElement ExportRequestDate { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_4_lblDescription")]
		public IWebElement Description4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_4_lblTotalCharge")]
		public IWebElement TotCharge4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_0_lblInvoiceName")]
		public IWebElement InvName { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_0_lblInvoiceNum")]
		public IWebElement InvNum { get; set; }

		[FindsBy(How = How.Id, Using = "dgridInvoiceSummary_0_lblInvoiceAmount")]
		public IWebElement InvAmt { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_1_lblInvoiceNum")]
		public IWebElement InvNum1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridFeeSummary_1_lblInvoiceChargeTo")]
		public IWebElement InvoiceChargeTo1 { get; set; }

        [FindsBy(How = How.Id, Using = "chkSimAdjAmount")]
        public IWebElement DiscloseSimultaneousPolicyamountCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "spnChkSimAdjAmount")]
        public IWebElement DiscloseSimultaneousPolicyAmountText { get; set; }

        [FindsBy(How = How.Id, Using = "chkTitlePrAdj")]
        public IWebElement DiscloseTitlePremiumAdjustmentAmountCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "spnchkTitlePrAdj")]
        public IWebElement DiscloseTitlePremiumAdjustmentAmountText { get; set; }
        [FindsBy(How = How.Id, Using = "dgridFeeSummary_0_lblTotalCharge")]
        public IWebElement TotalCharge { get; set; }
        
		#endregion

        public InvoiceFees WaitForScreenToLoad(IWebElement e = null)
        {
            try
            {
                this.SwitchToContentFrame();
                //e = e ?? InvoiceFeeListTable;
                //this.WaitCreation(e);
                //this.WaitCreation(e ?? InvoiceFeeListTable, timeout);
                if(!this.WaitCreation(e ?? InvoicetosummaryTable))
                {
                    this.SwitchToContentFrame();
                    this.WaitCreation(e ?? InvoicetosummaryTable);
                }
                
            }
            catch
            {
                this.SwitchToContentFrame();
                //e = e ?? InvoiceFeeListTable;
                //this.WaitCreation(e);
                this.WaitCreation(e ?? InvoicetosummaryTable);
            }
            return this;
        }

        public bool FinalizeSelectedFee(string feeDesc)
        {
            Reports.TestStep = "Select the "+ feeDesc+" from the Invoice fee list table and click on final button.";
            bool status = false;
            this.InvoiceFeeListTable.PerformTableAction("Description", feeDesc, "Sel", TableAction.On);
            Support.AreEqual("True", FastDriver.InvoiceFees.Final.Enabled.ToString(), bIgnoreCase: true);
            if(this.Final.Enabled)
            {
                this.Final.FAClick();
                this.WaitForScreenToLoad();
                Reports.TestStep = "Verify the status of the invoice is Finalized.";
                string statusString = this.InvoicetosummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message;
                status = (statusString.Equals("FINAL")) ? true : false;
            }
            else
            {
                Reports.StatusUpdate("Final Button is not enabled", false);
            }
            return status;
        }
        public bool EstimateSelectedFee(string[] feeDesc)
        {
            Reports.TestStep = "Select the fees from the Invoice fee list table and click on estimate button.";
            bool status = false;
            foreach (string desc in feeDesc)
            {
                this.InvoiceFeeListTable.PerformTableAction("Description", desc, "Sel", TableAction.On);
            }
            if (this.Estimate.IsEnabled())
            {
                this.Estimate.FAClick();
                this.WaitForScreenToLoad();
                Thread.Sleep(3000);
                Reports.TestStep = "Verify the status of the invoice is Estimated.";
                string statusString = this.InvoicetosummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message;
                status = (statusString.Equals("ESTIMATED")) ? true : false;
            }
            else
            {
                Reports.StatusUpdate("Estimate Button is not enabled", false);
            }
            return status;
        }
        public bool CancelInvoice(string feeDesc,string expectedStatus)
        {
            bool status = false;
            Reports.TestStep = "Select the " + feeDesc + " from the Invoice fee list table and click on Cancel button.";
            string invoiceID = this.InvoicetosummaryTable.PerformTableAction(1, 2, TableAction.GetText).Message.Trim();
            this.InvoiceFeeListTable.PerformTableAction("Description", feeDesc, "Sel", TableAction.On);
            if (this.Cancel.Enabled)
            {
                this.Cancel.FAClick();
                Reports.TestStep = "Verify the message on cancelling the invoice";
                Support.AreEqual("Do you wish to cancel invoice " + invoiceID + "?", FastDriver.WebDriver.HandleDialogMessage());
                this.WaitForScreenToLoad();
                Reports.TestStep = "Verify the status of the invoice is Cancelled.";
                string statusString = this.InvoicetosummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message;
                status = (statusString.Equals(expectedStatus)) ? true : false;
            }
            else
            {
                Reports.StatusUpdate("Cancel Button is not enabled", false);
            }
            return status;
        }

        public void PerformDelivery(string deliveryMethod)
        {
            Reports.TestStep = "Perfom the " + deliveryMethod + " delivery method.";
            this.cboMethod.FASelectItem(deliveryMethod);
            FastDriver.FileFees.Deliver.FAClick();
           
            switch (deliveryMethod)
            {
                case "Email":
                    {
                        FastDriver.EmailDlg.WaitForDialogToLoad();
                        FastDriver.EmailDlg.SendEmail();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Print":
                    {
                        if (!isAlertPresent())
                        {
                       // FastDriver.WebDriver.WaitForWindowAndSwitch(windowName: "Print", timeoutSeconds: 20);
                        FastDriver.PrintDlg.SelectPrinter();
                        FastDriver.PrintDlg.ClickPrint();
                        HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 200 ? 200 : int.Parse(AutoConfig.WaitTime) * 3);
                        }
                    else
                    {
                        Reports.StatusUpdate("Printer is not configured correctly", false);
                    }
                        break;
                    }
                case "Fax":
                    {
                        FastDriver.FaxDlg.WaitForScreenToLoad();
                        FastDriver.FaxDlg.SendFax();
                        FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        break;
                    }
                case "Preview":
                    {
                        //FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, 200);
                        if (HandleDeliveryFailure(deliveryMethod, int.Parse(AutoConfig.WaitTime) * 3 > 250 ? 250 : int.Parse(AutoConfig.WaitTime) * 3))
                        {
                            Reports.TestStep = "Save PDF file";
                            string tempPdfFile = @"C:\Temp\temp.PDF";
                            SavePDFFile(tempPdfFile);
                            
                        }                        
                        break;
                    }
                    
            }
           
            this.WaitForScreenToLoad();
        }

        public InvoiceFees Delivery(string method)
        {
            cboMethod.FASelectItem(method);
            Deliver.FAClick();
            return this;
        }

        public List<string> GetExportRequestDate()
        {
            List<string> ExportRequestDate = new List<string>();
            try
            {
                foreach (IWebElement row in InvoiceFeeListTable.FindElements(By.TagName("tr")))
                {
                    ExportRequestDate.Add(row.Text);
                }
                return ExportRequestDate;
            }
            catch (Exception ex)
            {
                throw new Exception("Exception", ex);

            }
        }

        public bool WaitUntilInvoiceNumberIsGeneratedForTheFirstInvName(int timeOut=10)
        {
            this.SwitchToContentFrame();
            //this.WaitCreation(InvoicetosummaryTable, AutoConfig.WaitTime);
            var result = false;
            string currentInvNo = "";
            InvoicetosummaryTable.PerformTableAction(1, 2, TableAction.Click);
            try
            {
                WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(timeOut));
                wait.Until(w =>
                {
                    currentInvNo = InvoicetosummaryTable.PerformTableAction(1, 2, TableAction.GetText).Message;
                    if(!currentInvNo.Trim().Equals("0") && !string.IsNullOrEmpty(currentInvNo))
                    {
                        result = true;

                    }
                    return result;
                });
            }
            catch { return false; }
            return result;
        }

        public string SavePDFFile(string PDFFilePath)
        {
            try
            {
                //TODO: Need to convert this to AutoIt
                Reports.UpdateDebugLog("Inside Try block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                BrowserWindow AdobeReaderwin = new BrowserWindow();
                UITestControlCollection Browsercnt = AdobeReaderwin.FindMatchingControls();

                for (int i = 0; i < Browsercnt.Count; i++)
                {
                    if (((BrowserWindow)Browsercnt[i]).GetProperty("Name").ToString().Contains(@"Documents/Print"))
                    {
                        AdobeReaderwin.Maximized = true;
                        break;
                    }
                }

                Random ran=new Random();
                int ranNumber= ran.Next(250);
                Playback.Wait(5000);
                PDFFilePath = PDFFilePath.Replace(".PDF", ranNumber + ".PDF");

                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleAdobeReaderDialog(false, true);

                Playback.Wait(2000);
                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(2000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(5000);
                FastDriver.WebDriver.HandleConfirmSaveAsDialog(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");
                

            }
            catch (Exception)
            {
                //Sometimes the preview window doesn't have name
                Reports.UpdateDebugLog("Inside Catch block", "", "", "", "", "Continuing test execution", Reports.Result(true), "");
                Keyboard.SendKeys("^{S}", System.Windows.Input.ModifierKeys.Shift);
                Playback.Wait(2000);
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This check the do not show this message again
                FastDriver.WebDriver.HandleDialogMessage(false, true); //This close the dialog

                Keyboard.SendKeys("{N}", System.Windows.Input.ModifierKeys.Alt);
                Keyboard.SendKeys(PDFFilePath);
                Playback.Wait(5000);

                Keyboard.SendKeys("{S}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(10000);
                FastDriver.WebDriver.HandleDialogMessage(false, true);

                Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);
                Playback.Wait(7000);
                Support.CloseAllProcessStartingWith("AcroRd32");
                Support.CloseAllProcessStartingWith("Acrobat");

            }

            return PDFFilePath;
           
           
        }
        //
        public void AddNewInvoice(string Role)
        {
            try
            {
                Reports.TestStep = "Add new invoice to file";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();
                New.FAClick();
                FastDriver.AddressBookSearchDlg.WaitForDialogToLoad();
                FastDriver.AddressBookSearchDlg.FileaddressBookRadio.FASetCheckbox(true);
                FastDriver.AddressBookSearchDlg.FileAddressBookSearchResultTable.PerformTableAction("Role", Role, "Select", TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception Ex)
            {
                Reports.StatusUpdate("Exception " + Ex.Message, false);
            }

        }
        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                string Message = FastDriver.WebDriver.HandleDialogMessage();
                if (Message.Contains("No printer") || Message.Contains("error while populating printers"))
                {
                    Reports.StatusUpdate("Printer is not configured", false);
                }
                else if (string.IsNullOrEmpty(Message))
                {
                    return false;
                }

                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
        public bool HandleDeliveryFailure(string deliveryMethod, int timeoutSeconds)
        {
            try
            {
                FastDriver.WebDriver.WaitForDeliveryWindow(deliveryMethod, timeoutSeconds);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return true;
            }
            catch (WebDriverTimeoutException)
            {
                Reports.StatusUpdate(string.Format("'{0}' failed after {1} seconds.", deliveryMethod, timeoutSeconds), false);
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                return false;
            }
        }

        public void SelectAllFeesFromInvoiceFeeList()
        {
            try
            {
                int TotalRows = FastDriver.InvoiceFees.InvoiceFeeListTable.GetRowCount();
                for (int row = 0; row < TotalRows - 1; row++)
                {
                    FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(row, 8, TableAction.On);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to select all fees in invoice fee list. " + ex.Message, false);
            }

        }

        public InvoiceFees Open()
        {
            return FastDriver.LeftNavigation.Navigate<InvoiceFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Invoice Fees").WaitForScreenToLoad();

        }

        public void ValidateHighlightedRows(string InvoiceName)
        {
            List<IWebElement> TableRows = FastDriver.InvoiceFees.InvoicetosummaryTable.FindElements(By.TagName("tr")).ToList();
            int RowCount2 = TableRows.Count;
            for (int j = 1; j <= RowCount2; j++)
            {
                if (TableRows[j].FAGetText().Contains(InvoiceName))
                {
                    string HighlightedRowColour2 = TableRows[j].GetAttribute("style").ToString();
                    if (HighlightedRowColour2.Contains("rgb(255, 255, 160)").ToString().Trim().ToLower() == "true")
                    {
                        Reports.StatusUpdate("The invoice with the name" + InvoiceName + " is Highlighted.", true);
                        break;
                    }
                    else
                        if (j == RowCount2)
                            Reports.StatusUpdate("The invoice with the name" + InvoiceName + " is not Highlighted.", false);
                }
            }
        }
	}
}
