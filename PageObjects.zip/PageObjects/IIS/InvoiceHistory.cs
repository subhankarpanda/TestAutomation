using System;
using System.Threading;
using System.Collections.Generic;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq.Expressions;
using System.Linq;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;


namespace FASTSelenium.PageObjects.IIS
{
    public class InvoiceHistory : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "grdInv_grdInv")]
        public IWebElement SummaryTable { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Amount { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Action { get; set; }

        [FindsBy(How = How.Id, Using = "lblCurStatus")]
        public IWebElement CurrentStatus { get; set; }

        [FindsBy(How = How.Id, Using = "lblFstEst")]
        public IWebElement FirstEstimated { get; set; }

        [FindsBy(How = How.Id, Using = "lblTot")]
        public IWebElement Total { get; set; }

        [FindsBy(How = How.Id, Using = "lblFstFinal")]
        public IWebElement FirstFinalized { get; set; }

        [FindsBy(How = How.Id, Using = "lblInvTo")]
        public IWebElement InvoiceTo { get; set; }

        [FindsBy(How = How.Id, Using = "lblInvNum")]
        public IWebElement InvoiceNumber { get; set; }

        [FindsBy(How = How.Id, Using = "grdInv_0_lblDescr")]
        public IWebElement Description0 { get; set; }

        [FindsBy(How = How.Id, Using = "grdInv_0_lblAmount")]
        public IWebElement Amt0 { get; set; }

        [FindsBy(How = How.Id, Using = "grdInv_6_lblDescr")]
        public IWebElement Description6 { get; set; }

        [FindsBy(How = How.Id, Using = "grdInv_6_lblAmount")]
        public IWebElement Amt6 { get; set; }

        [FindsBy(How = How.Id, Using = "grdInv_6_lblAction")]
        public IWebElement Action6 { get; set; }

        #endregion

        public InvoiceHistory WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryTable, 10);
            return this;
        }

        public InvoiceHistoryParameters GetInvoiceHistoryData(int DataSetNum)
        {
            InvoiceHistoryParameters InvHistoryParameters = new InvoiceHistoryParameters();
            try
            {
                FastDriver.InvoiceHistory.SwitchToContentFrame();
                
                InvHistoryParameters.InvoiceTo = InvoiceTo.FAGetText();
                InvHistoryParameters.CurrentStatus = CurrentStatus.FAGetText();
                InvHistoryParameters.Total = Total.FAGetText();
                if (FirstFinalized.Exists() && !FirstFinalized.FAGetText().Equals(" "))
                    InvHistoryParameters.FirstFinalized = Convert.ToDateTime(FirstFinalized.FAGetText()).ToDateString();
                if (FirstEstimated.Exists() && !FirstEstimated.FAGetText().Equals(" "))
                    InvHistoryParameters.FirstEstimated = Convert.ToDateTime(FirstEstimated.FAGetText()).ToDateString();
                //
                IWebElement Row = SummaryTable.FindElements(By.TagName("tr")).Where(rows => rows.Displayed && rows.GetAttribute("innerHTML").Contains("<td")).ElementAt<IWebElement>(DataSetNum);
                    List<IWebElement> allSpanTags = Row.FindElements(By.XPath(".//td")).ToList();
                    InvHistoryParameters.Description = allSpanTags[0].FAGetText();
                    InvHistoryParameters.Amount = allSpanTags[1].FAGetText();
                    if (allSpanTags.Count == 5)
                    {
                        InvHistoryParameters.Action = allSpanTags[2].FAGetText();
                        InvHistoryParameters.AdjustedOrCancelled  = (allSpanTags[3].FAGetText().Trim()=="")? allSpanTags[3].FAGetText():Convert.ToDateTime(allSpanTags[3].FAGetText()).ToDateString();
                    }
                    else
                    {
                        InvHistoryParameters.SalesTax = allSpanTags[2].FAGetText();
                        InvHistoryParameters.Action = allSpanTags[3].FAGetText();
                        if (!allSpanTags[4].FAGetText().Equals(" "))
                            InvHistoryParameters.AdjustedOrCancelled = (allSpanTags[3].FAGetText().Trim() == "") ? allSpanTags[3].FAGetText() : Convert.ToDateTime(allSpanTags[5].FAGetText()).ToDateString();
                    }

                    return InvHistoryParameters;
            }
            catch (Exception Ex)
            {
                Reports.StatusUpdate("Unable to get Invoice History data "+Ex.Message, false);
                return InvHistoryParameters;
            }
        }

    }

   
}
