using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class IssueDisbursements : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDisburse")]
		public IWebElement Disburse { get; set; }

		[FindsBy(How = How.Id, Using = "txtIDt")]
		public IWebElement ID { get; set; }

		[FindsBy(How = How.Id, Using = "grdDL")]
		public IWebElement Table { get; set; }

		#endregion


        public IssueDisbursements WaitForScreenToLoad()
        {            
            this.SwitchToContentFrame();
            this.WaitCreation(Table, 30);
            return this;
        }

	}




}
