using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class IssueManualCheck : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlDis")]
		public IWebElement DisburseAs { get; set; }

		[FindsBy(How = How.Id, Using = "txtRefer")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "ddlFrmAcc")]
		public IWebElement FromAccount { get; set; }

		[FindsBy(How = How.Id, Using = "txtChkNo")]
		public IWebElement CheckNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtIsuDate")]
		public IWebElement IssueDate { get; set; }

		[FindsBy(How = How.Id, Using = "chkUpdt")]
		public IWebElement UpdateTrustAccounting { get; set; }

        [FindsBy(How = How.Id, Using = "btnExp")]
        public IWebElement DisbursementDetailsExpand { get; set; }

		#endregion

        #region Useful Methods
        public IssueManualCheck WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(DisbursementDetailsExpand, 10);
            return this;
        }
        #endregion

    }
}
