using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class IssueWireDisbursement : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "chkApproval1")]
        public IWebElement Approved { get; set; }

        [FindsBy(How = How.Id, Using = "chkRejected")]
        public IWebElement Rejected { get; set; }

        [FindsBy(How = How.Id, Using = "txtIssueDate")]
        public IWebElement IssueDate { get; set; }

        [FindsBy(How = How.Id, Using = "ddlWireAcctNo")]
        public IWebElement AccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaWireInfo")]
        public IWebElement Information { get; set; }

        [FindsBy(How = How.Id, Using = "txtABAno")]
        public IWebElement ABANumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaRecBankName")]
        public IWebElement BankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaRecBankAddr")]
        public IWebElement BankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtBeneficiaryAcct")]
        public IWebElement BeneficiaryAccountNumber { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaBeneficiaryName")]
        public IWebElement BeneficiaryName { get; set; }

        [FindsBy(How = How.Id, Using = "txtAreaBeneficiaryAddr")]
        public IWebElement BeneficiaryAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote1")]
        public IWebElement Note1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote2")]
        public IWebElement Note2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote3")]
        public IWebElement Note3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtNote4")]
        public IWebElement Note4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtIntBIC")]
        public IWebElement BIC { get; set; }

        [FindsBy(How = How.Id, Using = "txtIntBankName")]
        public IWebElement IntermediaryBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtIntBankAdd")]
        public IWebElement IntermediaryBankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "txtBicAcc")]
        public IWebElement BeneficiaryBankBIC { get; set; }

        [FindsBy(How = How.Id, Using = "txtBenBank")]
        public IWebElement BeneficiaryBankName { get; set; }

        [FindsBy(How = How.Id, Using = "txtBenbankAdd")]
        public IWebElement BeneficiaryBankAddress { get; set; }

        [FindsBy(How = How.Id, Using = "lblDocName")]
        public IWebElement PO_Invoice { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src=\"../Images2/CloseImage.GIF\"]")]
        public IWebElement CloseImageGIF { get; set; }

        [FindsBy(How = How.Id, Using = "Img3")]
        public IWebElement Image { get; set; }

        [FindsBy(How = How.Id, Using = "lblDocName")]
        public IWebElement Miscellaneous { get; set; }

        [FindsBy(How = How.Id, Using = "tblSourceDoc")]
        public IWebElement DocumentSourceTable { get; set; }

        [FindsBy(How = How.Id, Using = "Img1")]
        public IWebElement CloseImg { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        #endregion

        #region Useful Methods
        public IssueWireDisbursement WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Approved);
            return this;
        }
        #endregion
    }
}
