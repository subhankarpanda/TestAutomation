using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class LeaseSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgLease")]
		public IWebElement SummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		#endregion

	}
	public class LeaseDetail : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement LeaseInformationName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress")]
        public IWebElement AddressLabelOne { get; set; }

        [FindsBy(How = How.Id, Using = "dgLease")]
        public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement LeaseInformationName1 { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtGABcode")]
		public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtEnterpriseNum")]
        public IWebElement EnterpriseNum { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdFindName")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusPhone")]
		public IWebElement BusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
		public IWebElement BusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusFax")]
		public IWebElement BusFax { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
		public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
		public IWebElement WeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "bp_comboAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEdit")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textName")]
		public IWebElement NameEdit { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "txtLeaseAmount")]
		public IWebElement LeaseAmount { get; set; }

		[FindsBy(How = How.Id, Using = "cboPer")]
		public IWebElement Per { get; set; }

		[FindsBy(How = How.Id, Using = "txtFor")]
		public IWebElement For { get; set; }

		[FindsBy(How = How.Id, Using = "cg_btnPayment")]
		public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbySellerAtClosing")]
        public IWebElement LeaseBPbySellerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtOthersSeller")]
        public IWebElement LeaseOthersSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerOthers")]
        public IWebElement DropdownLease { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement PDDdone { get; set; }

		[FindsBy(How = How.Id, Using = "cg_dcs_0_tdsc")]
		public IWebElement ChargeDescription { get; set; }

		[FindsBy(How = How.Id, Using = "cg_dcs_0_tbc")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cg_dcs_0_tsc")]
		public IWebElement SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cg_lblFooter")]
		public IWebElement CheckAmount { get; set; }

		[FindsBy(How = How.Id, Using = "bp_labelIdcode")]
		public IWebElement IDCodeLebel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_imgAdHocFlag")]
		public IWebElement GlobalImage { get; set; }

        [FindsBy(How = How.Id, Using = "cg_dcs_0_tga")]
		public IWebElement LoanEstimate { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cg_lblFooter img")]
		public IWebElement CheqImage { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cg_dcs")]
		public IWebElement LeaseChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "cg_dcs")]
        public IWebElement ChargeTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditAttentionContactInfo")]
        public IWebElement ContactEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactBusPhone")]
        public IWebElement ContactBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtContactExtnPhone")]
        public IWebElement ContactExtnPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactBusFax")]
        public IWebElement ContactBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactCellPhone")]
        public IWebElement ContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactPager")]
        public IWebElement ContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactEmailAddress")]
        public IWebElement ContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkContactWeeklyEmailStatus")]
        public IWebElement ContactWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src='../images/ico_write.gif']")]
        public IWebElement PencilIcon { get; set; }
        #endregion

        public LeaseDetail AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
                chargeElement.SendKeys(FAKeys.Tab);
            }
            return this;

        }

        public LeaseDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public LeaseDetail WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode);

            return this;
        }

        public void FindGABcode(string gabcode)
        {
            this.GABcode.FASetText(gabcode);
            this.Find.FAClick();
        }

        public LeaseDetail Open()
        {
            FastDriver.LeftNavigation.Navigate<DepositinEscrow>("Home>Order Entry>Escrow Charge Processes>Lease");
            this.WaitForScreenToLoad();
            return this;
        }

        public void Add16Charges()
        {
            FastDriver.LeaseDetail.ChargeDescription.FASetText("Description1");
            FastDriver.LeaseDetail.BuyerCharge.FASetText("1.11");
            FastDriver.LeaseDetail.SellerCharge.FASetText("1.11");
            Thread.Sleep(5000);
            FastDriver.LeaseDetail.SellerCharge.SendKeys(FAKeys.Tab + FAKeys.Tab);
            for (int iterator = 2; iterator <= 16; iterator++)
            {
                if (FastDriver.LeaseDetail.LeaseChargesTable.GetRowCount() < iterator)
                {
                    Reports.StatusUpdate("New row not generated, try one more time", true);
                    FastDriver.WebDriver.FindElement(By.Id("cg_dcs_" + (iterator - 2) + "_tsc")).FASetText("1.11" + FAKeys.Tab + FAKeys.Tab);
                    Thread.Sleep(5000);
                    break;
                }
                FastDriver.WebDriver.FindElement(By.Id("cg_dcs_" + (iterator - 1) + "_tdsc")).FASetText("Description" + iterator + FAKeys.Tab);
                Thread.Sleep(5000);
                FastDriver.WebDriver.FindElement(By.Id("cg_dcs_" + (iterator - 1) + "_tbc")).FASetText("1.11");
                FastDriver.WebDriver.FindElement(By.Id("cg_dcs_" + (iterator - 1) + "_tsc")).FASetText("1.11" + FAKeys.Tab + FAKeys.Tab);
                Thread.Sleep(5000);
            }
        }

        public void EnterDataInSectionHLease()
        {
            Reports.TestStep = "Enter charge in LEASE Lease Charges table.";
            Open();
            FastDriver.LeaseDetail.FindGABcode("LEASE");
            FastDriver.LeaseDetail.UpdateCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Rent/Lease Payment Due", 2000.00, null, 3000.00, null, 444);
            FastDriver.LeaseDetail.AddCharge(FastDriver.LeaseDetail.LeaseChargesTable, "Lease ADHOC", 2000.00, null, 3000.00, null, 222);
            FastDriver.BottomFrame.Done();
        }
        public string GetLeaseFullName
        {
            get 
            {
                string leasefullName = (this.LeaseInformationName.FAGetText() + " " + this.LeaseInformationName1.FAGetText()).Trim();
                return leasefullName;
            }
        }
        public bool VerifyImageExists(string imgName)
        {
            bool exist = false;

            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElements(ByLocator.TagName, "img")
              .FirstOrDefault(p => p.GetAttribute("src").Contains(imgName));
                if (element == null)
                {
                    Reports.StatusUpdate("Img not found.", false);
                }
                else
                {
                    Reports.StatusUpdate("Img found", true);
                    exist = true;
                }
            }
            catch (Exception)
            {
                Reports.StatusUpdate("Img found", true);

            }

            return exist;
        }
	}
}
