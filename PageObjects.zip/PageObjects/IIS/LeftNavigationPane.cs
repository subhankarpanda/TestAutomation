﻿using FASTSelenium.Common;
using FASTSelenium.ImageRecognition;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class FileSiteLeftNavigationPane : PageObject
    {
        public FileSiteLeftNavigationPane()
            : base()
        {
            IRHelpers.InitElements<FileSiteLeftNavigationPane>(this);
        }

        #region Web Elements
        //[FindsBy(How = How.CssSelector, Using = "li[title='Home']>a")]
        [FindsBy(How = How.LinkText, Using = "Home")]
        public IWebElement Home { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Order Entry']>a")]
        public IWebElement OrderEntry { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='File Homepage']>a")]
        public IWebElement FileHomepage { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Others']>a")]
        public IWebElement Others { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Select Office']>a")]
        public IWebElement SelectOffice { get; set; }

        [FindsBy(How = How.LinkText, Using = "Buyers")]
        public IWebElement mnuBuyers { get; set; }

        [FindsBy(How = How.LinkText, Using = "Sellers")]
        public IWebElement mnuSellers { get; set; }

        [FindsBy(How = How.LinkText, Using = "GFE Entry")]
        public IWebElement GFEEntry { get; set; }

        [FindsBy(How = How.LinkText, Using = "Proration")]
        public IWebElement Proration { get; set; }

        [FindsBy(How = How.LinkText, Using = "Off-Set")]
        public IWebElement Off_Set { get; set; }

        [FindsBy(How = How.LinkText, Using = "HUD-1 Statement")]
        public IWebElement HUD { get; set; }

        [FindsBy(How = How.LinkText, Using = "Interest Bearing Accounts")]
        public IWebElement IBA { get; set; }

        [FindsBy(How = How.LinkText, Using = "Active Disbursement Summary")]
        public IWebElement ActiveDisbursement { get; set; }

        [FindsBy(How = How.LinkText, Using = "Deposit In Escrow")]
        public IWebElement DepositinEscrow { get; set; }

        [FindsBy(How = How.LinkText, Using = "Work Queue Setup")]
        public IWebElement WorkQueueSetup { get; set; }

        [FindsBy(How = How.LinkText, Using = "Manage Work Queues")]
        public IWebElement ManageWorkQueues { get; set; }

        [FindsBy(How = How.LinkText, Using = "Manage Work Queue Users")]
        public IWebElement ManageWorkQueueUsers { get; set; }

        [FindsBy(How = How.LinkText, Using = "File Notes")]
        public IWebElement FileNotes { get; set; }

        [FindsBy(How = How.LinkText, Using = "My Fast Today")]
        public IWebElement MFT { get; set; }

        [FindsBy(How = How.LinkText, Using = "File Search")]
        public IWebElement FileSearch { get; set; }

        [FindsBy(How = How.LinkText, Using = "Reserve File Num")]
        public IWebElement ReserveFileNum { get; set; }

        [FindsBy(How = How.LinkText, Using = "New File Entry")]
        public IWebElement NewFileEntry { get; set; }

        [FindsBy(How = How.LinkText, Using = "Quick File Entry")]
        public IWebElement QuickFileEntry { get; set; }

        [FindsBy(How = How.LinkText, Using = "Quick Refi Entry")]
        public IWebElement QuickRefiEntry { get; set; }

        [FindsBy(How = How.LinkText, Using = "File Workflow")]
        public IWebElement FileWorkflow { get; set; }

        [FindsBy(How = How.LinkText, Using = "Escrow Closing")]
        public IWebElement EscrowClosing { get; set; }

        [FindsBy(How = How.LinkText, Using = "Deposits")]
        public IWebElement Deposits { get; set; }

        [FindsBy(How = How.LinkText, Using = "Deposit/Receipt History")]
        public IWebElement DepositHistory { get; set; }

        [FindsBy(How = How.LinkText, Using = "Deposit Outside Escrow")]
        public IWebElement DepositOutsideEscrow { get; set; }

        [FindsBy(How = How.LinkText, Using = "Event/Tracking Log")]
        public IWebElement EventLog { get; set; }

        [FindsBy(How = How.LinkText, Using = "Threshold Amount Setup")]
        public IWebElement ThresholdAmountSetup { get; set; }

        [FindsBy(How = How.LinkText, Using = "Request Policy Number")]
        public IWebElement RequestPolicyNumber { get; set; }

        [FindsBy(How = How.LinkText, Using = "1099-S")]
        public IWebElement Ten1099s { get; set; }

        [FindsBy(How = How.LinkText, Using = "View Change History")]
        public IWebElement ViewChangeHistory { get; set; }

        #endregion

        #region IR Elements | Deployment Items from "ImageRecognition\Media\LeftNav\*"

        [IRFindsBy(URI = "IR_LN_LeftArrow.BMP", Width = 40, Height = 40, OffsetLeft = 150, OffsetTop = 530, Text = "Left Arrow")]
        public IRButton IRLeftArrow { get; set; }

        [IRFindsBy(URI = "IR_LN_RightArrow.BMP", Width = 40, Height = 40, OffsetLeft = 150, OffsetTop = 550, Text = "Right Arrow")]
        public IRButton IRRightArrow { get; set; }

        [IRFindsBy(URI = "IR_LN_DoubleLeftArrow.BMP", Width = 40, Height = 40, OffsetLeft = 270, OffsetTop = 530, Text = "Double Left Arrow")]
        public IRButton IRDouleLeftArrow { get; set; }

        [IRFindsBy(URI = "IR_LN_DoubleRightArrow.BMP", Width = 40, Height = 40, OffsetLeft = 0, OffsetTop = 530, Text = "Double Right Arrow")]
        public IRButton IRDoubleRightArrow { get; set; }
        #endregion

        #region Services
        public FileSiteLeftNavigationPane LoadHomePage()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(Home);
            Home.FAClick();
            
            return this;
        }

        public OrderEntrySubPane ExpandOrderEntry()
        {
            //TO DO
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(OrderEntry);
            OrderEntry.FAClick();
            
            return FastDriver.GetPage<OrderEntrySubPane>();
        }

        public FileSiteLeftNavigationPane LoadOrderEntry()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(OrderEntry);
            OrderEntry.FAClick();
            
            return this;
        }

        public FileSiteLeftNavigationPane LoadFileHomepage()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(FileHomepage);
            FileHomepage.FAClick();
            
            return this;
        }

        public FileSiteLeftNavigationPane LoadOthersNavigation()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(Others);
            Others.FAClick();
            
            return this;
        }

        public FileSiteLeftNavigationPane LoadSelectOffice()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(SelectOffice);
            SelectOffice.FAClick();
            
            return this;
        }

        public FileSiteLeftNavigationPane Buyers()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(mnuBuyers);
            mnuBuyers.FAClick();
            
            return this;
        }

        public FileSiteLeftNavigationPane Sellers()
        {
            this.SwitchToLeftNavigationPane();
            this.WaitCreation(mnuSellers);
            mnuSellers.FAClick();
            
            return this;
        }

        #endregion
    }
}
