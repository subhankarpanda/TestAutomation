using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class LenderPoliciesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridProducts_dgridProducts")]
		public IWebElement LenderProductTable { get; set; }

		#endregion

        public LenderPoliciesDlg WaitForScreenToLoad(string windowName = "Other Product Selection", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? LenderProductTable);

            return this;
        }
	}
}
