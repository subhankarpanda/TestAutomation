using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class LenderUpdatesReviewDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//input[@type='button' and @value='Done']")]
		public IWebElement Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='button' and @value='Cancel']")]
		public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "chkConventional")]
        public IWebElement Conventional { get; set; }

        [FindsBy(How = How.Id, Using = "chkFHA")]
        public IWebElement FHA { get; set; }

        [FindsBy(How = How.Id, Using = "chkVA")]
        public IWebElement VA { get; set; }

        [FindsBy(How = How.Id, Using = "chkOther")]
        public IWebElement Other { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='radio' and @value='1']")]
        public IWebElement Accept { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@type='radio' and @value='0']")]
        public IWebElement Reject { get; set; }
        
        [FindsBy(How = How.CssSelector, Using = ".rejectTextArea")]
        public IWebElement RejectComment { get; set; }

        [FindsBy(How = How.Id, Using = "tblLoanCostsSection")]
        public IWebElement LenderUpdatesReviewTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherCostsSection")]
        public IWebElement LenderUpdatesReviewTableF { get; set; }
               
		#endregion

        public LenderUpdatesReviewDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? LenderUpdatesReviewTable);

            return this;
        }
	}
}

