using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Collections.Generic;
using System.Xml;
using System.IO;
using FASTWCFHelpers.FastClosingDisclosureService;
using System.Text;
using SeleniumInternalHelpersSupportLibrary;
using FASTWCFHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class LenderUpdatesSingleWindow : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "rdnProjectedPaymentsChange_1")]
        public IWebElement rdnPPAccept { get; set; }

        [FindsBy(How = How.Id, Using = "rdnProjectedPaymentsChange_0")]
        public IWebElement rdnPPReject { get; set; }

        [FindsBy(How = How.Id, Using = "rdnProjectedPaymentsChange_2")]
        public IWebElement rdnPPPendingReview { get; set; }

        [FindsBy(How = How.Id, Using = "rdnLenderUpdateAllChange_1")]
        public IWebElement rdnAcceptAll { get; set; }

        [FindsBy(How = How.Id, Using = "rdnLenderUpdateAllChange_0")]
        public IWebElement rdnRejectAll { get; set; }

        [FindsBy(How = How.Id, Using = "rdnLenderUpdateAllChange_2")]
        public IWebElement rdnPendingReviewAll { get; set; }

        [FindsBy(How = How.Id, Using = "txtProjectedPaymentsRejectComments")]
        public IWebElement txtRejectionComments { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement btnCancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement btnSave{ get; set; }

        [FindsBy(How = How.Id, Using = "chkIsPropertyTax")]
        public IWebElement chkPropertyTax { get; set; }

        [FindsBy(How = How.Id, Using = "lblIsPropertyTax")]
        public IWebElement lblPropertyTax { get; set; }

        [FindsBy(How = How.Name, Using = "ddlPropertyTax")]
        public IWebElement lstPropertyTax { get; set; }
        
        [FindsBy(How = How.Id, Using = "chkHOIns")]
        public IWebElement chkHomeOwnersInsurance { get; set; }

        [FindsBy(How = How.Id, Using = "lblIsHomeOwnerInsurance")]
        public IWebElement lblHomeOwnerInsurance { get; set; }

        [FindsBy(How = How.Name, Using = "ddlHomeOwnerInsuranceList")]
        public IWebElement lstHomeOwnerInsurance { get; set; }

        [FindsBy(How = How.Id, Using = "chkProjectedPaymentOthers")]
        public IWebElement chkProjectedPaymentOthers { get; set; }

        [FindsBy(How = How.Id, Using = "lblIsProjectedPaymentEstimateOther")]
        public IWebElement lblProjectedPaymentOthers { get; set; }

        [FindsBy(How = How.Id, Using = "lblProjectedPaymentEstimateOtherTypesCDID")]
        public IWebElement ProjectedPaymentOthersTypes { get; set; }

        [FindsBy(How = How.Id, Using = "lblPPEstimateIncludesOtherInEscrowID")]
        public IWebElement lstProjectedPaymentOthersType { get; set; }

        [FindsBy(How = How.Id, Using = "lblProjectedPaymentEstimateOther")]
        public IWebElement PPOthersShowOnForm { get; set; }
        
        
        //Year Range 1 Objects
        [FindsBy(How = How.Id, Using = "YearRange0")]
        public IWebElement lblYearRange0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblStartRange0")]
        public IWebElement StartYearRange0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEndRange0")]
        public IWebElement EndRange0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPrincipalInterestLine10")]
        public IWebElement PrincipalInterest0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPrincipalInterestLine20")]
        public IWebElement MaxValue0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblMortgageInsurance0")]
        public IWebElement MortgageInsurance0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedEscrow0")]
        public IWebElement EstimatedEscrow0 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedTotalMonthlyPayment0")]
        public IWebElement EstimatedTotalMonthlyPayment0 { get; set; }

        //Year range 2 Objects

        [FindsBy(How = How.Id, Using = "YearRange1")]
        public IWebElement lblYearRange1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblStartRange1")]
        public IWebElement StartYearRange1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEndRange1")]
        public IWebElement EndRange1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPrincipalInterestLine11")]
        public IWebElement PrincipalInterest1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPrincipalInterestLine21")]
        public IWebElement MaxValue { get; set; }
        

        [FindsBy(How = How.Id, Using = "lblMortgageInsurance1")]
        public IWebElement MortgageInsurance1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedEscrow1")]
        public IWebElement EstimatedEscrow1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedTotalMonthlyPayment1")]
        public IWebElement EstimatedTotalMonthlyPayment1 { get; set; }

        //Year range 3 Objects

        [FindsBy(How = How.Id, Using = "YearRange2")]
        public IWebElement lblYearRange2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblStartRange2")]
        public IWebElement StartYearRange2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEndRange2")]
        public IWebElement EndRange2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPrincipalInterestLine12")]
        public IWebElement PrincipalInterest2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblMortgageInsurance2")]
        public IWebElement MortgageInsurance2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedEscrow2")]
        public IWebElement EstimatedEscrow2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedTotalMonthlyPayment2")]
        public IWebElement EstimatedTotalMonthlyPayment2 { get; set; }

        //Year range 4 Objects

        [FindsBy(How = How.Id, Using = "YearRange3")]
        public IWebElement lblYearRange3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblStartRange3")]
        public IWebElement StartYearRange3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEndRange3")]
        public IWebElement EndRange3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPrincipalInterestLine13")]
        public IWebElement PrincipalInterest3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblMortgageInsurance3")]
        public IWebElement MortgageInsurance3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedEscrow3")]
        public IWebElement EstimatedEscrow3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstimatedTotalMonthlyPayment3")]
        public IWebElement EstimatedTotalMonthlyPayment3 { get; set; }


        [FindsBy(How = How.Id, Using = "lblEstimatedTaxInsuranceAssesment")]
        public IWebElement EstimatedTaxInsuranceAssesment { get; set; }
        
		#endregion

        public static string DataContractSerialize<T>(T obj, Type[] knownTypes, string xmlNamespace)
        {
            string xmlString = string.Empty;
            try
            {
                using (MemoryStream memStream = new MemoryStream())
                {
                    using (StreamReader reader = new StreamReader(memStream))
                    {
                        System.Runtime.Serialization.DataContractSerializer serializer = new System.Runtime.Serialization.DataContractSerializer(obj.GetType(), knownTypes);

                        if (!string.IsNullOrEmpty(xmlNamespace))
                        {
                            XmlWriterSettings settings = new XmlWriterSettings();
                            settings.Indent = true;
                            settings.NewLineOnAttributes = false;
                            using (XmlWriter writer = XmlWriter.Create(memStream, settings))
                            {
                                serializer.WriteStartObject(writer, obj);
                                writer.WriteAttributeString("xmlns", "ns", null, xmlNamespace);
                                writer.WriteAttributeString("xmlns", "xsi", null, xmlNamespace);
                                writer.WriteAttributeString("xmlns", "xsd", null, xmlNamespace);
                                serializer.WriteObjectContent(writer, obj);
                                serializer.WriteEndObject(writer);

                                writer.Flush();
                                writer.Close();
                            }
                        }
                        else
                        {
                            serializer.WriteObject(memStream, obj);
                        }

                        memStream.Position = 0;

                        xmlString = reader.ReadToEnd();
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return xmlString;
        }
        public static Type[] GetClosingDisclosureKnownTypes()
        {
            Type[] knownTypes = new Type[] { 
                typeof(ClosingDisclosureChargeFeeBase) 
                ,typeof(ClosingDisclosureChargeFee) 
                ,typeof(ClosingDisclosureImpoundCharge) 
                ,typeof(ClosingDisclosureLenderCredits) 
                ,typeof(ClosingDisclosureLoanCharge) 
                ,typeof(ClosingDisclosureTransactionSummaryCharge) 
                ,typeof(ClosingCostSectionCharges) 
                ,typeof(ClosingDisclosureEscrowChargeTemplate) 
                ,typeof(ClosingDisclosureRecordingFees) 
                };

            return knownTypes;
        }
        public static string ConvertXmlToFormattedString(XmlDocument xmlDocument)
        {
            System.IO.MemoryStream w = new System.IO.MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(w, Encoding.Unicode);

            writer.Formatting = Formatting.Indented;
            xmlDocument.WriteContentTo(writer);

            writer.Flush();
            w.Seek(0L, System.IO.SeekOrigin.Begin);

            System.IO.StreamReader reader = new System.IO.StreamReader(w);

            return reader.ReadToEnd();
        }
        public static FASTWCFHelpers.FastClosingDisclosureService.OperationResponse QCStagingPosting(int file)
        {
            Reports.TestStep = "Get CD Details";
            FASTWCFHelpers.FastClosingDisclosureService.ServiceFileRequest requestGetCDDetails = new FASTWCFHelpers.FastClosingDisclosureService.ServiceFileRequest

            {
                FileId = file,
                Source = "FAST",
                Target = "FAST",
                EmployeeObjectCD = "1",

            };

            var responseGetCDDetails = ClosingDisclosureService.GetClosingDisclosure(requestGetCDDetails);
            Support.AreEqual("1", responseGetCDDetails.Status.ToString(), responseGetCDDetails.StatusDescription);
            var responseSerialized = DataContractSerialize<FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosure>(responseGetCDDetails, LenderUpdatesSingleWindow.GetClosingDisclosureKnownTypes(), "");
            string resSerialized = responseSerialized.ToString();
            XmlDocument reqPostQCXML = new XmlDocument();
            reqPostQCXML.LoadXml(resSerialized);
            var reqPostQC = ConvertXmlToFormattedString(reqPostQCXML);
            Reports.TestStep = "Prepare request data for PostQCStaging";
            FASTWCFHelpers.FastClosingDisclosureService.PostQCStagingServiceRequest postQCServiceReq = new FASTWCFHelpers.FastClosingDisclosureService.PostQCStagingServiceRequest
            {
                FileID = (int)file,
                RequestXml = reqPostQC,
                Source = "FAST",
                Target = "FAST",
                MISMOTypeCdID = 1,
                EmployeeObjectCD = "1",
            };

            var postQCResponse = ClosingDisclosureService.PostQCStaging(postQCServiceReq);
            Support.AreEqual("1", postQCResponse.Status.ToString(), postQCResponse.StatusDescription);
            return postQCResponse;
        }
        //
        public static FASTWCFHelpers.FastClosingDisclosureService.OperationResponse MISMOPosting(int file)
        {
            //  Genereate MISMO
            Reports.TestStep = "Generate MISMO for the data contract";
            FASTWCFHelpers.FastClosingDisclosureService.ConvertToMismoResponse cdToMismoReq = ClosingDisclosureService.GenerateMismo(file);

            Reports.TestStep = "PosT MISMO  to Lender ";
            var postMismoResponse = ClosingDisclosureService.PostMismoClosingDisclosure(cdToMismoReq.MismoXml);
            Support.AreEqual("1", postMismoResponse.Status.ToString(), postMismoResponse.StatusDescription);
            return postMismoResponse;
        }
        
	}
}

