﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class LinkTitlePolicyDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.ClassName, Using = "ui-dialog-title")]
        public IWebElement Window { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tCF_tL1_ucTr_pnlTrans > table")]
        public IWebElement TransactionInfoTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//td/span[contains(text(),'1B:")]
        public IWebElement LinkTable { get; set; }
        //table[@id='FAFDataGrid1']/tbody/tr[1]/td/b"
        
        [FindsBy(How = How.Id, Using = "FAFDataGrid1_0_rdSelect")]
        public IWebElement OwnerPolicy1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1")]
        public IWebElement LinkPolicyTable { get; set; }
        

        #endregion WebElements

        public LinkTitlePolicyDlg WaitForScreenToLoad(string windowName = "Link Title Policy Dialog", IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? OwnerPolicy1);
            return this;
        }

    }
}
