﻿using System;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Diagnostics;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;

namespace FASTSelenium.PageObjects.IIS
{
    public class LoanInvestors : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "btnAdd")]
        public IWebElement Add { get; set; }

        [FindsBy(How = How.Id, Using = "btnRev")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dgLI")]
        public IWebElement LoanInvestorSummmaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_txtLoanNum")]
        public IWebElement LoanInvestorLoanNumber { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_labelIdcode")]
        public IWebElement LoanInvestorIDCode { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_chkEditContactInfo")]
        public IWebElement EditContact { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textBusPhone")]
        public IWebElement BusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_txtExtnPhone")]
        public IWebElement BusPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textBusFax")]
        public IWebElement BusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textEmailAddress")]
        public IWebElement Email { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_comboSalesRep1")]
        public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_comboSalesRep2")]
        public IWebElement SalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "TBP_chkWeeklyEmailStatus")]
        public IWebElement StatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "dgLIC")]
        public IWebElement LoanInvestorContactsTable { get; set; }
        #endregion

        #region Useful Methods
        public LoanInvestors WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Add);
            return this;
        }
        #endregion
    }

    
}
