﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class LoanInvestorsDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "dgLIS_dgLIS")]
        public IWebElement LoanInvestorsTable { get; set; }
        #endregion

        #region Methods
        public LoanInvestorsDlg WaitForScreenToLoad(string windowName = "Loan Investors Selection")
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch(windowName, true, timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(LoanInvestorsTable, 10);
            return this;
        }
        #endregion
    }
}
