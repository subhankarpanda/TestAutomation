using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class ManualCheckReceiptReason : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtManualChkRecptReason")]
        public IWebElement txtManualCheckReceiptReason { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement OK { get; set; }

        #endregion

        //public ManualCheckReceiptReason WaitForScreenToLoad(IWebElement element = null)
        //{
        //    FastDriver.WebDriver.WaitForWindowAndSwitch("Manual Check/Receipt Reason");
        //    //  this.SwitchToContentFrame();
        //    this.WaitCreation(element ?? txtManualCheckReceiptReason);

        //    return this;
        //}

        //
        //
        public ManualCheckReceiptReason WaitForScreenToLoad(string windowName = "Manual Check", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? txtManualCheckReceiptReason);

            return this;
        }

    }
}
