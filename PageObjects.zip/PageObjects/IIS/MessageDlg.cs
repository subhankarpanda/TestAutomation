﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Windows.Input;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Diagnostics;

namespace FASTSelenium.PageObjects
{
    public class MessageDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnYes")]
        public IWebElement Yes { get; set; }

        [FindsBy(How = How.Id, Using = "btnNo")]
        public IWebElement No { get; set; }

        [FindsBy(How = How.Id, Using = "spnMessage")]
        public IWebElement MessageTxt { get; set; }

        #endregion

        public MessageDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.WebDriver.WaitForWindowAndSwitch("Message", true, 15);
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? Yes);
            return this;
        }

        public MessageDlg AcceptWarning()
        {
            WaitForScreenToLoad();
            Yes.FAClick();
            return this;
        }
    }
}