using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class MgmtCheckDetailDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "txtVoucherInfo")]
		public IWebElement CheckVoucherInfo { get; set; }

		#endregion


        public MgmtCheckDetailDlg WaitForScreenToLoad(string windowName = "Check Detail")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Description, 5);

            return this;
        }
	}
}
