﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Windows.Input;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using System.Diagnostics;

namespace FASTSelenium.PageObjects
{
    public class MinMaxDialog : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "rdoMinimumMaximum")]
        public IWebElement MinMaxRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtMinimum")]
        public IWebElement MinimumAmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximum")]
        public IWebElement MaximumAmount { get; set; }

        [FindsBy(How = How.Id, Using = "rdoOnlyInterest")]
        public IWebElement OnlyInterestRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtPopInterest")]
        public IWebElement OnlyInterestTextBox { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrincipalInterestCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrincipalInterestDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine10")]
        public IWebElement MinimumAmountLabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine11")]
        public IWebElement MinimumAmountLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine12")]
        public IWebElement MinimumAmountLabel3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine13")]
        public IWebElement MinimumAmountLabel4 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine20")]
        public IWebElement MaximumAmountLabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine21")]
        public IWebElement MaximumAmountLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine22")]
        public IWebElement MaximumAmountLabel3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPILine23")]
        public IWebElement MaximumAmountLabel4 { get; set; }

        [FindsBy(How = How.Id, Using = "txtMinimum")]
        public IWebElement MinimumAmountTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "txtMaximum")]
        public IWebElement MaximumAmountTextbox { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI0")]
        public IWebElement Minmaxplus1 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI1")]
        public IWebElement Minmaxplus2 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI2")]
        public IWebElement Minmaxplus3 { get; set; }

        [FindsBy(How = How.Id, Using = "divImgPI3")]
        public IWebElement Minmaxplus4 { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrincipalInterestDone")]
        public IWebElement Doneminmax { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrincipalInterestCancel")]
        public IWebElement Cancelminmax { get; set; }

        [FindsBy(How = How.Id, Using = "rdoOnlyInterest")]
        public IWebElement OnlyInterestRadioButton1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtPopInterest")]
        public IWebElement OnlyInterestTextBox1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay0")]
        public IWebElement EstTotalMnthPaymentlabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay1")]
        public IWebElement EstTotalMnthPaymentlabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay2")]
        public IWebElement EstTotalMnthPaymentlabel3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblEstTotMonPay3")]
        public IWebElement EstTotalMnthPaymentlabel4 { get; set; }

        [FindsBy(How = How.Id, Using = "rdoPrincipalInterest")]
        public IWebElement PrincipalandInterestRadioButton1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtPrincipalInterest")]
        public IWebElement PrincipalandInterestTextbox { get; set; }

        #endregion
    }

}