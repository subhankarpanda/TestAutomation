using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class MiscellaneousDisbursementSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgMiscDisb")]
		public IWebElement SummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "labelNumRecords")]
        public IWebElement RecordCount { get; set; }
		#endregion

        public MiscellaneousDisbursementSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryTable);

            return this;
        }
	}
}
