using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class MiscDisbursementDetail : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement MISCDispursement_LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement MISCDispursement_LenderName1 { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdAdHoc")]
		public IWebElement AdHoc { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtGABcode")]
		public IWebElement GABcode { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdFindName")]
		public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
        public IWebElement GABID { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtName")]
		public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress")]
        private IWebElement Address1 { set; get; }

        [FindsBy(How = How.Id, Using = "bp_labelAddress2")]
        private IWebElement Address2 { set; get; }

		[FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusPhone")]
		public IWebElement BusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusFax")]
		public IWebElement BusinessFax { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
		public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
		public IWebElement StatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "bp_comboAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEdit")]
		public IWebElement EditNamecheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textName")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_btnPayment")]
		public IWebElement PaymentDetails { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tdsc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tbc")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tsc")]
		public IWebElement SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tga")]
		public IWebElement Non_GFEcharge { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs_1_tdsc")]
        public IWebElement Description1 { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs_1_tbc")]
        public IWebElement BuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs_1_tsc")]
        public IWebElement SellerCharge1 { get; set; }

		[FindsBy(How = How.Id, Using = "cgc_dcs_0_tdsc")]
		public IWebElement CheckOnlyDescription { get; set; }

		[FindsBy(How = How.Id, Using = "cgc_dcs_0_tbc")]
		public IWebElement CheckOnlyCharge { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_lblFooter")]
		public IWebElement CheckAmount { get; set; }

		[FindsBy(How = How.LinkText, Using = "/smsfast/images/ico_write.gif")]
		public IWebElement PaymentEditedImage { get; set; }

		[FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
		public IWebElement BusinessPartyRequired { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement CheckIssuedImage { get; set; }

		[FindsBy(How = How.Id, Using = "bp_labelName")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "bp_labelIdcode")]
		public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs_0_tga")]
		public IWebElement LoanEstimate { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cgm_lblFooter img")]
        public IWebElement CheqImage { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs")]
		public IWebElement MiscChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactBusPhone")]
        public IWebElement BusinessPhoneContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtContactExtnPhone")]
        public IWebElement BusinessPhoneExtensionContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactBusFax")]
        public IWebElement BusinessFaxContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactCellPhone")]
        public IWebElement CellPhoneContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactPager")]
        public IWebElement PagerContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textContactEmailAddress")]
        public IWebElement EmailAddressContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkContactWeeklyEmailStatus")]
        public IWebElement StatusEmailContact { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditAttentionContactInfo")]
        public IWebElement EditAttentionContact { get; set; }

        [FindsBy(How = How.Id, Using = "cgm_dcs")]
        public IWebElement MiscellaneousDisbursementBuyerSellerChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelStateAndZip")]
        public IWebElement StateAndZip { get; set; }

        [FindsBy(How = How.Id, Using = "ddlExchangeDisbursementTypes")]
        public IWebElement ExchDisbursementType { get; set; }

        [FindsBy(How = How.Id, Using = "ddlExchangeProperties")]
        public IWebElement ExchProperty { get; set; }

        [FindsBy(How = How.Id, Using = "txtExchangeCheckDescription")]
        public IWebElement ExchDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtExchangeAmount")]
        public IWebElement ExchAmount { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src='../images/ico_write.gif']")]
        public IWebElement PencilIcon { get; set; }


        #endregion

        public MiscDisbursementDetail Open()
        {
            FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>("Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
            this.WaitForScreenToLoad();

            return this;
        }

        public MiscDisbursementDetail AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
                chargeElement.SendKeys(FAKeys.Tab);
            }
            return this;

        }

        public MiscDisbursementDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public MiscDisbursementDetail WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode);
            return this;
        }

        public void FindGABcode(string gabcode)
        {
            this.GABcode.FASetText(gabcode);
            this.Find.FAClick();
        }

        public void VerifyAdhocValues(BusOrgAdhocDlgParameters MiscDisbAdhoc, bool Countryflag = false)
        {
            Support.AreEqual(MISCDispursement_LenderName.FAGetText().Trim(), MiscDisbAdhoc.Name1.Trim(), "Verify GabNameLine1");
            Support.AreEqual(MISCDispursement_LenderName1.FAGetText().Trim(), MiscDisbAdhoc.Name2.Trim(), "Verify GabNameLine2");

            if(string.IsNullOrEmpty(MiscDisbAdhoc.AddrLine2.Trim()) && string.IsNullOrEmpty(MiscDisbAdhoc.AddrLine2.Trim()))
                Support.AreEqualTrim(Address1.FAGetText(),"");
            else
                Support.AreEqualTrim(Address1.FAGetText(), MiscDisbAdhoc.AddrLine1 + ", " + MiscDisbAdhoc.AddrLine2);

            if (string.IsNullOrEmpty(MiscDisbAdhoc.AddrLine3.Trim()) && string.IsNullOrEmpty(MiscDisbAdhoc.AddrLine4.Trim()))
                Support.AreEqualTrim(Address2.FAGetText(), "");
            else
                Support.AreEqualTrim(Address2.FAGetText(), MiscDisbAdhoc.AddrLine3 + ", " + MiscDisbAdhoc.AddrLine4);

            if (string.IsNullOrEmpty(MiscDisbAdhoc.City.Trim()) && string.IsNullOrEmpty(MiscDisbAdhoc.State.Trim()) && !Countryflag)
                Support.AreEqualTrim(StateAndZip.FAGetText(), "");
            else
                Support.AreEqualTrim(StateAndZip.FAGetText(), MiscDisbAdhoc.City + ", " + MiscDisbAdhoc.State + ", " + MiscDisbAdhoc.Zip + ", " + MiscDisbAdhoc.Country);
        }

        public void VerifyAdhocGABID()
        {
            Support.AreEqual(IDCode.FAGetText().Substring(0, 2), "AD", "Verify if the system generated adhoc ID Code is displayed");
        }

        public void EnterDataInSectionHMiscellaneousDisbursement()
        {
            Reports.TestStep = "Enter charge in Miscellaneous Disbursement, Miscellaneous Disbursement Buyer/Seller Charges Charges table.";
            Open();
            FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
            FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscellaneousDisbursementBuyerSellerChargesTable, "Misc Adhoc", 2000.00, null, 3000.00, null, 444);
            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionHMiscellaneousDisbursement_HUD()
        {
            Reports.TestStep = "HUD Statement-Enter charge in Miscellaneous Disbursement, Miscellaneous Disbursement Buyer/Seller Charges Charges table.";
            Open();
            FastDriver.MiscDisbursementDetail.FindGABcode("HUDMISCDB1");
            FastDriver.MiscDisbursementDetail.AddCharge(FastDriver.MiscDisbursementDetail.MiscellaneousDisbursementBuyerSellerChargesTable, "Misc Adhoc", 2000.00, null, 3000.00, null);
            FastDriver.BottomFrame.Done();
        }
    }
}
