using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class MiscDisbursementDetailDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "bp_cmdAdHoc")]
		public IWebElement AdHoc { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtGABcode")]
		public IWebElement bpGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "bp_cmdFindName")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtName")]
		public IWebElement bpName { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusPhone")]
		public IWebElement bptextBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
		public IWebElement bpExtnPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textBusFax")]
		public IWebElement bptextBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textCellPhone")]
		public IWebElement bptextCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textPager")]
		public IWebElement bptextPager { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
		public IWebElement bptextEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
		public IWebElement bpWeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "bp_comboAttention")]
		public IWebElement bpcomboAttention { get; set; }

		[FindsBy(How = How.Id, Using = "bp_chkEdit")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textName")]
		public IWebElement bptextName { get; set; }

		[FindsBy(How = How.Id, Using = "bp_textReference")]
		public IWebElement bptextReference { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_btnPayment")]
		public IWebElement PaymentDetails { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tdsc")]
		public IWebElement MiscDescription { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tga")]
		public IWebElement MiscNonGFEcharge { get; set; }

		[FindsBy(How = How.Id, Using = "cgc_dcs_0_tdsc")]
		public IWebElement cgcdcs0tdsc { get; set; }

		[FindsBy(How = How.Id, Using = "cgc_dcs_0_tbc")]
		public IWebElement HUD1lineNumber0 { get; set; }

		[FindsBy(How = How.Id, Using = "cgm_dcs_0_tga")]
		public IWebElement MiscGFEcharge { get; set; }

		#endregion

	}
}
