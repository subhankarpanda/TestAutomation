using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class MoveWorkQMessageDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboQList")]
		public IWebElement QueueList { get; set; }

		[FindsBy(How = How.Id, Using = "Faflabel7")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "Faflabel3")]
		public IWebElement Belowcomments { get; set; }

		[FindsBy(How = How.Id, Using = "btnOK")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		#endregion

        public MoveWorkQMessageDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //this.SwitchToContentFrame();
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(element ?? QueueList);

            return this;
        }
	}
}
