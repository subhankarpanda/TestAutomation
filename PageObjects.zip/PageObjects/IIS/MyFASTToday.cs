using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class MyFASTToday : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlAlertUser")]
        public IWebElement AlertUser { get; set; }

        [FindsBy(How = How.Id, Using = "ddlAlertType")]
        public IWebElement AlertType { get; set; }

        [FindsBy(How = How.Id, Using = "btnAlertSelect")]
        public IWebElement AlertsSelect { get; set; }

        [FindsBy(How = How.Id, Using = "btnAlertEventLog")]
        public IWebElement EventLogAlerts { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSummaryAlerts_0_chkDel")]
        public IWebElement DeleteAlerts { get; set; }

        [FindsBy(How = How.Id, Using = "ddlMyFilters")]
        public IWebElement MyFilters { get; set; }

        [FindsBy(How = How.Id, Using = "btnFilterSave")]
        public IWebElement Save { get; set; }

        [FindsBy(How = How.Id, Using = "btnFilterDel")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.Id, Using = "btnFilterClear")]
        public IWebElement ClearSearchFilter { get; set; }

        [FindsBy(How = How.Id, Using = "btnApply")]
        public IWebElement Apply { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFilterEmployee")]
        public IWebElement FilterEmployee { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFilterWorkGroup")]
        public IWebElement FilterWorkGroup { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFilterTaskCategory")]
        public IWebElement FilterTaskCategory { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFilterTaskOffice")]
        public IWebElement FilterTaskOffice { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFileOwnReg")]
        public IWebElement FileOwningRegion { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTaskRegion")]
        public IWebElement TaskRegion { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTaskName")]
        public IWebElement TaskName { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTaskStatus")]
        public IWebElement TaskStatus { get; set; }

        [FindsBy(How = How.Id, Using = "btnEditAddlFilters")]
        public IWebElement EditAdditionalFilters { get; set; }

        [FindsBy(How = How.Id, Using = "txtGABCode")]
        public IWebElement GABCode { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindGAB")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "btnClearGAB")]
        public IWebElement ClearAddSearchFilter { get; set; }

        [FindsBy(How = How.Id, Using = "txtBusOrgName")]
        public IWebElement GABName { get; set; }

        [FindsBy(How = How.Id, Using = "ddlRecentBusOrg")]
        public IWebElement Recent { get; set; }

        [FindsBy(How = How.Id, Using = "btnSelect")]
        public IWebElement TasksSelect { get; set; }

        [FindsBy(How = How.Id, Using = "btnEventLog")]
        public IWebElement EventLogTasks { get; set; }

        [FindsBy(How = How.Id, Using = "btnFileInfo")]
        public IWebElement FileInfo { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_chkStart")]
        public IWebElement StartTask { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_chkComplete")]
        public IWebElement CompleteTask { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_chkWaive")]
        public IWebElement WaiveTask { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblWGName")]
        public IWebElement Unassigned { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks")]
        public IWebElement _ActiveTasksTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnNext")]
        public IWebElement Next { get; set; }

        [FindsBy(How = How.Id, Using = "txtPgNum")]
        public IWebElement PageNumber { get; set; }

        [FindsBy(How = How.Id, Using = "btnGoto")]
        public IWebElement GoToPage { get; set; }

        [FindsBy(How = How.Id, Using = "ddlATO")]
        public IWebElement AssignedTo { get; set; }

        [FindsBy(How = How.Id, Using = "ddlWG")]
        public IWebElement WorkgroupSelect { get; set; }

        [FindsBy(How = How.Id, Using = "idSummaryAlerts")]
        public IWebElement SummaryAlerts { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblAssignedTo")]
        public IWebElement SelectActiveTask1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_1_lblAssignedTo")]
        public IWebElement SelectActiveTask2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblFileNumList")]
        public IWebElement Filenumber { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSummaryAlerts_dgridSummaryAlerts")]
        public IWebElement SummaryAlertsTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddRemove_WorkGroup")]
        public IWebElement AddRemoveWorkGroup { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddRemove_TaskOffice")]
        public IWebElement AddRemoveTaskOffice { get; set; }

        [FindsBy(How = How.Id, Using = "btnAddRemove_TaskName")]
        public IWebElement AddRemoveTaskName { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement AlertSummaryFile { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSummaryAlerts_0_lblMessage")]
        public IWebElement Message { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSummaryAlerts_0_lblAlertFileNum")]
        public IWebElement FileNumberSummaryAlert { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblWGName")]
        public IWebElement WorkGroupPane1 { get; set; }

        [FindsBy(How = How.Id, Using = "btnExpFilters")]
        public IWebElement AddSearchFexpand { get; set; }

        [FindsBy(How = How.Id, Using = "lblBusOrgIDCode")]
        public IWebElement AddSearchIDCodePane { get; set; }

        [FindsBy(How = How.LinkText, Using = "Primary Filter")]
        public IWebElement PrimaryFilterImage { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblTaskNameList")]
        public IWebElement Task1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgTasks_0_lblDueDateList")]
        public IWebElement DueDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "imgTaskOffice")]
        public IWebElement TaskOfficeImage1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPgNum")]
        public IWebElement PagePane { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'QA Automation Office - DO NOT TOUCH')]")]
        public IWebElement TaskNameElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'Accounting')]")]
        public IWebElement AccountingElement { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'ADEC-ITI-BILL-FULL')]")]
        public IWebElement ADECITIBILLFULL { get; set; }

        #endregion


        public MyFASTToday WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FindNow);

            return this;
        }

        public MyFASTToday WaitForTaskTableToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(_ActiveTasksTable);

            return this;
        }

        public MyFASTToday ActiveTasksTable(int columnToSearch, string searchValue, int actionCell, TableAction action, string value = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(this._ActiveTasksTable);
            _ActiveTasksTable.PerformTableAction(columnToSearch, searchValue, actionCell, action, value);

            return this;
        }

        public MyFASTToday Open()
        {
            FastDriver.LeftNavigation.Navigate<MyFASTToday>(@"Home>Order Entry>My Fast Today");
            Thread.Sleep(5000);
            this.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 20);
            this.WaitForScreenToLoad();
            return this;
        }
        //
        public void DeleteObsoleteAlerts(int NumberOfALerts,string AlertType,string AlertUser)
        {
            this.WaitForScreenToLoad();
            this.AlertType.FASelectItem(AlertType);
            this.AlertUser.FASelectItem(AlertUser);
            this.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 30);
            Thread.Sleep(2000);
            this.WaitForScreenToLoad();
            int rowCount = this.SummaryAlertsTable.GetRowCount();
            Reports.TestStep = "Delete alerts in MFT";
            for (int i = 1; i < (NumberOfALerts > rowCount ? rowCount : NumberOfALerts); i++)
            {

                DateTime MFTAlertDate = Convert.ToDateTime(this.SummaryAlertsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Substring(0, 10)).ToUniversalTime();
                DateTime CurrentTime = DateTime.UtcNow;
                if ((CurrentTime.Date - MFTAlertDate.Date).TotalDays >= 2) // delete alerts in past year or months or before 5 days
                {
                    this.SummaryAlertsTable.PerformTableAction(i, 1, TableAction.Click);
                }
                else
                {
                    Reports.StatusUpdate("No Alert is deleted", true);
                    break;
                }
            }
            this.Open();
        }

        public bool ValidateAlertOnMFT(string AlertType, string AlertMessage, string FileNumber, string AlertUser = "Unassigned")
        {
            this.Open();
            this.AlertType.FASelectItem(AlertType);
            this.AlertUser.FASelectItem(AlertUser);
            this.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 30);
            Thread.Sleep(2000);
            this.WaitForScreenToLoad();

            Reports.TestStep = "Verify " + AlertType + " alerts in MFT";
            bool status = false;
            for (int i = this.SummaryAlertsTable.GetRowCount(); i > 0; i--)
            {
                DateTime MFTAlertDate = Convert.ToDateTime(this.SummaryAlertsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Substring(0, 10));
                if (MFTAlertDate <= DateTime.Now && MFTAlertDate >= DateTime.Now.AddDays(-2)) // to limit search in alerts table
                {
                    if (!this.SummaryAlertsTable.PerformTableAction(i, 4, TableAction.GetText).Message.Equals(FileNumber))
                        continue;
                    status = this.SummaryAlertsTable.PerformTableAction(i, 5, TableAction.GetText).Message.Equals(AlertMessage);
                    if (status)
                    {
                        this.SummaryAlertsTable.PerformTableAction(i, 5, TableAction.Click);
                        break;
                    }
                }
                else
                    break;
            }
            return status;

        }
        //
        public bool DeleteAlertOnMFT(string AlertType, string AlertMessage, string FileNumber, string AlertUser = "Unassigned")
        {

            this.WaitForScreenToLoad();

            Reports.TestStep = "Delete " + AlertType + " alerts in MFT";
            bool status = false;
            for (int i = this.SummaryAlertsTable.GetRowCount(); i > 0; i--)
            {
                DateTime MFTAlertDate = Convert.ToDateTime(this.SummaryAlertsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Trim().Substring(0, 10));
                if (MFTAlertDate <= DateTime.Now && MFTAlertDate >= DateTime.Now.AddDays(-2)) // to limit search in alerts table
                {
                    if (!this.SummaryAlertsTable.PerformTableAction(i, 4, TableAction.GetText).Message.Equals(FileNumber))
                        continue;
                    status = this.SummaryAlertsTable.PerformTableAction(i, 5, TableAction.GetText).Message.Equals(AlertMessage);
                    if (status)
                    {
                        this.SummaryAlertsTable.PerformTableAction(i, 1, TableAction.Click);
                        break;
                    }
                }
                else
                    break;
            }
            this.Open();
            this.AlertType.FASelectItem(AlertType);
            this.AlertUser.FASelectItem(AlertUser);
            this.WebDriver.WaitForWindowAndSwitch("One moment please...", toExist: false, timeoutSeconds: 20);
            Thread.Sleep(2000);
            this.WaitForScreenToLoad();
            Reports.TestStep = "Validate that alert is deleted";
            for (int i = this.SummaryAlertsTable.GetRowCount(); i > 0; i--)
            {
                DateTime MFTAlertDate = Convert.ToDateTime(this.SummaryAlertsTable.PerformTableAction(i, 3, TableAction.GetText).Message.Substring(0, 10));
                if (MFTAlertDate <= DateTime.Now && MFTAlertDate >= DateTime.Now.AddDays(-2)) // to limit search in alerts table
                {
                    if (!this.SummaryAlertsTable.PerformTableAction(i, 4, TableAction.GetText).Message.Equals(FileNumber))
                        continue;
                    status = (!this.SummaryAlertsTable.PerformTableAction(i, 5, TableAction.GetText).Message.Equals(AlertMessage));
                    if (status)
                    {
                        return !status;
                    }
                }
                else
                {
                    status = true;
                    break;
                }
            }

            return status;

        }

        public MyFASTToday RemoveFilter(string filterName)
        {
            this.Open();
            this.WaitCreation(MyFilters);

            if (MyFilters.FAGetAllTextFromSelect().Contains(filterName))
            {
                MyFilters.FASelectItem(filterName);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                this.WaitForScreenToLoad();
                Delete.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                Thread.Sleep(10000);
            }
            //foreach (var item in MyFilters.FAFindElements(ByLocator.TagName, "option").GetAllVisible())
            //{
            //    if (item.Text.Contains(filterName))
            //    {
            //        MyFilters.FASelectItem(filterName);
            //        FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 5);
            //        this.WaitForScreenToLoad();
            //        Delete.FAClick();
            //        FastDriver.WebDriver.HandleDialogMessage();
            //        Thread.Sleep(10000);
            //    }
            //}
            return this;
        }

        public bool VerifyFilterAvailability(string filterName)
        {
            Open();
            return MyFilters.Text.Contains(filterName);
        }

        public int MarkTaskAs(IWebElement table, TaskStatus status)
        {
            int count = 0;

            for (int i = 2; i < _ActiveTasksTable.GetRowCount(); i++)
            {
                if (!table.PerformTableAction(i, 1, TableAction.GetCell).Element.FAFindElements(ByLocator.TagName, "img").FirstOrDefault(j => j.FAGetAttribute("id").Contains("imgStart")).IsVisible())
                {
                    count = i;
                    switch (status)
                    {
                        case FASTSelenium.Common.TaskStatus.Start:
                            _ActiveTasksTable.PerformTableAction(i, 1, TableAction.On);
                            break;
                        case FASTSelenium.Common.TaskStatus.Complete:
                            _ActiveTasksTable.PerformTableAction(i, 2, TableAction.On);
                            break;
                        case FASTSelenium.Common.TaskStatus.Waive:
                            _ActiveTasksTable.PerformTableAction(i, 3, TableAction.On);
                            break;
                        default:
                            break;
                    }

                    break;
                }
            }

            return count;
        }
        //
        public bool OpenTaskCommentDlgForTask(string TaskName, string FileNumber)
        {
            try
            {
                FastDriver.MyFASTToday.WaitForScreenToLoad();
               List<IWebElement> TableRows = FastDriver.MyFASTToday._ActiveTasksTable.FindElements(By.TagName("tr")).Where(r => r.Displayed).ToList();
               int RowCount = TableRows.Count;
               for (int j = 1; j < RowCount;j++ )
                {
                    if (TableRows[j].FAGetText().Contains(TaskName) && TableRows[j].FAGetText().Contains(FileNumber))
                    {
                        //IWebElement TaskComment = FastDriver.MyFASTToday._ActiveTasksTable.PerformTableAction(j,12, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "IMG");
                        IWebElement TaskComment = TableRows[j].FAFindElement(ByLocator.Id, "imgComment");
                        TaskComment.FAClick();
                        for (int i = 0; i < 5; i++)
                        {
                            try
                            {
                                Thread.Sleep(3000);
                                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad();
                                return true;
                            }
                            catch
                            {
                                FastDriver.MyFASTToday.WaitForScreenToLoad();
                                TaskComment.FAClick();
                                continue;
                            }
                        }
                    }
                }
                return false;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        //
        public void SelectTaskNameFilter(string TaskName, string TaskRegion = "QA Automation Region - DO NOT TOUCH")
        {
            FastDriver.MyFASTToday.TaskRegion.FASelectItem(TaskRegion);
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.MyFASTToday.WaitForScreenToLoad();
            FastDriver.MyFASTToday.AddRemoveTaskName.FAClick();
            FastDriver.TaskNameSelection.WaitForScreenToLoad();
            FastDriver.TaskNameSelection.TaskTable.PerformTableAction("Task Name", TaskName, "Select", TableAction.On);
            FastDriver.TaskNameSelection.Select.FAClick();
            FastDriver.MyFASTToday.WaitForScreenToLoad();
        }
        
    }
}
