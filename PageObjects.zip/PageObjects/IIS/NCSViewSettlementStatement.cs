﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using System.Diagnostics;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using Microsoft.VisualStudio.TestTools.UITesting;


namespace FASTSelenium.PageObjects.IIS
{
    public class NCSViewSettlementStatement : PageObject
    {
        #region WebElements

        #region Old Screen elements
        [FindsBy(How = How.XPath, Using = "//span[@id='DescrEditable'][contains(text(),'New Loan(s)')]")]
        public IWebElement NewLoansSection { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='DescrEditable'][contains(text(),'Commission')]")]
        public IWebElement CommissionSection { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='DescrEditable'][contains(text(),'Consideration')]")]
        public IWebElement ConsiderationSection { get; set; }
        #region sanath
        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[3]/td/table")]
        public IWebElement PropertySubsection1 { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[4]/td/table")]
        public IWebElement OutsideSubsection1 { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[@id='table-9']/tbody/tr[3]/td/table")]
        public IWebElement payoffloansection1stinstance { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[4]/td/table/tbody/tr[5]/td[3]/div")]
        public IWebElement Oeveri { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[contains(@bordercolor,'#f5f5f5')]")]
        public IWebElement TRDtable { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Tax Installment: Interest Due to Chase Manhattan Mortgage Corporation')]")]
        public IWebElement Ptcfrom { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Ad Hoc Entry to The Northern Trust Company')]")]
        public IWebElement debugfrom { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Funds Held 1st instance')]")]
        public IWebElement debugto { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Ad Hoc Entry to The Northern Trust Company')]")]
        public IWebElement SixthRow { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Funds Held 2nd instance')]")]
        public IWebElement SecondRow { get; set; }
        //[FindsBy(How = How.XPath, Using = "//table[@id='table-13']/tbody/tr[8]/td[3]/div")]
        //public IWebElement debugfrom { get; set; }
        //[FindsBy(How = How.XPath, Using = "//table[@id='table-13']/tbody/tr[3]/td[3]/div")]
        //public IWebElement debugto { get; set; }
        #endregion Sanath
        //parimala start

        //charges of Buyer Broker instance

        [FindsBy(How = How.XPath, Using = "//table[@id='table-6']/tbody/tr[3]/td/table")]
        public IWebElement Firstinstance { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-6']/tbody/tr[4]/td/table")]
        public IWebElement Secondinstance { get; set; }


        //Subsections of Disbursement Paid Section
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Homeowner Association')]")]
        public IWebElement From_HomeownerAssociation { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Insurance')]")]
        public IWebElement To_Insurance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Inspection/Repair')]")]
        public IWebElement From_InspectionRepair { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Miscellaneous Disbursement')]")]
        public IWebElement To_MiscellaneousDisbursement { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Utility')]")]
        public IWebElement From_Utility { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Outside Escrow')]")]
        public IWebElement To_OutsideEscrow { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[5]/td/table/tbody/tr[1]/td[3]/div/span/b")]
        public IWebElement HomeownerAssociationVerify { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[8]/td/table/tbody/tr[1]/td[3]/div/span/b")]
        public IWebElement Inspection_RepairVerify { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[13]/td/table/tbody/tr[1]/td[3]/div/span/b")]
        public IWebElement UtilityVerify { get; set; }

        //Homeowners Association and Inspection/Repair Subsection of Disbursement paid section
        [FindsBy(How = How.XPath, Using = "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Association Dues to The Northern Trust Company')]")]
        public IWebElement From_AssociationDues { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Certification Letter to The Northern Trust Company')]")]
        public IWebElement To_CertificateLetter { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Pest Repair to First American Title Company')]")]
        public IWebElement From_PestCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Septic Inspection to The Northern Trust Company')]")]
        public IWebElement To_SepticCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[3]/td/table/tbody/tr[5]/td[3]/div/span/span[1]")]
        public IWebElement HomeownerAssociationCharge_Verify { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[4]/td/table/tbody/tr[6]/td[3]/div/span/span[1]")]
        public IWebElement PestRepairCharger_Verify { get; set; }

        //Disbursement paid subsection table
        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[3]/td/table")]
        public IWebElement HomeownerSubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[4]/td/table")]
        public IWebElement HomewarrentySubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[5]/td/table")]
        public IWebElement InspectionSubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[6]/td/table")]
        public IWebElement InsuranceSubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[7]/td/table")]
        public IWebElement LeaseSubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[8]/td/table")]
        public IWebElement PropertySubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[9]/td/table")]
        public IWebElement SurverySubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[10]/td/table")]
        public IWebElement UtilitySubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[11]/td/table")]
        public IWebElement REBSubsection { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[12]/td/table")]
        public IWebElement OutsideSubsection { get; set; }

        //Header Section
        [FindsBy(How = How.Id, Using = "headerSectionData")]
        public IWebElement HeaderSection { get; set; }

        [FindsBy(How=How.Id,Using="ckhSelectAllAddress")]
        public IWebElement AddressSelectAll { get; set; }

        [FindsBy(How = How.Id,Using = "ckhName")]
        public IWebElement NameSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "refreshImage")]
        public IWebElement RefreshIcon { get; set; }

        [FindsBy(How = How.Id, Using = "brokenImage")]
        public IWebElement BrokenLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divlenderPlusIcon']//table")]
        public IWebElement lenderdetailsdialogbox { get; set; }
        //parimala end anil start

        //Anil

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Attorney: Lenders Advantage A Division Of First American Title Ins.')]")]
        public IWebElement Attorney_1st_Instance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Attorney Fee')]")]
        public IWebElement Attorney_1st_INS_1st_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'First Instance Second cahrge A987')]")]
        public IWebElement Attorney_1st_INS_2nd_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'First Instance Third cahrge B876')]")]
        public IWebElement Attorney_1st_INS_3rd_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Attorney: Lenders Advantage A Division Of First American Title Ins.')]")]
        public IWebElement Attorney_2nd_Instance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Modified Charge in Source')]")]
        public IWebElement Attorney_2nd_INS_1st_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Second cahrge T654')]")]
        public IWebElement Attorney_2nd_INS_2nd_cahrge { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Third cahrge 8u76')]")]
        public IWebElement Attorney_2nd_INS_3rd_cahrge { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Attorney: Bank of America')]")]
        public IWebElement Attorney_3rd_Instance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Updated Charge Desc in Pdd')]")]
        public IWebElement Attorney_3rd_INS_1st_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'3rd Instance Second charge F652')]")]
        public IWebElement Attorney_3rd_INS_2nd_cahrge { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'3rd Instance Third charge G543')]")]
        public IWebElement Attorney_3rd_INS_3rd_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Attorney: New Century Mortgage ')]")]
        public IWebElement Attorney_4th_Instance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Added New charge for New Instance')]")]
        public IWebElement Attorney_4th_INS_1st_cahrge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'4th Instance Second charge H345')]")]
        public IWebElement Attorney_4th_INS_2nd_cahrge { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'4th Instance Third charge K876')]")]
        public IWebElement Attorney_4th_INS_3rd_cahrge { get; set; }

        // Disbursement Paid Section


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Survey')]")]
        public IWebElement Disbursement_Paid_FirstInstance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Survey')]")]
        public IWebElement Disbursement_Paid_FirstInstance_1stCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1st Instance Second cahrge G876')]")]
        public IWebElement Disbursement_Paid_FirstInstance_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1st Instance Third cahrge H654')]")]
        public IWebElement Disbursement_Paid_FirstInstance_3rdCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Modified Description in Survey screen')]")]
        public IWebElement Disbursement_Paid_FirstInstance_4thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Second cahrge Y654')]")]
        public IWebElement Disbursement_Paid_FirstInstance_5thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Third cahrge U432')]")]
        public IWebElement Disbursement_Paid_FirstInstance_6thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span/b[contains(text(),'Lease')]")]
        public IWebElement Disbursement_Paid_Lease_Instance { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Rent/Lease Payment Due')]")]
        public IWebElement Disbursement_Paid_Lease_1stCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1st Instance Second charge Z333')]")]
        public IWebElement Disbursement_Paid_Lease_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1st Instance Third charge E222')]")]
        public IWebElement Disbursement_Paid_Lease_3rdCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Updated Charge Description in Source Screen')]")]
        public IWebElement Disbursement_Paid_Lease_4thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Second charge G222')]")]
        public IWebElement Disbursement_Paid_Lease_5thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Third cahrge F111')]")]
        public IWebElement Disbursement_Paid_Lease_6thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Utilities')]")]
        public IWebElement Disbursement_Paid_Utility_1stCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1st Instance Second charge H543')]")]
        public IWebElement Disbursement_Paid_Utility_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1st Instance Third charge J765')]")]
        public IWebElement Disbursement_Paid_Utility_3rdCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Updated Charge in Utility source screen')]")]
        public IWebElement Disbursement_Paid_Utility_4thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'2nd Instance Second charge M543')]")]
        public IWebElement Disbursement_Paid_Utility_5thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Home Warranty')]")]
        public IWebElement Disbursement_Paid_HW_1stCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Home Warranty - Early Coverage')]")]
        public IWebElement Disbursement_Paid_HW_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Updated Charge for Homewarranty first charge')]")]
        public IWebElement Disbursement_Paid_HW_3rdCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Modified charge for Home Warranty - Early Cov')]")]
        public IWebElement Disbursement_Paid_HW_4thCharge { get; set; }


        //END's Anil


        [FindsBy(How = How.XPath, Using = "//table[@id='tbTitleEscrowCharges']/tbody/tr[@id='trCharge_1']/td/table/tbody/tr/td")]
        public IWebElement TitleCharge1 { get; set; }


        [FindsBy(How = How.XPath, Using = "//table[@id='tbRecordingTransferCharges']/tbody/tr[@id='trCharge_1']/td/table/tbody/tr/td")]
        public IWebElement RecordingCharge1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tbFinancial']/tbody/tr[@id='trCharge_1']/td/table/tbody/tr/td")]
        public IWebElement FiancialCharge1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='tbFinancial']/tbody/tr[@id='trCharge_2']/td/table/tbody/tr/td")]
        public IWebElement FiancialCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrintDeliver")]
        public IWebElement PrintDeliver { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tbFinancial")]
        public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tbLoanCharges")]
        public IWebElement LoanCharges { get; set; }

        [FindsBy(How = How.Id, Using = "tblFileViewHdr")]
        public IWebElement HeaderTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "lblTableRow")]
        public IWebElement Table { get; set; }

        [FindsBy(How = How.LinkText, Using = "Buyer Charge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.LinkText, Using = "Buyer Credit")]
        public IWebElement BuyerCredit { get; set; }

        [FindsBy(How = How.LinkText, Using = "Seller Charge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.LinkText, Using = "Seller Credit")]
        public IWebElement SellerCredit { get; set; }

        [FindsBy(How = How.ClassName, Using = "tbHeader")]
        public IWebElement HeaderTableSS { get; set; }

        [FindsBy(How = How.ClassName, Using = "tdSubTotals")]
        public IWebElement SubTotalsHeader { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table.tbContent")]
        public IWebElement MainTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbTotalsSec")]
        public IWebElement SubTotalsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbCommissions")]
        public IWebElement CommissionTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbFinancial")]
        public IWebElement FinancialTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbProrationsAdjustments")]
        public IWebElement ProrationTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbLoanCharges")]
        public IWebElement LoanChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbImpounds")]
        public IWebElement ImpoundsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbTitleEscrowCharges")]
        public IWebElement TitleEscrowTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tbTitleEscrowCharges #trCharge_1 .tdChargeDesc")]
        public IWebElement TitleEscrowTable_ChargeDesc { get; set; }

        [FindsBy(How = How.Id, Using = "tbRecordingTransferCharges")]
        public IWebElement RecordingTransferChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbPayOffs")]
        public IWebElement PayOffTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbFundsHeld")]
        public IWebElement FundsHeldTable { get; set; }

        [FindsBy(How = How.Id, Using = "tbMiscellaneous")]
        public IWebElement MiscTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='idContainer']/table[1]")]
        public IWebElement ViewSettlementStatmentTable { get; set; }

        #endregion Old Screen elements

        #region New Screen elements

        [FindsBy(How = How.Id, Using = "btnCollapseAll")]
        public IWebElement btnCollapseAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnExpandAll")]
        public IWebElement btnExpandAll { get; set; }
        [FindsBy(How = How.Id, Using = "ParentTable")]
        public IWebElement ParentTable { get; set; }

        #region Subtotals Checkboxes
        [FindsBy(How = How.Id, Using = "chkSubTotal-CSTECHRGTO.")]
        public IWebElement TitleEscrow_SubtotalCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSDEPOSITS.")]
        public IWebElement DepositsInEscrow_SubtotalCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSCOMMISS.")]
        public IWebElement Commissions_SubtotalCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSelectAll")]
        public IWebElement SelectAll_SubtotalsCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSATTORNEY.")]
        public IWebElement Attorney_SubtotalsCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSNEWLN.")]
        public IWebElement NewLoan_SubtotalsCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSPAYOFFLN.")]
        public IWebElement PayoffLoan_SubtotalsCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSASSMPTLN.")]
        public IWebElement AssumptionLoan_SubtotalsCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "chkSubTotal-CSFUNDHELD.")]
        public IWebElement FundsHeld_SubtotalsCheckbox { get; set; }
        #endregion

        #region Disbursement paid subtotal checkboxes.
        //Old Disbursement Subtotal Checkbox
        //[FindsBy(How = How.Id, Using = "chkSubTotal-CSDISBRSPD.")]
        //public IWebElement DisbursementsPaid_SubtotalsCheckbox { get; set; }93-Disburse
        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'93-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_HomeOwnrAssoc_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'96-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_HomeWarranty_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'425-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_InspctnRep_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'359-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_Insurance_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'364-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_Lease_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'365-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_MiscDisbursements_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'373-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_PropertyTaxChk_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'376-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_Survey_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'378-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_Utility_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'692-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_REBCharges_SubtotalCheckbx { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'646-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_OutsideEscrow_SubtotalCheckbx { get; set; }

        #endregion


        [FindsBy(How = How.XPath, Using = "//tbody[contains(@rowkey,'646-Disburse')]//input[@id='chkSubTotal-CSDISBRSPD.']")]
        public IWebElement Disburs_OutsideEscrow_SubTable { get; set; }

        #region Disbursement paid labels.

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'93-Disburse')]//b[contains(text(),'Homeowner Association')]")]
        public IWebElement Disburs_HomeOwnrAssoc_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'96-Disburse')]//b[contains(text(),'Home Warranty')]")]
        public IWebElement Disburs_HomeWarranty_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'425-Disburse')]//b[contains(text(),'Inspection/Repair')]")]
        public IWebElement Disburs_InspctnRep_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'359-Disburse')]//b[contains(text(),'Insurance')]")]
        public IWebElement Disburs_Insurance_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'364-Disburse')]//b[contains(text(),'Lease')]")]
        public IWebElement Disburs_Lease_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'365-Disburse')]//b[contains(text(),'Miscellaneous Disbursement')]")]
        public IWebElement Disburs_MiscDisbursement_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'373-Disburse')]//b[contains(text(),'Property Tax Check')]")]
        public IWebElement Disburs_PropertyTaxChk_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'376-Disburse')]//b[contains(text(),'Survey')]")]
        public IWebElement Disburs_Survey_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'378-Disburse')]//b[contains(text(),'Utility')]")]
        public IWebElement Disburs_Utility_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'692-Disburse')]//b[contains(text(),'Real Estate Broker Charges')]")]
        public IWebElement Disburs_REBCharges_Label { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@rowkey,'646-Disburse')]//b[contains(text(),'Outside Escrow')]")]
        public IWebElement Disburs_OutsideEscrow_Label { get; set; }

        [FindsBy(How = How.Id, Using = "MiscDescrEditable")]
        public IWebElement MiscDisbpayee_edit { get; set; }

        #endregion


        #region Drag_Drop_Mappings

        #region Section mappings
        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSDISBRSPD')]//div[@class='Section_portlet_Header']")]
        public IWebElement DisbursementsTableDragDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSPAYOFFLN')]//div[@class='Section_portlet_Header']")]
        public IWebElement PayoffLoanTableDragDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSNEWLN')]//div[@class='Section_portlet_Header']")]
        public IWebElement NewLoanTableDragDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSASSMPTLN')]//div[@class='Section_portlet_Header']")]
        public IWebElement AssumptionLoanTableDragDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSSALEPRIC')]//div[@class='Section_portlet_Header']")]
        public IWebElement ConsiderationTableDragDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CashSection')]//div[@class='Section_portlet_Header']")]
        public IWebElement CashFromToTableDragDrop { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'TotalSection')]//div[@class='Section_portlet_Header']")]
        public IWebElement TotalsTableDragDrop { get; set; }
       
        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSCOMMISS')]//div[@class='Section_portlet_Header']")]
        public IWebElement CommissionTableDragDrop { get; set; }
        

        #endregion

        #region Instances
        [FindsBy(How = How.XPath, Using = "//tr[@class='ui-state-default groupheader_row'][contains(text(),'Mrtg. Broker: Broker One Mortgage')]")]
        public IWebElement Mortgage_Broker_Instance1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@class='ui-state-default groupheader_row'][contains(text(),'Lender: Loan Advisors')]")]
        public IWebElement Lender_Instance1 { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//div[@class='ui-state-default groupheader_row']//tr[@rowkey='367-1']")]
        public IWebElement Mortgage_Broker_Instance1_0 { get; set; }
        

        
        
        
        #endregion

        #region Charges
        #region Consideration Charges
        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/Span[contains(text(),'First Sale Price')]")]
        public IWebElement Consideration1stSaleP { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/Span[contains(text(),'Second Sale Price')]")]
        public IWebElement Consideration2ndSaleP { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/Span[contains(text(),'Third Sale Price')]")]
        public IWebElement Consideration3rdSaleP { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/Span[contains(text(),'Fourth Sale Price')]")]
        public IWebElement Consideration4thSaleP { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/Span[contains(text(),'Fifth Sale Price')]")]
        public IWebElement Consideration5thSaleP { get; set; }

        #endregion


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Transfer Fee to Homeowner Association Services, Inc')]")]
        public IWebElement Homeowner_AscCharge1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Lender: Loan Advisors')]")]
        public IWebElement Lender_AscCharge1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Administration Fee')]")]
        public IWebElement Fees_Charge1 { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Check Fee - Additional')]")]
        public IWebElement Fees_Charge3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-11']/tbody/tr[5]/td[3]/div")]
        public IWebElement fees_row3 { get; set; }

      

        [FindsBy(How = How.XPath, Using = "//table[@id='table-11']/tbody/tr[3]/td[5]/div")]
        public IWebElement fees_sellertot { get; set; }

        [FindsBy(How = How.Id, Using = "table-11")]
        public IWebElement feestable { get; set; }


        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[3]/td[1]/table/tbody/tr[4]/td[3]/div")]
        public IWebElement REBchrg_row3 { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'General Excise Tax')]")]
        public IWebElement REB_Charge1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'Other REB Broker charges')]")]
        public IWebElement REB_Charge3 { get; set; }

     

        //Commision subinstances table

        [FindsBy(How = How.XPath, Using = "//table[@id='table-6']/tbody/tr[3]/td/table")]
        public IWebElement Commision_1stinstancetable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='table-6']/tbody/tr[4]/td/table")]
        public IWebElement Commision_2ndinstancetable { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[@id='table-6']/tbody/tr[5]/td/table")]
        public IWebElement Commision_3rdinstancetable { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[@id='table-6']/tbody/tr[6]/td/table")]
        public IWebElement Commision_4thinstancetable { get; set; }
        //end


        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[3]/td/table/tbody/tr[2]/td[3]/div")]
        public IWebElement Inschargefrom { get; set; }
        [FindsBy(How = How.XPath, Using = "//table[@id='table-12']/tbody/tr[3]/td/table/tbody/tr[4]/td[3]/div")]
        public IWebElement Inschargeto { get; set; }





        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr'][contains(text(),'Association Dues to Homeowner Association Services, Inc')]")]
        public IWebElement Homeowner_AscCharge2 { get; set; }
        #endregion

        #endregion

        #region Editable Headers
        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSSALEPRIC')]//span[@id='DescrEditable']")]
        public IWebElement ConsiderationDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSDEPOSITS')]//span[@id='DescrEditable']")]
        public IWebElement DepositsInEscrowDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSDOETOTAL')]//span[@id='DescrEditable']")]
        public IWebElement EarnestMoneyDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSADJUST')]//span[@id='DescrEditable']")]
        [FindsBy(How = How.Id, Using = "table-4", Priority = 1)]
        public IWebElement AdjustmentsDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSPRORATE')]//span[@id='DescrEditable']")]
        public IWebElement ProrationsDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSCOMMISS')]//span[@id='DescrEditable']")]
        public IWebElement CommissionsDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSATTORNEY')]//span[@id='DescrEditable']")]
        public IWebElement AttorneysDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSNEWLN')]//span[@id='DescrEditable']")]
        public IWebElement NewLoanDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSPAYOFFLN')]//span[@id='DescrEditable']")]
        public IWebElement PayoffLoanDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSASSMPTLN')]//span[@id='DescrEditable']")]
        public IWebElement AssumptionLoanDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSTECHRGTO')]//span[@id='DescrEditable']")]
        public IWebElement TitleEscrowChrgDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSDISBRSPD')]//span[@id='DescrEditable']")]
        public IWebElement DisbursementsDescrH { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(@id,'CSFUNDHELD')]//span[@id='DescrEditable']")]
        public IWebElement FundsHeldDescrH { get; set; }
        #endregion

        // New ViewSettlementStatement Web Elements below this line.
        [FindsBy(How = How.Id, Using = "buyerPlusIcon")]
        public IWebElement buyerPlusIcon { get; set; }
        [FindsBy(How = How.Id, Using = "borrowerPlusIcon")]
        public IWebElement borrowerPlusIcon { get; set; }
        [FindsBy(How = How.Id, Using = "sellerPlusIcon")]
        public IWebElement sellerPlusIcon { get; set; }
        [FindsBy(How = How.Id, Using = "propertyPlusIcon")]
        public IWebElement propertyPlusIcon { get; set; }
        [FindsBy(How = How.Id, Using = "lenderPlusIcon")]
        public IWebElement LenderPlusIcon { get; set; }

        [FindsBy(How = How.Id, Using = "divlenderPlusIcon")]
        public IWebElement LenderHeaderDetails { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divlenderPlusIcon']//table")]
        public IWebElement LenderDetailsPopUpTbl { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divSellerInfo']/b[contains(text(),'Seller:')]")]
        public IWebElement customheadersellerlabel { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divPropertyInfo']/b[contains(text(),'Property:')]")]
        public IWebElement customheaderpropertylabel { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divBuyerInfo']//b[contains(text(),'Buyer:')]")]
        public IWebElement customheaderbuyerlabel { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divBuyerInfo']//b[contains(text(),'Borrower:')]")]
        public IWebElement customheaderborrowerlabel { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divsellerPlusIcon']//table")]
        public IWebElement sellerdetailsdialogbox { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divbuyerPlusIcon']//table")]
        public IWebElement buyerdetailsdialogbox { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divpropertyPlusIcon']//table")]
        public IWebElement propertydetailsdialogbox { get; set; }
        [FindsBy(How = How.Id, Using = "btnDonePopUp")]
        public IWebElement dialogboxbottomframedonebutton { get; set; }
        [FindsBy(How = How.Id, Using = "btnCancelPopUp")]
        public IWebElement dialogboxbottomframecancelbutton { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divLenderInfo']//b[contains(text(),'Lender:')]")]
        public IWebElement customheaderLenderlabel { get; set; }
        [FindsBy(How = How.XPath, Using = "//span[@id='ui-id-1']")]
        public IWebElement webpagedialogboxtitle { get; set; }

        [FindsBy(How = How.Id, Using = "Arrow-12")]
        public IWebElement DisbursementPaidSection { get; set; }

        [FindsBy(How = How.Id, Using = "CSDISBRSPD.")]
        public IWebElement CollapsableSectionDisbursementPaid { get; set; }

        [FindsBy(How = How.Id, Using = "CSFUNDHELD.")]
        public IWebElement NewFundsHeldTable { get; set; }

        [FindsBy(How = How.Id, Using = "CSSALEPRIC.")]
        public IWebElement NewConsiderationSection { get; set; }

        [FindsBy(How = How.Id, Using = "CSDEPOSITS.")]
        public IWebElement DepositsInEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "CSCOMMISS.")]
        public IWebElement Commission { get; set; }

        [FindsBy(How = How.Id, Using = "table-1")]
        public IWebElement NewConsiderationTable { get; set; }

        [FindsBy(How = How.Id, Using = "table-2")]
        public IWebElement NewDepositsInEscrowTable { get; set; }
        [FindsBy(How = How.Id, Using = "table-3")]
        public IWebElement EMTable { get; set; }
        [FindsBy(How = How.Id, Using = "table-4")]
        public IWebElement AdjustmentsTable { get; set; }
        [FindsBy(How = How.Id, Using = "table-5")]
        public IWebElement ProrationsTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#table-11")]
        public IWebElement TitleEscrowRecordTxTable { get; set; }

        [FindsBy(How = How.Id, Using = "CSTECHRGTO.")]
        public IWebElement TitleEscrowChargesTBL { get; set; }


        [FindsBy(How = How.CssSelector, Using = "#table-6")]
        public IWebElement NewCommissionsTable { get; set; }

        [FindsBy(How = How.Id, Using = "CSATTORNEY.")]
        public IWebElement Attorney { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#table-7")]
        public IWebElement NewAttorneyTable { get; set; }

        [FindsBy(How = How.Id, Using = "table-8")]
        public IWebElement NewNewLoanTable { get; set; }

        [FindsBy(How = How.Id, Using = "table-13")]
        public IWebElement FundsHeldTableUseID { get; set; }

        [FindsBy(How = How.Id, Using = "CSPAYOFFLN.")]
        public IWebElement PayoffLoan { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#table-9")]
        public IWebElement NewPayoffLoanTable { get; set; }

        [FindsBy(How = How.Id, Using = "CSASSMPTLN.")]
        public IWebElement AssumptionLoan { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#table-10")]
        public IWebElement AssumptionLoanTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#table-12")]
        public IWebElement DisbursementsTable { get; set; }

        [FindsBy(How = How.Id, Using = "CashSection")]
        public IWebElement CashSection { get; set; }

        [FindsBy(How = How.Id, Using = "table-900")]
        public IWebElement CashSectionTable { get; set; }

        [FindsBy(How = How.ClassName, Using = "contextregion_misctable")]
        public IWebElement MiscellaneousDisbursementTable { get; set; }
     
        [FindsBy(How = How.XPath, Using = "//table[@id='contextregion_misctable ui-sortable']/tbody/tr/td[4]/div/Span")]
        public IWebElement Miscdisb_header { get; set; }

        [FindsBy(How = How.ClassName, Using = "context-menu")]
        public IWebElement MiscellaneousDisbursementContextMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='context-menu__items']/li[@class='context-menu__item']/span[@class='context-menu__link']")]
        public IWebElement CreateGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='context-menu__items']/li[@class='context-menu__item sub-menu__enable']/span")]
        public IWebElement AddtoGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='context-menu__items']/li[@class='context-menu__link disable-context-menu__item']/span[@class='context-menu__link disable-context-menu__item']")]
        public IWebElement AddtoGroupDisabled { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='context-menu__customgroup']/li[@class='customgrp_submenu']/span[@class='span_submenu']")]
        public IWebElement AddtoGroupSubList1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='misc_group_divider']/span[contains(text(),'Misc. Disbursement 2 for HUD Test Name 1 Misc. Disbursement 2 for HUD Test Name 2')]")]
        public IWebElement AddtoGroupSubList2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='context-menu__items']/li[@class='context-menu__item']/span[@class='context-menu__link']")]
        public IWebElement RemovefromGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@class='context-menu__items']/li[@class='context-menu__link disable-context-menu__item']/span")]
        public IWebElement RemovefromGroupDisabled { get; set; }
        [FindsBy(How = How.Id, Using = "tblcustomgroup-1")]
        public IWebElement MDFirstGroup { get; set; }

        [FindsBy(How = How.Id, Using = "tblcustomgroup-2")]
        public IWebElement MDSecondGroup { get; set; }

        [FindsBy(How = How.Id, Using = "tblcustomgroup-3")]
        public IWebElement MDThirdGroup { get; set; }



        [FindsBy(How = How.XPath, Using = "//td[@class='maxWidth200 chargeStyle ']/div[contains(text(),'432,235,527.11')]")]
        public IWebElement Disbursement_Paid_Misd_FirstGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@class='maxWidth200 chargeStyle ']/div[contains(text(),'690,821,239.76')]")]
        public IWebElement Disbursement_Paid_Misd_SecondGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//td[@class='maxWidth200 chargeStyle ']/div[contains(text(),'705.00')]")]
        public IWebElement Disbursement_Paid_Misd_ThirdGroup { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='subTotalDescrStyle']/span[contains(text(),'1stInstFirstcharge ')]")]
        public IWebElement Disbursement_Paid_Misd__1st_1stCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='subTotalDescrStyle']/span[contains(text(),'3rdInstSecondCharge')]")]
        public IWebElement Disbursement_Paid_Misd_3rd_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='subTotalDescrStyle']/span[contains(text(),'2ndInstFirstCharge ')]")]
        public IWebElement Disbursement_Paid_Misd_2nd_1stCharge { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='subTotalDescrStyle']/span[contains(text(),'2ndInstSecondCharge ')]")]
        public IWebElement Disbursement_Paid_Misd_2nd_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='subTotalDescrStyle']/span[contains(text(),'1stInstSecondcharge ')]")]
        public IWebElement Disbursement_Paid_Misd_1st_2ndCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'3rdInstThirdCharge ')]")]
        public IWebElement Disbursement_Paid_Misd_3rd_3rdCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1stInstThirdcharge ')]")]
        public IWebElement Disbursement_Paid_Misd_1st_3rdCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'1stInstFourthcharge ')]")]
        public IWebElement Disbursement_Paid_Misd_1st_4thCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='maxWidth400 ChargeDescr']/span[@class='nonsubTotalDescrStyle']/span[contains(text(),'3rdInstFourthCharge ')]")]
        public IWebElement Disbursement_Paid_Misd_3rd_4thCharge { get; set; }



        #region GotoMenu
        [FindsBy(How = How.ClassName, Using = "CDGoToMenu")]
        public IWebElement GoToButton { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSSALEPRIC.")]
        public IWebElement GoToSalePrice { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSDEPOSITS.")]
        public IWebElement GoToDeposits { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSDOETOTAL.")]
        public IWebElement GoToEarnestMoney { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSADJUST.")]
        public IWebElement GoToAdjustments { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSPRORATE.")]
        public IWebElement GoToProrations { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSCOMMISS.")]
        public IWebElement GoToComissions { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSATTORNEY.")]
        public IWebElement GoToAttorney { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSNEWLN.")]
        public IWebElement GoToNewLoans { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSPAYOFFLN.")]
        public IWebElement GoToPayAssumtionLoan { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSTECHRGTO.")]
        public IWebElement GoToTitleEscrowChrgs { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSDISBRSPD.")]
        public IWebElement GoToDisbursementPaid { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CSFUNDHELD.")]
        public IWebElement GoToFundsHeld { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-CashSection")]
        public IWebElement GoToCashFromTo { get; set; }

        [FindsBy(How = How.Id, Using = "GoTo-TotalSection")]
        public IWebElement GoToTotals { get; set; }


        #endregion
        #endregion

        #endregion
        #region Methods

        public NCSViewSettlementStatement MarkSelectAllCheckBox()
        {
            SelectAll_SubtotalsCheckbox.FAClick();
            return this;
        }

        public NCSViewSettlementStatement Open(IWebElement element = null)
        {
            FastDriver.LeftNavigation.Navigate<ViewSettlementStatement>("Home>Order Entry>Escrow Closing>View Settlement Stmt.");
            this.WaitForScreenToLoad();

            return this;
        }

        public NCSViewSettlementStatement DragAndDropRowOnTableUsingRowIndex(IWebElement table, int fromRowIndex, int toRowIndex, int offsetY = 15)
        {
            // Build the elements dynamically using the description column on the table
            IWebElement fromElement = table.FindElement(By.XPath("./tbody/tr[" + fromRowIndex + "]"));
            IWebElement toElement = table.FindElement(By.XPath("./tbody/tr[" + toRowIndex + "]"));

            fromElement.FADragAndDropWithOffset(toElement, offsetY);

            return this;
        }

        //public ViewSettlementStatement WaitForScreenToLoad(IWebElement element = null)
        //{
        //    this.SwitchToContentFrame();

        //    if (element != null)
        //        this.WaitCreation(element);
        //    else
        //    {
        //        if (AutoConfig.UseCDFormType)
        //            this.WaitCreation(MainTable, 20);
        //        else
        //            this.WaitCreation(PrintDeliver, 20);
        //    }

        //    return this;
        //}

        public NCSViewSettlementStatement WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();

            /*if (AutoConfig.UseCDFormType)
                this.WaitCreation(element ?? MainTable);
                else
                this.WaitCreation(element ?? PrintDeliver);*/
            this.WaitCreation(element ?? SelectAll_SubtotalsCheckbox);

            return this;
        }

        public NCSViewSettlementStatement WaitForOldScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PrintDeliver, 20);

            return this;
        }

        public NCSViewSettlementStatement verifyColumnsLocation(string SellerDebit = null, string SellerCredit = null, string Description = null, string BuyerDebit = null, string BuyerCredit = null)
        {
            this.SwitchToContentFrame();
            System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> tds = getTableHeader().FindElements(By.TagName("td"));
            string[] colName;
            if (SellerDebit != null)
            {
                colName = SellerDebit.Split(' ');
                Reports.StatusUpdate("Seller Debit Column is Located on the first Column on the left side of the screen.", (tds[0].Text.Replace("\n", "").Replace(" ", "").Contains(colName[0])
                    && tds[0].Text.Replace("\n", "").Replace(" ", "").Contains(colName[1])));
            }

            if (SellerCredit != null)
            {
                colName = SellerCredit.Split(' ');
                Reports.StatusUpdate("Seller Credit Column is Located on the Second Column on the left side of the screen.", (tds[1].Text.Replace("\n", "").Replace(" ", "").Contains(colName[0])
                    && tds[1].Text.Replace("\n", "").Replace(" ", "").Contains(colName[1])));
            }

            if (Description != null)
            {
                Reports.StatusUpdate("Description Column is Located on the Third Column on the center of the screen.", (Description.Replace(" ", "") == tds[2].Text.Replace("\n", "").Replace(" ", "").Trim()));
            }

            if (BuyerDebit != null)
            {
                colName = BuyerDebit.Split(' ');
                Reports.StatusUpdate("Buyer Debit Column is Located on the Fourth Column on the right side of the screen.", (tds[3].Text.Replace("\n", "").Replace(" ", "").Contains(colName[0])
                    && tds[3].Text.Replace("\n", "").Replace(" ", "").Contains(colName[1]) && tds[3].Text.Replace("\n", "").Replace(" ", "").Contains(colName[2])));
            }

            if (BuyerCredit != null)
            {
                colName = BuyerCredit.Split(' ');
                Reports.StatusUpdate("Buyer Credit Column is Located on the Fifth Column on the right side of the screen.", (tds[4].Text.Replace("\n", "").Replace(" ", "").Contains(colName[0])
                    && tds[4].Text.Replace("\n", "").Replace(" ", "").Contains(colName[1]) && tds[4].Text.Replace("\n", "").Replace(" ", "").Contains(colName[2])));
            }

            return this;
        }

        public IWebElement getTableHeader()
        {
            IWebElement table = FastDriver.WebDriver.FindElements(By.TagName("table")).FirstOrDefault(i => i.GetAttribute("class").Contains("tbHeader") && i.Displayed);
            //Debug.Print(table.Text);

            return table;
        }

        public NCSViewSettlementStatement verifyRowsForSubtotalsSection()
        {
            IWebElement tableContent = FastDriver.WebDriver.FindElements(By.TagName("table")).FirstOrDefault(i => i.GetAttribute("class").Contains("tbContent") && i.Displayed);
            IWebElement SubTotalHeader = tableContent.PerformTableAction((tableContent.GetRowCount() - 3), 1, TableAction.GetCell).Element;
            IWebElement totalSectionTable = FastDriver.WebDriver.FindElement(By.Id("tbTotalsSec"));

            if (SubTotalHeader.Text != "Subtotals")
                Reports.StatusUpdate("Subtotals Header Table is displayed in the expected row.", true);
            else
                Reports.StatusUpdate("Subtotals Header Table is not displayed in the expected row.", false);

            if (totalSectionTable.GetRowCount() == 3)
                Reports.StatusUpdate("The number of rows for Subtotals Section are correct.", true);
            else
                Reports.StatusUpdate("The number of rows for Subtotals Section are not the expected.", true);

            return this;
        }

        public bool AreSubtotalsLabelAndCheckboxDisplayed()
        {
            try
            {
                Support.AreEqual("false", FastDriver.ViewSettlementStatement.CollapsableSectionDisbursementPaid.FindElement(By.LinkText("Subtotals")).IsDisplayed().ToString().ToLower(), "System should not display the Subtotal Label and checkbox.");
                return true;
            }
            catch (NoSuchElementException e)
            {
                return false;
            }
        }

        public bool IsDisbursementSectionDisabled()
        {
            try
            {
                Support.AreEqual("true", FastDriver.ViewSettlementStatement.CollapsableSectionDisbursementPaid.FindElement(By.ClassName("SectionHeader_disabled")).FAGetText().Contains("Disbursements Paid").ToString().ToLower(), "System should display the Disbursement section in grey and collapsed.");
                return true;
            }
            catch (NoSuchElementException e)
            {
                return false;
            }
        }

        public void GoToButtonHover()
        {
            WebDriver.WaitForWindowAndSwitch("One Moment Please...", false, 10);
            WaitForScreenToLoad();
            GoToButton.FAClick();

        }

        public NCSViewSettlementStatement SelectDocuments(IWebElement table, List<string> documents)
        {
            

            List<IWebElement> docs = new List<IWebElement>();

            if (documents == null)
                docs = DisbursementsTable.FindElements(By.XPath(".//tr")).Where(row => row.Displayed).ToList(); // select all
            else
            {
                foreach (var doc in documents)
                {
                    try
                    {
                         
                        docs.Add(table.FindElement(By.XPath(".//tr/td/div/span/*[text()='" + doc + "']")));
                    }
                    catch
                    {
                        Reports.StatusUpdate("Unable to find document '" + doc + "' on the table", true);
                    }
                }
            }


            if (docs.Count == 0)    //  unable to find any doc on table
               return this;

            UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
            Playback.Wait(500); // need this
            for (int i = 0; i < docs.Count; i++)
            {
                docs[i].Click();                                  // click on row to select
            }
            UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);     // release CTRL key
            
           return this;
        }

    
       


        #endregion
    }
}
