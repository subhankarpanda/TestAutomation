using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.PageObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Interactions.Internal;
using OpenQA.Selenium.Interactions;
using System.IO;
using OpenQA.Selenium.IE;

namespace FASTSelenium.PageObjects.IIS
{
	public class NewFileEntry : PageObject
	{

        int waitTime = Convert.ToInt32(AutoConfig.WaitTime);
		#region WebElements

        [FindsBy(How = How.Id, Using = "tabNFE_dgridEscrow_dgridEscrow")]
        public IWebElement EscrowProdOfficeGridTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_dgridTitle_dgridTitle")]
        public IWebElement TitleProdOfficeGridTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tabNFE_pnTOO']/table[2]")]
        public IWebElement TitleOwningOfficeTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_lblEnteredBy")]
		public IWebElement EnteredBy { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement MessagePane { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement FileStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndName")]
        public IWebElement DetailsBuyerIndividualName { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndMiddle")]
        public IWebElement DetailsBuyerIndividualMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndLast")]
        public IWebElement DetailsBuyerIndividualLastName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSpouseName")]
		public IWebElement DetailsBuyerSpouseName { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement DetailsFileEstimatedDate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Details")]
		public IWebElement DetailsDetail { get; set; }

		[FindsBy(How = How.LinkText, Using = "Parties")]
		public IWebElement DetailsParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Info")]
		public IWebElement DetailsPropertyInfo { get; set; }

        [FindsBy(How = How.LinkText, Using = "Lenders/Mortgage Brokers")]
		public IWebElement DetailsLendersMortgageBrokers { get; set; }

		[FindsBy(How = How.LinkText, Using = "Special Instructions")]
		public IWebElement DetailsSpecialInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPrefix")]
		public IWebElement DetailsNewFileEntryPrefix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtCustFileNo")]
		public IWebElement DetailsNewFileEntryCustFileNo { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtSuffix")]
		public IWebElement DetailsNewFileEntrySuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_chkAutoNo")]
		public IWebElement DetailsAutoNumber { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtMasterFile")]
		public IWebElement DetailsNewFileEntryMasterFile { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtLotNo")]
		public IWebElement DetailsNewFileEntryLotNo { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnCOO")]
		public IWebElement DetailsChangeOObutton { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_chkTitle")]
		public IWebElement DetailsTitlecheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_chkEscrow")]
		public IWebElement DetailsEscrowcheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_chkSubEscrow")]
		public IWebElement DetailsSubEscrowcheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_rdCD")]
		public IWebElement FormType_CD { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_rdHUD")]
		public IWebElement FormType_HUD { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboTitleOffice")]
		public IWebElement DetailsNewFileEntryTitleOffice { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboTitleOfficer")]
		public IWebElement DetailsNewFileEntryTitleOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboEscrowOffice")]
		public IWebElement DetailsNewFileEntryEscrowOffice { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboEscrowOfficer")]
		public IWebElement DetailsNewFileEntryEscrowOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboEscrowAssistant")]
		public IWebElement DetailsNewFileEntryEscrowAssisstant { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboUnderWriters")]
		public IWebElement DetailsNewFileEntryUnderWriters { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboBusinessSegment")]
		public IWebElement DetailsNewFileEntryBusinessSegment { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboTransType")]
		public IWebElement DetailsNewFileEntryBusinessSegment1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboTransType")]
		public IWebElement DetailsNewFileEntryTransactionType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboProgramType")]
		public IWebElement DetailsNewFileEntryProgramType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridOwnerPolicy_0_radSelect")]
		public IWebElement DetailsDetailsNewFileEntryPolicyRadiobutton { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddRemoveOwnerPolicy")]
		public IWebElement DetailsAddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridLenderPolicy_0_chkSelect")]
		public IWebElement DetailsNewFileEntryPolicySelect { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddRemoveLenderPolicy")]
		public IWebElement DetailsAddRemoveLenderPolicy { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridOthers_0_chkSelectOth")]
		public IWebElement DetailsNewFileEntrySelectOther { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddRemoveOthers")]
		public IWebElement DetailsAddRemoveother { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_btnAddRemoveGuarantee")]
        public IWebElement DetailsAddRemoveGuarantee { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridOwnerPolicy_dgridOwnerPolicy")]
		public IWebElement OwnerPolicyTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridLenderPolicy_dgridLenderPolicy")]
		public IWebElement LenderPolicyTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridOthers_dgridOthers")]
		public IWebElement OthersTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_dgridGuarantee_dgridGuarantee")]
        public IWebElement GuaranteeTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_txtGABcode")]
		public IWebElement DetailsBussSourceGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_cmdFindName")]
		public IWebElement DetailsFind { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_txtName")]
		public IWebElement DetailsBuinessSourceName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_chkEditContactInfo")]
		public IWebElement DetailsEditCheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textBusPhone")]
		public IWebElement DetailsNewFileEntryBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_txtExtnPhone")]
		public IWebElement DetailsNewFileEntryBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textBusFax")]
		public IWebElement DetailsNewFileEntryBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textCellPhone")]
		public IWebElement DetailsNewFileEntryCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textPager")]
		public IWebElement DetailsPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textEmailAddress")]
		public IWebElement DetailsEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_chkWeeklyEmailStatus")]
		public IWebElement DetailsEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_comboAttention")]
		public IWebElement DetailsAttention { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_chkEdit")]
		public IWebElement DetailsEditNameCheckbox { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textName")]
		public IWebElement DetailsEditName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_comboSalesRep1")]
		public IWebElement DetailsSalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_comboSalesRep2")]
		public IWebElement DetailsSalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_textReference")]
		public IWebElement DetailsReference { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_comboAddtionalRole")]
		public IWebElement DetailsAddtionalRole { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_txtPercent")]
		public IWebElement DetailsPercent { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_txtAmount")]
		public IWebElement DetailsAmount { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboSearchInsts")]
		public IWebElement DetailsSearchType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddRmvInsts")]
		public IWebElement DetailsAddRemoveInstruction { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtInstructions")]
		public IWebElement DetailsNewFileEntryInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtAddInstructions")]
		public IWebElement DetailsNewFileEntryAddInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "btnScan")]
		public IWebElement DetailsScan { get; set; }

		[FindsBy(How = How.Id, Using = "btnUpload")]
		public IWebElement DetailsUpload { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnRefresh")]
		public IWebElement DetailsRefresh { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnDInstruction")]
		public IWebElement DetailsDistributieryInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_btnAddNew")]
		public IWebElement DetailsAddNew_buyer { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_btnRemove")]
		public IWebElement DetailsRemove_buyer { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_btnSignature")]
		public IWebElement DetailsSignatures { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_cboType")]
		public IWebElement DetailsBuyerType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtHusName")]
		public IWebElement DetailsBuyerHusbandName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtHusMiddle")]
		public IWebElement DetailsBuyerHusbandMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtHusLast")]
		public IWebElement DetailsBuyerHusbandLast { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtHusSuffix")]
		public IWebElement DetailsBuyerHusbandSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtHusSSNTIN")]
		public IWebElement DetailsBuyerHusbandSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSpouseName")]
		public IWebElement DetailsBuyerSpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSpouseMiddle")]
		public IWebElement DetailsBuyerSpouseMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSpouseLast")]
		public IWebElement DetailsBuyerSpouseLast { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSpouseSuffix")]
		public IWebElement DetailsBuyerSpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSpouseSSNTIN")]
		public IWebElement DetailsBuyerSpouseSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSt1")]
		public IWebElement DetailsBuyerStreet1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSt2")]
		public IWebElement DetailsBuyerStreet2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSt3")]
		public IWebElement DetailsBuyerStreet3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtSt4")]
		public IWebElement DetailsBuyerStreet4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtCity")]
		public IWebElement DetailsBuyerCity { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_cboState")]
		public IWebElement DetailsBuyerState { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtZIP")]
		public IWebElement DetailsBuyerZIP { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtCounty")]
		public IWebElement DetailsBuyerCounty { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_cboCountry")]
		public IWebElement DetailsBuyerCountry { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtBusPh")]
		public IWebElement DetailsBuyerBusPh { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtExtnPhone")]
		public IWebElement DetailsBuyerHomePhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtHomePh")]
		public IWebElement DetailsBuyerHomePh { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtBusFax")]
		public IWebElement DetailsBuyerBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtCellFax")]
		public IWebElement DetailsBuyerCellFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtPager")]
		public IWebElement DetailsBuyerPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtEmail")]
		public IWebElement DetailsBuyerEmail { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_btnAddNew")]
		public IWebElement DetailsAddNewSeller { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_btnRemove")]
		public IWebElement DetailsRemoveSeller { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_btnSignature")]
		public IWebElement DetailsSignaturesseller { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_cboType")]
		public IWebElement DetailsSellerType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtHusName")]
		public IWebElement DetailsSellerHusbandName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtHusMiddle")]
		public IWebElement DetailsSellerHusbandMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtHusLast")]
		public IWebElement DetailsSellerHusbandLast { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtHusSuffix")]
		public IWebElement DetailsSellerHusbandSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtHusSSNTIN")]
		public IWebElement DetailsSellerHusbandSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSpouseName")]
		public IWebElement DetailsSellerSpouseName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSpouseMiddle")]
		public IWebElement DetailsSellerSpouseMiddle { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSpouseLast")]
		public IWebElement DetailsSellerSpouseLast { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSpouseSuffix")]
		public IWebElement DetailsSelerSpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSpouseSSNTIN")]
		public IWebElement DetailsSellerSpouseSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSt1")]
		public IWebElement DetailsSellerStreet1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSt2")]
		public IWebElement DetailsSellerStreet2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSt3")]
		public IWebElement DetailsSellerStreet3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtSt4")]
		public IWebElement DetailsSellerStreet4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtCity")]
		public IWebElement DetailsSellerCity { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_cboState")]
		public IWebElement DetailsSellerState { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtZIP")]
		public IWebElement DetailsSellerZIP { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtCounty")]
		public IWebElement DetailsSellerCounty { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_cboCountry")]
		public IWebElement DetailsSellerCountry { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtBusPh")]
		public IWebElement DetailsSellerBusPh { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtExtnPhone")]
		public IWebElement DetailsSellerBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtHomePh")]
		public IWebElement DetailsSellerHomePh { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtBusFax")]
		public IWebElement DetailsSellerBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtCellFax")]
		public IWebElement DetailsSellerCellFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtPager")]
		public IWebElement DetailsSellerPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtEmail")]
		public IWebElement DetailsSellerEmail { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPropertyType")]
		public IWebElement DetailsPropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPropertySt1")]
		public IWebElement DetailsPropertyStreet1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPropertySt2")]
		public IWebElement DetailsPropertyStreet2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPropertySt3")]
		public IWebElement DetailsPropertyStreet3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPropertySt4")]
		public IWebElement DetailsPropertyStreet4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPropertyCity")]
		public IWebElement DetailsPropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPropertyState")]
		public IWebElement DetailsPropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPropertyZIP")]
		public IWebElement DetailsPropertyZIP { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPropertyCounty")]
		public IWebElement DetailsPropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPropertyCountry")]
		public IWebElement DetailsPropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucTerms_txtSalePrice")]
		public IWebElement DetailsSalePrice { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucTerms_txtLiability")]
		public IWebElement DetailsLiability { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucTerms_txtFirstNewLoan")]
		public IWebElement DetailsFirstNewLoan { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucTerms_txtFirstNewLoanLiability")]
		public IWebElement DetailsFirstNewLoanLiability { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucTerms_txtSecondNewLoan")]
		public IWebElement DetailsSecondNewLoan { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucTerms_txtSecondNewLoanLiability")]
		public IWebElement DetailsSecondNewLoanLiability { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDates_txtEstDaystoClose")]
		public IWebElement DetailsEstimatedDaystoClose { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDates_txtEstSettleDate")]
		public IWebElement DetailsEstimatedSettleDate { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDates_txtDateOfContract")]
		public IWebElement DetailsDateOfContract { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDates_txtDateOfContractAccpt")]
		public IWebElement DetailsDateofContractAccept { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridDocs_1_lblDocName")]
		public IWebElement ScanRow { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_dgridDocs")]
        public IWebElement UploadedDocumentsTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous PDFDocument")]
		public IWebElement UploadRowPDF { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous JPGFile")]
		public IWebElement UploadRowJPG { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous TIFFFile")]
		public IWebElement UploadRowTIFF { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous DOCFile")]
		public IWebElement UploadRowDoc { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous DOCXFile")]
		public IWebElement UploadRowDocx { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous XLSFile")]
		public IWebElement UploadRowXls { get; set; }

		[FindsBy(How = How.LinkText, Using = "Miscellaneous XLSXFile")]
		public IWebElement UploadRowXlsx { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ImagePDF { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ImageJPG { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ImageTIFF { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ImageDoc { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ImageDocx { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Imagexls { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Imagexlsx { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndName")]
		public IWebElement IndBuyerF { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndMiddle")]
		public IWebElement IndBuyerM { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndLast")]
		public IWebElement IndBuyerL { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtTrustBEName")]
		public IWebElement TrustBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_dgridBuyerSeller")]
		public IWebElement BuyerSummary { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtIndName")]
		public IWebElement IndSellerF { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtIndMiddle")]
		public IWebElement IndSellerM { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtIndLast")]
		public IWebElement IndSellerL { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtTrustBEName")]
		public IWebElement TrustSeller { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_dgridBuyerSeller")]
		public IWebElement SellerSummary { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboBusSrcType")]
		public IWebElement BusType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtAddInstructions")]
		public IWebElement AdditionalInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelIdcode")]
		public IWebElement Gcode1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelName")]
		public IWebElement Name1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelName2")]
		public IWebElement Name2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelAddress")]
		public IWebElement Address1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelAddress2")]
		public IWebElement Address2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelStateAndZip")]
		public IWebElement Address3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtExtnPhone")]
		public IWebElement BuyerPhExtn { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtExtnPhone")]
		public IWebElement SellerPhExtn { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndSuffix")]
		public IWebElement IndBuyerSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtIndSSNTIN")]
		public IWebElement IndBuyerSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtIndSuffix")]
		public IWebElement IndSellerSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtIndSSNTIN")]
		public IWebElement IndSellerSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucBuyer_txtTrustBESSNTIN")]
		public IWebElement TrustBuyerSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtTrustBESSNTIN")]
		public IWebElement TrustSellerSSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement PartiesFileEstimatedDate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Details")]
		public IWebElement PartiesDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Parties")]
		public IWebElement PartiesParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Info")]
		public IWebElement PartiesPropertyInfo { get; set; }

		[FindsBy(How = How.LinkText, Using = "Lenders/Mortgage Brokers")]
		public IWebElement PartiesLendersMortgageBrokers { get; set; }

		[FindsBy(How = How.LinkText, Using = "Special Instructions")]
		public IWebElement PartiesSpecialInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_txtGABcode")]
		public IWebElement PartiesDirectedByGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_cmdFindName")]
		public IWebElement PartiesDirectedByFind { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_txtName")]
		public IWebElement PartiesDirectedByName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_chkEditContactInfo")]
		public IWebElement PartiesDirectedByEditContact { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textBusPhone")]
		public IWebElement PartiesDirectedByBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_txtExtnPhone")]
		public IWebElement PartiesDirectedByBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textBusFax")]
		public IWebElement PartiesDirectedByBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textCellPhone")]
		public IWebElement PartiesDirectedByCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textPager")]
		public IWebElement PartiesDirectedByPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textEmailAddress")]
		public IWebElement PartiesDirectedByEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_chkWeeklyEmailStatus")]
		public IWebElement PartiesDirectedByEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_comboAttention")]
		public IWebElement PartiesDirectedByAttention { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_chkEdit")]
		public IWebElement PartiesDirectedByEdit { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textName")]
		public IWebElement PartiesDirectedByEditName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_comboSalesRep1")]
		public IWebElement PartiesDirectedBySalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_comboSalesRep2")]
		public IWebElement PartiesDirectedBySalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_textReference")]
		public IWebElement PartiesDirectedByReference { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_comboAddtionalRole")]
		public IWebElement PartiesDirectedByAddtionalRole { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_txtPercent")]
		public IWebElement PartiesDirectedByPercent { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_txtAmount")]
		public IWebElement PartiEstimatedDirectedByAmount { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_txtGABcode")]
		public IWebElement PartiesAssociatedBusPartyGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_cmdFindName")]
		public IWebElement PartiesAssociatedBusPartyFind { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_txtName")]
		public IWebElement PartiesAssociatedBusPartyName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_chkEditContactInfo")]
		public IWebElement PartiesAssociatedBusPartyEditcont { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textBusPhone")]
		public IWebElement PartiesAssociatedBusPartyBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_txtExtnPhone")]
		public IWebElement PartiesAssociatedBusPartyBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textBusFax")]
		public IWebElement PartiesAssociatedBusPartyBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textCellPhone")]
		public IWebElement PartiesAssociatedBusPartyCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textPager")]
		public IWebElement PartiesAssociatedBusPartyPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textEmailAddress")]
		public IWebElement PartiesAssociatedBusPartyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_chkWeeklyEmailStatus")]
		public IWebElement PartiesAssociatedBusPartyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_comboAttention")]
		public IWebElement PartiesAssociatedBusPartyAttention { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_chkEdit")]
		public IWebElement PartiesAssociatedBusPartyEdit { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textName")]
		public IWebElement PartiesAssociatedBusPartyEditName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_comboSalesRep1")]
		public IWebElement PartiesAssociatedBusPartySalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_comboSalesRep2")]
		public IWebElement PartiesAssociatedBusPartySalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_textReference")]
		public IWebElement PartiesAssociatedBusPartyReference { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_comboAddtionalRole")]
		public IWebElement PartiesAssociatedBusPartyAddtionalRole { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_txtPercent")]
		public IWebElement PartiesAssociatedBusPartyPercent { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_txtAmount")]
		public IWebElement PartiesAssociatedBusPartyAmount { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cmdAddRemoveEscrowOffice")]
		public IWebElement PartiesAddRemoveEscrowproductionOffice { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cmdAddRemoveTitleOffice")]
		public IWebElement PartiesAddRemoveTitleproductionOffice { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_labelIdcode")]
		public IWebElement PartiesGcode1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_labelName")]
		public IWebElement PartiesName1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_labelName2")]
		public IWebElement PartiesName2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_labelAddress")]
		public IWebElement PartiesAddress1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_labelAddress2")]
		public IWebElement PartiesAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucDirectedBy_labelStateAndZip")]
		public IWebElement PartiesAddress3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_labelIdcode")]
		public IWebElement AssociatedPartiesGcode1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_labelName")]
		public IWebElement AssociatedPartiesName1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_labelName2")]
		public IWebElement AssociatedPartiesName2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_labelAddress")]
		public IWebElement AssociatedPartiesAddress1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_labelAddress2")]
		public IWebElement AssociatedPartiesAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucAssoBusParty_labelStateAndZip")]
		public IWebElement AssociatedPartiesAddress3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridOwnerPolicy_0_radSelect")]
		public IWebElement Product1 { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement PropertyInfoFileEstimateddate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Details")]
		public IWebElement PropertyInfoDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Parties")]
		public IWebElement PropertyInfoParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Info")]
		public IWebElement PropertyInfoPropertyInfo { get; set; }

		[FindsBy(How = How.LinkText, Using = "Lenders/Mortgage Brokers")]
		public IWebElement PropertyInfoLendersMortgageBrokers { get; set; }

		[FindsBy(How = How.LinkText, Using = "Special Instructions")]
		public IWebElement PropertyInfoSpecialInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPInfoPropertyType")]
		public IWebElement PropertyInfoPropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtAPNTMK")]
		public IWebElement PropertyInfoNewFileEntryAPNTMK { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPInfoPropertySt1")]
		public IWebElement PropertyInfoPropertyStreet1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPInfoPropertySt2")]
		public IWebElement PropertyInfoPropertyStreet2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPInfoPropertySt3")]
		public IWebElement PropertyInfoPropertyStreet3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPInfoPropertySt4")]
		public IWebElement PropertyInfoPropertyStreet4 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPInfoPropertyCity")]
		public IWebElement PropertyInfoPropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPInfoPropertyState")]
		public IWebElement PropertyInfoPropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPInfoPropertyZIP")]
		public IWebElement PropertyInfoPropertyZIP { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPInfoPropertyCounty")]
		public IWebElement PropertyInfoPropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_cboPInfoPropertyCountry")]
		public IWebElement PropertyInfoPropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtLot")]
		public IWebElement PropertyInfoLot { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtBlock")]
		public IWebElement PropertyInfoBlock { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtUnit")]
		public IWebElement PropertyInfoUnit { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtTrack")]
		public IWebElement PropertyInfoTrack { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtFee")]
		public IWebElement PropertyInfoFee { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtBuilding")]
		public IWebElement PropertyInfoBuilding { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtBook")]
		public IWebElement PropertyInfoBook { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtPage")]
		public IWebElement PropertyInfoPage { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtSection")]
		public IWebElement PropertyInfoSection { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtTownShip")]
		public IWebElement PropertyInfoTownShip { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtRange")]
		public IWebElement PropertyInfoRange { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtParcel")]
		public IWebElement PropertyInfoParcel { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtSubDivCond")]
		public IWebElement PropertyInfoSubDivisionCondominium { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ddlEstateType")]
		public IWebElement PropertyInfoEstimatedateType { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement LenderMortgageBrokersFileStatus { get; set; }

		[FindsBy(How = How.LinkText, Using = "Details")]
		public IWebElement LenderMortgageBrokersDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Parties")]
		public IWebElement LenderMortgageBrokersParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Info")]
		public IWebElement LenderMortgageBrokersPropertyInfo { get; set; }

		[FindsBy(How = How.LinkText, Using = "Lenders/Mortgage Brokers")]
		public IWebElement LenderMortgageBrokersLendersMortgageBrokers { get; set; }

		[FindsBy(How = How.LinkText, Using = "Special Instructions")]
		public IWebElement LenderMortgageBrokersSpecialInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddLender")]
		public IWebElement LenderMortgageBrokersNewLenderAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnRemoveLender")]
		public IWebElement LenderMortgageBrokersNewLenderRemove { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_txtGABcode")]
		public IWebElement LenderMortgageBrokersNewLenderGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_cmdFindName")]
		public IWebElement LenderMortgageBrokersNewLenderFind { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_txtName")]
		public IWebElement LenderMortgageBrokersNewLenderName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_chkEditContactInfo")]
		public IWebElement LenderMortgageBrokersNewLenderEditContact { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textBusPhone")]
		public IWebElement LenderMortgageBrokersNewLenderBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_txtExtnPhone")]
		public IWebElement LenderMortgageBrokersNewLenderBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textBusFax")]
		public IWebElement LenderMortgageBrokersNewLenderBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textCellPhone")]
		public IWebElement LenderMortgageBrokersNewLenderCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textPager")]
		public IWebElement LenderMortgageBrokersNewLenderPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textEmailAddress")]
		public IWebElement LenderMortgageBrokersNewLenderEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_chkWeeklyEmailStatus")]
		public IWebElement LenderMortgageBrokersNewLenderEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_comboAttention")]
		public IWebElement LenderMortgageBrokersNewLenderAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_chkEdit")]
		public IWebElement LenderMortgageBrokersEditName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textName")]
		public IWebElement LenderMortgageBrokersNewLendertextName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_comboSalesRep1")]
		public IWebElement LenderMortgageBrokersNewLenderSalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_comboSalesRep2")]
		public IWebElement LenderMortgageBrokersNewLenderSalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_textReference")]
		public IWebElement LenderMortgageBrokersNewLenderReference { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddPayOffLend")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnRmvPayOffLend")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderRemove { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_txtGABcode")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_cmdFindName")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderFind { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_txtName")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_chkEditContactInfo")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderEditCont { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textBusPhone")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_txtExtnPhone")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textBusFax")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textCellPhone")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textPager")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textEmailAddress")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_chkWeeklyEmailStatus")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_comboAttention")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderAttention { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_chkEdit")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderEditName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textName")]
		public IWebElement LenderMortgageBrokersPayOfficeLendertextName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_textReference")]
		public IWebElement LenderMortgageBrokersPayOfficeLenderReference { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnAddMortBroker")]
		public IWebElement LenderMortgageBrokersMortgageBrokerAddNew { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_btnRmvMortBroker")]
		public IWebElement LenderMortgageBrokersMortgageBrokerRemove { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_txtGABcode")]
		public IWebElement LenderMortgageBrokersMortgageBrokerGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_cmdFindName")]
		public IWebElement LenderMortgageBrokersMortgageBrokerFind { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_txtName")]
		public IWebElement LenderMortgageBrokersMortgageBrokerName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_chkEditContactInfo")]
		public IWebElement LenderMortgageBrokersMortgageBrokerEditcont { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textBusPhone")]
		public IWebElement LenderMortgageBrokersMortgageBrokerBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_txtExtnPhone")]
		public IWebElement LenderMortgageBrokersMortgageBrokerBusPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textBusFax")]
		public IWebElement LenderMortgageBrokersMortgageBrokerBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textCellPhone")]
		public IWebElement LenderMortgageBrokersMortgageBrokerCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textPager")]
		public IWebElement LenderMortgageBrokersMortgageBrokerPager { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textEmailAddress")]
		public IWebElement LenderMortgageBrokersMortgageBrokerEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_chkWeeklyEmailStatus")]
		public IWebElement LenderMortgageBrokersMortgageBrokerEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_comboAttention")]
		public IWebElement LenderMortgageBrokersMortgageBrokerAttention { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_chkEdit")]
		public IWebElement LenderMortgageBrokersMortgageBrokerEditName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textName")]
		public IWebElement LenderMortgageBrokersMortgageBrokertextName { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_comboSalesRep1")]
		public IWebElement LenderMortgageBrokersMortgageBrokerSalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_comboSalesRep2")]
		public IWebElement LenderMortgageBrokersMortgageBrokerSalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_textReference")]
		public IWebElement LenderMortgageBrokersMortgageBrokerReference { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridNewLenders")]
		public IWebElement NewLenderSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridmBrokers")]
		public IWebElement MBSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_dgridPayOffLenders")]
		public IWebElement PayOffSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_labelIdcode")]
		public IWebElement NewLenderGcode1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_labelName")]
		public IWebElement NewLenderName1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_labelName2")]
		public IWebElement NewLenderName2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_labelAddress")]
		public IWebElement NewLenderAddress1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_labelAddress2")]
		public IWebElement NewLenderAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucNewLender_labelStateAndZip")]
		public IWebElement NewLenderAddress3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_labelIdcode")]
		public IWebElement PayOffGcode1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_labelName")]
		public IWebElement PayOffName1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_labelName2")]
		public IWebElement PayOffName2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_labelAddress")]
		public IWebElement PayOffAddress1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_labelAddress2")]
		public IWebElement PayOffAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucPayOffLender_labelStateAndZip")]
		public IWebElement PayOffAddress3 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_labelIdcode")]
		public IWebElement MBGcode1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_labelName")]
		public IWebElement MBName1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_labelName2")]
		public IWebElement MBName2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_labelAddress")]
		public IWebElement MBAddress1 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_labelAddress2")]
		public IWebElement MBAddress2 { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucMortgageBroker_labelStateAndZip")]
		public IWebElement MBAddress3 { get; set; }

		[FindsBy(How = How.Id, Using = "cboFileStatus")]
		public IWebElement SpecialInstructionFileEstimatedDate { get; set; }

		[FindsBy(How = How.LinkText, Using = "Details")]
		public IWebElement SpecialInstructionDetails { get; set; }

		[FindsBy(How = How.LinkText, Using = "Parties")]
		public IWebElement SpecialInstructionParties { get; set; }

		[FindsBy(How = How.LinkText, Using = "Property Info")]
		public IWebElement SpecialInstructionPropertyInfo { get; set; }

		[FindsBy(How = How.LinkText, Using = "Lenders/Mortgage Brokers")]
		public IWebElement SpecialInstructionLendersMortgageBrokers { get; set; }

		[FindsBy(How = How.LinkText, Using = "Special Instructions")]
		public IWebElement SpecialInstructionSpecialInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucSplInst_dgridSplInst_dgridSplInst")]
        public IWebElement SpecialInstructionsTable { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_ucSplInst_dgridSplInst_0_chkSelSplInst")]
		public IWebElement SpecialInstructionNewFileEntrySelect { get; set; }

		[FindsBy(How = How.Id, Using = "tabNFE_txtNotes")]
		public IWebElement SpecialInstructionNewFileEntryNotes { get; set; }

		[FindsBy(How = How.LinkText, Using = "Service File: Atleast one product required.")]
		public IWebElement ProductError { get; set; }

		[FindsBy(How = How.LinkText, Using = "Real Property: SubDivision Name can have maximum of 255 characters")]
		public IWebElement PropertyError { get; set; }

		[FindsBy(How = How.LinkText, Using = "Service File: File Number already exists or reserved.")]
		public IWebElement DupFileNumError { get; set; }

        [FindsBy(How = How.Id, Using = "button1")]
        public IWebElement PayoffDemandRequestOK { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_txtFileNo")]
        public IWebElement DetailsFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucSeller_txtTrust1099Lastname")]
        public IWebElement TrustLastNameFor1099_S { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'images2')]")]
        public IWebElement UploadedImg { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Service File: File Number already exists or reserved.']")]
        public IWebElement ErrorMsg { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_txtBusOrgNMLS")]
        public IWebElement NMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_labelContactName")]
        public IWebElement BusSourceContactName { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ucBusinessSource_ddlBusOrgStateLicense")]
        public IWebElement STLicense { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_cboUWEmployees")]
        public IWebElement UW_Employee { get; set; }
       

        [FindsBy(How = How.Id, Using = "tabNFE_ddlOfficeLN")]
        public IWebElement DetailsOfficeLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "tabNFE_ddlOfficerLN")]
        public IWebElement DetailsOfficerLicenseID { get; set; }

        #endregion

        public NewFileEntry Open()
        {
            FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Home>Order Entry>New File Entry");

            return this;
        }

        public NewFileEntry WaitForScreenToLoad(IWebElement element = null, int timeout = 10)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? EnteredBy);
            return this;
        }


        public bool WaitForEitherElements(IWebElement element, IWebElement alternateElement)
        {
            
            return Report.UpdateLog<bool>(element, "Wait", "Visible", "", () =>
            {
                
                WebDriverWait Wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(Convert.ToInt32(AutoConfig.WaitTime)));
                try
                {
                    this.SwitchToContentFrame();
                    Wait.Until(FAExpectedConditions.ElementIsVisible(element));
                }
                catch (WebDriverTimeoutException)
                {
                    if(alternateElement.IsVisible())
                    {
                        return true;
                    }
                    throw;
                }
                return true;
            });
        }

        public string CreateNewFile(string userID, string state, bool IsBuyerDetailsNeeded=false)
        {
            Reports.TestStep = "Create a file through New File Entry.";
            string fileNo = "";
            bool IsNeedIdentifiedForADMSetup = false;
            bool IsTitleEscrowOfficerSetThruADM = false;
            while (!IsNeedIdentifiedForADMSetup)
            {
                this.SwitchToContentFrame();
                if (!FastDriver.NewFileEntry.FileStatus.IsVisible())
                {
                    FastDriver.LeftNavigation.Navigate<NewFileEntry>(@"Home>Order Entry>New File Entry");
                    WaitForEitherElements(FastDriver.PendingFileSearch.SkipSearch, FileStatus);
                }

                if (FastDriver.PendingFileSearch.SkipSearch.IsVisible())
                {
                    FastDriver.PendingFileSearch.SkipSearch.FAClick();
                    FastDriver.NewFileEntry.WaitForScreenToLoad(FileStatus, Convert.ToInt32(AutoConfig.WaitTime));
                }

                Reports.TestStep = "Click New button, provided an existing Pending file is currently opened.";

                var currentFileNo = DetailsNewFileEntryCustFileNo.FAGetValue();
                if (!string.IsNullOrEmpty(currentFileNo))
                {
                    FastDriver.BottomFrame.New();
                    WaitForEitherElements(FastDriver.PendingFileSearch.SkipSearch, FileStatus);
                    if (FastDriver.PendingFileSearch.SkipSearch.IsVisible())
                    {
                        FastDriver.PendingFileSearch.SkipSearch.FAClick();
                        FastDriver.NewFileEntry.WaitForScreenToLoad(DetailsTitlecheckbox, Convert.ToInt32(AutoConfig.WaitTime));
                    }
                }


                Reports.TestStep = "Fill the mandatory details.";
                FastDriver.NewFileEntry.DetailsTitlecheckbox.FASetCheckbox(true);
                FastDriver.NewFileEntry.DetailsEscrowcheckbox.FASetCheckbox(true);
                //string parsedReversedUserID = "";
               // if (userID.Contains("\\"))
                //{
                  //  parsedReversedUserID = userID.Split('\\').LastOrDefault().Substring(4, 4).ToUpper() + ", " + userID.Split('\\').LastOrDefault().Substring(0, 4).ToUpper();
                //}
                if(!IsTitleEscrowOfficerSetThruADM)
                {
                    IsTitleEscrowOfficerSetThruADM = SetTitleEscrowOfficer(userID);
                   if (IsTitleEscrowOfficerSetThruADM)
                   {
                       //this.SwitchToContentFrame();
                       FastDriver.BottomFrame.Cancel();
                       FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                       continue;
                   }
                }
                if (IsTitleEscrowOfficerSetThruADM)
                {
                    FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
                    FastDriver.NewFileEntry.DetailsNewFileEntryTitleOfficer.FASelectItem(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
                }
                IsNeedIdentifiedForADMSetup = true;
            }
            FastDriver.NewFileEntry.DetailsNewFileEntryBusinessSegment.FASelectItem(@"Residential");
            FastDriver.NewFileEntry.DetailsNewFileEntryTransactionType.FASelectItem(@"Sale w/Mortgage");
            FastDriver.NewFileEntry.DetailsNewFileEntryProgramType.FASelectItem(@"No Program Type");
            FastDriver.NewFileEntry.OwnerPolicyTable.PerformTableAction(2, 1, TableAction.On);
            FastDriver.NewFileEntry.DetailsBussSourceGABcode.FASetText("HUDFLINSR1");
            FastDriver.NewFileEntry.DetailsFind.FAClick();
            FastDriver.NewFileEntry.DetailsAddtionalRole.FASelectItem(@"Title Agent");
            FastDriver.NewFileEntry.DetailsSearchType.FASelectItem(@"No Search Type");
            FastDriver.NewFileEntry.DetailsPropertyState.FASelectItem(state);
            FastDriver.NewFileEntry.FormType_CD.FAClick();
            if(IsBuyerDetailsNeeded)
            {
                Reports.TestStep = "Enter the Buyer details.";
                FastDriver.NewFileEntry.DetailsAddNew_buyer.FAClick();
                FastDriver.NewFileEntry.DetailsBuyerType.FASelectItem("Individual");
                FastDriver.NewFileEntry.DetailsBuyerIndividualName.FASetText("BuyerFirstName");
                FastDriver.NewFileEntry.DetailsBuyerIndividualMiddleName.FASetText("BuyerMiddleName");
                FastDriver.NewFileEntry.DetailsBuyerIndividualLastName.FASetText("BuyerLastName");
            }
            FastDriver.BottomFrame.Save();

            if(WaitUntilFileNoIsGenerated(Convert.ToInt32(AutoConfig.WaitTime)))
            {
                fileNo = DetailsNewFileEntryCustFileNo.FAGetValue();
                FastDriver.BottomFrame.Done();
                return fileNo;
            }

            return string.Empty;
        }

        public NewFileEntry FindBusinessSourceGAB(string gab = "boa")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(DetailsBussSourceGABcode);
            DetailsBussSourceGABcode.FASetText(gab + FAKeys.Tab);
            DetailsFind.FAClick();

            return this;
        }

        public NewFileEntry FindLenderMortgageBrokerGAB(string gab = "HUDFLINSR1")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LenderMortgageBrokersNewLenderGABcode);
            LenderMortgageBrokersNewLenderGABcode.FASetText(gab + FAKeys.Tab);
            LenderMortgageBrokersNewLenderFind.FAClick();

            return this;
        }

        public NewFileEntry FindDirectedByGAB(string gab = "HUDFLINSR1")
        {
            this.WaitForScreenToLoad(PartiesDirectedByGABcode);
            PartiesDirectedByGABcode.FASetText(gab + FAKeys.Tab);
            PartiesDirectedByFind.FAClick();

            return this;
        }

        public NewFileEntry FindAssociatedBusinessPartyGAB(string gab = "HUDFLINSR1")
        {
            this.WaitForScreenToLoad(PartiesAssociatedBusPartyGABcode);
            PartiesAssociatedBusPartyGABcode.FASetText(gab + FAKeys.Tab);
            PartiesAssociatedBusPartyFind.FAClick();

            return this;
        }

        public NewFileEntry FindLenderMortgageBrokersPayoffLenderGAB(string gab = "HUDFLINSR1")
        {
            this.WaitForScreenToLoad(LenderMortgageBrokersPayOfficeLenderGABcode);
            LenderMortgageBrokersPayOfficeLenderGABcode.FASetText(gab + FAKeys.Tab);
            LenderMortgageBrokersPayOfficeLenderFind.FAClick();

            return this;
        }

        public NewFileEntry FindLenderMortgageBrokersMortagageBrokerDetailsGAB(string gab = "HUDFLINSR1")
        {
            this.WaitForScreenToLoad(LenderMortgageBrokersMortgageBrokerGABcode);
            LenderMortgageBrokersMortgageBrokerGABcode.FASetText(gab + FAKeys.Tab);
            LenderMortgageBrokersMortgageBrokerFind.FAClick();

            return this;
        }

        public bool WaitUntilFileNoIsGenerated(int timeOut = 20)
        {
            System.Threading.Thread.Sleep(12000);
            this.SwitchToContentFrame();
            //this.WaitCreation(InvoicetosummaryTable, AutoConfig.WaitTime);
            var result = false;
            string FileNo = "";
            
            try
            {
                WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(timeOut));
                wait.Until(w =>
                {
                    this.SwitchToContentFrame();
                    if (this.WaitCreation(DetailsNewFileEntryCustFileNo))
                    {
                        FileNo = DetailsNewFileEntryCustFileNo.FAGetValue();
                        if (!string.IsNullOrEmpty(FileNo))
                        {
                            result = true;

                        }
                    }
                    return result;
                });
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                return false; 
            }
            return result;
        }

        public NewFileEntry ClickOnDetailsTab()
        {
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                try
                {
                    this.WaitCreation(DetailsDetail);
                    DetailsDetail.FAClick();
                    Playback.Wait(250);
                    this.WaitForScreenToLoad(DetailsNewFileEntryCustFileNo);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }, timeout: 60, idleInterval: 5);

            return this;
        }

        public NewFileEntry ClickOnPartiesTab()
        {
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                try
                {
                    this.WaitCreation(PartiesParties);
                    PartiesParties.FAClick();
                    Playback.Wait(250);
                    this.WaitForScreenToLoad(PartiesDirectedByFind);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }, timeout: 60, idleInterval: 5);

            return this;
        }

        public NewFileEntry ClickOnLenderMortgageBrokerTab()
        {
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                try
                {
                    this.WaitCreation(DetailsLendersMortgageBrokers);
                    DetailsLendersMortgageBrokers.FAClick();
                    Playback.Wait(250);
                    this.WaitForScreenToLoad(LenderMortgageBrokersNewLenderAddNew);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }, timeout: 60, idleInterval: 5);

            return this;
        }

        public NewFileEntry ClickOnSpecialInstructionsTab()
        {
            FastDriver.WebDriver.WaitForActionToComplete(() =>
            {
                try
                {
                    this.WaitCreation(DetailsSpecialInstructions);
                    DetailsSpecialInstructions.FAClick();
                    Playback.Wait(250);
                    this.WaitForScreenToLoad(SpecialInstructionsTable);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }, timeout: 60, idleInterval: 5);

            return this;
        }

        private string GetParsedUserIDWithSpace(string userID, bool IsToBeReversed = false)
        {
            string parsedUserID = "";
            if (userID.Contains("\\"))
            {
                parsedUserID = userID.Split('\\').LastOrDefault().Substring(0, 4) + " " + userID.Split('\\').LastOrDefault().Substring(4, 4);
            }
            if (IsToBeReversed)
            {
                parsedUserID = parsedUserID.Split(' ').LastOrDefault() + ", " + parsedUserID.Split(' ').FirstOrDefault();
                return parsedUserID.ToUpper();
            }
            return parsedUserID;
        }


        private bool SetTitleEscrowOfficer(string userID)
        {
            try
            {
                IWebElement tempEmployeeTypeElement = null;
                Actions actions = null;
                string parsedReversedUserID = "";
                string tempID = userID.Split('\\').Last().ToUpper();
                bool IsADMSetupRequired = false;
                if (userID.Contains("\\"))
                {
                    parsedReversedUserID = userID.Split('\\').LastOrDefault().Substring(4, 4).ToUpper() + ", " + userID.Split('\\').LastOrDefault().Substring(0, 4).ToUpper();
                }
                string parsedUserID = (parsedReversedUserID.Split(' ').LastOrDefault() +" "+ parsedReversedUserID.Split(' ').FirstOrDefault().Remove(4)).ToUpper();
                var allOptionsForEscrow = FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FAGetAllTextFromSelect();
                var allOptionsForTitle = FastDriver.NewFileEntry.DetailsNewFileEntryTitleOfficer.FAGetAllTextFromSelect();
                if (!allOptionsForEscrow.Contains(parsedReversedUserID) || !allOptionsForTitle.Contains(parsedReversedUserID))
                {
                    IsADMSetupRequired = true;
                    var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                    AdminDriver.Login(AutoConfig.FASTAdmURL, credentials);
                    FastDriver.LeftNavigation.Navigate<EmployeeSearch>(@"Home>System Maintenance>Employee Setup").WaitForScreenToLoad();
                    int i = 1;
                    while (i <= 2)
                    {
                        FastDriver.EmployeeSearch.SwitchToContentFrame();
                        FastDriver.EmployeeSearch.LoginName.FASetText("fastts\\fastqa07");
                        FastDriver.EmployeeSearch.SearchNow.FAClick();
                        FastDriver.EmployeeSearch.WaitForScreenToLoad();
                        Playback.Wait(2000);
                        FastDriver.EmployeeSearch.SwitchToContentFrame();
                        FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, parsedUserID, 2, TableAction.Click);
                        FastDriver.EmployeeSearch.Edit.FAClick();
                        FastDriver.EmployeeSetup.WaitForScreenToLoad();

                        Reports.StatusUpdate("Check if the correct User ID has been opened :", FastDriver.EmployeeSetup.IDCode.FAGetValue() == (tempID + "A"), "", "", "", tempID + "A", FastDriver.EmployeeSetup.IDCode.FAGetValue());
                        actions = new Actions(FastDriver.WebDriver);
                        tempEmployeeTypeElement = FastDriver.EmployeeSetup.EmployeeTypes;

                        if (i == 1)
                        {
                            tempID = parsedReversedUserID.Split(' ').LastOrDefault().ToUpper() + parsedReversedUserID.Split(' ').FirstOrDefault().Replace(',', ' ').ToUpper();
                            new SelectElement(FastDriver.EmployeeSetup.EmployeeTypes).DeselectAll();
                            FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Escrow Assistant");
                            FastDriver.BottomFrame.Done();
                            i++;
                            continue;
                        }
                        actions.KeyDown(FAKeys.LeftShift).SendKeys(tempEmployeeTypeElement, "Title Officer").Build().Perform();
                        FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Title Officer");
                        FastDriver.EmployeeSetup.EmployeeTypes.FASelectItem("Escrow Assistant");
                        FastDriver.BottomFrame.Done();
                        i++;
                        //actions.SendKeys(elem, FAKeys.Shift).SendKeys(elem, "Title Assistant").SendKeys(elem, "Title Officer").SendKeys(elem, "Escrow Officer").SendKeys(elem, "Escrow Assistant").Build().Perform();
                        //actions.KeyDown(FAKeys.LeftShift).SendKeys(elem, "Escrow Assistant").SendKeys(elem, "Escrow Officer").SendKeys(elem, "Exchange Assistant").SendKeys(elem, "Exchange Officer").SendKeys(elem, "Other").SendKeys(elem, "Sales Rep").SendKeys(elem, "Title Assistant").SendKeys(elem, "Title Officer").Build().Perform();
                        //actions.KeyDown(FAKeys.LeftShift).SendKeys(elem, "Escrow Officer").SendKeys(elem, "Title Officer").Build().Perform();
                    }
                    AdminDriver.ResumeIISDriver();
                }
                if (!IsADMSetupRequired)
                {
                    FastDriver.NewFileEntry.DetailsNewFileEntryEscrowOfficer.FASelectItem(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
                    FastDriver.NewFileEntry.DetailsNewFileEntryTitleOfficer.FASelectItem(GetParsedUserIDWithSpace(userID: AutoConfig.UserName, IsToBeReversed: true));
                    return false;
                }
                return true;
            }
            catch(Exception ex)
            {
                throw new Exception("Error occurred while executing SetTitleEscrowOfficer function in NewFileEntry page object! Error: " + ex.Message);
            }
        }

        public void CreateDetailedFile(string fileNum = null, bool title = true, bool escrow = true, bool subescrow = false, string busGAB = "HUDFLINSR1", string busSegment = "Residential", string transType = "Sale w/Mortgage", 
            string programType = "No Program Type", string ownerPolicy = "ALTA Extended Leasehold Owners Policy", string addRole = "Title Agent", string searchType = "No Search Type", bool buyer = true, bool seller = true,
            BuyerSellerType buyerType = BuyerSellerType.HusbandWife, BuyerSellerType sellerType = BuyerSellerType.HusbandWife, bool saveFile = true, string city = "Santa Ana", string state = "CA", string zipCode = "92707",
            string county = "Orange", string underwriters = null)
        {
            this.WaitForScreenToLoad();
            if(fileNum != null)
            {
                DetailsAutoNumber.FASetCheckbox(false);
                DetailsFileNumber.FASetText(fileNum);
            }
            DetailsTitlecheckbox.FASetCheckbox(title);
            DetailsEscrowcheckbox.FASetCheckbox(escrow);
            DetailsSubEscrowcheckbox.FASetCheckbox(subescrow);
            if(underwriters != null)
            {
                DetailsNewFileEntryUnderWriters.FASelectItem(underwriters);
            }
            DetailsNewFileEntryBusinessSegment.FASelectItem(busSegment);
            DetailsNewFileEntryTransactionType.FASelectItem(transType);
            DetailsNewFileEntryProgramType.FASelectItem(programType);
            if (!OwnerPolicyTable.Text.Contains(ownerPolicy))
            {
                DetailsAddRemove.FAClick();
                FastDriver.ProductSelectionDlg.WaitForScreenToLoad(FastDriver.ProductSelectionDlg.Table)
                    .Table.PerformTableAction(2, ownerPolicy, 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    return OwnerPolicyTable.Text.Contains(ownerPolicy);
                }, timeout: 30, idleInterval: 2);
            }
            else
            {
                OwnerPolicyTable.PerformTableAction(2, ownerPolicy, 1, TableAction.On);
            }
            FindBusinessSourceGAB(busGAB);
            DetailsAddtionalRole.FASelectItem(addRole);
            DetailsSearchType.FASelectItem(searchType);
            if (buyer)
            {
                DetailsAddNew_buyer.FAClick();
                switch (buyerType)
                {
                    case BuyerSellerType.HusbandWife:
                        DetailsBuyerType.FASelectItem(@"Husband/Wife");
                        DetailsBuyerHusbandName.FASetText(@"Buyer2Firstname");
                        DetailsBuyerHusbandLast.FASetText(@"Buyer2Lastname");
                        DetailsBuyerSpouseFirstName.FASetText(@"Buyer2SpouseName");
                        break;
                    case BuyerSellerType.Individual:
                        DetailsBuyerType.FASelectItem(@"Individual");
                        IndBuyerF.FASetText(@"Buyer1Firstname");
                        IndBuyerL.FASetText(@"Buyer1Firstname");
                        break;
                    case BuyerSellerType.BusinessEntity:
                        DetailsBuyerType.FASelectItem(@"Business Entity");
                        TrustBuyer.FASetText(@"Buyer1Firstname");
                        TrustBuyerSSNTIN.FASetText("1523215202");
                        break;
                    default:
                        break;
                }
            }
            if (seller)
            {
                DetailsAddNewSeller.Click();
                switch (buyerType)
                {
                    case BuyerSellerType.HusbandWife:
                        DetailsSellerType.FASelectItemBySendingKeys(@"Husband/Wife");
                        DetailsSellerHusbandName.FASetText(@"Seller2Firstname");
                        DetailsSellerHusbandLast.FASetText(@"Seller2Lastname");
                        DetailsSellerSpouseName.FASetText(@"Seller2SpouseName");
                        break;
                    case BuyerSellerType.Individual:
                        DetailsSellerType.FASelectItemBySendingKeys(@"Individual");
                        IndSellerF.FASetText(@"Seller2Firstname");
                        IndSellerL.FASetText(@"Seller2Lastname");
                        break;
                    case BuyerSellerType.BusinessEntity:
                        DetailsSellerType.FASelectItem(@"Business Entity");
                        TrustSeller.FASetText(@"Seller2Firstname");
                        TrustSellerSSNTIN.FASetText("1523215202");
                        break;
                    default:
                        break;
                }
            }
            DetailsPropertyStreet1.FASetText(@"1 First American Way");
            DetailsPropertyStreet2.FASetText(@"PropertyStreet2");
            DetailsPropertyStreet3.FASetText(@"PropertyStreet3");
            DetailsPropertyStreet4.FASetText(@"PropertyStreet4");
            DetailsPropertyCity.FASetText(city);
            DetailsPropertyState.FASelectItem(state);
            DetailsPropertyZIP.FASetText(zipCode);
            DetailsPropertyCounty.FASelectItem(county);
            DetailsSalePrice.FASetText(@"600,000.00");
            DetailsFirstNewLoan.FASetText(@"250,000.00");
            DetailsSecondNewLoan.FASetText(@"150,000.00");
            if (saveFile)
            {
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }
            
        }

        public void MouseOverUploadedImg()
        {
            Actions action = new Actions(FastDriver.WebDriver);
            action.MoveToElement(FastDriver.NewFileEntry.UploadedImg).Perform();
        }

	}
	public class Icon : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "Pending")]
		public IWebElement Pending { get; set; }

		#endregion

	}

    public class AdminDriver : FASTLogin
    {
        static IWebDriver tempDriverInstance = null;
        static string IISWindowHandle = "";
        public static void Login(string URL, Credentials credentials, bool cleanSession = false)
        {
            tempDriverInstance = FastDriver.WebDriver;
            IISWindowHandle = FastDriver.WebDriver.CurrentWindowHandle;
            InternetExplorerOptions options = new InternetExplorerOptions()
            {
                UnexpectedAlertBehavior = InternetExplorerUnexpectedAlertBehavior.Ignore
            };
            var ADMDriver = new InternetExplorerDriver(options);

            Report.UpdateLog(ADMDriver, " Navigate to ADM URL", AutoConfig.FASTAdmURL, () =>
            {
                ADMDriver.Navigate().GoToUrl(AutoConfig.FASTAdmURL);
            });
            FastDriver.WebDriver = ADMDriver;
            PerformInternalLogin(URL, credentials);
            if (FastDriver.WebDriver.WaitForAlertToExist(3))
                FastDriver.WebDriver.SwitchTo().Alert().Accept();
        }

        public static void ResumeIISDriver()
        {
            FastDriver.WebDriver.Quit();
            FastDriver.WebDriver = tempDriverInstance;
            FastDriver.WebDriver.SwitchTo().Window(IISWindowHandle);
            //Playback.Wait(3000);
        }
    }
}
