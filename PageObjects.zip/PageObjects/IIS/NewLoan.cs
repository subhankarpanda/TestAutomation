using System;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Diagnostics;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class NewLoan : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs")]
        public IWebElement LenderCreditsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_cBntExp3")]
        public IWebElement LenderCreditsIcon { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tLD")]
        public IWebElement LoanDetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelName")]
        public IWebElement LenderNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgCCP_dcs")]
        public IWebElement CreditChargePointsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgCCP_dcs_0_tsc")]
        public IWebElement LoanChargesCredit_ChargeSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgCCP_dcs_1_tsc")]
        public IWebElement LoanChargesCredit_ChargeSellerCharge1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tNL_tLC_NLC_cgLC6_cBntExp3")]
        public IWebElement LoanCharges_ExpandLenderCredits { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG6_dcs_0_tbc")]
        public IWebElement MortagageGFE_6NewLoanCharges_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG6_dcs_0_tbd")]
        public IWebElement MortgageBrokerLenderCreditBuyerCredit { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tNL_tMB_NMB_aMCG6_cBntExp3")]
        public IWebElement Mortgage_ExpandLenderCredits { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_dcs")]
        public IWebElement LoanCharges_FutureRecFeesLenderTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_dcs_0_tdsc")]
        public IWebElement LoanCharges_FutureRecFeesLenderDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_dcs_1_tdsc")]
        public IWebElement LoanCharges_FutureRecFeesLenderDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_dcs_0_tbc")]
        public IWebElement LoanCharges_FutureRecFeesLenderBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_dcs_1_tbc")]
        public IWebElement LoanCharges_FutureRecFeesLenderBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs")]
        public IWebElement LoanChargesOriginationChargeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_dcs_0_tsr")]
        public IWebElement LoanCharges_FutureRecFeesLenderSellerCredit { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#tNL_tLC_NLC_cg78_cBntExp3")]
        public IWebElement LoanCharges_ExpandFutureRecFeesLender { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgCCP_dcs_0_tga")]
        public IWebElement LoanChargesCredit_ChargeLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgCCP_dcs_0_tbc")]
        public IWebElement LoanChargesCredit_ChargeBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgCCP_dcs_1_tbc")]
        public IWebElement LoanChargesCredit_ChargeBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtCDPerLoanAmt")]
        public IWebElement CreditChargePointsPercentageLoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_ddlCDCCPDispFormat")]
        public IWebElement CreditChargePointsPercentageDisplayFormat { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtCDIRSPoints")]
        public IWebElement CreditChargePointsPercentageIRSPoints { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs")]
        public IWebElement LoanCharges_NewLoanTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_ddlLT")]
        public IWebElement LoanDetailsLoantype { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLA")]
        public IWebElement LoanDetailsLoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLL")]
        public IWebElement LoanDetailsLoanLiability { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_ddlMP")]
        public IWebElement LoanDetailsMortgageProduct { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_ddlPO")]
        public IWebElement LoanDetailsProductOption { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_ddlAS")]
        public IWebElement LoanDetailsAccountServicing { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdHUD")]
        public IWebElement LoanDetailsHUDType_HUD { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdLegacy")]
        public IWebElement LoanDetailsHUDType_Legacy { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtMortgageInsCase")]
        public IWebElement LoanDetailsMortgageInsCase { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLoanNumber")]
        public IWebElement LoanDetailsLoanNumber { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_chkRLU")]
        public IWebElement LoanDetailsRestrictLenderUpdates { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_cmdCheckDetails")]
        public IWebElement LoanDetailsCheckDetails { get; set; }

        //[FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_cmdCheckDetails")]
        //public IWebElement LoanDetailsCheckDetails1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_cmdRemoveBusParty")]
        public IWebElement LoanDetailsRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtGABcode")]
        public IWebElement LoanDetailsGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_cmdFindName")]
        public IWebElement LoanDetailsFind { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cmdCDPDD")]
        public IWebElement CreditCharge_Points_PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtName")]
        public IWebElement LoanDetailsGABName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelName")]
        public IWebElement BusinessPartyNameField { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelName2")]
        public IWebElement BusinessPartyNameField2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_chkEditContactInfo")]
        public IWebElement LoanDetailsEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textBusPhone")]
        public IWebElement LoanDetailsBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtExtnPhone")]
        public IWebElement LoanDetailsBusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textBusFax")]
        public IWebElement LoanDetailsBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textCellPhone")]
        public IWebElement LoanDetailsCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textPager")]
        public IWebElement LoanDetailsPager { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textEmailAddress")]
        public IWebElement LoanDetailsEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_chkWeeklyEmailStatus")]
        public IWebElement LoanDetailsEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_comboAttention")]
        public IWebElement LoanDetailsAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_chkEdit")]
        public IWebElement LoanDetailsEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textName")]
        public IWebElement LoanDetailsName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_comboSalesRep1")]
        public IWebElement LoanDetailsSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_comboSalesRep2")]
        public IWebElement LoanDetailsSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtFD")]
        public IWebElement LoanDetailsFundingDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtSD")]
        public IWebElement LoanDetailsSigningDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_chkFR")]
        public IWebElement LoanDetailsFundsReceived { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtRS")]
        public IWebElement LoanDetailsRescissionPeriodBegins { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtRD")]
        public IWebElement LoanDetailsDays { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtRE")]
        public IWebElement LoanDetailsEnds { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_cmdRf")]
        public IWebElement LoanDetailsRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLLP")]
        public IWebElement LoanDetailsHazardInsuranceLossPayee { get; set; }

        //[FindsBy(How = How.LinkText, Using = "/smsfast/FastNetApp2/images/ico_brokenlink.gif")]

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'ico_brokenlink.gif')]")]
        public IWebElement LoanDetailsHazardInsuranceLossPayeebrokenlinkgif { get; set; }

        [FindsBy(How = How.Id, Using = "tblBusPartyDetails")]
        public IWebElement LoanDetailsBusPartyTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelIdcode")]
        public IWebElement LoanDetailsGabcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_btnLnInvs")]
        public IWebElement LoanInvestors { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdCD")]
        public IWebElement FormType_CD { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdHUD")]
        public IWebElement FormType_HUD { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement MessagePaneTop { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tLC")]
        public IWebElement LoanChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cmdPC")]
        public IWebElement LoanChargesPayCharges { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_btnPayment")]
        public IWebElement LoanChargesPrincipalBalanceChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tdsc")]
        public IWebElement LoanChargesPrincipalBalanceChargesdescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tbc")]
        public IWebElement LoanChargesPrincipalBalanceChargesBuyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tbd")]
        public IWebElement LoanChargesPrincipalBalanceChargesBuyercredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tsc")]
        public IWebElement LoanChargesPrincipalBalanceChargesSellercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tsr")]
        public IWebElement LoanChargesPrincipalBalanceChargessellercredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tga")]
        public IWebElement LoanChargesPrincipalBalanceChargesLEAmount { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src=\"../images/ico_blank.gif\"]")]
        public IWebElement LoanChargesPrincipalBalanceChargesPenImage { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_lblInitBuyer")]
        public IWebElement LoanCharges_InitialDepositBuyerChargeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_lblInitSeller")]
        public IWebElement LoanCharges_InitialDepositSellerChargeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs")]
        public IWebElement LoanChargesImpoundsTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_btnPayment")]
        public IWebElement LoanChargesInterestCalculationPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_cboInterestType")]
        public IWebElement LoanChargesInterestCalculationInterestType { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_rdoPerDiem")]
        public IWebElement LoanChargesInterestCalculationPerDiem { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_txtPerDiem")]
        public IWebElement LoanChargesInterestCalculationPerDiemAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_txtFromDate")]
        public IWebElement LoanChargesInterestCalculationFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_chkInclusiveFrom")]
        public IWebElement LoanChargesInterestCalculationInclusiveFrom { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_cboBasisDays")]
        public IWebElement LoanChargesInterestCalculationBasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_rdoPercentRate")]
        public IWebElement LoanChargesInterestCalculationPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_txtPercentRate")]
        public IWebElement LoanChargesInterestCalculationPercentageRate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_txtToDate")]
        public IWebElement LoanChargesInterestCalculationToDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_chkInclusiveTo")]
        public IWebElement LoanChargesInterestCalculationInclusiveTo { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs_0_tdsc")]
        public IWebElement LoanChargesInterestCalculationDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs_0_tga")]
        public IWebElement InterestCalculation_Loan_Estimates_Row1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs_0_tbc")]
        public IWebElement LoanChargesInterestCalculationbuyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs_0_tbd")]
        public IWebElement LoanChargesInterestCalculationbuyercredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs_0_tsc")]
        public IWebElement LoanChargesInterestCalculationsellercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs_0_tsr")]
        public IWebElement LoanChargesInterestCalculationsellercredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_IPror_CGrid_dcs")]
        public IWebElement InterestCalculationTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbInterestCredit")]
        public IWebElement LoanChargesInterestCalculationCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbInterestCharge")]
        public IWebElement LoanChargesInterestCalculationCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbInterestZero")]
        public IWebElement LoanChargesInterestCalculationZero { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtInterestGFE")]
        public IWebElement LoanChargesInterestCalculationGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cmdOPD")]
        public IWebElement LoanChargesOriginationChargePaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_0_tdsc")]
        public IWebElement LoanChargesOriginationChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_1_tdsc")]
        public IWebElement LoanChargesOriginationChargeDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_0_tbc")]
        public IWebElement LoanChargesOriginationChargebuyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_1_tbc")]
        public IWebElement LoanChargesOriginationChargebuyercharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_0_tbd")]
        public IWebElement LoanChargesOriginationChargebuyercredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_0_tsc")]
        public IWebElement LoanChargesOriginationChargeSellercharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_0_tsr")]
        public IWebElement LoanChargesOriginationChargeSellercredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbOriginationCredit")]
        public IWebElement LoanChargesOriginationChargeCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbOriginationCharge")]
        public IWebElement LoanChargesOriginationChargeCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbOriginationZero")]
        public IWebElement LoanChargesOriginationChargeZero { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs_0_tga")]
        public IWebElement LoanChargesOriginationChargeGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtFP")]
        public IWebElement LoanChargesOriginationChargePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtFA")]
        public IWebElement LoanChargesOriginationChargeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtOP")]
        public IWebElement LoanChargesOriginationChargeIRSOriginationPoints { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgOF_dcs")]
        public IWebElement OriginationChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs")]
        public IWebElement NewLoanChargesTable { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement LoanChargesItemizedOrginationChargeRemainingExpand { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_btnPayment")]
        public IWebElement LoanChargesItemizedOrginationChargeRemainingPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_dgridRemaining")]
        public IWebElement LoanChargesItemizedOrginationChargeRemainingTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgItC_dcs_0_tdsc")]
        public IWebElement LoanChargesItemizedOrginationChargeRemainingDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgItC_dcs_0_tbc")]
        public IWebElement LoanChargesItemizedOrginationChargeRemainingBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgItC_dcs_0_tbd")]
        public IWebElement LoanChargesItemizedOrginationChargeRemainingBuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cmdDPD")]
        public IWebElement LoanChargesCredit_ChargePointsPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbCCPCredit")]
        public IWebElement LoanChargesCredit_ChargePointsCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbCCPCharge")]
        public IWebElement LoanChargesCredit_ChargePointsCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_rbCCPZero")]
        public IWebElement LoanChargesCredit_ChargePointsZero { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtCCPBC")]
        public IWebElement LoanChargesCredit_ChargePointsBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtCCPSC")]
        public IWebElement LoanChargesCredit_ChargePointsSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtCCPDescr")]
        public IWebElement LoanChargesCredit_ChargePointsDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtGFECCP")]
        public IWebElement LoanChargesCredit_ChargePointsGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtDPCT")]
        public IWebElement LoanChargesCredit_ChargePointsPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtDA")]
        public IWebElement LoanChargesCredit_ChargePoints_Amount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtDP")]
        public IWebElement LoanChargesCredit_Charge_IRSDiscountPoints { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtCDIRSPoints")]
        public IWebElement CreditChargeIRSPoints { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_Button1")]
        public IWebElement LoanChargesAdjustedOriginationChargePaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtAdjDescr")]
        public IWebElement LoanChargesAdjustedOriginationChargeDescription { get; set; }
        //  TODO: element name makes no sense
        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_btnPayment")]
        public IWebElement LoanChargesGFE_3NewLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_btnPayment")]
        public IWebElement MBChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_btnPayment")]
        public IWebElement NewLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_tdButtonExpand")]
        public IWebElement NewLoanMortgage_Contact_Expand { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_txtBusOrgNMLS")]
        public IWebElement NewLoanMortgage_NMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_txtBusContactNMLS")]
        public IWebElement NewLoanMortgage_Contact_NMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_ddlBusOrgStateLicense")]
        public IWebElement NewLoanMortgage_STLICENSEID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_ddlBusContactStateLicense")]
        public IWebElement NewLoanMortgage_Contact_STLICENSEID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtBusOrgNMLS")]
        public IWebElement NewLoanDetails_NMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_ddlEditBusOrgStateLicense")] //FAST generates a second field which contains a newly added license for a modified GAB.
        public IWebElement NewLoanDetails_ModifiedLicense { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtEditNMLSIDValue")] //FAST generates a second field which contains a newly added NMLS ID for a modified GAB.
        public IWebElement NewLoanDetails_ModifiedNMLS { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelContactName")]
        public IWebElement NewLoanDetails_ContactName{ get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtBusContactNMLS")]
        public IWebElement NewLoanDetails_Contact_NMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_chkBusContactNMLS")]
        public IWebElement NewLoanDetails_Contact_NMLSIDEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_ddlBusOrgStateLicense")]
        public IWebElement NewLoanDetails_STLICENSEID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_ddlBusContactStateLicense")]
        public IWebElement NewLoanDetails_Contact_STLICENSEID { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_chkBusContactStateLicense")]
        public IWebElement NewLoanDetails_Contact_STEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tdsc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesdescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_8_tdsc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesdescription8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tbc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_1_tbc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_2_tbc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_3_tbc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_4_tbc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_8_tbc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tbd")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_1_tbd")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_2_tbd")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_3_tbd")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCredit4 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_4_tbd")]
        public IWebElement LoanChargesGFE_3NewLoanChargesBuyerCredit5 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tsc")]
        public IWebElement LoanChargesGFE_3NewLoanChargesSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tsr")]
        public IWebElement LoanChargesGFE_3NewLoanChargesSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tga")]
        public IWebElement LoanChargesGFE_3NewLoanChargesGFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs")]
        public IWebElement LoanCharges_LenderCreditTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG6_dcs")]
        public IWebElement Mortgage_LenderCreditTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_4_tdsc")]
        public IWebElement LoanChargesGFE_6NewLoanChargesdescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_0_tbc")]
        public IWebElement LoanChargesGFE_6NewLoanCharges_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_0_tbd")]
        public IWebElement LoanChargesGFE_6NewLoanCharges_BuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_1_tbd")]
        public IWebElement LoanChargesGFE_6NewLoanCharges_BuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_0_tsc")]
        public IWebElement LoanChargesGFE_6NewLoanCharges_SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_0_tsr")]
        public IWebElement LoanChargesGFE_6NewLoanCharge_SellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_dcs_0_tga")]
        public IWebElement LoanChargesGFE_6NewLoanCharge_GFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC6_btnPayment")]
        public IWebElement LoanChargesGFE_6NewLoanCharge_PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cg78_btnPayment")]
        public IWebElement LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cmdIMP")]
        public IWebElement LoanChargesmpountPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cmdDPD")]
        public IWebElement LoanChargesDiscountPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtDPCT")]
        public IWebElement LoanChargesDiscountPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtDA")]
        public IWebElement LoanChargesDiscountAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgDP_dcs_0_tdsc")]
        public IWebElement LoanChargesDiscountDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgDP_dcs_0_tbc")]
        public IWebElement LoanChargesDiscountBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgDP_dcs_0_tbd")]
        public IWebElement LoanChargesDiscountBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgDP_dcs_0_tsc")]
        public IWebElement LoanChargesDiscountSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgDP_dcs_0_tsr")]
        public IWebElement LoanChargesDiscountSellerCredit { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement LoanChargesNewLoanChargesexpand { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_btnPayment")]
        public IWebElement LoanChargesNewLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tdsc")]
        public IWebElement LoanChargesNewLoanChargesDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_1_tdsc")]
        public IWebElement LoanChargesNewLoanChargesDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tbc")]
        public IWebElement LoanChargesNewLoanChargesBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_1_tbc")]
        public IWebElement LoanChargesNewLoanChargesBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_2_tbc")]
        public IWebElement LoanChargesNewLoanChargesBuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tbd")]
        public IWebElement LoanChargesNewLoanChargesBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tsc")]
        public IWebElement LoanChargesNewLoanChargesSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tsr")]
        public IWebElement LoanChargesNewLoanChargesSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_0_tdsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Description1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_1_tdsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Description2 { get; set; }

        #region Impounds
        #region Months
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_0_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_1_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_2_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_3_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months4 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_4_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months5 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months6 { get; set; }


        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_6_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months7 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_7_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_8_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months9 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_9_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months10 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_10_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months11 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_11_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months12 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_12_tms")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_Months13 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs")]
        public IWebElement AggregateAccountingAdjustmentTable { get; set; }
        #endregion

        #region Monthly Charges
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_0_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_1_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_2_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge3 { get; set; }

        [FindsBy(How = How.Id, Using =
        "tNL_tLC_NLC_icgIC_dcs_3_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge4 { get; set; }

        [FindsBy(How = How.Id, Using =
        "tNL_tLC_NLC_icgIC_dcs_4_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge5
        { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge6 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_6_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge7 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_7_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge8 { get; set; }

        [FindsBy(How = How.Id, Using =
        "tNL_tLC_NLC_icgIC_dcs_8_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge9 { get; set; }

        [FindsBy(How = How.Id, Using =
        "tNL_tLC_NLC_icgIC_dcs_9_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge10
        { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_10_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge11
        { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_11_tmc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_MonthlyCharge12
        { get; set; }

        #endregion

        #region Buyer Charges

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_0_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_1_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_2_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_3_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge4 { get; set; }
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_4_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge6 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_6_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge7 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_7_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_9_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge10 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_10_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge11 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_11_tbc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_BuyerCharge12 { get; set; }

        #endregion

        #region Seller Charges
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_0_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_1_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_2_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_3_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge4 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_4_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge5 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge6 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_6_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge7 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_7_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_8_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge9 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_9_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge10 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_10_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge11 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_11_tsc")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_SellerCharge12 { get; set; }

        #endregion

        #region Loan Estimates

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_0_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_1_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_2_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_3_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_4_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate5 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate6 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_6_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate7 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_7_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_8_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate9 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_9_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate10 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_10_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate11 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_11_tga")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_LoanEstimate12 { get; set; }

        #endregion

        #region AggregateAccountingAdjustment
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_optCr")]
        public IWebElement LoanChargesAggregateAccountingAdjustmentCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_optCg")]
        public IWebElement LoanChargesAggregateAccountingAdjustmentCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_optZr")]
        public IWebElement LoanChargesAggregateAccountingAdjustmentZero { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtBC")]
        public IWebElement LoanChargesAggregateAccountingAdjustmentBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtSC")]
        public IWebElement LoanChargesAggregateAccountingAdjustmentSeller { get; set; }

        #endregion

        #region Additional Fields
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description6 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_6_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description7 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_7_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description8 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_8_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description9 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_9_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description10 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_10_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description11 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_11_tdsc")]
        public IWebElement LoanChargesAdditionalFeescollectedbyLender_Description12 { get; set; }

        #endregion

        #endregion Impounds

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs")]
        public IWebElement LoanChargesPrincipalReductiontable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_txtInitGFE")]
        public IWebElement LoanChargesAggregateAccountingAdjustment_GFEAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_btnPayment")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_tdsc")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_Description { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_icgIC_dcs_5_tdsc")]
        public IWebElement LoanChargesGFE_7FutureRecordingFeescollectedbyLender_MB_Description { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_tbc")]
        public IWebElement LoanChargesPrincipalreduction_Payment_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_1_tbc")]
        public IWebElement LoanChargesConstruction_Holdback_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_tbd")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_BuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_tsc")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_tsr")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_SellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_tga")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_LEAmount { get; set; }
        
        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_cBntExp3")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_Expand { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_cBntExp3")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_1_tbc")]
        public IWebElement LoanChargesPrincipalreduction_Constructionholdback_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_btnPayment")]
        public IWebElement LoanChargesItemizedOriginationCharges_PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgItC_dcs")]
        public IWebElement ItemizationOriginationChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgItC_dcs_0_tdsc")]
        public IWebElement LoanChargesItemizedOriginationCharges_Description { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgItC_dcs_0_tbc")]
        public IWebElement LoanChargesItemizedOriginationCharges_BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tbc")]
        public IWebElement BorrowerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs_0_tbd")]
        public IWebElement BorrowerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPB_dcs")]
        public IWebElement PrincipalBalanceChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tMB")]
        public IWebElement MortgageBrokerTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_btnPC")]
        public IWebElement MortgagePayCharges { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_cmdCheckDetails")]
        public IWebElement MortgageCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_cmdRemoveBusParty")]
        public IWebElement MortgageRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_txtGABcode")]
        public IWebElement MortgageGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_cmdFindName")]
        public IWebElement MortgageFind { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_txtName")]
        public IWebElement MortgageGABName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_chkEditContactInfo")]
        public IWebElement MortgageEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textBusPhone")]
        public IWebElement MortgageBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_txtExtnPhone")]
        public IWebElement MortgageBusinessPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textBusFax")]
        public IWebElement MortgageBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textCellPhone")]
        public IWebElement MortgageCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textPager")]
        public IWebElement MortgagePager { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textEmailAddress")]
        public IWebElement MortgageEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_chkWeeklyEmailStatus")]
        public IWebElement MortgageStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_comboAttention")]
        public IWebElement MortgageAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_chkEdit")]
        public IWebElement MortgageEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textName")]
        public IWebElement MortgageName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_comboSalesRep1")]
        public IWebElement MortgageSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_comboSalesRep2")]
        public IWebElement MortgageSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_textReference")]
        public IWebElement MortgageReference { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aYSP_tdHeading")]
        public IWebElement MortgageBrokerPaidFee { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aYSP_btnPayment")]
        public IWebElement MortgageYieldSpreadPremiumPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aYSP_dcs_0_tdsc")]
        public IWebElement MortgageYieldSpreadPremiumdescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aYSP_dcs_0_tbc")]
        public IWebElement MortgageYieldSpreadPremiumAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aYSP_dcs")]
        public IWebElement BrokerFeeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_btnPayment")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs")]
        public IWebElement MortgageBrokerChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG78_cBntExp3")]
        public IWebElement Mortgage_ExpandFutureRecFees { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_cBntExp3")]
        public IWebElement Mortgage_ExpandMortgageBrokerCharges { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG78_dcs")]
        public IWebElement Mortgage_FutureRecFeesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tdsc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesdescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tdsc")]
        public IWebElement MBChargesDescription0 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_1_tdsc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesdescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_2_tdsc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesdescription3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_1_tbc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_2_tbc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tbc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tbd")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_1_tbd")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_2_tbd")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_3_tbd")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesBuyerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tsc")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tsr")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tga")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG6_btnPayment")]
        public IWebElement MortgageGFE_6MortgageBrokerChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG78_btnPayment")]
        public IWebElement MortgageGFE_7FutureRecordingFeescollectedbyLenderMBPaymentDetails { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement MortgageGFE_7MortgageBrokerExpand { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG78_dcs_0_tdsc")]
        public IWebElement MortgageGFE_7MortgageBrokerDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG78_dcs_0_tbc")]
        public IWebElement MortgageGFE_7MortgageBrokerBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_labelIdcode")]
        public IWebElement MortgageBrokerGABlabel { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tNT")]
        public IWebElement NoteTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_chkCM")]
        public IWebElement NoteConstructionMortgage { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_chkAR")]
        public IWebElement NoteAssignmentofRents { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_ddlPT")]
        public IWebElement NotePaymentType { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtIR")]
        public IWebElement NoteInterestRate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtBR")]
        public IWebElement NoteBaseRate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtPMR")]
        public IWebElement NotePlusMinusRate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtER")]
        public IWebElement NoteEquivalentRate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtMCR")]
        public IWebElement NoteMaxChargeRate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_chkBPy")]
        public IWebElement NoteBalloonPayment { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_chkAC")]
        public IWebElement NoteAlienationClause { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_chkPPP")]
        public IWebElement NotePre_PaymentPenalty { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_chkLCg")]
        public IWebElement NoteLateChargeof_checkbox { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_optLCg")]
        public IWebElement NoteLateChargeof_Percentageradio { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtLCg")]
        public IWebElement NoteLateChargeof_Percentagetext { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtLCgD")]
        public IWebElement NoteLateChargeofDays { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_optLCgA")]
        public IWebElement NoteLateChargeof_Amountradio { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtLCgA")]
        public IWebElement NoteLateChargeof_AmountText { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtIF")]
        public IWebElement NoteInterestFrom { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtFPD")]
        public IWebElement NoteFirstPaymentDue { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtLPD")]
        public IWebElement NoteLastPaymentDue { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtDD")]
        public IWebElement NoteDueDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtADt")]
        public IWebElement NoteAgreementDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtPYA")]
        public IWebElement NotePaymentAmount { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtPDP")]
        public IWebElement NotePaymentDate_and_Period { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_ddlPP")]
        public IWebElement NotePayablePer { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_txtLTm")]
        public IWebElement NoteLoanTerm { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_optLTY")]
        public IWebElement NoteLoanterm_Year { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tNT_NNOTE_optLTM")]
        public IWebElement NoteLoanterm_Month { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement NoteTable { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tPT")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_btnTR")]
        public IWebElement PartiesTrustorMortgagorRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_txtTM")]
        public IWebElement PartiesTrustorMortgagor { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_btnOB")]
        public IWebElement PartiesBeneficiaryMortgageeRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_txtOB")]
        public IWebElement PartiesBeneficiaryMortgagee { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_txtGABcode")]
        public IWebElement PartiesGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_cmdFindName")]
        public IWebElement PartiesFind { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_txtName")]
        public IWebElement PartiesGabName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_chkEditContactInfo")]
        public IWebElement PartiesEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textBusPhone")]
        public IWebElement PartiesBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textBusFax")]
        public IWebElement PartiesBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textCellPhone")]
        public IWebElement PartiesCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textPager")]
        public IWebElement PartiesPager { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textEmailAddress")]
        public IWebElement PartiesEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_chkWeeklyEmailStatus")]
        public IWebElement PartiesStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_comboAttention")]
        public IWebElement PartiesAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_chkEdit")]
        public IWebElement PartiesEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textName")]
        public IWebElement PartiesName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_comboSalesRep1")]
        public IWebElement PartiesSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_comboSalesRep2")]
        public IWebElement PartiesSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_textReference")]
        public IWebElement PartiesReference { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'ico_brokenlink.gif')]")]
        public IWebElement TrustorMortgagerbrokenlink { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'ico_brokenlink.gif')]")]
        public IWebElement benificiarybrokenlink { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tRP")]
        public IWebElement RelatedPartiesTab { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement RelatedParties { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_cmdNw")]
        public IWebElement RelatedPartiesNew { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_cmdDelete")]
        public IWebElement RelatedPartiesRemove { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_grdPaye_0_ddlRT")]
        public IWebElement RelatedPartyRoletype { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_grdPaye_1_ddlRT")]
        public IWebElement RelatedPartyRoletype2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_txtGABcode")]
        public IWebElement RelatedPartiesRelatedPartyGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_cmdFindName")]
        public IWebElement RelatedPartiesRelatedParty_Find { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_txtName")]
        public IWebElement RelatedPartiesRelatedPartyGabName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_labelIdcode")]
        public IWebElement RelatedPartiesGABCodeLabel { get; set; }



                    [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_labelName")]
        public IWebElement RelatedPartiesGABNameLabel1 { get; set; }

                    [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_labelName2")]
                    public IWebElement RelatedPartiesGABNameLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_chkEditContactInfo")]
        public IWebElement RelatedPartiesRelatedParty_Edit { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textBusPhone")]
        public IWebElement RelatedPartiesBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textBusFax")]
        public IWebElement RelatedPartiesBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textCellPhone")]
        public IWebElement RelatedPartiesCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textPager")]
        public IWebElement RelatedPartiesPager { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textEmailAddress")]
        public IWebElement RelatedPartiesEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_chkWeeklyEmailStatus")]
        public IWebElement RelatedPartiesStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_comboAttention")]
        public IWebElement RelatedPartiesAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_chkEdit")]
        public IWebElement RelatedPartiesEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textName")]
        public IWebElement RelatedPartiesName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_comboSalesRep1")]
        public IWebElement RelatedPartiesSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_comboSalesRep2")]
        public IWebElement RelatedPartiesSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_bp_textReference")]
        public IWebElement RelatedPartiesReference { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_txtDOB")]
        public IWebElement RelatedPartiesDOB { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_txtOcc")]
        public IWebElement RelatedPartiesOccupation { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRP_NLRP_grdPaye")]
        public IWebElement RelatedPartiesSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tRM")]
        public IWebElement RcdgMortgageeTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRM_NRM_txtTrustDeedDate")]
        public IWebElement RCDG_MortageTrustDeedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRM_NRM_txtRecordingDate")]
        public IWebElement RCDG_MortageRecordingDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRM_NRM_txtInstrument")]
        public IWebElement RCDG_MortageInstrument { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRM_NRM_txtBook")]
        public IWebElement RCDG_MortageBook { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRM_NRM_txtPage")]
        public IWebElement RCDG_MortagePage { get; set; }

        [FindsBy(How = How.Id, Using = "cmdRf")]
        public IWebElement RCDG_MortageRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tRM_txtTIM")]
        public IWebElement RCDG_MortageTitleInsuranceMortagagee { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'ico_brokenlink.gif')]")]
        public IWebElement RCDG_MortageTitleInsuranceMortagageebrokenlink { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tRcp")]
        public IWebElement RecapTab { get; set; }

        [FindsBy(How = How.Id, Using = "lblLF")]
        public IWebElement PaidByLender { get; set; }

        [FindsBy(How = How.Id, Using = "lblFA")]
        public IWebElement ProjectedLoanFunding { get; set; }       

        [FindsBy(How = How.Id, Using = "lblLCA")]
        public IWebElement LenderDetailsPaidAtClosingCheck { get; set; }

        [FindsBy(How = How.Id, Using = "lblMBNC")]
        public IWebElement MortgageBroker { get; set; }

        [FindsBy(How = How.Id, Using = "tblRecap")]
        public IWebElement RecapTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='Table11']/*//table[1]")]
        public IWebElement RecapTableTop { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='Table11']/*//table[2]")]
        public IWebElement RecapTableBottom { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tNL_tQC")]
        public IWebElement QCClosingTab { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlLT")]
        public IWebElement LoanInterestType { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlOT")]
        public IWebElement OccupancyType { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddltT")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlLP")]
        public IWebElement GovtProgram { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlSOF")]
        public IWebElement SourceOfFund { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlIN")]
        public IWebElement InvestorName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlIPN")]
        public IWebElement SpecialInvestorProductName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_ddlSLN")]
        public IWebElement SecondaryLienInformation { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_txtSD")]
        public IWebElement SecondaryLienRecordedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_txtAppraisedVal")]
        public IWebElement AppraisedValue { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_txtNum")]
        public IWebElement NumberOfUnits { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tQC_NLQC_chkFR")]
        public IWebElement PiggybackSecondHUD1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelName")]
        public IWebElement LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLL")]
        public IWebElement LenderPolicyLiability { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement NoteLenderPolicyLiability { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtReference2")]
        public IWebElement Reference2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tga")]
        public IWebElement MortgageGFE_3MortgageBrokerChargesLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgPRH_dcs_0_json")]
        public IWebElement Description1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblMTEF")]
        public IWebElement lblMTEF { get; set; }

        [FindsBy(How = How.Id, Using = "lblFEE")]
        public IWebElement PaidByMortgageBroker { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtPropertyValue")]
        public IWebElement PropertyValue { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_optAppPropValue")]
        public IWebElement AppraisedPropertyValue { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_optEstPropValue")]
        public IWebElement EstimatedPropertyValue { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelAddress1")]
        public IWebElement LenderAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelAddress2")]
        public IWebElement LenderAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelAddress3")]
        public IWebElement LenderAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelAddress4")]
        public IWebElement LenderAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_labelStateAndZip")]
        public IWebElement LenderCityStateZip { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_tblAddr")]
        public IWebElement LenderAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textContactBusPhone")]
        public IWebElement LenderContactBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_txtContactExtnPhone")]
        public IWebElement LenderContactBusinessPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_bp_textContactEmailAddress")]
        public IWebElement LenderContactEmail { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tPT_NLP_TBP_labelIdcode")]
        public IWebElement PartiesGABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lbl1200LN")]
        public IWebElement LenderFutrRecFeesPaidToLender { get; set; }

        [FindsBy(How = How.Id, Using = "lbl1200MB")]
        public IWebElement MrtgFutrRecFeesPaidToMrtgBroker { get; set; }

        [FindsBy(How = How.Id, Using = "lblNLC")]
        public IWebElement LenderDetailsPaidAtClosingRBL { get; set; }

        [FindsBy(How = How.Id, Using = "lblPOC")]
        public IWebElement LenderDetailsPaidByOthersPOC { get; set; }

        [FindsBy(How = How.Id, Using = "lblRBL1")]
        public IWebElement MrtgBrokerDetailsPaidAtClosingRBL { get; set; }

        [FindsBy(How = How.Id, Using = "lblMPOC")]
        public IWebElement MrtgBrokerDetailsPaidByOthersPOC { get; set; }

        [FindsBy(How = How.Id, Using = "lblMPOL")]
        public IWebElement MrtgBrokerDetailsPaidByOthersLender { get; set; }


        #endregion

        public NewLoan Open()
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            this.WaitForScreenToLoad();

            return this;
        }

        public NewLoan WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 30); //on some slow environment this dialog stay open for a while need to handle it.

            this.SwitchToContentFrame();
            this.WaitCreation(element ?? LoanDetailsGABcode);
            return this;
        }

        public NewLoan Expand(IWebElement e)
        {
            if (String.IsNullOrEmpty(e.GetAttribute("class")) || e.GetAttribute("class").Contains("cButtonExpandFalse"))
                e.FAClick();

            return this;
        }

        public NewLoan SaveAndReloadLoanChargesScreen()
        {
            FastDriver.BottomFrame.Done();
            FastDriver.NewLoan.WaitForScreenToLoad();
            FastDriver.NewLoan.LoanChargesTab.FAClick();
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
            return this;
        }

        public NewLoan WaitForLoanChargesTabToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30); //on some slow environment this dialog stay open for a while need to handle it.
            this.SwitchToContentFrame();
            this.WaitCreation(NewLoanChargesTable);
            return this;
        }

        public NewLoan WaitForMortgageBrokerTabToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30); //on some slow environment this dialog stay open for a while need to handle it.
            this.SwitchToContentFrame();
            this.WaitCreation(MortgageGABcode);

            return this;
        }

        public NewLoan WaitForRecapToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            this.SwitchToContentFrame();
            this.WaitCreation(RecapTable);
            return this;
        }

        public NewLoan FillNewLoanForm(NewLoanParameters newLoan)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoanDetailsLoantype);

            LoanDetailsLoantype.FASelectItem(newLoan.Type);
            LoanDetailsLoanAmount.FASetText(newLoan.Amount + FAKeys.Tab);

            //handle "Do you want to update Liability Amount" alert
            FastDriver.WebDriver.HandleDialogMessage(timeout: 2);
            this.SwitchToContentFrame();

            LoanDetailsGABcode.FASetText(newLoan.GABCode);
            LoanDetailsFind.FAClick();

            LoanDetailsMortgageInsCase.FASetText(newLoan.MortgageInsCase);
            //handle "GAB code not found" alert
            FastDriver.WebDriver.HandleDialogMessage(timeout: 3);
            this.SwitchToContentFrame();

            this.WaitForValue(LoanDetailsGabcodeLabel, newLoan.GABCode);
            return this;
        }

        public NewLoan FindGABCode(string GABCode, bool waitForValue = false)
        {
            WaitForScreenToLoad(LoanDetailsGABcode);
            LoanDetailsGABcode.FASetText(GABCode);
            LoanDetailsFind.FAClick();
            this.WebDriver.HandleDialogMessage(timeout: 3); // to handle Changing Business Party error
            this.SwitchToContentFrame();
            if(waitForValue)
                this.WaitForValue(LoanDetailsGabcodeLabel, GABCode);

            return this;
        }

        public NewLoan MortgageFindGABCode(string GABCode)
        {
            this.SwitchToContentFrame();
            MortgageGABcode.FASetText(GABCode);
            MortgageFind.FAClick();
            this.WebDriver.HandleDialogMessage(timeout: 3); // to handle Changing Business Party error
            this.SwitchToContentFrame();
            this.WaitForValue(MortgageBrokerGABlabel, GABCode);

            return this;
        }

        public NewLoan MortgageFindGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }

            MortgageGABcode.FASetText(GABCode);
            MortgageGABName.FASetText(GABName);
            MortgageFind.FAClick();
            return this;
        }

        public NewLoan PartiesFindGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }

            PartiesGABcode.FASetText(GABCode);
            PartiesGabName.FASetText(GABName);
            PartiesFind.FAClick();
            return this;
        }

        public NewLoan FindRelatedPartyGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }
            RelatedPartiesRelatedPartyGABcode.FASetText(GABCode);
            RelatedPartiesRelatedPartyGabName.FASetText(GABName);
            RelatedPartiesRelatedParty_Find.FAClick();
            return this;
        }

        public NewLoan FindPartiesGAB(string GABCode = null, string GABName = null)
        {
            if (GABCode == null && GABName == null)
            {
                throw new ArgumentNullException("Must specify a GAB name or a GAB code to search for GAB.");
            }
            PartiesGABcode.FASetText(GABCode);
            PartiesGabName.FASetText(GABName);
            PartiesFind.FAClick();
            return this;
        }

        public Dictionary<string, string> GetLenderDetails()
        {
            Dictionary<string, string> LenderDetails = new Dictionary<string, string>();
            try
            {
                this.WaitForScreenToLoad();
                string LenderName = this.BusinessPartyNameField.FAGetText().Trim()+ " " + this.BusinessPartyNameField2.FAGetText().Trim();
                Reports.TestStep = "Get lender details from new loan screen";
                LenderDetails.Add("LenderName", string.IsNullOrEmpty(LenderName.Trim()) ? "Blank" : LenderName.Trim());
                if (string.IsNullOrEmpty(this.LenderContactBusinessPhone.FAGetValue().Trim()))
                LenderDetails.Add("LenderBusinessPhone", string.IsNullOrEmpty(this.LoanDetailsBusinessPhone.FAGetValue().Trim()) ? "Blank" : this.LoanDetailsBusinessPhone.FAGetValue().Trim());
                else
                    LenderDetails.Add("LenderBusinessPhone", this.LenderContactBusinessPhone.FAGetValue().Trim());
                if (string.IsNullOrEmpty(this.LenderContactBusinessPhoneExt.FAGetValue().Trim()))
                LenderDetails.Add("LenderBusinessPhoneExtension", string.IsNullOrEmpty(this.LoanDetailsBusinessPhoneExtension.FAGetValue().Trim()) ? "Blank" : this.LoanDetailsBusinessPhoneExtension.FAGetValue().Trim());
                else
                    LenderDetails.Add("LenderBusinessPhoneExtension", this.LenderContactBusinessPhoneExt.FAGetValue().Trim());

                LenderDetails.Add("LenderBusinessFax", string.IsNullOrEmpty(this.LoanDetailsBusinessFax.FAGetValue().Trim()) ? "Blank" : this.LoanDetailsBusinessFax.FAGetValue().Trim());
                LenderDetails.Add("LenderCellPhone", string.IsNullOrEmpty(this.LoanDetailsCellPhone.FAGetValue().Trim()) ? "Blank" : this.LoanDetailsCellPhone.FAGetValue().Trim());
                LenderDetails.Add("LenderPager", string.IsNullOrEmpty(this.LoanDetailsPager.FAGetValue().Trim()) ? "Blank" : this.LoanDetailsPager.FAGetValue().Trim());
                if(string.IsNullOrEmpty(this.LenderContactEmail.FAGetValue().Trim()))
                LenderDetails.Add("LenderEmail", string.IsNullOrEmpty(this.LoanDetailsEmailAddress.FAGetValue().Trim()) ? "Blank" : this.LoanDetailsEmailAddress.FAGetValue().Trim());
                else
                    LenderDetails.Add("LenderEmail", this.LenderContactEmail.FAGetValue().Trim());

                LenderDetails.Add("LenderNMLSID", string.IsNullOrEmpty(this.NewLoanDetails_NMLSID.FAGetValue().Trim()) ? "Blank" : this.NewLoanDetails_NMLSID.FAGetValue().Trim());
                if(string.IsNullOrEmpty(this.NewLoanDetails_STLICENSEID.FAGetValue().Trim())||this.NewLoanDetails_STLICENSEID.FAGetValue().Trim()=="0")
                LenderDetails.Add("LenderStateLicenseID", "Blank");
                else
                    LenderDetails.Add("LenderStateLicenseID", this.NewLoanDetails_STLICENSEID.FAGetValue().Trim());
              //
                for (int i = 1; i <LenderAddress.GetRowCount(); i++)
                {
                    string LenderAddressLine = LenderAddress.PerformTableAction(i, 1, TableAction.GetText).Message;
                    if (i == LenderAddress.GetRowCount()-1)
                    {

                        string[] LenderCityStateZip = LenderAddressLine.Split(',');
                        LenderDetails.Add("LenderZip", LenderCityStateZip[LenderCityStateZip.Length - 2].Trim());
                        LenderDetails.Add("LenderState", LenderCityStateZip[LenderCityStateZip.Length - 3].Trim());
                        LenderDetails.Add("LenderCity", LenderCityStateZip[LenderCityStateZip.Length - 4].Trim());
                    }
                    else
                    {
                        LenderDetails.Add("LenderAddressLine" + i, LenderAddressLine);
                    }
                }

                for (int i = 1; i <= 4;i++ )
                {
                    string Value="Blank";
                   bool isKeyAdded= LenderDetails.TryGetValue("LenderAddressLine" + i,out Value);
                   if (!isKeyAdded)
                       LenderDetails.Add("LenderAddressLine" + i, "Blank");
                }

                LenderDetails.Add("LenderContactName", this.NewLoanDetails_ContactName.FAGetText());               
                LenderDetails.Add("LenderContactSTLicenseID", string.IsNullOrEmpty(this.NewLoanDetails_Contact_STLICENSEID.FAGetSelectedItem().Trim()) ? "Blank" : this.NewLoanDetails_Contact_STLICENSEID.FAGetSelectedItem().Trim());
                LenderDetails.Add("LenderContactNMLSID", string.IsNullOrEmpty(this.NewLoanDetails_Contact_NMLSID.FAGetText().Trim()) ? "Blank" : this.NewLoanDetails_Contact_NMLSID.FAGetText().Trim()); 
                return LenderDetails;
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return LenderDetails;
            }

        }

        public NewLoan ClickLoanDetailsTab()
        {
            this.LoanDetailsTab.FAClick();
            this.WaitForScreenToLoad();
            return this;
        }

        public NewLoan ClickChargesTab()
        {
            this.SwitchToContentFrame();
            LoanChargesTab.FAClick();
            this.WaitForLoanChargesTabToLoad();

            return this;
        }

        public NewLoan ClickMortgageBrokerTab()
        {
            this.SwitchToContentFrame();
            MortgageBrokerTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            WaitForMortgageBrokerTabToLoad();

            return this;
        }

        public NewLoan ClickRecapTab(IWebElement element = null)
        {
            RecapTab.FAClick();
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? RecapTable);

            return this;
        }

        public NewLoan ClickQCClosingTab()
        {
            this.SwitchToContentFrame();
            this.QCClosingTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            this.SwitchToContentFrame();
            this.WaitCreation(TransactionType);
            return this;
        }

        public NewLoan ClickNoteTab()
        {
            NoteTab.FAClick();
            this.SwitchToContentFrame();
            this.WaitCreation(NotePaymentType);
            return this;
        }

        public NewLoan ClickPartiesTab()
        {
            PartiesTab.FAClick();
            this.SwitchToContentFrame();
            this.WaitCreation(PartiesGABcode);
            return this;
        }

        public NewLoan ClickRelatedPartiesTab()
        {
            RelatedPartiesTab.FAClick();
            this.SwitchToContentFrame();
            this.WaitCreation(RelatedPartiesNew);
            return this;
        }

        public NewLoan ClickRcdgMortageeTab()
        {
            this.RcdgMortgageeTab.FAClick();
            this.SwitchToContentFrame();
            this.WaitCreation(RCDG_MortageBook);
            return this;
        }

        public NewLoan UpdateImpoundCharge(string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editdescription = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoanChargesImpoundsTable);

            if (months.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString() + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab);
                Playback.Wait(250);
            }
            if (editdescription != string.Empty)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editdescription + FAKeys.Tab);
                Playback.Wait(250);
            }

            return this;
        }

        public NewLoan UpdateImpoundCharge(IWebElement table, string chargeDescription, double? buyerCharge, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editdescription = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(table);

            IWebElement inputElement;
            if (months.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                table.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (editdescription != string.Empty)
            {
                inputElement = table.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editdescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            return this;
        }

        public NewLoan AddImpoundCharge(string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editdescription = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoanChargesImpoundsTable);

            if (chargeDescription != string.Empty)
            {
                LoanChargesImpoundsTable.PerformTableAction(LoanChargesImpoundsTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (months.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString() + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete + FAKeys.Tab).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            //push TAB to trigger new line to show up
            LoanChargesImpoundsTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.Click);
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(FAKeys.TabAway);
            return this;
        }

        public PaymentDetailsDlg OpenPaymentDetailsDialog(IWebElement chargesTable, string chargeDescription, IWebElement paymentDetailsButton)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            chargesTable.PerformTableAction(1, chargeDescription, 1, TableAction.Click);

            paymentDetailsButton.FAClick();
            return FastDriver.GetPage<PaymentDetailsDlg>();
        }

        public NewLoan AddPrincipalReductionAdhocCharge(string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoanChargesPrincipalReductiontable);

            if (chargeDescription != string.Empty)
            {
                LoanChargesPrincipalReductiontable.PerformTableAction(LoanChargesPrincipalReductiontable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                var chargeElement = LoanChargesPrincipalReductiontable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.GetCell).Element.FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                chargeElement.Click();
                chargeElement.Clear();
                chargeElement.FireEvent("onfocus");
                chargeElement.FASetText(buyerCharge.ToString());

                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                LoanChargesPrincipalReductiontable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                LoanChargesPrincipalReductiontable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                LoanChargesPrincipalReductiontable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                LoanChargesPrincipalReductiontable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
            }
            return this;

        }

        public NewLoan AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public NewLoan AddChargeRefinance(IWebElement chargesTable, string chargeDescription, double? BorrowerCharge = null, double? BorrowerCredit = null,  double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Charge", TableAction.SetText, BorrowerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Credit", TableAction.SetText, BorrowerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }


        public NewLoan UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public void EnterValuesInPDD(PDD obj)
        {
            this.SwitchToContentFrame();
            IWebElement NewLoanHtmlTable = WebDriver.FindElement(By.Id(obj.NewLoanTableId));
            int filterrowcount = NewLoanHtmlTable.GetRowCount();
            //var NewLoantbledit;

            for (int i = 1; i < filterrowcount; i++)
            {
                string newloanchargeid, newloanimgid;
                int l = i - 1;
                if (obj.NewLoanTableId != "tNL_tLC_NLC_IPror_CGrid_tbButtons")
                {
                    newloanchargeid = obj.NewLoanTableId + "_" + l + "_tdsc";
                    newloanimgid = obj.NewLoanTableId + "_" + l + "_lbp";
                    var NewLoantbledit = WebDriver.FindElement(By.Id(newloanchargeid));
                    string desc = NewLoantbledit.GetAttribute("value").ToString().Trim();
                    if (desc == obj.ChargeDescription)
                    {
                        NewLoanHtmlTable.PerformTableAction((i + 1), 1, TableAction.GetCell).Element.FAClick();
                        break;
                    }
                }
                else
                { }
            }

            var btnPayment = WebDriver.FindElement(By.Id(obj.NewLoanTableId.Replace("dcs", "") + "btnPayment"));
            btnPayment.FAClick();
            Playback.Wait(750);
            FastDriver.PaymentDetailsDlg.EnterValuesInPPD(obj);

        }

        public NewLoan ExpandChargeSection(IWebElement section)
        {
            return ExpandCollapseChargeSection(section);
        }

        public NewLoan CollapseChargeSection(IWebElement section)
        {
            return ExpandCollapseChargeSection(section, false);
        }

        private NewLoan ExpandCollapseChargeSection(IWebElement section, bool expand = true)
        {
            string xclass = "cButtonExpand";
            if (expand)
                xclass = "cButtonExpandFalse";

            int tries = 0;
            while (section.GetAttribute("class") == xclass && tries++ < 3)
            {
                section.Click();
                Playback.Wait(1000);
            }
            //TODO: report if unable to expand/collapse
            return this;
        }

        public NewLoan WaitForLoanDetailsTabToLoad()
        {
            WebDriverWait waitDriver = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            waitDriver.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return LoanDetailsLoantype.Displayed;
                }
                catch (NoSuchElementException)
                {
                    return false;
                }
                catch (StaleElementReferenceException)
                {
                    return false;
                }
                catch (InvalidOperationException)
                {
                    return false;
                }
            });
            return this;                     // this element appears on both HUD and CD files
        }

        public NewLoan AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false, bool clickAccept = true)
        {
            string alertText = "";
            try
            {
                WebDriver.WaitForAlertToExist(5);
                var alert = WebDriver.SwitchTo().Alert();
                alertText = alert.Text;
                if (clickAccept)
                    alert.Accept();
                else
                    alert.Dismiss();
                if (SwitchToWindow)
                    WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            }
            catch (Exception)
            {
                alertText = "No Alert was Found";
            }
            finally
            {
                if (CompareWith != null)
                {
                    SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
                }

            }
            return this;
        }

        public void EditLoanAmountAndVerifyLoanLiabilityWhenFACCFeeExist(string loanamount)
        {
            LoanDetailsLoanAmount.FASetText(loanamount);
            Keyboard.SendKeys(FAKeys.TabAway);
            VerifyMsgWhenLoanAmountismodified();
            VerifyMsgDisplayedWhenLoanLiabilityisModifiedandFACCFeeExists();
            string LoanAmt = Convert.ToDouble(loanamount).ToString("###,###,##0.00");
            Support.AreEqual(LoanDetailsLoanLiability.FAGetValue(), LoanAmt);
            FastDriver.BottomFrame.Done();
        }

        public void VerifyMsgWhenLoanAmountismodified()
        {
            string Message = "Loan Amount has changed.  Do you wish to update the Loan Amount to the Loan Liability?";
            AcceptDialogAndCompareWith(CompareWith: Message);
        }

        public  void EnterDataInSectionA()
        {

            Reports.TestStep = "Enter Charge in A Charge Lines.";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            Reports.TestStep = "Enter charge in Credit charge point table.";
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.CreditChargePointsTable, "", 100.99, null, 200.99, null, 400);

            Reports.TestStep = "Enter charge in Origination charge table.";
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.OriginationChargesTable, "Application Fee", 100.99, 500, 200.99, 600, 600);
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.OriginationChargesTable, "Origination Fee", 300.99, 700, 400.99, 800, 800);

            Reports.TestStep = "Enter charge for Mortgage Broker Fee.";
            FastDriver.NewLoan.ClickMortgageBrokerTab();
            FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription);
            FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FASetText("Broker Fee Mortage Broker");
            FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("500.00");
            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionE_NewLoan_MB()
        {

            Reports.TestStep = "Enter Charge in E Charge Lines.";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.LoanCharges_ExpandFutureRecFeesLender.FAClick();

            Reports.TestStep = "Enter charge in Credit charge point table.";
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Assignment", 100.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Deed", 200.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Mortgage", 300.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Municipal Lien Certificate", 400.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Release", 500.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderTable, "Future Recording Fee - Subordination", 600.99, null, null, null, null, null, null, null);

            Reports.TestStep = "Enter charge for Mortgage Broker Fee.";
            FastDriver.NewLoan.ClickMortgageBrokerTab();
            FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Assignment", 100.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Deed", 200.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Mortgage", 300.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Municipal Lien Certificate", 400.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Release", 500.99, null, null, null, null, null, null, null);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.Mortgage_FutureRecFeesTable, "Future Recording Fee - Subordination", 600.99, null, null, null, null, null, null, null);

            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionF_NewLoan_MB()
        {

            Reports.TestStep = "Enter Charge in F Charge Lines.";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            Reports.TestStep = "Enter charge in Interest Calculation table.";
            FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
            FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FASelectItem("365");
            FastDriver.NewLoan.LoanChargesInterestCalculationPerDiem.FAClick();
            FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FASetText("1000.99");
            FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText("03-30-2016");
            FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText("04-28-2016");
            FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FASetCheckbox(true);
            FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FASetCheckbox(false);
            FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FASetText("29,028.71");
            FastDriver.BottomFrame.Done();
        }

        public  void EnterDataInSectionBNewLoan()
        {
            Reports.TestStep = "Enter Charge in B Charge Lines.";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            Reports.TestStep = "Enter charge in New Loan Charges table.";
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Credit Report", 100.99, 600, 200.99, 900, 777);
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.NewLoanChargesTable, "Flood Certification", 100.99, 700, 200.99, 1000, 888);

            Reports.TestStep = "Enter charge in Mortgage Broker ,mortage broker charges table.";
            FastDriver.NewLoan.ClickMortgageBrokerTab();
            FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription);
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Appraisal Fee", 100.99, 300.00, 200.99, 400.99, 999);
            FastDriver.NewLoan.AddCharge(FastDriver.NewLoan.MortgageBrokerChargesTable, "Credit Report", 100.99, 300.00, 200.99, 400.99, 555);
            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionG_NewLoan()
        {

            Reports.TestStep = "Enter Charge in G Charge Lines.";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            Reports.TestStep = "Enter charge in Impound table.";
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, "Homeowner's Insurance", 100.99, null, 300.99, null, 400);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, "Mortgage Insurance", 200.99, null, 240.99, null, 400);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, "City Property Taxes", 300.99, null, 500.99, null, 400);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, "County Property Taxes", 400.99, null, 600.99, null, 400);
            FastDriver.NewLoan.UpdateCharge(FastDriver.NewLoan.LoanChargesImpoundsTable, "Annual Assessments", 500.99, null, 700.99, null, 400);

            Reports.TestStep = "Select Credit Radio button in Aggregate Accounting Adjustment section and Enter Credits.";
            FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCredit.FAClick();
            FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("345.67");
            FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.Clear();

            FastDriver.BottomFrame.Done();
        }

        public void VerifyMsgDisplayedWhenLoanLiabilityisModifiedandFACCFeeExists()
        {
            string Message = "Changing the Sales Price, Loan Amount or Liability Amounts will result in automatic recalculation of impacted fees if no override exists.If override exists there will be no auto-recalculation and impacted fees will be removed.";
            AcceptDialogAndCompareWith(CompareWith: Message);
        }

        public void OpenLoanChargesPrincipalreduction_Constructionholdback_PaymentDetailsDialog()
        {
            FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_PaymentDetails.FAClick();
        }

        /// <summary>
        /// Calculate Buyer Charge for Insterest Calculation Summary when interest type is Fixed Rate
        /// </summary>
        /// <param name="buyerCharge">Principal Balance Buyer Charge</param>
        /// <param name="days">Days difference between dates</param>
        /// <param name="basedOnDays">Based on days</param>
        /// <param name="i">Interest percentage</param>
        /// <returns></returns>
        private decimal CalculateFixedRatedBuyerCharge(decimal buyerCharge, int days, int basedOnDays, decimal i)
        {
            return buyerCharge * (i/100) * (days / basedOnDays);
        }

        public void verifyEmptyLine(string chargeDesc, IWebElement table)
        {
            IWebElement charge, lastCharge;
            charge = table.PerformTableAction(table.GetRowCount(), 1, TableAction.GetCell).Element
                    .FAFindElements(ByLocator.TagName, "input").FirstOrDefault(input => input.Displayed).FireEvent("onblur");
            if (charge.GetAttribute("value").Contains(chargeDesc))
            {
                lastCharge = table.PerformTableAction(table.GetRowCount(), table.GetColumnCount(), TableAction.GetCell).Element
                    .FAFindElements(ByLocator.TagName, "input").FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                lastCharge.Click();
                Keyboard.SendKeys(FAKeys.TabAway);

            }
        }
    }

}
