using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class NewLoanDisbursements : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNw")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdRmv")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_txtGABcode")]
		public IWebElement GABcode { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_cmdFindName")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textBusPhone")]
		public IWebElement BusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textBusFax")]
		public IWebElement BuinesssFax { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textEmailAddress")]
		public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_chkWeeklyEmailStatus")]
		public IWebElement WeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_comboAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_chkEdit")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textName")]
		public IWebElement TextName { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_comboSalesRep1")]
		public IWebElement SalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_comboSalesRep2")]
		public IWebElement SalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "txtChkAmt")]
		public IWebElement CheckAmount { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_0_chkSel")]
		public IWebElement Charges1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_1_chkSel")]
		public IWebElement Charges2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_2_chkSel")]
		public IWebElement Charges3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_3_chkSel")]
		public IWebElement Charges4 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_4_chkSel")]
		public IWebElement Charges5 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPayee")]
		public IWebElement PayeeSummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges")]
		public IWebElement DisbursementChargesTable { get; set; }

		[FindsBy(How = How.Id, Using = "bpP_labelIdcode")]
		public IWebElement IDCode { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_1_lblPayeeName")]
		public IWebElement ChargesPayeeName1 { get; set; }

		[FindsBy(How = How.Id, Using = "idCheckIssuedIcon")]
		public IWebElement CheckIssuedIcon { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_3_lblPayeeName")]
		public IWebElement ChargesPayeeName2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_0_lblBuyerCharge")]
		public IWebElement BuyerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_0_lblBuyerCredit")]
		public IWebElement BuyerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_0_lblSellerCharge")]
		public IWebElement SellerCharge { get; set; }

		[FindsBy(How = How.Id, Using = "dgridCharges_0_lblSellerCredit")]
		public IWebElement SellerCredit { get; set; }

		[FindsBy(How = How.Id, Using = "tblBusPartyDetails")]
		public IWebElement LoanDisbBusinessCompo { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelName")]
        public IWebElement PayeeName { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelName2")]
        public IWebElement PayeeNameLebel2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelAddress")]
        public IWebElement PayeeAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelAddress2")]
        public IWebElement PayeeAddress2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelStateAndZip")]
        public IWebElement PayeeCityStateZipCode { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPayee_0_lblName")]
        public IWebElement PayeeName1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPayee_1_lblName")]
        public IWebElement PayeeName2 { get; set; }


        public IWebElement NthChargeSelect(int i=0)
        {
            return FastDriver.WebDriver.FindElement(By.Id("dgridCharges_" + i + "_chkSel"));
        }
		#endregion

        public NewLoanDisbursements WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode);

            return this;
        }

        public NewLoanDisbursements FindGABCode(string GABCode)
        {
            this.SwitchToContentFrame();
            this.GABcode.FASetText(GABCode);
            this.Find.FAClick();
            //this.WebDriver.HandleDialogMessage(timeout: 3); // to handle Changing Business Party error
            this.SwitchToContentFrame();
            this.WaitForValue(IDCode, GABCode);

            return this;
        }

	}
}
