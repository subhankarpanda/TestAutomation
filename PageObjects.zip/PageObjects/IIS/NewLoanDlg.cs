using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class NewLoanDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "__tab_tNL_tLD")]
		public IWebElement LoanDetails { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLD_NLD_ddlLT")]
		public IWebElement LoanType { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLA")]
		public IWebElement LoanAmount { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLD_NLD_txtLL")]
		public IWebElement LoanLiability { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdHUD")]
		public IWebElement HUD { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdLegacy")]
		public IWebElement Legacy { get; set; }

        [FindsBy(How = How.Id, Using = "tNL_tLD_NLD_rdCD")]
        public IWebElement CD { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tLC")]
		public IWebElement LoanChargesTab { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tMB")]
		public IWebElement MortgageBrokerTab { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tNT")]
		public IWebElement NoteTab { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tPT")]
		public IWebElement PartiesTab { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tRP")]
		public IWebElement RelatedPartiesTab { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tRM")]
		public IWebElement RcdgMortgageeTab { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tRcp")]
		public IWebElement RecapTab { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_8_tdsc")]
		public IWebElement LoanChargesGFE_3NewLoanDlgChargesdescription8 { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_8_tbc")]
		public IWebElement LoanChargesGFE_3NewLoanDlgChargesBuyerCharge8 { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement LoanChargesPrincipalreduction_Constructionholdback { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tLC_NLC_cgLC_dcs_0_tga")]
		public IWebElement LoanChargesGFE_3NewLoanDlgChargesGFEAmount { get; set; }

		[FindsBy(How = How.Id, Using = "__tab_tNL_tMB")]
		public IWebElement MortgageBrokertab { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_txtGABcode")]
		public IWebElement MortgageGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tMB_NMB_bp_cmdFindName")]
		public IWebElement MortgageFind { get; set; }

		[FindsBy(How = How.Id, Using = "tNL_tMB_NMB_aMCG_dcs_0_tga")]
		public IWebElement MortgageGFE_3MortgageBrokerChargesAmount { get; set; }

		#endregion

        public NewLoanDlg WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Blank page", false, 10);
            FastDriver.WebDriver.WaitForWindowAndSwitch("New Loan", true, 30);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(LoanDetails, 30);
            return this;
        }
	}
}
