using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class NewLoanSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDel")]
		public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry")]
		public IWebElement LoanSummaryTable { get; set; }

		#endregion

        /// <summary>
        /// Opens preferred New Loan instance.
        /// </summary>
        /// <param name="index">Based on 1st row equals index=1</param>
        /// <returns></returns>
        public NewLoan Open(int index)
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
            this.WaitForScreenToLoad();
            this.LoanSummaryTable.PerformTableAction(index + 1, 1, TableAction.DoubleClick);

            return FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
        }

        public NewLoanSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? LoanSummaryTable);

            return this;
        }

        public NewLoanSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan");
           return this.WaitForScreenToLoad();
        }
	}
}
