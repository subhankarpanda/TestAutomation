﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Interactions;
using UIKeyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using UIModifierKeys = System.Windows.Input.ModifierKeys;
using SeleniumInternalHelpersSupportLibrary;
using AutoIt;
using System.Diagnostics;
using FASTSelenium.ImageRecognition;

namespace FASTSelenium.PageObjects.IIS
{
    public class NextGenDocumentRepository : PageObject
    {
        public NextGenDocumentRepository()
            : base()
        {
            IRHelpers.InitElements<NextGenDocumentRepository>(this);
        }

        #region IR Elements | Deployment Items from "ImageRecognition\Media\DocRep\*"

        [IRFindsBy(URI = "DR_Button_CreateDocument.BMP", /*Left = 220, Top = 365*/ Width = 40, Height = 40, Text = "Template Search")]
        public IRButton IRCreateDocument { get; set; }

        [IRFindsBy(URI = "DR_Tab_TemplateSearch_OFF.BMP", /*Left = 320, Top = 90*/ Width = 130, Height = 50, Text = "Template Search")]
        public IRButton IRTplSearchTab_OFF { get; set; }

        [IRFindsBy(URI = "DR_Tab_TemplateSearch_ON.BMP", /*Left = 320, Top = 90*/ Width = 130, Height = 50, Text = "Template Search")]
        public IRButton IRTplSearchTab_ON { get; set; }

        [IRFindsBy(URI = "DR_Button_Search.BMP", /*Left = 700, Top = 150*/ Width = 50,  Height = 50, Text = "Search")]
        public IRButton IRSearch { get; set; }

        [IRFindsBy(URI = "DR_DN_Sanity09.BMP", /*Left = 460, Top = 360*/ Width = 160, Height = 40, Text = "SAN_NEXTGEN_09")]
        public IRButton IRDocName_Sanity09 { get; set; }

        [IRFindsBy(URI = "DR_DN_Sanity09_Edited.BMP", /*Left = 460, Top = 360*/ Width = 160, Height = 40, Text = "SAN_NEXTGEN_09")]
        public IRButton IRDocName_Sanity09_Edited { get; set; }

        [IRFindsBy(URI = "DR_DN_EscrowInstruction.BMP", /*Left = 460, Top = 370*/ Width = 310, Height = 50, Text = "NEXTGEN_SAN_EscrowInstruction_DoNotTouch")]
        public IRButton IRDocName_EscrowInstruction { get; set; }
        
        [IRFindsBy(URI = "DR_RCM_Deliver.BMP", /*Left = 530, Top = 370*/ Width = 230, Height = 40, Text = "Deliver")]
        public IRButton IRContextMenu_Deliver { get; set; }

        [IRFindsBy(URI = "DR_RCM_Print.BMP", /*Left = 750, Top = 380*/ Width = 100, Height = 30, Text = "Print")]
        public IRButton IRContextMenu_Print { get; set; }

        [IRFindsBy(URI = "DR_TN_Sanity100.BMP", /*Left = 380, Top = 370*/ Width = 150, Height = 50, Text = "SAN_NEXTGEN100")]
        public IRButton IRTplName_Sanity100 { get; set; }

        [IRFindsBy(URI = "DR_RCM_CreateDocument.BMP", /*Left = 450, Top = 380*/ Width = 150, Height = 60, Text = "Create Document")]
        public IRButton IRContextMenu_CreateDocument { get; set; }

        [IRFindsBy(URI = "DR_RCM_EditDocumentName.BMP", /*Left = 610, Top = 470*/ Width = 240, Height = 50, Text = "Edit Document Name")]
        public IRButton IRContextMenu_EditDocumentName { get; set; }

        [IRFindsBy(URI = "DR_RCM_AddWatermark.BMP", /*Left = 520, Top = 510*/ Width = 250, Height = 50, Text = "Add Watermark")]
        public IRButton IRContextMenu_AddWatermark { get; set; }

        [IRFindsBy(URI = "DR_Checkbox_All.BMP", Width = 120, Height = 40, Text = "All")]
        public IRButton IRFilterValue_All { get; set; }

        #endregion

        #region WebElements_FileDocuments

        public string ContextMenuXPath = "(//ul[@id='contextMenuDocument']/li[1]/ul[@id='deliver_ul_single'])[1]";

        [FindsBy(How = How.Id, Using = "ui-id-3")]
        public IWebElement FileDocumentsTab { get; set; }

        [FindsBy(How = How.Id, Using = "ui-id-4")]
        public IWebElement TemplateSearchTab { get; set; }

        [FindsBy(How = How.Id, Using = "btnDocTemplateSearch")]
        public IWebElement TemplateSearchButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnUploadDocument")]
        public IWebElement Upload { get; set;}

        [FindsBy(How = How.Id, Using = "btnScanDocument")]
        public IWebElement Scan { get; set;}

        [FindsBy(How = How.Id, Using = "btnImportRecord")]
        public IWebElement ImportedRecordedDocs { get; set; }

        [FindsBy(How = How.Id, Using = "btnDEInstructions")]
        public IWebElement DeliveryInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeArchive")]
        public IWebElement DeArchive { get; set; }

        [FindsBy(How = How.Id, Using = "DocumentSearchViewModel_SearchScope")]
        public IWebElement SearchScope_TheFile_File { get; set; }

        [FindsBy(How = How.Id, Using = "DocumentSearchViewModel_KeyWord")]
        public IWebElement SearchScope_Keyword { get; set; }

        [FindsBy(How = How.Id, Using = "DocumentSearchViewModel_UserFileNumber")]
        public IWebElement SearchScope_UserFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "btnFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "btnNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#gridDocumentsInnerGrid, #gridDocuments")]
        public IWebElement DocumentsTable { get; set; }

        //Added by Luz
        [FindsBy(How = How.Id, Using = "gridDocumentsInnerGrid")]
        public IWebElement DocTableRows { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/a[text()='P a c k a g e s']")]
        public IWebElement Packages { get; set; }

        [FindsBy(How = How.LinkText, Using = "Reload Packages")]
        public IWebElement ReloadPackagesicon { get; set; }

        [FindsBy(How = How.Id, Using = "imgVersionFlg")]
        public IWebElement ImageVersionIcon { get; set; }

        [FindsBy(How = How.Id, Using = "imgSplit")]
        public IWebElement SplitIcon { get; set; }

        [FindsBy(How = How.Id, Using = "imgPDFTypeDoc")]
        public IWebElement PdfViewerIcon { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='editImage']/a")]
        public IWebElement EditImage { get; set; }

        [FindsBy(How = How.Id, Using = "imgVersionFlg")]
        public IWebElement VersionIcon { get; set; }

        // Search Result context menu
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='editdocname']/a")]
        public IWebElement EditDocumentName { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='viewedit']/a")]
        public IWebElement ViewEdit { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='addwatermark']/a")]
        public IWebElement AddWatermark { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='convert separator']//a[@href='#convertTo']")]
        public IWebElement Convertto { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='convert separator']//a[@href='#convertToPDF']")]
        public IWebElement ConverttoPDF { get; set; }      

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']/a[@href='#deliver']")]
        public IWebElement SearchResult_Deliver { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//a[@href='#deliverPrint']")]
        public IWebElement SearchResult_DeliverPrint { get; set; }
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//a[@href='#deliverWINTRACK']")]
        public IWebElement SearchResult_DeliverWINTRACK { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//a[@href='#deliverFax']")]
        public IWebElement SearchResult_DeliverFax { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//a[@href='#deliverEmail']")]
        public IWebElement SearchResult_DeliverEmail { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//a[@href='#deliverPreview']")]
        public IWebElement SearchResult_DeliverPreview { get; set; }

        [FindsBy(How = How.Id, Using = "DocumentName")]
        public IWebElement DashboardDocuments { get; set; }

         [FindsBy(How = How.XPath, Using = "134255_ImageColId_0")]
        public IWebElement TemplatePhrases { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//a[@href='#deliverImageDoc']")]
        public IWebElement SearchResult_DeliverImageDoc { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='deliver separator']//ul[@id='deliver_ul_single']/li[@class='deliver']//a[@href='#deliverImageDoc']")]
        public IWebElement SearchResult_DeliverImageDoc1 { get; set; }

        //Added By Subhankar for Interface EP
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='interfaceQ separator']//div[@id='interface_Que']/table[@id='dynIQTable']/tr/input[@id='cbx_EP2']")]
        public IWebElement EPCheckBox { get; set; }
        [FindsBy(How = How.Id, Using = "ImgEP2")]
        public IWebElement InterfaceEP { get; set; }
        //Added By Subhankar
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='interfaceQ separator']/a[@href='#interfaceQ']")]
        public IWebElement AddInterfaceQueue { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_EP2")]
        public IWebElement EP { get; set; }


         [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='details']/a[@href='#details']")]
         public IWebElement SearchResult_Details { get; set; }

         [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#viewedit']")]
         public IWebElement PhrasesViewEdit { get; set; }

         //contextMenuDocument
         [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='viewedit']/a[@href='#viewedit']")]
         public IWebElement Phrases_ViewEdit { get; set; }

         [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li/span[@class='dynatree-node dynatree-folder dynatree-expanded dynatree-has-children dynatree-lastsib dynatree-exp-el dynatree-ico-ef']")]
         public IWebElement AssociateDocumentPackageParent { get; set; } 

        [FindsBy(How = How.Id, Using = "WaterMarkdd")]
        public IWebElement WaterMark_SelectWatermarkOption { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Water Mark']/ancestor::div[2]//button/span[text()='Cancel']")]
        public IWebElement WaterMark_Cancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Water Mark']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement WaterMark_Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='changeDocType']/a")]
        public IWebElement Change_Type { get; set; }

        //Edit Document popup
        [FindsBy(How = How.Id, Using = "txtDocName")]
        public IWebElement EditDocument_DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDocType")]
        public IWebElement ChangeType_DocumentType { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement ChangeType_Comments { get; set; }

        [FindsBy(How = How.Id, Using = "txtDocuName")]
        public IWebElement ChangeType_DocumentName { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Edit Document']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement EditDocument_Done { get; set; }

        [FindsBy(How = How.Id, Using = "StatusChangeDate")]
        public IWebElement SelectDocumetcopy { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_5.2")]
        public IWebElement StFilterCreated { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_5.4")]
        public IWebElement EditFilter { get; set; }

        [FindsBy(How = How.Id, Using = "filterDialog")]
        public IWebElement SfilterOk { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='remove separator']/a")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@class='WebGridHeader']/th[@class='DocType']/img")]
        public IWebElement TypeFilter { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@class='WebGridHeader']/th[@class='StatusDescr']/img")]
        public IWebElement StatusFilter { get; set; }

        // Indranil Start

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']//a[@href='#Finalize']")]
        public IWebElement Finalize { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='remove separator']/a[@href='#remove']")]
        public IWebElement RemoveMulti { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_5.5")]
        public IWebElement FinalizedFilter { get; set; }

        [FindsBy(How = How.Id, Using = "btn_OK5")]
        public IWebElement StatusFilterOK { get; set; }

        [FindsBy(How = How.Id, Using = "btn_ClearFilter")]
        public IWebElement StatusFilterClear { get; set; }

        [FindsBy(How = How.Id, Using = "divTitlePolicyDetails")]
        public IWebElement LinkTemplatePopupDiv { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_4.18")]
        public IWebElement TitleReportFilter { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_4.11")]
        public IWebElement LenderPolicyFilter { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_4.14")]
        public IWebElement OwnerPolicyFilter { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_4.25")]
        public IWebElement EscrowPDBFilter { get; set; }

        [FindsBy(How = How.Id, Using = "gridPublishImages")]
        public IWebElement PublishDocTable { get; set; }

        // Favorite Uploaded Document Related 

        [FindsBy(How = How.Id, Using = "imgFavoriteDocument")]
        public IWebElement FavoriteDocsUIButton { get; set; }
        

        [FindsBy(How = How.Id, Using = "tblFavoriteView")]
        public IWebElement FavoriteDocsDialog_Table { get; set; }

        [FindsBy(How = How.Id, Using = "btnFavoriteDocumentDone")]        
        public IWebElement FavoriteDocsDialog_Done { get; set; }
        
       
        // Indranil End


        //Added by Luz
        [FindsBy(How = How.XPath, Using = "//table[@id='dataTable']/tbody/tr/td/img[@alt='Clear filter']")]
        public IWebElement XRemoveFilter { get; set; }
        
        [FindsBy(How = How.Id, Using = "cbx_4.41")]
        public IWebElement RemovedItemsCheckBox { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='filterDialog']//input[@type='button'][@value='OK']")]
        public IWebElement OKTypeFilter { get; set; }

        //Added By Subhankar for Publish Queue
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='publish separator']/a")]
        public IWebElement AddPublishQueue { get; set; }

        //Added by subhankar for Publish Document 
        [FindsBy(How = How.Id, Using = "divPublishImagesGrid")]
        public IWebElement PublishDoc { get; set; }
        [FindsBy(How = How.Id, Using = "PublishedToImg")]
        public IWebElement PublishTo { get; set; }
        [FindsBy(How = How.Id, Using = "chkSelectAll")]
        public IWebElement SelectAllPublish { get; set; }
        [FindsBy(How = How.XPath, Using = "//div/span[text()='Publish Documents']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement PublishDocument_Done { get; set; }

        //Added By Subhankar for LenderPolicy Exception
        //[FindsBy(How = How.XPath, Using = "//div[@id='divDocumentInfo']/div[@class='div5px']/table/tr[1]/td[1]/textarea")]
        //public IWebElement LenderException { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divDocumentInfo']//textarea")]
         public IWebElement LenderException { get; set; }


        //[FindsBy(How = How.XPath, Using = "//div[@id='divDocumentInfo']/textarea//ancestor::/div[@class='div5px']/table/tr[1]/td[1]")]
        //public IWebElement LenderException1 { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[id='divSearchDocuments']/ancestor::div[2]//button/span[text()='Cancel']")]
        public IWebElement CopyDocuments_Cancel { get; set; }



        #region Context menu of DocumentsTable
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']/a[@href='#deliver']")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverPrint']")]
        public IWebElement DeliverPrint { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverFax']")]
        public IWebElement DeliverFax { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverEmail']")]
        public IWebElement DeliverEmail { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverPreview']")]
        public IWebElement DeliverPreview { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverImageDoc']")]
        public IWebElement DeliverImageDoc { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverLVIS']")]
        public IWebElement DeliverLVIS { get; set; }
        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='deliver separator']//a[@href='#deliverWINTRACK']")]
        public IWebElement DeliverWINTRACK { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='addtoAssocPackage separator']/a[@href='#addtoAssocPackage']")]
        public IWebElement AddToAssociatePackage { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocumentMulti']/li[@class='addtoRTMPackage']/a[@href='#addtoRTMPackage']")]

         // "//ul[@id='contextMenuDocument']/li[@class='addtoRTMPackage']/a[@href='#addtoRTMPackage']")]

        public IWebElement AddToRTMPackage { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='changeDocType']/a[@href='#changeDocType']")]
        public IWebElement ChangeType { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='addtoRTMPackage']/a[@href='#addtoRTMPackage']")]
        public IWebElement AddToRTMPackage1 { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']//li/a[@href='#Finalize']")]
        public IWebElement Doc_Finalize { get; set; }



        //Added by Rashmi

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='addtoAssocPackage separator']/a")]
        public IWebElement AddAssociatePkg { get; set; }

        
        [FindsBy(How = How.XPath, Using = "//div/span[text()='Associate Packages']/ancestor::div[2]//button/span[text()='Cancel']")]
        public IWebElement AssociatePackages_Cancel { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divAddToPackages']/table[@id='dynATable']/tbody//tr//td[@class='Menu']//input")]
        public IWebElement AssociatePackagesRbtn { get; set; }    
       

        [FindsBy(How = How.XPath, Using = "//div[@id='divAddToPackages']/table[@id='dynATable']/tbody//tr[2]//td[1][@class='Menu']//input")]
        public IWebElement AssociatePackagesRbtn2 { get; set; }



        [FindsBy(How = How.XPath, Using = "//div[@id='divAddToPackages']/table[@id='dynATable']/tbody//tr[3]//td[1][@class='Menu']//input")]
        public IWebElement AssociatePackagesRbtn3 { get; set; }

        #endregion

        // the following 2 elements only works for the 1st AssociatePackage
        [FindsBy(How = How.Id, Using = "_rdbtnCNAPackage")]
        public IWebElement AssociatePackages { get; set; }

        [FindsBy(How = How.Id, Using = "dynATable")]
        public IWebElement AssociatePackagesTable { get; set; }
        

        [FindsBy(How = How.XPath, Using = "//*[@id='_rdbtnCNAPackage']/following-sibling::input")]
        public IWebElement AssociatePackagesName { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Associate Packages']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement AssociatePackages_Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a[text()='Associate Document Packages']/ancestor::li[1]")]
        public IWebElement AssociateDocumentPackages { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a[text()='RTM Packages']/ancestor::li[1]")]
        public IWebElement RTMDocumentPackages { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#Rename']")]
        public IWebElement AssociateDocumentPackages_Rename { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']/li/a[@text()='Rename']")]
        public IWebElement AssociateDocumentPackages_Rename1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#Remove']")]
        public IWebElement AssociateDocumentPackages_Remove { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='docMenu']/li/a[@href='#RemoveDoc']")]
        public IWebElement AssociateDocumentPackages_Remove1 { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#Deliver']")]
        public IWebElement AssociateDocumentPackages_Deliver { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#Print']")]
        public IWebElement AssociateDocumentPackages_DeliverPrint { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#Fax']")]
        public IWebElement AssociateDocumentPackages_DeliverFax { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#EMail']")]
        public IWebElement AssociateDocumentPackages_DeliverEMail { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#Preview']")]
        public IWebElement AssociateDocumentPackages_DeliverPreview { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aDocSubMenu']//a[@href='#ImageDoc']")]
        public IWebElement AssociateDocumentPackages_DeliverImageDoc { get; set; }

        //Search Scope drop down  

        [FindsBy(How = How.XPath, Using = "//ul[@id='SearchDocsContextMenu']//a[@href='#copyall']")]
        public IWebElement CopyallFile { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='SearchDocsContextMenu']//a[@href='#copy']")]
        public IWebElement CopyFile { get; set; }


        [FindsBy(How = How.XPath, Using = "//ul[@id='SearchDocsContextMenu']//a[@href='#preview']")]
        public IWebElement Preview { get; set; }


        // Search Scope Button 

        [FindsBy(How = How.Id, Using = "btnCopyDocs")]
        public IWebElement CopyButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnCopyAllDocs")]
        public IWebElement CopyAllButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnPreviewDoc")]
        public IWebElement PreviewButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Cancel']")]
        public IWebElement CancelButton { get; set; }        

       
        //Asocieted Document 

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']")]
        public IWebElement PackagesTree { get; set; }

        
        // Save Filter Options Documents Table Header

        [FindsBy(How = How.Id, Using = "dynTable")]
        public IWebElement TypeFilterParentTable { get; set; }

        [FindsBy(How = How.Id, Using = "cbx_4")]
        public IWebElement All_filter { get; set; }

        [FindsBy(How = How.Id, Using = "afterFilterImage")]
        public IWebElement AfterFilterImage { get; set; }
        
        
        

        #endregion

        #region X Web Elements 
        //Added By Rashmi
        [FindsBy(How = How.Id, Using = "item.DocStatusCD")]
        public IWebElement DocStatusCDCombo { get; set; }


        [FindsBy(How = How.Id, Using = "item.DocTypeName")]
        public IWebElement itemDocTypeName { get; set; }


        [FindsBy(How = How.Id, Using = "item.DocumentName")]
        public IWebElement itemDocumentName { get; set; }

             
        [FindsBy(How = How.XPath, Using = "//table[@id='gridDocumentsInnerGrid']//td[@class='DocumentName']/input")]
        public IWebElement itemDocumentName1 { get; set; }



        [FindsBy(How = How.Id, Using = "item.DocTypeCDID")]
        public IWebElement itemDocTypeCDID { get; set; }






        [FindsBy(How = How.Id, Using = "eventComment")]
        public IWebElement TxtEventComment { get; set; }

        [FindsBy(How = How.Id, Using = "divEventComments")]
        public IWebElement DivEventComment { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divEventComments']//textarea[@id='eventComment']")]
        public IWebElement UnfinalizedNote { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement FAFErrorMessageList { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Reason - UnFinalize']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement ReasonUnfinalize_Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']/ul/li/ul/li/span/a")]
        public IWebElement AssociateDocumentPackageEle { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul[1]/li[2]/span")]
        public IWebElement AssociateDocumentPackageEle1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul[1]/li[3]/span")]
        public IWebElement AssociateDocumentPackageEle2 { get; set; }



        [FindsBy(How = How.Id, Using = "tblFASTDocs")]
        public IWebElement tableFastDocs { get; set; }

        [FindsBy(How = How.Id, Using = "tblImageContainer")]
        public IWebElement tableImages { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul[1]/li[2]/following-sibling::ul/li/span[contains(text()='NEXTGEN_SAN_TitleReports_DoNotTouch')]")]


        //[FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/following-sibling::ul/li[2]/span[contains(text()='NEXTGEN_SAN_TitleReports_DoNotTouch')]")]
        //public IWebElement RTMPackageEle11 { get; set; }


        // Aleady below two elements are present with the same element name.. if some one want these remove other two and add the below ones , build was failing bcz of this

        //[FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[1]/span/span[1]")]
        //public IWebElement RTMPackageEle1 { get; set; }


        //[FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[2]/span")]
        //public IWebElement RTMPackageEle2 { get; set; }

       

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']/ul/li/ul/li/li/span/a/input[@id='editNode']")]
        public IWebElement AssociateDocumentPackageEle_Edit { get; set; } 
        
        //
        [FindsBy(How = How.XPath, Using = "//ul[@id='headerContextMenuDocument']/li[@class='clearFilter']/a")]
        public IWebElement ClearFilter { get; set; }
                
        [FindsBy(How = How.XPath, Using = "//table[@id='dynTable']//td[contains(text(), 'Fast Docs')]/input")]
        public IWebElement TypeFilter_FastDocs { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#gridDocumentsInnerGrid")]
        public IWebElement DocumentsInnerTable { get; set; }
        #endregion

        #region WebElements_TemplateSearch

        // Favorite Filter criteria Select any Region

        [FindsBy(How = How.Id, Using = "lst_FavoriteSearch")]
        public IWebElement MySearch { get; set; }

        [FindsBy(How = How.Id, Using = "btnSaveSearch")]
        public IWebElement MySearchSaveButton { get; set; }

        [FindsBy(How = How.Id, Using = "favoriteName")]
        public IWebElement EnterNewFilterName { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Save']")]
        public IWebElement SaveButonMySearch { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='dataTable']")]
        public IWebElement SourceAndStateAll { get; set; }

        //[FindsBy(How = How.XPath, Using = "//table[@id='dataTable']//span[@id='ddcl-ddl_states-ddw']")]
        //public IWebElement StateAll { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='0']")]
        public IWebElement SelectALL{ get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='410']")]
        public IWebElement CaliforniaRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='11974']")]
        public IWebElement CarefreeRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='12837']")]
        public IWebElement SelectRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='6210']")]
        public IWebElement SelectNATRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='349']")]
        public IWebElement SelectMortgageRegion { get; set; } 

        [FindsBy(How = How.XPath, Using = "//td/table[@id='dataTable']//span[@id='ddcl-ddl_sources']")]
        public IWebElement ValuesRegeion { get; set; }

        [FindsBy(How = How.XPath, Using = "//td/table[@id='dataTable']//span[@id='ddcl-ddl_states']")]
        public IWebElement StateFilter { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='dataTable']/tbody/tr/td/img[@alt='add new filter']")]
        public IWebElement AddFilterRow { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='dataTable']/tbody")]
        public IWebElement DataTable { get; set; }

        [FindsBy(How = How.Id, Using = "ddl_FilterTypes_5")]
        public IWebElement KeywordsFilter { get; set; }

        [FindsBy(How = How.Id, Using = "tempObjectCd")]
        public IWebElement NewTemplateRegion { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateSearch")]
        public IWebElement SearchTemplateCriteriaButton { get; set; }

        [FindsBy(How = How.Id, Using = "ddSearchScopes")]
        public IWebElement SearchScope { get; set; }

        [FindsBy(How = How.Id, Using = "divTemplateSearchResults")]
        public IWebElement TableResults { get; set; }

        [FindsBy(How = How.Id, Using = "ddSearchScopes")]
        public IWebElement TemplateCriteria { get; set; }               

        [FindsBy(How = How.Id, Using = "ddTemplTypes")]
        public IWebElement TemplateTypeSelect { get; set; }

        [FindsBy(How = How.Id, Using = "txtTemplateName")]
        public IWebElement TemplateDescription { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateSearch")]
        public IWebElement Search { get; set; }

        [FindsBy(How = How.Id, Using = "btnTemplateNewSearch")]
        public IWebElement TemplateNewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "ddl_Filters")]
        public IWebElement FilterSelection { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#gridTemplateResultsInnerGrid, #gridTemplateResults")]
        public IWebElement TemplatesTable { get; set; }

        [FindsBy(How = How.Id, Using = "gridTemplateResultsInnerGrid")]
        public IWebElement TemplatesTableInnerGrid { get; set; }

        [FindsBy(How = How.Id, Using = "paggingOn")]
        public IWebElement PagingON { get; set; }

        [FindsBy(How = How.Id, Using = "paggingOff")]
        public IWebElement PagingOFF { get; set; }

        [FindsBy(How = How.Id, Using = "ddl_FilterTypes_0")]
        public IWebElement Keywords_filter_0 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[contains(@id, 'ddl_FilterTypes_')]")]
        public IWebElement ddl_FilterTypes { get; set; }     
         
        [FindsBy(How = How.Id, Using = "ddcl-ddl_states")]
        public IWebElement StateValue_CA { get; set; }

        [FindsBy(How = How.Id, Using = "ddcl-ddl_states-i1")]
        public IWebElement StateValue_CA_1 { get; set; }

        [FindsBy(How = How.Id, Using = "ddcl-ddl_states-i0")]
        public IWebElement StateValue_All { get; set; }

        [FindsBy(How = How.LinkText, Using = "add new filter")]
        public IWebElement AddFilterIcon { get; set; }

        [FindsBy(How = How.CssSelector, Using = ":contains(Text(),'CA')")]
        public IWebElement StateValues { get; set; }

        //Added by Luz
        [FindsBy(How = How.XPath, Using = "//li[@class='ui-state-tabdeselect ui-state-default ui-corner-top']/a[text()='Template Results']")]
        public IWebElement TemplateResultsTab { get; set; }

        // context menu for Template Search Results table
        [FindsBy(How = How.XPath, Using = "//ul[@id='UserTemplateContextMenu']/li[@class='create']/a")]
        public IWebElement CreateDocument { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//ul[@id='UserTemplateContextMenu']/li[@class='edit']/a")]
        public IWebElement CreateEditDocument { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='UserTemplateContextMenu']/li[@class='create']/a[@href='#CreateAllDocuments']")]
        public IWebElement CreateAllDocuments { get; set; }

        [FindsBy(How = How.Id, Using = "tblUserinputSelection_1")]
        public IWebElement MultiIndexValueTable1 { get; set; }

        [FindsBy(How = How.Id, Using = "tblUserinputSelection_2")]
        public IWebElement MultiIndexValueTable2 { get; set; }

        //Added by Luz
        [FindsBy(How = How.Id, Using = "imgCreateDoc")]
        public IWebElement CreateDocIcon { get; set; }

        [FindsBy(How = How.Id, Using = "imgEditDoc")]
        public IWebElement CreateEditDocIcon { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divTitlePolicyDetails']/table")]
        public IWebElement TitlePolicyDetailsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select a Policy Document']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement TitlePolicyDetails_Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='viewedit']/a[text()='Phrase View/Edit']")]
        public IWebElement PhraseViewEdit { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='contextMenuDocument']/li[@class='viewedit']/a[text()='Document View/Edit']")]
        public IWebElement DocumentViewEdit { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='DEContextMenu']/li[@class='delete separator']/a")]
        public IWebElement Delete_PhraseContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='deleteDonesBtnID']")]
        public IWebElement Done_Reasonbutton { get; set; }

        [FindsBy(How = How.Id, Using = "ddl_keywords")]
        public IWebElement keywordsValues { get; set; }

        // Work on these later
        [FindsBy(How = How.XPath, Using = "//tbody/div[not(contains(@style,'display: none'))]//table")]
        public IWebElement Dialog_Table { get; set; }

        [FindsBy(How = How.XPath, Using = "//tbody/div[not(contains(@style,'display: none'))]//button/span[text()='Cancel']")]
        public IWebElement Dialog_Cancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//tbody/div[not(contains(@style,'display: none'))]//button/span[text()='Done']")]
        public IWebElement Dialog_Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnCreateEdit")]
        public IWebElement DocInfo_CreateEdit { get; set; }

        [FindsBy(How = How.Id, Using = "gridTemplateResultsdivInnerGrid")]
        public IWebElement TableResultsTemplateSearchTAB { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='gridTemplateResultsdivInnerGrid']//div//img[@id='img_afav']")]
        public IWebElement FavoriteOption { get; set; }

          //Added By Rishi
        [FindsBy(How = How.Id, Using = "ddcl-ddl_sources")]
        public IWebElement SourcesFilter_Values { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='189']")]
        public IWebElement QASandpoint { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='dataTable']//span[text()='Corporate, Region']")]
        public IWebElement CorporateRegion { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='196']")]
        public IWebElement Corporate { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='12837']")]
        public IWebElement Region { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_sources-ddw']//input[@type='checkbox'][@value='410']")]
        public IWebElement CaliforniaR { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_states-ddw']//input[@type='checkbox'][@Id='ddcl-ddl_states-i0']")]
        public IWebElement StateValue_ALL_0 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ddcl-ddl_states-ddw']//input[@type='checkbox'][@Id='ddcl-ddl_states-i1']")]
        public IWebElement StateValueCA { get; set; }

        [FindsBy(How = How.XPath, Using = "//div//span[@class='dynatree-node dynatree-exp-c dynatree-ico-c']/a[text()='APR Endorse Template']")]
        public IWebElement Packages1_Ele0 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select a Commitment Document']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement TitlePolicyDetailsCommtiment_Done { get; set; }          //Select a Policy Document

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select Exceptions']/ancestor::div[2]//button/span[text()='Done']")]
        public IWebElement CopyFromExcep_Done { get; set; }
        //  btnSave
        [FindsBy(How = How.Id, Using = "divSaveMySearch")]
        public IWebElement FavoriteSearchDIV { get; set; }

        [FindsBy(How = How.Id, Using = "chkPrimary")]
        public IWebElement FavoriteSearchPrimaryChk { get; set; }

        [FindsBy(How = How.Id, Using = "lblFilterChange")]
        public IWebElement Modified_Not_Saved { get; set; }

        [FindsBy(How = How.Id, Using = "btnSave")]
        public IWebElement FavoriteSearchSaveBtn { get; set; }

        #endregion
        //Select Exceptionsclose Desc
        #region WebElements_DocumentInfo

        [FindsBy(How = How.Id, Using = "lblSLiability")]
        public IWebElement SalesLiability { get; set; }

        [FindsBy(How = How.Id, Using = "phraseNameDesc")]
        public IWebElement TablePhrasehead { get; set; }

        //[FindsBy(How = How.Id, Using = "ui-id-6")]
        //public IWebElement PhraseViewTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#deletePhrase']")]
        public IWebElement DeletePhraseTable { get; set; }


        //[FindsBy(How = How.Id, Using = "ui-id-7")]  // not sure if id is auto-generated. as of 1/8/16 in Eval00, id = ui-id-5
        [FindsBy(How = How.XPath, Using = "//li[@id='liInfo']/a[text()='Info']")]
        public IWebElement DocumentInfoTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@id='liDocInfo']/a[text()='Info']")]
        public IWebElement DocumentInfoTab1 { get; set; }


        //Added by Luz
        [FindsBy(How = How.Id, Using = "divTemplateProperties")]
        public IWebElement InfoTabscreen { get; set; }

        //[FindsBy(How = How.Id, Using = "ui-id-8")]  // not sure if id is auto-generated. as of 1/8/16 in Eval00, id = ui-id-6
        [FindsBy(How = How.XPath, Using = "//div[@id='divDocumentInfo']//li/a[text()='Phrase View']")]
        public IWebElement PhraseViewTab { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divDocumentInfo']//li/a[text()='Data Elements']")]
        public IWebElement DataElementsTab { get; set; }

        //[FindsBy(How = How.Id, Using = "ui-id-9")]  // not sure if id is auto-generated. as of 1/8/16 in Eval00, id = ui-id-7
        [FindsBy(How = How.XPath, Using = "//div[@id='divDocumentInfo']//li/a[text()='Details']")]
        public IWebElement DetailsTab { get; set; }           

        [FindsBy(How = How.Id, Using = "DocumentNameID")]
        public IWebElement DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "DocStatusCD")]
        public IWebElement DocumentStatus { get; set; }

        [FindsBy(How = How.Id, Using = "DocumentID")]
        public IWebElement DocumentID { get; set; }

        [FindsBy(How = How.Id, Using = "btnDocEditor")]
        public IWebElement DocumentEditor { get; set; }

        [FindsBy(How = How.Id, Using = "ddlDeliveryMethods")]
        public IWebElement DocumentDeliveryMethods { get; set; }

        [FindsBy(How = How.Id, Using = "btnCreateSave")]
        public IWebElement DocInfo_CreateSave { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement DocInfo_Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnTitleReportSave")]
        public IWebElement DocInfo_Save { get; set; }

        [FindsBy(How = How.Id, Using = "txtEffectiveDate")]
        public IWebElement DocInfo_EffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtTitleReportDescr")]
        public IWebElement TitleReportDocDescription { get; set; }

        [FindsBy(How = How.Id, Using = "btnCopyFrom")]
        public IWebElement DocInfo_CopyFrom { get; set; }

        [FindsBy(How = How.Id, Using = "btnTitleReportSave")]
        public IWebElement TitleReportSave { get; set; }

        //Added By Subhankar for Policy
        [FindsBy(How = How.Id, Using = "btnPolicyInfoSave")]
        public IWebElement PolicyReportSave { get; set; }

        [FindsBy(How = How.Id, Using = "txtEffectiveDate")]
        public IWebElement EffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtExccd")]
        public IWebElement TitelReportExceptions { get; set; }

        

        [FindsBy(How = How.Id, Using = "ddlExcsrc")]
        public IWebElement TitelReportExceptionsSourceRegion { get; set; }

        [FindsBy(How = How.Id, Using = "txtReqcd")]
        public IWebElement TitelReportRequirements { get; set; }

        [FindsBy(How = How.Id, Using = "ddlReqsrc")]
        public IWebElement TitelReportRequirementsSourceRegion { get; set; }

        [FindsBy(How = How.Id, Using = "txtInfocd")]
        public IWebElement TitelReportInformation { get; set; }

        [FindsBy(How = How.Id, Using = "ddlInfosrc")]
        public IWebElement TitelReportInformationSourceRegion { get; set; }


        [FindsBy(How = How.Id, Using = "txtEndorsecd")]
        public IWebElement TitelReportEndorsement { get; set; }
        // aDDED by Rishi
        [FindsBy(How = How.Id, Using = "ExcRegionName")]
        public IWebElement TitelReportExceptSourceReg { get; set; }
       
         [FindsBy(How = How.Id, Using = "ReqRegionName")]
        public IWebElement TitelReportReqtSourceReg { get; set; }
         
         [FindsBy(How = How.Id, Using = "InfoRegionName")]
         public IWebElement TitelReportInfotSourceReg { get; set; }
         
         [FindsBy(How = How.Id, Using = "EndorseRegionName")]
         public IWebElement TitelReportEndortSourceReg { get; set; }
          //**

        [FindsBy(How = How.Id, Using = "ddlEndorsesrc")]
        public IWebElement TitelReportEndorsementSourceRegion { get; set; }

        [FindsBy(How = How.Id, Using = "All_Elements")]
        public IWebElement AllElements { get; set; }

        [FindsBy(How = How.Id, Using = "Elements_Missing_Values")]
        public IWebElement Elements_Missing_Values { get; set; }

        [FindsBy(How = How.LinkText, Using = "Spell Check")]
        public IWebElement Spell_Check { get; set; }

        [FindsBy(How = How.XPath, Using = "//td/span[@title='Refresh Document']")]
        public IWebElement RefreshDocument { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@title='Please select ...']")]
        public IWebElement PleaseSelect { get; set; }

        [FindsBy(How = How.Id, Using = "btnMovePhrasesUp")]
        public IWebElement MovePhrasesUp { get; set; }

        [FindsBy(How = How.Id, Using = "btnMovePhrasesDown")]
        public IWebElement MovePhrasesDown { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeletePhrases")]
        public IWebElement DeletePhrases { get; set; }

        [FindsBy(How = How.Id, Using = "Span_Expand")]
        public IWebElement ExpandIcon { get; set; }

        [FindsBy(How = How.Id, Using = "Span_Collapse")]
        public IWebElement CollapseIcon { get; set; }

        [FindsBy(How = How.Id, Using = "btnSaveDocumentDataElements")]
        public IWebElement SaveDocumentDataElements { get; set; }

        [FindsBy(How = How.Id, Using = "btnDataElementSave")]
        public IWebElement DataElementAutoSave { get; set; }

        [FindsBy(How = How.LinkText, Using = "Refresh Phrase")]
        public IWebElement Refresh_PhraseIcon { get; set; }

        [FindsBy(How = How.LinkText, Using = "Refresh Data Element")]
        public IWebElement Refresh_DataElementIcon { get; set; }

        [FindsBy(How = How.Id, Using = "divDocDetails")]
        public IWebElement DocumentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "btnAgentNetPolicyNum")]
        public IWebElement AssignPolicyNum { get; set; }

        [FindsBy(How = How.Id, Using = "txtPolicyDescr")]
        public IWebElement PolicyDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerAmount")]
        public IWebElement Policy_BuyerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerAmount")]
        public IWebElement Policy_SellerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "txtIssueDate")]
        public IWebElement Policy_IssueDate { get; set; }

        [FindsBy(How = How.Id, Using = "txtPolicyNumber")]
        public IWebElement PolicyInfo_PolicyNumber{ get; set; }

        [FindsBy(How = How.Id, Using = "ddlFastProduct")]
        public IWebElement ProductSelect { get; set; }

        [FindsBy(How = How.Id, Using = "btnPolicyInfoSave")]
        public IWebElement PolicyInfoSave { get; set; }

        [FindsBy(How = How.Id, Using = "gridPropertyInfo")]
        public IWebElement Policy_PropertyTable { get; set; }

        [FindsBy(How = How.Id, Using = "gridLenderInfo")]
        public IWebElement Policy_LenderTable { get; set; }

        [FindsBy(How = How.Id, Using = "gridSellerInfo")]
        public IWebElement Policy_SellerTable { get; set; }

        [FindsBy(How = How.Id, Using = "gridBuyerInfo")]
        public IWebElement Policy_BuyerTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnEndorsementInfoSave")]
        public IWebElement EndorsementInfoSave { get; set; }

        [FindsBy(How = How.Name, Using = "txtDEValue")]
        public IWebElement DataElementTextValue { get; set; }

        [FindsBy(How = How.Id, Using = "txtEffectiveDt")]
        public IWebElement Policy_EffectiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "chkAutoPolicyNumber")]
        public IWebElement Policy_Autonumbercheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "DataElementGrid")]
        public IWebElement DataElementTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divDeleteReason']/textarea[@id='DeleteReason']")]
        public IWebElement DeletePhraseReason { get; set; }

        
        public IWebElement GetFilterSelect(int index)
        {
            return this.WebDriver.FindElement(By.CssSelector("table#dataTable tr:nth-child(" + index + ") td:nth-child(2) select"));
        }

        public IWebElement GetFilterValue(int index)
        {
            return this.WebDriver.FindElement(By.CssSelector("table#dataTable tr:nth-child(" + index + ") td:nth-child(3) span.ui-dropdownchecklist-text"));
        }
        
        public IWebElement GetFilterInput(int index, string value)
        {
            return this.WebDriver.FindElement(By.CssSelector("table#dataTable tr:nth-child(" + index + ") td:nth-child(3) input[value=\"" + value + "\"]"));
        }

        public IWebElement GetFilterLabel(int index, int labelIndex)
        {
            return this.WebDriver.FindElement(By.CssSelector("table#dataTable tr:nth-child(" + index + ") td:nth-child(3) div.ui-dropdownchecklist-item:nth-child(" + labelIndex + ") label"));
        }

        public IWebElement GetFilterInputDiv(int index, int divIndex)
        {
            return this.WebDriver.FindElement(By.CssSelector("table#dataTable tr:nth-child(" + index + ") td:nth-child(3) div.ui-dropdownchecklist-item:nth-child(" + divIndex + ")"));
        } 
        #endregion

        #region WebElements_PhaseView
        // on EVAL00, i got id="ui-id-11"
        //[FindsBy(How = How.Id, Using = "ui-id-11")]
        //public IWebElement PhraseViewTab { get; set; }

        [FindsBy(How = How.Id, Using = "PhraseDataElementGridResult")]
        public IWebElement PhraseDataElementTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "table#PhraseDataElementGridResult table#table_1 tr#row_1")]
        public IWebElement PhraseViewTableHeader1 { get; set; }

        //Added by Luz
        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#insert']")]
        public IWebElement PhrasesInsert { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='DEContextMenu']/li[@class='edit separator']/a")]
        public IWebElement PhraseContextEdit{ get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#above']")]
        public IWebElement PhrasesAbovetContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#below']")]
        public IWebElement PhraseBelowContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#aboveAddPhrase']")]
        public IWebElement AbovePhraseContext { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#belowAddPhrase']")]
        public IWebElement BelowPhraseContext { get; set; }
        //
        [FindsBy(How = How.Id, Using = "editorControlObject")]
        public IWebElement DocumentEditorObject { get; set; }     

        [FindsBy(How = How.Id, Using = "refreshDocBtn")]
        public IWebElement Refresh { get; set; }

        [FindsBy(How = How.Id, Using = "table_0")]
        public IWebElement PhraseDataElementTable0 { get; set; }

        [FindsBy(How = How.Id, Using = "table_1")]
        public IWebElement PhraseDataElementTable1 { get; set; }

        [FindsBy(How = How.Id, Using = "table_2")]
        public IWebElement PhraseDataElementTable2 { get; set; }

        [FindsBy(How = How.Id, Using = "table_3")]
        public IWebElement PhraseDataElementTable3 { get; set; }

        [FindsBy(How = How.Id, Using = "table_4")]
        public IWebElement PhraseDataElementTable4 { get; set; }

        [FindsBy(How = How.Id, Using = "table_5")]
        public IWebElement PhraseDataElementTable5 { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='insert separator']/a[contains(text(),'Insert')]")]
        public IWebElement Insert { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='above']/a[contains(text(),'Above')]")]
        public IWebElement Above { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='below separator']/a[contains(text(),'Below')]")]
        public IWebElement Below { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='aboveSectionBreak separator']/a[contains(text(),'Section Break')]")]
        public IWebElement AboveSectionBreak { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//ul[@id='belowAddPhrase']/li[@class='belowSectionBreak separator']/a")]
        public IWebElement BelowSectionBreak { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='editSB separator']/a[contains(text(),'Edit Section Break')]")]
        public IWebElement EditSectionBreak { get; set; }

        [FindsBy(How = How.XPath, Using = "//li[@class='delete separator']/a[contains(text(),'Delete')]")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#aboveRestartNumbering']")]
        public IWebElement AboveRestartNumbering { get; set; }

        [FindsBy(How = How.Id, Using = "DEContextMenu")]
        public IWebElement DEContextMenu { get; set; }

        [FindsBy(How = How.Id, Using = "above")]
        public IWebElement AboveBelow { get; set; }

        [FindsBy(How = How.Id, Using = "aboveAddPhrase")]
        public IWebElement AbovePhraseContextMenu { get; set; }

        [FindsBy(How = How.Id, Using = "DEContextMenu")]
        public IWebElement ContextMenu1 { get; set; }

        [FindsBy(How = How.Id, Using = "above")]
        public IWebElement ContextMenu2 { get; set; }

        [FindsBy(How = How.Id, Using = "aboveAddPhrase")]
        public IWebElement ContextMenu3 { get; set; }

        [FindsBy(How = How.Id, Using = "belowAddPhrase")]
        public IWebElement ContextMenu4 { get; set; }

        [FindsBy(How = How.Id, Using = "MiscPhraseName")]
        public IWebElement Misc_Phrase_Name { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divMiscPhrase']/following-sibling::*/div[1]//button/span[text()='Done']")]
        public IWebElement Misc_Phrase_DialogDone { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSectionBreakDialog']/following-sibling::*/div[1]//button/span[text()='Done']")]
        public IWebElement SectionBreak_DialogDone { get; set; }

        //Added by Subhankar
        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#aboveAddTemplate']")]
        public IWebElement AddTemplate { get; set; }

        [FindsBy(How = How.XPath, Using = "//form[@id='form1']//div[@id='pnlTempDlg']//table[@id='fraTest']//td/select[@id='templateList']")]
        public IWebElement TemplateType { get; set; }

        

        //Added by Luis
        public IWebElement PhraseViewDETableValues(string phrase)
        {
            var phrasesAmount = PhraseDataElementTable.GetRowCount();
            for(int i = 1; i <= phrasesAmount; i++){
                if(PhraseDataElementTable.PerformTableAction(i,1,TableAction.GetText).Message.Contains(phrase)){
                    return PhraseDataElementTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.Id("Table"));
                }
                  
            }

            throw new NoSuchElementException("Could not find Phrase "+phrase);
        }

        //Added by Luz
        public void ContextMenuSeparator(string separator)
        {
            string MenuContextclass = FastDriver.NextGenDocumentRepository.DEContextMenu.FAFindElement(ByLocator.CssSelector, separator).FAFindElement(ByLocator.TagName, "a").FAGetAttribute("class");
            if (MenuContextclass == "disabledCSS")
            {
                Support.AreEqual(true.ToString(), true.ToString(), "Option is disable");
            }
            else
            {
                Support.AreEqual(false.ToString(), true.ToString(), "Option is Enable");
            }

        }
        #endregion

        #region WebElements_Details

        [FindsBy(How = How.Id, Using = "tblDocDetails")]
        public IWebElement DetailsTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Document Information']/ancestor::div[2]//button/span[text()='OK']")]
        public IWebElement DocDetails_OK { get; set; }

        //Added by Luz
        [FindsBy(How = How.Id, Using = "tblDocDetails")]
        public IWebElement PhraseViewDetailsTable { get; set; }
        #endregion

        #region RTM Package

        [FindsBy(How = How.Id, Using = "ui-id-7")]
        public IWebElement Details { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#divMailTo']")]
        public IWebElement MailTo { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#divReturnTo']")]
        public IWebElement ReturnTo { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/div/div/input[@title='Search GAB']")]
        public IWebElement SearchGAB { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/div/div/input[@title='Select Addresses']")]
        public IWebElement SelectAddresses { get; set; }

        [FindsBy(How = How.Id, Using = "_rdbtnCNRTMPackage")]
        public IWebElement RTMPakageRadio { get; set; }

        [FindsBy(How = How.Id, Using = "dynATable")]
        public IWebElement PakageTable { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div/span[text()='RTM Packages']/ancestor::div[2]//button/span[text()='Cancel']")]
        [FindsBy(How = How.XPath, Using = "//div[not (contains(@style, 'display: none;'))]/div/div/button/span[text()='Cancel']")]
        public IWebElement CancelRTMPackages { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSearchAddresses']/ancestor::div[1]//button/span[text()='Done']")]
        public IWebElement DoneSearchAddresses { get; set; }



        //div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons']"

        [FindsBy(How = How.XPath, Using = " //div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable ui-dialog-buttons']")]
        public IWebElement DivAddress { get; set; }



        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Done']")]
        public IWebElement OKbuCopyFile { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div/span[text()='RTM Packages']/ancestor::div[2]//button/span[text()='Done']")]
        [FindsBy(How = How.XPath, Using = "//div[(contains(@style, 'z-index: 1002;') or contains(@style, 'z-index: 1004;'))  and (not(contains(@style, 'display: none;')))]/div/div[@class='ui-dialog-buttonset']/button/span[text()='Done']")]
        public IWebElement DoneRTMPackages { get; set; }

        [FindsBy(How = How.Id, Using = "tblFBPAddresses")]
        public IWebElement FileBusinessPartyTable { get; set; }

        [FindsBy(How = How.Id, Using = "ddlretFileOffice")]
        public IWebElement OfficeSelection { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/span/span[@class='dynatree-expander'")]
        public IWebElement ExpandRTMTree { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/span/a[text()='RTM Packages']")]
        public IWebElement RTMPackageLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[1]/span/a[@class='dynatree-expander']")]
        public IWebElement AssoPackageLink { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[1]/ul/li/span/a[contains(@title, 'Package ID:')]")]
        public IWebElement FirstAssoMPackage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/ul/li/span/a[contains(@title, 'Package ID:')]")]
        public IWebElement FirstRTMPackage { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']/li[@class='Deliver separator']/a[@href='#Deliver']")]
        public IWebElement DeliverRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']/li[@class='Details']/a[@href='#Details']")]
        public IWebElement DetailsRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']//a[@href='#Print']")]
        public IWebElement PrintRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']//a[@href='#Fax']")]
        public IWebElement FaxRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']//a[@href='#EMail']")]
        public IWebElement EmailRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']//a[@href='#Preview']")]
        public IWebElement PreviewRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']//a[@href='#ImageDoc']")]
        public IWebElement ImageDocRTM { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='RTMsubMenu']//a[@href='#BULKMAIL']")]
        public IWebElement BULKMAILRTM { get; set; }


        //*** Added by Rishi
         [FindsBy(How = How.Id, Using = "txtRTM")]
        public IWebElement EditpackageName { get; set; }

         [FindsBy(How = How.Id, Using = "_rdbtnCNAPackage")]
         public IWebElement Asso_PakageRadio { get; set; }
         // 
         [FindsBy(How = How.Id, Using = "txtAssoc")]
         public IWebElement Assoc_EditpackageName { get; set; }

        [FindsBy(How = How.Id, Using = "txtTabName")]
        public IWebElement TabName{ get; set; }

        [FindsBy(How = How.Id, Using = "txtCopies")]
        public IWebElement Copies { get; set; }

        [FindsBy(How = How.Id, Using = "chkColor")]
        public IWebElement Colourchk { get; set; }

        [FindsBy(How = How.Id, Using = "package_link")]
        public IWebElement PackageLink { get; set; }

        [FindsBy(How = How.Id, Using = "rtmMenu")]
        public IWebElement RtmMenu { get; set; }

        [FindsBy(How = How.XPath, Using = "//li/a[text()='Create New Package']")]
        public IWebElement Rtm_Creatnewpackage { get; set; }

        [FindsBy(How = How.Id, Using = "editNode")]
        public IWebElement Rtm_EditName { get; set; }

        [FindsBy(How = How.Id, Using = "newName")]
        public IWebElement Rtm_AddressName { get; set; }

        [FindsBy(How = How.Id, Using = "newAddress1")]
        public IWebElement Rtm_Addressline1 { get; set; }

        [FindsBy(How = How.Id, Using = "newCity")]
        public IWebElement Rtm_AddressCity { get; set; }
        [FindsBy(How = How.Id, Using = "newddlState")]
        public IWebElement Rtm_AddressState { get; set; }

        [FindsBy(How = How.Id, Using = "newZipCode")]
        public IWebElement Rtm_AddressZip { get; set; }

        [FindsBy(How = How.Id, Using = "newPhone")]
        public IWebElement Rtm_AddressContactNo { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/ul/li[2]/span/a[contains(@class, 'dynatree-title')]")]
        public IWebElement RTMPackage2_node { get; set; }


        [FindsBy(How = How.XPath, Using = "//li/a[text()='Rename']")]
        public IWebElement Context_Rename { get; set; }


        [FindsBy(How = How.XPath, Using = "//div/ul/li[2]/ul/li[2]/span/span[contains(@class, 'dynatree-icon')]")]
        public IWebElement RTMpackageEDIT { get; set; }

        [FindsBy(How = How.Id, Using = "editNode")]
        public IWebElement RTMpackageEDIT_Box { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[1]/span")]
        //public IWebElement RTMPackageEle1 { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[2]/span")]
        //public IWebElement RTMPackageEle2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[1]/span/span[2]")]
        public IWebElement RTMPackage1_Doc1node { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='tree']//a/ancestor::ul/li[2]/ul/li/ul/li[2]/span/span[2]")]
        public IWebElement RTMPackage1_Doc2node { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='rtmMenu']/li[@class='addAddress']/a[text()='Add Addresses']")]
        public IWebElement AddAddresses { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonset']/button/span[text()='Close']")]
        public IWebElement CreateNewClose { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonset']/button/span[text()='Cancel']")]
        public IWebElement SelectAddressCancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonset']/button/span[text()='Done']")]
        public IWebElement SelectAddressDone { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSearchAddresses']/following-sibling::*/div[1]//button/span[text()='Done']")]
        public IWebElement RTMSelectAddressDone { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='rtmMenu']/li//a[@href='#createNP']")]
        public IWebElement CreateNewPackage_RTM { get; set; }

        #endregion

        #region DocGen Test
        //[FindsBy(How = How.Id, Using = "table_0")]
        //public IWebElement PhraseDataElementTable0 { get; set; }

        //[FindsBy(How = How.Id, Using = "table_1")]
        //public IWebElement PhraseDataElementTable1 { get; set; }

        //[FindsBy(How = How.Id, Using = "table_2")]
        //public IWebElement PhraseDataElementTable2 { get; set; }

        //[FindsBy(How = How.Id, Using = "table_3")]
        //public IWebElement PhraseDataElementTable3 { get; set; }

        //[FindsBy(How = How.Id, Using = "table_4")]
        //public IWebElement PhraseDataElementTable4 { get; set; }

        //[FindsBy(How = How.XPath, Using = "//li[@class='insert separator']/a[contains(text(),'Insert')]")]
        //public IWebElement Insert { get; set; }

        //[FindsBy(How = How.XPath, Using = "//li[@class='above']/a[contains(text(),'Above')]")]
        //public IWebElement Above { get; set; }

        //[FindsBy(How = How.XPath, Using = "//ul[@id='above']/li[@class='below separator']/a")]
        //public IWebElement Below { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aboveAddPhrase']/li[@class='aboveAddPhrase']/a")]
        public IWebElement AbovePhrase { get; set; }

        //[FindsBy(How = How.XPath, Using = "//li[@class='aboveSectionBreak separator']/a[contains(text(),'Section Break')]")]
        //public IWebElement AboveSectionBreak { get; set; }

        //Added By Subhankar-7/22/2016
        [FindsBy(How = How.XPath, Using = "//ul[@id='DEContextMenu']/li[@class='move separator']/a")]
        public IWebElement PhraseContextMove { get; set; }
        [FindsBy(How = How.XPath, Using = "//div/span[text()='Phrase Re-Sequence']/ancestor::div[2]//div[@id='viewPhrases']/table[@id='tblPhraseView']")]
        public IWebElement PhraseDesc { get; set; }
        [FindsBy(How = How.Id, Using = "pdv_1")]
        public IWebElement PhraseDescription1 { get; set; }
        [FindsBy(How = How.Id, Using = "pdv_2")]
        public IWebElement PhraseDescription2 { get; set; }
        [FindsBy(How = How.XPath, Using = "//ul[@id='DEContextMenu']/li[@class='delete separator']/a")]
        public IWebElement PhraseContextDelete { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonpane ui-widget-content ui-helper-clearfix']/button/span[text()='Done']")]
        public IWebElement DeleteDone { get; set; }
        [FindsBy(How = How.XPath, Using = "//ul//li/a[@href='#aboveMiscPhrase']")]
        public IWebElement AboveMiscPhrase { get; set; }



        [FindsBy(How = How.CssSelector, Using = "li.aboveSectionBreak")]
        public IWebElement AboveSectionBreakLi { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li.aboveAddPhrase")]
        public IWebElement AboveAddPhraseLi { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='aboveAddPhrase']/li/a[contains(text(),'Section Break')]")]
        public IWebElement SectionBreck { get; set; }

        //[FindsBy(How = How.XPath, Using = "//ul[@id='belowAddPhrase']/li[@class='belowSectionBreak separator']/a")]
        //public IWebElement BelowSectionBreak { get; set; }

        [FindsBy(How = How.XPath, Using = "//ul[@id='belowAddPhrase']/li[@class='belowAddPhrase']/a")]
        public IWebElement BelowPhrase { get; set; }

        //[FindsBy(How = How.XPath, Using = "//ul[@id='DEContextMenu']/li[@class='editSB separator']/a")]
        //public IWebElement EditSectionBreak { get; set; }

        //[FindsBy(How = How.XPath, Using = "//ul[@id='DEContextMenu']/li[@class='delete separator']/a")]
        //public IWebElement Delete { get; set; }


        [FindsBy(How = How.Id, Using = "tblDocDetails")]
        public IWebElement DetailsTable1 { get; set; }

        #endregion
   
        public NextGenDocumentRepository Open()
        {
            FastDriver.LeftNavigation.Navigate<NextGenDocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

            return this;
        }

        public NextGenDocumentRepository CreateDocumentFromTemplate(string templateDescription = "*", string documentName = "", string searchScope = "All Templates", string templateType = "All", string errorMessage = "", string effectiveDate = "", KeyValuePair<string, string>[] filters = null)
        {
            Reports.TestStep = "Create a document " + documentName;
            this.TemplateSearchButton.FADoubleClick();
            this.WaitForTemplateSearchTabToLoad();
            if (filters != null)
            {
                Reports.TestStep = "Set search filters";
                for (int i = 0; i < filters.Length; i++)
                {
                    var SelectFilter = this.GetFilterSelect(i + 1);
                    if (SelectFilter.IsEnabled())
                        SelectFilter.FASelectItem(filters[i].Key);

                    var InputFilter = this.GetFilterValue(i + 1);
                    if (InputFilter.GetCssValue("overflow").Contains("hidden") == false)
                        InputFilter.FASetText(filters[i].Value, continueOnFailure: true);
                }
            }
            this.SearchScope.FASelectItem(searchScope);
            if (filters != null)
            {
                Reports.TestStep = "Verify search filters";
                for (int i = 0; i < filters.Length; i++)
                {
                    Support.AreEqual(filters[i].Key, this.GetFilterSelect(i + 1).FAGetSelectedItem());
                    Support.AreEqual(filters[i].Value, this.GetFilterValue(i + 1).FAGetText());
                }
            }
            this.TemplateTypeSelect.FASelectItem(templateType);
            if (filters == null)
            {
                if (this.GetFilterValue(2).Exists())
                    this.GetFilterValue(2).FAClickAction();

                var checkbox = this.WebDriver.FindElement(By.Id("ddcl-ddl_states-i0"));
                if(checkbox.IsDisplayed())
                    checkbox.FAClick();
                
            }
            this.TemplateDescription.FASetText(templateDescription);
            this.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Reports.TestStep = "Select the Document , Right-Click and select \"Create\" option from the context";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            if (string.IsNullOrEmpty(effectiveDate) == false)
            {
                Reports.TestStep = "Modify effective date";
                this.WaitForTemplateSearchTabToLoad();
                this.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FAClickAction();
                this.DocumentInfoTab.FAClickAction();
                this.WaitForScreenToLoad(this.DocInfo_EffectiveDate);
                this.DocInfo_EffectiveDate.FASetText(effectiveDate);
                this.DocInfo_CreateSave.FAClick();
            }
            else
            {
                this.WaitForTemplateSearchTabToLoad();
                this.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FARightClick();
                this.CreateDocument.FASelectContextMenuItem();
            }

            if (string.IsNullOrEmpty(errorMessage) == false)
            {
                string message = FastDriver.WebDriver.HandleDialogMessage();
                Support.AreEqual(errorMessage, message);

                return this;
            }

            if (this.TitlePolicyDetailsTable.Exists(5))
            {
                Reports.TestStep = "Select any policy document name from the list and click on \"Done\" button";
                this.TitlePolicyDetailsTable.Exists(5);
                this.TitlePolicyDetailsTable.PerformTableAction(1, 1, TableAction.Click);
                this.TitlePolicyDetails_Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
            }

            if (string.IsNullOrEmpty(documentName) == false)
            {
                Reports.TestStep = "Rename document";
                this.WaitForScreenToLoad();
                this.DocumentsTable.PerformTableAction("Name", templateDescription, "Name", TableAction.GetCell).Element.FARightClick();
                this.EditDocumentName.FASelectContextMenuItem();

                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                this.WaitForScreenToLoad();
                this.EditDocument_DocumentName.FASetText(documentName);
                this.EditDocument_Done.FAClick();
            }
            else
            {
                documentName = templateDescription;
            }

            Reports.TestStep = "Verify document creation"; // TODO: search actual Description column
            this.WaitForScreenToLoad();
            var docs = this.DocumentsTable.GetAttribute("textContent");
            Support.AreEqual("True", docs.Contains(documentName).ToString(), "Document Table contains doc named: " + documentName);

            return this;
        }

        public NextGenDocumentRepository CreateEditDocumentFromTemplate(string templateDescription = "*", string documentName = "", string searchScope = "All Templates", string templateType = "All", string errorMessage = "", string effectiveDate = "", KeyValuePair<string, string>[] filters = null)
        {
            Reports.TestStep = "Create a document " + documentName;
            this.TemplateSearchButton.FADoubleClick();
            this.WaitForTemplateSearchTabToLoad();
            if (filters != null)
            {
                Reports.TestStep = "Set search filters";
                for (int i = 0; i < filters.Length; i++)
                {
                    var SelectFilter = this.GetFilterSelect(i + 1);
                    if (SelectFilter.IsEnabled())
                        SelectFilter.FASelectItem(filters[i].Key);

                    var InputFilter = this.GetFilterValue(i + 1);
                    if (InputFilter.GetCssValue("overflow").Contains("hidden") == false)
                        InputFilter.FASetText(filters[i].Value);
                }
            }
            this.SearchScope.FASelectItem(searchScope);
            if (filters != null)
            {
                Reports.TestStep = "Verify search filters";
                for (int i = 0; i < filters.Length; i++)
                {
                    Support.AreEqual(filters[i].Key, this.GetFilterSelect(i + 1).FAGetSelectedItem());
                    Support.AreEqual(filters[i].Value, this.GetFilterValue(i + 1).FAGetText());
                }
            }
            this.TemplateTypeSelect.FASelectItem(templateType);
            if (filters == null)
            {
                this.GetFilterValue(2).FAClickAction();
                this.WebDriver.FindElement(By.Id("ddcl-ddl_states-i0")).FADoubleClick();
            }
            this.TemplateDescription.FASetText(templateDescription);
            this.Search.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

            Reports.TestStep = "Select the Document , Right-Click and select \"CreateEdit\" option from the context";
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
            if (string.IsNullOrEmpty(effectiveDate) == false)
            {
                Reports.TestStep = "Modify effective date";
                this.WaitForTemplateSearchTabToLoad();
                this.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FAClickAction();
                this.DocumentInfoTab.FAClickAction();
                this.WaitForScreenToLoad(this.DocInfo_EffectiveDate);
                this.DocInfo_EffectiveDate.FASetText(effectiveDate);
                this.DocInfo_CreateSave.FAClick();
            }
            else
            {
                this.WaitForTemplateSearchTabToLoad();
                this.TemplatesTable.PerformTableAction("Description", templateDescription, "Description", TableAction.GetCell).Element.FARightClick();
                this.CreateEditDocument.FASelectContextMenuItem();
            }


            return this;
        }

        //Added by Rashmi
        public NextGenDocumentRepository UploadAllTypesofFiles()
        {
            string filePath;
            Reports.TestStep = "Uploading different types of Files.";
            List<string> FileType = new List<string>();
            FileType.Add("PDF File");
            FileType.Add("Word File");
            FileType.Add("Excel File");
            FileType.Add("Tiff File");
            FileType.Add("JPEG File");


            foreach (string pair in FileType)
            {

                Open();
                #region Click on Upload button
                Reports.TestStep = "Click on Upload button";
                FastDriver.NextGenDocumentRepository.Upload.FAClick();
                #endregion

                #region Browse document
                Reports.TestStep = "Browse document";

                if (pair == "PDF File")
                {
                    filePath = Reports.DEPLOYDIR + @"\PDFSigQFormalRep.pdf";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);


                    #region Save the File
                    Reports.TestStep = "Save the File";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save File", true, 20);
                    FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "PDF File");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion




                }
                else if (pair == "Word File")
                {
                    filePath = Reports.DEPLOYDIR + @"\DPUC0005_Maintain_Phrase.doc";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    #region Save the File
                    Reports.TestStep = "Save the File";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save File", true, 20);
                    FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "Word File");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion

                }
                else if (pair == "Excel File")
                {
                    filePath = Reports.DEPLOYDIR + @"\NexGen_Report.xlsx";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    #region Save the File
                    Reports.TestStep = "Save the File";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save File", true, 20);
                    FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "Excel File");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion
                }
                else if (pair == "Tiff File")
                {
                    filePath = Reports.DEPLOYDIR + @"\TiFF1.tif";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    #region Save the File
                    Reports.TestStep = "Save the File";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save File", true, 20);
                    FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "Tiff File");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion
                }
                else if (pair == "JPEG File")
                {
                    filePath = Reports.DEPLOYDIR + @"\imagesJPG.jpg";
                    FastDriver.UploadDocumentDlg.UploadFile(filePath);

                    #region Save the File
                    Reports.TestStep = "Save the File";
                    FastDriver.WebDriver.WaitForWindowAndSwitch("Save File", true, 20);
                    FastDriver.SaveDocumentDlg.SaveDocument(@"Escrow: Payoff Demand/Bills", "Miscellaneous", "JPEG File");
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    #endregion
                }

                #endregion




                #region Navigate to Document Repository Screen
                Reports.TestStep = "Navigate to Document Repository Screen";
                FastDriver.NextGenDocumentRepository.Open();
                #endregion
            }
            
            return this;

        }

        public NextGenDocumentRepository REG0031_Filter()
        {

              string TypeFilterenable, typetooltip, valText, strType;
                int row_Count, innerRowCount;
                List<string> eleText = new List<string>();

           #region Hold Right Click
                    Reports.TestStep = "Hold Right Click and click on 'PhraseView/Edit' option from context";

                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[9].Highlight();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[9].FARightClick();

                    Reports.TestStep = "Click on Phrase/view Edit";
                    FastDriver.NextGenDocumentRepository.PhraseViewEdit.FASelectContextMenuItem();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.NextGenDocumentRepository.PhraseViewTab.FAClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    #endregion
                    #region Edit value of any data element and click on "Save" and "Done Button
                    Reports.TestStep = "Edit value of any data element and click on \"Save\" and \"Done\" Button";
                    var dataElement = FastDriver.NextGenDocumentRepository.DataElement("Buyer Name(s)");
                    var editedBuyerFirstName = "Edited-Buyer-First-Name";
                    dataElement["Input"].FASetText(editedBuyerFirstName);
                    FastDriver.NextGenDocumentRepository.SaveDocumentDataElements.FAClick();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    Reports.TestStep = "Click Done";
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    FastDriver.NextGenDocumentRepository.DocInfo_Done.FADoubleClick();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    #endregion


                    #region Select "Finalized" option from the dropdown
                    Reports.TestStep = "Select \"Finalized\" option from the Status dropdown";
                    FastDriver.NextGenDocumentRepository.Open();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[10].Highlight();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[10].FADoubleClick();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("TR"))[2].FindElements(By.TagName("TD"))[10].FAFindElement(ByLocator.Id, "item.DocStatusCD").FASelectItem("Finalized");

                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    #endregion

                    #region  Navigate to Document Repository Screen
                    Reports.TestStep = "Navigate to Document Repository Screen";
                    FastDriver.NextGenDocumentRepository.Open();
                    #endregion

                    #region Take a rowcount od Documents Table
                    innerRowCount = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;
                    

                    #endregion

                    #region Verify Type Filter in Documents Table
                    Reports.TestStep = "Verify Type Filter in Documents Table";
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.TagName("img")).FADoubleClick();                 

                    int Typerow_Count = 0;
                    Typerow_Count = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr")).Count - 1;


                    for (int i = 0; i < Typerow_Count; i++)
                    {

                        FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].FASetCheckbox(true);
                        bool chkStatus = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].Selected;
                        string caseSwitch = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FAGetText();


                        if (chkStatus == true)
                        {
                            #region Fast Docs Filter
                            if (caseSwitch == "Fast Docs")
                            {
                                Reports.TestStep = "Filter \"Fast File Documents\" in Document Table";

                                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("INPUT"))[i]);

                             //  IWebElement tableFastDocs = FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("tblFASTDocs"));


                                foreach (IWebElement ele in FastDriver.NextGenDocumentRepository.tableFastDocs.FindElements(By.TagName("tr")))                                
                                {

                                    bool chkStatusFastDoc = ele.FindElement(By.TagName("INPUT")).Selected;                                   

                                    if (ele.FindElement(By.TagName("INPUT")).Selected)
                                    {
                                        valText = ele.FindElement(By.TagName("td")).Text;

                                        eleText.Add(valText);

                                    }

                                    else
                                    {
                                        valText = ele.FindElement(By.TagName("td")).Text;

                                        eleText.Add(valText);

                                    }

                                }

                                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                                FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FAClick();
                               
                                int Docrow_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;
                                if (Docrow_Count > 1)
                                {

                                    for (int j = 1; j < Docrow_Count; j++)
                                    {
                                        string strFastDocType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR"))[j].FindElements(By.TagName("TD"))[8].FAGetText();

                                        if (eleText.Contains(strFastDocType))
                                        {

                                            Support.AreEqual("True", "True", "Document " + strFastDocType + " Filtered in the Document Table.");

                                        }
                                    }
                                }

                            }
                            #endregion

                            #region Images Filter
                            else if (caseSwitch == "Images")
                            {

                                Reports.TestStep = "Filter \"Image Type Documents\" in Document Table";
                                eleText.Clear();
                                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("INPUT"))[i]);
                               // IWebElement tableImages = FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("tblImageContainer"));

                                foreach (IWebElement ele in FastDriver.NextGenDocumentRepository.tableImages.FindElements(By.TagName("tr")))
                                {
                                    bool chkStatusFastDoc = ele.FindElement(By.TagName("INPUT")).Selected;
                                    if (ele.FindElement(By.TagName("INPUT")).Selected)
                                    {
                                        valText = ele.FindElement(By.TagName("td")).Text;
                                        eleText.Add(valText);
                                    }

                                    else
                                    {
                                        eleText.Clear();
                                        valText = ele.FindElement(By.TagName("td")).Text;
                                        eleText.Add(valText);

                                    }

                                }

                                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                                FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FADoubleClick();
                                int Docrow_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;
                                if (Docrow_Count > 1)
                                {
                                    for (int j = 1; j < Docrow_Count; j++)
                                    {
                                        string strImageType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR"))[j].FindElements(By.TagName("TD"))[8].FAGetText();

                                        if (eleText.Contains(strImageType))
                                        {
                                            Support.AreEqual("True", "True", "Document " + strImageType + " Filtered in the Document Table.");
                                        }

                                    }
                                }

                            }
                            #endregion

                            #region Filter All
                            else if (caseSwitch == "All")
                            {

                                Reports.TestStep = "Filter \"All Type\" in Document Table";
                                string RmvItem = FastDriver.NextGenDocumentRepository.WebDriver.FindElement(By.Id("cbx_4.41")).IsSelected().ToString();
                                Support.AreEqual("False", RmvItem, "Remove Items is Unselected.");


                                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                                FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FAClick();


                                row_Count = 0;

                                row_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;
                                if (row_Count > 1)
                                {
                                    if (row_Count == innerRowCount)
                                    {
                                        Support.AreEqual("True", "True", "All Documents Filtered in the Document Table.");
                                    }
                                }

                                Reports.TestStep = "Verify if Type Filter Enabled.";
                                TypeFilterenable = FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).Enabled.ToString();
                                Support.AreEqual("True", TypeFilterenable, "Type Filter Enabled");
                                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();

                                typetooltip = FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).FAGetAttribute("Title");
                                Support.AreEqual("Filter set by : FAST QA07", typetooltip, "Type filter set by Automation User at order level");


                            }

                            else
                            {
                                Reports.TestStep = "Filter" + caseSwitch + "Type in Document Table";
                                MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                                FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FAClick();

                                int Docrow_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;

                                if (Docrow_Count > 1)
                                {
                                    Support.AreEqual("True", "True", "'" + Docrow_Count.ToString() + " Documents with " + caseSwitch + " Type are Filtered in the Document Table." + "'");
                                }
                                else 
                                
                                { Support.AreEqual("True", "True", " Documents with " + caseSwitch + " Type are not found in the Document Table." + "'"); }

                            }
                            #endregion

                        }

                        #region Verify Type Filter Enabled.                       
                        Reports.TestStep = "Verify Clear Filter after filter enabled";
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).FADoubleClick();

                        MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")));
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")).FAClick();

                        string ImgFilterenable = FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.TagName("img")).Enabled.ToString();
                        Support.AreEqual("True", ImgFilterenable, "Type Filter is cleared after clear filter and Image filter is enabled");
                        #endregion

                        FastDriver.NextGenDocumentRepository.Open();
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.TagName("img")).FADoubleClick();

                    }                   

                    #endregion

                    #region Verify Second Filter icon in the search Results Grid

                    FastDriver.NextGenDocumentRepository.Open();
                    FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                    Reports.TestStep = "Verify Second Filter icon in the search Results Grid";
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[2].FindElement(By.TagName("img")).FADoubleClick();

                    Typerow_Count = 0;
                    Typerow_Count = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr")).Count - 1;


                    for (int i = 0; i < Typerow_Count; i++)
                    {

                        FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].FASetCheckbox(true);
                        bool chkStatus = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].Selected;
                        string caseSwitch = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FAGetText();
                        MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FADoubleClick();
                        strType = "";
                        strType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[6].FAGetText();
                        if (chkStatus == true)
                        {

                            int rc = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR")).Count;

                            if (rc > 1)
                            {


                                #region Filter PDF, Tiff File Formats

                                if (strType.Contains(caseSwitch))
                                {
                                    Reports.TestStep = "Filter " + strType + " File Type Document in Documents table";
                                    int Docrow_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;

                                    if (Docrow_Count > 1)
                                    {
                                        Support.AreEqual("True", "True", "'" + Docrow_Count.ToString() + " Documents with " + strType + " File type are Filtered in the Document Table." + "'");
                                    }
                                   
                                }
                                #endregion
                                #region Filter Other File Formats
                                else if (caseSwitch == "Other File Formats")
                                {

                                    Reports.TestStep = "Filter Other File Formats in Documents table";
                                    int Docrow_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;

                                    if (Docrow_Count > 1)
                                    {
                                        for (int j = 1; j < Docrow_Count; j++)
                                        {
                                            strType = "";
                                            strType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR"))[j].FindElements(By.TagName("TD"))[6].FAGetText();

                                            if (strType.Contains("Other"))
                                            {
                                                Support.AreEqual("True", "True", "Document " + strType + " Filtered in the Document Table.");
                                            }

                                        }
                                    }

                                }
                                #endregion
                                #region Filter All File Formats
                                else
                                {

                                    Reports.TestStep = "Filter All format in Documents table";
                                    row_Count = 0;
                                    row_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;

                                    if (row_Count > 1)
                                    {
                                        if (row_Count == innerRowCount)
                                        {
                                            Support.AreEqual("True", "True", "All Documents Filtered in the Document Table.");
                                        }
                                    }

                                }
                                #endregion

                            }
                            else

                            { Support.AreEqual("True", "True", " Documents with " + strType + " File type are not found in the Document Table." + "'"); }

                        }

                        Reports.TestStep = "Verify Clear Filter after filter enabled";

                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[2].FindElement(By.Id("afterFilterImage")).FADoubleClick();

                        FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].FASetCheckbox(false);
                        MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FADoubleClick();
                        FastDriver.NextGenDocumentRepository.Open();
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[2].FindElement(By.TagName("img")).FADoubleClick();

                    }

                    #endregion

                    #region Verify Status Filter in Documents Table
                    Reports.TestStep = "Verify Status Filter in Documents Table";
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[2].FindElement(By.Id("afterFilterImage")).FADoubleClick();

                    MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")));
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")).FADoubleClick();
                    FastDriver.NextGenDocumentRepository.Open();
                    FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[9].FindElement(By.TagName("img")).FADoubleClick();

                    Typerow_Count = 0;
                    Typerow_Count = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr")).Count - 1;


                    for (int i = 0; i < Typerow_Count; i++)
                    {

                        FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].FASetCheckbox(true);
                        bool chkStatus = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FindElements(By.XPath("//input[@type='checkbox']"))[i].Selected;
                        string caseSwitch = FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[i].FAGetText();
                        MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")));
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='OK']")).FAClick();

                        if (chkStatus == true)
                        {
                            FastDriver.NextGenDocumentRepository.Open();
                            int rc = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR")).Count;
                           
                            if (rc > 1)
                            {
                                strType = "";
                                strType = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("TR"))[1].FindElements(By.TagName("TD"))[9].FAGetText();
                               


                                #region Filter Different Status types
                                if (strType.Contains(caseSwitch))
                                {
                                    Reports.TestStep = "Filter " + strType + " Status Type Document in Documents table";
                                    int Docrow_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;

                                    Support.AreEqual("True", "True", "'" + Docrow_Count.ToString() + " Documents with " + strType + " Stauts are Filtered in the Document Table." + "'");

                                }
                                #endregion
                                #region Filter All Status types
                                else
                                {
                                    Reports.TestStep = "Filter All Status Type Document in Documents table";
                                    row_Count = 0;
                                    row_Count = FastDriver.NextGenDocumentRepository.DocumentsInnerTable.FindElements(By.TagName("tr")).Count;
                                    if (row_Count == innerRowCount)
                                    {
                                        Support.AreEqual("True", "True", "All Documents Filtered in the Document Table.");
                                    }
                                }
                                #endregion
                            }
                            else

                            { Support.AreEqual("True", "True", " Documents with " + caseSwitch + " status are not found in the Document Table." + "'"); }

                        }


                        Reports.TestStep = "Verify Clear Filter after filter enabled";
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[9].FindElement(By.Id("afterFilterImage")).FADoubleClick();

                        MouseHoverOnObject(FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")));
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElement(By.XPath("//input[@value='Clear Filter']")).FAClick();
                        FastDriver.NextGenDocumentRepository.Open();
                        FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[9].FindElement(By.TagName("img")).FADoubleClick();


                    }

                    #endregion

                    return this;
        }

        //Added by Luz
        public bool DocumentsTableTemplateExist(string TempName)
        {
            var phrasesAmount = DocumentsTable.GetRowCount();
            for (int i = 1; i <= phrasesAmount; i++)
            {
                if (DocumentsTable.PerformTableAction(i, 1, TableAction.GetText).Message.Contains(TempName))
                {
                    return true;
                }

            }

            throw new NoSuchElementException("Could not find Template " + TempName);
        }
        
        public void DeliveriesNGDocRep(String delivermethod)
        {
            FastDriver.WebDriver.FindElement(By.LinkText("Deliver")).FAMoveToElement();
            Mouse.Move(new System.Drawing.Point(0, 0));
            Playback.Wait(3000);
            FastDriver.WebDriver.FindElement(By.LinkText(delivermethod)).FASelectContextMenuItem();
        }
        //

        //Indranil Start

        public void ClearStatusFilter()
        {
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[9].FindElement(By.Id("afterFilterImage")).FAClick();

            FastDriver.NextGenDocumentRepository.StatusFilterClear.FAClick();
        }

        public void LinkTemplateToDocuments(int DocSeqNo)
        {

            Playback.Wait(2000);
            FastDriver.NextGenDocumentRepository.LinkTemplatePopupDiv.FindElement(By.TagName("TABLE")).FindElements(By.TagName("TR"))[DocSeqNo].FAClick();
            Playback.Wait(2000);

        }

        public void FilterTitleReport()
        {
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.TypeFilter.FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[1].FAMouseOver();
            FastDriver.NextGenDocumentRepository.TitleReportFilter.FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[7].FindElements(By.TagName("td"))[0].FindElement(By.TagName("INPUT")).FAClick();
            Playback.Wait(2000);

        }

        public void FilterPolicyDoc()
        {
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.TypeFilter.FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[1].FAMouseOver();
            FastDriver.NextGenDocumentRepository.LenderPolicyFilter.FAClick();
            FastDriver.NextGenDocumentRepository.OwnerPolicyFilter.FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[7].FindElements(By.TagName("td"))[0].FindElement(By.TagName("INPUT")).FAClick();
            Playback.Wait(2000);

        }

        public void FilterImageDoc()
        {
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.TypeFilter.FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[2].FAMouseOver();
            FastDriver.NextGenDocumentRepository.EscrowPDBFilter.FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[7].FindElements(By.TagName("td"))[0].FindElement(By.TagName("INPUT")).FAClick();
            Playback.Wait(2000);

        }

        public void ClearTypeFilter()
        {
            FastDriver.NextGenDocumentRepository.Open();
            FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
            FastDriver.NextGenDocumentRepository.DocumentsTable.FindElements(By.TagName("tr"))[0].FindElements(By.TagName("th"))[8].FindElement(By.Id("afterFilterImage")).FAClick();
            FastDriver.NextGenDocumentRepository.TypeFilterParentTable.FindElements(By.TagName("tr"))[7].FindElements(By.TagName("td"))[1].FindElement(By.TagName("INPUT")).FAClick();
            Playback.Wait(2000);
        }
        
        // Indranil End

        public void AddPhraseBelowInPhraseView()
        {
            FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2].Highlight();

            FastDriver.NextGenDocumentRepository.ContextMenu1.FindElements(By.TagName("A"))[2].FAMouseOver();
            FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")).Highlight();

            FastDriver.NextGenDocumentRepository.ContextMenu2.FindElement(By.LinkText("Below")).FAMouseOver();


            FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0].Highlight();
            FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0].FAMouseOver();
            FastDriver.NextGenDocumentRepository.ContextMenu4.FindElements(By.TagName("A"))[0].JSClick();
        }
        
        #region Services

        public void SelectDeletefromContextMenu()
        {
            FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).Highlight();
            FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).FAMouseOver();
            FastDriver.NextGenDocumentRepository.ContextMenu1.FindElement(By.LinkText("Delete")).JSClick();
        }

        public void mouseHover(IWebElement menu, IWebElement menuOption)
        {
            Actions action = new Actions(FastDriver.WebDriver);
            action.MoveToElement(menu).Perform();
            action.MoveToElement(menuOption).Perform();

        }

        public void FAHoverByID(string elementID)
        {
            Actions Action = new Actions(FastDriver.WebDriver);
            IWebElement WebElement = FastDriver.WebDriver.FindElement(By.CssSelector("#" + elementID));
            Action.MoveToElement(WebElement).Perform();
        }      
      
        public NextGenDocumentRepository CreateAllTypesofDocs()
        {
            Reports.TestStep = "Creating File Documents of different types";
            List<string> TempType = new List<string>();
            TempType.Add("Endorsement/Guarantee");
            TempType.Add("Title Reports");
            TempType.Add("Owner Policy");
           // TempType.Add("Lender Policy");
            TempType.Add("Escrow Instruction");
            //TempType.Add("Exchange Miscellaneous");
            //TempType.Add("Exchange Delayed");
            //TempType.Add("Escrow Ltr/Transmittal");
            //TempType.Add("Misc Escrow Document");
            //TempType.Add("Policy w/o Title Reports");
            //TempType.Add("Legal Size Paper");
            //TempType.Add("Legal/Recordable Doc");
            //TempType.Add("Gen'd Data Element");
            //TempType.Add("Guarantee");
            //TempType.Add("Misc Title Document");
            //TempType.Add("Title Ltr/Transmittal");
            //TempType.Add("Form");

            foreach (string pair in TempType)
            {
                Open();
                TemplateSearchButton.FAClick();
                WaitForTemplateSearchTabToLoad();
                WaitForScreenToLoad(SearchScope);
                SearchScope.FASelectItem("All Templates");
                TemplateTypeSelect.FASelectItem(pair);
                StateValue_CA.FAClick();
                StateValue_All.FAClick();
                Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Please Wait...", false, 100);

                WaitForTemplateSearchTabToLoad();
                List<IWebElement> temps = new List<IWebElement>();
                temps = TemplatesTable.FindElements(By.XPath(".//tr")).Where(row => row.Displayed).ToList();
                if (temps.Count >= 4)
                {
                    TemplatesTable.PerformTableAction(1, 4, TableAction.Click).Element.FARightClick();
                    CreateDocument.FASelectContextMenuItem();
                    WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("Templates not present, continue with next template type", false);
                    continue;
                }
               
            }
            return this;
                       
        }              

        //private void InsertPhrase(string tplPhraseName, string phraseDescription)
        //{
        //    if (FastDriver.DocumentEditor.IRInsertPhrase3.DelayOnce(60).Visible())
        //    {
        //        FastDriver.DocumentEditor.IRInsertPhrase3.ContextClick();
        //        FastDriver.DocumentEditor.IRInsertPhraseBottom3.FAClick();
        //        FastDriver.DocumentEditor.IRInsertSearch1st3.DoubleClick();
        //    }
        //    else if (FastDriver.DocumentEditor.IRInsertPhrase2.Visible())
        //    {
        //        FastDriver.DocumentEditor.IRInsertPhrase2.ContextClick();
        //        FastDriver.DocumentEditor.IRInsertPhraseBottom2.FAClick();
        //        FastDriver.DocumentEditor.IRInsertSearch4.DoubleClick();
        //    }
        //    else
        //    {
        //        Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
        //    }
        //    //
        //    Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
        //    FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
        //    //
        //    Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
        //    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
        //    FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
        //    FastDriver.PhraseSelectDlg.Search.FAClick();
        //    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
        //    FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
        //    FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
        //    FastDriver.DialogBottomFrame.ClickDone();
        //    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
        //    FastDriver.DocumentEditor.WaitForScreenToLoad();
        //    if (FastDriver.DocumentEditor.IRSave2.DelayOnce(6).Visible())
        //        FastDriver.DocumentEditor.IRSave2.FAClick();
        //    else if (FastDriver.DocumentEditor.IRSave3.Visible())
        //        FastDriver.DocumentEditor.IRSave3.FAClick();
        //    else
        //        Support.Fail("'Save Button' was not found by ImageRecognition");
        //    FastDriver.DocumentEditor.WaitForScreenToLoad();
        //    FastDriver.DocumentEditor.Close.FAClick();
        //    FastDriver.DocumentEditor.WaitCreation(FastDriver.DocumentEditor.Yes);
        //    FastDriver.DocumentEditor.Yes.FAClick();
        //    Playback.Wait(6000);
        //}          

        private void InsertPhrase(string tplPhraseName, string phraseDescription)
        {
            try
            {

                //  if (FastDriver.DocumentEditor.IRDocumentCurrentLine6.DelayOnce(20).Visible())


                //if (FastDriver.DocumentEditor.IRInsertPhrase7.DelayOnce(20).Visible())

                if (FastDriver.DocumentEditor.IRInsertPhrase.DelayOnce(20).Offset(220, 190).Visible())

                //if (FastDriver.DocumentEditor.IRInsertPhrase3.DelayOnce(60).Visible())
                // if (FastDriver.DocumentEditor.IRInsertPhrase2.DelayOnce(60).Offset(1850 - 320, 50).Visible())     // 1600 * 1200
                {
                    //FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 190).ContextClick();
                    //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 230).FAClick();
                    //FastDriver.DocumentEditor.IRInsertSearch1st.Offset(568, 238).DoubleClick();

                    FastDriver.DocumentEditor.IRDocumentCurrentLine6.DelayOnce(20).ContextClick();
                    FastDriver.DocumentEditor.DefaultSectionBreak1.DelayOnce(60).FAClick();
                    FastDriver.DocumentEditor.DefaultSectionBreak2.DelayOnce(60).Highlight(5);


                    FastDriver.DocumentEditor.DefaultSectionBreak2.DelayOnce(60).FAClick();


                    // FastDriver.DocumentEditor.IR_CM_InsertDataElement3.DelayOnce(20).FAClick();
                    FastDriver.DocumentEditor.IRInsertSearch5.DoubleClick();
                    Keyboard.SendKeys(FAKeys.Enter);


                    //FastDriver.DocumentEditor.IRInsertPhrase3.Offset(220, 130).ContextClick();
                    //FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(300, 50).FAClick();
                    //FastDriver.DocumentEditor.IRInsertSearch1st.Offset(568, 238).DoubleClick();




                }

                else if (FastDriver.DocumentEditor.IRInsertPhrase9.Visible())

                // else if (FastDriver.DocumentEditor.IRInsertPhrase6.Visible())
                {
                    FastDriver.DocumentEditor.IRInsertPhrase.Offset(220, 190 + 720).ContextClick();
                    FastDriver.DocumentEditor.IRInsertPhraseBottom.Offset(240, 230 + 680).FAClick();
                    FastDriver.DocumentEditor.IRInsertSearch.Offset(560, 732).DoubleClick();
                }
                else
                {
                    Support.Fail("'Insert Phrase/Search' was not found by ImageRecognition");
                }
                //
                Reports.TestStep = "Enter phrase code and hit enter to insert phrase (or) Click Search Button \"…\" for inserting phrase";
                FastDriver.WebDriver.WaitForWindowAndSwitch("Phrase Selection", true, 20);
                //
                Reports.TestStep = "Select a phrase from the phrase search dialog and click on done button";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.Description.FASetText(phraseDescription);
                FastDriver.PhraseSelectDlg.Search.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, tplPhraseName, 1, TableAction.Click);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                if (FastDriver.DocumentEditor.IRSave.DelayOnce(6).Offset(1800, 50).Visible())
                    FastDriver.DocumentEditor.IRSave.Offset(1800, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1570, 50).Visible())
                    FastDriver.DocumentEditor.IRSave.Offset(1570, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).Visible())     // 1600 * 1200
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 320, 50).FAClick();
                else if (FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).Visible())     // 1280 * 1024
                    FastDriver.DocumentEditor.IRSave.Offset(1850 - 640, 50).FAClick();
                else
                    Support.Fail("'Save Button' was not found by ImageRecognition");
                FastDriver.DocumentEditor.WaitForScreenToLoad();
                FastDriver.DocumentEditor.Close.FAClick();
                FastDriver.DocumentEditor.WaitCreation(FastDriver.DocumentEditor.Yes);
                FastDriver.DocumentEditor.Yes.FAClick();
                Playback.Wait(6000);
            }
            catch (Exception ex)
            {
                MasterTestClass.FailTest(MasterTestClass.GetExceptionInfo(ex));
            }
        }
          
        public NextGenDocumentRepository AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false, bool clickAccept = true)
        {
            string alertText = "";
            try
            {
                WebDriver.WaitForAlertToExist(5);
                var alert = WebDriver.SwitchTo().Alert();
                alertText = alert.Text;
                if (clickAccept)
                    alert.Accept();
                else
                    alert.Dismiss();
                if (SwitchToWindow)
                    WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            }
            catch (Exception)
            {
                alertText = "No Alert was Found";
            }
            finally
            {
                if (CompareWith != null)
                {
                    SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
                }

            }
            return this;
        }
        
        public NextGenDocumentRepository ValidateDEResolvedvalues()
        {
            List<IWebElement> l2 = DataElementTable.FindElements(By.XPath("//input[@name='txtDEValue']")).ToList();

            Support.AreEqual("True", l2[0].FAGetText().Contains("").ToString());
            Support.AreEqual("True", l2[1].FAGetText().Contains("").ToString());
            Support.AreEqual("True", l2[2].FAGetText().Contains("").ToString());

            return this;
        }

        public NextGenDocumentRepository ValidateDataElementsinDEscreen()
        {
            List<IWebElement> l2 = DataElementTable.FindElements(By.XPath("//div[@id='mainDiv']/table[@id='PhraseDataElementGridResult']/tbody/tr/td/div/table/tbody/tr/td/label")).ToList();

            Support.AreEqual("True", l2[0].FAGetText().Contains("Buyer Employed By Name").ToString());
            Support.AreEqual("True", l2[1].FAGetText().Contains("File No Prefix").ToString());
            Support.AreEqual("True", l2[2].FAGetText().Contains("Buyer Contact: Name").ToString());

            return this;
        }

        public NextGenDocumentRepository ValidatePhrasesinDEscreen()
        {
            List<IWebElement> l2 = DataElementTable.FindElements(By.XPath("//div[@class='parentDiv']/table/tbody/tr/td[@id='phraseNameDesc']")).ToList();

            Support.AreEqual("True", l2[0].FAGetText().Contains("Phrase Marker").ToString());
            Support.AreEqual("True", l2[1].FAGetText().Contains("ALB8/ALB8").ToString());
            Support.AreEqual("True", l2[2].FAGetText().Contains("ENC2/249").ToString());

            return this;
        }
        
        public IDictionary<string, IWebElement> DataElement(string dataElementName)
        {
            Dictionary<string, IWebElement> dataElement = new Dictionary<string, IWebElement>();
            try
            {   // if data Element is not found, the first line will throw NoSuchElementException
                var element = WebDriver.FindElement(By.XPath("//table[@id='Table']//td/label[text()='" + dataElementName + "']/ancestor::tr[1]"));
                dataElement.Add("Row", element);
                //dataElement.Add("DocphraseElementId", element.FindElement(By.XPath("./td[@id='DocphraseElement_ID']")));
                //dataElement.Add("Image", element.FindElement(By.XPath("./td[1]")));   // need to find other way to identify
                dataElement.Add("Label", element.FindElement(By.XPath("./td/label")));
                dataElement.Add("Input", element.FindElement(By.XPath("./td/input")));  //[@name='txtDEValue']

               // dataElement.Add("Input", element.FindElement(By.XPath("./td/textarea")));  //[@name='txtDEValue']
                dataElement.Add("Refresh", element.FindElement(By.XPath("./td/span/img[@title='Refresh Data Element']"))); 
            }
            catch (NoSuchElementException)
            {
                //report element not found?
            }
            return dataElement;
        }

        // this method works ONLY if there is only one of each type of document on the table
        // TODO: make this method works for all scenarios
        public bool WaitForDocument(string documentName, string documentType = "", int timeout = 180, bool toExist = true)
        {
            var watch = Stopwatch.StartNew();
            while (watch.ElapsedMilliseconds <= timeout * 1000)
            {
                this.Open();
                //
                if (this.DocumentsTable.Exists())
                {
                    var table = this.DocumentsTable.GetAttribute("textContent");
                    if (toExist && table.Contains(documentName) && (documentType != "" ? table.Contains(documentType): true))
                        return true;
                    if (!toExist && !table.Contains(documentName) && !(documentType != "" ? table.Contains(documentType) : false))
                        return false;
                }
                Playback.Wait(5000);
            }

            if (toExist)
                return false;
            else
                return true;
        }

        public string GetTextLabelFromTableCell(IWebElement element)
        {
            string reVal = "";

            try
            {
                reVal = element.FindElement(By.XPath("//label")).Text;
            }
            catch { }

            return reVal;
        }

        public IWebElement FindAssociatePackage(string packageName, bool forContextMenu = false)
        {
            var associatePackage = this.AssociateDocumentPackages.FindElement(By.XPath(".//a[text()='" + packageName + "']/ancestor::li[1]"));

            if (!forContextMenu)
                return associatePackage;
            else
                return associatePackage.FindElement(By.XPath(".//a[text()='" + packageName + "']"));
        }

        public IWebElement FindRTMPackage(string packageName, bool forContextMenu = false)
        {
            var rtmPackage = this.RTMDocumentPackages.FindElement(By.XPath(".//a[text()='" + packageName + "']/ancestor::li[1]"));

            if (!forContextMenu)
                return rtmPackage;
            else
                return rtmPackage.FindElement(By.XPath(".//a[text()='" + packageName + "']"));
        }

        public NextGenDocumentRepository SelectAllDocuments()
        {

            this.SwitchToContentFrame();
            var docs = DocumentsTable.FindElements(By.XPath(".//tr")).Where(row => row.Displayed).ToList();

            UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
            Playback.Wait(500); // need this
            for (int i = 0; i < docs.Count; i++)
            {
                docs[i].Click();                                        // click on row to select
            }
            UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);     // release CTRL key

            return this;
        }

        //TODO: make it more generic and move to WebElementExtensions.cs   add to PerformTableAction()
        public NextGenDocumentRepository SelectDocuments(IWebElement table, List<string> documents = null)
        {
            this.SwitchToContentFrame();

            List<IWebElement> docs = new List<IWebElement>();

            if (documents == null)
                docs = DocumentsTable.FindElements(By.XPath(".//tr")).Where(row => row.Displayed).ToList(); // select all
            else
            {
                foreach (var doc in documents)
                {
                    try
                    {
                        docs.Add(table.FindElement(By.XPath(".//tr/td/*[text()='" + doc + "']")));
                    }
                    catch
                    {
                        Reports.StatusUpdate("Unable to find document '" + doc + "' on the table", true);
                    }
                }
            }

            if (docs.Count == 0)    //  unable to find any doc on table
                return this;

            UIKeyboard.PressModifierKeys(UIModifierKeys.Control);       // hold down CTRL key
            Playback.Wait(500); // need this
            for (int i = 0; i < docs.Count; i++)
            {
                docs[i].Click();                                        // click on row to select
            }
            UIKeyboard.ReleaseModifierKeys(UIModifierKeys.Control);     // release CTRL key

            return this;
        }

        public NextGenDocumentRepository SelectTemplatefromSelectionCriteria(string Searchscope, string TemplateType, string TempalteDesc)
        {
            this.SwitchToContentFrame();
            SearchScope.FASelectItem(Searchscope);
            TemplateTypeSelect.FASelectItem(TemplateType);
            TemplateDescription.FASetText(TempalteDesc);
            
            return this;
        }

       public NextGenDocumentRepository WaitForScreenToLoad(IWebElement element = null)
       {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TemplateSearchButton);

            return this;
       }

       public NextGenDocumentRepository WaitForTemplateSearchTabToLoad(int WaitTimeInSeconds = 20)
       {
           WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(WaitTimeInSeconds));
           wait.Until(d =>
           {
               FastDriver.WebDriver.SwitchTo().DefaultContent();
               this.SwitchToContentFrame();
               return TemplatesTable.Exists();
           });

           return this;
       }

       public NextGenDocumentRepository WaitForPhaseviewTabToLoad(int WaitTimeInSeconds = 20)
       {
           WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(WaitTimeInSeconds));
           wait.Until(d =>
           {
               FastDriver.WebDriver.SwitchTo().DefaultContent();
               this.SwitchToContentFrame();
               return PhraseDataElementTable.Exists();
           });

           return this;
       }

       public NextGenDocumentRepository WaitForPhaseviewToLoad(IWebElement element = null)
       {
           this.SwitchToContentFrame();
           this.WaitCreation(element ?? TemplatesTable);
           return this;
       }

       public NextGenDocumentRepository WaitForDocumentEditorToLoad(int WaitTimeInSeconds = 300)
       {
           WebDriverWait wait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(WaitTimeInSeconds));
           wait.Until(d =>
           {
               FastDriver.WebDriver.SwitchTo().DefaultContent();
               WebDriver.SwitchTo().Frame("fraEditor");
               return DocumentEditorObject.Exists();
           });

           return this;
       }

        public NextGenDocumentRepository SelectOKButton()
       {
           List<IWebElement> coll = FastDriver.WebDriver.FindElements(By.TagName("button")).ToList();


           coll.ForEach(element =>
           {
               if (element.Text.Equals("OK"))
               {
                   element.Click();
               }
           });


           return this;
       }

        public NextGenDocumentRepository HandleAdobeReaderError()
        {
            AutoItX.WinWait("Acrobat Reader", "", 5);
            AutoItX.WinActivate("Acrobat Reader");

            Report.UpdateLog(WebDriver, "Button", "OK", () =>
            {
                AutoItX.ControlClick("Acrobat Reader", "", "[CLASS:ThunderRT6CommandButton;Text:OK]");
            });

            AutoItX.WinWaitClose("Acrobat Reader", "", 5);

            return this;
        }

        public NextGenDocumentRepository SelectPhraseandRightClick(string PhraseText)
        {
            DataElementTable.FindElement(By.XPath("//td[@id='phraseName' and contains(text(), '"+PhraseText+"')]")).FARightClick();

            return this;

        }

        public void MouseHoverOnObject(IWebElement TargetElement)
        {

            string javaScript = "var evObj = document.createEvent('MouseEvents');" +
                                "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);" +
                                "arguments[0].dispatchEvent(evObj);";
            IJavaScriptExecutor js = FastDriver.WebDriver as IJavaScriptExecutor;
            js.ExecuteScript(javaScript, TargetElement);
        }

        //Favorite Documents common service to remove existing docs if any
        public NextGenDocumentRepository ClearFavoritedocsdata()
        {
            this.WaitForScreenToLoad(this.FavoriteDocsUIButton);
            this.FavoriteDocsUIButton.FAClick();
            this.WaitForScreenToLoad(this.FavoriteDocsDialog_Done);
            int favdocscount = this.FavoriteDocsDialog_Table.GetRowCount();
            if (favdocscount >= 1)
            {
                this.FavoriteDocsDialog_Done.FAMoveToElement();
                this.FavoriteDocsDialog_Done.FAClick();
            int i;
           for(i=1;i<favdocscount;i++)
           {
               this.WaitForScreenToLoad(this.FavoriteDocsUIButton);
               this.FavoriteDocsUIButton.FAMoveToElement();
               this.FavoriteDocsUIButton.FAClick();
               this.WaitForScreenToLoad(this.FavoriteDocsDialog_Done);
               this.FavoriteDocsDialog_Table.PerformTableAction(2, 4, TableAction.GetCell).Element.FindElement(By.TagName("img")).FAClick();
               this.FavoriteDocsDialog_Done.FAMoveToElement();
               this.FavoriteDocsDialog_Done.FAClick();
               FastDriver.WebDriver.HandleDialogMessage(true, true);
               this.WaitForScreenToLoad();
           }
            }
            else
            {
                this.FavoriteDocsDialog_Done.FAClick();                
                Reports.StatusUpdate("Not required to delete any data", true);
                this.WaitForScreenToLoad();
            }
            return this;
        }

        #endregion

        public void ShowContextMenu(string xpath, double left, double top)
        {
            var contextMenu = this.WebDriver.FindElement(OpenQA.Selenium.By.XPath(xpath));
            var js = (OpenQA.Selenium.IJavaScriptExecutor)FastDriver.WebDriver;
            var obj = js.ExecuteScript("" +
                "arguments[0].style.left = '" + left + "px';" +
                "arguments[0].style.top = '" + top + "px';" +
                "arguments[0].style.display = 'block';" +
                "arguments[0].style.visibility = 'visible';" +
                "return arguments[0];",
            contextMenu);
            Playback.Wait(1000);

            return;
        }

        public void JSClick(string xpath)
        {
            ((IWebElement)this.WebDriver.FindElement(OpenQA.Selenium.By.XPath(xpath))).JSClick();
        }
    }
    

    public class DetailsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tblDocDetails")]
        public IWebElement DetailsTable { get; set; }

        //Added by Luz
        [FindsBy(How = How.Id, Using = "divDetailsDocumentDialog")]
        public IWebElement Detailsdialog { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Document Information']/ancestor::div[2]//button/span[text()='OK']")]
        public IWebElement OK_Detailsbutton { get; set; }

        #endregion
        
        public DetailsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Reason - UnFinalize", true, 20);
            this.WaitCreation(element ?? DetailsTable);
            return this;
        }

    }
    
    public class SectionBreakDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "rdNxtPage")]
        public IWebElement NextPage { get; set; }

        [FindsBy(How = How.Id, Using = "rdCont")]
        public IWebElement Continious { get; set; }

        [FindsBy(How = How.Id, Using = "ddlHeaderPhrase")]
        public IWebElement HeaderPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "ddlFooterPhrase")]
        public IWebElement FooterPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "txtTop")]
        public IWebElement TopMargin { get; set; }

        [FindsBy(How = How.Id, Using = "txtbottom")]
        public IWebElement BottomMargin { get; set; }

        [FindsBy(How = How.Id, Using = "rdPageCont")]
        public IWebElement PageContinious { get; set; }

        [FindsBy(How = How.Id, Using = "rdRestart")]
        public IWebElement PageRestart { get; set; }

        [FindsBy(How = How.Id, Using = "SectionBreakCancelID")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "SectionBreakDoneID")]
        public IWebElement Done { get; set; }

        #endregion
        
        public SectionBreakDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Section Break", true, 20);
            this.WaitCreation(element ?? HeaderPhrase);
            return this;
        }

    }
    
    public class DeleteDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "DeleteReason")]
        public IWebElement DeleteReason { get; set; }

        [FindsBy(How = How.Id, Using = "deleteCancelBtnID")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "deleteDonesBtnID")]
        public IWebElement Done { get; set; }

        #endregion
        
        public DeleteDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Reason - Delete", true, 20);
            this.WaitCreation(element ?? DeleteReason);
            return this;
        }

    }

    public class UnFinalizeDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "eventComment2")]
        public IWebElement UnFinalizeReason { get; set; }

        [FindsBy(How = How.Id, Using = "unfinalizeCancelBtnID")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "unfinalizeDonesBtnID")]
        public IWebElement Done { get; set; }

        #endregion
        
        public UnFinalizeDlg WaitForScreenToLoad(IWebElement element = null)
        {
            
            WebDriver.WaitForWindowAndSwitch("Reason - UnFinalize", true, 20);
            this.WaitCreation(element ?? UnFinalizeReason);
            return this;
        }

    }

}
