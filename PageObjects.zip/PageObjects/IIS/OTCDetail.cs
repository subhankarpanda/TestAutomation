using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class OTCDetail : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "Check Details")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdFindName")]
        public IWebElement Find { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement GabName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement BusinessPartyNameField { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName2")]
        public IWebElement BusinessPartyNameField2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_tblAddr")]
        public IWebElement BusinessPartyAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEditContactInfo")]
        public IWebElement EditContact { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement BusPhone { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement BusFax { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Name, Using = "Id_contains")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement WeeklyEmailStatus { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep1")]
        public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep2")]
        public IWebElement SalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textReference")]
        public IWebElement Reference { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement AgentLicNum { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement DipStatusCode { get; set; }

        [FindsBy(How = How.Id, Using = "Button1")]
        public IWebElement SplitLSP { get; set; }

        [FindsBy(How = How.Id, Using = "txtChargesRetained")]
        public IWebElement ChargesRetained { get; set; }

        [FindsBy(How = How.Id, Using = "comboType")]
        public IWebElement Type { get; set; }

        [FindsBy(How = How.Id, Using = "agc_btnPayment")]
        public IWebElement OTCTitleServicesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tdsc")]
        public IWebElement OTCTitleServicesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tbc")]
        public IWebElement OTCTitleServicesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tbd")]
        public IWebElement OTCTitleServicesBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tsc")]
        public IWebElement OTCTitleServicesSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tsr")]
        public IWebElement OTCTitleServicesSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs")]
        public IWebElement OTCLenderPolicyEndorsementTable { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_btnPayment")]
        public IWebElement OTCLenderPolicyEndorsementPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tdsc")]
        public IWebElement OTCLenderPolicyEndorsementDescription { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tbc")]
        public IWebElement OTCLenderPolicyEndorsementBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tbd")]
        public IWebElement OTCLenderPolicyEndorsementBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tsc")]
        public IWebElement OTCLenderPolicyEndorsementSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tsr")]
        public IWebElement OTCLenderPolicyEndorsementSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_btnPayment")]
        public IWebElement OTCOwnerPolicyEndorsementPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs")]
        public IWebElement OTCOwnerPolicyEndorsementTable { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tdsc")]
        public IWebElement OTCOwnerPolicyEndorsementDescription { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tbc")]
        public IWebElement OTCOwnerPolicyEndorsementBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tbd")]
        public IWebElement OTCOwnerPolicyEndorsementBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tsc")]
        public IWebElement OTCOwnerPolicyEndorsementSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tsr")]
        public IWebElement OTCOwnerPolicyEndorsementSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "afc_btnCalculateFee")]
        public IWebElement CalculateFees { get; set; }

        [FindsBy(How = How.Id, Using = "afc_btnAdd")]
        public IWebElement RecordingFeeTransferTaxAddRecordingFees { get; set; }

        [FindsBy(How = How.Id, Using = "afc_btnPayment")]
        public IWebElement RecordingFeeTransferTaxPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df")]
        public IWebElement RecFeesAndTTaxTable { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df_0_tds")]
        public IWebElement RecordingFeeTransferTaxDesciption { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df_0_tbc")]
        public IWebElement RecordingFeeTransferTaxBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df_0_tsc")]
        public IWebElement RecordingFeeTransferTaxSellerCharge { get; set; }

        [FindsBy(How = How.LinkText, Using = "License Number: ")]
        public IWebElement LicenseNumberLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalCharges")]
        public IWebElement TotalChgs { get; set; }

        [FindsBy(How = How.Id, Using = "lblChargesRetained")]
        public IWebElement ChgsRetained { get; set; }

        [FindsBy(How = How.Id, Using = "lblOTCFundDue")]
        public IWebElement OTCFundDue { get; set; }

        [FindsBy(How = How.Id, Using = "lblEMHeld")]
        public IWebElement EarnestAmountHeld { get; set; }

        [FindsBy(How = How.LinkText, Using = "/smsfast/images/ico_write.gif")]
        public IWebElement AmountEditedImage { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.LinkText, Using = "Funds Deposited: $")]
        public IWebElement FundsDepositedLabel { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tga")]
        public IWebElement OTCTitleServicesLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetCheckAmt")]
        public IWebElement NetCheckAmt { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_ddlBusOrgStateLicense")]
        public IWebElement BusOrg_LicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_ddlBusContactStateLicense")]
        public IWebElement BusOrg_ContactLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "lblCheckToolTip")]
        public IWebElement CheqImage { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtGRCLoanEstimateUnroundedAmount")]
        public IWebElement GRCLoanEstimateUnroundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtTTLoanEstimateUnroundedAmount")]
        public IWebElement TTLoanEstimateUnroundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtGRCLoanEstimateRoundedAmount")]
        public IWebElement GRCLoanEstimateRoundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtTTLoanEstimateRoundedAmount")]
        public IWebElement TTLoanEstimateRoundedAmount { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs")]
        public IWebElement TitleServicesTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img#afc_divbrokenlinkGRC")]
        public IWebElement RecFeeLEbrokenImage { get; set; }
        
        [FindsBy(How = How.CssSelector, Using = "img#afc_divbrokenlinkTT")]
        public IWebElement TTaxLEbrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "afc_btnAdd")]
        public IWebElement AddRecordingFees { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_chkDisplayAggregateOnCD")]
        public IWebElement DisplayAggregateOnCD { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_chkTitlePremiumAdjustment")]
        public IWebElement DisplayTitlePremiumAdjustment { get; set; }

        [FindsBy(How = How.Id, Using = "btnOwnerBS")]
        public IWebElement OTCBSsplit { get; set; }

        [FindsBy(How = How.Id, Using = "lblOwnerSeller")]
        public IWebElement OTCBSSplitSellerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblOwnerBuyer")]
        public IWebElement OTCBSSplitBuyerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "txtOwnerAdjAmnt")]
        public IWebElement OTCDisclosedOwnerPremium { get; set; }

        [FindsBy(How = How.Id, Using = "txtlenderAdjAmnt")]
        public IWebElement OTCDisclosedLoanPremium { get; set; }

        [FindsBy(How = How.Id, Using = "lblBifurcatedTransaction")]
        public IWebElement OTCBifurcatedTransaction { get; set; }

        [FindsBy(How = How.Id, Using = "txtLenderLoanEstmt")]
        public IWebElement OTCLenderLoanEstmt { get; set; }

        [FindsBy(How = How.Id, Using = "txtOwnerLoanEstmt")]
        public IWebElement OTCOwnerLoanEstmt { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tga")]
        public IWebElement OwnerLoanEstimateUnroundedAmtOTCGrid { get; set; }

        [FindsBy(How = How.Id, Using = "lblLenderPlcName")]
        public IWebElement LenderPlaceName { get; set; }

        [FindsBy(How = How.Id, Using = "lblOwnerPlcName")]
        public IWebElement OwnerPlaceName { get; set; }

        [FindsBy(How = How.Id, Using = "tblTitlePolicyCalc")]
        public IWebElement TPC_Section { get; set; }

        [FindsBy(How = How.Id, Using = "dgridOTCSummary")]
        public IWebElement OTC_Summary { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement OTC_Remove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement OTC_Edit { get; set; }

        [FindsBy(How = How.Id, Using = "chkDAggOnCD")]
        public IWebElement OTC_AggLenderPolicyEndorsementsCD { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_tdButtonExpand")]
        public IWebElement OTC_ContactDetailsExpandBtn { get; set; }

        [FindsBy(How = How.Id, Using = "txtSimPolicyAdjAmt")]
        public IWebElement OTCTitlePremiumAdjustment { get; set; }

        [FindsBy(How = How.Id, Using = "lblShowOnCD")]
        public IWebElement OTCShowonCDPage3Label { get; set; }

        [FindsBy(How = How.Id, Using = "FAFCBShowOnCD")]
        public IWebElement OTCShowonCDPage3Checkbox { get; set; }

        [FindsBy(How = How.Id, Using = "BrokenImage")]
        public IWebElement OTCTPABrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "btnLenderBS")]
        public IWebElement OTCLenderBSsplit { get; set; }

        [FindsBy(How = How.Id, Using = "lblLenderSeller")]
        public IWebElement OTCLenderBSSplitSellerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblLenderBuyer")]
        public IWebElement OTCLenderBSSplitBuyerPercentage { get; set; }


        #endregion

        public OTCDetail Open()
        {
            FastDriver.LeftNavigation.Navigate<OTCDetail>("Home>Order Entry>Outside Title Company");
            this.WaitForScreenToLoad();

            return this;
        }

        public void FindGAB(string gabcode)
        {
            this.GABcode.FASetText(gabcode);
            this.Find.Click();
            this.WaitCreation(FastDriver.WebDriver.FindElement(By.Id("bpB_labelIdcode")));
            Support.AreEqual(gabcode, FastDriver.WebDriver.FindElement(By.Id("bpB_labelIdcode")).FAGetText(),bIgnoreCase :true);
        }


        public OTCDetail WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GABcode, 5);

            return this;
        }

        #region AddLastLineCharges
        //used Lender's Policy and Endorsements table
        public void AddLastLineCharges(IWebElement Table, string TableId, string ChargeDesc, double? BuyerCharge = null, double? BuyerCredit = null, double? SellerCharge = null, double? SellerCredit = null, double? LoanEstimate = null, double? Months = null, double? MonthlyCharges = null)
        {
            try
            {
                int i = Table.GetRowCount();
                i = i - 2;

                #region Select cells from last row
                string ChargeDescID = TableId + "_" + i + "_tdsc", BuyerChargeId = TableId + "_" + i + "_tbc";
                string BuyerCreditId = TableId + "_" + i + "_tbd", SellerChargeId = TableId + "_" + i + "_tsc";
                string SellerCreditId = TableId + "_" + i + "_tsr", LoanEstimateId = TableId + "_" + i + "_tga";
                string MonthsId = TableId + "_" + i + "_tms", MonthlyChargesId = TableId + "_" + i + "_tmc";
                #endregion
                if (ChargeDesc != string.Empty)
                {
                    Reports.TestStep = "Entered Charge Description - " + ChargeDesc.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(ChargeDescID)).FASetText(ChargeDesc);
                }
                if(Months.HasValue)
                {
                    Reports.TestStep = "Entered months - " + Months.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(MonthsId)).FASetText(Months.ToString());
                }
                if (MonthlyCharges.HasValue)
                {
                    Reports.TestStep = "Entered monthly charges - " + MonthlyCharges.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(MonthlyChargesId)).FASetText(MonthlyCharges.ToString());
                }
                if(BuyerCharge.HasValue)
                {
                    Reports.TestStep = "Entered Buyer Charge - " + BuyerCharge.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(BuyerChargeId)).FASetText(BuyerCharge.ToString());
                }
                if (BuyerCredit.HasValue)
                {
                    Reports.TestStep = "Entered Buyer Credit - " + BuyerCredit.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(BuyerCreditId)).FASetText(BuyerCredit.ToString());
                }
                if (SellerCharge.HasValue)
                {
                    Reports.TestStep = "Entered Seller Charge - " + SellerCharge.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(SellerChargeId)).FASetText(SellerCharge.ToString());
                }
                if (SellerCredit.HasValue)
                {
                    Reports.TestStep = "Entered Seller Credit - " + SellerCredit.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(SellerCreditId)).FASetText(SellerCredit.ToString());
                }
                if (LoanEstimate.HasValue)
                {
                    Reports.TestStep = "Entered Loan Estimate - " + LoanEstimate.ToString();
                    FastDriver.WebDriver.FindElement(By.Id(LoanEstimateId)).FASetText(LoanEstimate.ToString());
                }
            }
            catch (Exception e)
            {
                Reports.TestStep = e.Message + " for " + ChargeDesc;
                Reports.TestResult = false;
            }
        }

        public OTCDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;

        }


        #endregion
    }
}
