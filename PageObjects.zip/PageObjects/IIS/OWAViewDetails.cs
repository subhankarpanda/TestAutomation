using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class OWAViewDetails : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "chkApproval1")]
		public IWebElement Approved { get; set; }

		[FindsBy(How = How.Id, Using = "chkRejected")]
		public IWebElement Rejected { get; set; }

		[FindsBy(How = How.Id, Using = "txtApprovedBy1")]
		public IWebElement ApprovedBy { get; set; }

		[FindsBy(How = How.Id, Using = "txtApprovedOn1")]
		public IWebElement ApprovedOn { get; set; }

		#endregion

	}
}
