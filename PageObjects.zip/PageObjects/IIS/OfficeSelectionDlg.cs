using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
	public class OfficeSelectionDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "dGridSelectedOffices_dGridSelectedOffices")]
        public IWebElement OfficesSelectTable { get; set; }

        [FindsBy(How = How.Id, Using = "comboOfficeStatus")]
        public IWebElement Display { get; set; }

		[FindsBy(How = How.Id, Using = "comboRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_0_chkSelect")]
		public IWebElement Office1 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_1_chkSelect")]
		public IWebElement Office2 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_2_chkSelect")]
		public IWebElement Office3 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_3_chkSelect")]
		public IWebElement Office4 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_4_chkSelect")]
		public IWebElement Office5 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_5_chkSelect")]
		public IWebElement Office6 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_6_chkSelect")]
		public IWebElement Office7 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_7_chkSelect")]
		public IWebElement Office8 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_8_chkSelect")]
		public IWebElement Office9 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_dGridActiveOffices")]
		public IWebElement OfficesTable { get; set; }

        [FindsBy(How = How.Name, Using = "dGridActiveOffices_dGridActiveOffices")]
        public IWebElement OfficesTable1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSelectedOffices_dGridSelectedOffices")]
        public IWebElement SelectedOfficesTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "grdOffSel_0_chkSelOff")]
		public IWebElement grdOffSel0SelOff { get; set; }

		[FindsBy(How = How.Id, Using = "grdOffSel_1_chkSelOff")]
		public IWebElement grdOffSel1SelOff { get; set; }

		[FindsBy(How = How.Id, Using = "rdoOfficeGroup")]
		public IWebElement OfficeGroup { get; set; }

		[FindsBy(How = How.Id, Using = "rdoOffice")]
		public IWebElement Offices { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_9_chkSelect")]
		public IWebElement Office10 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_11_chkSelect")]
		public IWebElement Office11 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_12_chkSelect")]
		public IWebElement Office12 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_13_chkSelect")]
		public IWebElement Office13 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_14_chkSelect")]
		public IWebElement Office14 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_15_chkSelect")]
		public IWebElement Office15 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_16_chkSelect")]
		public IWebElement Office16 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_25_chkSelect")]
		public IWebElement Office25 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_26_chkSelect")]
		public IWebElement Office26 { get; set; }

		[FindsBy(How = How.Id, Using = "dGridActiveOffices_2_lblOfficeName")]
		public IWebElement OfficeName { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_0_lblOfficeName")]
        public IWebElement OfficeName1 { get; set; }

		#endregion

        public OfficeSelectionDlg WaitForScreenToLoad(string windowName = "Office Selection", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? Region);

            return this;
        }
        //
        [Description("If parameter is blank then first office which is not already selected is returned")]
        public string SelectOffice(string OfficeName="")
        {
            try
            {
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.OfficesTable.GetRowCount(); i++)
                {
                    if (string.IsNullOrEmpty(OfficeName))
                    {
                        IWebElement CheckBox = OfficesTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.TagName("input"));
                        if (!CheckBox.IsSelected())
                        {
                            OfficesTable.PerformTableAction(i, 1, TableAction.On);
                            OfficeName = OfficesTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                            return OfficeName;
                        }
                    }
                    else
                    {
                        if (OfficeName == OfficesTable.PerformTableAction(i, 2, TableAction.GetText).Message)
                        {
                            OfficesTable.PerformTableAction(i, 1, TableAction.On);
                            return OfficeName;
                        }
                    }

                }
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return OfficeName;
        }
        //
        [Description("If parameter is blank then first office which is already selected is removed")]
        public string DeselectOffice(string OfficeName = "")
        {
            try
            {
                this.WaitForScreenToLoad();
                for (int i = 1; i < this.OfficesTable.GetRowCount(); i++)
                {
                    if (string.IsNullOrEmpty(OfficeName))
                    {
                        IWebElement CheckBox = OfficesTable.PerformTableAction(i, 1, TableAction.GetCell).Element.FindElement(By.TagName("input"));
                        if (CheckBox.IsSelected())
                        {
                            OfficesTable.PerformTableAction(i, 1, TableAction.Off);
                            OfficeName = OfficesTable.PerformTableAction(i, 2, TableAction.GetText).Message;
                            return OfficeName;
                        }
                    }
                    else
                    {
                        if (OfficeName == OfficesTable.PerformTableAction(i, 2, TableAction.GetText).Message)
                        {
                            OfficesTable.PerformTableAction(i, 1, TableAction.Off);
                            return OfficeName;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return OfficeName;
        }

	}
}
