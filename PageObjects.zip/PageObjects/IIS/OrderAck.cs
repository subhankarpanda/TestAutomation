using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class OrderAck : PageObject
	{
		#region WebElements

		[FindsBy(How = How.LinkText, Using = "Close this window")]
		public IWebElement Closethiswindow { get; set; }

		[FindsBy(How = How.LinkText, Using = "Thank you for your Title Order.")]
		public IWebElement ThankyouforyourTitleOrder { get; set; }

        [FindsBy(How = How.XPath, Using = "//a[contains(@onmouseover, 'Continue')]")]
        public IWebElement Ok { get; set; }

        [FindsBy(How = How.Id, Using = "DontShowThisAgain")]
        public IWebElement DontShowMsg { get; set; }

        #endregion

        #region Useful Methods
        public OrderAck WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.SwitchToWindowByUrl("https://fwtestweb1.firstam.com/fastweb/fastorder/templates/title/DonotShowThisMsgAgain.asp?Services=Thank");
            FastDriver.WebDriver.SwitchTo().DefaultContent();
            this.WaitCreation(element ?? DontShowMsg);
            return this;

        }
        #endregion

    }
}
