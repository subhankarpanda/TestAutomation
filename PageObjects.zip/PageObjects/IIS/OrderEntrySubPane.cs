﻿using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class OrderEntrySubPane : PageObject
    {
        [FindsBy(How = How.CssSelector, Using = "li[title='Quick File Entry']>a")]
        public IWebElement QuickFileEntry { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='Escrow Closing']>a")]
        public IWebElement EscrowClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "li[title='File Homepage']>a")]
        public IWebElement FileHomepage { get; set; }

        public FileHomepage LoadFileHomepage()
        {
            this.SwitchToLeftNavigationPane();
            FileHomepage.FAClick();
            
            return FastDriver.GetPage<FileHomepage>();
        }

        public DuplicateFileSearch LoadDuplicateFileSearch()
        {
            this.SwitchToLeftNavigationPane();
            QuickFileEntry.FAClick();
            
            return FastDriver.GetPage<DuplicateFileSearch>();
        }
    }
}
