using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class OutgoingWireApproval : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboBankAccounts")]
		public IWebElement Select_BankAcct { get; set; }

		[FindsBy(How = How.Id, Using = "cboMethod")]
		public IWebElement Select_Method { get; set; }

		[FindsBy(How = How.Id, Using = "btnDeliver")]
		public IWebElement Deliver { get; set; }

		[FindsBy(How = How.Id, Using = "IssueDateFrom")]
		public IWebElement IssueDateFrom { get; set; }

		[FindsBy(How = How.Id, Using = "IssueDateTo")]
		public IWebElement IssueDateTo { get; set; }

		[FindsBy(How = How.Id, Using = "cboStatus")]
		public IWebElement Select_Status { get; set; }

		[FindsBy(How = How.Id, Using = "IWType")]
		public IWebElement Select_ItemType { get; set; }

		[FindsBy(How = How.Id, Using = "chkSelectAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "cmdFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "cmdViewDetails")]
		public IWebElement ViewDetails { get; set; }

		[FindsBy(How = How.Id, Using = "cmdTransmitNow")]
		public IWebElement Transmit { get; set; }

		[FindsBy(How = How.Name, Using = "dgWireApproval_dgWireApproval")]
		public IWebElement SearchResults { get; set; }

		[FindsBy(How = How.Id, Using = "dgWireApproval_0_ChkSel")]
		public IWebElement SelUnapproved { get; set; }

		[FindsBy(How = How.Id, Using = "dgWireApproval_0_ChkSel")]
		public IWebElement SelUnapproved1 { get; set; }

		#endregion

        public OutgoingWireApproval WaitForScreenToLoad(IWebElement elememt = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(elememt ?? IssueDateFrom);
            return this;
        }

	}
}
