using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class OutsideEscrowCompanyDetail : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = "Check Details")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtName")]
        public IWebElement Name_F { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement BusinessPartyNameField { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName2")]
        public IWebElement BusinessPartyNameField2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEditContactInfo")]
        public IWebElement EditContact { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textBusPhone")]
        public IWebElement BusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtExtnPhone")]
        public IWebElement BusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_ddlBusOrgStateLicense")]
        public IWebElement LicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkWeeklyEmailStatus")]
        public IWebElement WeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep1")]
        public IWebElement SalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep2")]
        public IWebElement SalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_btnPayment")]
        public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "txtPBbyBuyerAtClosing")]
        public IWebElement OEPBbyBuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyOthers")]
        public IWebElement OEBPbyOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOthersBuyer")]
        public IWebElement DropdownOE { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement PDDdone { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_0_tdsc")]
        public IWebElement ChargeDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_0_tbc")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_0_tsc")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_lblFooter")]
        public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblgetOECCharges")]
        public IWebElement OECCharges { get; set; }

        [FindsBy(How = How.Id, Using = "lblgetOtherFileCharges")]
        public IWebElement OtherFileCharges { get; set; }

        [FindsBy(How = How.Id, Using = "lblgetOtherFileCredits")]
        public IWebElement OtherFileCredits { get; set; }

        [FindsBy(How = How.Id, Using = "lblgetNetCheckAmt")]
        public IWebElement NetCheckAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tblOtherChargesCredits")]
        public IWebElement OutsideEscrowCompanyTable { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_0_tga")]
        public IWebElement LoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_lblFooter")]
        public IWebElement CheqImage { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs")]
        public IWebElement OutsideEscrowCompanyCharges { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_tblAddr")]
        public IWebElement Address { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelAddress")]
        public IWebElement GABAddressLabel { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement OECError { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_1_tdsc")]
        public IWebElement ChargeDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_1_tbc")]
        public IWebElement BuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_1_tsc")]
        public IWebElement SellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "ocg_dcs_1_tga")]
        public IWebElement LoanEstimate2 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src='../images/ico_write.gif']")]
        public IWebElement PencilIcon { get; set; }

        #endregion

        public OutsideEscrowCompanyDetail WaitForScreenToLoad()
        {
            
            this.SwitchToContentFrame();

            this.WaitCreation(GABcode);
            return this;
        }

        public OutsideEscrowCompanyDetail FillCompanyDetailsForm(string gabCode, string chargeDesc)
        {
            
            this.SwitchToContentFrame();

            GABcode.FASetText(gabCode);
            Find.FAClick();
            this.WaitForValue(GABcodeLabel, gabCode);
            ChargeDescription.FASetText(chargeDesc);

            return this;
        }

        public OutsideEscrowCompanyDetail AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public OutsideEscrowCompanyDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public OutsideEscrowCompanyDetail FindGAB(string GABCode, bool waitForValue = false)
        {
            this.SwitchToContentFrame();
            GABcode.FASetText(GABCode);
            Find.FAClick();
            if(waitForValue)
                this.WaitForValue(GABcodeLabel, GABCode);
            return this;
        }

        public OutsideEscrowCompanyDetail Open()
        {
            FastDriver.LeftNavigation.Navigate<OutsideEscrowCompanyDetail>("Home>Order Entry>Outside Escrow Company");
            this.WaitForScreenToLoad();
            return this;
        }

        public OutsideEscrowCompanyDetail OECHSectionCharges(string GabCode ="HUDOUTESC1",bool secondInstance= false)
        {
            this.Open();

            if (secondInstance == true)
                FastDriver.BottomFrame.New();
                           

            FastDriver.OutsideEscrowCompanyDetail.FindGAB(GabCode);
            FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("OEC Charges 1");
            Keyboard.SendKeys("{TAB}");
            FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.FASetText("345.67");
            FastDriver.OutsideEscrowCompanyDetail.SellerCharge.FASetText("789.98");
            FastDriver.OutsideEscrowCompanyDetail.LoanEstimate.FASetText("399.99");
            Keyboard.SendKeys("{TAB}");

            FastDriver.OutsideEscrowCompanyDetail.ChargeDescription2.FASetText("OEC Charges 2");
            Keyboard.SendKeys("{TAB}");
            FastDriver.OutsideEscrowCompanyDetail.BuyerCharge2.FASetText("123.67");
            FastDriver.OutsideEscrowCompanyDetail.SellerCharge2.FASetText("456.98");
            FastDriver.OutsideEscrowCompanyDetail.LoanEstimate2.FASetText("789.99");

            return this;
        }
    }
}
