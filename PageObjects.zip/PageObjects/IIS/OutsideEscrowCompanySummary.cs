using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class OutsideEscrowCompanySummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridOECSummary")]
		public IWebElement SummaryTable { get; set; }

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		#endregion

        #region - Methods
        public OutsideEscrowCompanySummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();

            this.WaitCreation(Edit);
            return this;
        }

        #endregion

    }
}
