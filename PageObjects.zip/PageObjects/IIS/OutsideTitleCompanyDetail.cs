﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
namespace FASTSelenium.PageObjects.IIS
{
    public class OutsideTitleCompanyDetail : PageObject
    {
        #region IWebElements

        [FindsBy(How = How.Id, Using = "agc_btnPayment")]
        public IWebElement TitleServicePaymentDetail { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalCharges")]
        public IWebElement TotalCharges { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtGABcode")]
        public IWebElement GABCodeEdit { get; set; }

        [FindsBy(How = How.Id, Using = "lblEMHeld")]
        public IWebElement EarnestMoneyHeld { get; set; }

        [FindsBy(How = How.Id, Using = "lblChargesRetained")]
        public IWebElement FundsDeposited { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetCheckAmt")]
        public IWebElement NetCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblOTCFundDue")]
        public IWebElement FundsDue { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtName")]
        public IWebElement NameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement NameLabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName2")]
        public IWebElement NameLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelAddress")]
        public IWebElement AddressLabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelAddress2")]
        public IWebElement AddressLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdFindName")]
        public IWebElement FindBtn { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_ddlBusOrgStateLicense")]
        public IWebElement LicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "txtChargesRetained")]
        public IWebElement FundsDepositedEdit { get; set; }

        [FindsBy(How = How.Id, Using = "comboType")]
        public IWebElement TypeSelect { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtExtnPhone")]
        public IWebElement BusPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEditContactInfo")]
        public IWebElement EditContact { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tdsc")]
        public IWebElement TitleServiceDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tbc")]
        public IWebElement TitleServiceBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_1_tbc")]
        public IWebElement TitleServiceBuyerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tbd")]
        public IWebElement TitleServiceBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tsc")]
        public IWebElement TitleServiceSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_1_tsc")]
        public IWebElement TitleServiceSellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tsr")]
        public IWebElement TitleServiceSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_0_tga")]
        public IWebElement TitleServiceLEUnrounded1 { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs_7_tbc")]
        public IWebElement SettlementCharge { get; set; }

        [FindsBy(How = How.Id, Using = "agc_dcs")]
        public IWebElement TitleServicesTable { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_chkDisplayAggregateOnCD")]
        public IWebElement LenderPEDisplayAggregateCheck { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_chkTitlePremiumAdjustment")]
        public IWebElement LenderPEDisplayTPA { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_btnPayment")]
        public IWebElement LenderPEPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tdsc")]
        public IWebElement LenderPEDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tbc")]
        public IWebElement LenderPEBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tbd")]
        public IWebElement LenderPEBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tsc")]
        public IWebElement LenderPESellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tsr")]
        public IWebElement LenderPESellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs_0_tga")]
        public IWebElement LenderPELEUnrounded1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_btnPayment")]
        public IWebElement OwnerPEPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tdsc")]
        public IWebElement OwnerPEDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tbc")]
        public IWebElement OwnerPEBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tbd")]
        public IWebElement OwnerPEBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tsc")]
        public IWebElement OwnerPESellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tsr")]
        public IWebElement OwnerPESellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs_0_tga")]
        public IWebElement OwnerPELEUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeO_dcs")]
        public IWebElement OwnerPolicyAndEndorsementsTable { get; set; }

        [FindsBy(How = How.Id, Using = "afc_btnAdd")]
        public IWebElement AddRecordingFees { get; set; }

        [FindsBy(How = How.Id, Using = "afc_btnPayment")]
        public IWebElement RFeesTTaxesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "afc_lblGRCBuyerAmount")]
        public IWebElement RFeesFRFeesBuyerLabel { get; set; }

        [FindsBy(How = How.Id, Using = "afc_lblTXBuyer")]
        public IWebElement TTaxesBuyerLabel { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtGRCLoanEstimateUnroundedAmount")]
        public IWebElement RFeesFTFeesLEUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtTTLoanEstimateUnroundedAmount")]
        public IWebElement TTaxesLEUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtGRCLoanEstimateRoundedAmount")]
        public IWebElement RFeesFRFeesLERounded { get; set; }

        [FindsBy(How = How.Id, Using = "afc_txtTTLoanEstimateRoundedAmount")]
        public IWebElement TTaxesLERounded { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df")]
        public IWebElement RecFeesAndTTaxTable { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df_0_tds")]
        public IWebElement RFeesTTaxesDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df_0_tbc")]
        public IWebElement RFeesTTaxesBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "afc_df_0_tsc")]
        public IWebElement RFeesTTaxesSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "agcItemizeL_dcs")]
        public IWebElement LendersPolicyAndEndorsementsTable { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_DipStatusCode")]
        public IWebElement DipStatusCode { get; set; }

        //added
        [FindsBy(How = How.Id, Using = "agcItemizeL_btnPayment")]
        public IWebElement PDDlendersPolicyandEndorsements { get; set; }

        //added
        [FindsBy(How = How.Id, Using = "agcItemizeO_btnPayment")]
        public IWebElement PDDOwnersPolicyandEndorsements { get; set; }

        //added
        [FindsBy(How = How.Id, Using = "lblLenderPlcName")]
        public IWebElement OTCLenderPolicyName { get; set; }


        //added
        [FindsBy(How = How.Id, Using = "txtOwnerAdjAmnt")]
        public IWebElement OTCDisclosedOwnerPremium { get; set; }
        //
        [FindsBy(How = How.Id, Using = "txtlenderAdjAmnt")]
        public IWebElement OTCDisclosedLoanPremium { get; set; }

        //added
        [FindsBy(How = How.Id, Using = "lblOwnerPlcName")]
        public IWebElement OTCOwnerPolicyName { get; set; }

        //added
        [FindsBy(How = How.Id, Using = "chkDAggOnCD")]
        public IWebElement AggregateLenderPolicyandEndorsementsonCD { get; set; }


        //added
        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
        public IWebElement OTCBSSplitBuyerCharge { get; set; }

        #endregion

        [FindsBy(How = How.Id, Using = "bpB_textBusPhone")]
        public IWebElement BusinessPhoneNumber { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        public OutsideTitleCompanyDetail UpdateLendersPolicyAndEndorsementsTable(string chargeDescription, double? buyerCharge, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, string editdescription = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LendersPolicyAndEndorsementsTable);
            var rows = LendersPolicyAndEndorsementsTable.FindElements(By.TagName("tr"));

            //IWebElement row = rows.
            //    FirstOrDefault(tempRow => tempRow.FindElements(By.TagName("input")).FirstOrDefault(ipt => ipt.GetAttribute("id").Contains("_tdsc") && ipt.Displayed)
            //        .GetAttribute("value").Trim().Contains(chargeDescription));

            IWebElement row = null;
            foreach (var tempRow in rows)
            {
                IWebElement descriptionInput = tempRow.FindElements(By.TagName("input")).FirstOrDefault(i => i.GetAttribute("id").Contains("_tdsc") && i.Displayed);
                try
                {
                    if (descriptionInput.GetAttribute("value").Trim().Contains(chargeDescription))
                    {
                        row = tempRow;
                        break;
                    }
                }
                catch (NullReferenceException)
                {
                    continue;
                }
            }

            if (row == null)
                throw new NoSuchElementException(string.Format("Could not find an Impound Charge with description '{0}'", chargeDescription));

            IWebElement inputElement;
            if (buyerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbc") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(buyerCharge.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (buyerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbd") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(buyerCredit.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (sellerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsc") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(sellerCharge.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (sellerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsr") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(sellerCredit.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (loanEstimate.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tga") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(loanEstimate.ToString());
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }

            return this;
        }

        public OutsideTitleCompanyDetail WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TotalCharges);

            return this;
        }

        public OutsideTitleCompanyDetail SaveAndReloadScreen()
        {
            FastDriver.BottomFrame.Done();
            FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
            return this;
        }

        public OutsideTitleCompanyDetail FindGAB(string gab = "boa", bool waitForValue = true)
        {
            GABCodeEdit.FASetText(gab + FAKeys.Tab);
            FindBtn.FAClick();
            this.WaitForValue(IDCode, gab);

            return this;
        }

        public OutsideTitleCompanyDetail AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public void EnterDataInSectionBOTC()
        {
            Reports.TestStep = "Enter charge in Outside Title Company Title services and Lenders Policy and Endorsement table.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
            FastDriver.OutsideTitleCompanyDetail.FindGAB("HUDOUTESC1");
            FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, "Title - Title Examination", 2000.00, null, 3000.00, null, 444);
            FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.TitleServicesTable, "Title - Abstract or Title Search", 2000.00, null, 3000.00, null, 333);

            FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title - Lender Policy and Endorsements", 2000.00, null, 3000.00, null, 222);
            FastDriver.OutsideTitleCompanyDetail.AddCharge(FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable, "Title - Lender Policy", 2000.00, null, 3000.00, null, 111);

            FastDriver.BottomFrame.Done();
        }

        public void EnterDataInSectionHOTC()
        {
            Reports.TestStep = "Enter charge in Outside Title Company Owner's Policy and Endorsements table.";
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company").WaitForScreenToLoad();
            FastDriver.OutsideTitleCompanyDetail.FindGAB("STARTOTC");
            FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Owner Policy (Optional)", 2000.00, null, 3000.00, null, 444);
            FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Endorsement (s)- O", 2000.00, null, 3000.00, null, 333);
            FastDriver.OutsideTitleCompanyDetail.UpdateCharge(FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable, "Title - Title Insurance Binder - O", 2000.00, null, 3000.00, null, 222);
            FastDriver.BottomFrame.Done();
        }

        public OutsideTitleCompanyDetail UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public string GetOutsideTitleCompanyFullName
        {
            get
            {
                string nameLine1 = this.NameLabel1.FAGetText();
                string nameLine2 = this.NameLabel2.FAGetText();
                return (nameLine1 + " " + nameLine2).Trim();
            }
        }
        //
        public OutsideTitleCompanyDetail Open()
        {
            FastDriver.LeftNavigation.Navigate<OutsideTitleCompanyDetail>("Home>Order Entry>Outside Title Company");
            this.WaitForScreenToLoad();
            return this;
        }

    }
}
