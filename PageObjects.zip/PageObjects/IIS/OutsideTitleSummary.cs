using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class OutsideTitleSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridOTCSummary")]
		public IWebElement SummaryTable { get; set; }

		#endregion

        public OutsideTitleSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SummaryTable);
            return this;
        }
        //
        public OutsideTitleSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<OutsideTitleSummary>("Home>Order Entry>Outside Title Company");
            this.WaitForScreenToLoad();
            return this;
        }

                        
	}
}
