using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class OverdraftConfirmationDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "tblDisbDetail")]
        public IWebElement tblDisbDetail { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProcess")]
        public IWebElement ReasonForLoss { get; set; }

        [FindsBy(How = How.Id, Using = "txtLossExplanation")]
        public IWebElement LossExplanation { get; set; }

        #endregion

        public void ConfirmWireTransfer()
        {
            WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
            this.SwitchToDialogContentFrame();
            this.ReasonForLoss.FASelectItem("Date Down: Did Not Review Available Date Down Information");
            this.LossExplanation.FASetText("Loss Explanation");
            FastDriver.DialogBottomFrame.ClickDone();
            WebDriver.SwitchToWindow(Support.FASTWindowName);
        }

        public OverdraftConfirmationDlg WaitForScreenToLoad(string windowName = "Overdraft Reason", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? ReasonForLoss);
            return this;
        }

        public OverdraftConfirmationDlg OverDraftConfirmationEnterDetails(string ReasonforlossOD = "Date Down: Did Not Review Available Date Down Information", string LossExplanationOD = "Loss Explanation")
        {
            this.WaitForScreenToLoad();
            this.ReasonForLoss.FASelectItem(ReasonforlossOD);
            this.LossExplanation.FASetText(LossExplanationOD);
            FastDriver.DialogBottomFrame.ClickDone();
            return this;
        }

        public bool IsOverDraftConfirmationDialogPresent(string DialogName = "Overdraft Reason")
        {
            try
            {

                WebDriver.SwitchTo().DefaultContent();
                if (DialogName == "Overdraft Reason")
                {
                    this.SwitchToDialogContentFrame();
                    return WebDriver.PageSource.Contains(DialogName);
                }
                else
                    return WebDriver.PageSource.Contains(DialogName);

            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }

        }
        
        public void Handle()
        {
            if (IsOverDraftConfirmationDialogPresent("Overdraft Confirmation"))
            {
                Reports.TestStep = "Click OK on Overdraftdialog.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad("Overdraft Confirmation", FastDriver.OverdraftConfirmationDlg.ReasonForLoss);
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
            }
            else
            {
                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                    FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.DialogBottomFrame.ClickDone();
            }
        }
         public OverdraftConfirmationDlg ClickOK(string windowName = "Overdraft Confirmation")
        {
            if (IsOverDraftConfirmationDialogPresent())
            {
                WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
                this.SwitchToDialogContentFrame();
                this.WaitCreation(ReasonForLoss);
                this.ReasonForLoss.FASelectItem("Date Down: Did Not Review Available Date Down Information");
                this.LossExplanation.FASetText("Loss Explanation");
                FastDriver.DialogBottomFrame.ClickDone();
                WebDriver.SwitchToWindow(Support.FASTWindowName);
            }
            return this;
        }
     

    }
}
