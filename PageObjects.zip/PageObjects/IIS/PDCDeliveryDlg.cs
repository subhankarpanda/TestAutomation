using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PDCDeliveryDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtCopies")]
		public IWebElement Copies { get; set; }

		[FindsBy(How = How.Id, Using = "chkEDeliver")]
		public IWebElement EDeliver { get; set; }

		[FindsBy(How = How.Id, Using = "txtSubject")]
		public IWebElement Subject { get; set; }

		[FindsBy(How = How.Id, Using = "txtMsg")]
		public IWebElement Msg { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnMail")]
		public IWebElement Mail { get; set; }

        #endregion

        #region Useful Methods
        public PDCDeliveryDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame(false);
            this.WaitCreation(Mail);
            return this;
        }

        public PDCDeliveryDlg SendAssocPkgMail()
        {
            WaitForScreenToLoad();
            Subject.FASetText("Test - Associated Package Mail");
            Msg.FASetText("This is a test mail.");
            Mail.FAClick();
            return this;
        }
        #endregion

    }
}
