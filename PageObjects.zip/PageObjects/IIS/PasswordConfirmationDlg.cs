using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class PasswordConfirmationDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtPassword")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProcess")]
        public IWebElement ReasonForLoss { get; set; }

        [FindsBy(How = How.Id, Using = "txtLossExplanation")]
        public IWebElement LossExplanation { get; set; }

        [FindsBy(How = How.Id, Using = "txtPassword")]
        public IWebElement LossPassword { get; set; }

        [FindsBy(How = How.Id, Using = "ddlPropertyType")]
        public IWebElement PropertyType { get; set; }

        #endregion

        public PasswordConfirmationDlg WaitForScreenToLoad(IWebElement element = null)
        {
        //    WebDriver.WaitForWindowAndSwitch("Password Confirmation", true, 15);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? ReasonForLoss);
            return this;
        }

        public void ConfirmPassword(string pwd = "FirstAmerican")
        {
            Reports.TestStep = "Confirm the password.";
            WaitForScreenToLoad();
            ReasonForLoss.FASelectItemByIndex(10);
            LossExplanation.FASetText("AUT Reason");
            if (Password.IsDisplayed())
            Password.FASetText(AutoConfig.CheckPrintingPassword);
            FastDriver.DialogBottomFrame.ClickDone();
            //WebDriver.SwitchToWindow(Support.FASTWindowName);
        }

        public void EnterPassword()
        {
            WaitForScreenToLoad(element: Password);
            Password.FASetText(AutoConfig.CheckPrintingPassword);
            FastDriver.DialogBottomFrame.ClickDone();
        }

        public void EnterOverdraftReason()
        {
            WaitForScreenToLoad();
            ReasonForLoss.FASelectItemByIndex(10);
            LossExplanation.FASetText("AUT Reason");
            FastDriver.DialogBottomFrame.ClickDone();
        }

        public bool IsOverDraftReasonDialogPresent()
        {
            try
            {
                WebDriver.SwitchTo().DefaultContent();
                this.SwitchToDialogContentFrame();
                return WebDriver.PageSource.Contains("Overdraft Reason");
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        public bool IsPasswordConfirmationDialogPresent()
        {
            try
            {
                WebDriver.SwitchTo().DefaultContent();
                this.SwitchToDialogContentFrame();
                return WebDriver.PageSource.Contains("Password Confirmation");
            }
            catch (WebDriverTimeoutException)
            {
                return false;
            }
        }

        public void Handle()
        {
            if (FastDriver.OverdraftConfirmationDlg.IsOverDraftConfirmationDialogPresent("Overdraft Confirmation"))
            {
                Reports.TestStep = "Click OK on Overdraftdialog.";
                FastDriver.OverdraftConfirmationDlg.WaitForScreenToLoad("Overdraft Confirmation", FastDriver.OverdraftConfirmationDlg.ReasonForLoss);
                FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
            }
            else
            {
                Reports.TestStep = "Enter password confimation details dialog info.";
                FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");
                if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                    FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                FastDriver.DialogBottomFrame.ClickDone();
            }
        }
    }
}
