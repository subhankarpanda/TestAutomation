using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PathDetailsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnDone")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "dgSuccessorTasks_dgSuccessorTasks")]
		public IWebElement TaskTable { get; set; }

		#endregion

	}
}
