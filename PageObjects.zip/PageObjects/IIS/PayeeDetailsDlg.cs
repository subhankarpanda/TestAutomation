using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PayeeDetailsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "lblName")]
		public IWebElement OfficeName { get; set; }

		[FindsBy(How = How.Id, Using = "lblcode")]
		public IWebElement BUIDPane { get; set; }

		[FindsBy(How = How.Id, Using = "Table3")]
		public IWebElement PayeeDetails { get; set; }

		#endregion


        public PayeeDetailsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? BUIDPane);
            return this;
        }

	}
}
