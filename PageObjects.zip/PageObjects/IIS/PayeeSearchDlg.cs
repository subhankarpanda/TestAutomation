using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class PayeeSearchDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "comboOfficeStatus")]
        public IWebElement Display { get; set; }

        [FindsBy(How = How.Id, Using = "Table1")]
        public IWebElement SearchCriteria { get; set; }

        [FindsBy(How = How.Id, Using = "Table2")]
        public IWebElement SearchResults { get; set; }

        [FindsBy(How = How.Id, Using = "rblOfficeAddressBook_1")]
        public IWebElement FileProductionOffices { get; set; }

        [FindsBy(How = How.Id, Using = "rblOfficeAddressBook_0")]
        public IWebElement Office { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_0")]
        public IWebElement Organization { get; set; }

        [FindsBy(How = How.Id, Using = "rblAddressBook_1")]
        public IWebElement OfficeAdressBook { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_0_chkSelect")]
        public IWebElement PayeeName_1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_1_chkSelect")]
        public IWebElement PayeeName_2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_2_chkSelect")]
        public IWebElement PayeeName_3 { get; set; }

        [FindsBy(How = How.Id, Using = "comboRegion")]
        public IWebElement comboRegion { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_3_chkSelect")]
        public IWebElement PayeeName_4 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_4_chkSelect")]
        public IWebElement PayeeName_5 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_5_chkSelect")]
        public IWebElement PayeeName_6 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_6_chkSelect")]
        public IWebElement PayeeName_7 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_7_chkSelect")]
        public IWebElement PayeeName_8 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices_8_chkSelect")]
        public IWebElement PayeeName_9 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridActiveOffices")]
        public IWebElement OfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults_0_chkFABSelect")]
        public IWebElement FABFirstCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults_3_chkFABSelect")]
        public IWebElement FABfourthCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "dGridFABResults")]
        public IWebElement FABResultsTable { get; set; }

        [FindsBy(How = How.Id, Using = "textEntityID")]
        public IWebElement GABIDcode { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFind")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewGABEntry")]
        public IWebElement NewGABEntry{ get; set; }

        [FindsBy(How = How.Id, Using = "dgGAB")]
        public IWebElement GABSearchResultTable { get; set; }

        [FindsBy(How = How.Id, Using = "textEntityName")]
        public IWebElement GABEntityName { get; set; }
        #endregion

        public PayeeSearchDlg WaitForScreenToLoad(string windowName = "Payee Search", IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? SearchCriteria);

            return this;
        }

        /// <summary>
        /// This method selects the search domain before selecting the offices.
        /// </summary>
        /// <param name="office"></param>
        /// <param name="fileProdOffice"></param>
        public void SelectSearchDomain(bool office=true, bool fileProdOffice= false)
        {
            if(office)
            {
                this.Office.FAClick();
            }
            if(fileProdOffice)
            {
                this.FileProductionOffices.FAClick();
            }
        }
    }
}
