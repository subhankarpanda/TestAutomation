using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PaymentConfirmationDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlTypeOfShortage")]
		public IWebElement TypeOfShortage { get; set; }

		[FindsBy(How = How.Id, Using = "optYes")]
		public IWebElement optYes { get; set; }

		[FindsBy(How = How.Id, Using = "optNo")]
		public IWebElement optNo { get; set; }

		[FindsBy(How = How.Id, Using = "ddlEmpResponsibility")]
		public IWebElement EmployeeResponsibility { get; set; }

		[FindsBy(How = How.Id, Using = "ddlProcess")]
		public IWebElement Process { get; set; }

		[FindsBy(How = How.Id, Using = "txtLossExplanation")]
		public IWebElement LossExplanation { get; set; }

		[FindsBy(How = How.Id, Using = "ddlPropertyType")]
		public IWebElement PropertyType { get; set; }

		[FindsBy(How = How.Id, Using = "txtPassword")]
		public IWebElement Password { get; set; }

		#endregion

	}
}
