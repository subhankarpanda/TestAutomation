using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class PaymentDetailsDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlMonthsPrepaidText")]
        public IWebElement MonthPrepaidSelect { get; set; }

        [FindsBy(How = How.Id, Using = "LenderAffiliate")]
        public IWebElement LenderAffiliate { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#USEDEFAULT,#c")]
        public IWebElement USEDEFAULT { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cboSellerPaymentMethod, #selsellerPayMethod")]
        public IWebElement SellerPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#DESCRPTION, #txtDesc, #txtDescription")]
        public IWebElement DESCRPTION { get; set; }

        [FindsBy(How = How.Id, Using = "txtNoOfMonthsPrepaid")]
        public IWebElement NoMonthsPrepaid { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#cboBuyerPaymentMethod, #selBuyPayMethod")]
        public IWebElement BuyerPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#c,#USEDEFAULT")]
        public IWebElement usedefault { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtDescription,#DESCRPTION,#txtDesc")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtLoanEstimatedDesc")]
        public IWebElement LEDescription { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtGfeThirdPartyNameDefault")]
        public IWebElement PayeeNameCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#PAYTO, #txtPaTo, #txtPayTo")]
        public IWebElement PayTo { get; set; }

        [FindsBy(How = How.Id, Using = "UNROUNDED")]
        public IWebElement LoanEstimateUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "ROUNDED")]
        public IWebElement LoanEstimateRounded { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerCharge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cboGFEType")]
        public IWebElement GFEType { get; set; }

        [FindsBy(How = How.Id, Using = "chkLSP")]
        public IWebElement LenderSelectedProvider { get; set; }

        [FindsBy(How = How.Id, Using = "chkPOBOB")]
        public IWebElement PaidonbehalfofBorrower { get; set; }

        [FindsBy(How = How.Id, Using = "chkPPOC")]
        public IWebElement POCEnterPost { get; set; }

        [FindsBy(How = How.Id, Using = "txtPPOCamt")]
        public IWebElement POCAmount { get; set; }

        [FindsBy(How = How.Id, Using = "cboPartialPayMethod")]
        public IWebElement POCPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbySeller")]
        public IWebElement PaidBySeller { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtBuyerCredit' or @id='txtBuyerCdt']")]
        public IWebElement BuyerCredit { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@id='txtSellerCredit' or @id='txtSellercdt']")]
        public IWebElement SellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "UNROUNDED")]
        public IWebElement LoadEstimateUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "ROUNDED")]
        public IWebElement LoadEstimateRounded { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtPBbyBuyerAtClosing, #txtBuyerAtClosing")]
        public IWebElement PaidbyBuyerAtClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtBPbySellerAtClosing, #txtSellerAtClosing")]
        public IWebElement PaidbySellerAtClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtAdditionalDesc,#AdditionalDescription")]
        public IWebElement AdditionalDescription { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#PAYEENAME, #txtGfeThirdPartyNameDefault,#txtPayeeName")]
        public IWebElement PayeeName { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#TOTALCHARGE, #txtTotalCharge")]
        public IWebElement TotalCharge { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#FAFChkBuyerDisplayL, #chkDisplayLCDBuyer")]
        public IWebElement BuyerDisplayLenderOnCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#FAFChkSellerDisplayL")]
        public IWebElement SellerDisplayLenderOnCD { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#chkPartOf[type='checkbox'], #FAFChkPartOf")]
        public IWebElement PartOf { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlPaidbyBuyerClosing, #ddlBuyerAtClosingPayMethod")]
        public IWebElement PaidbyBuyerAtClosingPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlPaidbySellerClosing, #ddlSellerAtClosingPayMethod")]
        public IWebElement PaidbySellerAtClosingPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlOthersBuyer, #ddlBuyerPaidbyOthersPayMethod")]
        public IWebElement BuyerPaidByOthersPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#ddlSellerOthers, #ddlSellerPaidbyOthersPayMethod")]
        public IWebElement SellerPaidByOthersPaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBuyerCredit")]
        public IWebElement BuyerCreditPaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "selPayMethod")]
        public IWebElement PaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerCredit")]
        public IWebElement SellerCreditPaymentMethod { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#chkGfePOBOBFlag, #chkDoubleAsteriskFlag")]
        public IWebElement DoubleAsteriskIndicator { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayLCDBuyer")]
        public IWebElement DisplayLBorrower { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayLCDSeller")]
        public IWebElement DisplayLSeller { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img#BrokenImage")]
        public IWebElement BrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "SectionB")]
        public IWebElement SectionB { get; set; }

        [FindsBy(How = How.Id, Using = "SectionC")]
        public IWebElement SectionC { get; set; }

        [FindsBy(How = How.Id, Using = "SectionH")]
        public IWebElement SectionH { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtBPbyBuyerBeforeClosing, #txtBuyerBeforeClosing")]
        public IWebElement PaidbyBuyerBeforeClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerBeforeClosing")]
        public IWebElement PaidbySellerBeforeClosing { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtOthersSeller, #txtSellerPaidbyOthers")]
        public IWebElement PaidbySellerOthers { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonset']/button/span[text()='Done']")]
        public IWebElement CDDlgDoneButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonset']/button/span[text()='Close']")]
        public IWebElement CDDlgCloseButton { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#txtBPbyOthers, #txtBuyerPaidbyOthers")]
        public IWebElement PaidbyBuyerOthers { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerAtClosing")]
        public IWebElement PaidBySellerAtClosing { get; set; }

        //SRT Team2 r10.2016
        [FindsBy(How = How.Id, Using = "txtSPbySeller")]
        public IWebElement SellerPaidBySeller { get; set; }

        //[FindsBy(How = How.Id, Using = "txtBPbySellerAtClosing")]
        //public IWebElement PaidBySellerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtGfeThirdPartyNameDefault")]
        public IWebElement GfeThirdPartyNameDefault { get; set; }

        [FindsBy(How = How.Id, Using = "FAFPrimaryPolicyFlag")]
        public IWebElement PrimaryPolicy { get; set; }

        [FindsBy(How = How.Id, Using = "SectionB")]
        public IWebElement SectionBDidNotShopFor { get; set; }

        [FindsBy(How = How.Id, Using = "SectionC")]
        public IWebElement SectionCDidShopFor { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyer")]
        public IWebElement BuyerPaidByBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyLender")]
        public IWebElement BuyerPaidByLender { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='MyModal']//tr[contains(.,'Asterisk for SS')]")]
        public IWebElement AsteriskForSS { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[contains(.,'Asterisk for SS')]")]
        public IWebElement AsteriskForSSinOTCRFeesTTaxesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement DoneButton { get; set; }

        //Added by Rashmi
        [FindsBy(How = How.Id, Using = "chkPrimaryPolicy")]
        public IWebElement PrimaryPolicyChk { get; set; }

        //Added
        [FindsBy(How = How.Id, Using = "FAFPrimaryPolicyFlag")]
        public IWebElement FeeEntryPrimaryPolicyChk { get; set; }
        #endregion

        public PaymentDetailsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? Description);
            return this;
        }

        public PaymentDetailsDlg WaitForScreenToLoad(string windowName, IWebElement element = null)
        {
            //TODO: Get rid of this method, no longer needed.
            return this.WaitForScreenToLoad(element);
        }

        public PaymentDetailsDlg EnterPaymentDetails(string description = null, string buyerCharge = null, string sellerCharge = null)
        {
            this.SwitchToDialogContentFrame();
            if (description != string.Empty)
            {
                Description.FASetText(description);
                Description.SendKeys(FAKeys.Tab);
            }
            if (buyerCharge != string.Empty)
            {
                BuyerCharge.FASetText(buyerCharge);
                BuyerCharge.SendKeys(FAKeys.Tab);
            }
            if (sellerCharge != string.Empty)
            {
                SellerCharge.FASetText(sellerCharge);
                SellerCharge.SendKeys(FAKeys.Tab);
            }

            return this;
        }

        public PaymentDetailsDlg EnterPaymentDetails(PaymentDetailsParameters details, bool autoUpdateChargesSum = true)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Description);

            // check if data == null is already handled in extension methods: FASetText, etc.
            // sidney: we're in process of making this looks cleaner

            if (!String.IsNullOrEmpty(details.AdditionalDescription))
            {
                AdditionalDescription.FASetText(details.AdditionalDescription);
            }

            if (details.UpdateDescription != null && details.UpdateDescription == true)
                Description.FASetText(details.ChargeDescription);

            USEDEFAULT.FASetCheckbox(details.UseDefaultModify);

            if (details.SectionBdidnotShopFor == true)
                SectionBDidNotShopFor.FASetCheckbox(true);

            LenderAffiliate.FASetCheckbox(details.LenderAffiliate);

            if (details.SectionCDidShopFor == true)
                SectionCDidShopFor.FASetCheckbox(true); ;

            if (details.SectionHOtherCosts == true)
                SectionH.FASetCheckbox(true);

            if (details.LEDescription != null)
                FastDriver.PaymentDetailsDlg.LEDescription.FASetText(details.LEDescription, continueOnFailure: true);

            //if (details.UseDefaultModify.HasValue && details.UseDefaultModify == true)
            //    usedefault.FASetCheckbox(details.UseDefaultChecked);
            FastDriver.PaymentDetailsDlg.PartOf.FASetCheckbox(details.PartOfCheckbox);

            if (details.PayTo != string.Empty)
                PayTo.FASetText(details.PayTo);

            if (details.PayeeName != string.Empty)
                PayeeName.FASetText(details.PayeeName);

            if (details.LoanEstimateUnrounded.HasValue)
                LoadEstimateUnrounded.FASetText(details.LoanEstimateUnrounded.ToString());

            if (details.LoanEstimateRounded.HasValue)
                LoadEstimateRounded.FASetText(details.LoanEstimateRounded.ToString());

            if (details.BuyerAtClosing.HasValue)
                PaidbyBuyerAtClosing.FASetText(details.BuyerAtClosing.ToString());

            if (details.BuyerChargePaymentMethod != null)
                PaidbyBuyerAtClosingPaymentMethod.FASelectItem(details.BuyerChargePaymentMethod);

            if (details.BuyerBeforeClosing.HasValue)
                PaidbyBuyerBeforeClosing.FASetText(details.BuyerBeforeClosing.ToString());

            if (details.BuyerPaidbyOther.HasValue)
                PaidbyBuyerOthers.FASetText(details.BuyerPaidbyOther.ToString());

            if (details.BuyerPaidbyOtherPaymentMethod != null)
                BuyerPaidByOthersPaymentMethod.FASelectItem(details.BuyerPaidbyOtherPaymentMethod);

            if (details.BuyerDoubleAsteriskChecked != null)
                DoubleAsteriskIndicator.FASetCheckbox(details.BuyerDoubleAsteriskChecked);

            if (details.BuyerCredit.HasValue)
                BuyerCredit.FASetText(details.BuyerCredit.ToString());

            if (details.BuyerCreditPaymentMethod != null)
                BuyerCreditPaymentMethod.FASelectItem(details.BuyerCreditPaymentMethod);

            if (details.BuyerLenderCheckbox != null)
                BuyerDisplayLenderOnCD.FASetCheckbox(details.BuyerLenderCheckbox);

            if (details.SellerPaidAtClosing.HasValue)
                PaidbySellerAtClosing.FASetText(details.SellerPaidAtClosing.ToString());

            if (details.SellerChargePaymentMethod != null)
                SellerPaymentMethod.FASelectItem(details.SellerChargePaymentMethod);

            if (details.SellerLenderCheckbox != null)
                SellerDisplayLenderOnCD.FASetCheckbox(details.SellerLenderCheckbox);

            if (details.SellerPaidBeforeClosing.HasValue)
                PaidbySellerBeforeClosing.FASetText(details.SellerPaidBeforeClosing.ToString());

            if (details.SellerPaidbyOthers.HasValue)
                PaidbySellerOthers.FASetText(details.SellerPaidbyOthers.ToString());

            if (details.SellerPaidbyOtherPaymentMthd != null)
                SellerPaidByOthersPaymentMethod.FASelectItem(details.SellerPaidbyOtherPaymentMthd);

            if (details.SellerCredit.HasValue)
                SellerCredit.FASetText(details.SellerCredit.ToString());
            
            if(details.SellerCreditPaymentMethod != null)
                SellerCreditPaymentMethod.FASelectItem(details.SellerCreditPaymentMethod);

            double? TotalBuyerCharge, TotalSellerCharge;
            if (!details.BuyerAtClosing.HasValue)
                details.BuyerAtClosing = 0;

            if (!details.BuyerBeforeClosing.HasValue)
                details.BuyerBeforeClosing = 0;

            if (!details.BuyerPaidbyOther.HasValue)
                details.BuyerPaidbyOther = 0;

            TotalBuyerCharge = details.BuyerAtClosing + details.BuyerBeforeClosing + details.BuyerPaidbyOther;
            if (BuyerCharge.Enabled && autoUpdateChargesSum)
                BuyerCharge.FASetText(TotalBuyerCharge.ToString());

            if (!details.SellerPaidAtClosing.HasValue)
                details.SellerPaidAtClosing = 0;

            if (!details.SellerPaidBeforeClosing.HasValue)
                details.SellerPaidBeforeClosing = 0;

            if (!details.SellerPaidbyOthers.HasValue)
                details.SellerPaidbyOthers = 0;

            if (details.Description != string.Empty)
                DESCRPTION.FASetText(details.Description);


            if (details.NoMonthsPrepaid != string.Empty)
                NoMonthsPrepaid.FASetText(details.NoMonthsPrepaid);

            if (details.AdditionalDescription != string.Empty)
                AdditionalDescription.FASetText(details.AdditionalDescription);

            TotalSellerCharge = details.SellerPaidAtClosing + details.SellerPaidBeforeClosing + details.SellerPaidbyOthers;
            if (SellerCharge.Enabled && autoUpdateChargesSum)
                SellerCharge.FASetText(TotalSellerCharge.ToString());

            FastDriver.DialogBottomFrame.ClickDone();
            return this;
        }

        public PaymentDetailsDlg AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false)
        {
            string alertText = "";
            try
            {
                WebDriver.WaitForAlertToExist(5);
                var alert = WebDriver.SwitchTo().Alert();
                alertText = alert.Text;
                alert.Accept();
                if (SwitchToWindow)
                    WebDriver.SwitchToWindow(SeleniumInternalHelpersSupportLibrary.Support.FASTWindowName);
            }
            catch (Exception)
            {
                alertText = "No Alert was Found";
            }
            finally
            {
                if (CompareWith != null)
                {
                    SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
                }

            }
            return this;
        }

        public bool VerifyBrokenImage()
        {
            try
            {
                if (BrokenImage.Displayed)
                    return true;
                else
                    return false;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public string EnterPaymentDetailsData(bool SetBuyerSellerCredit = false)
        {

            WaitForScreenToLoad();
            this.SwitchToDialogContentFrame();
            Description.FASetText("ChargeDescriptionEdited");
            usedefault.FASetCheckbox(false);
            string CurrentPayeeName = PayeeName.FAGetValue();
            PayeeName.FASetText("EditedPayeeName");
            PartOf.FASetCheckbox(true);
            LoadEstimateUnrounded.FASetText("$5,000.50");
            LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
            LoadEstimateUnrounded.FASetText("$5,000.49");
            LoadEstimateRounded.SendKeys(FAKeys.Tab);
            LoadEstimateRounded.FASetText("$10,000.00");
            LoadEstimateRounded.SendKeys(FAKeys.Tab);
            BuyerCharge.FASetText("$3,000.00");
            PaidbyBuyerAtClosing.FASetText("$0.00");
            PaidbyBuyerBeforeClosing.FASetText("$2,000.00");
            SellerCharge.FASetText("$4,000.00");
            PaidbySellerAtClosing.FASetText("$0.00");
            PaidbySellerBeforeClosing.FASetText("$3,000.00");
            PaidbyBuyerOthers.FASetText("$1,000.00");
            PaidbySellerOthers.FASetText("$1,000.00");
            if (SetBuyerSellerCredit)
            {
                BuyerCredit.FASetText("$1,000.00");
                SellerCredit.FASetText("$2,000.00");
            }
            return CurrentPayeeName;
        }

        public string EnterPaymentDetailsDataForDisbursement(bool SetBuyerSellerCredit = false)
        {

            WaitForScreenToLoad();
            this.SwitchToDialogContentFrame();
            Description.FASetText("ChargeDescriptionEdited");
            usedefault.FASetCheckbox(false);
            string CurrentPayeeName = PayeeName.FAGetValue();
            PayeeName.FASetText("EditedPayeeName");
            PartOf.FASetCheckbox(true);
            LoadEstimateUnrounded.FASetText("$5,000.50");
            LoadEstimateUnrounded.SendKeys(FAKeys.Tab);
            LoadEstimateUnrounded.FASetText("$5,000.49");
            LoadEstimateRounded.SendKeys(FAKeys.Tab);
            LoadEstimateRounded.FASetText("$10,000.00");
            LoadEstimateRounded.SendKeys(FAKeys.Tab);
            BuyerCharge.FASetText("$5,000.00");
            PaidbyBuyerAtClosing.FASetText("$4,000.00");
            PaidbyBuyerBeforeClosing.FASetText("$0.00");
            SellerCharge.FASetText("$6,000.00");
            PaidbySellerAtClosing.FASetText("$5,000.00");
            PaidbySellerBeforeClosing.FASetText("$0.00");
            PaidbyBuyerOthers.FASetText("$1,000.00");
            PaidbySellerOthers.FASetText("$1,000.00");
            if (SetBuyerSellerCredit)
            {
                BuyerCredit.FASetText("$1,000.00");
                SellerCredit.FASetText("$2,000.00");
            }
            return CurrentPayeeName;
        }

        public void EnterValuesInPPD(PDD obj)
        {
            this.SwitchToDialogContentFrame();

            PaymentDetailsParameters details = new PaymentDetailsParameters();
            if (obj.PDDDescription != string.Empty)
            {
                details.UpdateDescription = true;
                details.ChargeDescription = obj.PDDDescription;
            }
            details.SectionBdidnotShopFor = obj.SectionBdidnotShopFor;
            details.LenderAffiliate = obj.LenderAffiliate;
            details.SectionCDidShopFor = obj.SectionCDidShopFor;
            details.SectionHOtherCosts = obj.SectionHOtherCosts;
            details.UseDefaultModify = obj.UseDefaultModify;
            details.PayTo = obj.PayTo;
            details.PayeeName = obj.PayeeName;
            details.LoanEstimateUnrounded = obj.LoanEstimateUnrounded;
            details.LoanEstimateRounded = obj.LoanEstimateRounded;
            details.BuyerAtClosing = obj.BuyerAtClosing;
            details.BuyerChargePaymentMethod = obj.BuyerChargePaymentMethod;
            details.BuyerBeforeClosing = obj.BuyerBeforeClosing;
            details.BuyerPaidbyOther = obj.BuyerPaidbyOther;
            details.BuyerPaidbyOtherPaymentMethod = obj.BuyerPaidbyOtherPaymentMethod;
            details.BuyerCredit = obj.BuyerCredit;
            details.BuyerCreditPaymentMethod = obj.BuyerCreditPaymentMethod;
            details.SellerPaidAtClosing = obj.SellerPaidAtClosing;
            details.SellerChargePaymentMethod = obj.SellerChargePaymentMethod;
            details.SellerPaidBeforeClosing = obj.SellerPaidBeforeClosing;
            details.SellerPaidbyOthers = obj.SellerPaidbyOthers;
            details.SellerPaidbyOtherPaymentMthd = obj.SellerPaidbyOtherPaymentMthd;
            details.SellerCredit = obj.SellerCredit;
            details.SellerCreditPaymentMethod = obj.SellerCreditPaymentMethod;
            details.BuyerDoubleAsteriskChecked = obj.BuyerDoubleAsteriskChecked;
            details.AdditionalDescription = obj.AdditionalDescription;

            EnterPaymentDetails(details);

        }

        public PaymentDetailsDlg CalculateBuyerSellerCharge(string BuyerSellerToolTip)
        {


            string BuyerCharge;
            string BuyerTooltip;
            string SellerCharge;
            string SellerTooltip;
            double BuyerCharge_PDD;
            double BuyerPAC = Convert.ToDouble(PaidbyBuyerAtClosing.FAGetValue().Replace("$", ""));
            double BuyerPBC = Convert.ToDouble(PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", ""));
            double BuyerPBO = Convert.ToDouble(PaidbyBuyerOthers.FAGetValue().Replace("$", ""));

            BuyerCharge_PDD = (BuyerPAC + BuyerPBC + BuyerPBO);
            BuyerCharge = BuyerCharge_PDD.ToString().FormatAsMoney();

            string Formatted_B_PAC = BuyerPAC.ToString().FormatAsMoney();
            string Formatted_B_PBC = BuyerPBC.ToString().FormatAsMoney();
            string Formatted_B_PBO = BuyerPBO.ToString().FormatAsMoney();


            string B_PAC_PM = PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
            string B_PBO_PM = BuyerPaidByOthersPaymentMethod.FAGetSelectedItem();
            string DefaultBuyerToolTip = BuyerSellerToolTip.Split('\n')[0];
            if (Formatted_B_PAC == "0.00" && Formatted_B_PBC == "0.00" && Formatted_B_PBO == "0.00")
            {
                BuyerTooltip = DefaultBuyerToolTip;
            }
            else if (B_PBO_PM == "")
            {
                BuyerTooltip = "Buyer: " + B_PAC_PM + "- $" + Formatted_B_PAC + ", POC-B- $" + Formatted_B_PBC;
            }
            else
            {
                BuyerTooltip = "Buyer: " + B_PAC_PM + "- $" + Formatted_B_PAC + ", POC-B- $" + Formatted_B_PBC + ", " + B_PBO_PM + "- $" + Formatted_B_PBO;
            }


            double SellerPAC = Convert.ToDouble(PaidbySellerAtClosing.FAGetValue().Replace("$", ""));
            double SellerPBC = Convert.ToDouble(PaidbySellerBeforeClosing.FAGetValue().Replace("$", ""));
            double SellerPBO = Convert.ToDouble(PaidbySellerOthers.FAGetValue().Replace("$", ""));
            string S_PAC_PM = PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
            string S_PBO_PM = SellerPaidByOthersPaymentMethod.FAGetSelectedItem();

            double SellerCharge_PDD = (SellerPAC + SellerPBC + SellerPBO);
            SellerCharge = SellerCharge_PDD.ToString().FormatAsMoney();

            string Formatted_S_PAC = SellerPAC.ToString().FormatAsMoney();
            string Formatted_S_PBC = SellerPBC.ToString().FormatAsMoney();
            string Formatted_S_PBO = SellerPBO.ToString().FormatAsMoney();
            string DefaultSellerToolTip = BuyerSellerToolTip.Split('\n')[1];
            if (Formatted_S_PAC == "0.00" && Formatted_S_PBC == "0.00" && Formatted_S_PBO == "0.00")
            {
                SellerTooltip = DefaultSellerToolTip;
            }
            else if (S_PBO_PM == "")
            {
                SellerTooltip = "Seller: " + S_PAC_PM + "- $" + Formatted_S_PAC + ", POC-S- $" + Formatted_S_PBC;

            }
            else
            {
                SellerTooltip = "Seller: " + S_PAC_PM + "- $" + Formatted_S_PAC + ", POC-S- $" + Formatted_S_PBC + ", " + S_PBO_PM + "- $" + Formatted_S_PBO;

            }
            return this;
        }

        public string CalculateBuyerCharge()
        {

            double BuyerPAC = Convert.ToDouble(PaidbyBuyerAtClosing.FAGetValue().Replace("$", ""));
            double BuyerPBC = Convert.ToDouble(PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", ""));
            double BuyerPBO = Convert.ToDouble(PaidbyBuyerOthers.FAGetValue().Replace("$", ""));

            double BuyerCharge_PDD = (BuyerPAC + BuyerPBC + BuyerPBO);
            return BuyerCharge_PDD.ToString().FormatAsMoney();

        }

        public string CalculateSellerCharge()
        {
            double SellerPAC = Convert.ToDouble(PaidbySellerAtClosing.FAGetValue().Replace("$", ""));
            double SellerPBC = Convert.ToDouble(PaidbySellerBeforeClosing.FAGetValue().Replace("$", ""));
            double SellerPBO = Convert.ToDouble(PaidbySellerOthers.FAGetValue().Replace("$", ""));

            double SellerCharge_PDD = (SellerPAC + SellerPBC + SellerPBO);
            return SellerCharge_PDD.ToString().FormatAsMoney();

        }

        public PaymentDetailsDlg VerifyHeaderDetails(string description = null, string additionalDescription = null, string payTo = null, string payeeName = null, double? totalCharge = null)
        {
            this.SwitchToDialogContentFrame();

            if (description != null) Support.AreEqual(description, DESCRPTION.FAGetValue(), "Description");
            if (additionalDescription != null) Support.AreEqual(additionalDescription, AdditionalDescription.FAGetValue(), "Addtl Description");
            if (totalCharge.HasValue) Support.AreEqual(totalCharge.Value.ToString().FormatAsMoney(true), TotalCharge.FAGetValue(), "Total Charge");
            if (payTo != null) Support.AreEqual(payTo, PayTo.FAGetValue(), "Pay To");
            if (payeeName != null) Support.AreEqual(payeeName, PayeeName.FAGetValue(), "Payee Name");

            return this;
        }

        public PaymentDetailsDlg VerifyPaidByCharges(double? paidbyBuyerBeforeClosing = null, double? paidbyBuyerAtClosing = null, string paidbyBuyerAtClosingPaymentMethod = null, double? paidbyBuyerOthers = null, string buyerPaidByOthersPaymentMethod = null,
            double? paidbySellerBeforeClosing = null, double? paidbySellerAtClosing = null, string paidbySellerAtClosingPaymentMethod = null, double? paidbySellerOthers = null, string sellerPaidByOthersPaymentMethod = null)
        {
            this.SwitchToDialogContentFrame();

            if (paidbyBuyerBeforeClosing.HasValue) Support.AreEqual(paidbyBuyerBeforeClosing.Value.ToString().FormatAsMoney(true), PaidbyBuyerBeforeClosing.FAGetValue(), "Paid by Buyer Before Closing");
            if (paidbyBuyerAtClosing.HasValue) Support.AreEqual(paidbyBuyerAtClosing.Value.ToString().FormatAsMoney(true), PaidbyBuyerAtClosing.FAGetValue(), "Paid by Buyer At Closing");
            if (paidbyBuyerAtClosingPaymentMethod != null) Support.AreEqual(paidbyBuyerAtClosingPaymentMethod.ToUpper(), PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToUpper(), "Paid by Buyer At Closing Payment Method");
            if (paidbyBuyerOthers.HasValue) Support.AreEqual(paidbyBuyerOthers.Value.ToString().FormatAsMoney(true), PaidbyBuyerOthers.FAGetValue(), "Paid by Buyer Others");
            if (buyerPaidByOthersPaymentMethod != null) Support.AreEqual(buyerPaidByOthersPaymentMethod.ToUpper(), BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToUpper(), "Paid by Buyer Others Payment Method");
            if (paidbySellerBeforeClosing.HasValue) Support.AreEqual(paidbySellerBeforeClosing.Value.ToString().FormatAsMoney(true), PaidbySellerBeforeClosing.FAGetValue(), "Paid by Seller Before Closing");
            if (paidbySellerAtClosing.HasValue) Support.AreEqual(paidbySellerAtClosing.Value.ToString().FormatAsMoney(true), PaidbySellerAtClosing.FAGetValue(), "Paid by Seller Others");
            if (paidbySellerAtClosingPaymentMethod != null) Support.AreEqual(paidbySellerAtClosingPaymentMethod.ToUpper(), PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToUpper(), "Paid by Seller Others Payment Method");
            if (paidbySellerOthers.HasValue) Support.AreEqual(paidbySellerOthers.Value.ToString().FormatAsMoney(true), PaidbySellerOthers.FAGetValue(), "Paid by Seller Others");
            if (sellerPaidByOthersPaymentMethod != null) Support.AreEqual(sellerPaidByOthersPaymentMethod.ToUpper(), SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToUpper(), "Paid by Seller Others Payment Method");

            return this;
        }

        public void PaymentDetailsPaidByBorrowerBeforeClosing(string ChargeAmount)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details");
            FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
            FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText(ChargeAmount);
            FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText(ChargeAmount);
            FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded.FASetText(ChargeAmount);
            Reports.TestStep = "Click Done";
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
        }


        //public PaymentDetailsDlg VerifyPaymentDetails(string desc = null, string additionalDescription = null, string payTo = null, string payeeName = null, double? totalCharge = null,
        //    double? paidbyBuyerBeforeClosing = null)
        //{
        //    this.SwitchToDialogContentFrame();

        //    Support.AreEqual("New Home Rate (Title Only)", DESCRPTION.FAGetValue(), "Description");
        //    Support.AreEqual("", AdditionalDescription.FAGetValue(), "Addtl Description");
        //    Support.AreEqual("$4.98", TotalCharge.FAGetValue(), "Total Charge");
        //    Support.AreEqual(AutoConfig.SelectedOfficeName, PayTo.FAGetValue(), "Pay To");
        //    Support.AreEqual(AutoConfig.SelectedOfficeName, PayeeName.FAGetValue(), "Payee Name");

        //    Support.AreEqual(@"True", PaidbyBuyerBeforeClosing.FAGetValue(), "Paid by Buyer Before Closing");
        //    Support.AreEqual(@"True", PaidbyBuyerOthers.FAGetValue(), "Paid by Buyer Others");
        //    Support.AreEqual(@"Fee", PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), "Buyer Payment Method");
        //    Support.AreEqual(@"True", PaidbySellerBeforeClosing.FAGetValue(), "Paid by Buyer Before Closing");
        //    Support.AreEqual(@"True", PaidbySellerOthers.FAGetValue(), "Paid by Seller Others");
        //    Support.AreEqual(@"Fee", PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), "Seller Payment Method");

        //    Support.AreEqual(@"True", PaidbyBuyerAtClosing.Enabled.ToString(), "PaidbyBuyerAtClosing");
        //    Support.AreEqual(@"True", PaidbyBuyerOthers.Enabled.ToString(), "PaidbyBuyerOthers");
        //    Support.AreEqual(@"True", PaidbyBuyerAtClosingPaymentMethod.Enabled.ToString(), "PaidbyBuyerAtClosingPaymentMethod");
        //    Support.AreEqual(@"True", PaidbyBuyerOthers.Enabled.ToString(), "PaidbyBuyerOthers");
        //    Support.AreEqual(@"True", BuyerPaidByOthersPaymentMethod.Enabled.ToString(), "BuyerPaidByOthersPaymentMethod");
        //    Support.AreEqual(@"True", PaidbySellerAtClosing.Enabled.ToString(), "PaidbySellerAtClosing");
        //    Support.AreEqual(@"True", PaidbySellerAtClosingPaymentMethod.Enabled.ToString(), "PaidbySellerAtClosingPaymentMethod");
        //    Support.AreEqual(@"True", PaidbySellerOthers.Enabled.ToString(), "PaidbySellerOthers");
        //    Support.AreEqual(@"True", SellerPaidByOthersPaymentMethod.Enabled.ToString(), "SellerPaidByOthersPaymentMethod");
        //    Support.AreEqual(@"True", PaidbySellerAtClosing.Enabled.ToString(), "PaidbySellerAtClosing");

        //    return this;
        //}


    }
}
