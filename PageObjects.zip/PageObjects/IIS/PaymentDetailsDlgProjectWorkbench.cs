﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class PaymentDetailsDlgProjectWorkbench : PageObject
    {
        #region WebElements

       

        [FindsBy(How = How.Id, Using = "txtAddDescription")]
        public IWebElement AdditionalDescription { get; set; }

        [FindsBy(How = How.Id, Using = "divMainPDD")]
        public IWebElement PDDTable { get; set; }

        [FindsBy(How = How.Id, Using = "txtTotalCharge")]
        public IWebElement TotalCharge { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='ui-button-text'][contains(text(),Done")]
        public IWebElement PDDDone { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@class='ui-button-text'][contains(text(),Cancel")]
        public IWebElement PDDCancel { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@ClassName='ui-dialog-buttonset')/button[2]")]
        public IWebElement done { get; set; }

        [FindsBy(How = How.ClassName, Using = "ui-dialog-buttonset")]
        public IWebElement PDDdone1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtPayToFee")]
        public IWebElement PayTo { get; set; }

        [FindsBy(How = How.Id, Using = "txtPayeeName")]
        public IWebElement PayeeName { get; set; }





        #endregion

        #region Services
        public PaymentDetailsDlgProjectWorkbench WaitForScreentoLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("Payment Details", true, 10);
            return this;
        }

        #endregion
    }
}
