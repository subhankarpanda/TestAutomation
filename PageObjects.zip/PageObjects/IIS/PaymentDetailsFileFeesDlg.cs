using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class PaymentDetails : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtDesc")]
        public IWebElement Desc { get; set; }

        [FindsBy(How = How.Id, Using = "txtTotalCharge")]
        public IWebElement TotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtAdditionalDesc")]
        public IWebElement AdditionalDesc { get; set; }


        [FindsBy(How = How.CssSelector, Using = "#txtLoanEstimatedDesc")]
        public IWebElement LEDesc { get; set; }

        [FindsBy(How = How.Id, Using = "txtPaTo")]
        public IWebElement PaTo { get; set; }

        [FindsBy(How = How.Id, Using = "txtPayeeName")]
        public IWebElement PayeeNameCD { get; set; }
        

        [FindsBy(How = How.Id, Using = "txtGfeThirdPartyNameDefault")]
        public IWebElement GfeThirdPartyNameDefault { get; set; }

        [FindsBy(How = How.Id, Using = "UNROUNDED")]
        public IWebElement LEUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "FAFChkPartOf")]
        public IWebElement PartOf { get; set; }

        [FindsBy(How = How.Id, Using = "ROUNDED")]
        public IWebElement LERounded { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img#BrokenImage")]
        public IWebElement BrokenImage { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerAtClosing")]
        public IWebElement BuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerBeforeClosing")]
        public IWebElement BuyerBeforeClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerPaidbyOthers")]
        public IWebElement BuyerPaidByOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBuyerAtClosingPayMethod")]
        public IWebElement BuyerAtClosingPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBuyerPaidbyOthersPayMethod")]
        public IWebElement BuyerPaidbyOthersPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "selGfeEntryTypeCdID")]
        public IWebElement selGfeEntryTypeCdID { get; set; }

        [FindsBy(How = How.Id, Using = "chkGfeLenderDirectedFlag")]
        public IWebElement GfeLenderDirectedFlag { get; set; }

        [FindsBy(How = How.Id, Using = "chkGfePOBOBFlag")]
        public IWebElement GfePOBOBFlag { get; set; }


        [FindsBy(How = How.Id, Using = "chkDoubleAsteriskFlag")]
        public IWebElement DoubleAsteriskFlag { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyBuyer")]
        public IWebElement BPbyBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyLender")]
        public IWebElement BPbyLender { get; set; }

        [FindsBy(How = How.Id, Using = "selBuyPayMethod")]
        public IWebElement selBuyPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyMB")]
        public IWebElement BPbyMB { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerCharge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerAtClosing")]
        public IWebElement SellerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerBeforeClosing")]
        public IWebElement SellerBeforeClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerPaidbyOthers")]
        public IWebElement SellerPaidbyOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerAtClosingPayMethod")]
        public IWebElement SellerAtClosingPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerPaidbyOthersPayMethod")]
        public IWebElement SellerPaidbyOthersPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbySeller")]
        public IWebElement SPbySeller { get; set; }

        [FindsBy(How = How.Id, Using = "selsellerPayMethod")]
        public IWebElement selsellerPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbyLender")]
        public IWebElement SPbyLender { get; set; }

        [FindsBy(How = How.Id, Using = "txtSPbyMB")]
        public IWebElement SPbyMB { get; set; }

        [FindsBy(How = How.Id, Using = "FAFChkBuyerDisplayL")]
        public IWebElement BuyerDisplayL { get; set; }

        [FindsBy(How = How.Id, Using = "FAFChkSellerDisplayL")]
        public IWebElement SellerDisplayL { get; set; }

        [FindsBy(How = How.Id, Using = "LenderAffiliate")]
        public IWebElement LenderAffiliate { get; set; }

        [FindsBy(How = How.Id, Using = "SectionB")]
        public IWebElement SectionB { get; set; }

        [FindsBy(How = How.Id, Using = "SectionC")]
        public IWebElement SectionC { get; set; }

        [FindsBy(How = How.Id, Using = "SectionH")]
        public IWebElement SectionH { get; set; }

        [FindsBy(How = How.Id, Using = "FAFPrimaryPolicyFlag")]
        public IWebElement PrimaryPolicy { get; set; }

        #endregion
        public PaymentDetails WaitForScreenToLoad()
        {
            WebDriver.WaitForWindowAndSwitch("Payment Details", true, 5);
            this.SwitchToDialogContentFrame();

            this.WaitCreation(Desc);
            return this;
        }

        public PaymentDetails EnterPaymentDetails(string description, string buyerCharge, string sellerCharge)
        {
            this.SwitchToDialogContentFrame();

            Desc.FASetText(description);
            Desc.SendKeys(FAKeys.Tab);
            BuyerCharge.FASetText(buyerCharge);
            BuyerCharge.SendKeys(FAKeys.Tab);
            SellerCharge.FASetText(sellerCharge);
            SellerCharge.SendKeys(FAKeys.Tab);
            return this;
        }

        public void VerifyLoanEstimateDescTitleFeeinPDD(string FeeType, string FeeDesc)
        {
            Reports.TestStep = "VERIFY LOANESTIMATE DESCRIPTION IS PREPENDED WITH TITLE FOLLOWED BY FEE DESCRIPTION";
            if (FeeType != "OwnerPolicy")
            {
                Support.AreEqual("Title - " + FeeDesc, LEDesc.GetAttribute("value"));//get attribute value instead of text
            }
            else
            {
                Support.AreEqual("Title - Owner's Title Insurance (optional)", LEDesc.GetAttribute("value"));//get attribute value instead of text
            }
        }

        public bool VerifyBrokenImage()
        {
            try
            {
                if (BrokenImage.Displayed)
                    return true;
                else
                    return false;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public PaymentDetails VerifyHeaderDetails(string description = null, string additionalDescription = null, string payTo = null, string payeeName = null, double? totalCharge = null)
        {
            this.SwitchToDialogContentFrame();

            if (description != null) Support.AreEqual(description, Desc.FAGetValue(), "Description");
            if (additionalDescription != null) Support.AreEqual(additionalDescription, AdditionalDesc.FAGetValue(), "Addtl Description");
            if (totalCharge.HasValue) Support.AreEqual(totalCharge.Value.ToString().FormatAsMoney(true), TotalCharge.FAGetValue(), "Total Charge");
            if (payTo != null) Support.AreEqual(payTo, PaTo.FAGetValue(), "Pay To");
            if (payeeName != null) Support.AreEqual(payeeName, GfeThirdPartyNameDefault.FAGetValue(), "Payee Name");

            return this;
        }

        public PaymentDetails VerifyPaidByCharges(double? paidbyBuyerAtClosing = null, string paidbyBuyerAtClosingPaymentMethod = null, double? paidbyBuyerOthers = null, double? buyerPaidByMortgageBroker = null,
            double? paidbySellerAtClosing = null, string paidbySellerAtClosingPaymentMethod = null, double? paidbySellerOthers = null, double? sellerPaidByMortgageBroker = null)
        {
            this.SwitchToDialogContentFrame();

            if (paidbyBuyerAtClosing.HasValue) Support.AreEqual(paidbyBuyerAtClosing.Value.ToString().FormatAsMoney(true), BPbyBuyer.FAGetValue(), "Paid by Buyer At Closing");
            if (paidbyBuyerAtClosingPaymentMethod != null) Support.AreEqual(paidbyBuyerAtClosingPaymentMethod.ToUpper(), selBuyPayMethod.FAGetSelectedItem().ToUpper(), "Paid by Buyer At Closing Payment Method");
            if (paidbyBuyerOthers.HasValue) Support.AreEqual(paidbyBuyerOthers.Value.ToString().FormatAsMoney(true), BPbyLender.FAGetValue(), "Paid by Buyer Others");
            if (buyerPaidByMortgageBroker != null) Support.AreEqual(buyerPaidByMortgageBroker.Value.ToString().FormatAsMoney(true), BPbyMB.FAGetValue(), "Buyer Paid by Mortgage Broker");
            if (paidbySellerAtClosing.HasValue) Support.AreEqual(paidbySellerAtClosing.Value.ToString().FormatAsMoney(true), SPbySeller.FAGetValue(), "Paid by Seller Others");
            if (paidbySellerAtClosingPaymentMethod != null) Support.AreEqual(paidbySellerAtClosingPaymentMethod.ToUpper(), selsellerPayMethod.FAGetSelectedItem().ToUpper(), "Paid by Seller Others Payment Method");
            if (paidbySellerOthers.HasValue) Support.AreEqual(paidbySellerOthers.Value.ToString().FormatAsMoney(true), SPbyLender.FAGetValue(), "Paid by Seller Others");
            if (sellerPaidByMortgageBroker != null) Support.AreEqual(sellerPaidByMortgageBroker.Value.ToString().FormatAsMoney(true), SPbyMB.FAGetValue(), "Seller Paid by Mortgage Broker");

            return this;
        }
    }
}
