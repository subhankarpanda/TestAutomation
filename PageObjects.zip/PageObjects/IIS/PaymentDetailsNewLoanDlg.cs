using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PaymentDetailsNewLoanDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDescription")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileCharge")]
		public IWebElement FileCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cboPaymentMethod")]
		public IWebElement PaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "chkDisplayLCDBuyer")]
		public IWebElement DisplayLOnCD { get; set; }

        [FindsBy(How = How.Id, Using = "chk")]
		public IWebElement UseDefault { get; set; }

        [FindsBy(How = How.Id, Using = "USEDEFAULT")]
        public IWebElement UseDefaultChkBox { get; set; }

        [FindsBy(How = How.Id, Using = "txtPayTo")]
		public IWebElement PayTo { get; set; }

        [FindsBy(How = How.Id, Using = "PAYEENAME")]
        public IWebElement PayeeName { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerCredit")]
        public IWebElement SellerCreditPaymentMethod { get; set; }
        
		#endregion

        public PaymentDetailsNewLoanDlg WaitForScreenToLoad(string windowName = "Payment Details")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Description);
            return this;
        }
	}
}
