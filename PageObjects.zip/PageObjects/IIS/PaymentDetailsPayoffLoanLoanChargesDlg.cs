﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class PaymentDetailsPayoffLoanLoanChargesDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "DESCRPTION")]
        public IWebElement Desc { get; set; }

        [FindsBy(How = How.Id, Using = "txtBuyerCharge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtSellerCharge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtPBbyBuyerAtClosing")]
        public IWebElement BuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbySellerAtClosing")]
        public IWebElement SellerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyOthers")]
        public IWebElement BuyerPaidByOthers { get; set; }

        [FindsBy(How = How.Id, Using = "txtOthersSeller")]
        public IWebElement SellerPaidbyOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlPaidbyBuyerClosing")]
        public IWebElement BuyerPaymentMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOthersBuyer")]
        public IWebElement BuyerPaidbyOthersPayMethod { get; set; }

        [FindsBy(How = How.Id, Using = "ddlSellerOthers")]
        public IWebElement SellerPaidbyOthersPayMethod { get; set; }
        
        #endregion 

        public PaymentDetailsPayoffLoanLoanChargesDlg WaitForScreenToLoad()
        {
            WebDriver.WaitForWindowAndSwitch("Payment Details", true, 5);
            this.SwitchToDialogContentFrame();

            this.WaitCreation(Desc);
            return this;
        }
    }
}
