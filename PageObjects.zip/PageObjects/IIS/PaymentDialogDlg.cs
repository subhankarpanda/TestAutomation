using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PaymentDialogDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtDesc")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "txtTotalCharge")]
		public IWebElement TotalCharge { get; set; }

		[FindsBy(How = How.Id, Using = "selPayMethod")]
		public IWebElement PaymentMethod { get; set; }

		[FindsBy(How = How.Id, Using = "cboGFEType")]
		public IWebElement GFEType { get; set; }

		[FindsBy(How = How.Id, Using = "chkLSP")]
		public IWebElement LenderSelectedProvider { get; set; }

		[FindsBy(How = How.Id, Using = "chkPOBOB")]
		public IWebElement PaidonbehalfofBorrower { get; set; }

		#endregion

	}
}
