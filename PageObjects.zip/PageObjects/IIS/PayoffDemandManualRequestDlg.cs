﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;


namespace FASTSelenium.PageObjects.IIS
{
    public class PayoffDemandManualRequestDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "txtDate")]
        public IWebElement Date { get; set; }

        [FindsBy(How = How.Id, Using = "imgCal_txtDate")]
        public IWebElement Calendar { get; set; }

        [FindsBy(How = How.Id, Using = "OK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "Cancel")]
        public IWebElement Cancel { get; set; }
        #endregion

        public PayoffDemandManualRequestDlg WaitForScreenToLoad(string windowName = "Payoff Demand Manual Request")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Date, 5);

            return this;
        }

    }
}
