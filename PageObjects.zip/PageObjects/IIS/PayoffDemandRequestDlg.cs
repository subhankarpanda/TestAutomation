﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;


namespace FASTSelenium.PageObjects.IIS
{
    public class PayoffDemandRequestDlg : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "button1")]
        public IWebElement OKbtn { get; set; }

        [FindsBy(How = How.Id, Using = "//td[contains(text(),'Automatic Payoff Demand Request Initiated']")]
        public IWebElement WarningText { get; set; }
        #endregion

        public PayoffDemandRequestDlg WaitForScreenToLoad(string windowName = "Payoff Demand Request")
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(OKbtn);

            return this;
        }

        public void OK()
        {
            WaitForScreenToLoad();
            OKbtn.Click();
        }
    }
}
