using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;

namespace FASTSelenium.PageObjects.IIS
{
    public class PayoffLoanDetails : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelName")]
        public IWebElement labelone { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelName2")]
        public IWebElement labeltwo { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelName")]
        public IWebElement GabLabelPayee { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tPP")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tRC")]
        public IWebElement RecordingTab { get; set; }

        [FindsBy(How = How.LinkText, Using = "Check Details")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_cmdCheckDetails")]
        public IWebElement CheckDetailsButton { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_txtGABcode")]
        public IWebElement LenderGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_cmdFindName")]
        public IWebElement LenderFind { get; set; }
        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelName")]
        public IWebElement LenderGABName { get; set; }
        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_txtName")]
        public IWebElement LenderName { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_chkEditContactInfo")]
        public IWebElement LenderEditContact { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textBusPhone")]
        public IWebElement LenderBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textBusFax")]
        public IWebElement LenderBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textCellPhone")]
        public IWebElement LenderCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textPager")]
        public IWebElement LenderPager { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textEmailAddress")]
        public IWebElement LenderEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_chkWeeklyEmailStatus")]
        public IWebElement LenderEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_comboAttention")]
        public IWebElement LenderAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_chkEditContactInfo")]
        public IWebElement LenderEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_chkEdit")]
        public IWebElement LenderEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textName")]
        public IWebElement LenderNameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_textReference")]
        public IWebElement LenderReference { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_ddlLT")]
        public IWebElement LenderLoanType { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_txtOPB")]
        public IWebElement OriginalPrincipalBalance { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_btnInvk")]
        public IWebElement RequestDemandStatement { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_chkRAUdt")]
        public IWebElement RestrictDemandUpdates { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusOrgID: Business Party required")]
        public IWebElement BusinessPartyrequired { get; set; }

        [FindsBy(How = How.Id, Using = "lblPB")]
        public IWebElement PrincipalBalanceAmt { get; set; }

        [FindsBy(How = How.LinkText, Using = "$22.12")]
        public IWebElement PrincipalBalancePane { get; set; }

        [FindsBy(How = How.Id, Using = "lblTC")]
        public IWebElement TotalChargeAmt { get; set; }

        [FindsBy(How = How.LinkText, Using = "$20.20")]
        public IWebElement TotalChargePane { get; set; }

        [FindsBy(How = How.LinkText, Using = "$22.12")]
        public IWebElement PayOffAmountPane { get; set; }

        [FindsBy(How = How.LinkText, Using = "$22.12")]
        public IWebElement CheckAmountPane { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblPoA")]
        public IWebElement Payoffamt { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessageList { get; set; }

        [FindsBy(How = How.Id, Using = "lblCA")]
        public IWebElement CheckAmt { get; set; }
        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelName")]
        public IWebElement LenderLabelName { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLD_PLD_bpB_labelContactName")]
        public IWebElement DetailsContactName { get; set; }

        #endregion

        public PayoffLoanDetails Open()
        {
            FastDriver.LeftNavigation.Navigate<PayoffLoanDetails>("Home>Order Entry>Payoff Loan");
            this.WaitForScreenToLoad();

            return this;
        }

        public PayoffLoanDetails WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? LenderGABcode);
            return this;
        }

        public PayoffLoanDetails FillDetailsForm(string lenderGABCode, string principalBalance)
        {
            this.SwitchToContentFrame();
            SearchGAB(lenderGABCode);
            WaitForGABCode(lenderGABCode);
            OriginalPrincipalBalance.FASetText(principalBalance);
            return this;
        }

        public PayoffLoanDetails SearchGAB(string lenderGABCode)
        {
            this.SwitchToContentFrame();
            LenderGABcode.FASetText(lenderGABCode);
            LenderFind.FAClick();
            return this;
        }

        public PayoffLoanDetails WaitForGABCode(string lenderGABCode)
        {
            this.SwitchToContentFrame();
            this.WaitForValue(GABcodeLabel, lenderGABCode);
            return this;
        }

        public PayoffLoanDetails FindGABCode(string GABCode, bool WaitForGabCodeLabel = true)
        {
            // combine SearchGAB() and WaitForGABCode()
            this.SwitchToContentFrame();
            LenderGABcode.FASetText(GABCode);
            LenderFind.FAClick();
            if (WaitForGabCodeLabel)
            {
                Playback.Wait(500);
                this.WaitForValue(GABcodeLabel, GABCode);
            }

            return this;
            //return SearchGAB(GABCode).WaitForGABCode(GABCode);

        }

        public PayoffLoanCharges ClickChargesTab()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ChargesTab);
            ChargesTab.FAClick();
            return FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
        }

        public PayoffLoanParites ClickPartiesTab()
        {
            this.SwitchToContentFrame();
            PartiesTab.FAClick();
            return FastDriver.PayoffLoanParites.WaitForScreeToLoan();
        }

        public PayoffLoanRecording ClickRecordingTab()
        {
            this.SwitchToContentFrame();
            RecordingTab.FAClick();
            return FastDriver.PayoffLoanRecording.WaitForScreeToLoan();
        }
    }

    public class PayoffLoanCharges : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cmdPC")]
        public IWebElement PayChargesBtn { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs")]
        public IWebElement LoanChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs_0_tga")]
        public IWebElement LoanChargesEstimatedUnRounded { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tPP")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tRC")]
        public IWebElement RecordingTab { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_btnPayment")]
        public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_idToolbar")]
        public IWebElement POLCPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs_0_tdsc")]
        public IWebElement LoanChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs_0_tbc")]
        public IWebElement LoanChargesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs_0_tbd")]
        public IWebElement LoanChargesBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs_0_tsc")]
        public IWebElement LoanChargesSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cg_dcs_0_tsr")]
        public IWebElement LoanChargesSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs_0_tga")]
        public IWebElement InterestCalculationLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_dgridIS")]
        public IWebElement InterestCalculationSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cmdNew")]
        public IWebElement InterestCalculationSummaryNew { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_btnPayment")]
        public IWebElement InterestCalculationPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_cboInterestType")]
        public IWebElement InterestCalculationInterestType { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_rdoPerDiem")]
        public IWebElement InterestCalculationPerDiem { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_txtPerDiem")]
        public IWebElement InterestCalculationProrPerDiem { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_txtFromDate")]
        public IWebElement InterestCalculationProrFromDate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_chkInclusiveFrom")]
        public IWebElement InterestCalculationInclusiveFrom { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_cboBasisDays")]
        public IWebElement InterestCalculationBasedonDays { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_rdoPercentRate")]
        public IWebElement InterestCalculationPercentRate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_txtPercentRate")]
        public IWebElement InterestCalculationProrPercentRateval { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_txtToDate")]
        public IWebElement InterestCalculationProrToDate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_chkInclusiveTo")]
        public IWebElement InterestCalculationInclusiveTo { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs_0_tdsc")]
        public IWebElement InterestCalculationChargeDesc { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs_0_tbc")]
        public IWebElement InterestCalculationBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs_0_tbd")]
        public IWebElement InterestCalculationBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs_0_tsc")]
        public IWebElement InterestCalculationSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs_0_tsr")]
        public IWebElement InterestCalculationSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_IPror_CGrid_dcs")]
        public IWebElement InterestCalculationTable { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs")]
        public IWebElement PayoffLoanChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_btnPayment")]
        public IWebElement PayoffLoanChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_0_tdsc")]
        public IWebElement PayoffLoanChargesDescription { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement PencilImage { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_0_tbc")]
        public IWebElement PayoffLoanChargesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_0_tbd")]
        public IWebElement PayoffLoanChargesBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_0_tsc")]
        public IWebElement PayoffLoanChargeSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_0_tsr")]
        public IWebElement PayoffLoanChargeSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_1_tdsc")]
        public IWebElement PayoffLoanChargesDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_1_tbc")]
        public IWebElement PayoffLoanChargesBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_1_tbd")]
        public IWebElement PayoffLoanChargesBuyerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_1_tsc")]
        public IWebElement PayoffLoanChargeSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_1_tsr")]
        public IWebElement PayoffLoanChargeSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_8_tdsc")]
        public IWebElement PayoffLoanChargesDescription8 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_8_tbc")]
        public IWebElement PayoffLoanChargesBuyerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_8_tbd")]
        public IWebElement PayoffLoanChargesBuyerCredit8 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_8_tsc")]
        public IWebElement PayoffLoanChargeSellerCharge8 { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_8_tsr")]
        public IWebElement PayoffLoanChargeSellerCredit8 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPB")]
        public IWebElement PrincipalBalance { get; set; }

        [FindsBy(How = How.Id, Using = "lblTC")]
        public IWebElement TotalCharges { get; set; }

        [FindsBy(How = How.Id, Using = "lblPoA")]
        public IWebElement PayoffAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblCA")]
        public IWebElement CheckAmt { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_0_tga")]
        public IWebElement PayoffLoanChargeLoanEstimate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tLC_PLC_cgLnCgSet_dcs_8_tga")]
        public IWebElement PayoffLoanChargeLoanEstimate8 { get; set; }

        [FindsBy(How = How.Id, Using = "idChkIsdIcn")]
        public IWebElement CheqImage { get; set; }

        #endregion

        public PayoffLoanCharges WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            this.SwitchToContentFrame();
            this.WaitCreation(LoanChargesBuyerCharge);
            return this;
        }

        public PayoffLoanCharges SaveAndReloadScreen()
        {
            FastDriver.BottomFrame.Done();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
            FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            return this;
        }

        public PayoffLoanCharges FillChargesForm(string buyerChange, string sellerChange)
        {
            this.SwitchToContentFrame();
            LoanChargesBuyerCharge.FASetText(buyerChange);
            LoanChargesSellerCharge.FASetText(sellerChange);
            return this;
        }

        public PayoffLoanCharges AcceptDialogAndCompareWith(string CompareWith = null, bool SwitchToWindow = false, bool ClickAcceptButton = true)
        {
            string alertText = "";
            alertText = WebDriver.HandleDialogMessage(switchBackToFastWindow: SwitchToWindow, clickAcceptButton: ClickAcceptButton); //waits for the alert to show up, clicks Accept button, switches back to FAST window and returns the text of the alert message.

            if (CompareWith != null)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(alertText, CompareWith);
            }

            return this;
        }

        public void AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

        }

        public void AddChargeRefinance(IWebElement chargesTable, string chargeDescription, double? BorrowerCharge = null, double? BorrowerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Charge", TableAction.SetText, BorrowerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Credit", TableAction.SetText, BorrowerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }


            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

        }


        public void AddChargeRefinanceJavaS(IWebElement chargesTable, string chargeDescription, double? BorrowerCharge = null, double? BorrowerCredit = null, double? loanEstimate = null)
        {



            if (chargeDescription != string.Empty)
            {
                chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                   .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }

            IWebElement chargeElement = chargesTable.PerformTableAction(1, chargeDescription, 2, TableAction.Click).Element.FindElement(By.XPath(".."));

            if (BorrowerCharge.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[2].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, BorrowerCharge.ToString());
            }

            if (BorrowerCredit.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[3].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, BorrowerCredit.ToString());


            }


            if (loanEstimate.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[4].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, loanEstimate.ToString());


            }

        }

        public void AddChargeJavaS(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {


            if (chargeDescription != string.Empty)
            {
                chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                   .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
            }

            IWebElement chargeElement = chargesTable.PerformTableAction(1, chargeDescription, 2, TableAction.Click).Element.FindElement(By.XPath(".."));

            if (buyerCharge.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[2].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, buyerCharge.ToString());
            }

            if (buyerCredit.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[3].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, buyerCredit.ToString());


            }

            if (sellerCharge.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[4].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, sellerCharge.ToString());
            }

            if (sellerCredit.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[5].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, sellerCredit.ToString());


            }

            if (loanEstimate.HasValue)
            {
                string ID = chargeElement.FAFindElements(ByLocator.TagName, "td").ToList()[6].FAFindElement(ByLocator.TagName, "input").GetAttribute("id");
                settext(ID, loanEstimate.ToString());


            }

        }

        public void settext(string id, string txt)
        {

            IJavaScriptExecutor js = FastDriver.WebDriver as IJavaScriptExecutor;

            js.ExecuteScript("document.getElementById('" + id + "').value = '" + txt + "';");
        }


        public void UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

        }

        public PayoffLoanParites ClickPartiesTab()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PartiesTab);
            PartiesTab.FAClick();
            return FastDriver.GetPage<PayoffLoanParites>();
        }
    }

    public class PayoffLoanParites : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tPP")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tRC")]
        public IWebElement RecordingTab { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_btnTR")]
        public IWebElement TrustorMortgagorRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_txtTM")]
        public IWebElement TrustorMortgagor { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_btnOB")]
        public IWebElement BeneficiaryMortgageeRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_txtOB")]
        public IWebElement BeneficiaryMortgagee { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_txtGABcode")]
        public IWebElement TrusteeGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_cmdFindName")]
        public IWebElement TrusteeFind { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_txtName")]
        public IWebElement TrusteeBPName { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_chkEditContactInfo")]
        public IWebElement TrusteeEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textBusPhone")]
        public IWebElement TrusteeBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textBusFax")]
        public IWebElement TrusteeBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textCellPhone")]
        public IWebElement TrusteeCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textPager")]
        public IWebElement TrusteePager { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textEmailAddress")]
        public IWebElement TrusteeEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_comboAttention")]
        public IWebElement TrusteeAttention { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_chkEdit")]
        public IWebElement TrusteeEdit { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textName")]
        public IWebElement TrusteeEditName { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_textReference")]
        public IWebElement TrusteeReference { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_labelIdcode")]
        public IWebElement TrusteeGABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_labelName")]
        public IWebElement TrusteeNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tPP_PLP_TBP_labelAddress")]
        public IWebElement TrusteeAddressLabel { get; set; }



        #endregion

        public PayoffLoanParites WaitForScreeToLoan(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.SwitchToContentFrame();
            Playback.Wait(500);
            this.WaitCreation(element ?? TrusteeGABcode);
            return this;
        }

        public PayoffLoanParites FindGABCode(string GABCode, bool WaitForGabCodeLabel = true)
        {
            this.SwitchToContentFrame();
            TrusteeGABcode.FASetText(GABCode);
            TrusteeFind.FAClick();
            if (WaitForGabCodeLabel)
                this.WaitForValue(TrusteeGABcodeLabel, GABCode);
            return this;
        }

        public PayoffLoanRecording ClickRecordingTab()
        {
            this.SwitchToContentFrame();
            RecordingTab.FAClick();
            return FastDriver.GetPage<PayoffLoanRecording>();
        }
    }

    public class PayoffLoanRecording : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLD")]
        public IWebElement DetailsTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tLC")]
        public IWebElement ChargesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tPP")]
        public IWebElement PartiesTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tPL_tRC")]
        public IWebElement RecordingTab { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tRC_ctl02_txtTrustDeedDate")]
        public IWebElement PayoffLoanRecordingTrustDeedDate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tRC_ctl02_txtRecordingDate")]
        public IWebElement PayoffLoanRecordingRecordingDate { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tRC_ctl02_txtInstrument")]
        public IWebElement PayoffLoanRecordingInstrument { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tRC_ctl02_txtBook")]
        public IWebElement PayoffLoanRecordingBook { get; set; }

        [FindsBy(How = How.Id, Using = "tPL_tRC_ctl02_txtPage")]
        public IWebElement PayoffLoanRecordingPage { get; set; }

        #endregion

        public PayoffLoanRecording WaitForScreeToLoan()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.SwitchToContentFrame();
            Playback.Wait(250);
            this.WaitCreation(PayoffLoanRecordingTrustDeedDate);
            return this;
        }

    }

    public class PayoffLoanSummary : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "grdLoanSumry")]
        public IWebElement LoanSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_0")]
        public IWebElement LoanSummaryTableRow1 { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_1")]
        public IWebElement LoanSummaryTableRow2 { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_0_lblName")]
        public IWebElement LoanSummaryTableRow1Name { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_1_lblName")]
        public IWebElement LoanSummaryTableRow2Name { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_0_lblLoanAmt")]
        public IWebElement LoanSummaryTableRow1LoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_1_lblLoanAmt")]
        public IWebElement LoanSummaryTableRow2LoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_0_lblCntct")]
        public IWebElement LoanSummaryTableRow1Contact { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_1_lblCntct")]
        public IWebElement LoanSummaryTableRow2Contact { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_0_lblBusPh")]
        public IWebElement LoanSummaryTableRow1BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_1_lblBusPh")]
        public IWebElement LoanSummaryTableRow2BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_0_lblBusFx")]
        public IWebElement LoanSummaryTableRow1BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "grdLoanSumry_1_lblBusFx")]
        public IWebElement LoanSummaryTableRow2BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement LoanSummaryEdit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement LoanSummaryNew { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDel")]
        public IWebElement LoanSummaryRemove { get; set; }
        #endregion


        public PayoffLoanSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<PayoffLoanSummary>("Home>Order Entry>Payoff Loan");
            this.WaitForScreenToLoad();

            return this;
        }
        //
        public PayoffLoanSummary WaitForScreenToLoad(int timeout = 5)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(LoanSummaryTable, timeout);
            return this;
        }

    }
}
