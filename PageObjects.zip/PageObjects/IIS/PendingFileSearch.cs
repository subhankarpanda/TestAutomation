using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PendingFileSearch : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnskipsearch")]
		public IWebElement SkipSearch { get; set; }

		[FindsBy(How = How.Id, Using = "btnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "btnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "txtPrincipals")]
		public IWebElement Principals { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_0")]
		public IWebElement PrincipalsBuyer { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_1")]
		public IWebElement PrincipalsSeller { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_2")]
		public IWebElement PrincipalsDebtor { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals1_3")]
		public IWebElement PrincipalsAny1 { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_0")]
		public IWebElement PrincipalsIndHusWif { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_1")]
		public IWebElement PrincipalsTrusteeEstate { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_2")]
		public IWebElement PrincipalsBusinessEntity { get; set; }

		[FindsBy(How = How.Id, Using = "rblPrincipals2_3")]
		public IWebElement PrincipalsAny2 { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropAddress")]
		public IWebElement PropertyAddress { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropName")]
		public IWebElement PropertyName { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropLot")]
		public IWebElement PropertyLot { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropTract")]
		public IWebElement PropertyTract { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropParcel")]
		public IWebElement PropertyParcel { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropSubDiv")]
		public IWebElement PropertySubDivision { get; set; }

		[FindsBy(How = How.Id, Using = "txtAPNTaxNo")]
		public IWebElement APNTaxNo { get; set; }

		[FindsBy(How = How.Id, Using = "comboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "txtCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "comboCountry")]
		public IWebElement Country { get; set; }

		[FindsBy(How = How.Id, Using = "txtNumbers")]
		public IWebElement Numbers { get; set; }

		[FindsBy(How = How.Id, Using = "txtEmpName")]
		public IWebElement EmployeeName { get; set; }

		[FindsBy(How = How.Id, Using = "ddEmpType")]
		public IWebElement EmployeeType { get; set; }

		[FindsBy(How = How.Id, Using = "dgSearchResults")]
		public IWebElement SearchResultTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "31782")]
		public IWebElement Filenumber { get; set; }

		[FindsBy(How = How.Id, Using = "btnselect1")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "btnnewsearch1")]
		public IWebElement NewSearch1 { get; set; }

		[FindsBy(How = How.Id, Using = "btngoback")]
		public IWebElement GoBack { get; set; }

		[FindsBy(How = How.Id, Using = "btncontinue")]
		public IWebElement Continue { get; set; }

		#endregion

        public PendingFileSearch Open()
        {
            FastDriver.LeftNavigation.Navigate<PendingFileSearch>("Home>Order Entry>New File Entry");
            this.WaitForScreenToLoad();
            return this;
        }

        public PendingFileSearch WaitForScreenToLoad(IWebElement element = null, int timeout = 25)
        {
            //element = Principals;
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? FindNow);
            return this;
        }

        public NewFileEntry ClickOnSkipSearch()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(SkipSearch);
            SkipSearch.FAClick();

            return FastDriver.GetPage<NewFileEntry>();
        }
	}
}
