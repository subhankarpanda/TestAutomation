using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
	public class PhraseResequenceDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "btnPhrUp")]
		public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "btnPhrDown")]
		public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPhrase_dgridPhrase")]
		public IWebElement PhraseTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Done']")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[contains(@class,'ui-dialog') and contains(@style,'display: block')]//button/span[text()='Cancel']")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "pdv_2")]
        public IWebElement row01 { get; set; }

        [FindsBy(How = How.Id, Using = "pdv_1")]
        public IWebElement row02 { get; set; }

		#endregion

        public PhraseResequenceDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Up);
            return this;
        }

        public Dictionary<string, int> GetPhraseSequence()
        {
            Dictionary<string, int> phraseSeqnce = new Dictionary<string, int>();
            int rowCount=this.PhraseTable.GetRowCount();
            for (int i = 1; i <= rowCount; i++)
            {
                phraseSeqnce.Add(this.PhraseTable.PerformTableAction(i , 1, TableAction.GetText).Message, Convert.ToInt16(this.PhraseTable.PerformTableAction(i , 3, TableAction.GetText).Message));
            }
            return phraseSeqnce;
        }
	}
}
