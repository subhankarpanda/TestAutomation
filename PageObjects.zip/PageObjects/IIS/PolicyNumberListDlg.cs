using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PolicyNumberListDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridPolicyNumbers_dgridPolicyNumbers")]
		public IWebElement PolicyNameTable { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPolicyNumbers_0_rbSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPolicyNumbers_1_rbSelect")]
		public IWebElement select1 { get; set; }

		#endregion

	}
}
