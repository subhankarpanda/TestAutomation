using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class PrintChecks : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "txtIDt")]
        public IWebElement IssueDate { get; set; }

        [FindsBy(How = How.Id, Using = "grdCL_0_lblCNo")]
        public IWebElement CheckNumber { get; set; }

        [FindsBy(How = How.Id, Using = "grdCL_0_lblPye")]
        public IWebElement Payee { get; set; }

        [FindsBy(How = How.Id, Using = "grdCL")]
        public IWebElement CheckListTable { get; set; }
        #endregion

        public PrintChecks WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? IssueDate);

            return this;
        }

        public PrintChecks Delivery()
        {
            WaitForScreenToLoad();
            Deliver.FAClick();
            FastDriver.WebDriver.HandleDialogMessage(); // This is to handle the SDN Search dialog message, in case it shows up.
            return this;
        }
    }
}
