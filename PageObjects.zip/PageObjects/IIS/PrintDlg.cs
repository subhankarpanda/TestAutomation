using System;
using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium.Internal;

namespace FASTSelenium.PageObjects.IIS
{
    public class PrintDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "FAFDialog_0_iframe")]
        public IWebElement FADialogiFrame { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnPrint")]
        public IWebElement Print { get; set; }

        [FindsBy(How = How.Id, Using = "cboPrinters")]
        public IWebElement Printers { get; set; }

        [FindsBy(How = How.Id, Using = "txtNumCopies")]
        public IWebElement NumCopies { get; set; }

        [FindsBy(How = How.Id, Using = "cboMailBox")]
        public IWebElement MailBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
        public IWebElement Buyer { get; set; }

        [FindsBy(How = How.Id, Using = "chkSeller")]
        public IWebElement Seller { get; set; }

        [FindsBy(How = How.Id, Using = "chkMisc")]
        public IWebElement Misc { get; set; }

        [FindsBy(How = How.Id, Using = "cboTray")]
        public IWebElement PaperTray { get; set; }

        [FindsBy(How = How.Id, Using = "txtCustomer")]
        public IWebElement OfficePreferencesCustomer { get; set; }

        [FindsBy(How = How.Id, Using = "txtFile")]
        public IWebElement OfficePreferencesFile { get; set; }

        [FindsBy(How = How.Id, Using = "txtAccounting")]
        public IWebElement OfficePreferencesAccounting { get; set; }

        [FindsBy(How = How.Id, Using = "txtNumOther")]
        public IWebElement OfficePreferencesOther { get; set; }

        [FindsBy(How = How.Id, Using = "txtOther")]
        public IWebElement OfficePreferencesComments { get; set; }

        [FindsBy(How = How.Id, Using = "pubDocument")]
        public IWebElement PublishDocument { get; set; }

        [FindsBy(How = How.Id, Using = "imgDocument")]
        public IWebElement ImageDocument { get; set; }
        #endregion

        public PrintDlg WaitForScreenToLoad()
        {
            //WebDriver.WaitForWindowAndSwitch("Print", true, 20);
            //this.WaitForDialogScreenToLoad();
            this.SwitchToDialogContentFrame(switchToFraPageWin:false);
            this.WaitCreation(Printers);
            return this;
        }

        public PrintDlg WaitForDialogScreenToLoad()
        {

            try
            {

                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            }
            catch (WebDriverTimeoutException)
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_1_iframe");
            }

            this.WaitCreation(Printers);
            return this;
        }

        public PrintDlg SelectPrinter(string printerName = "TEXT_FILE_PRINTER") 
        {
            this.WaitForScreenToLoad();
            this.Printers.FASelectItemBySendingKeys(printerName);

            return this;
        }

        public PrintDlg ClickCancel()
        {
            WaitForScreenToLoad();
            Cancel.FAClick();
            return this;
        }

        public PrintDlg ClickPrint()
        {
            WaitForScreenToLoad();
            Print.FAClick();
            return this;
        }

        public void SendPrint(string printerName = "TEXT_FILE_PRINTER") //replaced "HP Universal Printing PCL 6"
        {
            Keyboard.SendKeys(FAKeys.TabAway);
            Keyboard.SendKeys(printerName);
            Keyboard.SendKeys("%(P)");
        }

        public void ValidatePrinterConfig()
        {
            if (isAlertPresent() && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
            {
                Reports.StatusUpdate("Printer is not configured", false);
            }
        }

        private bool isAlertPresent()
        {

            try
            {
                FastDriver.WebDriver.SwitchTo().Alert();
                return true;
            }
            catch (NoAlertPresentException)
            {
                return false;
            }
        }
    }
}
