using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using AutoIt;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class PrintEscrowSetlleStmt : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ucStmtDtl_lblALTAComments")]
        public IWebElement CommentSection { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_txtALTAComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optPropertyAddress")]
        public IWebElement PrintPropertyAddress { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optPropertyLegDescr")]
        public IWebElement PrintPropertyLegalDescription { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optPropertyAddrLegDescr")]
        public IWebElement PrintBoth { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkRecptNo")]
        public IWebElement ReceiptNo { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkIssDate")]
        public IWebElement IssueDate { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkPayor")]
        public IWebElement Payor { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkDepositType")]
        public IWebElement TypeOfFunds { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkReprsntg")]
        public IWebElement Representing { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkDescr")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkLoanNumber")]
        public IWebElement PrintLoanNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_lblAmndDateTime")]
        public IWebElement AmendedDate { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkIssuedCD")]
        public IWebElement IssuedWithCD { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_lblBuyer")]
        public IWebElement BorrowerText { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_btnTrDates")]
        public IWebElement TermsDates { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optStlmt")]
        public IWebElement Settlement { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optDsbst")]
        public IWebElement Disbursement { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkEst")]
        public IWebElement Estimated { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkFinal")]
        public IWebElement Final { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_lblStmtDate")]
        public IWebElement SettlementDate { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_lblDsbrmtDate")]
        public IWebElement DisbursementDate { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkAmnd")]
        public IWebElement Amended { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkRvised")]
        public IWebElement RevisedAfterSettlement { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkCmbned")]
        public IWebElement Combined { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_ddlCmbned")]
        public IWebElement CombinedNumberofCopies { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkSgnCmbned")]
        public IWebElement CombinedSignatures { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkInitialCmbned")]
        public IWebElement CombinedInitialsChkBx { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkBuyer")]
        public IWebElement Buyeronly { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_ddlBuyer")]
        public IWebElement BuyerNumberofCopies { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkSgnBuyer")]
        public IWebElement BuyerSignatures { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkInitialBuyer")]
        public IWebElement BuyerInitialsChkBx { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkSeller")]
        public IWebElement SellerOnly { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_ddlSeller")]
        public IWebElement SellerNumberofCopies { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkSgnSeller")]
        public IWebElement SellerSignatures { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkInitialSeller")]
        public IWebElement SellerInititalsChkBx { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_ckbEsrwOfcerSgn")]
        public IWebElement PrintEscrowOfficerSignature { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_btnCS")]
        public IWebElement CheckSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkEM")]
        public IWebElement PrintMemoEstimated { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_txtEM")]
        public IWebElement PrintMemoEstimatedNotice { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkFM")]
        public IWebElement PrintMemoFinal { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_txtFM")]
        public IWebElement PrintMemoFinalNotice { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optEscrowAddr")]
        public IWebElement PrintOwningOfficeBusAdd { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optSettleLoc")]
        public IWebElement PrintSettlementLocFromLender { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_txtSettlementLoc")]
        public IWebElement PrintSettlementLocFromLenderTextBox { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optEscrowSigBlank")]
        public IWebElement PrintBlankSignatureLineWithEscrowOfficerName { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optEscrowNoSig")]
        public IWebElement NoEscrowOfficerSignatureLine { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_txtEscrowOfcName")]
        public IWebElement PrintBlankSignatureLineText { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkEscrowSign")]
        public IWebElement PrintAltaEscrowOfficerSignature { get; set; }

        //US#759302
        [FindsBy(How = How.Id, Using = "ucStmtDtl_ckbEsrwOfcerSgnImg")]
        public IWebElement PrintEscrowOfficerSigImg { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_ckbEsrwOfcerSgnImg")]
        public IWebElement PrintSSEscrowOfficerSignature { get; set; }
        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkAttachCom")]
        public IWebElement CombinedAttachSignSep { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkInitialCmbned")]
        public IWebElement CombinedInitials { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkAttachBuy")]
        public IWebElement BuyerAttachSignSep { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkInitialBuyer")]
        public IWebElement BuyerInitials { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkAttachSel")]
        public IWebElement SellerAttachSignSep { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_chkInitialSeller")]
        public IWebElement SellerInitials { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optLetterSize")]
        public IWebElement PageSizeLetter { get; set; }

        [FindsBy(How = How.Id, Using = "ucStmtDtl_optLegalSize")]
        public IWebElement PageSizeLegal { get; set; }


        #endregion

        #region Applicable only to 2824-NCS-Commercial files
        [FindsBy(How = How.Id, Using = "ucStmtDtl_ckbTransactionInfSummary")]
        public IWebElement TransactionInfSumryChkbx { get; set; }

        #endregion

        public PrintEscrowSetlleStmt WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Deliver);

            return this;
        }

        public PrintEscrowSetlleStmt Open()
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement");
                this.WaitForScreenToLoad();
            }
            catch
            {
                Thread.Sleep(5000);
                FastDriver.LeftNavigation.Navigate<PrintEscrowSetlleStmt>("Home>Order Entry>Escrow Closing>Settlement Statement");
                this.WaitForScreenToLoad();
            }

            return this;
        }

        public PrintEscrowSetlleStmt SelectDeliveryMethod(string method)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Method);
            this.Method.FASelectItem(method);
            return this;
        }

        public PrintEscrowSetlleStmt ClickDeliver()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Deliver);
            this.Deliver.FAClick();
            return this;
        }

        public string[] GetListofDeliveryMethods()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Method);
            string[] listofdelivery = this.Method.FAGetDropdownOptions().ToStringArray();
            return listofdelivery;
        }

        public PrintEscrowSetlleStmt Delivery(string method)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Method);
            this.Method.FASelectItem(method);
            this.Deliver.FAClick();
            return this;
        }

        /// <summary>
        /// This Function selects the client format for delivering the Settlement statement. Options are buyer seller or combined format.
        /// </summary>
        /// <param name="clntFormat">Name of the format, Expected parameter values are buyer/seller/combined</param>
        /// <param name="noOfCopy">No of copy for the statement. default value is one </param>
        /// <param name="sgnNeeded">Need signature of buyer/seller/both</param>
        public void SlctClientFormatForDelvry(string clntFormat, int noOfCopy = 1, bool sgnNeeded = false)
        {
            switch (clntFormat.ToLower())
            {
                case "buyer":
                    this.Combined.FASetCheckbox(false);
                    this.SellerOnly.FASetCheckbox(false);
                    this.Buyeronly.FASetCheckbox(true);
                    this.BuyerNumberofCopies.FASelectItem(noOfCopy.ToString());
                    this.BuyerSignatures.FASetCheckbox(true);
                    break;

                case "seller":
                    this.Combined.FASetCheckbox(false);
                    this.SellerOnly.FASetCheckbox(true);
                    this.Buyeronly.FASetCheckbox(false);
                    this.SellerNumberofCopies.FASelectItem(noOfCopy.ToString());
                    this.SellerSignatures.FASetCheckbox(true);
                    break;
                default:
                    this.Combined.FASetCheckbox(true);
                    this.SellerOnly.FASetCheckbox(false);
                    this.Buyeronly.FASetCheckbox(false);
                    this.CombinedNumberofCopies.FASelectItem(noOfCopy.ToString());
                    this.CombinedSignatures.FASetCheckbox(true);
                    break;
            }
        }
    }
}
