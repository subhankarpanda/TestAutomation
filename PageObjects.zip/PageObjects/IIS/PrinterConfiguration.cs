using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;


namespace FASTSelenium.PageObjects.IIS
{
    public class PrinterConfiguration : PageObject
    {
        #region WebElements

        [FindsBy(How = How.LinkText, Using = " Save ")]
        public IWebElement Save { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[@id='idToolbarSave']/table/tbody/tr/td/span/button")]
        public IWebElement SaveBtn { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']")]
        public IWebElement CheckPrinterAssignmentsTable { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']")]
        public IWebElement SystemPrinterAssignmentsTable { get; set; }

        //        [FindsBy(How = How.Id, Using = "tblSystemGrid")]
        //public IWebElement SystemTable { get; set; }


        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//button[contains(text(),'rint Test Check'])")]
        public IWebElement PrintTestCheck { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//*[contains(.,'Test Check')]/button")]
        public IWebElement PrintTestCheck1 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelectPrinter { get; set; }
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 4]//select")]
        public IWebElement SelectPrinter1 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 2]/td[position() = 4]//select")]
        public IWebElement SelectPrinter2 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 3]/td[position() = 4]//select")]
        public IWebElement SelectPrinter3 { get; set; }

        //TODO: ADD FindsByAttribute

        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 1]//input")]
        public IWebElement Check1 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 2]/td[position() = 1]//input")]
        public IWebElement Check2 { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 3]/td[position() = 1]//input")]
        public IWebElement Check3 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 6]//select")]
        public IWebElement Top1 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 2]/td[position() = 6]//select")]
        public IWebElement Top2 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 3]/td[position() = 6]//select")]
        public IWebElement Top3 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 7]//select")]
        public IWebElement Left1 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 2]/td[position() = 7]//select")]
        public IWebElement Left2 { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='divCheckGridView']//table[@id='idGVTableBody']//tr[position() = 3]/td[position() = 7]//select")]
        public IWebElement Left3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement PaperSize1 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement PaperSize2 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement PaperSize3 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Ten99SForms { get; set; }

        [FindsBy(How = How.LinkText, Using = "Adjustments Forms")]
        public IWebElement AdjustmentsForms { get; set; }

        [FindsBy(How = How.LinkText, Using = "Closing Statements")]
        public IWebElement ClosingStatements { get; set; }

        [FindsBy(How = How.LinkText, Using = "Deposit Receipt Summaries")]
        public IWebElement DepositReceiptSummaries { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//span[contains(.,'1099-S Forms')")]
        public IWebElement _1099SForms { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 3]//select")]
        public IWebElement _1099SFormsSelectPrinter { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 4]//select")]
        public IWebElement _1099SFormsSelectTray { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 5]//select")]
        public IWebElement _1099SFormsSelectTopOffSet { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//tr[position() = 1]/td[position() = 6]//select")]
        public IWebElement _1099SFormsSelectLeftOffSet { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//span[Contains(.,'Deposit Receipts')")]
        public IWebElement DepositReceipts { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//tr[position() = 5]/td[position() = 3]//select")]
        public IWebElement DepositReceiptSelectPrinter { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//span[Contains(.,'Exchange Fee List')")]
        public IWebElement ExchangeFeeList { get; set; }
        //
        [FindsBy(How = How.XPath, Using = "//div[@id='divSystemGridView']//table[@id='idGVTableBody']//tr[position() = 9]/td[position() = 3]//select")]
        public IWebElement ExchangeFeeListSelectPrinter { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelectPrinter5 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelectPrinter6 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement SelectPrinter7 { get; set; }

        //TODO: ADD FindsByAttribute
        //public IWebElement SelectPrinter8 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Tray4 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Tray5 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Tray8 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Top4 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Top5 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Left4 { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Left5 { get; set; }

        #endregion

        public PrinterConfiguration WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(CheckPrinterAssignmentsTable);
            return this;
        }

        public PrinterConfiguration SetDefaultPrinter(string printerName = "TEXT_FILE_PRINTER")
        {
            this.SwitchToContentFrame();

            if (CheckPrinterAssignmentsTable.FAGetText().Contains("*" + printerName))
                CheckPrinterAssignmentsTable.PerformTableAction(1, 4, TableAction.SelectItemBySendkeys, "*" + printerName);
            else
                CheckPrinterAssignmentsTable.PerformTableAction(1, 4, TableAction.SelectItem, printerName); //Printer is not default            
            this.CheckPrinterAssignmentsTable.PerformTableAction(1, 1, TableAction.On);
            SaveBtn.FAClick();

            return this;
        }

        public PrinterConfiguration SetPDFPrinter()
        {
            //this.WaitForScreenToLoad();

            //try
            //{
            //    CheckPrinterAssignmentsTable.PerformTableAction(1, 4, TableAction.SelectItem, "PDFCreator");

            //    if (CheckPrinterAssignmentsTable.PerformTableAction(1, 4, TableAction.GetSelectedItem).Message.Clean() != "PDFCreator")
            //        Support.Fail("PDFCreater is not installed on test agent.");
            //}
            //catch
            //{
            //    Support.Fail("PDFCreater is not installed on test agent.");
            //}

            //Playback.Wait(5000);
            //this.CheckPrinterAssignmentsTable.PerformTableAction(1, 1, TableAction.On);
            //SaveBtn.FAClick();

            // Set PDFCreator default tray setting
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\SMS\PrintManager\1487\731\PDFCreator", "BinName", "Printer auto select");
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\SMS\PrintManager\1487\731\PDFCreator", "LeftOffset", "0");
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\SMS\PrintManager\1487\731\PDFCreator", "PaperSize", "Auto");
            Registry.SetValue(@"HKEY_CURRENT_USER\Software\SMS\PrintManager\1487\731\PDFCreator", "TopOffset", "0");

            return this;
        }
        //
        public PrinterConfiguration Open()
        {
            FastDriver.LeftNavigation.Navigate<PrinterConfiguration>("Home>Printer Configuration");
            FastDriver.WebDriver.WaitForWindowAndSwitch("One Moment Please...", false);
            this.WaitForScreenToLoad();
            return this;
        }
        //
        public void SetPrinterAndTrayForDocType(string DocType, string Printer = @"*TEXT_FILE_PRINTER", string Tray = @"Automatically Select", string TopOffSet = "", string LeftOffset = "")
        {
            // FastDriver.PrinterConfiguration.DepositReceipts.FAClick();
            try
            {
                this.WaitForScreenToLoad();
                IEnumerable<IWebElement> Rows = this.SystemPrinterAssignmentsTable.FAFindElements(ByLocator.TagName, "tr");
                foreach (IWebElement Row in Rows)
                {
                    if (Row.FAGetText().Contains(DocType))
                    {

                        IWebElement Doc = Row.FindElements(By.TagName("SPAN")).Where(r => r.FAGetText().Contains(DocType)).First<IWebElement>();
                        Doc.FAClick();
                        try
                        {
                            IWebElement PrinterDropDown = Row.FindElements(By.TagName("SELECT")).First<IWebElement>();
                            PrinterDropDown.FASelectItem(Printer);

                        }
                        catch (Exception ex)
                        {
                            if (ex.Message.Contains("Cannot locate element with text: *TEXT_FILE_PRINTER"))
                            {
                                IWebElement PrinterDropDown = Row.FindElements(By.TagName("SELECT")).First<IWebElement>();
                                PrinterDropDown.FASelectItem(Printer.Replace('*', ' ').Trim());
                                Thread.Sleep(2000);
                            }
                            else throw;
                        }
                        IWebElement TrayDropDown = Row.FindElements(By.TagName("SELECT")).ElementAt<IWebElement>(1);
                        TrayDropDown.FASelectItem(Tray);
                        Thread.Sleep(2000);
                        if (!string.IsNullOrEmpty(TopOffSet))
                        {
                            IWebElement TopOffsetDropDown = Row.FindElements(By.TagName("SELECT")).ElementAt<IWebElement>(2);
                            TopOffsetDropDown.FASelectItem(@TopOffSet);
                            Thread.Sleep(2000);
                        }
                        if (!string.IsNullOrEmpty(LeftOffset))
                        {
                            IWebElement LeftOffsetDropDown = Row.FindElements(By.TagName("SELECT")).ElementAt<IWebElement>(3);
                            LeftOffsetDropDown.FASelectItem(LeftOffset);
                            Thread.Sleep(2000);
                        }
                        break;
                    }
                }
                FastDriver.PrinterConfiguration.SaveBtn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(5000);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to set printer or tray \n" + ex.Message, false);
            }
        }
        //
        public void ResetPrinterAndTrayForDocType(string DocType)
        {
            string Printer = @"Always Use Default"; string TopOffSet = "0"; string LeftOffset = "0";
            try
            {
                this.WaitForScreenToLoad();
                IEnumerable<IWebElement> Rows = this.SystemPrinterAssignmentsTable.FAFindElements(ByLocator.TagName, "tr");
                foreach (IWebElement Row in Rows)
                {
                    if (Row.FAGetText().Contains(DocType))
                    {

                        IWebElement Doc = Row.FindElements(By.TagName("SPAN")).Where(r => r.FAGetText().Contains(DocType)).First<IWebElement>();
                        Doc.FAClick();
                        try
                        {
                            IWebElement PrinterDropDown = Row.FindElements(By.TagName("SELECT")).First<IWebElement>();
                            PrinterDropDown.FASelectItemBySendingKeys(Printer);

                        }
                        catch (Exception ex)
                        {
                            if (ex.Message.Contains("Cannot locate element with text: *TEXT_FILE_PRINTER"))
                            {
                                IWebElement PrinterDropDown = Row.FindElements(By.TagName("SELECT")).First<IWebElement>();
                                PrinterDropDown.FASelectItemBySendingKeys(Printer.Replace('*', ' ').Trim());
                                Thread.Sleep(2000);
                            }
                            else throw;
                        }
                        //IWebElement TrayDropDown = Row.FindElements(By.TagName("SELECT")).ElementAt<IWebElement>(1);
                        //TrayDropDown.FASelectItem(Tray);
                        //Thread.Sleep(2000);
                        if (!string.IsNullOrEmpty(TopOffSet))
                        {
                            IWebElement TopOffsetDropDown = Row.FindElements(By.TagName("SELECT")).ElementAt<IWebElement>(2);
                            TopOffsetDropDown.FASelectItem(TopOffSet);
                            Thread.Sleep(2000);
                        }
                        if (!string.IsNullOrEmpty(LeftOffset))
                        {
                            IWebElement LeftOffsetDropDown = Row.FindElements(By.TagName("SELECT")).ElementAt<IWebElement>(3);
                            LeftOffsetDropDown.FASelectItem(LeftOffset);
                            Thread.Sleep(2000);
                        }
                        break;
                    }
                }
                FastDriver.PrinterConfiguration.SaveBtn.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                Thread.Sleep(5000);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to set printer or tray \n" + ex.Message, false);
            }
        }

    }
}
