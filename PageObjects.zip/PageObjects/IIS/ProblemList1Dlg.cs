using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ProblemList1Dlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSelProb_0_chkSelProb")]
		public IWebElement dgridSelProb0SelProb { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_1_chkSelProb")]
		public IWebElement dgridSelProb1SelProb { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelProb_2_chkSelProb")]
		public IWebElement dgridSelProb2SelProb { get; set; }

		#endregion

	}
}
