using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ProductSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "ddlPrdctType")]
		public IWebElement ProductType { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProducts_dgridProducts")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "dgridProducts_0_chkSelPrdct")]
        public IWebElement Checkbox1 { get; set; }

		#endregion

        public ProductSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //FastDriver.WebDriver.WaitForWindowAndSwitch("Product List", timeoutSeconds: 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? ProductType);
            return this;
        }

	}
	public class ProductSelectionDialog : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "idGVTableBody")]
		public IWebElement TableProducts { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "btnClear")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

        #endregion

        public ProductSelectionDialog WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Select);

            return this;
        }

    }
}
