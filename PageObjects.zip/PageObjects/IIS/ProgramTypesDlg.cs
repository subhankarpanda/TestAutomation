using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ProgramTypesDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridPrograms_0_radSelPgm")]
		public IWebElement Program1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_1_radSelPgm")]
		public IWebElement Program2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_2_radSelPgm")]
		public IWebElement Program3 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_dgridPrograms")]
		public IWebElement ProgramTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnCheckAll")]
		public IWebElement CheckAll { get; set; }

		[FindsBy(How = How.Id, Using = "btnClearAll")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_0_chkSelPgm")]
		public IWebElement dgridPrograms0SelPgm { get; set; }

		[FindsBy(How = How.Id, Using = "dgridPrograms_1_chkSelPgm")]
		public IWebElement dgridPrograms1SelPgm { get; set; }

		#endregion

        public ProgramTypesDlg WaitForScreenToLoad(string windowName = "Program Type Selection")
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ProgramTable);
            return this;
        }

	}
}
