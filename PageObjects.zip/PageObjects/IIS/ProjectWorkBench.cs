﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using System.Drawing;
using AutoIt;
using OpenQA.Selenium.Interactions;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace FASTSelenium.PageObjects.IIS
{
    public class ProjectWorkBench : PageObject
    {
        #region WebElements

        [FindsBy(How = How.XPath, Using = ".//*[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only ui-state-focus ui-state-hover']")]
        public IWebElement refreshOK { get; set; }

        [FindsBy(How = How.Id, Using = "btnCreate")]
        public IWebElement Create { get; set; }

        [FindsBy(How = How.Id, Using = "btnRefresh")]
        public IWebElement Refresh { get; set; }

        [FindsBy(How = How.Id, Using = "idRefreshOk")]
        public IWebElement RefreshOKbutton { get; set; }

        [FindsBy(How = How.Id, Using = "idRefreshCancel")]
        public IWebElement RefreshCancelbutton { get; set; }

        [FindsBy(How = How.Id, Using = "btnBuyerSelection")]
        public IWebElement eclipse_Button { get; set; }

        [FindsBy(How = How.Id, Using = "btnBuyerSelectionUpdt")]
        public IWebElement UpdateSiteFilesBuyerEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "btnSellerSelectionUpdt")]
        public IWebElement UpdateSiteFilesSellerEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "btnNotesSelectionUpdt")]
        public IWebElement UpdateSiteFilesNotesEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "btnLenderSelectionUpdt")]
        public IWebElement UpdateSiteFilesNewLendersEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "createupdatetab")]
        public IWebElement CreateUpdateTab { get; set; }

        [FindsBy(How = How.Id, Using = "copyAllAddresses")]
        public IWebElement CopyAllAddresses { get; set; }

        [FindsBy(How = How.Id, Using = "btnaddrow")]
        public IWebElement AddButton { get; set; }

        [FindsBy(How = How.Id, Using = "txtSiteFileNum")]
        public IWebElement SiteFileNum { get; set; }

        [FindsBy(How = How.Id, Using = "chkCopyFromProjectFile")]
        public IWebElement CopyForSiteFile1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddressLine1")]
        public IWebElement AddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtcity")]
        public IWebElement nameCity { get; set; }

        [FindsBy(How = How.Id, Using = "ddlStates")]
        public IWebElement State { get; set; }

        [FindsBy(How = How.Id, Using = "txtZip")]
        public IWebElement nameZip { get; set; }

        [FindsBy(How = How.Id, Using = "txtcounty")]
        public IWebElement nameCounty { get; set; }

        [FindsBy(How = How.Id, Using = "ddlCountries")]
        public IWebElement ddlCountries { get; set; }

        [FindsBy(How = How.Id, Using = "btnaddrow")]
        public IWebElement AddNewRow { get; set; }

        [FindsBy(How = How.Id, Using = "addAddress")]
        public IWebElement AddressPopUp { get; set; }

        [FindsBy(How = How.Id, Using = "chkCopyFromProjectFile")]
        public IWebElement CopyForSiteFile2 { get; set; }

        [FindsBy(How = How.Id, Using = "chkCopyFromProjectFile")]
        public IWebElement CopyForSiteFile3 { get; set; }

        [FindsBy(How = How.Id, Using = "chkCopyFromProjectFile")]
        public IWebElement CopyForSiteFile4 { get; set; }

        [FindsBy(How = How.Id, Using = "chkCopyFromProjectFile")]
        public IWebElement CopyForSiteFile5 { get; set; }

        [FindsBy(How = How.Id, Using = "chkBusinessSource")]
        public IWebElement BusinessSource { get; set; }

        [FindsBy(How = How.Id, Using = "chkServiceType")]
        public IWebElement ServiceType { get; set; }

        [FindsBy(How = How.Id, Using = "chkBusinessSegment")]
        public IWebElement BusinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "chkTransactionType")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "chkFormType")]
        public IWebElement FormType { get; set; }

        [FindsBy(How = How.Id, Using = "chkEscrowTitleOO")]
        public IWebElement EscrowTitleOO { get; set; }

        [FindsBy(How = How.Id, Using = "chkProducts")]
        public IWebElement Products { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
        public IWebElement Buyer { get; set; }

        [FindsBy(How = How.Id, Using = "chkSeller")]
        public IWebElement Seller { get; set; }

        [FindsBy(How = How.Id, Using = "chkLender")]
        public IWebElement Lender { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecCreateSiteFiles")]
        public IWebElement CreateSiteFiles { get; set; }

        [FindsBy(How = How.Id, Using = "grdCreateSiteFiles")]
        public IWebElement tblCreateSiteFiles { get; set; }

        [FindsBy(How = How.Id, Using = "lblProjectFileSummary")]
        public IWebElement ProjSummaryTab { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyName")]
        public IWebElement ProjSummaryPropertyNameValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyNameTitle")]
        public IWebElement ProjSummaryPropertyNameTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressTitle")]
        public IWebElement ProjSummaryPropertyAddressTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressLine5")]
        public IWebElement ProjSummaryPropertyAddressValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblTransactionType")]
        public IWebElement ProjSummaryTransactionTypeValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblTransactionTypeTitle")]
        public IWebElement ProjSummaryTransactionTypeTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblServiceType")]
        public IWebElement ProjSummaryServiceTypeValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblServiceTypeTitle")]
        public IWebElement ProjSummaryServiceTypeTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblBusinessSourceTitle")]
        public IWebElement ProjSummaryBusinessSourceTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblTitleOwningOffice")]
        public IWebElement ProjSummaryTitleOwningOfficeValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblTitleOwningOfficeTitle")]
        public IWebElement ProjSummaryTitleOwningOfficeTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblEscrowOwningOffice")]
        public IWebElement ProjSummaryEscrowOwningOfficeValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblEscrowOwningOfficeTitle")]
        public IWebElement ProjSummaryEscrowOwningOfficeTitle { get; set; }

        [FindsBy(How = How.Id, Using = "lblSalesAmountTitle")]
        public IWebElement ProjSummarySalesAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblSalesLiabilityAmtTitle")]
        public IWebElement ProjSummarySalesLiability { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanAmountTitle")]
        public IWebElement ProjSummaryLoanAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanLiabilityAmtTitle")]
        public IWebElement ProjSummaryLoanLiability { get; set; }

        [FindsBy(How = How.Id, Using = "lblSecUpdateSiteFiles")]
        public IWebElement UpdateSiteFileTab { get; set; }

        [FindsBy(How = How.Id, Using = "txtaddrline1")]
        public IWebElement Address1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtaddrline2")]
        public IWebElement Address2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtaddrline3")]
        public IWebElement Address3 { get; set; }

        [FindsBy(How = How.Id, Using = "txtaddrline4")]
        public IWebElement Address4 { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSiteFiles")]
        public IWebElement TotalSiteFilesValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblOpenSiteFiles")]
        public IWebElement OpenSiteFilesValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblClosedSiteFiles")]
        public IWebElement ClosedSiteFilesValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblCancelledSiteFiles")]
        public IWebElement CancelledSiteFilesValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblOpenInErrorSiteFiles")]
        public IWebElement OpenInErrorSiteFilesValue { get; set; }

        [FindsBy(How = How.Id, Using = "totalSuccess")]
        public IWebElement TotalSuccessCreatedFiles { get; set; }

        [FindsBy(How = How.Id, Using = "grdCreateSiteFiles")]
        public IWebElement SiteFilesTable { get; set; }
        
        [FindsBy(How = How.Id, Using = "div_SiteFilesGrid")]
        public IWebElement SiteFilesGrid { get; set; }

        [FindsBy(How = How.Id, Using = "divErrorWarningMsg")]
        public IWebElement ErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressLine1")]
        public IWebElement PropAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressLine2")]
        public IWebElement PropAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressLine3")]
        public IWebElement PropAddressLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressLine4")]
        public IWebElement PropAddressLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "lblPropertyAddressLine1")]
        public IWebElement PropertyAddress_Line1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblprojectfileid")]
        public IWebElement ProjectFileNum { get; set; }

        [FindsBy(How = How.Id, Using = "btnremoverow")]
        public IWebElement RemoveButton { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyer")]
        public IWebElement BuyerLabel { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#div_UpdateSiteFilesSection #chkUpdateSelectAll")]
        public IWebElement UpdateSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkUpdateTransactionType")]
        public IWebElement UpdateTransactionTypeChk { get; set; }

        [FindsBy(How = How.Id, Using = "chkUpdateProducts")]
        public IWebElement UpdateProductsChk { get; set; }

        [FindsBy(How = How.Id, Using = "radProducts")]
        public IWebElement UpdateProductsOverwrite { get; set; }

        [FindsBy(How = How.Id, Using = "radProducts")]
        public IWebElement UpdateProductsAppend { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyerUpdt")]
        public IWebElement UpdateBuyerChk { get; set; }

        [FindsBy(How = How.Id, Using = "btnBuyerSelectionUpdt")]
        public IWebElement UpdateBuyerDetails { get; set; }

        [FindsBy(How = How.Id, Using = "chkSellerUpdt")]
        public IWebElement UpdateSellerChk { get; set; }

        [FindsBy(How = How.Id, Using = "chkUpdateNewLender")]
        public IWebElement UpdateNewLenderChk { get; set; }

        [FindsBy(How = How.Id, Using = "chkUpdateNotes")]
        public IWebElement UpdateNotesChk { get; set; }

        [FindsBy(How = How.Id, Using = "lblBusinessSource")]
        public IWebElement ProjSummaryBusinessSourceValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblSalesAmount")]
        public IWebElement ProjSummarySalesAmountValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblSalesLiabilityAmt")]
        public IWebElement ProjSummarySalesLiabilityValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanAmount")]
        public IWebElement ProjSummaryLoanAmountValue { get; set; }

        [FindsBy(How = How.Id, Using = "lblLoanLiabilityAmt")]
        public IWebElement ProjSummaryLoanLiabilityValue { get; set; }

        [FindsBy(How = How.Id, Using = "tabs_Menu_Img")]
        public IWebElement MenuIcon { get; set; }

        [FindsBy(How = How.Id, Using = "scPTWBCSF")]
        public IWebElement CreateSiteFileOption { get; set; }

        [FindsBy(How = How.Id, Using = "projFnd")]
        public IWebElement ProjectWorkbenchLink { get; set; }

        [FindsBy(How = How.Id, Using = "siteFnd")]
        public IWebElement SiteFileLink { get; set; }

        [FindsBy(How = How.Id, Using = "spnTitle")]
        public IWebElement SpanTitle { get; set; }

        [FindsBy(How = How.Id, Using = "tabs_Menu_Img")]
        public IWebElement Grid { get; set; }

        [FindsBy(How = How.Id, Using = "tabi")]
        public IWebElement TabIsEnded { get; set; }

        [FindsBy(How = How.CssSelector, Using = ".FAF-tabs-navigation li a[data-content='cPTWBCU']")]
        public IWebElement NewCreateUpdateTab { get; set; }

        [FindsBy(How = How.Id, Using = "cPWBL1")]//section
        public IWebElement CreateUpdate { get; set; }

        //[FindsBy(How = How.Id, Using = "scPWBL3")]
        [FindsBy(How = How.Id, Using = "scPTWBCSF")]
        public IWebElement CreateUpdateCreateSiteFiles { get; set; }

        //[FindsBy(How = How.Id, Using = "scPWBL4")]
        [FindsBy(How = How.Id, Using = "scPTWBUSF")]
        public IWebElement CreateUpdateUpdateSiteFiles { get; set; }

        [FindsBy(How = How.Id, Using = "cPTWBFS")]
        public IWebElement NewFeesTab { get; set; }

        [FindsBy(How = How.Id, Using = "cPTWBFS")]//section
        public IWebElement Fees { get; set; }

        [FindsBy(How = How.Id, Using = "scPTWBTEF")]
        public IWebElement FeesTitleAndEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "scPTWBRTF")]
        public IWebElement FeesRecordingAndTax { get; set; }

        [FindsBy(How = How.Id, Using = "btnBReset")]
        public IWebElement Reset { get; set; }

        [FindsBy(How = How.Id, Using = "divAutoSave")]
        public IWebElement AutoSave { get; set; }

        [FindsBy(How = How.Id, Using = "btnBSave")]
        public IWebElement btnAutoSave { get; set; }

        [FindsBy(How = How.Id, Using = "btnBDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "grdtitleEscrowfee")]
        public IWebElement TitleEscrowFeesTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdtitleEscrowfeeInnerGrid")]
        public IWebElement TitleEscrowFeesTable1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblDescription")]
        public IWebElement Table { get; set; }

        [FindsBy(How = How.Id, Using = "rbtnSelect")]
        public IWebElement RadioSelectTitleEscrowFee1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtTEBuyerCharge")]
        public IWebElement TitleEscrowFeeBuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtTESellerCharge")]
        public IWebElement TitleEscrowFeeSellerCharge1 { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#lblDescription,#lblTEDescription")]
        public IWebElement TitleEscrowFeeDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtTEBuyerSalesTax")]
        public IWebElement TitleEscrowFeeBuyerSalesTax1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtTESellerSalesTax")]
        public IWebElement TitleEscrowFeeSellerSalesTax1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtTETotalCharge")]
        public IWebElement TitleEscrowFeeTotalCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "div_TitleEscrowFeesGrid")]
        public IWebElement TitleEscrowFeesGrid { get; set; }

        [FindsBy(How = How.Id, Using = "div_RecordingTaxFeesGrid")]
        public IWebElement RecordingTaxFeesGrid { get; set; }

        [FindsBy(How = How.Id, Using = "grdrecordingtaxfee")]
        public IWebElement RecordingTaxFeesTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdrecordingtaxfeedivInnerGrid")]
        public IWebElement RecordingTaxFeesTableDivInnerGrid { get; set; }

        [FindsBy(How = How.Id, Using = "grdrecordingtaxfeeInnerGrid")]
        public IWebElement RecordingTaxFeesTableInnerGrid { get; set; }

        [FindsBy(How = How.Id, Using = "lblDescription")]
        public IWebElement RecordingTaxFeesTableDescription { get; set; }

        [FindsBy(How = How.Id, Using = "txtRTBuyerCharge")]
        public IWebElement RecordingTaxFeesTableBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtRTSellerCharge")]
        public IWebElement RecordingTaxFeesTableSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "txtRTTotalCharge")]
        public IWebElement RecordingTaxFeesTableTotalCharge { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#divSiteFilesSlider,#AllocateFeesSlider")]
        public IWebElement SiteFilesSlider { get; set; }

        [FindsBy(How = How.Id, Using = "imgAddSubFee")]
        public IWebElement AddSubFee1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtSearch")]
        public IWebElement FeeSearch { get; set; }//Sub Fee Search

        [FindsBy(How = How.Id, Using = "tblSubFee")]
        public IWebElement SubFeeTable { get; set; }

        //SubFeeSearchCheckBoxes are dynamic...
        [FindsBy(How = How.Id, Using = "chk_54195")]
        public IWebElement SubFeeSearchCheckBox1 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_65923")]
        public IWebElement TSubFeeSearchCheckBox2 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_54185")]
        public IWebElement TSubFeeSearchCheckBox3 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_66447")]
        public IWebElement TSubFeeSearchCheckBox4 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_54682")]
        public IWebElement RSubFeeSearchCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "chk_54695")]
        public IWebElement RSubFeeSearchCheckBox1 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_65929")]
        public IWebElement RSubFeeSearchCheckBox2 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_54908")]
        public IWebElement RSubFeeSearchCheckBox3 { get; set; }


        [FindsBy(How = How.Id, Using = "chk_63782")]
        public IWebElement SubFeeSearchCheckBox2 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_63765")]
        public IWebElement SubFeeSearchCheckBox3 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_54194")]
        public IWebElement SubFeeSearchCheckBox4 { get; set; }

        [FindsBy(How = How.Id, Using = "chk_63802")]
        public IWebElement SubFeeSearchCheckBox5 { get; set; }

        [FindsBy(How = How.Id, Using = "btnSubFeeDone")]
        public IWebElement SubFeeDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnSubFeesCancel")]
        public IWebElement SubFeeCancelButton { get; set; }

        [FindsBy(How = How.Id, Using = "imgExpandCollapseSubFee")]
        public IWebElement ExpandButton { get; set; }

        [FindsBy(How = How.Id, Using = "tblSubFeeType")]
        public IWebElement SubFeeDialogbox { get; set; }

        [FindsBy(How = How.Id, Using = "Container")]
        public IWebElement Container { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#SlidingTitle,#SliderImg")]
        public IWebElement SlidingTitle { get; set; }

        [FindsBy(How = How.Id, Using = "SliderImg")]
        public IWebElement SliderImg { get; set; }

        [FindsBy(How = How.Id, Using = "SliderImg")]
        public IWebElement UpdateFileSlider { get; set; }

        [FindsBy(How = How.Id, Using = "tblSFFeeSlider")]
        public IWebElement SiteFilesFeeSliderTable { get; set; }

        [FindsBy(How = How.Id, Using = "sliderHeaderTbl")]
        public IWebElement SliderTableHeader { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#SpnNSLFeeDescr,#divFeeDesc")]//#divFeeDesc 
        public IWebElement SiteFilesFeeSliderFeeDesc { get; set; }

        [FindsBy(How = How.Id, Using = "SpnNSLFeeDescr")]
        public IWebElement SiteFilesFeeSliderbottomFeeDesc { get; set; }

        [FindsBy(How = How.Id, Using = "btnSalesTaxOverride")]
        public IWebElement SiteFilesFeeSliderSalesTaxOverride { get; set; }

        [FindsBy(How = How.Id, Using = "tblFEE")]
        public IWebElement SiteFilesFeeSliderFeeTable { get; set; }

        [FindsBy(How = How.Id, Using = "dvnoSiteFiles")]
        public IWebElement SiteFilesInnerGridDiv1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalChrg")]
        public IWebElement SiteFilesFeeSliderTotalBuyerSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "City")]
        public IWebElement SiteFilesInnerGridCity { get; set; }

        [FindsBy(How = How.Id, Using = "drpFilCity")]
        public IWebElement SiteFilesInnerGridCityFilter { get; set; }

        [FindsBy(How = How.Id, Using = "buyerCharge")]
        public IWebElement SiteFilesInnerGriddollarbuyercharge { get; set; }

        [FindsBy(How = How.Id, Using = "sellerCharge")]
        public IWebElement SiteFilesInnerGriddollarsellercharge { get; set; }

        [FindsBy(How = How.Id, Using = "TotalCharge")]
        public IWebElement SiteFilesInnerGridTotalcharge { get; set; }

        [FindsBy(How = How.Id, Using = "buyerChargePer")]
        public IWebElement SiteFilesInnerGridAssignBuyerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "sellerChargePer")]
        public IWebElement SiteFilesInnerGridAssignSellerPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "buyerCharge")]
        public IWebElement SiteFilesInnerGridAssignBuyerDollar { get; set; }

        [FindsBy(How = How.Id, Using = "sellerCharge")]
        public IWebElement SiteFilesInnerGridAssignSellerDollar { get; set; }

        [FindsBy(How = How.Id, Using = "Total Charge")]
        public IWebElement SiteFilesInnerGridTotalChargePercentagedollar { get; set; }

        [FindsBy(How = How.Id, Using = "tblsffeegridHeader")]
        public IWebElement SiteFilesFeeSliderFeeGridHeaderTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblSFFeeGridBody")]
        public IWebElement SiteFilesFeeSliderFeeGridBodyTable { get; set; }

        [FindsBy(How = How.Id, Using = "divSFFeeGridBody")]
        public IWebElement SiteFilesFeeSliderFeeGridBodyTableDiv { get; set; }

        [FindsBy(How = How.Id, Using = "divTotalCharge")]
        public IWebElement SiteFilesFeeSliderTotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerChrg")]
        public IWebElement SiteFilesFeeSliderTotalBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerChrg")]
        public IWebElement SiteFilesFeeSliderTotalSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAvailableBuyerChrg")]
        public IWebElement SiteFilesFeeSliderTotalAvailableBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAvailableBuyerST")]
        public IWebElement SiteFilesFeeSliderTotalAvailableBuyerChargeSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAvailableSellerChrg")]
        public IWebElement SiteFilesFeeSliderTotalAvailableSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAvailableSellerST")]
        public IWebElement SiteFilesFeeSliderTotalAvailableSellerChargeSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAvailableChrg")]
        public IWebElement SiteFilesFeeSliderTotalAvailableTotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "siteFileNumber")]
        public IWebElement SiteFilesFeeSliderSiteFileNumber { get; set; }

        [FindsBy(How = How.Id, Using = "state")]
        public IWebElement SiteFilesFeeSliderState { get; set; }

        [FindsBy(How = How.Id, Using = "buyerCharge")]
        public IWebElement SiteFilesFeeSliderBuyerCharge { get; set; }

        [FindsBy(How = How.CssSelector, Using = ".salesTax.buyerSTLbl")]//#lblBuyerST
        public IWebElement SiteFilesFeeSliderBuyerChargeSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "sellerCharge")]
        public IWebElement SiteFilesFeeSliderSellerCharge { get; set; }

        [FindsBy(How = How.CssSelector, Using = ".salesTax.sellerSTLbl")]//#lblSellerST
        public IWebElement SiteFilesFeeSliderSellerChargeSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneSlider")]
        public IWebElement SiteFilesFeeSliderDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelSlider")]
        public IWebElement SiteFilesFeeSliderCancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAllocatedBuyerChrgPer")]
        public IWebElement SiteFilesFeeSliderTotalAllocatedBuyerChargePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAllocatedBuyerChrgDol")]
        public IWebElement SiteFilesFeeSliderTotalAllocatedBuyerChargeDollar { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAllocatedSellerChrgPer")]
        public IWebElement SiteFilesFeeSliderTotalAllocatedSellerChargePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAllocatedBSellerChrgDol")]
        public IWebElement SiteFilesFeeSliderTotalAllocatedSellerChargeDollar { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRemainingBuyerChrgPer")]
        public IWebElement SiteFilesFeeSliderTotalRemainingBuyerChargePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRemainingBuyerChrgDol")]
        public IWebElement SiteFilesFeeSliderTotalRemainingBuyerChargeDollar { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRemainingSellerChrgPer")]
        public IWebElement SiteFilesFeeSliderTotalRemainingSellerChargePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRemainingSellerChrgDol")]
        public IWebElement SiteFilesFeeSliderTotalRemainingSellerChargeDollar { get; set; }

        [FindsBy(How = How.Id, Using = "dlgConfirmBox")]
        public IWebElement ConfirmBox { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemoveFee")]
        public IWebElement RemoveFee { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div/button/span[text() = 'Ok']")]
        //[FindsBy(How = How.Id, Using = "btnConfirmPopUpOk")]
        [FindsBy(How = How.XPath, Using = "//div/button/span[text() = 'Ok']|//*[@id='btnConfirmPopUpOk']")]//uses pipe(|) to look both ways
        public IWebElement ConfirmBoxOk { get; set; }

        //[FindsBy(How = How.XPath, Using = "//div/button/span[text() = 'Cancel']")]
        //[FindsBy(How = How.Id, Using = "btnConfirmPopUpCancel")]
        [FindsBy(How = How.XPath, Using = "//div/button/span[text() = 'Cancel']|//*[@id='btnConfirmPopUpCancel']")]//uses pipe(|) to look both ways
        public IWebElement ConfirmBoxCancel { get; set; }

        [FindsBy(How = How.Id, Using = "grdSiteFilesInnerGrid")]
        public IWebElement SiteFilesInnerGridTable { get; set; }

        [FindsBy(How = How.Id, Using = "grdSiteFilesdivInnerGrid")]
        public IWebElement SiteFilesInnerGridDiv { get; set; }

        [FindsBy(How = How.Id, Using = "SiteFileNum")]
        public IWebElement SiteFilesInnerGridSiteFileNum { get; set; }

        [FindsBy(How = How.Id, Using = "TransactionType")]
        public IWebElement SiteFilesInnerGridTransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "County")]
        public IWebElement SiteFilesInnerGridCounty { get; set; }

        [FindsBy(How = How.Id, Using = "state")]
        public IWebElement SiteFilesInnerGridState { get; set; }

        [FindsBy(How = How.Id, Using = "drpFilCounty")]
        public IWebElement SiteFilesInnerGridCountyFilter { get; set; }

        [FindsBy(How = How.Id, Using = "drpFilState")]
        public IWebElement SiteFilesInnerGridStateFilter { get; set; }
        
        [FindsBy(How = How.Id, Using = "idCancel")]
        public IWebElement SiteFilesInnerGridCancel { get; set; }

        [FindsBy(How = How.Id, Using = "salesTax")]
        public IWebElement SiteFilesInnerGridsalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "idDone")]
        public IWebElement SiteFilesInnerGridDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnApplyDefaultCharges")]
        public IWebElement SiteFilesInnerGridApplyDefaultCharges { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//th[@id='siteFileNumber']/span[2]")]
        public IWebElement SiteFilesInnerGridSiteFileNumberSortIcons { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[@id='City']/span[2]")]
        public IWebElement SiteFilesInnerGridCitySortIcons { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[@id='County']/span[2]")]
        public IWebElement SiteFilesInnerGridCountySortIcons { get; set; }

        [FindsBy(How = How.XPath, Using = "//th[@id='state']/span[2]")]
        public IWebElement SiteFilesInnerGridStateSortIcons { get; set; }

        [FindsBy(How = How.Id, Using = "btnTeFSalesTaxOverride")]
        public IWebElement TitleAndEscrowFeesSalesTaxOverride { get; set; }

        [FindsBy(How = How.Id, Using = "tblFileSummaryInfoSubSec3")]
        public IWebElement FileSummaryInfoSubSec3Table { get; set; }

        [FindsBy(How = How.Id, Using = "tblSliderContainer")]
        public IWebElement UpdateSiteFilesSliderContainer { get; set; }

        [FindsBy(How = How.Id, Using = "divsliderTbl")]
        public IWebElement UpdateSiteFilesSliderTableDiv { get; set; }

        [FindsBy(How = How.Id, Using = "sliderTbl")]
        public IWebElement UpdateSiteFilesSliderTable { get; set; }

        [FindsBy(How = How.Id, Using = "sliderTbl1")]
        public IWebElement UpdateSiteFilesSliderTableTitles { get; set; }

        [FindsBy(How = How.Id, Using = "chkSF_14321")]
        public IWebElement UpdateSiteFilesSliderTableCheckboxRow1 { get; set; }

        [FindsBy(How = How.Id, Using = "chkSF_SelectAll")]
        public IWebElement UpdateSiteFilesSliderTableCheckboxSelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkSF_All_1")]
        public IWebElement UpdateSiteFilesSliderTableCheckbox1SelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkSF_All_2")]
        public IWebElement UpdateSiteFilesSliderTableCheckbox2SelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "chkSF_All_3")]
        public IWebElement UpdateSiteFilesSliderTableCheckbox3SelectAll { get; set; }

        [FindsBy(How = How.Id, Using = "radLenders_Del")]
        public IWebElement UpdateSiteFilesViewLenders { get; set; }

        [FindsBy(How = How.Id, Using = "radLenders_Add")]
        public IWebElement UpdateSiteFilesAddDeleteLenders { get; set; }

        [FindsBy(How = How.Id, Using = "radLenders_Updt")]
        public IWebElement UpdateSiteFilesUpdateLenderDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tblUpdateLender")]
        public IWebElement UpdateSiteFilesNewLendersLendersSelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneLenUpdt")]
        public IWebElement UpdateSiteFilesNewLendersDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelLenUpdt")]
        public IWebElement UpdateSiteFilesNewLendersCancel { get; set; }

        [FindsBy(How = How.Id, Using = "lblLenderName")]
        public IWebElement UpdateSiteFilesLenderNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "tblsffeegridFooter")]
        public IWebElement SiteFileSliderFooterTbl { get; set; }

        //Requested by Manjunath, Sumana
        //TODO: Verify the ID is valid (refers to an actual element)
        [FindsBy(How = How.Id, Using = "SlidingContent")]
        public IWebElement PercentageAllocationSlider { get; set; }

        [FindsBy(How = How.Id, Using = "blockupdate")]
        public IWebElement BlockUpdate { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAllocatedBuyerChrgPer")]
        public IWebElement TotalAllocatedBuyerChrgPer { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRemainingBuyerChrgPer")]
        public IWebElement TotalRemainingBuyerChrgPer { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAllocatedSellerChrgPer")]
        public IWebElement TotalAllocatedBSellerChrgPer { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalRemainingSellerChrgPer")]
        public IWebElement TotalRemainingSellerChrgPer { get; set; }

        [FindsBy(How = How.Id, Using = "chk_66450")]
        public IWebElement TSubFeedefault { get; set; }

        [FindsBy(How = How.Id, Using = "chk_66451")]
        public IWebElement TSubFeedefault1 { get; set; }
        [FindsBy(How = How.Id, Using = "chk_66452")]
        public IWebElement RSubFeedefault1 { get; set; }
        [FindsBy(How = How.Id, Using = "chk_66453")]
        public IWebElement RSubFeedefault2 { get; set; }

        [FindsBy(How = How.Id, Using = "tblsffeegridFooter")]
        public IWebElement SliderFooterTable { get; set; }

        [FindsBy(How = How.CssSelector, Using = "tr[style =\"background-color: rgb(255, 255, 160);\"]")]
        public IWebElement HighlightedRow { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerChargeHeader")]
        public IWebElement SiteFilesFeeSliderSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalCharge")]
        public IWebElement SiteFilesFeeSliderTotalCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "BuyerProm")]
        public IWebElement SiteFilesFeeSliderBuyerProm { get; set; }

        [FindsBy(How = How.Id, Using = "SellerProm")]
        public IWebElement SiteFilesFeeSliderSellerProm { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerSalesTaxHeader")]
        public IWebElement BuyerSalesTaxHeader { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerPromHeader")]
        public IWebElement BuyerPromHeader { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerSalesTaxHeader")]
        public IWebElement SellerSalesTaxHeader { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerPromHeader")]
        public IWebElement SellerPromHeader { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeaderBuyerSalesTax")]
        public IWebElement HeaderBuyerSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeaderBuyerProm")]
        public IWebElement HeaderBuyerProm { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeaderSellerCharge")]
        public IWebElement HeaderSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeaderSellerSalesTax")]
        public IWebElement HeaderSellerSalesTax { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeaderSellerProm")]
        public IWebElement HeaderSellerProm { get; set; }

        [FindsBy(How = How.Id, Using = "lblHeaderTotalCharge")]
        public IWebElement HeaderTotalCharge { get; set; }

        [FindsBy(How = How.Id, Using = "buyerAssignDoller")]
        public IWebElement BuyerAssignDOllar { get; set; }

        [FindsBy(How = How.Id, Using = "BuyersalesTax")]
        public IWebElement BuyerSalesTaxDollar { get; set; }

        [FindsBy(How = How.Id, Using = "sellerAssignDoller")]
        public IWebElement sellerAssignDollar { get; set; }

        [FindsBy(How = How.Id, Using = "SellerSalesTax")]
        public IWebElement sellerSalesTaxAssignDollar { get; set; }

        [FindsBy(How = How.Id, Using = "pdd")]
        public IWebElement PDDDet { get; set; }

        [FindsBy(How = How.Id, Using = "btnCalculateFees")]
        public IWebElement CalculateFees { get; set; }

        [FindsBy(How = How.Id, Using = "txtTEBuyerProm")]
        public IWebElement BuyerProm { get; set; }

        [FindsBy(How = How.Id, Using = "txtTESellerProm")]
        public IWebElement SellerProm { get; set; }


        [FindsBy(How = How.Id, Using = "chk_66455")]
        public IWebElement SubFeeIncDec { get; set; }


        [FindsBy(How = How.Id, Using = "chk_63805")]
        public IWebElement RecSubFeeIncDec { get; set; }

        [FindsBy(How = How.Id, Using = "chk_66506")]
        public IWebElement RecSubFeeBlnkOut1 { get; set; }

        //PROBLEM: In FeatINT branch CreateUpdateSubMenu is mapped differently
        //[FindsBy(How = How.XPath, Using = "selected")]
        //public IWebElement CreateUpdateSubMenu { get; set; }
        [FindsBy(How = How.Id, Using = "sub-menu1")]
        public IWebElement CreateUpdateSubMenu { get; set; }

        [FindsBy(How = How.Id, Using = "sub-menu2")]
        public IWebElement FeesSubMenu { get; set; }

        [FindsBy(How = How.Id, Using = "img_headericon cPTWBCU")]
        public IWebElement CreateUpdateMenuArrowIcon { get; set; }

        [FindsBy(How = How.Id, Using = "img_headericon cPTWBFS")]
        public IWebElement FeesMenuArrowIcon { get; set; }

        [FindsBy(How = How.Id, Using = "btnLenderSelection")]
        public IWebElement CreateSiteFilesNewLendersEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "scPTWBUSF")]
        public IWebElement UpdateSiteFilesOption { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='blockupdate']//table/tbody/tr/td")]
        public IWebElement SiteFileTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='blockupdate']//table/tbody/tr/td")]
        public IWebElement SiteFileStatus { get; set; }

        [FindsBy(How = How.Id, Using = "totalErrors")]
        public IWebElement ErrorMessagePane { get; set; }

        [FindsBy(How = How.Id, Using = "totalFailed")]
        public IWebElement TotalFailedErrorMessage { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@class='ui-dialog-buttonpane ui-widget-content ui-helper-clearfix']/div[@class='ui-dialog-buttonset']/button[@class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only ui-state-focus']/span")]
        public IWebElement ConfirmationDlgOK { get; set; }

        [FindsBy(How = How.Id, Using = "tabs_Menu_Img")]
        public IWebElement CreateUpdateMenu { get; set; }
        
        [FindsBy(How = How.Id, Using = "scPTWBCSF")]
        public IWebElement CreateSiteMenuOption { get; set; }

        [FindsBy(How = How.Id, Using = "scPTWBUSF")]
        public IWebElement UpdateSiteMenuOption { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
        public IWebElement CopyBuyerData { get; set; }

        [FindsBy(How = How.Id, Using = "chkSeller")]
        public IWebElement CopySellerData { get; set; }

        [FindsBy(How = How.Id, Using = "chkLender")]
        public IWebElement CopyLenderData { get; set; }

        [FindsBy(How = How.Id, Using = "div_CreateContainer")]
        public IWebElement CreateUpdateContainer { get; set; }

        [FindsBy(How = How.Id, Using = "div_siteslidergrid")]
        public IWebElement SiteSlideGrid { get; set; }

        [FindsBy(How = How.Id, Using = "dlgBuyerUpdt")]
        public IWebElement BuyerUpdateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelBSUpdt")]
        public IWebElement BuyerUpdateDialogCancelButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneBSUpdt")]
        public IWebElement BuyerUpdateDialogDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "tblBuyerUpdt")]
        public IWebElement BuyerUpdateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "dlgSellerUpdt")]
        public IWebElement SellerUpdateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "tblSellerUpdt")]
        public IWebElement SellerUpdateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "dlgNotes")]
        public IWebElement NotesUpdateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "tblNotes")]
        public IWebElement NotesUpdateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelNoteUpdt")]
        public IWebElement NotesUpdateDialogCancelButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneNoteUpdt")]
        public IWebElement NotesUpdateDialogDoneButton { get; set; }

        [FindsBy(How = How.Id, Using = "dlgBuyer")]
        public IWebElement BuyerCreateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "tblBuyer")]
        public IWebElement BuyerCreateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkBuyer")]
        public IWebElement BuyerCreateCheck { get; set; }

        [FindsBy(How = How.Id, Using = "btnBuyerSelection")]
        public IWebElement BuyerCreateEllipsis { get; set; }
        
        [FindsBy(How = How.Id, Using = "btnCancelBSCrt")]
        public IWebElement BuyerSellerCreateCancelDialogButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneBSCrt")]
        public IWebElement BuyerSellerCreateDoneDialogButton { get; set; }

        [FindsBy(How = How.Id, Using = "dlgSeller")]
        public IWebElement SellerCreateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "tblSeller")]
        public IWebElement SellerCreateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkSeller")]
        public IWebElement SellerCreateCheck { get; set; }

        [FindsBy(How = How.Id, Using = "btnSellerSelection")]
        public IWebElement SellerCreateEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "sliderTbl")]
        public IWebElement SliderTable { get; set; }

        [FindsBy(How = How.Id, Using = "dlgLender")]
        public IWebElement LenderCreateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "tblLender")]
        public IWebElement LenderCreateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkLender")]
        public IWebElement LenderCreateCheck { get; set; }

        [FindsBy(How = How.Id, Using = "btnLenderSelection")]
        public IWebElement LenderCreateEllipsis { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelLenCrt")]
        public IWebElement LenderCreateCancelDialogButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneLenCrt")]
        public IWebElement LenderCreateDoneDialogButton { get; set; }

        [FindsBy(How = How.Id, Using = "SiteFilesContent")]
        public IWebElement SiteFilesContentDialog { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalSiteFiles")]
        public IWebElement TotalSiteFiles { get; set; }

        [FindsBy(How = How.ClassName, Using = "sflink")]
        public IWebElement SiteFileLinkToList { get; set; }

        [FindsBy(How = How.Id, Using = "dlgLenderUpdt")]
        public IWebElement LenderUpdateDialog { get; set; }

        [FindsBy(How = How.Id, Using = "tblUpdateLender")]
        public IWebElement LenderUpdateDialogTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelLenUpdt")]
        public IWebElement LenderUpdateCancelDialogButton { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneLenUpdt")]
        public IWebElement LenderUpdateDoneDialogButton { get; set; }

        [FindsBy(How = How.XPath, Using = "//img[contains(@src,'SiteFilesImg-Disabled.png')]")]
        public IWebElement SiteFilesMenuDisabled { get; set; }
        


        #endregion

        #region PageObjectMethods
        public ProjectWorkBench WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? this.TotalSiteFilesValue);
            return this;
        }

        public bool IsAllocateFeesSliderDisabled()
        {
            try
            {
                return this.SlidingTitle.FAFindElement(ByLocator.ClassName, "SliderDisabled").Exists();
            }
            //Has TargetInvocationException replaced NoSuchElementException???
            catch (NoSuchElementException)
            {
                return false;
            }
            catch (System.Reflection.TargetInvocationException)
            {
                return false;
            }

        }

        public bool ValidateSalesTaxOverrideButtonOnAllocateFeesSlider(string ChargeDescription1)
        {
            try
            {
                //Sales Tax Override is in sync with the row where Fee Description is displayed
                if (WebDriver.FindElement(By.CssSelector(".tdTitle")).FAGetText().Contains(ChargeDescription1))
                {
                    //*Sales Tax Override button is aligned on the top right corner of the Allocate Fees slider 
                    //* Sales Tax Override button is displayed with the label- Sales Tax Override
                    if (WebDriver.FindElement(By.CssSelector(".rightAlign.displayInlineBlk")).FAGetText().Contains("Sales Tax Override"))
                        return true;
                    else
                        return false;
                }
                else
                {
                    return false;
                }
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public bool IsCellEnabledOnTitleEscrowFeesTable(string Description, int columnNumber)
        {
            try
            {
                /*
                //Title and Escrow Fees table column numbers:
                //"Sel" - 1
                //"Descritpion" - 2
                //"Buyer Charge" - 3
                //"Sales Tax" - 4
                //"Seller Charge" - 5
                //"Sales Tax" - 6
                //"Total Charge" - 7
                 * */
                return FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction(2, Description, columnNumber, TableAction.GetCell).Element.FindElement(By.TagName("input")).IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsCellEnabledOnRecordingTaxFeesTable(string Description, int columnNumber)
        {
            try
            {
                /*
                //Recording and Tax Fees table column numbers:
                //"Sel" - 1
                //"Descritpion" - 2
                //"Buyer Charge" - 3
                //"Seller Charge" - 4
                //"Total Charge" - 5
                 * */
                return FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction(2, Description, columnNumber, TableAction.GetCell).Element.FindElement(By.TagName("input")).IsEnabled();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsCellBlueOnTitleEscrowFeesTable(string Description, int columnNumber)
        {
            try
            {
                /*
                //Title and Escrow Fees table column numbers:
                //"Sel" - 1
                //"Descritpion" - 2
                //"Buyer Charge" - 3
                //"Sales Tax" - 4
                //PromColBuyer(hidden) 5
                //"Seller Charge" - 6
                //"Sales Tax" - 7
                //PromColSeller(hidden) - 8
                //"Total Charge" - 9
                 * */

                //title >> "Amount is not 100 % allocated."
                //class >> AmountNotAllocate
                FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction(2, Description, columnNumber, TableAction.GetCell).Element.FAFindElement(ByLocator.CssSelector, "input.AmountNotAllocate").IsDisplayed();
                Support.AreEqual("Amount is not 100% allocated.", FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction(2, Description, columnNumber, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").FAGetAttribute("title"), "Verifying tooltip message for " + Description + " on column " + columnNumber + "is 'Amount is not 100 % allocated.'");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsCellBlueOnRecordingTaxFeesTable(string Description, int columnNumber)
        {
            try
            {
                /*
                //Recording and Tax Fees table column numbers:
                //"Sel" - 1
                //"Description" - 2
                //"Buyer Charge" - 3
                //"Seller Charge" - 4
                //"Total Charge" - 5
                 * */

                //title >> "Amount is not 100 % allocated."
                //class >> AmountNotAllocate
                FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction(2, Description, columnNumber, TableAction.GetCell).Element.FAFindElement(ByLocator.CssSelector, "input.AmountNotAllocate").IsDisplayed();
                Support.AreEqual("Amount is not 100% allocated.", FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction(2, Description, columnNumber, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input").FAGetAttribute("title"), "Verifying tooltip message for " + Description + " on column " + columnNumber + "is 'Amount is not 100 % allocated.'");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsAddSubFeeButtonDisabledOnTitleAndEscrowSection(string ParentFeeDescription)
        {
            if (FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgAddSubFee").FAGetAttribute("disabled") == null)
            {
                Support.AreEqual(false, false, "Add Sub Fee button is enabled on parent fee: " + ParentFeeDescription);
                return false;
            }
            else
            {
                Support.AreEqual(true, true, "Add Sub Fee button is disabled on parent fee: " + ParentFeeDescription);
                return true;
            }
        }

        public bool IsAddSubFeeButtonDisabledOnRecAndTaxSection(string ParentFeeDescription)
        {
            if (FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgAddSubFee").FAGetAttribute("disabled") == null)
            {
                Support.AreEqual(false, false, "Add Sub Fee button is enabled on parent fee: " + ParentFeeDescription);
                return false;
            }
            else
            {
                Support.AreEqual(true, true, "Add Sub Fee button is disabled on parent fee: " + ParentFeeDescription);
                return true;
            }
        }

        public bool IsExpandCollapseSubFeeButtonDisabledOnTitleAndEscrowSection(string ParentFeeDescription)
        {
            if (FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgExpandCollapseSubFee").FAGetAttribute("disabled") == null)
            {
                Support.AreEqual(false, false, "Expand/Collapse Sub Fee button is enabled on parent fee: " + ParentFeeDescription);
                return false;
            }
            else
            {
                Support.AreEqual(true, true, "Expand/Collapse Sub Fee button is disabled on parent fee: " + ParentFeeDescription);
                return true;
            }
        }

        public bool IsExpandCollapseSubFeeButtonDisabledOnRecAndTaxSection(string ParentFeeDescription)
        {
            if (FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgExpandCollapseSubFee").FAGetAttribute("disabled") == null)
            {
                Support.AreEqual(false, false, "Expand/Collapse Sub Fee button is enabled on parent fee: " + ParentFeeDescription);
                return false;
            }
            else
            {
                Support.AreEqual(true, true, "Expand/Collapse Sub Fee button is disabled on parent fee: " + ParentFeeDescription);
                return true;
            }
        }

        public bool IsExpandCollapseSubFeeButtonDisplayedOnTitleAndEscrowSection(string ParentFeeDescription)
        {
            return FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgExpandCollapseSubFee").IsDisplayed();
        }

        public bool IsExpandCollapseSubFeeButtonDisplayedOnRecAndTaxSection(string ParentFeeDescription)
        {
            return FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgExpandCollapseSubFee").IsDisplayed();
        }

        public void ClickOnExpandCollapseSubFeeButtonDisplayedOnTitleAndEscrowSection(string ParentFeeDescription)
        {
            FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgExpandCollapseSubFee").FAClick();
        }

        public void ClickOnExpandCollapseSubFeeButtonDisplayedOnRecAndTaxSection(string ParentFeeDescription)
        {
            FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgExpandCollapseSubFee").FAClick();
        }

        public void ClickOnListOfSiteFilesLink()
        {
            this.FileSummaryInfoSubSec3Table.FindElement(By.CssSelector(".sflink")).FAClick();
            this.WaitCreation(SiteFilesInnerGridTable);
        }

        public ProjectWorkBench ClickCreateUpdateMenu(IWebElement menuOption = null)
        {
            WaitForScreenToLoad();
            Actions action = new Actions(FastDriver.WebDriver);
            action.MoveToElement(MenuIcon).MoveToElement(NewCreateUpdateTab).Perform();
            menuOption.FAClick();
            return this;
        }


        public void Open()
        {
            FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench");
            FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.Grid);
        }

        public void DoubleClickOnElement(IWebElement element)
        {
            Report.UpdateLog(element, "DoubleClick", "", "", () =>
            {
                new Actions(FastDriver.WebDriver).DoubleClick(element).Perform();
            });
        }

        public bool ValidateTitleEscrowFeesAreAlphabeticallyOrdered()
        {
            try
            {
                List<string> UnorderedUncheckedFeesList = new List<string>();
                List<string> OrderedUncheckedFeesList = new List<string>();

                ReadOnlyCollection<IWebElement> TableRows = FastDriver.ProjectWorkBench.TitleEscrowFeesTable.FindElements(By.CssSelector("tr:nth-child(n+2)"));
                foreach (IWebElement TableRow in TableRows)
                {
                    string FeeDescription = TableRow.FindElement(By.CssSelector("td:nth-child(2) label")).FAGetText();
                    OrderedUncheckedFeesList.Add(FeeDescription);
                    UnorderedUncheckedFeesList.Add(FeeDescription);
                }

                OrderedUncheckedFeesList.Sort();

                int FeeCount = 0;
                List<string> NoDuplicatesList = new List<string>(RemoveDuplicates(OrderedUncheckedFeesList));
                foreach (string Fee in RemoveDuplicates(OrderedUncheckedFeesList))
                {
                    if (NoDuplicatesList.IndexOf(Fee) != FeeCount)
                    {
                        return false;
                    }
                    ++FeeCount;
                }

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string[] RemoveDuplicates(List<string> s)
        {
            HashSet<string> set = new HashSet<string>(s);
            string[] result = new string[set.Count];
            set.CopyTo(result);
            return result;
        }

        public void NavigateToSiteFile(string siteFile)
        {
            Reports.TestStep = "Navigate to Site File: " + siteFile;
            FastDriver.ProjectWorkBench.Open();
            FastDriver.ProjectWorkBench.ClickOnListOfSiteFilesLink();
            FastDriver.ProjectWorkBench.SiteFilesInnerGridTable.PerformTableAction(1, siteFile, 1, TableAction.DoubleClick);
            FastDriver.FileHomepage.WaitForScreenToLoad();
        }

        public string GetHighlightedDescriptionFromTitleAndEscrowFeesTable()
        {
            try
            {
                return FastDriver.ProjectWorkBench.TitleEscrowFeesTable.FindElement(By.CssSelector("tr[style=\"background-color: rgb(255, 255, 160);\"]")).FAGetText();
            }
            catch (Exception)
            {
                //No Fee is highlighted
                return "";
            }
        }

        public string GetHighlightedDescriptionFromRecordingTaxFeesTable()
        {
            try
            {
                return FastDriver.ProjectWorkBench.RecordingTaxFeesTable.FindElement(By.CssSelector("tr[style=\"background-color: rgb(255, 255, 160);\"]")).FAGetText();
            }
            catch (Exception)
            {
                //No Fee is highlighted
                return "";
            }
        }

        public string GetHighlightedDescriptionFromSubFeeTable()
        {
            try
            {
                return FastDriver.ProjectWorkBench.SubFeeTable.FAFindElement(locator: ByLocator.CssSelector, criteria: ".matchedHighlightText").FAGetText();
            }
            catch (Exception)
            {
                //No Fee is highlighted
                return "";
            }
        }

        public bool IsFeeEditableOnTitleAndEscrowTable(string FeeDescription)
        {
            try
            {
                return FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction("Description", FeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(locator: ByLocator.TagName, criteria: "input").Exists();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsFeeEditableOnRecAndTaxTable(string FeeDescription)
        {
            try
            {
                return FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction("Description", FeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(locator: ByLocator.TagName, criteria: "input").Exists();
            }
            catch (Exception)
            {
                return false;
            }
        }

        //TODO: FIX
        public bool IsFeeEditableOnAllocateFeesSlider(string FeeDescription)
        {
            try
            {
                FastDriver.ProjectWorkBench.SiteFilesFeeSliderFeeDesc.FAFindElement(locator: ByLocator.TagName, criteria: "input");
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string GetDescriptionFromHighlightedRowOnTitleEscrowFeesTable()
        {
            string description = "";
            try
            {
                description = FastDriver.ProjectWorkBench.TitleEscrowFeesTable.FAFindElement(ByLocator.CssSelector, "tr[style=\"background-color: rgb(255, 255, 160);\"]").FAFindElement(ByLocator.Id, "lblDescription").FAGetValue();
            }
            catch (Exception)
            {
                //TODO: Log something?
            }
            return description;
        }

        public string GetDescriptionFromHighlightedRowOnRecAndTaxFeesTable()
        {
            string description = "";
            try
            {
                description = FastDriver.ProjectWorkBench.RecordingTaxFeesTable.FAFindElement(ByLocator.CssSelector, "tr[style=\"background-color: rgb(255, 255, 160);\"]").FAFindElement(ByLocator.Id, "lblDescription").FAGetValue();
            }
            catch (Exception)
            {
                //TODO: Log something?
            }
            return description;
        }

        public void ClickOnAddSubFeesButtonForParentTitleEscrowFee(string ParentFeeDescription)
        {
            try
            {
                FastDriver.ProjectWorkBench.TitleEscrowFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgAddSubFee").FAClick();
            }
            catch (Exception)
            {
                //TODO: Log something...
            }
        }

        public void ClickOnAddSubFeesButtonForParentRecAndTaxFee(string ParentFeeDescription)
        {
            try
            {
                FastDriver.ProjectWorkBench.RecordingTaxFeesTable.PerformTableAction("Description", ParentFeeDescription, "Description", TableAction.GetCell).Element.FAFindElement(ByLocator.Id, "imgAddSubFee").FAClick();
            }
            catch (Exception)
            {
                //TODO: Log something...
            }
        }

        public void CreateCustomSiteFile(string Country = "USA", string State = "", string CustomSiteFile = "", string Address = "", string City = "", string ZIPCode = "", string County = "",
            bool CopyBuyer = false, bool CopySeller = false, bool CopyLender = false)
        {
            try
            {
                ClickOnCreateSiteFilesLink();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SiteFilesTable);
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "Country", TableAction.SelectItemBySendkeys, Country);
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "State", TableAction.SelectItemBySendkeys, State);//look for new row (empty fields)
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "Custom Site File #", TableAction.SetText, CustomSiteFile);
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "Address", TableAction.SetText, Address);
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "City", TableAction.SetText, City);
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "Zip", TableAction.SetText, ZIPCode);
                FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", "", "County", TableAction.SetText, County);
                if (CopyBuyer)
                {
                    do
                    {
                        FastDriver.ProjectWorkBench.Buyer.FAClick();
                    }
                    while (!FastDriver.ProjectWorkBench.Buyer.IsSelected());
                    Support.AreEqual(true, FastDriver.ProjectWorkBench.Buyer.IsSelected(), "Verifying Buyer checkbox is selected");
                }
                if (CopySeller)
                {
                    do
                    {
                        FastDriver.ProjectWorkBench.Seller.FAClick();
                    }
                    while (!FastDriver.ProjectWorkBench.Seller.IsSelected());
                    Support.AreEqual(true, FastDriver.ProjectWorkBench.Seller.IsSelected(), "Verifying Seller checkbox is selected");
                }
                if (CopyLender)
                {
                    do
                    {
                        FastDriver.ProjectWorkBench.Lender.FAClick();
                    }
                    while (!FastDriver.ProjectWorkBench.Lender.IsSelected());
                    Support.AreEqual(true, FastDriver.ProjectWorkBench.Lender.IsSelected(), "Verifying Lender checkbox is selected");
                }
                FastDriver.ProjectWorkBench.Create.FAClick();
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.ErrorMessage);
                Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessage.FAGetText().Contains("1 File(s) successfully created."), "Verify custom site file was successfully created.");
                Support.AreEqual(CustomSiteFile, FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", CustomSiteFile, "Custom Site File #", TableAction.GetInputValue).Message, "Verify site file was created with custom #.");
            }
            catch (Exception)
            {

            }
        }

        public void CreateCopySiteFile(string CustomSiteFile, bool CopyLender = false, bool CopyBuyer = false, bool CopySeller = false)
        {
            ClickOnCreateSiteFilesLink();
            FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.CopyAllAddresses);
            int i = 0;
            do
            {
                FastDriver.ProjectWorkBench.CopyAllAddresses.FASetCheckbox(true);
                i++;
                if (i == 10)
                    break;
            }
            while (!FastDriver.ProjectWorkBench.CopyAllAddresses.IsSelected());

            Support.AreEqual(true, FastDriver.ProjectWorkBench.CopyAllAddresses.IsSelected(), "Verifying Copy All Addresses checkbox is selected");
            FastDriver.ProjectWorkBench.CopyLenderData.FASetCheckbox(CopyLender);
            FastDriver.ProjectWorkBench.CopyBuyerData.FASetCheckbox(CopyBuyer);
            FastDriver.ProjectWorkBench.CopySellerData.FASetCheckbox(CopySeller);
            FastDriver.ProjectWorkBench.Create.FAClick();
            FastDriver.ProjectWorkBench.WaitForScreenToLoad(FastDriver.ProjectWorkBench.SiteFileNum);
            Support.AreEqual(true, FastDriver.ProjectWorkBench.ErrorMessage.FAGetText().Contains("1 File(s) successfully created."), "Verify custom site file was successfully created.");
            Support.AreEqual(CustomSiteFile, FastDriver.ProjectWorkBench.SiteFilesTable.PerformTableAction("Custom Site File #", CustomSiteFile, "Custom Site File #", TableAction.GetInputValue).Message, "Verify site file was created with custom #.");

        }
        //TODO: Remove from FMUC0127_Project_Workbench class
        public void ClickOnCreateSiteFilesLink()
        {
            Actions action = new Actions(FastDriver.WebDriver);
            IWebElement Grid = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#tabs_Menu_Img");//Menu icon
            IWebElement NewCreateUpdateTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBCU']");//Create/Update tab
            if (!NewCreateUpdateTab.IsDisplayed())
            {
                //Reports.TestStep = "Click on Menu icon if Fees tab is not shown";
                action.Click(Grid).Perform();//if menu is not showing the tabs, then click on it
                NewCreateUpdateTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBCU']");//Fees tab
                FastDriver.ProjectWorkBench.WaitForScreenToLoad(NewCreateUpdateTab);
            }
            //Reports.TestStep = "Hover on Create/Update tab";
            action.MoveToElement(NewCreateUpdateTab).Perform();
            IWebElement CreateUpdateCreateSiteFiles = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#scPTWBCSF");//Create Site Files link
            action.Click(CreateUpdateCreateSiteFiles).Perform();
        }

        public string GetTextFromMenuLinkHighlightedInOrange()
        {
            //Remember to MoveToElement before calling this method
            string textFromMenuLinkHighlightedInOrange = "";
            try
            {
                textFromMenuLinkHighlightedInOrange = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAFtabs-content li div:hover").FAGetText();
            }
            catch (Exception)
            {
                textFromMenuLinkHighlightedInOrange = "";
            }
            return textFromMenuLinkHighlightedInOrange;
        }

        public bool IsCreateSiteFilesLinkHighlightedInOrange()
        {
            try
            {
                Actions action = new Actions(FastDriver.WebDriver);
                IWebElement Grid = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#tabs_Menu_Img");//Menu icon
                IWebElement NewCreateUpdateTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBCU']");//Create/Update tab
                if (!NewCreateUpdateTab.IsDisplayed())
                {
                    //Click on Menu icon if Create/Update tab is not show
                    action.Click(Grid).Perform();//if menu is not showing the tabs, then click on it
                    NewCreateUpdateTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBCU']");//Create/Update tab
                    FastDriver.ProjectWorkBench.WaitForScreenToLoad(NewCreateUpdateTab);
                }
                //Hover on Create/Update tab
                action.MoveToElement(NewCreateUpdateTab).Perform();
                IWebElement CreateUpdateCreateSiteFiles = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#scPTWBCSF");//Create Site Files link
                //Hover on Create Site Files link
                action.MoveToElement(CreateUpdateCreateSiteFiles).Perform();
                if ("Create Site Files" == GetTextFromMenuLinkHighlightedInOrange())
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsUpdateSiteFilesLinkHighlightedInOrange()
        {
            try
            {
                Actions action = new Actions(FastDriver.WebDriver);
                IWebElement Grid = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#tabs_Menu_Img");//Menu icon
                IWebElement NewCreateUpdateTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBCU']");//Create/Update tab
                if (!NewCreateUpdateTab.IsDisplayed())
                {
                    //Click on Menu icon if Create/Update tab is not shown
                    action.Click(Grid).Perform();//if menu is not showing the tabs, then click on it
                    NewCreateUpdateTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBCU']");//Create/Update tab
                    FastDriver.ProjectWorkBench.WaitForScreenToLoad(NewCreateUpdateTab);
                }
                //Hover on Create/Update tab
                action.MoveToElement(NewCreateUpdateTab).Perform();
                IWebElement CreateUpdateUpdateSiteFiles = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#scPTWBUSF");//Update Site Files link
                //Hover on Update Site Files link
                action.MoveToElement(CreateUpdateUpdateSiteFiles).Perform();
                if ("Update Site Files" == GetTextFromMenuLinkHighlightedInOrange())
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsTitleAndEscrowFeesLinkHighlightedInOrange()
        {
            try
            {
                Actions action = new Actions(FastDriver.WebDriver);
                IWebElement Grid = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#tabs_Menu_Img");//Menu icon
                IWebElement NewFeesTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBFS']");//Fees tab
                if (!NewFeesTab.IsDisplayed())
                {
                    //Click on Menu icon if Fees tab is not shown
                    action.Click(Grid).Perform();//if menu is not showing the tabs, then click on it
                    NewFeesTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBFS']");//Fees tab
                    FastDriver.ProjectWorkBench.WaitForScreenToLoad(NewFeesTab);
                }
                //Hover on Fees tab
                action.MoveToElement(NewFeesTab).Perform();
                IWebElement FeesTitleAndEscrow = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#scPTWBTEF");//Title and Escrow Fees link
                //Click on Title and Escrow link
                action.MoveToElement(FeesTitleAndEscrow).Perform();
                if ("Title and Escrow" == GetTextFromMenuLinkHighlightedInOrange())
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsRecordingAndTaxFeesLinkHighlightedInOrange()
        {
            try
            {
                Actions action = new Actions(FastDriver.WebDriver);
                IWebElement Grid = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#tabs_Menu_Img");//Menu icon
                IWebElement NewFeesTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBFS']");//Fees tab
                if (!NewFeesTab.IsDisplayed())
                {
                    //Click on Menu icon if Fees tab is not shown
                    action.Click(Grid).Perform();//if menu is not showing the tabs, then click on it
                    NewFeesTab = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, ".FAF-tabs-navigation li a[data-content='cPTWBFS']");//Fees tab
                    FastDriver.ProjectWorkBench.WaitForScreenToLoad(NewFeesTab);
                }
                //Hover on Fees tab
                action.MoveToElement(NewFeesTab).Perform();
                IWebElement FeesTitleAndEscrow = FastDriver.WebDriver.FAFindElement(ByLocator.CssSelector, "#scPTWBRTF");//Rec and Tax Fees link
                //Click on Rec and Tax link
                action.MoveToElement(FeesTitleAndEscrow).Perform();
                if ("Recording and Tax" == GetTextFromMenuLinkHighlightedInOrange())
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsCreateUpdateArrowIconConfiguredToRotate()
        {
            try
            {
                FastDriver.ProjectWorkBench.CreateUpdateMenuArrowIcon.FAMoveToElement();
                if ("arrowIconheader rotateArrowImage" == FastDriver.WebDriver.FAFindElement(ByLocator.Id, "img_headericon cPTWBCU").FAGetAttribute("class"))
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public bool IsFeesArrowIconConfiguredToRotate()
        {
            try
            {
                FastDriver.ProjectWorkBench.FeesMenuArrowIcon.FAMoveToElement();
                if ("arrowIconheader rotateArrowImage" == FastDriver.WebDriver.FAFindElement(ByLocator.Id, "img_headericon cPTWBFS").FAGetAttribute("class"))
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //TODO: Refactor to use an enum or maybe accept a webelement as a parameter
        //Methods affected: IsSiteFilesFeeSliderSiteFileNumberColumnSortedByDefault, IsSiteFilesInnerGridCityColumnSortedByDefault, IsSiteFilesInnerGridCountyColumnSortedByDefault, IsSiteFilesInnerGridStateColumnSortedByDefault
        public bool IsSiteFilesFeeSliderSiteFileNumberColumnSortedDesc()
        {
            try
            {
                return SiteFilesFeeSliderSiteFileNumber.FAFindElement(ByLocator.ClassName, "sorting_desc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesInnerGridCityColumnSortedDesc()
        {
            try
            {
                return SiteFilesInnerGridCity.FAFindElement(ByLocator.ClassName, "sorting_desc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesInnerGridCountyColumnSortedDesc()
        {
            try
            {
                return SiteFilesInnerGridCounty.FAFindElement(ByLocator.ClassName, "sorting_desc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesInnerGridStateColumnSortedDesc()
        {
            try
            {
                return SiteFilesFeeSliderState.FAFindElement(ByLocator.ClassName, "sorting_desc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesFeeSliderSiteFileNumberColumnSortedAsc()
        {
            try
            {
                return SiteFilesFeeSliderSiteFileNumber.FAFindElement(ByLocator.ClassName, "sorting_asc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesInnerGridCityColumnSortedAsc()
        {
            try
            {
                return SiteFilesInnerGridCity.FAFindElement(ByLocator.ClassName, "sorting_asc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesInnerGridCountyColumnSortedAsc()
        {
            try
            {
                return SiteFilesInnerGridCounty.FAFindElement(ByLocator.ClassName, "sorting_asc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool IsSiteFilesInnerGridStateColumnSortedAsc()
        {
            try
            {
                return SiteFilesFeeSliderState.FAFindElement(ByLocator.ClassName, "sorting_asc").IsDisplayed();
            }
            catch (Exception)
            {
                return false;
            }
        }

        #endregion PageObjectMethods

        #region Project Workbench Dialogs

        public LenderSelectionDlg LenderSelectionDlg
        {
            get { return FastDriver.GetPage<LenderSelectionDlg>(); }
        }

        public SiteFilesReportDlg SiteFilesReportDlg
        {
            get { return FastDriver.GetPage<SiteFilesReportDlg>(); }
        }

        public BuyerSelectionDlg BuyerSelectionDlg
        {
            get { return FastDriver.GetPage<BuyerSelectionDlg>(); }
        }

        public SellerSelectionDlg SellerSelectionDlg
        {
            get { return FastDriver.GetPage<SellerSelectionDlg>(); }
        }

    }

    public class LenderSelectionDlg : PageObject
    {

        [FindsBy(How = How.Id, Using = "tblLender")]
        public IWebElement LenderSelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "tblUpdateLender")]
        public IWebElement UpdateLenderSelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneLenCrt")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelLenCrt")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneLenUpdt")]
        public IWebElement UpdateDone { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelLenUpdt")]
        public IWebElement UpdateCancel { get; set; }

        [FindsBy(How = How.ClassName, Using = "ui-dialog-title")]
        public IWebElement DialogTitle { get; set; }

        public LenderSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.WaitCreation(element ?? LenderSelectionTable);
            return this;
        }

    }

    public class SiteFilesReportDlg : PageObject
    {

        [FindsBy(How = How.Id, Using = "grdSiteFilesInnerGrid")]
        public IWebElement SiteFilesReportTable { get; set; }

        [FindsBy(How = How.Id, Using = "idDone")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "idCancel")]
        public IWebElement Cancel { get; set; }

        public SiteFilesReportDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.WaitCreation(element ?? SiteFilesReportTable);
            return this;
        }

    }

    public class BuyerSelectionDlg : PageObject
    {
        [FindsBy(How = How.Id, Using = "tblBuyerUpdt")]
        public IWebElement BuyerSelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkSelectAllBuyerUpdt")]
        public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.Id, Using = "btnDoneBSUpdt")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelBSUpdt")]
        public IWebElement Cancel { get; set; }

        public BuyerSelectionDlg WaitForScreenToLoad()
        {
            this.WaitCreation(BuyerSelectionTable);
            return this;
        }
    }


    public class SellerSelectionDlg : PageObject
    {
        [FindsBy(How = How.Id, Using = "tblSellerUpdt")]
        public IWebElement SellerSelectionTable { get; set; }

        [FindsBy(How = How.Id, Using = "chkSelectAllSellerUpdt")]
        public IWebElement CheckAll { get; set; }
        
        [FindsBy(How = How.Id, Using = "btnDoneBSUpdt")]
        public IWebElement Done { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancelBSUpdt")]
        public IWebElement Cancel { get; set; }

        public SellerSelectionDlg WaitForScreenToLoad()
        {
            this.WaitCreation(SellerSelectionTable);
            return this;
        }
    }
    #endregion

}
