using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class PropertyTaxCheck : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bp_labelName")]
        public IWebElement gabLabelName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelName2")]
        public IWebElement gabLabelName1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_2_tbd")]
        public IWebElement buyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_3_tbd")]
        public IWebElement buyerCredit3 { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdCheckDetails")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bp_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtName")]
        public IWebElement GABName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEditContactInfo")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusPhone")]
        public IWebElement BusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_txtExtnPhone")]
        public IWebElement BusPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textBusFax")]
        public IWebElement BusFax { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkWeeklyEmailStatus")]
        public IWebElement StatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "bp_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bp_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bp_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_btnPayment")]
        public IWebElement PropertyTaxesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "txtPBbyBuyerAtClosing")]
        public IWebElement PTPBbyBuyerAtClosing { get; set; }

        [FindsBy(How = How.Id, Using = "txtBPbyOthers")]
        public IWebElement PTBPbyOthers { get; set; }

        [FindsBy(How = How.Id, Using = "ddlOthersBuyer")]
        public IWebElement DropdownPT { get; set; }

        [FindsBy(How = How.Id, Using = "btnDone")]
        public IWebElement PDDdone { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_0_tdsc")]
        public IWebElement PropertyTaxesDesc_1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_0_tbc")]
        public IWebElement PropertyTaxesBuyerCharge_1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_1_tbc")]
        public IWebElement PropertyTaxesBuyerCharge_2 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_2_tbc")]
        public IWebElement PropertyTaxesBuyerCharge_3 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_3_tbc")]
        public IWebElement PropertyTaxesBuyerCharge_4 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_4_tbc")]
        public IWebElement PropertyTaxesBuyerCharge_5 { get; set; }
        [FindsBy(How = How.Id, Using = "CGSt_dcs_0_tbd")]
        public IWebElement PropertyTaxesBuyerCredit_1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_0_tsc")]
        public IWebElement PropertyTaxesSellerCharge_1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_0_tsr")]
        public IWebElement PropertyTaxesSellerCredit_1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGDy_btnPayment")]
        public IWebElement AdditionalChargesPaymentDetails { get; set; }

        [FindsBy(How = How.Id, Using = "CGDy_dcs")]
        public IWebElement AdditionalChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "CGDy_dcs_0_tdsc")]
        public IWebElement AdditionalChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "CGDy_dcs_0_tbc")]
        public IWebElement AdditionalChargesbuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "CGDy_dcs_1_tbc")]
        public IWebElement AdditionalChargesbuyerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGDy_dcs_0_tsc")]
        public IWebElement AdditionalChargesSellerCharge { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusOrgID: Business Party")]
        public IWebElement BusinessPartyRequiredPane { get; set; }

        [FindsBy(How = How.CssSelector, Using = "img[src=\"../images/ico_write.gif\"]")]
        public IWebElement PenciImage { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Thistextfieldconsistsofonlyblanksortabs { get; set; }

        [FindsBy(How = How.Id, Using = "lblhwChkamount")]
        public IWebElement CheckIssuedImage { get; set; }

        [FindsBy(How = How.Id, Using = "lblhwChkamount")]
        public IWebElement CheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelIdcode")]
        public IWebElement GABcodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bp_labelContactName")]
        public IWebElement ContactName { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_0_tga")]
        public IWebElement PropertyTaxesLoanEstimate_1 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_1_tdsc")]
        public IWebElement PropertyTaxesDesc_2 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_1_tsc")]
        public IWebElement PropertyTaxesSellerCharge_2 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_2_tsc")]
        public IWebElement PropertyTaxesSellerCharge_3 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_3_tsc")]
        public IWebElement PropertyTaxesSellerCharge_4 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_1_tga")]
        public IWebElement PropertyTaxesLoanEstimate_2 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_1_tsr")]
        public IWebElement PropertyTaxesSellerCredit_2 { get; set; }

        [FindsBy(How = How.Id, Using = "CGSt_dcs_1_tbd")]
        public IWebElement PropertyTaxesBuyerCredit_2 { get; set; }
               
        [FindsBy(How = How.Id, Using = "CGSt_dcs")]
        public IWebElement PropertyTaxesTable { get; set; }

        #endregion

        public PropertyTaxCheck Open()
        {
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Escrow Charge Processes>Property Tax Check");
            this.WaitForScreenToLoad();

            return this;
        }

        public PropertyTaxCheck WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(GABcode);

            return this;
        }

        public PropertyTaxCheck FindGABCode(string GABCode, bool waitForValue = true)
        {
            this.SwitchToContentFrame();
            GABcode.FASetText(GABCode);
            Find.FAClick();
            if (waitForValue)
                this.WaitForValue(GABcodeLabel, GABCode);
            return this;
        }

        public PropertyTaxCheck UpdatePropertyTaxesTable(string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, string editdescription = "")
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PropertyTaxesTable, 10);
            var rows = PropertyTaxesTable.FindElements(By.TagName("tr"));

            //IWebElement row = rows.
            //    FirstOrDefault(tempRow => tempRow.FindElements(By.TagName("input")).FirstOrDefault(ipt => ipt.GetAttribute("id").Contains("_tdsc") && ipt.Displayed)
            //        .GetAttribute("value").Trim().Contains(chargeDescription));

            IWebElement row = null;
            foreach (var tempRow in rows)
            {
                IWebElement descriptionInput = tempRow.FindElements(By.TagName("input")).FirstOrDefault(i => i.GetAttribute("id").Contains("_tdsc") && i.Displayed);
                try
                {
                    if (descriptionInput.GetAttribute("value").Trim().Contains(chargeDescription))
                    {
                        row = tempRow;
                        break;
                    }
                }
                catch (NullReferenceException)
                {
                    continue;
                }
            }

            if (row == null)
                throw new NoSuchElementException(string.Format("Could not find an Impound Charge with description '{0}'", chargeDescription));

            IWebElement inputElement;
            if (buyerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbc") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(buyerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (buyerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tbd") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(buyerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (sellerCharge.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsc") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(sellerCharge.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (sellerCredit.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tsr") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(sellerCredit.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }
            if (loanEstimate.HasValue)
            {
                inputElement = row.FindElements(By.TagName("input")).FirstOrDefault(input => input.GetAttribute("id").Contains("_tga") && input.Displayed);
                inputElement.Click();
                inputElement.FireEvent("onfocus");
                Keyboard.SendKeys("{DEL}");
                inputElement.FASetText(loanEstimate.ToString() + Keys.Delete + Keys.Delete + Keys.Delete + Keys.Delete);
                inputElement.FireEvent("onkeyup");
                inputElement.FireEvent("onkeydown");
                inputElement.FireEvent("onchange");
                inputElement.FireEvent("onblur");
            }

            return this;
        }

        public void AddChargeRefinance(IWebElement chargesTable, string chargeDescription, double? BorrowerCharge = null, double? BorrowerCredit = null, double? loanEstimate = null)
        {
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Charge", TableAction.SetText, BorrowerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (BorrowerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Borrower Credit", TableAction.SetText, BorrowerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }


            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

        }

        public PropertyTaxCheck AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }

        public PropertyTaxCheck UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

    }
}
