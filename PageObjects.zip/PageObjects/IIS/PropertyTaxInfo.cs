using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UITesting;
namespace FASTSelenium.PageObjects.IIS
{
    public class PropertiesSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridPTaxSumry")]
        public IWebElement Table { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPTaxSumry")]
        public IWebElement PropertiesSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPTaxSumry_0_lblPropName")]
        public IWebElement PropertyName1 { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTabHeader { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTabHeader { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTmShr")]
        public IWebElement TimeShareTabHeader { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTabHeader { get; set; }

         [FindsBy(How = How.Id, Using = "dgridPTaxSumry_0_lblPropName")]
        public IWebElement SummaryRow1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPTaxSumry_1_lblPropName")]
        public IWebElement SummaryRow2 { get; set; }

        #endregion

        public PropertiesSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<PropertiesSummary>("Home>Order Entry>Properties/Tax Info");
            this.WaitForScreenToLoad();

            return this;
        }

        public PropertiesSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Edit);

            return this;
        }

        public void EditAddress(string rownumber)
        {
            this.Open();
            this.SwitchToContentFrame();
            this.PropertiesSummaryTable.PerformTableAction(1, rownumber, 1, TableAction.Click);
            this.Edit.FAClick();
            FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
        }

    }

    public class PropertyTaxInfoGeneral : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_lblSeqNum")]
        public IWebElement SeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabGnrl")]
        public IWebElement GeneralTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_gridAddress")]
        public IWebElement PropertyAdressTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_gridAddress_1_lblAddLine1")]
        public IWebElement PropertyAdressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_txtName")]
        public IWebElement GeneralPropertyInformationName { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ddlPropType")]
        public IWebElement GeneralPropertyInformationPropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_btnFsSrch")]
        public IWebElement GeneralFASTSearch { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_btnNewAdd")]
        public IWebElement GeneralNew { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_btnCopyAdd")]
        public IWebElement GeneralCopy { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_btnRemoveAdd")]
        public IWebElement GeneralRemove { get; set; }

        [FindsBy(How = How.CssSelector, Using = "td#tdAddDet #tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine1")]
        public IWebElement GeneralAddressDetailStreetLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine2")]
        public IWebElement GeneralAddressDetailStreetLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine3")]
        public IWebElement GeneralAddressDetailStreetLine3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtAddrLine4")]
        public IWebElement GeneralAddressDetailStreetLine4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtCity")]
        public IWebElement GeneralAddressDetailCity { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_cboState")]
        public IWebElement GeneralAddressDetailState { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtZip")]
        public IWebElement GeneralAddressDetailZip { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_txtCounty")]
        public IWebElement GeneralAddressDetailCounty { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_ucPhyAddr_cboCountry")]
        public IWebElement GeneralAddressDetailCountry { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_cboSrchTyp")]
        public IWebElement GeneralSearchType { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_btnAddRmv")]
        public IWebElement GeneralAddRemoveInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_txtInstr")]
        public IWebElement GeneralInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_txtAddInstr")]
        public IWebElement GeneralAdditionalInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabGnrl_GEN_txtComm")]
        public IWebElement GeneralComments { get; set; }

        #endregion

        public PropertyTaxInfoGeneral WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GeneralAddressDetailStreetLine1);
            return this;
        }

        public PropertyTaxInfoGeneral FillPropertyGeneralInfoForm(PropertyAddressParameters info)
        {
            this.SwitchToContentFrame();
            GeneralAddressDetailStreetLine1.FASetText(info.StreetLine1);
            GeneralAddressDetailStreetLine2.FASetText(info.StreetLine2);
            GeneralAddressDetailStreetLine3.FASetText(info.StreetLine3);
            GeneralAddressDetailCity.FASetText(info.City);
            GeneralAddressDetailState.FASelectItem(info.State);
            GeneralAddressDetailZip.FASetText(info.Zip);
            GeneralAddressDetailCounty.FASetText(info.County);
            return this;
        }

        public Dictionary<string, string> GetPropertyDetails()
        {
            this.WaitForScreenToLoad();
            PropertyTaxInfoLegalDesciption LegalDesc=new PropertyTaxInfoLegalDesciption();
            Dictionary<string, string> PropDetails = new Dictionary<string, string>();
            try
            {
                PropDetails.Add("AddressLine1", GeneralAddressDetailStreetLine1.FAGetText());
                PropDetails.Add("AddressLine2", GeneralAddressDetailStreetLine2.FAGetText());
                PropDetails.Add("AddressLine3", GeneralAddressDetailStreetLine3.FAGetText());
                PropDetails.Add("City", GeneralAddressDetailCity.FAGetText());
                PropDetails.Add("State", GeneralAddressDetailState.FAGetSelectedItem());
                PropDetails.Add("Zip", GeneralAddressDetailZip.FAGetText());
                PropDetails.Add("County", GeneralAddressDetailCounty.FAGetText());
                //
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab();
                Thread.Sleep(7000);
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                PropDetails.Add("Lot1", FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetText());
                PropDetails.Add("Block1", FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetText());
                PropDetails.Add("Unit1", FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetText());
                //
                FastDriver.PropertyTaxInfoGeneral.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad();
                PropDetails.Add("PropertyPropTaxAPN1", FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction("#1", "Prop1APN1", "#1", TableAction.GetText).Message);
                PropDetails.Add("PropertyPropTaxAPN2", FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction("#1", "9845012345", "#1", TableAction.GetText).Message);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return PropDetails;
        }

        public PropertyTaxInfoLegalDesciption ClickLegalDescriptionTab()
        {
            this.SwitchToContentFrame();
            LegalDescriptionTab.FAClick();

            return FastDriver.GetPage<PropertyTaxInfoLegalDesciption>();
        }


        public PropertyTaxInfoGeneral ClickTitleProdTab()
        {
            WaitForScreenToLoad();
            TitleProductionTab.FAClick();
            return this;
        }
    }

    public class PropertyTaxInfoLegalDesciption : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_lblSeqNum")]
        public IWebElement LegalSeqNo { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabGnrl")]
        public IWebElement GeneralTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_ddlPropType")]
        public IWebElement PropertyType { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtLot")]
        public IWebElement Lot { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtBlock")]
        public IWebElement Block { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtUnit")]
        public IWebElement Unit { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtTRact")]
        public IWebElement Tract { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtFee")]
        public IWebElement Fee { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtBuilding")]
        public IWebElement Building { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtBook")]
        public IWebElement Book { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtPage")]
        public IWebElement Page { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtSection")]
        public IWebElement Section { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtTownShip")]
        public IWebElement TownShip { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtRange")]
        public IWebElement Range { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtParcel")]
        public IWebElement Parcel { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtSubDivCondo")]
        public IWebElement SubdivisionCondo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtPhase")]
        public IWebElement Phase { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtGovtLotNo")]
        public IWebElement GovtLotNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtBorough")]
        public IWebElement Borough { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtProvince")]
        public IWebElement Province { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_txtParish")]
        public IWebElement CountyParish { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_chkEReg")]
        public IWebElement Ereg { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_chkConvReq")]
        public IWebElement ConversionRequired { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_chkUnincorp")]
        public IWebElement Unincorporated { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_shrtLglDesc_ddlEstateType")]
        public IWebElement EstateType { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRBook")]
        public IWebElement RecordingBook { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRPage")]
        public IWebElement RecordingPage { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRMapNo")]
        public IWebElement RecordingMapNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRMapDt")]
        public IWebElement RecordingMapDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRRBook")]
        public IWebElement ReRecordingBook { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRRPage")]
        public IWebElement ReRecordingPage { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRRMapNo")]
        public IWebElement ReRecordingMapNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtRRMapDt")]
        public IWebElement ReRecordingMapDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_btnRefrsh")]
        public IWebElement AbbreviatedLegalDescriptionRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_cmdAChkSpell")]
        public IWebElement AbbreviatedLegalDescriptionCheckSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_ddlACountyPhr")]
        public IWebElement AbbreviatedLegalDescriptionCountyPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_chkAtchLgl")]
        public IWebElement AbbrLegalDesciptionAttachedLegalReference { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtAbrvComnts")]
        public IWebElement AbbrLegalDesciptionComments { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_cmdCView")]
        public IWebElement CompleteLegalDescriptionView { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_cmdCRefresh")]
        public IWebElement CompleteLegalDescriptionRefresh { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_cmdCChkSpell")]
        public IWebElement CompleteLegalDescriptioncheckSpelling { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_ddlCCountyPhr")]
        public IWebElement CompleteLegalDescriptioncountyPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabLglDsc_LGL_txtCmpltComnts")]
        public IWebElement CompleteLegalDescriptionComments { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement Error { get; set; }

        [FindsBy(How = How.Id, Using = "txtPhrase")]
        public IWebElement LongLegalDescription { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMasg { get; set; }

        #endregion

        public PropertyTaxInfoLegalDesciption WaitForScreenToLoad()
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
            this.SwitchToContentFrame();
            Playback.Wait(250);
            this.WaitCreation(Lot);
            return this;
        }

        public PropertyTaxInfoLegalDesciption FillPropertyLegalInfoForm(PropertyAddressParameters info)
        {
            this.SwitchToContentFrame();
            Lot.FASetText(info.Lot);
            Block.FASetText(info.Block);
            Unit.FASetText(info.Unit);
            return this;
        }

        public PropertyTaxInfoAnnualTax ClickTaxTab()
        {
            this.SwitchToContentFrame();
            TaxTab.FAClick();

            return FastDriver.GetPage<PropertyTaxInfoAnnualTax>();
        }
    }

    public class PropertyTaxInfoAnnualTax : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPymnt3")]
        public IWebElement AnnualTaxpartialPaymentAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabGnrl")]
        public IWebElement GeneralTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_pnlSumm")]
        public IWebElement Summarytable { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_grdSumm")]
        public IWebElement Summarytable1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_btnRmv")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_grdSumm_0_lblGrdTaxNoApn")]
        public IWebElement TopMostAPN { get; set; }

        [FindsBy(How = How.LinkText, Using = "2006-2007")]
        public IWebElement TaxYear { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_chkAGnrt")]
        public IWebElement GenerateTaxCheck { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_btnAPyCl")]
        public IWebElement PayAtClose { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtADet")]
        public IWebElement AnnualTaxDetailforTaxIDAPN { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtATxy")]
        public IWebElement AnnualTaxTaxYear { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtATrNo")]
        public IWebElement AnnualTaxTraNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtATotx")]
        public IWebElement AnnualTaxTotalInstallmentTax { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnVol1")]
        public IWebElement AnnualTaxVolumeNo1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnVol2")]
        public IWebElement AnnualTaxVolumeNo2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnVol3")]
        public IWebElement AnnualTaxVolumeNo3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnVol4")]
        public IWebElement AnnualTaxVolumeNo4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_cboAnStatus1")]
        public IWebElement AnnualTaxStatus1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_cboAnStatus2")]
        public IWebElement AnnualTaxStatus2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_cboAnStatus3")]
        public IWebElement AnnualTaxStatus3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_cboAnStatus4")]
        public IWebElement AnnualTaxStatus4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDuedt1")]
        public IWebElement AnnualTaxDueDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDuedt2")]
        public IWebElement AnnualTaxDueDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDuedt3")]
        public IWebElement AnnualTaxDueDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDuedt4")]
        public IWebElement AnnualTaxDueDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInstl1")]
        public IWebElement AnnualTaxInstallmentAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInstl2")]
        public IWebElement AnnualTaxInstallmentAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInstl3")]
        public IWebElement AnnualTaxInstallmentAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInstl4")]
        public IWebElement AnnualTaxInstallmentAmount4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInt1")]
        public IWebElement AnnualTaxInterest1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInt2")]
        public IWebElement AnnualTaxInterest2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInt3")]
        public IWebElement AnnualTaxInterest3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnInt4")]
        public IWebElement AnnualTaxInterest4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPnlty1")]
        public IWebElement AnnualTaxPenality1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPnlty2")]
        public IWebElement AnnualTaxPenality2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPnlty3")]
        public IWebElement AnnualTaxPenality3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPnlty4")]
        public IWebElement AnnualTaxPenality4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPymnt1")]
        public IWebElement AnnualTaxpartialPaymentAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPymnt2")]
        public IWebElement AnnualTaxpartialPaymentAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPymnt3")]
        public IWebElement partialPaymentAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPymnt4")]
        public IWebElement AnnualTaxpartialPaymentAmount4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnBal1")]
        public IWebElement AnnualTaxBalanceDue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnBal2")]
        public IWebElement AnnualTaxBalanceDue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnBal3")]
        public IWebElement AnnualTaxBalanceDue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnBal4")]
        public IWebElement AnnualTaxBalanceDue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDtpd1")]
        public IWebElement AnnualTaxDatePaid1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDtpd2")]
        public IWebElement AnnualTaxDatePaid2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDtpd3")]
        public IWebElement AnnualTaxDatePaid3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDtpd4")]
        public IWebElement AnnualTaxDatePaid4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDlnq1")]
        public IWebElement AnnualTaxDelinquentDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDlnq2")]
        public IWebElement AnnualTaxDelinquentDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDlnq3")]
        public IWebElement AnnualTaxDelinquentDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnDlnq4")]
        public IWebElement AnnualTaxDelinquentDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtGdDt1")]
        public IWebElement AnnualTaxPaymentGoodThroughDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtGdDt2")]
        public IWebElement AnnualTaxPaymentGoodThroughDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtGdDt3")]
        public IWebElement AnnualTaxPaymentGoodThroughDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtGdDt4")]
        public IWebElement AnnualTaxPaymentGoodThroughDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnCert1")]
        public IWebElement AnnualTaxCertificateOfPurchase1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnCert2")]
        public IWebElement AnnualTaxCertificateOfPurchase2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnCert3")]
        public IWebElement AnnualTaxCertificateOfPurchase3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnCert4")]
        public IWebElement AnnualTaxCertificateOfPurchase4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnAsmnt1")]
        public IWebElement AnnualTaxAssesmentDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnAsmnt2")]
        public IWebElement AnnualTaxAssesmentDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnAsmnt3")]
        public IWebElement AnnualTaxAssesmentDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnAsmnt4")]
        public IWebElement AnnualTaxAssesmentDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPrsnl1")]
        public IWebElement AnnualTaxPersonalPropValue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPrsnl2")]
        public IWebElement AnnualTaxPersonalPropValue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPrsnl3")]
        public IWebElement AnnualTaxPersonalPropValue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnPrsnl4")]
        public IWebElement AnnualTaxPersonalPropValue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnLnd1")]
        public IWebElement AnnualTaxLandValue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnLnd2")]
        public IWebElement AnnualTaxLandValue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnLnd3")]
        public IWebElement AnnualTaxLandValue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnLnd4")]
        public IWebElement AnnualTaxLandValue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnImprv1")]
        public IWebElement AnnualTaxImprovementValue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnImprv2")]
        public IWebElement AnnualTaxImprovementValue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnImprv3")]
        public IWebElement AnnualTaxImprovementValue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnImpr4")]
        public IWebElement AnnualTaxImprovementValue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnNtvl1")]
        public IWebElement AnnualTaxNetValue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnNtvl2")]
        public IWebElement AnnualTaxNetValue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnNtvl3")]
        public IWebElement AnnualTaxNetValue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnNtvl4")]
        public IWebElement AnnualTaxNetValue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnHmonr1")]
        public IWebElement AnnualTaxHomeOwner1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnHmonr2")]
        public IWebElement AnnualTaxHomeOwner2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnHmonr3")]
        public IWebElement AnnualTaxHomeOwner3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnHmonr4")]
        public IWebElement AnnualTaxHomeOwner4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr11")]
        public IWebElement AnnualTaxOther11 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr12")]
        public IWebElement AnnualTaxOther12 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr13")]
        public IWebElement AnnualTaxOther13 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr14")]
        public IWebElement AnnualTaxOther14 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr21")]
        public IWebElement AnnualTaxOther21 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr22")]
        public IWebElement AnnualTaxOther22 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr23")]
        public IWebElement AnnualTaxOther23 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlAnvl_txtAnOthr24")]
        public IWebElement AnnualTaxOther24 { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx_TAX_tbcon_FtbpnlSupl")]
        public IWebElement SupplementalTaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMsgTaxYear { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMsg { get; set; }

        #endregion

        public PropertyTaxInfoAnnualTax WaitForScreenToLoad(IWebElement element = null)
        {
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);

            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TopMostAPN);
            return this;
        }

        public PropertyTaxInfoAnnualTax PerformActionOnSummaryTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int StartingRowNum = 1)
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(Summarytable);
                Summarytable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

                return this;
            }
            catch (StaleElementReferenceException) //Try again if get stale element reference exception
            {
                this.SwitchToContentFrame();
                this.WaitCreation(Summarytable);
                Summarytable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

                return this;
            }

        }


    }

    public class PropertyTaxInfoSupplementalTax : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabGnrl")]
        public IWebElement GeneralTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_btnRmv")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_chkSGnrt")]
        public IWebElement GenerateTaxCheck { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_btnSPPyCl")]
        public IWebElement PayAtClose { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSDet")]
        public IWebElement SupplementalTaxDetailforTaxIDAPN { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSuplNo")]
        public IWebElement SupplementalTaxSuppleNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSTxyr")]
        public IWebElement SupplementalTaxTaxYear { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSTrNo")]
        public IWebElement SupplementalTaxTRANo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSMisc")]
        public IWebElement SupplementalTaxMiscNo { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSTotx")]
        public IWebElement SupplementalTaxTotalInstallmentTax { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpVol1")]
        public IWebElement SupplementalTaxVolume1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpVol2")]
        public IWebElement SupplementalTaxVolume2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpVol3")]
        public IWebElement SupplementalTaxVolume3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpVol4")]
        public IWebElement SupplementalTaxVolume4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_cboSpStatus1")]
        public IWebElement SupplementalTaxStatus1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_cboSpStatus2")]
        public IWebElement SupplementalTaxStatus2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_cboSpStatus3")]
        public IWebElement SupplementalTaxStatus3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_cboSpStatus4")]
        public IWebElement SupplementalTaxStatus4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDuedt1")]
        public IWebElement SupplementalTaxDueDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDuedt2")]
        public IWebElement SupplementalTaxDueDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDuedt3")]
        public IWebElement SupplementalTaxDueDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDuedt4")]
        public IWebElement SupplementalTaxDueDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInstl1")]
        public IWebElement SupplementalTaxInstallmentAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInstl2")]
        public IWebElement SupplementalTaxInstallmentAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInstl3")]
        public IWebElement SupplementalTaxInstallmentAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInstl4")]
        public IWebElement SupplementalTaxInstallmentAmount4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInt1")]
        public IWebElement SupplementalTaxInterest1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInt2")]
        public IWebElement SupplementalTaxInterest2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInt3")]
        public IWebElement SupplementalTaxInterest3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpInt4")]
        public IWebElement SupplementalTaxInterest4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPnlty1")]
        public IWebElement SupplementalTaxPenality1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPnlty2")]
        public IWebElement SupplementalTaxPenality2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPnlty3")]
        public IWebElement SupplementalTaxPenality3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPnlty4")]
        public IWebElement SupplementalTaxPenality4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPymnt1")]
        public IWebElement SupplementalTaxpartialPaymentAmount1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPymnt2")]
        public IWebElement SupplementalTaxpartialPaymentAmount2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPymnt3")]
        public IWebElement SupplementalTaxpartialPaymentAmount3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpPymnt4")]
        public IWebElement SupplementalTaxpartialPaymentAmount4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpBal1")]
        public IWebElement SupplementalTaxBalanceDue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpBal2")]
        public IWebElement SupplementalTaxBalanceDue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpBal3")]
        public IWebElement SupplementalTaxBalanceDue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpBal4")]
        public IWebElement SupplementalTaxBalanceDue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDtpd1")]
        public IWebElement SupplementalTaxDatePaid1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDtpd2")]
        public IWebElement SupplementalTaxDatePaid2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDtpd3")]
        public IWebElement SupplementalTaxDatePaid3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDtpd4")]
        public IWebElement SupplementalTaxDatePaid4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDlnq1")]
        public IWebElement SupplementalTaxDelinquentDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDlnq2")]
        public IWebElement SupplementalTaxDelinquentDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDlnq3")]
        public IWebElement SupplementalTaxDelinquentDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpDlnq4")]
        public IWebElement SupplementalTaxDelinquentDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpGdDt1")]
        public IWebElement SupplementalTaxPaymentGoodThroughDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpGdDt2")]
        public IWebElement SupplementalTaxPaymentGoodThroughDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpGdDt3")]
        public IWebElement PaymentSupplementalTaxGoodThroughDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpGdDt4")]
        public IWebElement SupplementalTaxPaymentGoodThroughDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpCert1")]
        public IWebElement SupplementalTaxCertificateOfPurchase1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpCert2")]
        public IWebElement SupplementalTaxCertificateOfPurchase2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpCert3")]
        public IWebElement SupplementalTaxCertificateOfPurchase3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpCert4")]
        public IWebElement SupplementalTaxCertificateOfPurchase4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSupl_txtSpGdDt3")]
        public IWebElement SupplementalTaxPaymentGoodThroughDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl")]
        public IWebElement SpecialTaxTab { get; set; }

        #endregion

        public PropertyTaxInfoSupplementalTax WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SupplementalTaxStatus1);
            return this;
        }

    }

    public class PropertyTaxInfoSpecialTax : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabGnrl")]
        public IWebElement GeneralTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_btnRmv")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_chkSlGnrt")]
        public IWebElement GenerateTaxCheck { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_btnSIPycl")]
        public IWebElement PayAtClose { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSIDtls")]
        public IWebElement SpecialTaxDetailforTaxIDAPN { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSITxyr")]
        public IWebElement SpecialTaxTaxYear { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtTotInsl")]
        public IWebElement SpecialTaxTotalInstallmentTax { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlVol1")]
        public IWebElement SpecialTaxVol1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlVol2")]
        public IWebElement SpecialTaxVol2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlVol3")]
        public IWebElement SpecialTaxVol3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlVol4")]
        public IWebElement SpecialTaxVol4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_cboSlStatus1")]
        public IWebElement SpecialTaxStatus1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_cboSlStatus2")]
        public IWebElement SpecialTaxStatus2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_cboSlStatus3")]
        public IWebElement SpecialTaxStatus3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_cboSlStatus4")]
        public IWebElement SpecialTaxStatus4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDuedt1")]
        public IWebElement SpecialTaxDueDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDuedt2")]
        public IWebElement SpecialTaxDueDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDuedt3")]
        public IWebElement SpecialTaxDueDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDuedt4")]
        public IWebElement SpecialTaxDueDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInstl1")]
        public IWebElement SpecialTaxInstallmentAmt1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInstl2")]
        public IWebElement SpecialTaxInstallmentAmt2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInstl3")]
        public IWebElement SpecialTaxInstallmentAmt3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInstl4")]
        public IWebElement SpecialTaxInstallmentAmt4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInt1")]
        public IWebElement SpecialTaxInterest1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInt2")]
        public IWebElement SpecialTaxInterest2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInt3")]
        public IWebElement SpecialTaxInterest3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlInt4")]
        public IWebElement SpecialTaxInterest4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPnlty1")]
        public IWebElement SpecialTaxPenality1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPnlty2")]
        public IWebElement SpecialTaxPenality2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPnlty3")]
        public IWebElement SpecialTaxPenality3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPnlty4")]
        public IWebElement SpecialTaxPenality4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPymnt1")]
        public IWebElement SpecialTaxpartialPayment1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPymnt2")]
        public IWebElement SpecialTaxpartialPayment2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPymnt3")]
        public IWebElement SpecialTaxpartialPayment3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlPymnt4")]
        public IWebElement SpecialTaxpartialPayment4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlBal1")]
        public IWebElement SpecialTaxBalanceDue1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlBal2")]
        public IWebElement SpecialTaxBalanceDue2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlBal3")]
        public IWebElement SpecialTaxBalanceDue3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlBal4")]
        public IWebElement SpecialTaxBalanceDue4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDtpd1")]
        public IWebElement SpecialTaxDatePaid1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDtpd2")]
        public IWebElement SpecialTaxDatePaid2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDtpd3")]
        public IWebElement SpecialTaxDatePaid3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDtpd4")]
        public IWebElement SpecialTaxDatePaid4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDlnq1")]
        public IWebElement SpecialTaxDelinquentDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDlnq2")]
        public IWebElement SpecialTaxDelinquentDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDlnq3")]
        public IWebElement SpecialTaxDelinquentDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlDlnq4")]
        public IWebElement SpecialTaxDelinquentDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlGdDt1")]
        public IWebElement SpecialTaxPaymentGoodThroughDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlGdDt2")]
        public IWebElement SpecialTaxPaymentGoodThroughDate2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlGdDt3")]
        public IWebElement SpecialTaxPaymentGoodThroughDate3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlGdDt4")]
        public IWebElement SpecialTaxPaymentGoodThroughDate4 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlCert1")]
        public IWebElement SpecialTaxCertificateOfPurchase1 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlCert2")]
        public IWebElement SpecialTaxCertificateOfPurchase2 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlCert3")]
        public IWebElement SpecialTaxCertificateOfPurchase3 { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTx_TAX_tbcon_FtbpnlSpcl_txtSlCert4")]
        public IWebElement SpecialTaxCertificateOfPurchase4 { get; set; }

        #endregion

        public PropertyTaxInfoSpecialTax WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? SpecialTaxStatus1);
            return this;
        }

    }

    public class PropertyTaxInfoTitleProd : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabGnrl")]
        public IWebElement GeneralTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabLglDsc")]
        public IWebElement LegalDescriptionTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTx")]
        public IWebElement TaxTab { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabPTI_tabTtlPrd")]
        public IWebElement TitleProductionTab { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtPlEDt")]
        public IWebElement TitleProductionPlanEffactiveDate { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtAmendUpdate")]
        public IWebElement TitleProductionAmendUpdateDetails { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtTitleMortgage")]
        public IWebElement TitleProductionTitleMortgageInsuranceClause { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtVstg")]
        public IWebElement TitleProductionVesting { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_btnCpyBSVes")]
        public IWebElement CopyBuyerSellerVesting { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtEstateInterest")]
        public IWebElement TitleProductionEstateInterest { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtExcp")]
        public IWebElement TitleProductionExceptions { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_cboPropExcRgn")]
        public IWebElement TitleProductionExceptionsRegion { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtReq")]
        public IWebElement TitleProductionRequirements { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_cboPropReqRgn")]
        public IWebElement TitleProductionRequirementsRegion { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_txtInfoNotes")]
        public IWebElement TitleProductionInformationalNotes { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_cboPropInfoNotesRgn")]
        public IWebElement TitleProductionInformationalNotesRegion { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_btnSave")]
        public IWebElement ExceptionRequestInformationSave { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_btnExcepDoc")]
        public IWebElement ExceptionDocuments { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_hdnSave")]
        public IWebElement ExceptionRequestInformationHidenSave { get; set; }
        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_btnCpyBSVes")]
        public IWebElement buyersellerVestingBtn { get; set; }

        [FindsBy(How = How.Id, Using = "tabPTI_tabTtlPrd_TTL_lblExSoR")]
        public IWebElement ExceptionSourceRegion { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement ErrorMessage { get; set; }

        #endregion

        public PropertyTaxInfoTitleProd WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? TitleProductionVesting);
            return this;
        }

        public PropertyTaxInfoTitleProd FillTitlProdDetls(PropertyAddressParameters Dtls)
        {
            this.TitleProductionVesting.FASetText(Dtls.Vesting);
            return this;
        }

        public PropertyTaxInfoTitleProd ClickExcReqInfSave()
        {
            this.ExceptionRequestInformationSave.FAClick();
            WaitForScreenToLoad();
            this.WaitCreation(this.TitleProductionVesting);
            return this;
        }


    }
}
