using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class PropertyTaxSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.CssSelector, Using = "#btnNew,#cmdNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#btnEdit,#cmdEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.CssSelector, Using = "#btnRemove,#cmdDelete")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProperty")]
        public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPTaxSumry")]
        public IWebElement PropertiesSummary { get; set; }
        

        //TODO: ADD FindsByAttribute
        public IWebElement NameColumnPane { get; set; }

        #endregion

        //public PropertyTaxSummary WaitForScreenToLoad()
        //{
        //    this.SwitchToContentFrame();
        //    this.WaitCreation(SummaryTable, 10);
        //    return this;
        //}

        public PropertyTaxSummary WaitForScreenToLoad(IWebElement e = null)
        {
            e = e ?? PropertiesSummary;
            this.SwitchToContentFrame();
            this.WaitCreation(e);
            return this;
        }

        public PropertyTaxSummary ClickSummaryTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int StartingRowNum = 1)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PropertiesSummary);
            PropertiesSummary.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

            return this;
        }
    }
}
