using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ProrationDateChangedDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkSelectAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "chkTaxes")]
		public IWebElement Taxes { get; set; }

		[FindsBy(How = How.Id, Using = "chkRents")]
		public IWebElement Rents { get; set; }

		[FindsBy(How = How.Id, Using = "chkMiscellaneous")]
		public IWebElement Miscellaneous { get; set; }

		[FindsBy(How = How.Id, Using = "chkHomeOwnerAssociation")]
		public IWebElement HomeOwnerAssociation { get; set; }

		[FindsBy(How = How.Id, Using = "chkInsurance")]
		public IWebElement Insurance { get; set; }

		[FindsBy(How = How.Id, Using = "chkUtilities")]
		public IWebElement Utilities { get; set; }

		#endregion

        #region Useful methods
        public ProrationDateChangedDlg WaitForScreenToLoad(string windowName = "Re-calculate Prorations")
        {
            //WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(SelectAll);

            return this;
        }
        #endregion

    }
}
