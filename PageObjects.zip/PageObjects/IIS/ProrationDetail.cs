using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class ProrationDetail : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxCreditSeller")]
        public IWebElement CreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxDayofClose")]
        public IWebElement DayofClosePaidbySeller { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement Amount { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtFromDate")]
        public IWebElement FromDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromInclusive")]
        public IWebElement fromInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxfromProrate")]
        public IWebElement fromProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboBasedOn")]
        public IWebElement BasedOn { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_cboPer")]
        public IWebElement Per { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtToDate")]
        public IWebElement ToDate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoInclusive")]
        public IWebElement toInclusive { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_chkbxtoProrate")]
        public IWebElement toProrate { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement Description { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement BuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCredit")]
        public IWebElement BuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement SellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCredit")]
        public IWebElement SellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "Table1")]
        public IWebElement ProrationTable { get; set; }

        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtgfeAmount")]
        public IWebElement LE_amount { get; set; }

        #endregion

        public ProrationDetail WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Amount);

            return this;
        }

        public void SetProrarion(ProrationData p)
        {
            this.WaitForScreenToLoad();
            this.CreditSeller.FASetCheckbox(p.CreditSeller);
            this.DayofClosePaidbySeller.FASetCheckbox(p.DayofClosePaidbySeller);
            this.Amount.FASetText(((Decimal)p.ProrationAmount).ToString("N2"));
            this.FromDate.FASetText(p.FromDate);
            this.fromInclusive.FASetCheckbox(p.fromInclusive);
            this.fromProrate.FASetCheckbox(p.fromProrateDate);
            this.BasedOn.FASelectItem(p.BasedOn);
            this.Per.FASelectItem(p.Per);
            this.ToDate.FASetText(p.ToDate);
            this.toInclusive.FASetCheckbox(p.toInclusive);
            if (p.toInclusive)
            {
                this.WebDriver.HandleDialogMessage(true, true);
                this.WaitForScreenToLoad();
            }
            this.toProrate.FASetCheckbox(p.toProrateDate);
            if (!string.IsNullOrEmpty(p.Description))
            {
                this.Description.FASetText(p.Description, continueOnFailure: true);
                Keyboard.SendKeys(FAKeys.TabAway);
            }
            if (p.ProrationBuyerCharge!=0)
            this.BuyerCharge.FASetText(((Decimal)p.ProrationBuyerCharge).ToString("N2"));
            if (p.ProrationBuyerCredit != 0)
            this.BuyerCredit.FASetText(((Decimal)p.ProrationBuyerCredit).ToString("N2"));
            if (p.ProrationSellerCharge != 0)
            this.SellerCharge.FASetText(((Decimal)p.ProrationSellerCharge).ToString("N2"));
            if (p.ProrationSellerCredit != 0)
            this.SellerCredit.FASetText(((Decimal)p.ProrationSellerCredit).ToString("N2"));
            if (p.ProrationUtilityLE != 0)
            this.LE_amount.FASetText(((Decimal)p.ProrationUtilityLE).ToString("N2"));
        }

        public string EnterProrationDetails(string description = null, string per = null, string fromDate = null, string toDate = null, string amount = null, bool? creditSeller = null)
        {
            this.SwitchToContentFrame();

            Reports.TestStep = string.Format("Enter proration '{0}' details", description == null ? "" : description);

            CreditSeller.FASetCheckbox(creditSeller);

            if (description != null)
            {
                Description.Click();
                Keyboard.SendKeys("{DEL}");
                Description.SendKeys(description);
                Keyboard.SendKeys(FAKeys.TabAway); 
            }

            Per.FASelectItem(per);
            Keyboard.SendKeys(FAKeys.TabAway);

            Amount.FASetText(amount);
            Keyboard.SendKeys(FAKeys.TabAway);

            FromDate.FASetText(fromDate);
            Keyboard.SendKeys(FAKeys.TabAway);

            ToDate.FASetText(toDate);
            Keyboard.SendKeys(FAKeys.TabAway);

            return (bool)creditSeller && creditSeller.HasValue ? BuyerCharge.GetAttribute("value") : BuyerCredit.GetAttribute("value");
        }
    }

    public class ProrationData
    {
        public string Description = "Utilities";
        public string prorationType = "NONE";
        public bool CreditSeller;
        public bool DayofClosePaidbySeller;
        public decimal ProrationAmount;
        public string FromDate;
        public bool fromInclusive;
        public bool fromProrateDate;
        public string BasedOn;
        public string Per;
        public string ToDate;
        public bool toInclusive;
        public bool toProrateDate;
        public decimal ProrationBuyerCharge;
        public decimal ProrationBuyerCredit;
        public decimal ProrationSellerCharge;
        public decimal ProrationSellerCredit;
        public decimal ProrationUtilityLE;
    }
}
