﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class ProrationMisc : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dGridProration_0_Table2")]
        public IWebElement ProrationTaxTable1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_1_Table2")]
        public IWebElement ProrationTaxTable2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_2_Table2")]
        public IWebElement ProrationTaxTable3 { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_lblTitle")]
        public IWebElement Tax1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_lblTitle")]
        public IWebElement Rent1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_lblTitle")]
        public IWebElement Miscellaneous1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_1_lblTitle")]
        public IWebElement Tax2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_tdBuyerCharge")]
        public IWebElement CityCell { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_1_tdSellerCharge")]
        public IWebElement CountyCell { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_2_tdBuyerCharge")]
        public IWebElement AssesmentCell { get; set; }

        // Proration  - Misc
        public IWebElement NthCreditSeller(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Label1"));
        }
        public IWebElement NthDayofClosePaidbySeller(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel1"));
        }
        public IWebElement NthAmount(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel2"));
        }
        public IWebElement NthFrom(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel3"));
        }
        public IWebElement NthFromInclusive(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel4"));
        }
        public IWebElement NthFromProrateDate(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel5"));
        }
        public IWebElement NthBasedOn(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel6"));
        }
        public IWebElement NthPeriod(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel12"));
        }
        public IWebElement NthTo(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel13"));
        }
        public IWebElement NthToInclusive(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel14"));
        }
        public IWebElement NthToProrateDate(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel15"));
        }
        public IWebElement NthDescription(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel7"));
        }
        public IWebElement NthBuyerCharge(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel8"));
        }
        public IWebElement NthBuyerCredit(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel9"));
        }
        public IWebElement NthSellerCharge(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel10"));
        }
        public IWebElement NthSellerCredit(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel11"));
        }

        #endregion

        public ProrationMisc Open()
        {
            FastDriver.LeftNavigation.Navigate<ProrationMisc>("Home>Order Entry>Escrow Charge Processes>Proration>Miscellaneous");
            this.WaitForScreenToLoad();

            return this;
        }


        public ProrationMisc WaitForScreenToLoad(IWebElement e = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(e ?? New);

            return this;
        }

        public void MiscProration(string BC , String SC , String SCR , String BCR)
        {

            Open();
            FastDriver.ProrationMisc.Miscellaneous1.FAClick();
            FastDriver.ProrationMisc.Edit.FAClick();
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.SellerCredit.FASetCheckbox(true);
            FastDriver.ProrationDetail.Amount.FASetText("900.00");
            FastDriver.ProrationDetail.FromDate.FASetText("04-02-2012");
            FastDriver.ProrationDetail.BasedOn.FASelectItem("365");
            FastDriver.ProrationDetail.Per.FASelectItem("YEAR");
            FastDriver.ProrationDetail.ToDate.FASetText("07-02-2012");
            FastDriver.ProrationDetail.BuyerCharge.FASetText(BC);
            FastDriver.ProrationDetail.SellerCharge.FASetText(SC);
            FastDriver.ProrationDetail.BuyerCredit.FASetText(BCR);
            FastDriver.ProrationDetail.SellerCredit.FASetText(SCR);
            FastDriver.BottomFrame.Done();
        }
    }

}
