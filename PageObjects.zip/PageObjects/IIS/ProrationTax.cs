using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class ProrationTax : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dGridProration_0_Table2")]
        public IWebElement ProrationTaxTable1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_1_Table2")]
        public IWebElement ProrationTaxTable2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_2_Table2")]
        public IWebElement ProrationTaxTable3 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_3_Table2")]
        public IWebElement ProrationTaxTable4 { get; set; }

        [FindsBy(How = How.Id, Using = "btnNew")]
        public IWebElement New { get; set; }
        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtAmount")]
        public IWebElement Amount { get; set; }
        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtDescription")]
        public IWebElement Desc { get; set; }
        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtBuyerCharge")]
        public IWebElement bc { get; set; }
        [FindsBy(How = How.Id, Using = "ACalculateProration1_txtSellerCharge")]
        public IWebElement sc { get; set; }
        [FindsBy(How = How.Id, Using = "btnEdit")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "btnDelete")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_lblTitle")]
        public IWebElement Tax1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_lblTitle")]
        public IWebElement Rent1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_lblTitle")]
        public IWebElement Miscellaneous1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_1_lblTitle")]
        public IWebElement Tax2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_2_lblTitle")]
        public IWebElement Tax3 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_dGridProration")]
        public IWebElement ProrationTaxTable { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_0_tdBuyerCharge")]
        public IWebElement CityCell { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_1_tdSellerCharge")]
        public IWebElement CountyCell { get; set; }

        [FindsBy(How = How.Id, Using = "dGridProration_2_tdBuyerCharge")]
        public IWebElement AssesmentCell { get; set; }

        // Proration  - Tax
        public IWebElement NthCreditSeller(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Label1"));
        }
        public IWebElement NthDayofClosePaidbySeller(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel1"));
        }
        public IWebElement NthAmount(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel2"));
        }
        public IWebElement NthFrom(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel3"));
        }
        public IWebElement NthFromInclusive(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel4"));
        }
        public IWebElement NthFromProrateDate(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel5"));
        }
        public IWebElement NthBasedOn(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel6"));
        }
        public IWebElement NthPeriod(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel12"));
        }
        public IWebElement NthTo(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel13"));
        }
        public IWebElement NthToInclusive(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel14"));
        }
        public IWebElement NthToProrateDate(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel15"));
        }
        public IWebElement NthDescription(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel7"));
        }
        public IWebElement NthBuyerCharge(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel8"));
        }
        public IWebElement NthBuyerCredit(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel9"));
        }
        public IWebElement NthSellerCharge(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel10"));
        }
        public IWebElement NthSellerCredit(int i = 0)
        {
            return this.WebDriver.FindElement(By.Id("dGridProration_" + i + "_Faflabel11"));
        }


        #endregion

        public ProrationTax Open()
        {
            FastDriver.LeftNavigation.Navigate<ProrationTax>("Home>Order Entry>Escrow Charge Processes>Proration>Tax");
            this.WaitForScreenToLoad();

            return this;
        }

        public ProrationTax WaitForScreenToLoad(IWebElement e = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(e ?? New);

            return this;
        }

        public string ProrationTaxEntry(int tableNumber, string description, string fromDate, string toDate, string amount, bool creditSeller, string per = "YEAR")
        {
            string taxName = "";

            switch (tableNumber)
            {
                case 1:
                    CityCell.FAClick();
                    taxName = "City/Town Taxes";
                    break;
                case 2:
                    CountyCell.FAClick();
                    taxName = "County Taxes";
                    break;
                case 3:
                    AssesmentCell.FAClick();
                    taxName = "Assessments";
                    break;
                default:
                    break;
            }

            Edit.FAClick();
            
            //TODO: this does not belong here. Move this to the ProrationDetail page object.
            Reports.TestStep = string.Format("Enter '{0}' data", taxName); //Steps are not allowed inside services.
            FastDriver.ProrationDetail.SwitchToContentFrame();
            FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(creditSeller);

            FastDriver.ProrationDetail.Amount.FASetText(amount);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.ProrationDetail.FromDate.FASetText(fromDate);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.ProrationDetail.ToDate.FASetText(toDate);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.ProrationDetail.Per.FASelectItem(per);
            Keyboard.SendKeys(FAKeys.TabAway);
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.ProrationDetail.WaitForScreenToLoad();

            return creditSeller ? FastDriver.ProrationDetail.BuyerCharge.GetAttribute("value").ToString().Trim() : FastDriver.ProrationDetail.BuyerCredit.GetAttribute("value").ToString().Trim();
        }

        public void ProrationTaxEntryWithBuyerSellerAmount(int tableNumber, string description, string fromDate, string toDate, string amount, bool creditSeller, string PerDays, string per = "YEAR",String BuyerCharge=null,string SellerCharge=null,string BuyerCredit=null ,string SellerCredit=null)
        {
            string taxName = "";

            switch (tableNumber)
            {
                case 1:
                    CityCell.FAClick();
                    taxName = "City/Town Taxes";
                    break;
                case 2:
                    CountyCell.FAClick();
                    taxName = "County Taxes";
                    break;
                case 3:
                    AssesmentCell.FAClick();
                    taxName = "Assessments";
                    break;
                default:
                    break;
            }

            Edit.FAClick();

            //TODO: this does not belong here. Move this to the ProrationDetail page object.
            Reports.TestStep = string.Format("Enter '{0}' data", taxName); //Steps are not allowed inside services.
            FastDriver.ProrationDetail.SwitchToContentFrame();
            FastDriver.ProrationDetail.CreditSeller.FASetCheckbox(creditSeller);
            FastDriver.ProrationDetail.Amount.FASetText(amount);
            FastDriver.ProrationDetail.FromDate.FASetText(fromDate);
            FastDriver.ProrationDetail.BasedOn.FASelectItem(PerDays);
            FastDriver.ProrationDetail.Per.FASelectItem("YEAR");
            // Keyboard.SendKeys("{TAB}");
            FastDriver.ProrationDetail.ToDate.FASetText(toDate);

            if (BuyerCharge!=null)
            FastDriver.ProrationDetail.BuyerCharge.FASetText(BuyerCharge);
            else
                FastDriver.ProrationDetail.BuyerCharge.FASetText("0.00");

            if (SellerCharge != null)
            FastDriver.ProrationDetail.SellerCharge.FASetText(SellerCharge);
            else
                FastDriver.ProrationDetail.SellerCharge.FASetText("0.00");

            if (BuyerCredit != null)
            FastDriver.ProrationDetail.BuyerCredit.FASetText(BuyerCredit);
            else
                FastDriver.ProrationDetail.BuyerCredit.FASetText("0.00");

            if (SellerCredit != null)
            FastDriver.ProrationDetail.SellerCredit.FASetText(SellerCredit);
            else
                FastDriver.ProrationDetail.SellerCredit.FASetText("0.00");
            
            FastDriver.BottomFrame.Done();



        }



        public ProrationDetail SelectProrationTax(int tableNumber)
        {
            this.SwitchToContentFrame();

            switch (tableNumber)
            {
                case 1:
                    CityCell.FAClick();
                    break;
                case 2:
                    CountyCell.FAClick();
                    break;
                case 3:
                    AssesmentCell.FAClick();
                    break;
                default:
                    //TODO: this should throw
                    break;
            }

            Edit.FAClick();
            return FastDriver.GetPage<ProrationDetail>();
        }        
    }

}
