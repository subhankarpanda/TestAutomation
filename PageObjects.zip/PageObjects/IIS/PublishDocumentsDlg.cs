using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class PublishDocumentsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgFBPRoles_ctl01_chkUpdateAll")]
		public IWebElement SelectAll { get; set; }

		[FindsBy(How = How.Id, Using = "dgFBPRoles_0_chkSelect")]
		public IWebElement Select1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgFBPRoles")]
		public IWebElement Table { get; set; }

        [FindsBy(How = How.Id, Using = "dgFBPRoles_1_chkSelect")]
        public IWebElement Select2 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFBPRoles_8_chkSelect")]
        public IWebElement Select9 { get; set; }

        [FindsBy(How = How.Id, Using = "dgFBPRoles_9_chkSelect")]
        public IWebElement Select10 { get; set; }
		#endregion

        public PublishDocumentsDlg WaitForScreenToLoad(IWebElement e = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(SelectAll);

            return this;
        }
    
	}
}
