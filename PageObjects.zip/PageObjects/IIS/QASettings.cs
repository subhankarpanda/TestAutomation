using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class QASettings : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnApplyChanges")]
		public IWebElement SaveSettings { get; set; }

		[FindsBy(How = How.Id, Using = "chkTargetSpecificDeliveryServer")]
		public IWebElement TargetSpeccDeliveryServer { get; set; }

		[FindsBy(How = How.Id, Using = "chkWord2000Delivery")]
		public IWebElement Word2000Delivery { get; set; }

		[FindsBy(How = How.Id, Using = "chkNextGenDelivery")]
		public IWebElement NextGenDelivery { get; set; }

		#endregion

	}
}
