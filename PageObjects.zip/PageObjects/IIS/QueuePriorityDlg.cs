using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class WorkQueueMessagesBrowserDlgB : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "workQMsgsGrid_0_drpdwnPriority")]
		public IWebElement SelectPriority { get; set; }

		[FindsBy(How = How.Id, Using = "btnOK")]
		public IWebElement Done { get; set; }

		#endregion

        public WorkQueueMessagesBrowserDlgB WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? SelectPriority);
            return this;
        }

	}
}
