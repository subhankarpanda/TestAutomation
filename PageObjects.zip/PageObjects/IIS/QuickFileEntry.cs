﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using System;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
    public class QuickFileEntry : PageObject
    {
        #region WebElements
        [FindsBy(How = How.Id, Using = "BPSRC_txtGABcode")]
        public IWebElement txtBusinessSourceGABID { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_cmdFindName")]
        public IWebElement btnBusinessSourceGABFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelIdcode")]
        public IWebElement btnBusinessSourceGABCodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTransType")]
        public IWebElement ddlTransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboState")]
        public IWebElement ddlPropertyState { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceTitle")]
        public IWebElement cbxServiceTitle { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceEsrw")]
        public IWebElement cbxServiceEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceSubEsrw")]
        public IWebElement cbxServiceSubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBusSegment")]
        public IWebElement ddlBusinessSegment { get; set; }

        [FindsBy(How = How.Id)]
        public IWebElement btnDone { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine1")]
        public IWebElement Street1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine2")]
        public IWebElement Street2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine3")]
        public IWebElement Street3 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine4")]
        public IWebElement Street4 { get; set; }

        [FindsBy(How = How.Id, Using = "cmdContinue")]
        public IWebElement Continue { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_cboUWEmployees")]
        public IWebElement UW_Employee { get; set; }
        #endregion

        #region WebElements Converted from CodedUI object map

        [FindsBy(How = How.Id, Using = "BPSRC_txtGABcode")]
        public IWebElement BusinessSourceGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_cmdFindName")]
        public IWebElement BusinessSourceFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtName")]
        public IWebElement BusinessSourceName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkEditContactInfo")]
        public IWebElement BusinessSourceEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textBusPhone")]
        public IWebElement BusinessSourceBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtExtnPhone")]
        public IWebElement BusinessSourceBusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textBusFax")]
        public IWebElement BusinessSourceBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textCellPhone")]
        public IWebElement BusinessSourceCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textPager")]
        public IWebElement BusinessSourcePager { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textEmailAddress")]
        public IWebElement BusinessSourceEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkWeeklyEmailStatus")]
        public IWebElement BusinessSourceWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboAttention")]
        public IWebElement BusinessSourceAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkEdit")]
        public IWebElement BusinessSourceEditName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textName")]
        public IWebElement BusinessSourceNameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboSalesRep1")]
        public IWebElement BusinessSourceSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboSalesRep2")]
        public IWebElement BusinessSourceSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textReference")]
        public IWebElement BusinessSourceReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_comboAddtionalRole")]
        public IWebElement BusinessSourceAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtPercent")]
        public IWebElement BusinessSourcePercentage { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtAmount")]
        public IWebElement BusinessSourceAmount { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactBusPhone")]
        public IWebElement BusinessSourceAttentionContactBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtContactExtnPhone")]
        public IWebElement BusinessSourceAttentionContactBusinessPhoneExt { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactBusFax")]
        public IWebElement BusinessSourceAttentionContactBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactCellPhone")]
        public IWebElement BusinessSourceAttentionContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactPager")]
        public IWebElement BusinessSourceAttentionContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_textContactEmailAddress")]
        public IWebElement BusinessSourceAttentionContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_chkContactWeeklyEmailStatus")]
        public IWebElement BusinessSourceAttentionContactStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtGABcode")]
        public IWebElement DirectedBYGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_cmdFindName")]
        public IWebElement DirectedBYFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtName")]
        public IWebElement DirectedBYName { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkEditContactInfo")]
        public IWebElement DirectedBYEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textBusPhone")]
        public IWebElement DirectedBYBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textBusFax")]
        public IWebElement DirectedBYBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textCellPhone")]
        public IWebElement DirectedBYCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textPager")]
        public IWebElement DirectedBYPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textEmailAddress")]
        public IWebElement DirectedBYEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkWeeklyEmailStatus")]
        public IWebElement DirectedBYWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboAttention")]
        public IWebElement DirectedBYAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_chkEdit")]
        public IWebElement DirectedBYEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textName")]
        public IWebElement DirectedBYNameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboSalesRep1")]
        public IWebElement DirectedBYSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboSalesRep2")]
        public IWebElement DirectedBYSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_textReference")]
        public IWebElement DirectedBYReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboAddtionalRole")]
        public IWebElement DirectedBYAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtPercent")]
        public IWebElement DirectedBYPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtAmount")]
        public IWebElement DirectedBYAmount { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceTitle")]
        public IWebElement Title { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceEsrw")]
        public IWebElement Escrow { get; set; }

        [FindsBy(How = How.Id, Using = "chkMyFastNCS")]
        public IWebElement ProjectFile { get; set; }

        [FindsBy(How = How.Id, Using = "chkSrvceSubEsrw")]
        public IWebElement SubEscrow { get; set; }

        [FindsBy(How = How.Id, Using = "rdCD")]
        public IWebElement FormType_CD { get; set; }

        [FindsBy(How = How.Id, Using = "rdHUD")]
        public IWebElement FormType_HUD { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlPolicyIssuer")]
        public IWebElement UnderWriterFilter { get; set; }

        [FindsBy(How = How.Id, Using = "ddlBusSegment")]
        public IWebElement BusinessSegment { get; set; }

        [FindsBy(How = How.Id, Using = "chkAutoNum")]
        public IWebElement AutoNumber { get; set; }

        [FindsBy(How = How.Id, Using = "ddlTransType")]
        public IWebElement TransactionType { get; set; }

        [FindsBy(How = How.Id, Using = "chkUseAsMstr")]
        public IWebElement UseAsMasterFile { get; set; }

        [FindsBy(How = How.Id, Using = "ddlProgramType")]
        public IWebElement ProgramType { get; set; }

        [FindsBy(How = How.Id, Using = "chkProgTypeOveride")]
        public IWebElement ProgramTypeOverride { get; set; }

        [FindsBy(How = How.Id, Using = "chkSplAttnRequired")]
        public IWebElement SpecialAttentionRequired { get; set; }
                [FindsBy(How = How.Id, Using = "txtSplAttnComment")]
        public IWebElement SpecialAttentionComment { get; set; }


        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOfficeLN")]
        public IWebElement EscrowOwningOfficeSTLicenseId { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOfficerLN")]
        public IWebElement EscrowOwningOfficeOfficerSTLicenseId { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOffice")]
        public IWebElement EscrowOwningOffice { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOfficer")]
        public IWebElement EscrowOwningOfficeOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlAssistant")]
        public IWebElement EscrowOwningOfficeAssistant { get; set; }

        //the button is for prod office. Misleading naming convention
        //[FindsBy(How = How.Id, Using = "EsrwOwnOffice_btnRemove")]
        //public IWebElement AddRemoveEscrowOwnngOffice { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_btnRemove")]
        public IWebElement AddRemoveEscrowProdOffice { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlOffice")]
        public IWebElement TitleOwningOffice { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlOfficer")]
        public IWebElement TitleOwningOfficeOfficer { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlAssistant")]
        public IWebElement TitleOwningOfficeAssistant { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlUndrwriter")]
        public IWebElement TitleOwningOfficeUndrwriter { get; set; }

        //the button is for prod office. Misleading naming convention
        //[FindsBy(How = How.Id, Using = "TitleOwnOffice_btnRemove")]
        //public IWebElement AddRemoveTitleOwningOffice { get; set; } 

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_btnRemove")]
        public IWebElement AddRemoveTitleProdOffice { get; set; }

        [FindsBy(How = How.Id, Using = "BusinessPrograms_btnRemove")]
        public IWebElement AddRemoveBusinessProgrammes { get; set; }

        [FindsBy(How = How.Id, Using = "BusinessPrograms_grdBusProg")]
        public IWebElement BusinessProgramsTable { get; set; }

        [FindsBy(How = How.Id, Using = "Products_btnRemove")]
        public IWebElement AddRemoveProducts { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds_0_cpt")]
        public IWebElement ProductsSelect { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_ddlSearchType")]
        public IWebElement SearchType { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_btnRemove")]
        public IWebElement AddRemoveInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_txtInstructions")]
        public IWebElement SearchInstructions { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_txtAddInstruction")]
        public IWebElement AddInstruction { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtSlsPrie")]
        public IWebElement TermsDatesSalesPrice { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtLibltyAmnt")]
        public IWebElement TermsDatesLiabililtyAmount { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtNewLoanAmnt")]
        public IWebElement TermsDatesNewLoanAmnt { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtNewLoanLiblty")]
        public IWebElement TermsDatesNewLoanLiability { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtEstDaysToCls")]
        public IWebElement TermsDatesEstimateDaysToClose { get; set; }

        [FindsBy(How = How.Id, Using = "TermsDates_txtEstSetlDate")]
        public IWebElement TermsDatesEstimatedSettlementDate { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropName")]
        public IWebElement PropertyInformationName { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_ddlPropType")]
        public IWebElement PropertyInformationType { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropLotName")]
        public IWebElement PropertyInformationLot { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBlock")]
        public IWebElement PropertyInformationBlock { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropUnit")]
        public IWebElement PropertyInformationUnit { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTRact")]
        public IWebElement PropertyInformationTRact { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropFee")]
        public IWebElement PropertyInformationFee { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBuilding")]
        public IWebElement PropertyInformationBuilding { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBook")]
        public IWebElement PropertyInformationBook { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropPage")]
        public IWebElement PropertyInformationPage { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropSection")]
        public IWebElement PropertyInformationSection { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTownShip")]
        public IWebElement PropertyInformationTownShip { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropRange")]
        public IWebElement PropertyInformationRange { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropParcel")]
        public IWebElement PropertyInformationParcel { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropSubDivCondo")]
        public IWebElement PropertyInformationSubdivisionCondominium { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_ddlEstateType")]
        public IWebElement PropertyEstateType { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_chkEreg")]
        public IWebElement Propertyreg { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_chkCnvsnRqd")]
        public IWebElement PropertyCnvsnReqd { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxAPN1")]
        public IWebElement PropertyPropTaxAPN1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxYear1")]
        public IWebElement PropertyPropTaxYear1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxAPN2")]
        public IWebElement PropertyPropTaxAPN2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxYear2")]
        public IWebElement PropertyPropTaxYear2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine1")]
        public IWebElement PropertyBookAddrLin1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine2")]
        public IWebElement PropertyBookAddrLin2 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine3")]
        public IWebElement PropertyBookAddrLin3 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine4")]
        public IWebElement PropertyBookAddrLin4 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtCity")]
        public IWebElement PropertyCity { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboState")]
        public IWebElement PropertyState { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtZip")]
        public IWebElement PropertyZip { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtCounty")]
        public IWebElement PropertyCounty { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboCountry")]
        public IWebElement PropertyCountry { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_ddl1Type")]
        public IWebElement Buyer1Type { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt11FName")]
        public IWebElement Buyer1FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt11MName")]
        public IWebElement Buyer1MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt11LName")]
        public IWebElement Buyer1LastName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt11Suffix")]
        public IWebElement Buyer1Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt11SSN")]
        public IWebElement Buyer1SSN { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt12FName")]
        public IWebElement Buyer1SpouseName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt12MName")]
        public IWebElement Buyer1SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt12LName")]
        public IWebElement Buyer1SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt12Suffix")]
        public IWebElement Buyer1SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt12SSN")]
        public IWebElement Buyer1SpouseSSN { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_ddl2Type")]
        public IWebElement Buyer2Type { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt21FName")]
        public IWebElement Buyer2FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt21MName")]
        public IWebElement Buyer2MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt21LName")]
        public IWebElement Buyer2LastName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt21Suffix")]
        public IWebElement Buyer2Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt21SSN")]
        public IWebElement Buyer2SSN { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt22FName")]
        public IWebElement Buyer2SpouseName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt22MName")]
        public IWebElement Buyer2SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt22LName")]
        public IWebElement Buyer2SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt22Suffix")]
        public IWebElement Buyer2SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "Buyer_txt22SSN")]
        public IWebElement Buyer2SpouseSSN { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_ddl1Type")]
        public IWebElement Seller1Type { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt11FName")]
        public IWebElement Seller1FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt11MName")]
        public IWebElement Seller1MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt11LName")]
        public IWebElement Seller1LastName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt11Suffix")]
        public IWebElement Seller1Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt11SSN")]
        public IWebElement Seller1SSN { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt12FName")]
        public IWebElement Seller1SpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt12MName")]
        public IWebElement Seller1SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt12LName")]
        public IWebElement Seller1SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt12Suffix")]
        public IWebElement Seller1SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt12SSN")]
        public IWebElement Seller1SpouseSSN { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_ddl2Type")]
        public IWebElement Seller2Type { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt21FName")]
        public IWebElement Seller2FirstName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt21MName")]
        public IWebElement Seller2MiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt21LName")]
        public IWebElement Seller2LastName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt21Suffix")]
        public IWebElement Seller2Suffix { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt21SSN")]
        public IWebElement Seller2SSN { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt22FName")]
        public IWebElement Seller2SpouseFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt22MName")]
        public IWebElement Seller2SpouseMiddleName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt22LName")]
        public IWebElement Seller2SpouseLastName { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt22Suffix")]
        public IWebElement Seller2SpouseSuffix { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_txt22SSN")]
        public IWebElement Seller2SpouseSSN { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtGABcode")]
        public IWebElement NewLenderInformationGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_cmdFindName")]
        public IWebElement NewLenderInformationFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtName")]
        public IWebElement NewLenderInformationName { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_chkEditContactInfo")]
        public IWebElement NewLenderInformationEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textBusPhone")]
        public IWebElement NewLenderInformationBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textBusFax")]
        public IWebElement NewLenderInformationBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textCellPhone")]
        public IWebElement NewLenderInformationCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textPager")]
        public IWebElement NewLenderInformationPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textEmailAddress")]
        public IWebElement NewLenderInformationEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_chkWeeklyEmailStatus")]
        public IWebElement NewLenderInformationWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_comboAttention")]
        public IWebElement NewLenderInformationAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_chkEdit")]
        public IWebElement NewLenderInformationEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textName")]
        public IWebElement NewLenderInformationEditName { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_comboSalesRep1")]
        public IWebElement NewLenderInformationSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_comboSalesRep2")]
        public IWebElement NewLenderInformationSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_textReference")]
        public IWebElement NewLenderInformationReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtGABcode")]
        public IWebElement AssociatedBusinessPartyGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_cmdFindName")]
        public IWebElement AssociatedBusinessPartyFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtName")]
        public IWebElement AssociatedBusinessPartyName { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_chkEditContactInfo")]
        public IWebElement AssociatedBusinessPartyEditCont { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textBusPhone")]
        public IWebElement AssociatedBusinessPartyBusPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textBusFax")]
        public IWebElement AssociatedBusinessPartyBusFax { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textCellPhone")]
        public IWebElement AssociatedBusinessPartyCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textPager")]
        public IWebElement AssociatedBusinessPartyPager { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textEmailAddress")]
        public IWebElement AssociatedBusinessPartyEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_chkWeeklyEmailStatus")]
        public IWebElement AssociatedBusinessPartyWeeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboAttention")]
        public IWebElement AssociatedBusinessPartyAttention { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_chkEdit")]
        public IWebElement AssociatedBusinessPartyEdit { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textName")]
        public IWebElement AssociatedBusinessPartyEditName { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboSalesRep1")]
        public IWebElement AssociatedBusinessPartySalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboSalesRep2")]
        public IWebElement AssociatedBusinessPartySalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_textReference")]
        public IWebElement AssociatedBusinessPartyReference { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_comboAddtionalRole")]
        public IWebElement AssociatedBusinessPartyAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtPercent")]
        public IWebElement AssociatedBusinessPartyPercent { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_txtAmount")]
        public IWebElement AssociatedBusinessPartyAmount { get; set; }

        [FindsBy(How = How.Id, Using = "ddlNoteType")]
        public IWebElement NoteType { get; set; }

        [FindsBy(How = How.Id, Using = "txtNotes")]
        public IWebElement Notes { get; set; }

        [FindsBy(How = How.Id, Using = "SearchInstrctions_txtInstructions")]
        public IWebElement Instructions { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_grdProdOffice")]
        public IWebElement EscrowProdOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds")]
        public IWebElement ProductTable { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_lblOwningOffName")]
        public IWebElement TitleOwningOfficePane { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_lblOwningOffName")]
        public IWebElement EscrowOwningOfficePane { get; set; }

        [FindsBy(How = How.Id, Using = "EsrwOwnOffice_lblAdres")]
        public IWebElement EscrowOwningOfficeAddress { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_lblAdres")]
        public IWebElement TitleOwningOfficeAddress { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_opt11SSN")]
        public IWebElement SSN { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNum")]
        public IWebElement FileNum { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNumPrx")]
        public IWebElement FileNumPrefix { get; set; }

        [FindsBy(How = How.Id, Using = "txtFileNumbSfx")]
        public IWebElement FileNumSufix { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_grdProdOffice")]
        public IWebElement TitleProdOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "Seller_opt11TIN")]
        public IWebElement TIN { get; set; }

        [FindsBy(How = How.LinkText, Using = "ServiceFileNote: No text was entered in the Note.")]
        public IWebElement ServiceFileErr1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_labelIdcode")]
        public IWebElement LenderIdCode { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_lblCountry")]
        public IWebElement PropertyCounty1 { get; set; }

        [FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_lblCityStateZip")]
        public IWebElement PropertyZip1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelIdcode")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtEditNMLSIDValue")]
        public IWebElement BusinessSourceNMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtBusOrgNMLS")]
        public IWebElement BusSourceNMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelContactName")]
        public IWebElement BusSourceContactName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_imgAdHocFlag")]
        public IWebElement BusinessSourceGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "__FAFErrorMessageList")]
        public IWebElement QFEErrorMessage { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_imgAdHocFlag")]
        public IWebElement GabPencilImage { get; set; }

        [FindsBy(How = How.Id, Using = "chkNextGen")]
        public IWebElement NGCheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "Products_grdProds_5_chkProdts")]
        public IWebElement AltaStandardLoanCheckBox { get; set; }

        //Elemnts part of FMUC0086
        [FindsBy(How = How.Id, Using = "BPDIRBY_imgAdHocFlag")]
        public IWebElement DirectedByGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_imgAdHocFlag")]
        public IWebElement NewLenderGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "BPASBP_imgAdHocFlag")]
        public IWebElement AssociateLenderGABImage { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtBusOrgNMLS")]
        public IWebElement NewLenderNMLS { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_ddlBusOrgStateLicense")]
        public IWebElement NewLenderStateLicense { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_txtBusContactNMLS")]
        public IWebElement NewLenderContactNMLS { get; set; }

        [FindsBy(How = How.Id, Using = "BPNLINFO_ddlBusContactStateLicense")]
        public IWebElement NewLenderContactStateLicense { get; set; }
        #endregion

        #region Services
        public QuickFileEntry FindBusinessSourceByGABCode(string GABCode, string reference = "", string additionalRole = "")
        {
            this.SwitchToContentFrame();
            txtBusinessSourceGABID.FASetText(GABCode);
            btnBusinessSourceGABFind.FAClick();
            this.WaitForValue(this.btnBusinessSourceGABCodeLabel, GABCode);
            BusinessSourceReference.FASetText(reference);
            BusinessSourceAddtionalRole.FASelectItemBySendingKeys(additionalRole);

            return this;
        }

        public QuickFileEntry SelectTransactionType(string TransactionType)
        {
            this.SwitchToContentFrame();
            ddlTransactionType.FASelectItem(TransactionType);

            return this;
        }

        public QuickFileEntry SelectCountry(string Country)
        {
            this.SwitchToContentFrame();
            PropertyCountry.FASelectItem(Country);

            return this;
        }

        public QuickFileEntry SelectState(string State)
        {
            this.SwitchToContentFrame();
            ddlPropertyState.FASelectItem(State);

            return this;
        }

        public QuickFileEntry SelectBusinessSegment(string BusinessSegment)
        {
            this.SwitchToContentFrame();
            ddlBusinessSegment.FASelectItem(BusinessSegment);

            return this;
        }

        public QuickFileEntry SelectServiceTypeEscrow(bool selected)
        {
            this.SwitchToContentFrame();
            if (selected)
            {
                if (!cbxServiceEscrow.Selected)
                    cbxServiceEscrow.FAClick();
            }


            return this;
        }

        public QuickFileEntry SelectServiceTypeTitle(bool selected)
        {
            this.SwitchToContentFrame();
            if (selected)
            {
                if (!cbxServiceTitle.Selected)
                    cbxServiceTitle.FAClick();
            }


            return this;
        }
        public QuickFileEntry SelectServiceTypeSubEscrow(bool selected)
        {
            this.SwitchToContentFrame();
            if (selected)
            {
                if (!this.cbxServiceSubEscrow.Selected)
                    cbxServiceSubEscrow.FAClick();
            }


            return this;
        }

        public FileHomepage SubmitQuickFileEntryForm()
        {
            this.SwitchToBottomFrame();
            btnDone.FAClick();

            return FastDriver.GetPage<FileHomepage>();
        }
        #endregion

        public QuickFileEntry WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? txtBusinessSourceGABID);

            return this;
        }

        public void VerifyBusinessProgramTableOrder()
        {
            List<string> sortedList = new List<string>();
            List<string> tempList = new List<string>();
            foreach (var row in BusinessProgramsTable.FAFindElements(ByLocator.TagName, "tr").Where(i => i.GetAttribute("id").Contains("BusinessPrograms_grdBusProg_")))
            {
                sortedList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Sorting the List
            sortedList.Sort();

            //System list
            foreach (var row in BusinessProgramsTable.FAFindElements(ByLocator.TagName, "tr").Where(i => i.GetAttribute("id").Contains("BusinessPrograms_grdBusProg_")))
            {
                tempList.Add(row.FAFindElements(ByLocator.TagName, "td").ElementAt(0).FAGetText());
            }

            //Verify whether the elements are sorted
            for (int i = 0; i < sortedList.Count; i++)
            {
                SeleniumInternalHelpersSupportLibrary.Support.AreEqual(sortedList.ElementAt(i), tempList.ElementAt(i));
            }

        }

        public QuickFileEntry CreateFile(NewFileParameters Parameters)
        {
            this.FindBusinessSourceByGABCode(Parameters.BusinessSourceGABcode, Parameters.BusinessSourceReference, Parameters.BusinessSourceAdditionalRole)
                .SelectServiceTypeTitle(Parameters.Title)
                .SelectServiceTypeEscrow(Parameters.Escrow)
                .SelectBusinessSegment(Parameters.BusinessSegment)
                .SelectTransactionType(Parameters.TransactionType)
                .SelectState(Parameters.PropertyState);
            // FormType
            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FormType_CD.FASetCheckbox(true);
            //  Service
            ProgramType.FASelectItemByIndex(0);
            // Sales price
            TermsDatesSalesPrice.FASetText(Parameters.TermsDatesSalesPrice);
            //  Property
            PropertyPropTaxAPN1.FASetText(Parameters.PropertyPropTaxAPN1);
            PropertyBookAddrLin1.FASetText(Parameters.PropertyBookAddrLin1);
            PropertyCity.FASetText(Parameters.PropertyCity);
            PropertyState.FASelectItem(Parameters.PropertyState);
            PropertyZip.FASetText(Parameters.PropertyZipCode);
            PropertyCounty.FASetText(Parameters.PropertyCounty);
            //  Buyer
            Buyer1Type.FASelectItem(Parameters.Buyer1Type);
            Buyer1FirstName.FASetText(Parameters.Buyer1FirstName);
            Buyer1LastName.FASetText(Parameters.Buyer1LastName);
            if (Parameters.Buyer1Type == "Husband/Wife")
            {
                Buyer1SpouseName.FASetText(Parameters.Buyer1SpouseName);
                Buyer1SpouseLastName.FASetText(Parameters.Buyer1SpouseLastName);
            }
            //  Seller
            Seller1Type.FASelectItem(Parameters.Seller1Type);
            Seller1FirstName.FASetText(Parameters.Seller1FirstName);
            Seller1LastName.FASetText(Parameters.Seller1LastName);
            NoteType.FASelectItem(Parameters.NoteType);
            Notes.FASetText(Parameters.Notes);
            return this;
        }

        public void CreateStandardFile()
        {

            this.SwitchToContentFrame();
            this.WaitCreation(BusinessSourceGABcode);
            BusinessSourceGABcode.FASetText("HUDFLINSR1");
            BusinessSourceFind.FAClick();
            DirectedBYGABcode.FASetText("HUDLEASE03");
            DirectedBYFind.FAClick();
            if (!Title.Selected)
                Title.FAClick();
            if (!Escrow.Selected)
                Escrow.FAClick();
            BusinessSegment.FASelectItemBySendingKeys("Residential");
            TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            ProgramType.FASelectItemByIndex(0);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FormType_CD.FASetCheckbox(true);

            ProductTable.PerformTableAction(2, 1, TableAction.On);
            TermsDatesSalesPrice.FASetText("5000");
            PropertyInformationName.FASetText("J305");
            PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
            PropertyInformationLot.FASetText("Lot1");
            PropertyInformationBlock.FASetText("Block1");
            PropertyInformationUnit.FASetText("Unit1");
            PropertyPropTaxAPN1.FASetText("Prop1APN1");
            PropertyPropTaxAPN2.FASetText("9845012345");
            PropertyBookAddrLin1.FASetText("J305");
            PropertyBookAddrLin2.FASetText("JJEJAMQ");
            PropertyBookAddrLin3.FASetText("JJEJAMQ");
            PropertyCity.FASetText("ALBANY");
            PropertyState.FASelectItemBySendingKeys("CA");
            PropertyZip.FASetText("12345");
            PropertyCounty.FASetText("ALAMEDA");
            Buyer1Type.FASelectItemBySendingKeys("Individual");
            Buyer1FirstName.FASetText("Buyer1Firstname");
            Buyer1LastName.FASetText("Buyer1Lastname");
            Buyer1SSN.FASetText("123456789");
            Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            Buyer2FirstName.FASetText("Buyer2Firstname");
            Buyer2LastName.FASetText("Buyer2Lastname");
            Buyer2SpouseName.FASetText("Buyer2SpouseName");
            Buyer2SSN.FASetText("123456789");
            Seller1Type.FASelectItemBySendingKeys("Individual");
            Seller1FirstName.FASetText("Seller1Firstname");
            Seller1LastName.FASetText("Seller1Lastname");
            Seller1SSN.FASetText("987654321");
            Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            Seller2FirstName.FASetText("Seller2Firstname");
            Seller2LastName.FASetText("Seller2Lastname");
            Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            Seller2SSN.FASetText("987654321");
            NewLenderInformationGABcode.FASetText("247");
            NewLenderInformationFind.FAClick();
            AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
            AssociatedBusinessPartyFind.FAClick();
            NoteType.FASelectItemBySendingKeys("EPIC");
            Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
            Playback.Wait(1000);
            //Keyboard.SendKeys("^{D}"); //Send Control + D
            //FastDriver.BottomFrame.Done();

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }

        }

        public void CreateCustomizedFileWithProgramType()
        {

            this.SwitchToContentFrame();
            this.WaitCreation(BusinessSourceGABcode);
            BusinessSourceGABcode.FASetText("HUDFLINSR1");
            BusinessSourceFind.FAClick();
            DirectedBYGABcode.FASetText("HUDLEASE03");
            DirectedBYFind.FAClick();
            if (!Title.Selected)
                Title.FAClick();
            if (!Escrow.Selected)
                Escrow.FAClick();
            BusinessSegment.FASelectItemBySendingKeys("Residential");
            TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");
            ProgramType.FASelectItemByIndex(1);

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FormType_CD.FASetCheckbox(true);

            ProductTable.PerformTableAction(2, 1, TableAction.On);
            TermsDatesSalesPrice.FASetText("5000");
            PropertyInformationName.FASetText("J305");
            PropertyInformationType.FASelectItemBySendingKeys("Single Family Residence");
            PropertyInformationLot.FASetText("Lot1");
            PropertyInformationBlock.FASetText("Block1");
            PropertyInformationUnit.FASetText("Unit1");
            PropertyPropTaxAPN1.FASetText("Prop1APN1");
            PropertyPropTaxAPN2.FASetText("9845012345");
            PropertyBookAddrLin1.FASetText("J305");
            PropertyBookAddrLin2.FASetText("JJEJAMQ");
            PropertyBookAddrLin3.FASetText("JJEJAMQ");
            PropertyCity.FASetText("ALBANY");
            PropertyState.FASelectItemBySendingKeys("CA");
            PropertyZip.FASetText("12345");
            PropertyCounty.FASetText("ALAMEDA");
            Buyer1Type.FASelectItemBySendingKeys("Individual");
            Buyer1FirstName.FASetText("Buyer1Firstname");
            Buyer1LastName.FASetText("Buyer1Lastname");
            Buyer1SSN.FASetText("123456789");
            Buyer2Type.FASelectItemBySendingKeys("Husband/Wife");
            Buyer2FirstName.FASetText("Buyer2Firstname");
            Buyer2LastName.FASetText("Buyer2Lastname");
            Buyer2SpouseName.FASetText("Buyer2SpouseName");
            Buyer2SSN.FASetText("123456789");
            Seller1Type.FASelectItemBySendingKeys("Individual");
            Seller1FirstName.FASetText("Seller1Firstname");
            Seller1LastName.FASetText("Seller1Lastname");
            Seller1SSN.FASetText("987654321");
            Seller2Type.FASelectItemBySendingKeys("Husband/Wife");
            Seller2FirstName.FASetText("Seller2Firstname");
            Seller2LastName.FASetText("Seller2Lastname");
            Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            Seller2SSN.FASetText("987654321");
            NewLenderInformationGABcode.FASetText("247");
            NewLenderInformationFind.FAClick();
            AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
            AssociatedBusinessPartyFind.FAClick();
            NoteType.FASelectItemBySendingKeys("EPIC");
            Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
            Playback.Wait(1000);
            //Keyboard.SendKeys("^{D}"); //Send Control + D
            //FastDriver.BottomFrame.Done();

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }

        }

        public QuickFileEntry UnselectAllCheckboxFromProductTable()
        {
            this.SwitchToContentFrame();
            foreach (var chk in ProductTable.FAFindElements(ByLocator.TagName, "input").Where(p => p.FAGetAttribute("type") == "checkbox").GetAllVisible())
            {
                if (chk.Selected)
                    chk.FASetCheckbox(false);
            }

            return this;
        }

        public void CreateFileOnDemand(string buyer, string state)
        {

            this.SwitchToContentFrame();
            this.WaitCreation(BusinessSourceGABcode, 10);
            BusinessSourceGABcode.FASetText("HUDFLINSR1");
            BusinessSourceFind.FAClick();
            DirectedBYGABcode.FASetText("HUDLEASE03");
            DirectedBYFind.FAClick();
            if (!Title.Selected)
                Title.FAClick();
            if (!Escrow.Selected)
                Escrow.FAClick();
            BusinessSegment.FASelectItem("Residential");
            TransactionType.FASelectItemBySendingKeys("Sale w/Mortgage");

            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FormType_CD.FASetCheckbox(true);

            TermsDatesSalesPrice.FASetText("5000");
            PropertyInformationName.FASetText("J305");
            PropertyInformationType.FASelectItem("Single Family Residence");
            PropertyInformationLot.FASetText("Lot1");
            PropertyInformationBlock.FASetText("Block1");
            PropertyInformationUnit.FASetText("Unit1");
            PropertyPropTaxAPN1.FASetText("Prop1APN1");
            PropertyPropTaxAPN2.FASetText("9845012345");
            PropertyBookAddrLin1.FASetText("J305");
            PropertyBookAddrLin2.FASetText("JJEJAMQ");
            PropertyBookAddrLin3.FASetText("JJEJAMQ");
            PropertyCity.FASetText("ALBANY");
            PropertyState.FASelectItem(state);
            PropertyZip.FASetText("12345");
            PropertyCounty.FASetText("ALAMEDA");
            Buyer1Type.FASelectItem("Individual");
            Buyer1FirstName.FASetText(buyer);
            Buyer1LastName.FASetText("Buyer1Lastname");
            Buyer1SSN.FASetText("123456789");
            Buyer2Type.FASelectItem("Husband/Wife");
            Buyer2FirstName.FASetText("Buyer2Firstname");
            Buyer2LastName.FASetText("Buyer2Lastname");
            Buyer2SpouseName.FASetText("Buyer2SpouseName");
            Buyer2SSN.FASetText("123456789");
            Seller1Type.FASelectItem("Individual");
            Seller1FirstName.FASetText("Seller1Firstname");
            Seller1LastName.FASetText("Seller1Lastname");
            Seller1SSN.FASetText("987654321");
            Seller2Type.FASelectItem("Husband/Wife");
            Seller2FirstName.FASetText("Seller2Firstname");
            Seller2LastName.FASetText("Seller2Lastname");
            Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            Seller2SSN.FASetText("987654321");
            NewLenderInformationGABcode.FASetText("247");
            NewLenderInformationFind.FAClick();
            AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
            AssociatedBusinessPartyFind.FAClick();
            NoteType.FASelectItem("EPIC");
            Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
            Playback.Wait(1000);

            try
            {
                FastDriver.BottomFrame.Done();
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
            }

        }

        public void CreateDetailedFile(string businessGab = "HUDFLINSR1", string directedGab = "DirectedBYGABcode", string assocBusGab = "HUDASLNDR1", string newLoanGAB = "247", bool escrow = true, bool title = true, bool subEscrow = false, string businessSegment = "Residential", string transactionType = "Sale w/Mortgage", bool projectFile = false, bool useAsMasterFile = false, string FileName = null,  bool buyer = true, bool seller = true, bool saveFile = true)
        {

            this.SwitchToContentFrame();
            this.WaitCreation(BusinessSourceGABcode);
            BusinessSourceGABcode.FASetText(businessGab);
            BusinessSourceFind.FAClick();
            DirectedBYGABcode.FASetText(directedGab);
            DirectedBYFind.FAClick();
            Title.FASetCheckbox(title);
            Escrow.FASetCheckbox(escrow);
            ProjectFile.FASetCheckbox(projectFile);
            UseAsMasterFile.FASetCheckbox(useAsMasterFile);
            BusinessSegment.FASelectItem(businessSegment);
            TransactionType.FASelectItemBySendingKeys(transactionType);
            FormType_HUD.FASetCheckbox(!AutoConfig.UseCDFormType);
            FormType_CD.FASetCheckbox(AutoConfig.UseCDFormType);
            SubEscrow.FASetCheckbox(subEscrow);
            TermsDatesSalesPrice.FASetText("5000");
            TermsDatesLiabililtyAmount.FASetText("5000");
            TermsDatesNewLoanAmnt.FASetText("5000");
            if (FileName != null)
            {
                AutoNumber.FASetCheckbox(false);
                FileNum.FASetText(FileName);
            }
            //TermsDatesSalesPrice.FASetText("5000" + FAKeys.Tab);
            //TermsDatesLiabililtyAmount.FASetText("3000.00");
            //TermsDatesNewLoanAmnt.FASetText("2000.00");
            //TermsDatesNewLoanLiability.FASetText("2000.00");
            PropertyInformationName.FASetText("J305");
            PropertyInformationType.FASelectItem("Condominium");
            PropertyInformationLot.FASetText("Lot1");
            PropertyInformationBlock.FASetText("Block1");
            PropertyInformationUnit.FASetText("Unit1");
            PropertyInformationTRact.FASetText("Tract");
            PropertyInformationBuilding.FASetText("Building");
            PropertyInformationBook.FASetText("Book");
            PropertyInformationPage.FASetText("Page");
            PropertyInformationSection.FASetText("section");
            PropertyInformationTownShip.FASetText("Township");
            PropertyInformationRange.FASetText("Range");
            PropertyInformationParcel.FASetText("Parcel");
            PropertyInformationSubdivisionCondominium.FASetText("Subdivision1");
            PropertyPropTaxAPN1.FASetText("Prop1APN1");
            PropertyPropTaxAPN2.FASetText("9845012345");
            PropertyPropTaxYear2.FASetText("2006-2007");
            PropertyBookAddrLin1.FASetText("J305");
            PropertyBookAddrLin2.FASetText("JJEJAMQ");
            PropertyBookAddrLin3.FASetText("JJEJAMQ");
            PropertyCity.FASetText("ALBANY");
            PropertyState.FASelectItem("CA");
            PropertyZip.FASetText("12345");
            PropertyCounty.FASetText("ALAMEDA");
            if (buyer)
            {
                Buyer1Type.FASelectItem("Individual");
                Buyer1FirstName.FASetText("Buyer1Firstname");
                Buyer1LastName.FASetText("Buyer1Lastname");
                Buyer1SSN.FASetText("123456789");
                Buyer2Type.FASelectItem("Husband/Wife");
                Buyer2FirstName.FASetText("Buyer2Firstname");
                Buyer2LastName.FASetText("Buyer2Lastname");
                Buyer2SpouseName.FASetText("Buyer2SpouseName");
                Buyer2SSN.FASetText("123456789");
            }
            if (seller)
            {
                Seller1Type.FASelectItem("Individual");
                Seller1FirstName.FASetText("Seller1Firstname");
                Seller1LastName.FASetText("Seller1Lastname");
                Seller1SSN.FASetText("987654321");
                Seller2Type.FASelectItem("Husband/Wife");
                Seller2FirstName.FASetText("Seller2Firstname");
                Seller2LastName.FASetText("Seller2Lastname");
                Seller2SpouseFirstName.FASetText("Seller2SpouseName");
                Seller2SSN.FASetText("987654321");
            }
            NewLenderInformationGABcode.FASetText(newLoanGAB);
            NewLenderInformationFind.FAClick();
            AssociatedBusinessPartyGABcode.FASetText(assocBusGab);
            AssociatedBusinessPartyFind.FAClick();
            NoteType.FASelectItem("EPIC");
            Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
            Playback.Wait(1000);
            if (saveFile)
            {
                try
                {
                    ProgramType.FASelectItemByIndex(0);
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception)
                {
                    FastDriver.BottomFrame.Done();
                }
            }
            
        }
        //
        public QuickFileEntry SelectProgramType(string ProgramType)
        {
            try
            {
                FastDriver.QuickFileEntry.ProgramType.FASelectItem(@"++View More...");
                FastDriver.ProgramTypesDlg.WaitForScreenToLoad();
                FastDriver.ProgramTypesDlg.ProgramTable.PerformTableAction(@"#2", ProgramType, "#1", TableAction.On);
                System.Threading.Thread.Sleep(1000);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }

            return this;
        }
        //
        public Dictionary<string, string> GetSellerDetailsOnQFEPage
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Seller1Type", Seller1Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Seller1FirstName", Seller1FirstName.FAGetValue().Trim());
                AllDetails.Add("Seller1LastName", Seller1LastName.FAGetValue().Trim());
                AllDetails.Add("Seller2Type", Seller2Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Seller2FirstName", Seller2FirstName.FAGetValue().Trim());
                AllDetails.Add("Seller2SpouseFirstName", Seller2SpouseFirstName.FAGetValue().Trim());
                AllDetails.Add("Seller2SpouseLastName", Seller2SpouseLastName.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetBuyerDetailsOnQFEPage
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Buyer1Type", Buyer1Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Buyer1FirstName", Buyer1FirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer1LastName", Buyer1LastName.FAGetValue().Trim());
                AllDetails.Add("Buyer2Type", Buyer2Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Buyer2FirstName", Buyer2FirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer2SpouseFirstName", Buyer2SpouseName.FAGetValue().Trim());
                AllDetails.Add("Buyer2SpouseLastName", Buyer2SpouseLastName.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetPropDetailsOnQFEPage
        {
            get
            {
                Dictionary<string, string> PropAdrDetails = new Dictionary<string, string>();
                PropAdrDetails.Add("PropertyName", PropertyInformationName.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyType", PropertyInformationType.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyEstateType", PropertyEstateType.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyLotName", PropertyInformationLot.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBlock", PropertyInformationBlock.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyUnit", PropertyInformationUnit.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyTRact", PropertyInformationTRact.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyFee", PropertyInformationFee.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBuilding", PropertyInformationBuilding.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBook", PropertyInformationBook.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPage", PropertyInformationPage.FAGetValue().Trim());
                PropAdrDetails.Add("PropertySection", PropertyInformationSection.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxAPN1", PropertyPropTaxAPN1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxAPN2", PropertyPropTaxAPN2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxYear1", PropertyPropTaxYear1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxYear2", PropertyPropTaxYear2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine1", PropertyBookAddrLin1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine2", PropertyBookAddrLin2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine3", PropertyBookAddrLin3.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine4", PropertyBookAddrLin4.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyAddressBookCity", PropertyCity.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyCity", PropertyCity.FAGetValue());
                PropAdrDetails.Add("PropertyState", PropertyState.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyCountry", PropertyCountry.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyZip", PropertyZip.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyCounty", PropertyCounty.FAGetValue().Trim());
                PropAdrDetails.Add("TransactionType", TransactionType.FAGetSelectedItem().Trim());
                PropAdrDetails.Add("TermsDatesPrice", TermsDatesSalesPrice.FAGetValue().Trim());
                return PropAdrDetails;
            }

        }
        public bool ValidateFieldForLowerOrExactLimit(IWebElement Element, string InputValue, string OutputValue, bool HandleDialog = false)
        { //we are using the random click to remove focus from field under test
            RandomClick();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            Element.FAClick();
            Element.FASetText(InputValue + FAKeys.Tab, false, true);

            if (HandleDialog)
                FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            if (OutputValue == Element.FAGetValue().Trim())
            {
                return true;
            }
            else

                return false;

        }
        //
        //we are using the random click to remove focus from field under test
        private void RandomClick()
        {
            FastDriver.TopFrame.SwitchToTopFrame();
            FastDriver.TopFrame.FileNumberEditBox.FAClick();
        }
        public bool ValidateFieldForUpperLimit(IWebElement Element, string InputValue, string OutputValue, bool HandleDialog = false)
        {
            //we are using the random click to remove focus from field under test
            RandomClick();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            Element.FAClick();
            Element.FASetText(InputValue + FAKeys.Tab, false, true);
            if (HandleDialog)
                FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            if (OutputValue == Element.FAGetValue().Trim())
                return true;
            else
                return false;
        }
    }

    public class ProductsListDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridProducts_dgridProducts")]
        public IWebElement ProductSummary { get; set; }

        #endregion

        public ProductsListDlg WaitForScreenToLoad(string windowName = "Product List")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(ProductSummary);

            return this;
        }

    }

}
