using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UITesting;
using FASTWCFHelpers;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace FASTSelenium.PageObjects.IIS
{
	public class QuickRefiFileEntry : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "BPSRC_txtGABcode")]
		public IWebElement BusinessSourceGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_idBPTitle")]
		public IWebElement DirectedByArrowIcon { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtGABcode")]
		public IWebElement DirectedByGabCode { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_cmdFindName")]
		public IWebElement BusinessSourceFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelIdcode")]
        public IWebElement BusinessSourceID { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelName")]
        public IWebElement BusinessSourceName1 { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtBusOrgNMLS")]
        public IWebElement BusinessSourceNMLSID { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_labelContactName")]
        public IWebElement BusinessSourceContactName { get; set; }

        [FindsBy(How = How.Id, Using = "BPSRC_txtName")]
		public IWebElement BusinessSourceName { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_chkEditContactInfo")]
		public IWebElement BusinessSourceEditCont { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textBusPhone")]
		public IWebElement BusinessSourceBusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_txtExtnPhone")]
		public IWebElement BusinessSourceBusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textBusFax")]
		public IWebElement BusinessSourceBusinessFax { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textCellPhone")]
		public IWebElement BusinessSourceCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textPager")]
		public IWebElement BusinessSourcePager { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textEmailAddress")]
		public IWebElement BusinessSourceEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_chkWeeklyEmailStatus")]
		public IWebElement BusinessSourceWeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_comboAttention")]
		public IWebElement BusinessSourceAttention { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_chkEdit")]
		public IWebElement BusinessSourceEditName { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textName")]
		public IWebElement BusinessSourceNameEdit { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_comboSalesRep1")]
		public IWebElement BusinessSourceSalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_comboSalesRep2")]
		public IWebElement BusinessSourceSalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_textReference")]
		public IWebElement BusinessSourceReference { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_comboAddtionalRole")]
		public IWebElement BusinessSourceAddtionalRole { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_txtPercent")]
		public IWebElement BusinessSourcePercentage { get; set; }

		[FindsBy(How = How.Id, Using = "BPSRC_txtAmount")]
		public IWebElement BusinessSourceAmount { get; set; }

		[FindsBy(How = How.Id, Using = "chkSrvceTitle")]
		public IWebElement Title { get; set; }

		[FindsBy(How = How.Id, Using = "chkSrvceEsrw")]
		public IWebElement Escrow { get; set; }

		[FindsBy(How = How.Id, Using = "chkSrvceSubEsrw")]
		public IWebElement SubEscrow { get; set; }

		[FindsBy(How = How.Id, Using = "rdCD")]
		public IWebElement FormType_CD { get; set; }

		[FindsBy(How = How.Id, Using = "rdHUD")]
		public IWebElement FormType_HUD { get; set; }

		[FindsBy(How = How.Id, Using = "ddlBusSegment")]
		public IWebElement BusinessSegment { get; set; }

		[FindsBy(How = How.Id, Using = "chkAutoNum")]
		public IWebElement AutoNumber { get; set; }

		[FindsBy(How = How.Id, Using = "ddlTransType")]
		public IWebElement TransactionType { get; set; }

		[FindsBy(How = How.Id, Using = "chkUseAsMstr")]
		public IWebElement UseAsMasterFile { get; set; }

		[FindsBy(How = How.Id, Using = "ddlProgramType")]
		public IWebElement ProgramType { get; set; }

		[FindsBy(How = How.Id, Using = "chkProgTypeOveride")]
		public IWebElement ProgramTypeOverride { get; set; }

		[FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOffice")]
		public IWebElement EscrowOwningOffice { get; set; }

		[FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlOfficer")]
		public IWebElement EscrowOwningOfficeOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "EsrwOwnOffice_ddlAssistant")]
		public IWebElement EscrowOwningOfficeAssistant { get; set; }

		[FindsBy(How = How.Id, Using = "EsrwOwnOffice_btnRemove")]
		public IWebElement AddRemoveEscrowOwnngOffice { get; set; }

		[FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlOffice")]
		public IWebElement TitleOwningOffice { get; set; }

		[FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlOfficer")]
		public IWebElement TitleOwningOfficeOfficer { get; set; }

		[FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlAssistant")]
		public IWebElement TitleOwningOfficeAssistant { get; set; }

		[FindsBy(How = How.Id, Using = "TitleOwnOffice_ddlUndrwriter")]
		public IWebElement TitleOwningOfficeUndrwriter { get; set; }

		[FindsBy(How = How.Id, Using = "TitleOwnOffice_btnRemove")]
		public IWebElement AddRemoveTitleOwningOffice { get; set; }

		[FindsBy(How = How.Id, Using = "BusinessPrograms_btnRemove")]
		public IWebElement AddRemoveBusinessProgrammes { get; set; }

		[FindsBy(How = How.Id, Using = "BusinessPrograms_grdBusProg")]
		public IWebElement BusinessProgramsTable { get; set; }

		[FindsBy(How = How.Id, Using = "Products_btnRemove")]
		public IWebElement AddRemoveProducts { get; set; }

		[FindsBy(How = How.Id, Using = "Products_grdProds_0_chkProdts")]
		public IWebElement ProductsSelect { get; set; }

		[FindsBy(How = How.Id, Using = "SearchInstrctions_ddlSearchType")]
		public IWebElement SearchType { get; set; }

		[FindsBy(How = How.Id, Using = "SearchInstrctions_btnRemove")]
		public IWebElement AddRemoveInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "SearchInstrctions_txtInstructions")]
		public IWebElement SearchInstructions { get; set; }

		[FindsBy(How = How.Id, Using = "SearchInstrctions_txtAddInstruction")]
		public IWebElement AddInstruction { get; set; }

		[FindsBy(How = How.Id, Using = "TermsDates_txtSlsPrie")]
		public IWebElement TermsDatesSalesPrice { get; set; }

		[FindsBy(How = How.Id, Using = "TermsDates_txtLibltyAmnt")]
		public IWebElement TermsDatesLiabililtyAmount { get; set; }

		[FindsBy(How = How.Id, Using = "TermsDates_txtNewLoanAmnt")]
		public IWebElement TermsDatesNewLoanAmnt { get; set; }

		[FindsBy(How = How.Id, Using = "TermsDates_txtNewLoanLiblty")]
		public IWebElement TermsDatesNewLoanLiability { get; set; }

		[FindsBy(How = How.Id, Using = "TermsDates_txtEstDaysToCls")]
		public IWebElement TermsDatesEstimateDaysToClose { get; set; }

		[FindsBy(How = How.Id, Using = "TermsDates_txtEstSetlDate")]
		public IWebElement TermsDatesEstimatedSettlementDate { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropName")]
		public IWebElement PropertyInformationName { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_ddlPropType")]
		public IWebElement PropertyInformationType { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropLotName")]
		public IWebElement PropertyInformationLot { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBlock")]
		public IWebElement PropertyInformationBlock { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropUnit")]
		public IWebElement PropertyInformationUnit { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTRact")]
		public IWebElement PropertyInformationTRact { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropFee")]
		public IWebElement PropertyInformationFee { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBuilding")]
		public IWebElement PropertyInformationBuilding { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropBook")]
		public IWebElement PropertyInformationBook { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropPage")]
		public IWebElement PropertyInformationPage { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropSection")]
		public IWebElement PropertyInformationSection { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTownShip")]
		public IWebElement PropertyInformationTownShip { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropRange")]
		public IWebElement PropertyInformationRange { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropParcel")]
		public IWebElement PropertyInformationParcel { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropSubDivCondo")]
		public IWebElement PropertyInformationSubdivisionCondominium { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_ddlEstateType")]
		public IWebElement PropertyEstateType { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_chkEreg")]
		public IWebElement Propertyreg { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_chkCnvsnRqd")]
		public IWebElement PropertyCnvsnReqd { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxAPN1")]
		public IWebElement PropertyPropTaxAPN1 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxYear1")]
		public IWebElement PropertyPropTaxYear1 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxAPN2")]
		public IWebElement PropertyPropTaxAPN2 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_txtPropTaxYear2")]
		public IWebElement PropertyPropTaxYear2 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine1")]
		public IWebElement PropertyBookAddrLin1 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine2")]
		public IWebElement PropertyBookAddrLin2 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine3")]
		public IWebElement PropertyBookAddrLin3 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtAddrLine4")]
		public IWebElement PropertyBookAddrLin4 { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtCity")]
		public IWebElement PropertyCity { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboState")]
		public IWebElement PropertyState { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtZip")]
		public IWebElement PropertyZip { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_txtCounty")]
		public IWebElement PropertyCounty { get; set; }

		[FindsBy(How = How.Id, Using = "PropertyInformation_PhysicalAddressBook_cboCountry")]
		public IWebElement PropertyCountry { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_ddl1Type")]
		public IWebElement Borrower1Type { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt11FName")]
		public IWebElement Borrower1FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt11MName")]
		public IWebElement Borrower1MiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt11LName")]
		public IWebElement Borrower1LastName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt11Suffix")]
		public IWebElement Borrower1Suffix { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt11SSN")]
		public IWebElement Borrower1SSN { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt12FName")]
		public IWebElement Borrower1SpouseName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt12MName")]
		public IWebElement Borrower1SpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt12LName")]
		public IWebElement Borrower1SpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt12Suffix")]
		public IWebElement Borrower1SpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt12SSN")]
		public IWebElement Borrower1SpouseSSN { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_ddl2Type")]
		public IWebElement Borrower2Type { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt21FName")]
		public IWebElement Borrower2FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt21MName")]
		public IWebElement Borrower2MiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt21LName")]
		public IWebElement Borrower2LastName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt21Suffix")]
		public IWebElement Borrower2Suffix { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt21SSN")]
		public IWebElement Borrower2SSN { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt22FName")]
		public IWebElement Borrower2SpouseName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt22MName")]
		public IWebElement Borrower2SpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt22LName")]
		public IWebElement BorrowerSpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt22Suffix")]
		public IWebElement Borrower2SpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_txt22SSN")]
		public IWebElement Borrower2SpouseSSN { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@id='Seller_tblBuyerSeller']//td[@class='cButtonExpandFalse']")]
        public IWebElement SellersArrowIcon { set; get; }

		[FindsBy(How = How.Id, Using = "Seller_ddl1Type")]
		public IWebElement Seller1Type { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt11FName")]
		public IWebElement Seller1FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt11MName")]
		public IWebElement Seller1MiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt11LName")]
		public IWebElement Seller1LastName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt11Suffix")]
		public IWebElement Seller1Suffix { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt11SSN")]
		public IWebElement Seller1SSN { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt12FName")]
		public IWebElement Seller1SpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt12MName")]
		public IWebElement Seller1SpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt12LName")]
		public IWebElement Seller1SpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt12Suffix")]
		public IWebElement Seller1SpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt12SSN")]
		public IWebElement Seller1SpouseSSN { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_ddl2Type")]
		public IWebElement Seller2Type { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt21FName")]
		public IWebElement Seller2FirstName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt21MName")]
		public IWebElement Seller2MiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt21LName")]
		public IWebElement Seller2LastName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt21Suffix")]
		public IWebElement Seller2Suffix { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt21SSN")]
		public IWebElement Seller2SSN { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt22FName")]
		public IWebElement Seller2SpouseFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt22MName")]
		public IWebElement Seller2SpouseMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt22LName")]
		public IWebElement Seller2SpouseLastName { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt22Suffix")]
		public IWebElement Seller2SpouseSuffix { get; set; }

		[FindsBy(How = How.Id, Using = "Seller_txt22SSN")]
		public IWebElement Seller2SpouseSSN { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_txtGABcode")]
		public IWebElement NewLenderInformationGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_cmdFindName")]
		public IWebElement NewLenderInformationFind { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_txtName")]
		public IWebElement NewLenderInformationName { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_chkEditContactInfo")]
		public IWebElement NewLenderInformationEditCont { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textBusPhone")]
		public IWebElement NewLenderInformationBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textBusFax")]
		public IWebElement NewLenderInformationBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textCellPhone")]
		public IWebElement NewLenderInformationCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textPager")]
		public IWebElement NewLenderInformationPager { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textEmailAddress")]
		public IWebElement NewLenderInformationEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_chkWeeklyEmailStatus")]
		public IWebElement NewLenderInformationWeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_comboAttention")]
		public IWebElement NewLenderInformationAttention { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_chkEdit")]
		public IWebElement NewLenderInformationEdit { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textName")]
		public IWebElement NewLenderInformationEditName { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_comboSalesRep1")]
		public IWebElement NewLenderInformationSalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_comboSalesRep2")]
		public IWebElement NewLenderInformationSalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_textReference")]
		public IWebElement NewLenderInformationReference { get; set; }

		[FindsBy(How = How.Id, Using = "BPNLINFO_txtPayoffAmt")]
		public IWebElement NewLenderPayoffAmt { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_txtGABcode")]
		public IWebElement AssociatedBusinessPartyGABcode { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_cmdFindName")]
		public IWebElement AssociatedBusinessPartyFind { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_txtName")]
		public IWebElement AssociatedBusinessPartyName { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_chkEditContactInfo")]
		public IWebElement AssociatedBusinessPartyEditCont { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textBusPhone")]
		public IWebElement AssociatedBusinessPartyBusPhone { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textBusFax")]
		public IWebElement AssociatedBusinessPartyBusFax { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textCellPhone")]
		public IWebElement AssociatedBusinessPartyCellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textPager")]
		public IWebElement AssociatedBusinessPartyPager { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textEmailAddress")]
		public IWebElement AssociatedBusinessPartyEmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_chkWeeklyEmailStatus")]
		public IWebElement AssociatedBusinessPartyWeeklyEmailStatus { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_comboAttention")]
		public IWebElement AssociatedBusinessPartyAttention { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_chkEdit")]
		public IWebElement AssociatedBusinessPartyEdit { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textName")]
		public IWebElement AssociatedBusinessPartyEditName { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_comboSalesRep1")]
		public IWebElement AssociatedBusinessPartySalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_comboSalesRep2")]
		public IWebElement AssociatedBusinessPartySalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_textReference")]
		public IWebElement AssociatedBusinessPartyReference { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_comboAddtionalRole")]
		public IWebElement AssociatedBusinessPartyAddtionalRole { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_txtPercent")]
		public IWebElement AssociatedBusinessPartyPercent { get; set; }

		[FindsBy(How = How.Id, Using = "BPASBP_txtAmount")]
		public IWebElement AssociatedBusinessPartyAmount { get; set; }

		[FindsBy(How = How.Id, Using = "ddlNoteType")]
		public IWebElement NoteType { get; set; }

		[FindsBy(How = How.Id, Using = "txtNotes")]
		public IWebElement Notes { get; set; }

		[FindsBy(How = How.Id, Using = "Buyer_lblName")]
		public IWebElement Borrower { get; set; }

		[FindsBy(How = How.Id, Using = "BPDIRBY_cmdFindName")]
		public IWebElement DirectedByFind { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_comboAddtionalRole")]
        public IWebElement DirectedByAddtionalRole { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtPercent")]
        public IWebElement DirectedByPercentage { get; set; }

        [FindsBy(How = How.Id, Using = "BPDIRBY_txtAmount")]
        public IWebElement DirectedByAmount { get; set; }


		[FindsBy(How = How.Id, Using = "BPNLINFO_labelSourceName")]
		public IWebElement NewPayOffLender { get; set; }

        [FindsBy(How = How.Id, Using = "TitleOwnOffice_cboUWEmployees")]
        public IWebElement UW_Employee { get; set; }
		#endregion

        #region Services

        public QuickRefiFileEntry WaitForScrenToLoad(IWebElement elem=null)
        {
            this.SwitchToContentFrame();
            if(elem == null)
            this.WaitCreation(BusinessSourceGABcode);
            else
                this.WaitCreation(elem);

            return this;
        }
        //
        public void OpenQREPage()
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick Refi Entry").WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.ClickSkipSearchButton();
            this.WaitForScrenToLoad();
        }

        public QuickRefiFileEntry CreateStandardFile()
        {

            this.SwitchToContentFrame();
            this.WaitForScrenToLoad();
            BusinessSourceGABcode.FASetText("HUDFLINSR1");
            BusinessSourceFind.FAClick();            

            DirectedByArrowIcon.FAClick();
            Playback.Wait(2000);
            DirectedByGabCode.FASetText("HUDLEASE03");
            DirectedByFind.FAClick();
            if (!Title.Selected)
                Title.FAClick();
            if (!Escrow.Selected)
                Escrow.FAClick();
            BusinessSegment.FASelectItem("Residential");
            TransactionType.FASelectItemBySendingKeys("Refinance");
            if (ClosingDisclosureSupport.IMDFormType == "HUD")
                FormType_HUD.FASetCheckbox(true);
            else if (ClosingDisclosureSupport.IMDFormType == "CD")
                FormType_CD.FASetCheckbox(true);            
            PropertyInformationName.FASetText("J305");
            PropertyInformationType.FASelectItem("Single Family Residence");
            PropertyInformationLot.FASetText("Lot1");
            PropertyInformationBlock.FASetText("Block1");
            PropertyInformationUnit.FASetText("Unit1");
            PropertyPropTaxAPN1.FASetText("Prop1APN1");
            PropertyPropTaxAPN2.FASetText("9845012345");
            PropertyBookAddrLin1.FASetText("J305");
            PropertyBookAddrLin2.FASetText("JJEJAMQ");
            PropertyBookAddrLin3.FASetText("JJEJAMQ");
            PropertyCity.FASetText("ALBANY");
            PropertyState.FASelectItem("CA");
            PropertyZip.FASetText("12345");
            PropertyCounty.FASetText("ALAMEDA");
            Borrower1Type.FASelectItem("Individual");
            Borrower1FirstName.FASetText("Buyer1Firstname");
            Borrower1LastName.FASetText("Buyer1Lastname");
            Borrower1SSN.FASetText("123456789");
            Borrower2Type.FASelectItem("Husband/Wife");
            Borrower2FirstName.FASetText("Buyer2Firstname");
            Borrower2LastName.FASetText("Buyer2Lastname");
            Borrower2SpouseName.FASetText("Buyer2SpouseName");
            Borrower2SSN.FASetText("123456789");

            //Seller
            SellersArrowIcon.FAClick();
            Playback.Wait(1500);
            Seller1Type.FASelectItem("Individual");
            Seller1FirstName.FASetText("Seller1Firstname");
            Seller1LastName.FASetText("Seller1Lastname");
            Seller1SSN.FASetText("987654321");
            Seller2Type.FASelectItem("Husband/Wife");
            Seller2FirstName.FASetText("Seller2Firstname");
            Seller2LastName.FASetText("Seller2Lastname");
            Seller2SpouseFirstName.FASetText("Seller2SpouseName");
            Seller2SSN.FASetText("987654321");
            NewLenderInformationGABcode.FASetText("247");
            NewLenderInformationFind.FAClick();
            AssociatedBusinessPartyGABcode.FASetText("HUDASLNDR1");
            AssociatedBusinessPartyFind.FAClick();
            NoteType.FASelectItem("EPIC");
            Notes.FASetText(@"Notes Data including - * # Specialcharacter :) !" + FAKeys.Tab);
            Playback.Wait(1000);

            try
            {
                FastDriver.BottomFrame.Done();
                return this;
            }
            catch (Exception)
            {
                FastDriver.BottomFrame.Done();
                return this;
            }
            return this;
        }
        //
        //
        public Dictionary<string, string> GetSellerDetailsOnQFEPage
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Seller1Type", Seller1Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Seller1FirstName", Seller1FirstName.FAGetValue().Trim());
                AllDetails.Add("Seller1LastName", Seller1LastName.FAGetValue().Trim());
                AllDetails.Add("Seller2Type", Seller2Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Seller2FirstName", Seller2FirstName.FAGetValue().Trim());
                AllDetails.Add("Seller2SpouseFirstName", Seller2SpouseFirstName.FAGetValue().Trim());
                AllDetails.Add("Seller2SpouseLastName", Seller2SpouseLastName.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetBuyerDetailsOnQFEPage
        {
            get
            {
                Dictionary<string, string> AllDetails = new Dictionary<string, string>();
                AllDetails.Add("Buyer1Type", this.Borrower1Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Buyer1FirstName", this.Borrower1FirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer1LastName", Borrower1LastName.FAGetValue().Trim());
                AllDetails.Add("Buyer2Type", Borrower2Type.FAGetSelectedItem().Trim());
                AllDetails.Add("Buyer2FirstName", Borrower2FirstName.FAGetValue().Trim());
                AllDetails.Add("Buyer2SpouseFirstName", Borrower2SpouseName.FAGetValue().Trim());
                AllDetails.Add("Buyer2SpouseLastName", this.BorrowerSpouseLastName.FAGetValue().Trim());
                return AllDetails;
            }
        }

        public Dictionary<string, string> GetPropDetailsOnQFEPage
        {
            get
            {
                Dictionary<string, string> PropAdrDetails = new Dictionary<string, string>();
                PropAdrDetails.Add("PropertyName", PropertyInformationName.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyType", PropertyInformationType.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyEstateType", PropertyEstateType.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyLotName", PropertyInformationLot.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBlock", PropertyInformationBlock.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyUnit", PropertyInformationUnit.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyTRact", PropertyInformationTRact.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyFee", PropertyInformationFee.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBuilding", PropertyInformationBuilding.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBook", PropertyInformationBook.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPage", PropertyInformationPage.FAGetValue().Trim());
                PropAdrDetails.Add("PropertySection", PropertyInformationSection.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxAPN1", PropertyPropTaxAPN1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxAPN2", PropertyPropTaxAPN2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxYear1", PropertyPropTaxYear1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyPropTaxYear2", PropertyPropTaxYear2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine1", PropertyBookAddrLin1.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine2", PropertyBookAddrLin2.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine3", PropertyBookAddrLin3.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyBookAddressLine4", PropertyBookAddrLin4.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyAddressBookCity", PropertyCity.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyCity", PropertyCity.FAGetValue());
                PropAdrDetails.Add("PropertyState", PropertyState.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyCountry", PropertyCountry.FAGetSelectedItem());
                PropAdrDetails.Add("PropertyZip", PropertyZip.FAGetValue().Trim());
                PropAdrDetails.Add("PropertyCounty", PropertyCounty.FAGetValue().Trim());
                PropAdrDetails.Add("TransactionType", TransactionType.FAGetSelectedItem().Trim());
                PropAdrDetails.Add("TermsDatesPrice", TermsDatesSalesPrice.FAGetValue().Trim());
                return PropAdrDetails;
            }

        }

        #endregion

    }
}
