using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class RPNProductSelectionDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "grdSTARSProduct_0_optJacketSelect")]
		public IWebElement grdSTARSProptJacketSelect { get; set; }

		[FindsBy(How = How.Id, Using = "grdSTARSProduct_grdSTARSProduct")]
		public IWebElement SelProduct { get; set; }

		#endregion

        public RPNProductSelectionDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Select Product", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? SelProduct);
            return this;
        }
    }
}
