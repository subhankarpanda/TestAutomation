using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class RPNVoidDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtVoidReason")]
		public IWebElement VoidReason { get; set; }

		[FindsBy(How = How.Id, Using = "btnOK")]
		public IWebElement Done { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

        #endregion

        public RPNVoidDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? VoidReason);
            return this;
        }

    }
}
