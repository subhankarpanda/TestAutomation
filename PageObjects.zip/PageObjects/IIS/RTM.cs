using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class RTM : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement DeliverMethod { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliverGUI")]
        public IWebElement DeliverButton { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_btnAddaddresses")]
        public IWebElement AddAddressees { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_btnModify")]
        public IWebElement Modify { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_btnRemove")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_dgRTMPackages_0_txtName")]
        public IWebElement PackageIDName { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_dgRTMPackages_1_txtName")]
        public IWebElement PackageIDName2 { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs")]
        public IWebElement RTMPackageDocuments { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_RTM_RTMDOC_tabRTMSubTab_MailTo")]
        public IWebElement MailTo { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo")]
        public IWebElement MailToTable { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo")]
        public IWebElement ReturnTo { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_btnSearchGAB")]
        public IWebElement SearchGAB { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_btnSelectFileAddressees")]
        public IWebElement SelectAddressees { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_btnSelectFileAddressees")]
        public IWebElement SelectAddresses { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_ddlOfficeName")]
        public IWebElement ReturnToOfficeName { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_txtAttention")]
        public IWebElement ReturnToAttention { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_ReturnTo_txtReference")]
        public IWebElement ReturnToReference { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_txtTab")]
        public IWebElement Tab { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_1_txtTab")]
        public IWebElement Tab2 { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_txtCopies")]
        public IWebElement Copies { get; set; }

        [FindsBy(How = How.LinkText, Using = "UK ENDOR T")]
        public IWebElement Element { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_btnUp")]
        public IWebElement Up { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_btnDown")]
        public IWebElement Down { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_btnRemoveDocs")]
        public IWebElement RemoveDocument { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs")]
        public IWebElement PackageTable { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_ddlPackaging")]
        public IWebElement Packaging { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_txtAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_MailTo_dgRTMMailTo_0_txtReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_dgRTMPackages_0_lblName")]
        public IWebElement PackageIDNamePane { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_TC_DS")]
        public IWebElement DocumentsTab { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_cbxColor")]
        public IWebElement Color { get; set; }

        [FindsBy(How = How.Id, Using = "TC_RTM_RTMDOC_dgRTMPackages_1_lblName")]
        public IWebElement RTMPackage2 { get; set; }
        

        #endregion

        public RTM WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Modify);
            return this;
        }

        public RTM WaitForPackageNameToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(PackageIDName);
            return this;
        }

    }
}
