using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class RTMLogDetailsWindow : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "lblPackageName")]
		public IWebElement PackageName { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1_FAFDataGrid1")]
		public IWebElement DetailsTable { get; set; }

		#endregion

        public RTMLogDetailsWindow WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? DetailsTable);
            return this;
        }
	}
}
