using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class RTMMailToAddresseesDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "__tab_tabAddresses_tabFBP")]
        public IWebElement FileBusinessParties { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFBP_SelectFBPAll")]
        public IWebElement tabAddressBP_SelectFBPAll { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFBP_SelectFBPNone")]
        public IWebElement tabAddressP_SelectFBPNone { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabAddresses_tabRTM")]
        public IWebElement RTMPackageAddressees { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabRTM_SelectRTMAll")]
        public IWebElement tabAddressTM_SelectRTMAll { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabRTM_SelectRTMNone")]
        public IWebElement tabAddressM_SelectRTMNone { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabAddresses_tabRTM")]
        public IWebElement RTMPackageAddresses { get; set; }

        [FindsBy(How = How.Id, Using = "__tab_tabAddresses_tabFO")]
        public IWebElement FileOffices { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_SelectOfficeAll")]
        public IWebElement tabAddressSelectOfficeAll { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_SelectOfficeNone")]
        public IWebElement tabAddresselectOfficeNone { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridEscrowOwningOffice_0_chkEOOStatus")]
        public IWebElement AddressOwningOfficeSelection { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabRTM_dgRTMAddresses")]
        public IWebElement RTMPackageTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFBP_dgFBPAddresses")]
        public IWebElement FileBusinessPartyTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridEscrowProductionOffice_0_chkEPOStatus")]
        public IWebElement QastandpointCheck { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridEscrowProductionOffice_1_chkEPOStatus")]
        public IWebElement QaofficedataFastCheck { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridEscrowOwningOffice")]
        public IWebElement EscrowOwningOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridEscrowProductionOffice")]
        public IWebElement EscrowProductionOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridTitleOwningOffice")]
        public IWebElement TitleOwningOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabFO_dgridTitleProductionOffice")]
        public IWebElement TitleProductionOfficeTable { get; set; }

        [FindsBy(How = How.Id, Using = "tabAddresses_tabRTM_dgRTMAddresses_0_chkRTMSelect")]
        public IWebElement RTMPackageAddres1 { get; set; }

        #endregion

        public RTMMailToAddresseesDlg WaitForScreenToLoad()
        {

            try
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_0_iframe");
            }
            catch (Exception)
            {
                this.WebDriver.SwitchTo().DefaultContent();
                this.WaitForFrameAndSwitchByFrameId("FAFDialog_1_iframe");
            }

            try
            {
                this.WaitForFrameAndSwitchByFrameId("fraPageWin");
            }
            catch { }

            this.WaitCreation(RTMPackageAddressees);
            return this;
        }
    }
}
