using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class RTMPackageCountDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnNewPack")]
		public IWebElement CreateNewPackage { get; set; }

		[FindsBy(How = How.Id, Using = "dgPackage_0_rdPackage")]
		public IWebElement SelectPackage1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgPackage_0_lbName")]
		public IWebElement Package1Name { get; set; }
        

		#endregion

        #region Methods
        public RTMPackageCountDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? CreateNewPackage);

            return this;
        }
        #endregion
    }
}
