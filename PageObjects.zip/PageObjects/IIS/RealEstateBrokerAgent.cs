using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using System.Linq;
using SeleniumInternalHelpersSupportLibrary;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects.IIS;
using System.Collections.Generic;
namespace FASTSelenium.PageObjects.IIS
{
    public class RealEstateBrokerAgentSummary : PageObject
    {
        public struct StructDeletionResult
        {
            public string Status;
            public bool isErrorWarningCorrect;
        }
        public StructDeletionResult DeletionResult { get; set; }

        
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgdREBroker_1_labelName")]
        public IWebElement SellerbrokerName { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[.='Lenders Advantage']")]
        public IWebElement LendersAdvantage { get; set; }

         [FindsBy(How = How.Id, Using = "dgdREBroker_3_labelName")]
        public IWebElement BuyerBrokerName { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker_3")]
        public IWebElement Buyer { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker_1")]
        public IWebElement Seller { get; set; }

        [FindsBy(How = How.Id, Using = "dgdOtherREBroker_1_labelOtherName")]
        public IWebElement OtherbrokerName { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement SellerBuyerEdit { get; set; }

        //[FindsBy(How = How.Id, Using = "dgdREBroker_3_labelName")]
        //public IWebElement BuyerBrokerName { get; set; }
        
        //[FindsBy(How = How.Id, Using = "dgdREBroker_3")]
        //public IWebElement Buyer { get; set; }

        //[FindsBy(How = How.Id, Using = "dgdREBroker_1")]
        //public IWebElement Seller { get; set; }

        //[FindsBy(How = How.Id, Using = "dgdOtherREBroker_1_labelOtherName")]
        //public IWebElement OtherbrokerName { get; set; }

        //[FindsBy(How = How.Id, Using = "cmdEdit")]
        //public IWebElement SellerBuyerEdit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement SellerBuyerRemove { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement NewOther { get; set; }

        [FindsBy(How = How.Id, Using = "cmdOtherEdit")]
        public IWebElement EditOther { get; set; }

        [FindsBy(How = How.Id, Using = "dgdOtherREBroker")]
        public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "Other Broker 1 for HUD Test Name 1")]
        public IWebElement OtherBrokeforHUDTestName1 { get; set; }

        [FindsBy(How = How.Id, Using = "cmdOtherDelete")]
        public IWebElement RemoveOther { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker_1_labelName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker")]
        public IWebElement SellerBuyerSummary { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker_3_labelName")]
        public IWebElement BuyerbrokerNew { get; set; }

        #endregion

        public RealEstateBrokerAgentSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>("Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();

            return this;
        }

        public RealEstateBrokerAgentSummary WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            var o = this.WaitCreation(BuyerBrokerName, 5) || this.WaitCreation(SellerbrokerName, 5);

            return this;
        }

        public RealEstateBrokerAgentSummary SelectAgentBrokerBy(string BuyerOrSeller, string CommissionPercent="")
        {
            Reports.TestStep = "Real State Broken Agent";
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent");

            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper().Contains("BROKER"))
            {
                if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    SellerbrokerName.FAClick();

                if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    BuyerbrokerNew.FAClick();
                SellerBuyerEdit.FAClick();
            }

            if (BuyerOrSeller.ToUpper() == "OTHER")
                NewOther.FAClick();

            Reports.TestStep = "Enter Gab Code and Click on Find.";
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText("HUDASLNDR1");
            FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

            if (!string.IsNullOrWhiteSpace(CommissionPercent))
            {
                Reports.TestStep = "Enter commission percent";
                FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(CommissionPercent, true);
            }

            Reports.TestStep = "Click on Done.";
            FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            //FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
            return this;
        }



        //
        public void EditAgentBroker(string BuyerOrSeller,string REBAgentName="", string GABCode = "", string CommissionPercent = "", string CommissionAmount="")
        {
            
            try
            {
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Reports.TestStep = "Edit Real State Broker Agent";
                if (BuyerOrSeller.ToUpper() == "OTHER")
                {
                    if (string.IsNullOrEmpty(REBAgentName))
                    {
                        FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.Click);
                    }
                    else
                    {
                        FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, REBAgentName, 2, TableAction.Click);
                    }

                    EditOther.FAClick();
                }
                else
                {
                    if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    {
                        //SellerbrokerName.FAClick();
                        FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);
                    }
                    else if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    {
                        //BuyerBrokerName.FAClick();
                        FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                    }
                    SellerBuyerEdit.FAClick();
                }

                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad(FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode);
                if (GABCode != "")
                {
                    Reports.TestStep = "Enter Gab Code and Click on Find.";
                    FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(GABCode);
                    FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                }
                if (CommissionPercent != "")
                {
                    Reports.TestStep = "Enter commission percent";
                    FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(CommissionPercent+FAKeys.Tab, true);
                    FastDriver.RealEstateBrokerAgent.CommissionPercent.SendKeys(FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                }
                if (CommissionAmount != "")
                {
                    Reports.TestStep = "Enter commission amount";
                    FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(CommissionAmount+FAKeys.Tab, true);
                    FastDriver.RealEstateBrokerAgent.CommissionAmount.SendKeys(FAKeys.Tab);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                }
            }
            catch
            {
                throw;
            }
        }
        //

        public RealEstateBrokerAgentSummary SelectAgentBrokerByGABCode(string BuyerOrSeller, string GABCode,string AgentGabCode="")
        {
            
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            Reports.TestStep = "Select Real State Broken Agent";
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper().Contains("BROKER"))
            {
                if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    SellerbrokerName.FAClick();

                if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    BuyerbrokerNew.FAClick();
                SellerBuyerEdit.FAClick();
            }

            if (BuyerOrSeller.ToUpper() == "OTHER")
                NewOther.FAClick();

            Reports.TestStep = "Enter Gab Code and Click on Find.";
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(GABCode);
            FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();

            if (AgentGabCode != "")
            {
                FastDriver.RealEstateBrokerAgent.BrokerContactGABcode.FASetText(AgentGabCode);
                FastDriver.RealEstateBrokerAgent.BrokerContactFind.FAClick();
            }

            FastDriver.WebDriver.HandleDialogMessage();
            Reports.TestStep = "Click on Done.";
            FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent");
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
            return this;
        }

        public RealEstateBrokerAgentSummary SelectLicenceID(string BuyerOrSeller, string REBrokerLicenseID, string REAgentLicenseID="")
        {

            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            Reports.TestStep = "Select Real State Broken Agent";
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper().Contains("BROKER"))
            {
                if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);

                if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                SellerBuyerEdit.FAClick();//Keyboard.SendKeys(FAKeys.Alt + "E");
            }

            if (BuyerOrSeller.ToUpper() == "OTHER")
                NewOther.FAClick();

            Reports.TestStep = "Enter Gab Code and Click on Find.";
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.STLicenseID.FASelectItem(REBrokerLicenseID);
            if (REAgentLicenseID!="")
            FastDriver.RealEstateBrokerAgent.ConactSTLicenseID.FASelectItem(REAgentLicenseID);

            Reports.TestStep = "Click on Done.";
            FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent");
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();
            return this;
        }

        public RealEstateBrokerAgentSummary DeleteREAgent(string BuyerOrSeller)
        {

            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            Reports.TestStep = "Select Real State Broken Agent";
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper().Contains("BROKER"))
            {
                if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);

                if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                SellerBuyerEdit.FAClick();//Keyboard.SendKeys(FAKeys.Alt + "E");
            }


            Reports.TestStep = "Enter Gab Code and Click on Find.";
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.RemoveAgent.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();

            Reports.TestStep = "Click on Done.";
            FastDriver.RealEstateBrokerAgent.SwitchToBottomFrame();
            FastDriver.BottomFrame.Done();
            return this;
        }

        public RealEstateBrokerAgentSummary EditREBInfo(string BuyerOrSeller)
        {

            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            Reports.TestStep = "Select Real State Broken Agent";
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper().Contains("BROKER"))
            {
                if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);

                if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.FAClick();//Keyboard.SendKeys(FAKeys.Alt + "E");
            }
            Reports.TestStep = "Enter Gab Code and Click on Find.";
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.BrokerInformationEdit.FASetCheckbox(true);
            FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhone.FASetText("(999)999-9999");
            FastDriver.RealEstateBrokerAgent.BrokerInformationBusinessPhoneExtension.FASetText("999");
            FastDriver.RealEstateBrokerAgent.BrokerInformationEmailAddress.FASetText("sshri@firstam.com");
            FastDriver.BottomFrame.Done();
            return this;
        }


        public RealEstateBrokerAgentSummary DeleteREBrokerAgent(string BuyerOrSeller)
        {

            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            Reports.TestStep = "Select Real State Broken Agent";
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
            {
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);
            }

            if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
            {
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
            }
            SellerBuyerRemove.FAClick();
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                //Keyboard.SendKeys(FAKeys.Alt + "E");
            

            return this;
        }

        public RealEstateBrokerAgentSummary RemoveLicense(string BuyerOrSeller)
        {

            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            Reports.TestStep = "Select Real State Broken Agent";
            FastDriver.RealEstateBrokerAgentSummary.SwitchToContentFrame();

            if (BuyerOrSeller.ToUpper().Contains("BROKER"))
            {
                if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);

                if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                SellerBuyerEdit.FAClick();//Keyboard.SendKeys(FAKeys.Alt + "E");
            }

            if (BuyerOrSeller.ToUpper() == "OTHER")
                NewOther.FAClick();

            Reports.TestStep = "Enter Gab Code and Click on Find.";
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            FastDriver.RealEstateBrokerAgent.STLicenseID.FASelectItemByIndex(0);
            FastDriver.BottomFrame.Done();
            return this;
        }

        //
        public bool CreateAgentBroker(string BuyerOrSeller, string BrokerInformationGABcode = "HUDASLNDR1", string BrokerContactGABcode = "", string CommissionPercent = "", string CommissionAmount = "")
        {
            try
            {
                
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                Reports.TestStep = "Create Real State Broker Agent";
                int i=FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.GetRowCount();
                if (BuyerOrSeller.ToUpper() == "OTHER")
                {
                    NewOther.FAClick();
                    FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                }
                else
                {
                    if (BuyerOrSeller.ToUpper() == "SELLERBROKER")
                    {
                        //SellerbrokerName.FAClick();
                        FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.Click);
                    }
                    else if (BuyerOrSeller.ToUpper() == "BUYERBROKER")
                    {
                        //BuyerBrokerName.FAClick();
                        FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.Click);
                    }
                    SellerBuyerEdit.FAClick();
                    FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                }

                Reports.TestStep = "Enter Gab Code and Click on Find.";
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                if (!string.IsNullOrWhiteSpace(BrokerInformationGABcode))
                {
                    FastDriver.RealEstateBrokerAgent.BrokerInformationGABcode.FASetText(BrokerInformationGABcode);
                    FastDriver.RealEstateBrokerAgent.BrokerInformationFind.FAClick();
                }
                
                //
                if (!string.IsNullOrWhiteSpace(CommissionPercent))
                {
                    Reports.TestStep = "Enter commission percent";
                    FastDriver.RealEstateBrokerAgent.CommissionPercent.FASetText(CommissionPercent+FAKeys.Tab, true);
                }
                if (!string.IsNullOrWhiteSpace(BrokerContactGABcode))
                {
                    Reports.TestStep = "Find broker contact gab";
                    FastDriver.RealEstateBrokerAgent.BrokerContactGABcode.FASetText(BrokerContactGABcode, true);
                    FastDriver.RealEstateBrokerAgent.BrokerContactFind.FAClick();
                }
                if (!string.IsNullOrWhiteSpace(CommissionAmount))
                {
                    Reports.TestStep = "Enter commission amount";
                    FastDriver.RealEstateBrokerAgent.CommissionAmount.FASetText(CommissionAmount + FAKeys.Tab, true);
                    FastDriver.WebDriver.HandleDialogMessage();
                    FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                }

                //#region <SRT-ServReq> - R08
                ////Team                                  :  ServReq-Team1
                ////Iteration                             :  r08
                ////UserStory                             :  User Story 765685:INC2597809 - Direct - [Bug ] ProNo indicator not present in the Transaction Coordinator screen
                ////TestCase                              :  829582
                ////Appended By/ Created By               :  Tushar Shankar

                //Reports.TestStep = "To verify Proactive Notification image is visible in Transaction Summary Screen - INC2597809 ";
                //FastDriver.RealEstateBrokerAgent.TransactionCoordinator.Click();
                //FastDriver.TransactionCoordinatorSummary.SwitchToContentFrame();
                //FastDriver.TransactionCoordinatorSummary.New.Click();
                ////  Address Book Business Organization Search for the ID with Proactive Notification has been set in ADM site 
                //FastDriver.AddressBookSearchDlg.FindAndSelectContact(IDCode: "boa");
                //Playback.Wait(2000);
                //FastDriver.TransactionCoordinatorSummary.SwitchToContentFrame();
                //bool Pronoimage = FastDriver.TransactionCoordinatorSummary.ProNo.Exists();
                //Support.AreEqual("True", Pronoimage.ToString());
                //FastDriver.BottomFrame.Done();
                //FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();

                //#endregion <SRT-ServReq> - R08

                return true;
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Cannot create REB instance "+ex.Message, false);
                return false;
            }

        }
        //
        public StructDeletionResult DeleteAgentBroker(string BuyerOrSeller, string REBAgentName, string WarningMessage = "",bool ShouldBeDeleted=true)
        {
            IWebElement Table = null;
            IWebElement Remove = null;
            StructDeletionResult DelResult = new StructDeletionResult();
            bool IsREBSummaryLoadedAlready = FastDriver.GetPage<FASTSelenium.PageObjects.IIS.RealEstateBrokerAgentSummary>().NewOther.Exists();             
            if (!IsREBSummaryLoadedAlready)
            {
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            }

            try
            {
                this.SwitchToContentFrame();
                if(BuyerOrSeller.ToUpper().Equals("OTHER"))
                {
                    Table=FastDriver.RealEstateBrokerAgentSummary.SummaryTable;
                    Remove = FastDriver.RealEstateBrokerAgentSummary.RemoveOther;
                }
                else if (BuyerOrSeller.ToUpper().Equals("SELLERBROKER") || BuyerOrSeller.ToUpper().Equals("BUYERBROKER"))
                {
                    Table = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary;
                    Remove = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove;
                }
                if (!string.IsNullOrEmpty(REBAgentName))
                    DelResult.Status = Table.PerformTableAction("#2", REBAgentName, "#2", TableAction.Click).Status.ToString();

                if (DelResult.Status.Equals("Success"))
                {
                    Remove.Click();
                    if (!string.IsNullOrEmpty(WarningMessage))
                        DelResult.isErrorWarningCorrect = ValidateErrorWarningMessageInPopUp(WarningMessage);
                    else FastDriver.WebDriver.HandleDialogMessage();
                    this.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("REB Agent entry to be deleted doesn't exist", false);
                    DelResult.Status="Fail";
                    return DelResult;
                }
                this.SwitchToContentFrame();
                if (ShouldBeDeleted)
                {
                    if (Table.FAGetText().Contains("Available"))
                        DelResult.Status = Table.PerformTableAction("#2", "Available", "#2", TableAction.Click).Status.ToString();
                    else if (Table.FAGetText().Contains(REBAgentName))
                        DelResult.Status = "Fail";
                }
                else
                {
                    if (Table.FAGetText().Contains(REBAgentName))
                        DelResult.Status = Table.PerformTableAction("#2", REBAgentName, "#2", TableAction.Click).Status.ToString();
                    else
                        DelResult.Status = "Fail";

                }
                 return DelResult;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to delete REB agent instance " + ex.Message, false);
                return DelResult;
            }
        }
        //
        public StructDeletionResult CancelDeletionOfAgentBroker(string BuyerOrSeller, string REBAgentName, string WarningMessage = "")
        {
            IWebElement Table = null;
            IWebElement Remove = null;
            StructDeletionResult DelResult = new StructDeletionResult();
            bool IsREBSummaryLoadedAlready = FastDriver.GetPage<FASTSelenium.PageObjects.IIS.RealEstateBrokerAgentSummary>().NewOther.Exists();
            if (!IsREBSummaryLoadedAlready)
            {
                FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
            }

            try
            {
                this.SwitchToContentFrame();
                if (BuyerOrSeller.ToUpper().Equals("OTHER"))
                {
                    Table = FastDriver.RealEstateBrokerAgentSummary.SummaryTable;
                    Remove = FastDriver.RealEstateBrokerAgentSummary.RemoveOther;
                }
                else if (BuyerOrSeller.ToUpper().Equals("SELLERBROKER") || BuyerOrSeller.ToUpper().Equals("BUYERBROKER"))
                {
                    Table = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary;
                    Remove = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerRemove;
                }
                if (!string.IsNullOrEmpty(REBAgentName))
                    DelResult.Status = Table.PerformTableAction("#2", REBAgentName, "#2", TableAction.Click).Status.ToString();

                if (DelResult.Status.Equals("Success"))
                {
                    Remove.Click();
                    if (!string.IsNullOrEmpty(WarningMessage))
                        DelResult.isErrorWarningCorrect = ValidateErrorWarningMessageInPopUp(WarningMessage,false);
                    else
                        FastDriver.WebDriver.HandleDialogMessage(true, false);

                    this.WaitForScreenToLoad();
                }
                else
                {
                    Reports.StatusUpdate("REB Agent entry to be deleted doesn't exist", false);
                    DelResult.Status = "Fail";
                    return DelResult;
                }
                this.SwitchToContentFrame();
            
                    if (Table.FAGetText().Contains(REBAgentName))
                        DelResult.Status = Table.PerformTableAction("#2", REBAgentName, "#2", TableAction.Click).Status.ToString();
                    else
                        DelResult.Status = "Fail";

                
                return DelResult;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to delete REB agent instance " + ex.Message, false);
                return DelResult;
            }
        }
        //
        public bool CheckPresenceOfRealEstateAgentOrBroker(string BuyerOrSeller,string TypeBrokerOrAgent, string BrokerInformationGABName)
        {
            try
            {
                //FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgentSummary>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
                this.WaitForScreenToLoad();
                Reports.TestStep = "Check presence of Real State Broker Agent or broker";
                if (TypeBrokerOrAgent.Equals("Broker", StringComparison.CurrentCultureIgnoreCase))
                {
                    if (BuyerOrSeller.ToUpper() == "OTHER")
                    {
                        string OtherBroker = FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message;
                        if (OtherBroker.Contains(BrokerInformationGABName))
                            return true;
                    }
                    else
                    {
                        if (BuyerOrSeller.ToUpper() == "SELLER")
                        {
                            string SellerBroker = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 2, TableAction.GetText).Message;
                            if (SellerBroker.Contains(BrokerInformationGABName))
                                return true;
                        }
                        else if (BuyerOrSeller.ToUpper() == "BUYER")
                        {
                            string BuyerBroker = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 2, TableAction.GetText).Message;
                            if (BuyerBroker.Contains(BrokerInformationGABName))
                                return true;
                        }
                    }
                }
                else
                {
                        if (BuyerOrSeller.ToUpper() == "OTHER")
                        {
                            string OtherBroker = FastDriver.RealEstateBrokerAgentSummary.SummaryTable.PerformTableAction(2, 3, TableAction.GetText).Message;
                            if (OtherBroker.Contains(BrokerInformationGABName))
                                return true;
                        }
                        else
                        {
                            if (BuyerOrSeller.ToUpper() == "SELLER")
                            {
                                string SellerBroker = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(3, 3, TableAction.GetText).Message;
                                if (SellerBroker.Contains(BrokerInformationGABName))
                                    return true;
                            }
                            else if (BuyerOrSeller.ToUpper() == "BUYER")
                            {
                                string BuyerBroker = FastDriver.RealEstateBrokerAgentSummary.SellerBuyerSummary.PerformTableAction(5, 3, TableAction.GetText).Message;
                                if (BuyerBroker.Contains(BrokerInformationGABName))
                                    return true;
                            }
                        }
                }

               
                return false;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Real Estate Agent Not found " + ex.Message, false);
                return false;
            }

        }

        public bool ValidateErrorWarningMessageInPopUp(string ExpectedMessage,bool ShouldBeDeleted=true)
        {

                string Message = FastDriver.WebDriver.HandleDialogMessage(true,ShouldBeDeleted);
                return ExpectedMessage.Trim().Equals(Message);
        }
        //
        public bool ValidateErrorWarningMessageInMessagePane(string ExpectedMessage)
        {
           FastDriver.WebDriver.HandleDialogMessage();
           this.WaitForScreenToLoad();
           string Message= FastDriver.RealEstateBrokerAgent.MessagePane.FAGetText();
           return Message.Trim().Equals(ExpectedMessage);
        }
    }

    public class RealEstateBrokerAgent : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "bpDS_labelIdcode")]
        public IWebElement BrokerDisbursementGABCodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_cBntExp3")]
        public IWebElement REBExpandIcon { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_0_tga")]
        public IWebElement RealEstateBrokerChargesLoanUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "cgCC_dcs_0_tga")]
        public IWebElement CommisionChargeAmountLoanUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_0_tga")]
        public IWebElement REBBrokerCreditsLoanUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "cgPOC_dcs_0_tga")]
        public IWebElement POCbyBrokerLoanUnrounded { get; set; }

        [FindsBy(How = How.Id, Using = "btnTransactionCoordinator")]
        public IWebElement TransactionCoordinator { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement GabNameLabel1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName2")]
        public IWebElement GabNameLabel2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdAdHoc")]
        public IWebElement BrokerInformationAdHoc { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdCheckDetails")]
        public IWebElement BrokerInformationCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtGABcode")]
        public IWebElement BrokerInformationGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdFindName")]
        public IWebElement BrokerInformationFind { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtName")]
        public IWebElement BrokerInformationName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEditContactInfo")]
        public IWebElement BrokerInformationEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkBusOrgStateLicense")]
        public IWebElement STLicenseIDEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkBusContactStateLicense")]
        public IWebElement ContactSTLicenseIDEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
        public IWebElement IDCode { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelAddress")]
        public IWebElement Addressline1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelAddress2")]
        public IWebElement Addressline2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelStateAndZip")]
        public IWebElement Citystate { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelStateAndZip")]
        public IWebElement Citystateblank { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textBusPhone")]
        public IWebElement BrokerInformationBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtExtnPhone")]
        public IWebElement BrokerInformationBusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textBusFax")]
        public IWebElement BrokerInformationBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textCellPhone")]
        public IWebElement BrokerInformationCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textPager")]
        public IWebElement BrokerInformationPager { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textEmailAddress")]
        public IWebElement BrokerInformationEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkWeeklyEmailStatus")]
        public IWebElement BrokerInformationEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboAttention")]
        public IWebElement BrokerInformationAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEdit")]
        public IWebElement BrokerInformationEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textName")]
        public IWebElement BrokerInformationNameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep1")]
        public IWebElement BrokerInformationSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_comboSalesRep2")]
        public IWebElement BrokerInformationSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textReference")]
        public IWebElement BrokerInformationReference { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactName")]
        public IWebElement BrokerContactsName { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkEditAttentionContactInfo")]
        public IWebElement ContactEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactAddress")]
        public IWebElement ContactAddressline1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactAddress2")]
        public IWebElement ContactAddressline2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactStateAndZip")]
        public IWebElement ContactAddressline3 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactStateAndZip")]
        public IWebElement ContactAddressline3blank { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactBusPhone")]
        public IWebElement ContactBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtContactExtnPhone")]
        public IWebElement ContactExtnPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactBusFax")]
        public IWebElement ContactBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactEmailAddress")]
        public IWebElement ContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactCellPhone")]
        public IWebElement ContactCellphone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactPager")]
        public IWebElement ContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_chkContactWeeklyEmailStatus")]
        public IWebElement ContactweeklyEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactBusPhone")]
        public IWebElement ContactDetailsBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_txtContactExtnPhone")]
        public IWebElement ContactDetailsExtnPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactBusFax")]
        public IWebElement ContactDetailsBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactCellPhone")]
        public IWebElement ContactDetailsCellphone { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactPager")]
        public IWebElement ContactDetailsPager { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_textContactEmailAddress")]
        public IWebElement ContactDetailsEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_cmdAdHoc")]
        public IWebElement BrokerContactAdHoc { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_cmdAdHoc")]
        public IWebElement OtherAgentAdHoc { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_txtGABcode")]
        public IWebElement BrokerContactGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_cmdFindName")]
        public IWebElement BrokerContactFind { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_txtName")]
        public IWebElement BrokerContactGABName { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_chkEditContactInfo")]
        public IWebElement BrokerContactEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textBusPhone")]
        public IWebElement BrokerContactBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_txtExtnPhone")]
        public IWebElement BrokerContactBusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textBusFax")]
        public IWebElement BrokerContactBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textCellPhone")]
        public IWebElement BrokerContactCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textPager")]
        public IWebElement BrokerContactPager { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textEmailAddress")]
        public IWebElement BrokerContactEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_chkWeeklyEmailStatus")]
        public IWebElement BrokerContactStatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_comboAttention")]
        public IWebElement BrokerContactAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_chkEdit")]
        public IWebElement BrokerContactEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textName")]
        public IWebElement BrokerContactName { get; set; }


        [FindsBy(How = How.Id, Using = "bpB_ddlBusOrgStateLicense")]
        public IWebElement STLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_ddlBusOrgStateLicense")]
        public IWebElement ConactSTLicenseID { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_comboSalesRep1")]
        public IWebElement BrokerContactSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_comboSalesRep2")]
        public IWebElement BrokerContactSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_textReference")]
        public IWebElement BrokerContactReference { get; set; }

        [FindsBy(How = How.Id, Using = "txtCommissionPercent")]
        public IWebElement CommissionPercent { get; set; }

        [FindsBy(How = How.Id, Using = "txtCommissionAmount")]
        public IWebElement CommissionAmount { get; set; }

        [FindsBy(How = How.Id, Using = "chkCreditSeller")]
        public IWebElement CreditSeller { get; set; }

        [FindsBy(How = How.Id, Using = "txtCreditSellerAmount")]
        public IWebElement CreditSellerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "chkCreditBuyer")]
        public IWebElement CreditBuyer { get; set; }

        [FindsBy(How = How.Id, Using = "txtCreditBuyerAmount")]
        public IWebElement CreditBuyerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "chkCreditBuyerBroker")]
        public IWebElement CreditBuyerBroker { get; set; }

        [FindsBy(How = How.Id, Using = "txtCreditBuyerBroker")]
        public IWebElement CreditBuyerBrokerAmt { get; set; }

        [FindsBy(How = How.Id, Using = "chkCreditSellerBroker")]
        public IWebElement CreditSellerBroker { get; set; }

        [FindsBy(How = How.Id, Using = "txtCreditSellerBroker")]
        public IWebElement CreditSellerBrokerAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblBrokerDisbursements")]
        public IWebElement ListingBrokerDisbursements { get; set; }

        [FindsBy(How = How.Id, Using = "lblEarnestMoney")]
        public IWebElement HoldingEarnestMoneyAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblCreditFromOtherBroker")]
        public IWebElement CreditfromOtherBroker { get; set; }

        [FindsBy(How = How.Id, Using = "lblNetCheckAmount")]
        public IWebElement NetCommissionCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "lblHomeWarranty")]
        public IWebElement HomeWarrantyCharges { get; set; }

        [FindsBy(How = How.Id, Using = "idHomeWarranty")]
        public IWebElement HomeWarrantyChargesRow { get; set; }

        [FindsBy(How = How.Id, Using = "cgCC_dcs")]
        public IWebElement CommisionChargeTable { get; set; }

        [FindsBy(How = How.Id, Using = "cgCC_tdHeading")]
        public IWebElement CommisionPaidAtSettlementHeader { get; set; }
        
        [FindsBy(How = How.Id, Using = "cgCC_dcs_0_tdsc")]
        public IWebElement CommisionChargeAmountDescription { get; set; }

        [FindsBy(How = How.Id, Using = "cgCC_dcs_0_tbc")]
        public IWebElement CommisionChargeAmountBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cgCC_dcs_0_tsc")]
        public IWebElement CommisionChargeAmountSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_tdHeading")]
        public IWebElement RealEstateBrokerChargesHeader { get; set; }

        [FindsBy(How = How.Id, Using = "lblBrokerCharges")]
        public IWebElement BrokerChargesAmt { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs")]
        public IWebElement RealEstateBrokerChargesTable { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_0_tdsc")]
        public IWebElement RealEstateBrokerChargesDescription { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_1_tdsc")]
        public IWebElement RealEstateBrokerChargesDescription1 { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_2_tdsc")]
        public IWebElement RealEstateBrokerChargesDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_0_tbc")]
        public IWebElement RealEstateBrokerChargesBuyerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_0_tsc")]
        public IWebElement RealEstateBrokerChargesSellerCharge { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_1_tsc")]
        public IWebElement RealEstateBrokerChargesSellerCharge1 { get; set; }

        [FindsBy(How = How.Id, Using = "cgBC_dcs_2_tsc")]
        public IWebElement RealEstateBrokerChargesSellerCharge2 { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerCommissionAmt")]
        public IWebElement SellerCommissionAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerNetCheckAmt")]
        public IWebElement NetCheckAmt { get; set; }

        [FindsBy(How = How.Id, Using = "Table4")]
        public IWebElement RealEstateBrokerDisbursementsHeaderTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgdDisbSummary")]
        public IWebElement RealEstateBrokerDisbursementsSummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement RealEstateBrokerDisbursementsSummaryNew { get; set; }

        [FindsBy(How = How.Id, Using = "cmdRemove")]
        public IWebElement RealEstateBrokerDisbursementsSummaryDelete { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_cmdAdHoc")]
        public IWebElement RealEstateBrokerDisbursementAdHoc { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_cmdCheckDetails")]
        public IWebElement RealEstateBrokerDisbursementsCheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_txtGABcode")]
        public IWebElement RealEstateBrokerDisbursementsGABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_cmdFindName")]
        public IWebElement RealEstateBrokerDisbursementsbFind { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_txtName")]
        public IWebElement RealEstateBrokerDisbursementsName { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_chkEditContactInfo")]
        public IWebElement RealEstateBrokerDisbursementsEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textBusPhone")]
        public IWebElement RealEstateBrokerDisbursementsBusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_txtExtnPhone")]
        public IWebElement RealEstateBrokerDisbursementsBusinessPhoneExtension { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textBusFax")]
        public IWebElement RealEstateBrokerDisbursementsBusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textCellPhone")]
        public IWebElement RealEstateBrokerDisbursementsCellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textPager")]
        public IWebElement RealEstateBrokerDisbursementsPager { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textEmailAddress")]
        public IWebElement RealEstateBrokerDisbursementsEmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_chkWeeklyEmailStatus")]
        public IWebElement RealEstateBrokerDisbursementsEmailStatus { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_comboAttention")]
        public IWebElement RealEstateBrokerDisbursementsAttention { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_chkEdit")]
        public IWebElement RealEstateBrokerDisbursementsEditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textName")]
        public IWebElement RealEstateBrokerDisbursementsNameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_labelName")]
        public IWebElement RealEstateBrokerDisbursementsNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_comboSalesRep1")]
        public IWebElement RealEstateBrokerDisbursementsSalesRep1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_comboSalesRep2")]
        public IWebElement RealEstateBrokerDisbursementsSalesRep2 { get; set; }

        [FindsBy(How = How.Id, Using = "bpDS_textReference")]
        public IWebElement RealEstateBrokerDisbursementsReference { get; set; }

        [FindsBy(How = How.Id, Using = "txtDisbCheckAmount")]
        public IWebElement RealEstateBrokerDisbursementsCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_imgAdHocFlag")]
        public IWebElement ImageGlobe { get; set; }

        [FindsBy(How = How.Id, Using = "lblHomeWarranty")]
        public IWebElement HomeWarranty { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerNetCheckAmt")]
        public IWebElement NetCheckAmount { get; set; }

        [FindsBy(How = How.Id, Using = "acg_btnPayment")]
        public IWebElement PaymentDetails { get; set; }

        [FindsBy(How = How.LinkText, Using = "BusOrgID: Business Party required")]
        public IWebElement Err1 { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerCommissionAmt")]
        public IWebElement SellerBrokerCommisionAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerCommissionAmt")]
        public IWebElement BuyerBrokerCommisionAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherBrokerCommissionAmt")]
        public IWebElement OtherBrokerCommisionAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalAmt")]
        public IWebElement TotalBrokerCommisionAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerCommissionPct")]
        public IWebElement SellerBrokerCommisionPct { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerCommissionPct")]
        public IWebElement BuyerBrokerCommisionPct { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherBrokerCommissionPct")]
        public IWebElement OtherBrokerCommisionPct { get; set; }

        [FindsBy(How = How.Id, Using = "lblTotalPct")]
        public IWebElement TotalBrokerCommisionPct { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerNetCheckAmt")]
        public IWebElement SellerBrokerCommisionNetCheckAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerNetCheckAmt")]
        public IWebElement BuyerBrokerCommisionNetCheckAmt { get; set; }

        [FindsBy(How = How.Id, Using = "lblOtherBrokerNetCheckAmt")]
        public IWebElement OtherBrokerCommisionNetCheckAmt { get; set; }


                    [FindsBy(How = How.Id, Using = "lblOtherChargesPaidByBroker")]
        public IWebElement OtherChargesPaidByBroker { get; set; }
                            [FindsBy(How = How.Id, Using = "idOtherChargesPaidByBroker")]
        public IWebElement OtherChargesPaidByBrokerRow { get; set; }

        

        [FindsBy(How = How.XPath, Using = "//body/span[@id='__FAFErrorMessageList']/ul/li")]
        public IWebElement MessagePane { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsByAttribute(How = How.XPath, Using = "")]
        public IWebElement SellerBrokerCommisionAmtTitle { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement BuyerBrokerCommisionAmtTitle { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement OtherBrokerCommisionAmtTitle { get; set; }


        [FindsBy(How = How.Id, Using = "Table2")]
        public IWebElement TotalCommissionTable { get; set; }

        [FindsBy(How = How.Id, Using = "imgCheckIssued")]
        public IWebElement IssuedCheckImage { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_cBntExp3")]
        public IWebElement ExpandREBBrokerCredits { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_0_tdsc")]
        public IWebElement REBBrokerCreditsDescription { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_1_tdsc")]
        public IWebElement REBBrokerCreditsDescription2 { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_0_tbd")]
        public IWebElement REBBrokerCreditsBuyerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_1_tbd")]
        public IWebElement REBBrokerCreditsBuyerCredit2 { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_0_tsr")]
        public IWebElement REBBrokerCreditsSellerCredit { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs_1_tsr")]
        public IWebElement REBBrokerCreditsSellerCredit1 { get; set; }

        [FindsBy(How = How.Id, Using = "cgPOC_cBntExp3")]
        public IWebElement ExpandPOCbyBroker { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@id='idCgPOC']/td/table/tbody/tr/td/table/tbody/tr/td[@id='cgPOC_cBntExp3']")]
        public IWebElement ExpandPOCbyBrokerXpath { get; set; }

        [FindsBy(How = How.XPath, Using = "//tr[@id='idCgPOC']/td/table/tbody/tr/td/table/tbody/tr/td/table[@id='cgPOC_dcs']")]
        public IWebElement CommisionChargeTableXpath { get; set; }

        [FindsBy(How = How.Id, Using = "cgPOC_dcs")]
        public IWebElement POCbyBrokerTable { get; set; }

        [FindsBy(How = How.Id, Using = "cgPOC_dcs_0_tdsc")]
        public IWebElement POCbyBrokerDescription { get; set; }

        [FindsBy(How = How.Id, Using = "cgPOC_dcs_0_tbc")]
        public IWebElement POCbyBrokerAmount { get; set; }

        [FindsBy(How = How.Id, Using = "chkErnstMonInExcsOfComisn")]
        public IWebElement CreditSellerEarnestMoneyinexcesscheckbox { get; set; }

        [FindsBy(How = How.Id, Using = "txtExcesOfComisn")]
        public IWebElement CreditSellerEarnestMoneyinexcesstextBox { get; set; }

        [FindsBy(How = How.Id, Using = "chkCreditBuyerBroker")]
        public IWebElement CreditBuyerSellingBrokerCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "txtCreditSellerBroker")]
        public IWebElement CreditBuyerSellingBrokerTextBox { get; set; }

        [FindsBy(How = How.Id, Using = "lblBuyerCredits")]
        public IWebElement BuyerCreditsPane { get; set; }

        [FindsBy(How = How.Id, Using = "idSellerCredit")]
        public IWebElement BuyerCreditsCell { get; set; }

        [FindsBy(How = How.Id, Using = "lblSellerCredits")]
        public IWebElement SellerCreditsPane { get; set; }

        [FindsBy(How = How.Id, Using = "lblCommissionChrgAmt")]
        public IWebElement CommissionChargeAmount { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement BrokerName1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName2")]
        public IWebElement BrokerName2 { get; set; }

        [FindsBy(How = How.Id, Using = "cgBCd_dcs")]
        public IWebElement RealEstateBrokerCreditsTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker_1_labelName")]
        public IWebElement SellerBrokerName { get; set; }

        [FindsBy(How = How.Id, Using = "dgdREBroker_3_labelName")]
        public IWebElement BuyerBrokerName { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNew")]
        public IWebElement BuyerBrokerNew { get; set; }

        [FindsBy(How = How.Id, Using = "cmdEdit")]
        public IWebElement SellerBuyerEdit { get; set; }
        //[FindsBy(How = How.XPath, Using = "//button[@id/='cmdEdit']")]
        //public IWebElement SellerBuyerEdit { get; set; }

        [FindsBy(How = How.Id, Using = "cmdDelete")]
        public IWebElement SellerBuyerRemove { get; set; }

        [FindsBy(How = How.Id, Using = "dgdOtherREBroker_1_labelOtherName")]
        public IWebElement OtherBrokerName { get; set; }
        
        [FindsBy(How = How.Id, Using = "dgdOtherREBroker_1")]
        public IWebElement OtherBrokerNameRow { get; set; }

        [FindsBy(How = How.Id, Using = "bpA_cmdRemoveBusParty")]
        public IWebElement RemoveAgent { get; set; }
        #endregion

        public RealEstateBrokerAgent WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? BrokerInformationGABcode);

            return this;
        }

        public RealEstateBrokerAgent FindGAB(string gabCode = "344", bool waitForElementDisplayed = true)
        {
            this.SwitchToContentFrame();
            this.BrokerInformationGABcode.FASetText(gabCode);
            this.BrokerInformationFind.FAClick();
            if(waitForElementDisplayed)
            {
                Playback.Wait(500);
                //this.WaitCreation(FastDriver.WebDriver.FindElement(By.XPath(@"//span[@id='bpB_labelIdcode' and contains(.,'" + gabCode + "')]")));
                //this.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("span#bpB_labelIdcode:contains('"+gabCode+"')")));
                this.WaitForValue(this.IDCode, gabCode);
            }

            return this;
        }

        public RealEstateBrokerAgent FindAgentGAB(string gabCode = "344", bool waitForElementDisplayed = true)
        {
            this.SwitchToContentFrame();
            this.BrokerContactGABcode.FASetText(gabCode);
            this.BrokerContactFind.Click();
            if(waitForElementDisplayed)
                this.WaitCreation(FastDriver.WebDriver.FindElement(By.XPath(@"//span[@id='bpA_labelIdcode' and contains(.,'" + gabCode + "')]")));
                //this.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("span#bpA_labelIdcode:contains('"+gabCode+"')")));

            return this;
        }

        public RealEstateBrokerAgent FindDisbursementGAB(string gabCode = "344", bool waitForElementDisplayed = true)
        {
            this.WaitForScreenToLoad();
            this.RealEstateBrokerDisbursementsGABcode.FASetText(gabCode);
            this.RealEstateBrokerDisbursementsbFind.Click();
            if(waitForElementDisplayed)
                this.WaitCreation(FastDriver.WebDriver.FindElement(By.XPath(@"//span[@id='bpDS_labelIdcode' and contains(.,'" + gabCode + "')]")));
                //this.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("span#bpDS_labelIdcode:'" + gabCode + "'")));
            
            return this;
        }

        public RealEstateBrokerAgent AddRealEstateBrokerCredits(string chargeDescription, double? buyerCredit = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            
            this.SwitchToContentFrame();           
            IWebElement inputElement;
            if (!FastDriver.RealEstateBrokerAgent.REBBrokerCreditsDescription.IsVisible(3))
                FastDriver.RealEstateBrokerAgent.ExpandREBBrokerCredits.FAClick();
            this.WaitCreation(RealEstateBrokerCreditsTable);
            if (chargeDescription != string.Empty)
            {
                inputElement = RealEstateBrokerCreditsTable.PerformTableAction(RealEstateBrokerCreditsTable.GetRowCount(), 1, TableAction.GetCell).Element.FindElement(By.TagName("input"));
                inputElement.SendKeys(FAKeys.Tab);
                inputElement.FASetText(chargeDescription);
                inputElement.SendKeys(FAKeys.Tab);
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = RealEstateBrokerCreditsTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.GetCell).Element.FindElement(By.TagName("input"));
                inputElement.SendKeys(FAKeys.Tab);
                inputElement.FASetText(buyerCredit.ToString());
                inputElement.SendKeys(FAKeys.Tab);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = RealEstateBrokerCreditsTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.GetCell).Element.FindElement(By.TagName("input"));
                inputElement.SendKeys(FAKeys.Tab);
                inputElement.FASetText(sellerCredit.ToString()+FAKeys.Tab,true,true);
            }
            if (loanEstimate.HasValue)
            {
                inputElement = RealEstateBrokerCreditsTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.GetCell).Element.FindElement(By.TagName("input"));
                inputElement.SendKeys(FAKeys.Tab);
                inputElement.FASetText(loanEstimate.ToString());
                inputElement.SendKeys(FAKeys.Tab);
            }
            return this;
        }
        //
        public RealEstateBrokerAgent AddCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable, 10);
            IWebElement chargeElement;

            if (chargeDescription != string.Empty)
            {
                chargeElement = chargesTable.PerformTableAction(chargesTable.GetRowCount(), 1, TableAction.SetTextByCellIndex, chargeDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (buyerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCharge.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (sellerCredit.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }

            if (loanEstimate.HasValue)
            {
                chargeElement = chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                chargeElement.Click();
                Playback.Wait(250);
            }
            return this;

        }
        //Use this function when multiple rows are to be added in charges table
        public void AddCharge(IWebElement chargesTable,int row, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, double? sellerCredit = null, double? loanEstimate = null, bool GenerateNewRow=false)
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(chargesTable);
                IWebElement chargeElement;

                if (chargeDescription != string.Empty)
                {
                    chargeElement = chargesTable.PerformTableAction(row, 1, TableAction.SetText, chargeDescription+FAKeys.Tab).Element
                        .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                    chargeElement.Click();

                }

                if (buyerCharge.HasValue)
                {
                    chargeElement = chargesTable.PerformTableAction(row, 2, TableAction.SetText, buyerCharge.ToString()).Element
                        .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                    chargeElement.Click();
                }

                if (buyerCredit.HasValue)
                {
                    chargeElement = chargesTable.PerformTableAction(row, 3, TableAction.SetText, buyerCredit.ToString()).Element
                        .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                }

                if (sellerCharge.HasValue)
                {
                    chargeElement = chargesTable.PerformTableAction(row, 4, TableAction.SetText, sellerCharge.ToString()).Element
                        .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");                    

                }

                if (sellerCredit.HasValue)
                {
                    chargeElement = chargesTable.PerformTableAction(row, 5, TableAction.SetText, sellerCredit.ToString()).Element
                        .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                }

                if (loanEstimate.HasValue)
                {
                    chargeElement = chargesTable.PerformTableAction(row, 6, TableAction.SetText, loanEstimate.ToString()).Element
                        .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                }

                if (GenerateNewRow)
                {
                    int RowsBefore = chargesTable.GetRowCount();
                    Playback.Wait(3000);
                    int columns = chargesTable.GetColumnCount();
                    chargesTable.PerformTableAction(1, 1, TableAction.Click);
                    string value = chargesTable.PerformTableAction(row, columns, TableAction.GetInputValue).Message;
                    chargesTable.PerformTableAction(row, columns, TableAction.SetText, value+FAKeys.Tab + FAKeys.Tab);
                    int RowsAfter= chargesTable.GetRowCount();
                    if(RowsAfter-RowsBefore!=1)
                    {
                        IWebElement e = chargesTable.PerformTableAction(row, columns, TableAction.GetCell).Element.FindElement(By.TagName("input"));//FireEvent("onkeydown");
                        e.FADoubleClick();
                        e.FireEvent("onkeydown");
                    }
    
                }
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Error" + ex.Message, false);
            }

        }
        public RealEstateBrokerAgent UpdateCharge(IWebElement chargesTable, string chargeDescription, double? buyerCharge = null, double? buyerCredit = null, double? sellerCharge = null, 
            double? sellerCredit = null, double? loanEstimate = null, double? months = null, double? monthlyCharges = null, string editDescription = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(chargesTable);

            IWebElement inputElement;
            if (editDescription != null)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Description", TableAction.SetText, editDescription).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed);
                inputElement.FireEvent("onblur");
                Playback.Wait(250);
                Keyboard.SendKeys(FAKeys.TabAway);
                Keyboard.SendKeys(FAKeys.TabAway);
                inputElement.Click();
                chargeDescription = editDescription;
            }
            if (months.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Months", TableAction.SetText, months.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (monthlyCharges.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Monthly Charge", TableAction.SetText, monthlyCharges.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Charge", TableAction.SetText, buyerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (buyerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Buyer Credit", TableAction.SetText, buyerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCharge.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Charge", TableAction.SetText, sellerCharge.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (sellerCredit.HasValue)
            {
                inputElement = chargesTable.PerformTableAction("Description", chargeDescription, "Seller Credit", TableAction.SetText, sellerCredit.ToString()).Element
                    .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);
                inputElement.Click();
                Playback.Wait(250);
            }
            if (loanEstimate.HasValue)
            {
                chargesTable.PerformTableAction("Description", chargeDescription, "Loan Estimate Unrounded", TableAction.SetText, loanEstimate.ToString()).Element
                       .FindElements(By.TagName("input")).FirstOrDefault(input => input.Displayed).FireEvent("onblur");
                Playback.Wait(250);

            }

            return this;
        }

        public void NavigateToRealEstateBrokerAgent()
        {
            Reports.TestStep = "Navigate to Real Estate Broker screen";
            FastDriver.LeftNavigation.Navigate<RealEstateBrokerAgent>(@"Home>Order Entry>Real Estate Broker/Agent").WaitForScreenToLoad();
        }
        
        public RealEstateBrokerAgent WaitForElementToLoad(IWebElement Element = null)
        {
            //This is like WaitForScreenToLoad, but works when there's no GAB(for Seller or Buyer)...
            Element = Element ?? BrokerInformationAdHoc;
            WebDriverWait wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(120));
            wait.Until(d =>
            {
                try
                {
                    this.SwitchToContentFrame();
                    return Element.Displayed;
                }
                catch (NoSuchElementException e)
                {
                    return false;
                }
                catch (StaleElementReferenceException e)
                {
                    return false;
                }

            });
            return this;
        }

        public void VerifyAdhocValues(BusOrgAdhocDlgParameters REBAdhoc, bool Countryflag = false)
        {
            Support.AreEqual(GabNameLabel1.FAGetText().Trim(), REBAdhoc.Name1.Trim(), "Verify GabNameLine1");
            Support.AreEqual(GabNameLabel2.FAGetText().Trim(), REBAdhoc.Name2.Trim(), "Verify GabNameLine2");

            if (string.IsNullOrEmpty(REBAdhoc.AddrLine2.Trim()) && string.IsNullOrEmpty(REBAdhoc.AddrLine2.Trim()))
                Support.AreEqualTrim(Addressline1.FAGetText(), "");
            else
                Support.AreEqualTrim(Addressline1.FAGetText(), REBAdhoc.AddrLine1 + ", " + REBAdhoc.AddrLine2);

            if (string.IsNullOrEmpty(REBAdhoc.AddrLine3.Trim()) && string.IsNullOrEmpty(REBAdhoc.AddrLine4.Trim()))
                Support.AreEqualTrim(Addressline2.FAGetText(), "");
            else
                Support.AreEqualTrim(Addressline2.FAGetText(), REBAdhoc.AddrLine3 + ", " + REBAdhoc.AddrLine4);

            if (string.IsNullOrEmpty(REBAdhoc.City.Trim()) && string.IsNullOrEmpty(REBAdhoc.State.Trim()) && !Countryflag)
                Support.AreEqualTrim(Citystate.FAGetText(), "");
            else
                Support.AreEqualTrim(Citystate.FAGetText(), REBAdhoc.City + ", " + REBAdhoc.State + ", " + REBAdhoc.Zip + ", " + REBAdhoc.Country);
        }
        //
        public string[] AddNewRealEstateBrokerDisbursement(string GABCode, string CheckAmount)
        {
            string Status = "Fail";
            string REBDisbursementName = "";
            try
            {
                this.WaitForScreenToLoad();
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryNew.FAClick();
                this.WaitCreation(RealEstateBrokerDisbursementsGABcode, true);
                FastDriver.RealEstateBrokerAgent.FindDisbursementGAB(GABCode);
                FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FASetText(CheckAmount+FAKeys.Tab);
                REBDisbursementName = FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsNameLabel.FAGetText();
                if (!string.IsNullOrEmpty(REBDisbursementName))
                    Status = FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction("Name", REBDisbursementName, "Check Amt.", TableAction.Click, "$ " + CheckAmount).Status.ToString();

                return new[]{Status,REBDisbursementName};
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Unable to add new REB disbursement "+ex.Message, false);
                return new[] { Status, REBDisbursementName };
            }
        }

        public RealEstateBrokerAgentSummary.StructDeletionResult DeleteThirdPartyDisbursementEntry(string REBDisbursementName,string Message="")
        {
            RealEstateBrokerAgentSummary.StructDeletionResult DelResult = new RealEstateBrokerAgentSummary.StructDeletionResult();
            string Status = "Fail";
            try
            {
                this.SwitchToContentFrame();
                int RowCountBeforeDeletion = FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.GetRowCount();
                if (!string.IsNullOrEmpty(REBDisbursementName))
                    Status = FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.PerformTableAction("Name", REBDisbursementName, "Name", TableAction.Click).Status.ToString();
                if(Status=="Success")
                {
                    FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryDelete.Click();
                    if (!string.IsNullOrEmpty(Message))
                    {
                        DelResult.isErrorWarningCorrect = ValidateErrorWarningMessageInPopUp(Message);
                    }
                    else FastDriver.WebDriver.HandleDialogMessage();
                }
                else
                {
                    Reports.StatusUpdate("REB disbursement to be deleted doesnt exist", false);
                    DelResult.Status = "Fail";
                    DelResult.isErrorWarningCorrect = false;
                }
                FastDriver.RealEstateBrokerAgent.WaitForScreenToLoad();
                int RowCountAfterDeletion = FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsSummaryTable.GetRowCount();
                if(RowCountBeforeDeletion-RowCountAfterDeletion==1)
                    DelResult.Status = "Success";
                else
                    DelResult.Status = "Fail";

                return DelResult;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Unable to delete REB disbursement " + ex.Message, false);
                return DelResult;
            }
        }
        //   
        public RealEstateBrokerAgentSummary CancelREBInstance(string WarningMessage="")
        {
            try
            {
                Reports.TestStep = "Cancel REB instance";
                FastDriver.BottomFrame.Cancel();
                //
                Reports.TestStep = "Validate warning message and Click on Ok button.";
                if (!string.IsNullOrEmpty(WarningMessage))
                Support.AreEqual(WarningMessage, FastDriver.WebDriver.HandleDialogMessage());
                FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
                //
                Reports.TestStep = "To validate that Real Estate Broker/Agent Summary screen is loaded.";
                return FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
            }
            catch
            {
                throw;
            }
        }
        //
        public string ResetREBInstance(string WarningMessage="")
        {
            FastDriver.BottomFrame.SwitchToBottomFrame();
            Reports.TestStep = "Reset REB instance";
            FastDriver.BottomFrame.Reset();
            //
            Reports.TestStep = "Validate warning message and Click on Ok button.";
            if (!string.IsNullOrEmpty(WarningMessage))
            Support.AreEqual(WarningMessage, FastDriver.WebDriver.HandleDialogMessage());
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            //
            Reports.TestStep = "Get Real Estate Broker/Agent GAB is loaded after reset.";
            return    FastDriver.RealEstateBrokerAgent.GabNameLabel1.FAGetText() +" "+ FastDriver.RealEstateBrokerAgent.GabNameLabel2.FAGetText();
        }
        //
        public bool ValidateErrorWarningMessageInPopUp(string ExpectedMessage)
        {
            string Message = FastDriver.WebDriver.HandleDialogMessage(false);
            return ExpectedMessage.Trim().Equals(Message);
        }
        //
        public bool ValidateErrorWarningMessageInMessagePane(string ExpectedMessage)
        {
            
            FastDriver.RealEstateBrokerAgent.SwitchToContentFrame();
            Reports.TestStep = "Validate warning message";
            string Message = FastDriver.RealEstateBrokerAgent.MessagePane.FAGetText();
            return Message.Trim().Contains(ExpectedMessage);
        }
        //
        public Dictionary<string, string> GetBrokerAddress()
        {
            
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            Reports.TestStep = "Get broker address IIS";
            try
            {
                this.SwitchToContentFrame();

                //
                string[] AddressLines = string.IsNullOrWhiteSpace(Addressline1.FAGetText()) ? new string[2] { "", "" } : Addressline1.FAGetText().Split(',');
                AllDetails.Add("AddressLine1", string.IsNullOrWhiteSpace(AddressLines[0]) ? "" : AddressLines[0].Trim());
                AllDetails.Add("AddressLine2", string.IsNullOrWhiteSpace(AddressLines[1]) ? "" : AddressLines[1].Trim());
                //
                AddressLines = string.IsNullOrWhiteSpace(Addressline2.FAGetText()) ? new string[2] { "", "" } : Addressline2.FAGetText().Split(',');
                AllDetails.Add("AddressLine3", string.IsNullOrWhiteSpace(AddressLines[0].Trim()) ? "" : AddressLines[0].Trim());
                AllDetails.Add("AddressLine4", string.IsNullOrWhiteSpace(AddressLines[1].Trim()) ? "" : AddressLines[1].Trim());
                //
                AddressLines = string.IsNullOrWhiteSpace(Citystate.FAGetText()) ? new string[4] { "", "", "", "" } : Citystate.FAGetText().Split(',');
                AllDetails.Add("County", string.IsNullOrWhiteSpace(AddressLines[0].Trim()) ? "" : AddressLines[0].Trim());
                //AllDetails.Add("City", City.FAGetValue());
                AllDetails.Add("State", string.IsNullOrWhiteSpace(AddressLines[1].Trim()) ? "" : AddressLines[1].Trim());
                AllDetails.Add("Zip", string.IsNullOrWhiteSpace(AddressLines[2].Trim()) ? "" : AddressLines[2].Trim());
                AllDetails.Add("Country", string.IsNullOrWhiteSpace(AddressLines[3].Trim()) ? "" : AddressLines[3].Trim());
            }

            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            //
            return AllDetails;
        }
        //
        public Dictionary<string, string> GetBrokerContactAddress()
        {
            
            this.SwitchToContentFrame();
            Reports.TestStep = "Get broker contact address IIS";
            Dictionary<string, string> AllDetails = new Dictionary<string, string>();
            //
            string[] AddressLines = string.IsNullOrEmpty(ContactAddressline1.FAGetText()) ? new string[2] { "", "" } : ContactAddressline1.FAGetText().Split(',');
            AllDetails.Add("AddressLine1", string.IsNullOrEmpty(AddressLines[0].Trim()) ? "" : AddressLines[0].Trim());
            AllDetails.Add("AddressLine2", string.IsNullOrEmpty(AddressLines[1].Trim()) ? "" : AddressLines[0].Trim());
            //
            AddressLines = string.IsNullOrEmpty(ContactAddressline2.FAGetText()) ? new string[2] { "", "" } : ContactAddressline2.FAGetText().Split(',');
            AllDetails.Add("AddressLine3", string.IsNullOrEmpty(AddressLines[0].Trim()) ? "" : AddressLines[0].Trim());
            AllDetails.Add("AddressLine4", string.IsNullOrEmpty(AddressLines[1].Trim()) ? "" : AddressLines[0].Trim());
            //
            AddressLines = string.IsNullOrEmpty(ContactAddressline3.FAGetText()) ? new string[4] { "", "", "", "" } : ContactAddressline3.FAGetText().Split(',');
            AllDetails.Add("County", string.IsNullOrEmpty(AddressLines[0].Trim()) ? "" : AddressLines[0].Trim());
            //AllDetails.Add("City", City.FAGetValue());
            AllDetails.Add("State", string.IsNullOrEmpty(AddressLines[1].Trim()) ? "" : AddressLines[1].Trim());
            AllDetails.Add("Zip", string.IsNullOrEmpty(AddressLines[2].Trim()) ? "" : AddressLines[2].Trim());
            AllDetails.Add("Country", string.IsNullOrEmpty(AddressLines[3].Trim()) ? "" : AddressLines[3].Trim());
            //
            return AllDetails;
        }
        //
        public bool CheckPaymentDetailsButton(IWebElement ParentPaymentDetails)
        {
            bool result = true;
            try
            {
                IWebElement elemnt = ParentPaymentDetails.FindElements(By.TagName("button")).FirstOrDefault(p => p.FAGetText().Clean() == "Payment Details");
                result = elemnt.Exists();
            }
            catch (NullReferenceException)
            {
                Reports.StatusUpdate("Payment Details button does not exist", true);
                result = false;
            }
            return result;
        }

        /// <summary>
        /// this Function returns the full name of the broker GAB id entered.
        /// </summary>
        public string GetBrokerFullName
        {
            get
            {
                string brokerFullName=(this.GabNameLabel1.FAGetText().Trim()+" "+this.GabNameLabel2.FAGetText().Trim()).Trim();
                return brokerFullName;
            }
        }
        //
        //


    }
}