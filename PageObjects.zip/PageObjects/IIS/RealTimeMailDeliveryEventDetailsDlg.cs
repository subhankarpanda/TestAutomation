using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class RealTimeMailDeliveryEventDetailsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_FAFDataGrid1")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_lblRTMPackageStatus")]
		public IWebElement RTMPackageStatus { get; set; }

		[FindsBy(How = How.Id, Using = "FAFDataGrid1_0_lblDocName")]
		public IWebElement RTMPackageDocuments { get; set; }

		#endregion

	}
}
