using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class RealTimeMailDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "imgDocument")]
		public IWebElement ImageDocument { get; set; }

		[FindsBy(How = How.Id, Using = "pubDocument")]
		public IWebElement PublishDocument { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "btnMail")]
		public IWebElement Deliver { get; set; }

		#endregion

        public RealTimeMailDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Deliver);

            return this;
        }

	}
}
