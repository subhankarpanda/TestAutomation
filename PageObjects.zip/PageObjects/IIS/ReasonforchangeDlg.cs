using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
	public class ReasonforchangeDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cboReason")]
		public IWebElement Change { get; set; }

        [FindsBy(How = How.XPath, Using = "\\html")]
        public IWebElement ContentTable { get; set; }

		[FindsBy(How = How.Id, Using = "txtReason")]
		public IWebElement Reason { get; set; }

		[FindsBy(How = How.Id, Using = "cmdOk")]
		public IWebElement OK { get; set; }

		[FindsBy(How = How.Id, Using = "cmdCancel")]
		public IWebElement Cancel { get; set; }

		#endregion

        #region Services

        ///<summary>
        ///Enters fields
        ///<!summary>
        public ReasonforchangeDlg SetFields(string ChangeVal, string ReasonVal)
        {
            
            this.Change.FASelectItem(ChangeVal);
            this.Change.FireEvent("onchange");
            
            if (!this.Reason.IsDisplayed())
            {
                Playback.Wait(3000);
            }
            this.Reason.FASetText(ReasonVal);
            return this;
        }

        public ReasonforchangeDlg ClickOk()
        {
            this.OK.FAClick();
            Playback.Wait(2000);
            return this;
        }
        public ReasonforchangeDlg WaitForDialogToLoad(IWebElement Element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Reason for Change", timeoutSeconds: 60);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Element ?? Change);

            return this;
        }
        #endregion
    }
}
