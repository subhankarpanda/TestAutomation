using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ReceiptAdjustmentDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgRF")]
		public IWebElement RASearchResults { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtAmount")]
		public IWebElement Amount { get; set; }

		#endregion

        #region Useful Methods
        public ReceiptAdjustmentDlg WaitForScreenToLoad(string windowName = "Receipt Adjustment")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(Amount, 5);
            return this;
        }
        #endregion
    }
}
