using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class ReceiptToFile : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "lblType")]
		public IWebElement Type { get; set; }

		[FindsBy(How = How.Id, Using = "lblAmount")]
		public IWebElement Amount { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtAmount")]
		public IWebElement FileAmount { get; set; }

		[FindsBy(How = How.Id, Using = "lblConfirmRef")]
		public IWebElement Conf { get; set; }

		[FindsBy(How = How.Id, Using = "lblIssueDate")]
		public IWebElement IssueDate { get; set; }

		[FindsBy(How = How.Id, Using = "lblOriginator")]
		public IWebElement Originator { get; set; }

		[FindsBy(How = How.Id, Using = "lblSendingBank")]
		public IWebElement SendingBank { get; set; }

		[FindsBy(How = How.Id, Using = "lblOBI")]
		public IWebElement OBI { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ReceiptFiles { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddFile")]
		public IWebElement AddFile { get; set; }

		[FindsBy(How = How.Id, Using = "btnRemoveFile")]
		public IWebElement RemoveFile { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_dgRF")]
		public IWebElement ReceiptTable { get; set; }

        [FindsBy(How = How.XPath, Using = "//table[@name='dgRF_dgRF']//table")]
        public IWebElement ReceiptTableHeader { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtBUID")]
		public IWebElement BUID { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtFileNum")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_chkMR")]
		public IWebElement MR { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtReceiptNum")]
		public IWebElement ReceiptNumber { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_ddlCstType")]
		public IWebElement ReceivedFrom { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtPayor")]
		public IWebElement Payor { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_ddlCreditTo")]
		public IWebElement ForCreditOf { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_ddlRepresenting")]
		public IWebElement Representing { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtDescription")]
		public IWebElement Description { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_0_txtAmount")]
		public IWebElement AmountEdit { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_txtFileNum")]
		public IWebElement FileNumber1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_ddlCstType")]
		public IWebElement ReceivedFrom1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_txtPayor")]
		public IWebElement Payor1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_ddlCreditTo")]
		public IWebElement ForCreditOf1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_ddlRepresenting")]
		public IWebElement Representing1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_txtDescription")]
		public IWebElement Description1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgRF_1_txtAmount")]
		public IWebElement AmountEdit1 { get; set; }

		#endregion

        #region Useful Methods
        public ReceiptToFile WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(AddFile);
            return this;
        }
        #endregion
    }
}
