using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using SeleniumInternalHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace FASTSelenium.PageObjects.IIS
{
	public class RecordedDocsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdRefresh")]
		public IWebElement Refresh { get; set; }

		[FindsBy(How = How.Id, Using = "cboState")]
		public IWebElement State { get; set; }

		[FindsBy(How = How.Id, Using = "cboCounty")]
		public IWebElement County { get; set; }

		[FindsBy(How = How.Id, Using = "cmdScan")]
		public IWebElement Scan { get; set; }

		[FindsBy(How = How.Id, Using = "cmdAdd")]
		public IWebElement Add { get; set; }

		[FindsBy(How = How.Id, Using = "cmdSubmit")]
		public IWebElement Submit { get; set; }

		[FindsBy(How = How.Id, Using = "gdRecordedDocs_0_chkSelect")]
		public IWebElement gdRecordedDocs0Select { get; set; }

		[FindsBy(How = How.Id, Using = "gdRecordedDocs_1_chkSelect")]
		public IWebElement gdRecordedDocs1Select { get; set; }

        [FindsBy(How = How.Id, Using = "gdRecordedDocs_gdRecordedDocs")]
		public IWebElement Recordedcostable { get; set; }

        #region Services


        public RecordedDocsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Submit);

            return this;
        }


        public RecordedDocsDlg EnterRecordingInformation()
        {
            try
            {
                WebDriver.WaitForWindowAndSwitch("Recorded Docs", true, 60);
                this.SwitchToDialogContentFrame();
                this.WaitCreation(Refresh);
                County.FASelectItemBySendingKeys("O");  // for Orange
                // FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //WebDriver.SwitchToWindow("Recorded Docs");
                //this.SwitchToDialogContentFrame();
                int row = FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, "Assessment Map", 1, TableAction.DoubleClick).CurrentRow + 1;
                FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(row, 5, TableAction.SetText, "45");
                FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(row, 7, TableAction.SetText, "7");
                Add.FAClick();
                //Adding for Assessor Map
                //int row1 = FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, "Assessor Map", 1, TableAction.DoubleClick).CurrentRow + 1;
                //FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(row1, 5, TableAction.SetText, "40");
                //FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(row1, 7, TableAction.SetText, "5");

                //Add.FAClick();
                Submit.FAClick();
                //FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                //WebDriver.SwitchToWindow("Recorded Docs");

                var watch = Stopwatch.StartNew();
                while (watch.ElapsedMilliseconds <= 120 * 1000) // 120 Seconds
                {
                    this.SwitchToDialogContentFrame();
                    Refresh.FAClick();
                    Playback.Wait(1000);
                    string strVal = FastDriver.RecordedDocsDlg.Recordedcostable.PerformTableAction(1, 13, TableAction.GetText).Message.Trim();

                    if (strVal == "Completed")
                    {
                        break;
                    }

                    else if (strVal == "Request Failed, Please try again")
                    {
                        Submit.FAClick();

                    }

                }
                watch.Stop();

                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Refreshing Documents...", false);

                return this;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion


        #endregion

    }
}
