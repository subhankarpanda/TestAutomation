using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class RecordFeeTransferTaxDisb : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "cmdNw")]
        public IWebElement New { get; set; }

        [FindsBy(How = How.Id, Using = "cmdRmv")]
        public IWebElement Remove { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_cmdCheckDetails")]
        public IWebElement CheckDetails { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_txtGABcode")]
        public IWebElement GABcode { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_cmdFindName")]
        public IWebElement Find { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelIdcode")]
        public IWebElement GABLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelName")]
        public IWebElement NameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_txtName")]
        public IWebElement Name { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_labelAddress")]
        public IWebElement AddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_chkEditContactInfo")]
        public IWebElement Edit { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textBusPhone")]
        public IWebElement BusinessPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textBusFax")]
        public IWebElement BusinessFax { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textCellPhone")]
        public IWebElement CellPhone { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textPager")]
        public IWebElement Pager { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textEmailAddress")]
        public IWebElement EmailAddress { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_chkWeeklyEmailStatus")]
        public IWebElement StatusEmail { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_comboAttention")]
        public IWebElement Attention { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_chkEdit")]
        public IWebElement EditName { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textName")]
        public IWebElement NameEdit { get; set; }

        [FindsBy(How = How.Id, Using = "bpP_textReference")]
        public IWebElement Reference { get; set; }

        [FindsBy(How = How.Id, Using = "txtChkAmt")]
        public IWebElement Amount { get; set; }

        [FindsBy(How = How.Id, Using = "rdAll")]
        public IWebElement All { get; set; }

        [FindsBy(How = How.Id, Using = "rdNone")]
        public IWebElement None { get; set; }

        [FindsBy(How = How.Id, Using = "btnFeeAddress")]
        public IWebElement AddressDetails { get; set; }

        [FindsBy(How = How.Id, Using = "dgridPayee")]
        public IWebElement PayeeSummary { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees")]
        public IWebElement ChargeSelection { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees_0_chkSelected")]
        public IWebElement FirstCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees_1_chkSelected")]
        public IWebElement SecondCheckBox { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees_0_lblFeeDesc")]
        public IWebElement DescCharge { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees_0_lblTChrg")]
        public IWebElement TotalChargeDisbr { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees_0_lblBChrg")]
        public IWebElement BuyerChargeDisbr { get; set; }

        [FindsBy(How = How.Id, Using = "dgrFees_0_lblSChrg")]
        public IWebElement SellerChargeDisbr { get; set; }


        #endregion

        public RecordFeeTransferTaxDisb WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GABcode);

            return this;
        }
    }
}
