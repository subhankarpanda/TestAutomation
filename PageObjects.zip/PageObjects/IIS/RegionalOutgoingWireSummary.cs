﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class RegionalOutgoingWireSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "IssueDateFrom")]
        public IWebElement IssueDateFrom { get; set; }

        [FindsBy(How = How.Id, Using = "IssueDateTo")]
        public IWebElement IssueDateTo { get; set; }

        [FindsBy(How = How.Id, Using = "AmountFrom")]
        public IWebElement AmountFrom { get; set; }

        [FindsBy(How = How.Id, Using = "AmountTo")]
        public IWebElement AmountTo { get; set; }

        [FindsBy(How = How.Id, Using = "StatusCombo")]
        public IWebElement Status { get; set; }

        [FindsBy(How = How.Id, Using = "cmdFindNow")]
        public IWebElement FindNow { get; set; }

        [FindsBy(How = How.Id, Using = "cmdNewSearch")]
        public IWebElement NewSearch { get; set; }

        [FindsBy(How = How.Id, Using = "dgWireSummary_dgWireSummary")]
        public IWebElement OutGoingWireTable { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        #endregion

        public RegionalOutgoingWireSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? Status);
            return this;
        }
    }
}
