using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class RenameDocDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtFileNo")]
		public IWebElement FileNo { get; set; }

		[FindsBy(How = How.Id, Using = "txtEditDocName")]
		public IWebElement EditDocName { get; set; }

		[FindsBy(How = How.Id, Using = "chkChgType")]
		public IWebElement ChangeDocumentType { get; set; }

		[FindsBy(How = How.Id, Using = "chkCrtCpy")]
		public IWebElement CreateaCopy { get; set; }

		[FindsBy(How = How.Id, Using = "cboDocumentType")]
		public IWebElement cboDocumentType { get; set; }

		[FindsBy(How = How.Id, Using = "cboDocumentName")]
		public IWebElement cboDocumentName { get; set; }

		[FindsBy(How = How.Id, Using = "txtAddInformation")]
		public IWebElement AddInformation { get; set; }

		[FindsBy(How = How.Id, Using = "txtDocumentName")]
		public IWebElement EditDocumentName { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		#endregion

        public RenameDocDlg WaitForScreenToLoad(string windowName = "Edit Document")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(EditDocName);

            return this;
        }
	}
    
}
