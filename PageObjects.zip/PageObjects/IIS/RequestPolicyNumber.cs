using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using System.Linq;

namespace FASTSelenium.PageObjects.IIS
{
	public class RequestPolicyNumber : PageObject
	{
        #region WebElements

        [FindsBy(How = How.Id, Using = "ddlAgentFirms")]
        public IWebElement Firm { get; set; }

        [FindsBy(How = How.Id, Using = "ddlUnderwriters")]
		public IWebElement Underwriter { get; set; }

		[FindsBy(How = How.Id, Using = "btnRequestPolicyNumber")]
		public IWebElement RequestNumber { get; set; }

		[FindsBy(How = How.Id, Using = "btnAddProduct")]
		public IWebElement AddProduct { get; set; }

		[FindsBy(How = How.Id, Using = "btnVoidPolicyNumber")]
		public IWebElement VoidNumber { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_grdPolicyNumber")]
		public IWebElement Table { get; set; }

		[FindsBy(How = How.LinkText, Using = "grdPolicyNumber_grdPolicyNumber")]
		public IWebElement RPNtable { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_lblFASTProductName")]
		public IWebElement PolicyName { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_1_lblFASTProductName")]
		public IWebElement PolicyName1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_lblStatus")]
		public IWebElement Status { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_lblPolicyNumber")]
		public IWebElement PolicyNumbers { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_lblFeeDesc")]
		public IWebElement FeeDescription { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_lblAgentNetJacketType")]
		public IWebElement AgentNetProduct { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_lblFeeAmount")]
		public IWebElement Amount { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_btnSelectProduct")]
		public IWebElement SelProduct { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_1_lblPolicyNumber")]
		public IWebElement PolicyNumbers_2 { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_0_btnFees")]
		public IWebElement SelFees { get; set; }

		[FindsBy(How = How.Id, Using = "grdPolicyNumber_1_lblStatus")]
		public IWebElement Status_2 { get; set; }

		[FindsBy(How = How.Id, Using = "ddlAgentOffices")]
		public IWebElement AgentOffices { get; set; }

		#endregion
        public RequestPolicyNumber Open()
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.RequestPolicyNumber>("Home>Order Entry>Request Policy Number");
            this.WaitForScreenToLoad();
            return this;
        }

        public bool CanNavigateTo() {
           
            try
            {
                FastDriver.LeftNavigation.Navigate<RequestPolicyNumber>("Home>Order Entry");
                return FastDriver.LeftNavigation.RequestPolicyNumber.IsDisplayed();
            }
            catch (Exception) {
                return false;
            }


        }

        public void ClickOnDuplicatedProduct(string fastProductName)
        {
            FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + fastProductName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();
                FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdPolicyNumber_" + (Int32.Parse(id[1]) + 1) + "_lblFASTProductName").FAClick();
            }
            catch (Exception){}
        }

        public string ClickOnProductInstance(string product, int instanceNum = 1)
        {
            if (Table.FAGetText().Contains(product))
            {
                try
                {
                    Table.FAFindElements(ByLocator.TagName, "tr").Where(i => i.Text.Contains(product)).ElementAt(instanceNum - 1).FAClick();
                    return "Action succeded.";
                }
                catch (Exception e)
                {
                    return "Error: " + e.Message;
                }
            }
            else
            {
                return "Product not found.";
            }
        }

        public string GetProductInstancePolicyNumber(string fastProductName)
        {
            FastDriver.RequestPolicyNumber.WaitForScreenToLoad();
            try
            {
                IWebElement element = FastDriver.WebDriver.FAFindElement(ByLocator.XPath, @"//span[.='" + fastProductName + @"']");
                var id = element.FAGetAttribute("id").Split('_').ToList();
                return FastDriver.WebDriver.FAFindElement(ByLocator.Id, "grdPolicyNumber_" + (Int32.Parse(id[1]) + 1) + "_lblPolicyNumber").FAGetText().Clean();
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        public RequestPolicyNumber WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(Table);
            return this;
        }
    }
}
