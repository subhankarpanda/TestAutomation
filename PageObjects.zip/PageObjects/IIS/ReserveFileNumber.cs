using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ReserveFileNumber : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "btnFind")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "btnReserveNew")]
		public IWebElement ReserveNew { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "txtFileNumber")]
		public IWebElement FileNumber { get; set; }

		[FindsBy(How = How.Id, Using = "dgFAFResult")]
		public IWebElement FindSummary { get; set; }

		#endregion

        public ReserveFileNumber WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? ReserveNew);
            return this;
        }
        //
        public ReserveFileNumber Open()
        {
            FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Reserve File Num");
            FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
            this.WaitForScreenToLoad();
            return this;
        }
        public void ClickReserveNew()
        {
            this.ReserveNew.FAClick();
        }

        public void EnterFileNumAndClickFind(string FileNum)
        {
            this.FileNumber.FASetText(FileNum);
            this.Find.FAClick();

        }

        public ReserveFileNumber SearchResultTable(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int StartingRowNum = 1)
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(FindSummary);
                FindSummary.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

                return this;
            }
            catch (StaleElementReferenceException) //Try again if get stale element reference exception
            {
                this.SwitchToContentFrame();
                this.WaitCreation(FindSummary);
                FindSummary.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);

                return this;
            }
        }

        //
        public string ReserveNewFileNumber(string comment)
        {
            this.WaitForScreenToLoad();
            ClickReserveNew();
            Thread.Sleep(5000);
            FastDriver.ReserveFileDlg.AddComment(comment);
            FastDriver.DialogBottomFrame.ClickDone();
            Thread.Sleep(3000);
            string Message=FastDriver.WebDriver.HandleDialogMessage();
            string[] FileNum = Message.Split('=');
            this.WaitForScreenToLoad();
            return FileNum[1].Trim();
        }
	}
}
