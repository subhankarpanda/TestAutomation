using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{

    public class ReserveFileDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement txtComments { get; set; }
        #endregion

        public ReserveFileDlg AddComment(string comment)
        {
            WebDriver.WaitForWindowAndSwitch("File Number Reservation");
            this.SwitchToDialogContentFrame();
            this.WaitCreation(txtComments);
            this.txtComments.FASetText(comment);
            

            return this;
        }
    }

}
