using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTSelenium.PageObjects.IIS
{
    public class RetaininQDeleteDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "Retain")]
        public IWebElement RetainInQueue { get; set; }

        [FindsBy(How = How.Id, Using = "Delete")]
        public IWebElement Delete { get; set; }

        [FindsBy(How = How.Id, Using = "Table1")]
        public IWebElement RetainInQueueAlertMsg { get; set; }

        //TODO: ADD FindsByAttribute
        public IWebElement Text { get; set; }

        #endregion
                
        public bool RetainInQueueExists()
        {
            try
            {
                this.SwitchToDialogContentFrame(switchToFraPageWin: false);
                this.WaitCreation(RetainInQueue);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool CheckIfTheAlertMessageIsAsIntended()
        {
            try
            {
                this.SwitchToDialogContentFrame(switchToFraPageWin: false);
                var alertText = RetainInQueueAlertMsg.PerformTableAction(1, 1, TableAction.GetText).Message;
                if (alertText.Contains("have not attached the current document to a file. What would you like to do"))
                {
                    Reports.StatusUpdate("Pop-up message is as expected ! ", true);
                    return true;
                }
                else
                {
                    Reports.StatusUpdate("Pop-up message is not as expected ! ", false);
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public void WorkQMessageHandler(bool clickRetain)
        {
            try
            {
                this.SwitchToDialogContentFrame(switchToFraPageWin: false);
                if (clickRetain)
                {
                    this.WaitCreation(RetainInQueue);
                    RetainInQueue.Highlight();
                    RetainInQueue.FAClick();
                }
                else
                {
                    this.WaitCreation(Delete);
                    Delete.FAClick();
                }
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                Support.CloseAllProcessStartingWith("AcroRd");
            }
            catch (Exception)
            {
                Reports.StatusUpdate("WorkQueue window not present, skipping", true);
            }
            //WebDriver.SwitchToWindow(Support.FASTWindowName);
        }
    }
}
