using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class ReturnWire : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtReasonOfReturn")]
		public IWebElement ReasonOfReturn { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Amount { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement IssueDate { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement SendingBank { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement ConfNo { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement Originator { get; set; }

		//TODO: ADD FindsByAttribute
		public IWebElement OBI { get; set; }

		[FindsBy(How = How.Id, Using = "lblIssueDate")]
		public IWebElement DateData { get; set; }

		[FindsBy(How = How.Id, Using = "lblAmount")]
		public IWebElement AmtData { get; set; }

		[FindsBy(How = How.Id, Using = "lblSendingBank")]
		public IWebElement BankData { get; set; }

		[FindsBy(How = How.Id, Using = "lblOriginator")]
		public IWebElement OriginData { get; set; }

		[FindsBy(How = How.Id, Using = "lblOBI")]
		public IWebElement OBIData { get; set; }

		[FindsBy(How = How.Id, Using = "lblAmount")]
		public IWebElement AmtData1 { get; set; }

		#endregion

        #region
        public ReturnWire WaitForScreenToLoad()
        {
            this.SwitchToContentFrame();
            this.WaitCreation(ReasonOfReturn);
            return this;
        }
        #endregion

    }
}
