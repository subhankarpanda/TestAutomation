using FASTSelenium.Common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;


namespace FASTSelenium.PageObjects.IIS
{
    public class SDNTrackingSummary : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dgridHit")]
        public IWebElement SDNHitTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridNoHit")]
        public IWebElement SDNNoHitTable { get; set; }

        [FindsBy(How = How.Id, Using = "FAFDataGrid1")]
        public IWebElement SdnInProgressTable { get; set; }

        [FindsBy(How = How.Id, Using = "qa_3")]
        public IWebElement ExpandSDNHit { get; set; }

        [FindsBy(How = How.Id, Using = "Td1")]
        public IWebElement ExpandSDNNoHit { get; set; }

        [FindsBy(How = How.Id, Using = "Td3")]
        public IWebElement ExpandSearchInProgress { get; set; }

        [FindsBy(How = How.XPath, Using = "//span[contains(text(),'bin laden')]")]
        public IWebElement BinLaden { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHeader")]
        public IWebElement SDNTable { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHit_0_lblHitDocUplCleared")]
        public IWebElement SDNCleared { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHit_1_lblHitDocUplCleared")]
        public IWebElement SDNCleared1 { get; set; }
        
        [FindsBy(How = How.Id, Using = "dgridHit_0_lblSDNReferenceNumber")]
        public IWebElement SDNReferenceNumber { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHit_1_lblSDNReferenceNumber")]
        public IWebElement SDNReferenceNumber1 { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHit_0_lblHitName")]
        public IWebElement HitName { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHit_0_lblHitRoleAssociation")]
        public IWebElement HitRoleAssociation { get; set; }

        [FindsBy(How = How.Id, Using = "dgridHit_0_lblHitSearched")]
        public IWebElement HitSearched { get; set; } 

        #endregion

        public SDNTrackingSummary Open()
        {
            FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>("Home>Order Entry>SDN Tracking Summary");
            this.WaitForScreenToLoad();

            return this;
        }

        public SDNTrackingSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? ExpandSearchInProgress);
            return this;
        }

        public void WaitForSDNSearchComplete(int timeoutSeconds)
        {
            int i = 0;

            do
            {
                FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();

                if (FastDriver.SDNTrackingSummary.SdnInProgressTable.GetRowCount() == 1)
                {
                    break;
                }
                else
                {
                    i = i + 5;
                    Playback.Wait(5000);
                }
            } while (i <= timeoutSeconds);
        }
        public void ValidateNamesInSDNScreen(string name)
        {
            int rows = this.SDNNoHitTable.GetRowCount();
            for (int i = 1; i <= rows; i++)
            {
                string NohitNameTable = FastDriver.SDNTrackingSummary.SDNNoHitTable.FAGetText();
                if (NohitNameTable.Contains(name))
                {
                    Reports.StatusUpdate("The name: " + name + " exists in SDN tracking summary screen.", true);
                    break;
                }
                else
                {
                    if (i == rows)
                        Reports.StatusUpdate("The name: " + name + " doesn't exist in SDN tracking summary screen.", false);
                }
            }

        }

        public void ValidateNamesInSearchProgress(string name)
        {
            int rows = this.SdnInProgressTable.GetRowCount();
            for (int i = 1; i <= rows; i++)
            {
                string SdnInProgressNameTable = FastDriver.SDNTrackingSummary.SdnInProgressTable.FAGetText();
                if (SdnInProgressNameTable.Contains(name))
                {
                    Reports.StatusUpdate("The name: " + name + " exists in InProgress Table of SDN tracking summary screen.", true);
                    break;
                }
                else
                {
                    if (i == rows)
                        Reports.StatusUpdate("The name: " + name + " doesn't exist in InProgress Table of SDN tracking summary screen.", false);
                }
            }

        }

        public void ValidateNamesInHit(string name)
        {
            int rows = this.SDNHitTable.GetRowCount();
            for (int i = 1; i <= rows; i++)
            {
                string SdnInHitNameTable = FastDriver.SDNTrackingSummary.SDNHitTable.FAGetText();
                if (SdnInHitNameTable.Contains(name))
                {
                    Reports.StatusUpdate("The name: " + name + " exists in Hit Table of SDN tracking summary screen.", true);
                    break;
                }
                else
                {
                    if (i == rows)
                        Reports.StatusUpdate("The name: " + name + " doesn't exist in Hit Table of SDN tracking summary screen.", false);
                }
            }

        }

        public void ValidateDate(IWebElement TableName, string Name, int ColumnForDate)
        {
            string todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time").ToString("MM/dd/yyyy");
            int Count = TableName.GetRowCount();
            for (int i = 1; i <= Count; i++)
            {
                if (TableName.PerformTableAction(2, Name, i, TableAction.GetText).Message.Clean().Contains(Name).ToString() == "True")
                {
                    string DateForName = TableName.PerformTableAction(2, Name, ColumnForDate, TableAction.GetText).Message.Clean().Contains(todaysdate).ToString();
                    if (ColumnForDate == 4)
                    {
                        if (DateForName == "True")
                            Reports.StatusUpdate("The name: " + Name + " has searched date as " + todaysdate + ".", true);
                        else
                            Reports.StatusUpdate("The name: " + Name + " doesnot have searched date.", true);
                    }
                    if (ColumnForDate == 5)
                    {
                        if (DateForName == "True")
                            Reports.StatusUpdate("The name: " + Name + " has Hit date as " + todaysdate + ".", true);
                        else
                            Reports.StatusUpdate("The name: " + Name + " doesnot have Hit date.", true);
                    }
                    if (ColumnForDate == 9)
                    {
                        if (DateForName == "True")
                            Reports.StatusUpdate("The name: " + Name + " has No Hit date as " + todaysdate + ".", true);
                        else
                            Reports.StatusUpdate("The name: " + Name + " doesnot have No Hit date.", true);
                    }
                    break;
                }
                else
                {
                    if (i == Count)
                        Reports.StatusUpdate("The name: " + Name + " doesnot appear in the table " + TableName + ".", true);
                }
            }
        }

        public void ValidateRolesAreAlphabeticallyOrdered(IWebElement TableName)
        {
            List<string> Roles = new List<string>();
            List<string> Names = new List<string>();
            List<string> SortedRoles = new List<string>();

            int Count = TableName.GetRowCount();
            for (int i = 1; i < Count; i++)
            {
                string Coulmn1Value = Convert.ToString(i);
                string RoleName = TableName.PerformTableAction(1, Coulmn1Value, 3, TableAction.GetText).Message.ToString();
                Roles.Add(RoleName);
            }
            SortedRoles = Roles;
            SortedRoles.Sort();
            for (int j = 0; j <= Count - 1; j++)
            {
                if (SortedRoles[j] == Roles[j])
                {
                    if (j == Count - 2)
                    {
                        Reports.StatusUpdate("The Roles are in Sorted order in the table: " + TableName + ".", true);
                        break;
                    }
                }
                else
                {
                    Reports.StatusUpdate("The Roles are not in Sorted order in the table: " + TableName + ".", false);
                }
            }
        }

        public void ValidateAlphabeticalOrderOfNamesForParticularRole(IWebElement TableName, string RoleName)
        {
            List<string> Names = new List<string>();
            List<string> SortedNames = new List<string>();

            int Count = TableName.GetRowCount();
            for (int i = 1; i < Count; i++)
            {
                string Coulmn1Value = Convert.ToString(i);
                string Role = TableName.PerformTableAction(1, Coulmn1Value, 3, TableAction.GetText).Message.ToString();
                if (Role.Contains(RoleName))
                {
                    string Name = TableName.PerformTableAction(1, Coulmn1Value, 2, TableAction.GetText).Message.ToString();
                    Names.Add(Name);
                }
            }
            SortedNames = Names;
            SortedNames.Sort();
            for (int j = 0; j <= Count - 1; j++)
            {
                if (SortedNames[j] == Names[j])
                {
                    if (j == Count - 2)
                    {
                        Reports.StatusUpdate("The Names are in Sorted order for the Role " + RoleName + " in the table: " + TableName + ".", true);
                        break;
                    }
                }
                else
                {
                    Reports.StatusUpdate("The Names are not in Sorted order for the Role " + RoleName + " in the table: " + TableName + ".", true);
                }
            }
        }

        public void ValidateEachInstanceOfRoles(IWebElement TableName)
        {
            List<string> Roles = new List<string>();

            int Count = TableName.GetRowCount();
            int k = 0;
            for (int i = 1; i < Count; i++)
            {
                string Coulmn1Value = Convert.ToString(i);
                string RoleName = TableName.PerformTableAction(1, Coulmn1Value, 3, TableAction.GetText).Message.ToString();
                Roles.Add(RoleName);
            }

            for (int j = 1; j < Count; j++)
            {
                int CountOfInstnace = 0;
                for (k = 0; k < Count - 1; k++)
                {
                    //string Coulmn1Value = Convert.ToString(j);
                    // string Name = TableName.PerformTableAction(1, Coulmn1Value, 3, TableAction.GetText).Message.ToString();
                    if (TableName.PerformTableAction(1, j.ToString(), 3, TableAction.GetText).Message.ToString().Contains(Roles[k]).ToString() == "True")
                    {
                        CountOfInstnace = CountOfInstnace + 1;
                    }
                }
                if (CountOfInstnace == 1)
                    Reports.StatusUpdate("Unique Instance of Role / Association is displayed for the name: " + TableName.PerformTableAction(1, j.ToString(), 3, TableAction.GetText).Message.ToString() + ".", true);
                else
                    Reports.StatusUpdate("Duplicate Instance of Role / Association is displayed.", false);
            }

        }

        public void WaitForSDNPrcoessComplete(IWebElement TableName, string Name, int ColumnForDate)
        {
            FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();

            string todaysdate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.Now, TimeZoneInfo.Local.Id, "Pacific Standard Time").ToString("MM/dd/yyyy");
            int Count = TableName.GetRowCount();
            for (int i = 1; i <= Count; i++)
            {
                if (TableName.PerformTableAction(2, Name, i, TableAction.GetText).Message.Clean().Contains(Name).ToString() == "True")
                {
                    break;
                }
                else
                {
                    i = i + 5;
                    Playback.Wait(5000);
                    FastDriver.LeftNavigation.Navigate<SDNTrackingSummary>(@"Home>Order Entry>SDN Tracking Summary").WaitForScreenToLoad();
                }
            }

        }
    }
}

