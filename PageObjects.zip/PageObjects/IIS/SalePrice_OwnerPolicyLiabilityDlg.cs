﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
   public class SalePrice_OwnerPolicyLiabilityDlg : PageObject
   {
       #region Webelements
       [FindsBy(How = How.Id, Using = "frmOwnerLiability")]
       public IWebElement SP_OPL_Dlg_Frame { get; set; }

       [FindsBy(How = How.Id, Using = "txtFirstSP")]
       public IWebElement FirstSalePriceDesc { get; set; }

       [FindsBy(How = How.Id, Using = "txtSecondSP")]
       public IWebElement SecondSalePriceDesc { get; set; }
     
       [FindsBy(How = How.Id, Using = "txtThirdSP")]
       public IWebElement ThirdSalePriceDesc { get; set; }
       
       [FindsBy(How = How.Id, Using = "txtFourthSP")]
       public IWebElement FourthSalePriceDesc { get; set; }
       
       [FindsBy(How = How.Id, Using = "txtFifthSP")]
       public IWebElement FifthSalePriceDesc { get; set; }

       [FindsBy(How = How.Id, Using = "txtTotalSP")]
       public IWebElement TotalSalePrice { get; set; }

       [FindsBy(How = How.Id, Using = "txtFirstSPAmt")]
       public IWebElement FirstSalePriceAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtSecondSPAmt")]
       public IWebElement SecondSalePriceAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtThirdSPAmt")]
       public IWebElement ThirdSalePriceAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtFourthSPAmt")]
       public IWebElement FourthSalePriceAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtFifthSPAmt")]
       public IWebElement FifthSalePriceAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtSecondLiabilityAmount")]
       public IWebElement SecondLiabilityAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtThirdLiabilityAmount")]
       public IWebElement ThirdLiabilityAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtFourthLiabilityAmount")]
       public IWebElement FourthLiabilityAmount { get; set; }

       [FindsBy(How = How.Id, Using = "txtFifthLiabilityAmount")]
       public IWebElement FifthLiabilityAmount { get; set; }
       

       #endregion

       public SalePrice_OwnerPolicyLiabilityDlg WaitForScreenToLoad()
       {
           FastDriver.WebDriver.WaitForWindowAndSwitch("Sale Price/Owner's Policy Liabilities");           
           this.SwitchToDialogContentFrame();
           this.WaitCreation(SP_OPL_Dlg_Frame);
           return this;
       }
   }
}
