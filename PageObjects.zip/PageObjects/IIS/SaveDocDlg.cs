using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;
using AutoIt;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Drawing;

namespace FASTSelenium.PageObjects.IIS
{
    public class SaveDocumentDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtFileNo")]
        public IWebElement FileNo { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentType")]
        public IWebElement DocumentType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentName")]
        public IWebElement DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "cboWQTriggerNames")]
        public IWebElement WQTriggerNames { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement Ok { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        [FindsBy(How = How.Id, Using = "txtDocumentName")]
        public IWebElement DocumentNameText { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddInformation")]
        public IWebElement AdditionalInfo { get; set; }

        [FindsBy(How = How.Id, Using = "cboSDN")]
        public IWebElement SDNhitNameList { get; set; }

        [FindsBy(How = How.Id, Using = "chkBxFavoriteUpload")]
        public IWebElement FavoriteUploadChk { get; set; }

        

        #endregion

        public SaveDocumentDlg SaveDocument(string docType, string docName, string addtlInfo)
        {
            //WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(DocumentType);
            DocumentType.FASelectItem(docType);
            DocumentName.FASelectItem(docName);
            documentname = DocumentName.FAGetText();
            Keyboard.SendKeys(FAKeys.TabAway);
            AdditionalInfo.FASetText(addtlInfo);
            Keyboard.SendKeys(FAKeys.TabAway);
            Ok.Click();

            return this;
        }

        public SaveDocumentDlg SaveMisDocument(string docType, string docName)
        {
            //WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(DocumentType);
            DocumentType.FASelectItem(docType);
            DocumentNameText.FASetText(docName);
            Keyboard.SendKeys(FAKeys.TabAway);
            Ok.Click();
            return this;
        }

        public SaveDocumentDlg SaveDocumentSendingKeys(string docType, string docName, string addtlInfo)
        {
            Report.UpdateLog(WebDriver, "SendKeys", docType, () =>
            {
                Keyboard.SendKeys(docType);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(1000);
            });
            Report.UpdateLog(WebDriver, "SendKeys", docName, () =>
            {
                Keyboard.SendKeys(docName);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(1000);
            });
            Report.UpdateLog(WebDriver, "SendKeys", addtlInfo, () =>
            {
                Keyboard.SendKeys(addtlInfo);
                Keyboard.SendKeys(FAKeys.TabAway);
                Playback.Wait(1000);
            });
            Report.UpdateLog(WebDriver, "SendKeys", "{ENTER}", () =>
            {
                Keyboard.SendKeys("{ENTER}");
                Playback.Wait(1000);
            });

            return this;
        }

        public static string documentname;
        public SaveDocumentDlg SaveDocumentUsingAutoIt(string docType, string docName, string addtlInfo, string imageTrigger = null, string docName_ = null)
        {

            AutoItX.WinWait("Save Document", "", 20);
            AutoItX.WinActivate("Save Document");
            

            Report.UpdateLog(WebDriver, "Select Document Type", docType, () =>
            {
                AutoItX.ControlCommand("Save Document", "", "[CLASS:ThunderRT6ComboBox;INSTANCE:5]", "SelectString", docType);
            });
            Report.UpdateLog(WebDriver, "Select Document Name", docName, () =>
            {
                AutoItX.ControlCommand("Save Document", "", "[CLASS:ThunderRT6ComboBox;INSTANCE:4]", "SelectString", docName);
            });
            Report.UpdateLog(WebDriver, "Additional Info", addtlInfo, () =>
            {
                AutoItX.ControlSetText("Save Document", "", "[CLASS:ThunderRT6TextBox;INSTANCE:2]", addtlInfo);
            });
            if (imageTrigger != null)
            {
                Report.UpdateLog(WebDriver, "Select Image Trigger", imageTrigger, () =>
                {
                    AutoItX.ControlCommand("Save Document", "", "[CLASS:ThunderRT6ComboBox;INSTANCE:2]", "SelectString", imageTrigger);
                });
            }
            if (docName_ != null)
            {
                Report.UpdateLog(WebDriver, "Insert Document Name", docName_, () =>
                {
                    AutoItX.ControlSetText("Save Document", "", "[CLASS:ThunderRT6ComboBox;INSTANCE:2]", imageTrigger);
                });
            }
            Playback.Wait(10000);                                                   //Increasing wait time to avoid inconsistancy
            Report.UpdateLog(WebDriver, "Button", "OK", () =>
            {
                AutoItX.ControlEnable("Save Document", "", "[CLASS:ThunderRT6CommandButton;Text:OK]");
                Playback.Wait(20000);
                AutoItX.ControlClick("Save Document", "", "[CLASS:ThunderRT6CommandButton;Text:OK]");
            });

            //AutoItX.WinWaitClose("Save Document", "", 5);

            return this;
        }

        #region SaveDocument using CodedUI
        public SaveDocumentDlg SaveDocumentUsingCodedUI(string DocType, string DocName, string addtlInfo, string ImgTrigger = null, string Mode = "add")
        {
                WinWindow saveWindow = new WinWindow();
                saveWindow.SearchProperties.Add(WinWindow.PropertyNames.ClassName, "ThunderRT6FormDC", WinWindow.PropertyNames.Name, "Save Document");
                saveWindow.WindowTitles.Add("Save Document");
                saveWindow.SetFocus();

                WinWindow DocTypeWindow = new WinWindow(saveWindow);
                DocTypeWindow.SearchProperties.Add(WinWindow.PropertyNames.ControlId, "10");
                DocTypeWindow.WindowTitles.Add("Save Document");

                WinComboBox DocumentType = new WinComboBox(DocTypeWindow);
                DocumentType.WindowTitles.Add("Save Document");

                WinWindow DocNameWindow = new WinWindow(saveWindow);
                DocNameWindow.SearchProperties.Add(WinWindow.PropertyNames.ControlId, "12");
                DocNameWindow.WindowTitles.Add("Save Document");
                WinEdit DocumentName = new WinEdit(DocNameWindow);
                DocumentName.WindowTitles.Add("Save Document");

                WinWindow DocNameselWindow = new WinWindow(saveWindow);
                DocNameselWindow.SearchProperties.Add(WinWindow.PropertyNames.ControlId, "9");
                DocNameselWindow.WindowTitles.Add("Save Document");
                WinComboBox DocumentName1 = new WinComboBox(DocNameselWindow);
                DocumentName1.WindowTitles.Add("Save Document");

                WinWindow AddinfoselWindow = new WinWindow(saveWindow);
                AddinfoselWindow.SearchProperties.Add(WinWindow.PropertyNames.ControlId, "11");
                AddinfoselWindow.WindowTitles.Add("Save Document");
                WinEdit Addinfo = new WinEdit(AddinfoselWindow);
                AddinfoselWindow.WindowTitles.Add("Save Document");

                WinWindow TriggerWindow = new WinWindow(saveWindow);
                TriggerWindow.SearchProperties.Add(WinWindow.PropertyNames.ControlId, "3");
                TriggerWindow.WindowTitles.Add("Save Document");
                WinComboBox ImageTrigger = new WinComboBox(TriggerWindow);
                ImageTrigger.WindowTitles.Add("Save Document");

                WinWindow OKWindow = new WinWindow(saveWindow);
                OKWindow.SearchProperties.Add(WinWindow.PropertyNames.ControlId, "6");
                OKWindow.WindowTitles.Add("Save Document");
                WinButton OK = new WinButton(OKWindow);
                OK.SearchProperties.Add(WinButton.PropertyNames.Name, "OK");

                if (Mode.ToLower() == "add")
                    DocumentType.SelectedItem = DocType;

                if (DocType == "Miscellaneous")
                    DocumentName.Text = DocName;
                else
                    DocumentName1.SelectedItem = DocName;

                Addinfo.Text = addtlInfo;

                if (Mode.ToLower() == "add")
                    if (ImgTrigger == "")
                        ImageTrigger.SelectedItem = "AFFIX INV";
                    else
                        ImageTrigger.SelectedItem = ImgTrigger;
                else
                    if (ImgTrigger != "")
                        ImageTrigger.SelectedItem = ImgTrigger;

                Mouse.Click(OK, new Point(25, 17));

                return this;
        }
        #endregion SaveDocument using CodedUI

        public SaveDocumentDlg SaveEditImageUsingAutoIt()
        {

            AutoItX.WinWait("Save Document", "", 5);
            AutoItX.WinActivate("Save Document");

            Report.UpdateLog(WebDriver, "Button", "OK", () =>
            {
                AutoItX.ControlClick("Save Document", "", "[CLASS:ThunderRT6CommandButton;Text:OK]");
            });

            AutoItX.WinWaitClose("Save Document", "", 5);

            return this;
        }

        public SaveDocumentDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? FileNo);
            return this;
        }

        public SaveDocumentDlg WaitAndSwitchToWindow(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Save Document", true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? FileNo);
            return this;
        }

        public SaveDocumentDlg SaveWireDocument(string docType, string docName, string imgTrigName)
        {
            WaitForScreenToLoad();
            DocumentType.FASelectItem(docType);
            DocumentName.FASelectItem(docName);
            WQTriggerNames.FASelectItem(imgTrigName);
            Ok.FAClick();
            return this;
        }

        public SaveDocumentDlg SaveSDNClearanceDoc(string docType, string docName, int hitName)
        {
            WaitForScreenToLoad().DocumentType.FASelectItem(docType);
            DocumentName.FASelectItem(docName);
            SDNhitNameList.FASelectItemByIndex(hitName);
            Ok.FAClick();
            return this;
        }

    }
}
