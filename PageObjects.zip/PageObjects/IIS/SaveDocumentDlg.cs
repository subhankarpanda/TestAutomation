using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SaveDocument : PageObject
	{
		#region WebElements

        [FindsBy(How = How.Id, Using = "cboDocumentType")]
		public IWebElement DocumentType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentName")]
        public IWebElement DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddInformation")]
        public IWebElement AdditionalInfo { get; set; }

        [FindsBy(How = How.Id, Using = "cboWQTriggerNames")]
        public IWebElement ImageTrigger { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

		#endregion

        public SaveDocument WaitForScreenToLoad()
        {
            WebDriver.WaitForWindowAndSwitch("Save Document", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(DocumentType);
            return this;
        }
	}

    public class SaveDocumentNonActiveX : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "txtFileNo")]
        public IWebElement FileNo { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentType")]
        public IWebElement DocumentType { get; set; }

        [FindsBy(How = How.Id, Using = "cboDocumentName")]
        public IWebElement DocumentName { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddInformation")]
        public IWebElement AdditionalInfo { get; set; }

        [FindsBy(How = How.Id, Using = "txtDocumentName")]
        public IWebElement DocumentName2 { get; set; }

        [FindsBy(How = How.Id, Using = "cboWQTriggerNames")]
        public IWebElement ImageTrigger { get; set; }

        [FindsBy(How = How.Id, Using = "txtComments")]
        public IWebElement Comments { get; set; }

        [FindsBy(How = How.Id, Using = "btnOK")]
        public IWebElement OK { get; set; }

        [FindsBy(How = How.Id, Using = "btnCancel")]
        public IWebElement Cancel { get; set; }

        #endregion

        public SaveDocumentNonActiveX WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToImageWorkbenchFrame();
            this.WaitForFrameAndSwitchByFrameId("saveDocumentFrame");
            this.WaitCreation(element ?? DocumentType);
            return this;
        }

        public SaveDocumentNonActiveX SaveDocument(string docType = "", string docName = "", string addtlInfo = "", string imageTrigger = "", string docName2 = "")
        {
            this.WaitForScreenToLoad();

            if (docType != "")
                this.DocumentType.FASelectItem(docType);

            if (docName != "")
                this.DocumentName.FASelectItem(docName);

            if (addtlInfo != "")
                this.AdditionalInfo.FASetText(addtlInfo);

            if (imageTrigger != "")
                this.ImageTrigger.FASelectItem(imageTrigger);

            if (docName2 != "")
                this.DocumentName2.FASetText(docName2);

            this.OK.FAClick();

            return this;
        }
    }
}
