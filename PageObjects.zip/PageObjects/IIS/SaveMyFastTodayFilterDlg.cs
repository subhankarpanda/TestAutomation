using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SaveMyFastTodayFilterDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkPrimaryFilter")]
		public IWebElement PrimaryFilter { get; set; }

		[FindsBy(How = How.Id, Using = "txtFilterName")]
		public IWebElement FilterName { get; set; }

		[FindsBy(How = How.Id, Using = "btnSave")]
		public IWebElement Save { get; set; }

		[FindsBy(How = How.Id, Using = "btnCancel")]
		public IWebElement Cancel { get; set; }

        #endregion

        public SaveMyFastTodayFilterDlg WaitForScreenToLoad()
        {
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(Save);

            return this;
        }

    }
}
