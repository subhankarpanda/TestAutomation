using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SearchApprovedAttorneyDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "txtSearchName")]
		public IWebElement SearchName { get; set; }

		[FindsBy(How = How.Id, Using = "txtSearchCity")]
		public IWebElement SearchCity { get; set; }

		[FindsBy(How = How.Id, Using = "cboState")]
		public IWebElement cboState { get; set; }

		[FindsBy(How = How.Id, Using = "Button1")]
		public IWebElement Search { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSearchType_dgridSearchType")]
		public IWebElement Table { get; set; }

        #endregion

        public SearchApprovedAttorneyDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? Search);
            return this;
        }

    }
}
