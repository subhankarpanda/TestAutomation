using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
	public class SearchPageDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "optSearch_0")]
		public IWebElement GlobalAddressBook { get; set; }

		[FindsBy(How = How.Id, Using = "optSearch_1")]
		public IWebElement FileAddressBook { get; set; }

		[FindsBy(How = How.Id, Using = "optSearch_2")]
		public IWebElement EmployeeSearchAddressBook { get; set; }

		[FindsBy(How = How.Id, Using = "txtEntityName")]
		public IWebElement EntityName { get; set; }

		[FindsBy(How = How.Id, Using = "BtnFindNow")]
		public IWebElement FindNow { get; set; }

		[FindsBy(How = How.Id, Using = "ddlEntityType")]
		public IWebElement EntityType { get; set; }

		[FindsBy(How = How.Id, Using = "BtnNewSearch")]
		public IWebElement NewSearch { get; set; }

		[FindsBy(How = How.Id, Using = "txtfirstName")]
		public IWebElement firstName { get; set; }

		[FindsBy(How = How.Id, Using = "BtnCancel")]
		public IWebElement Cancel { get; set; }

		[FindsBy(How = How.Id, Using = "txtLastName")]
		public IWebElement LastName { get; set; }

		[FindsBy(How = How.Id, Using = "Btnfinished")]
		public IWebElement Finished { get; set; }

		[FindsBy(How = How.Id, Using = "grdTitleAndEscrowResults_0_chkSelect")]
		public IWebElement SelectCheckBox { get; set; }

		[FindsBy(How = How.Name, Using = "grdSearchResults")]
		public IWebElement SearchResults { get; set; }

		[FindsBy(How = How.Name, Using = "grdTitleAndEscrowResults")]
		public IWebElement TitleEscrowOfficerTable { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_0_optSelect")]
		public IWebElement SearchResultRadioButton { get; set; }

		[FindsBy(How = How.Id, Using = "optSearch_3")]
		public IWebElement Office { get; set; }

		[FindsBy(How = How.Id, Using = "optSearch_4")]
		public IWebElement ElectronicDeliveryGroup { get; set; }

		[FindsBy(How = How.Id, Using = "ddlRegion")]
		public IWebElement Region { get; set; }

		[FindsBy(How = How.Id, Using = "grdSearchResults_0_chkSelect")]
		public IWebElement SelectSearchResult { get; set; }

        [FindsBy(How = How.Id, Using = "grdSearchResults")]
        public IWebElement SearchResult { get; set; }

        [FindsBy(How = How.Name, Using = "grdSalesRep")]
        public IWebElement SalesRepTable { get; set; }

        #endregion
        public SearchPageDlg WaitForDialogToLoad(int timeout = 10, IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Search Page", timeoutSeconds: timeout);
            this.SwitchToDialogContentFrame(switchToFraPageWin: false);
            this.WaitCreation(element ?? FindNow);

            return this;
        }
        public SearchPageDlg WaitCreation()
        {
            this.WaitCreation(SelectSearchResult);
            return this;
        }
       
        public SearchPageDlg WaitForScreenToLoad(int timeout = 10)
        {
            return WaitForDialogToLoad(timeout);
        }

        public SearchPageDlg WaitForResultsToLoad()
        {
            FastDriver.WebDriver.HandleDialogMessage();
            WaitForDialogToLoad();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
            WaitForDialogToLoad();
            return this;
        }
    }
}
