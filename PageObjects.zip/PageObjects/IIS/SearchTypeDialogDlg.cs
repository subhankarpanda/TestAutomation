using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SearchTypeDialogDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSearchType_0_radSelSearchType")]
		public IWebElement SelectionRadioButton { get; set; }

        [FindsBy(How = How.Id, Using = "dgridSearchType_dgridSearchType")]
		public IWebElement SearchTypeTable { get; set; }

        
		#endregion

        public SearchTypeDialogDlg WaitForScreenToLoad(string windowName = "Search Type Dialog")
        {
            WebDriver.WaitForWindowAndSwitch(windowName, true, 10);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(SearchTypeTable);

            return this;
        }
	}
}
