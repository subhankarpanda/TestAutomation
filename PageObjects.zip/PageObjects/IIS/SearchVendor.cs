using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SearchVendor : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "bpB_cmdCheckDetails")]
		public IWebElement CheckDetails { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_txtGABcode")]
		public IWebElement GABcode { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_cmdFindName")]
		public IWebElement Find { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_txtName")]
		public IWebElement Name { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_chkEditContactInfo")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textBusPhone")]
		public IWebElement BusinessPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_txtExtnPhone")]
		public IWebElement BusinessPhoneExtension { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textBusFax")]
		public IWebElement BusinessFax { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textCellPhone")]
		public IWebElement CellPhone { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textPager")]
		public IWebElement Pager { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textEmailAddress")]
		public IWebElement EmailAddress { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_chkWeeklyEmailStatus")]
		public IWebElement StatusEmail { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_comboAttention")]
		public IWebElement Attention { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_chkEdit")]
		public IWebElement EditName { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textName")]
		public IWebElement NameEdit { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_comboSalesRep1")]
		public IWebElement SalesRep1 { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_comboSalesRep2")]
		public IWebElement SalesRep2 { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_textReference")]
		public IWebElement Reference { get; set; }

		[FindsBy(How = How.Id, Using = "txtConfirmDate")]
		public IWebElement VenderDetailsConfirmDate { get; set; }

		[FindsBy(How = How.Id, Using = "ddlProdProcess")]
		public IWebElement VenderDetailsProductionProcess { get; set; }

		[FindsBy(How = How.Id, Using = "txtCost")]
		public IWebElement VenderDetailsCost { get; set; }

		[FindsBy(How = How.Id, Using = "btnSaveComments")]
		public IWebElement CommentsSave { get; set; }

		[FindsBy(How = How.Id, Using = "txtComments")]
		public IWebElement Comments { get; set; }

		[FindsBy(How = How.Id, Using = "btnAdd")]
		public IWebElement ProblemLogAddRemove { get; set; }

		[FindsBy(How = How.Id, Using = "dgridProbLog_dgridProbLog")]
		public IWebElement ProblemLogTable { get; set; }

		[FindsBy(How = How.Id, Using = "bpB_lblGrade")]
		public IWebElement VendorGrade { get; set; }

		[FindsBy(How = How.Name, Using = "dgridComments_dgridComments")]
		public IWebElement CommentsTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "11-12-2012")]
		public IWebElement CommentsDate { get; set; }

		[FindsBy(How = How.Id, Using = "dgridComments_0_lblDate")]
		public IWebElement CommentsDate1 { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelName")]
        public IWebElement GABNameLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelIdcode")]
        public IWebElement GABIDCodeLabel { get; set; }

        [FindsBy(How = How.Id, Using = "bpB_labelContactName")]
        public IWebElement ContactName { get; set; }

        #endregion

        public SearchVendor WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? GABcode);

            return this;
        }

        public bool WaitForElement(IWebElement element = null)
        {
            try
            {
                this.SwitchToContentFrame();
                this.WaitCreation(element ?? GABcode);

                return true;
            }
            catch
            { return false; }
        }

        public SearchVendor FindGAB(string gab = "boa")
        {
            this.SwitchToContentFrame();
            GABcode.FASetText(gab + FAKeys.Tab);
            Find.FAClick();

            return this;
        }

	}
}
