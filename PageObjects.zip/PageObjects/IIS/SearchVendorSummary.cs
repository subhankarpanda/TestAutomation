using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SearchVendorSummary : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "cmdNew")]
		public IWebElement New { get; set; }

		[FindsBy(How = How.Id, Using = "cmdEdit")]
		public IWebElement Edit { get; set; }

		[FindsBy(How = How.Id, Using = "cmdDel")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "spnTitle")]
		public IWebElement _SearchVendorSummary { get; set; }

		[FindsBy(How = How.Id, Using = "grdVendorSummary")]
		public IWebElement SearchVendorSummaryTable { get; set; }

		#endregion

        public SearchVendorSummary WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? New);

            return this;
        }

	}
}
