using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SelectBusinessProgramsDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "dgridSelBP_0_chkSelBP")]
		public IWebElement BPCheckBox1 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_1_chkSelBP")]
		public IWebElement BPCheckBox2 { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelBP_dgridSelBP")]
		public IWebElement BPTable { get; set; }

		[FindsBy(How = How.Id, Using = "btnSelect")]
		public IWebElement Select { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_0_chkSelect")]
		public IWebElement Select1 { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_1_chkSelect")]
		public IWebElement Select2 { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_2_chkSelect")]
		public IWebElement Select3 { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_3_chkSelect")]
		public IWebElement Select4 { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_4_chkSelect")]
		public IWebElement Select5 { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_5_chkSelect")]
		public IWebElement Select6 { get; set; }

		[FindsBy(How = How.Id, Using = "grdMultiSelect_grdMultiSelect")]
		public IWebElement FilterTable { get; set; }

		#endregion

        public SelectBusinessProgramsDlg WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? this.BPCheckBox1);

            return this;
        }

        public SelectBusinessProgramsDlg SelectAllBusinessPrograms()
        {
            for (int i = 1; i < BPTable.GetRowCount(); i++)
            {
                BPTable.PerformTableAction(i, 1, TableAction.On);
            }

            return this;
        }

	}
}
