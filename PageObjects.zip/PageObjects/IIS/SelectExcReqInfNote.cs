using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SelectExcReqInfNote : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "chkSelectAllPhrase")]
		public IWebElement SelectAllPhrase { get; set; }

		[FindsBy(How = How.Id, Using = "dGridSelectedPhrase_0_chkSelectedPhrase")]
		public IWebElement dGridSelec0SelectedPhrase { get; set; }

        [FindsBy(How = How.Id, Using = "blkcpySelAll")]
        public IWebElement SelectAll_temp { get; set; }

        [FindsBy(How = How.XPath, Using = "//div/span[text()='Select Exceptions/Requirements/Informational Notes/Endorsements']/ancestor::div[2]//div/button/span[text()='Done']")]
        public IWebElement Bottom_Done { get; set; }

		#endregion

	}
}
