using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SelectFeeDlg : PageObject
	{
		#region WebElements

		[FindsBy(How = How.Id, Using = "grdServiceFileFee_0_optFeeSelect")]
		public IWebElement Sel { get; set; }

		[FindsBy(How = How.Id, Using = "grdServiceFileFee_grdServiceFileFee")]
		public IWebElement SelectFee { get; set; }

		#endregion

        public SelectFeeDlg WaitForScreenToLoad(IWebElement element = null)
        {
            WebDriver.WaitForWindowAndSwitch("Select Fee", true, 20);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(element ?? SelectFee);
            return this;
        }
	}
}
