using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
    public class SelectIBABankDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "optIBABank_0")]
        public IWebElement SelectAutomatedBankAccount { get; set; }

        [FindsBy(How = How.Id, Using = "optIBABank_1")]
        public IWebElement EnterRoutingNoForNonAutomatedBankAccount { get; set; }

        [FindsBy(How = How.Id, Using = "comboIBABanks")]
        public IWebElement IBABanks { get; set; }

        [FindsBy(How = How.Id, Using = "txtRoutingNo")]
        public IWebElement RoutingNumber { get; set; }

        #endregion

        public SelectIBABankDlg WaitForScreenToLoad(IWebElement element = null)
        {
            //WebDriver.WaitForWindowAndSwitch("Select IBA Bank", true, 10);
            this.SwitchToDialogContentFrame(switchToFraPageWin: true);
            this.WaitCreation(element ?? IBABanks);
            return this;
        }

        public void SelectAutomatedBank(string bankName)
        {
            this.SelectAutomatedBankAccount.FAClick();
            this.IBABanks.FASelectItem(bankName);
        }
    }
}
