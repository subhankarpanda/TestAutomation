using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;
using FASTSelenium.DataObjects.IIS;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;

namespace FASTSelenium.PageObjects.IIS
{
    public class SelectIBABeneficiaryDlg : PageObject
    {
        #region WebElements

        [FindsBy(How = How.Id, Using = "dGridBuyersResults")]
        public IWebElement SummaryTable { get; set; }

        [FindsBy(How = How.Id, Using = "dGridBuyersResults_0_optBuyerSelect")]
        public IWebElement BuyerSelect { get; set; }

        [FindsBy(How = How.Id, Using = "dGridBuyersResults_1_optBuyerSelect")]
        public IWebElement BuyerSelect1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridBuyersResults_2_optBuyerSelect")]
        public IWebElement BuyerSelect2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridBuyersResults_3_optBuyerSelect")]
        public IWebElement BuyerSelect3 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridBuyersResults_4_optBuyerSelect")]
        public IWebElement BuyerSelect4 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSellersResults_0_optSellerSelect")]
        public IWebElement SellerSelect { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSellersResults_1_optSellerSelect")]
        public IWebElement SellerSelect1 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSellersResults_2_optSellerSelect")]
        public IWebElement SellerSelect2 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSellersResults_3_optSellerSelect")]
        public IWebElement SellerSelect3 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSellersResults_4_optSellerSelect")]
        public IWebElement SellerSelect4 { get; set; }

        [FindsBy(How = How.Id, Using = "dGridSellersResults")]
        public IWebElement SellersTable { get; set; }

        [FindsBy(How = How.Id, Using = "optOthers")]
        public IWebElement OthersSelect { get; set; }

        [FindsBy(How = How.Id, Using = "txtName")]
        public IWebElement OtherName { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddrLn1")]
        public IWebElement OtherAddressLine1 { get; set; }

        [FindsBy(How = How.Id, Using = "txtAddrLn2")]
        public IWebElement OtherAddressLine2 { get; set; }

        [FindsBy(How = How.Id, Using = "txtCity")]
        public IWebElement OtherCity { get; set; }

        [FindsBy(How = How.Id, Using = "cboState")]
        public IWebElement OtherState { get; set; }

        [FindsBy(How = How.Id, Using = "txtZip")]
        public IWebElement OtherZip { get; set; }

        [FindsBy(How = How.Id, Using = "optSSN")]
        public IWebElement SSNRadio { get; set; }

        [FindsBy(How = How.Id, Using = "optTIN")]
        public IWebElement TINRadio { get; set; }

        [FindsBy(How = How.Id, Using = "txtSSNTIN")]
        public IWebElement SSNTINNumber { get; set; }

        [FindsBy(How = How.Id, Using = "optPerson")]
        public IWebElement PersonOther { get; set; }

        [FindsBy(How = How.Id, Using = "optBusiness")]
        public IWebElement BusinessOther { get; set; }

        #endregion

        public SelectIBABeneficiaryDlg WaitForScreenToLoad(int timeout = 10)
        {
            WebDriver.WaitForWindowAndSwitch("Select IBA Beneficiary", true, timeout);
            this.SwitchToDialogContentFrame();
            this.WaitCreation(OthersSelect);
            return this;
        }

        public SelectIBABeneficiaryDlg PerformTableOperation(int columnToSearchIndex, string searchValue, int actionCellIndex, TableAction action, string value = "", int StartingRowNum = 1)
        {
            try
            {
                this.WaitCreation(SummaryTable);
                SummaryTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);
                return this;
            }
            catch (StaleElementReferenceException) //Try again if get stale element reference exception
            {

                this.WaitCreation(SummaryTable);
                SummaryTable.PerformTableAction(columnToSearchIndex, searchValue, actionCellIndex, action, value, StartingRowNum);
                return this;
            }
        }

        /// <summary>
        /// This function adds the other beneficiary details.
        /// </summary>
        /// <param name="Beneficiary"></param>
        public void AddOtherBeneficiary(IBABeneficiary Beneficiary)
        {
            Reports.TestStep = "Add the other Beneficiary details.";
            this.WaitForScreenToLoad();
            this.OthersSelect.FAClick();
            this.OtherName.FASetText(Beneficiary.BeneficiaryName);
            this.OtherAddressLine1.FASetText(Beneficiary.AddressLine1);
            this.OtherAddressLine2.FASetText(Beneficiary.AddressLine2);
            this.OtherCity.FASetText(Beneficiary.City);
            this.OtherState.FASelectItem(Beneficiary.State);
            this.OtherZip.FASetText(Beneficiary.ZipCode);
            if (Beneficiary.selectSSN.Equals(true))
            {
                this.SSNRadio.FAClick();
                this.SSNTINNumber.FASetText(Beneficiary.SSNTINnumber);
            }
            if (Beneficiary.selectTIN.Equals(true))
            {
                this.TINRadio.FAClick();
                this.SSNTINNumber.FASetText(Beneficiary.SSNTINnumber);
            }
        }

        /// <summary>
        /// Validates input fields
        /// </summary>
        /// <param name=""></param>
        public void ValidateOTHER()
        {
            this.OthersSelect.FAClick();
            //  Name
            this.OtherName.FASetText(@"ABC123@.,/\#-_");
            this.OtherAddressLine1.FAClick();
            Support.AreEqual(@"ABC123.,/#-_", this.OtherName.FAGetValue(), "OTHER Name : String");
            //  Address Line 1
            this.OtherAddressLine1.FASetText(@"ABC123@.,/\#-_");
            this.OtherAddressLine2.FAClick();
            Support.AreEqual(@"ABC123.,/#-_", this.OtherAddressLine1.FAGetValue(), "OTHER Address Line 1 : String");
            //  Address Line 2
            this.OtherAddressLine2.FASetText(@"ABC123@.,/\#-_");
            this.OtherCity.FAClick();
            Support.AreEqual(@"ABC123.,/#-_", this.OtherAddressLine2.FAGetValue(), "OTHER Address Line 2 : String");
            //  City
            this.OtherCity.FASetText(@"ABC123@.,/\#-_");
            this.OtherZip.FAClick();
            Support.AreEqual(@"ABC123.,/#-_", this.OtherCity.FAGetValue(), "OTHER City : String");
            //  Zip
            this.OtherZip.FASetText(@"ABC123@.,/\#-_");
            this.OtherName.FAClick();
            Support.AreEqual("?????-????", this.OtherZip.FAGetValue(), "OTHER Zip : Numeric");
            //  SSN
            this.SSNRadio.FAClick();
            this.SSNTINNumber.FASetText(@"ABC123@.,/\#-_");
            this.OtherName.FAClick();
            Support.AreEqual("???-??-????", this.SSNTINNumber.FAGetValue(), "OTHER SSN : Numeric");
            //  TIN
            this.TINRadio.FAClick();
            this.SSNTINNumber.FASetText(@"ABC123@.,/\#-_");
            this.OtherName.FAClick();
            Support.AreEqual("??-???????", this.SSNTINNumber.FAGetValue(), "OTHER TIN : Numeric");
            //  
            this.BusinessOther.FAClick();
            this.PersonOther.FAClick();
        }
    }
}
