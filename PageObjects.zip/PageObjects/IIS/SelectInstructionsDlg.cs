using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class SelectInstructionsDlg : PageObject
	{
		#region WebElements

        [FindsBy(How = How.XPath, Using = "//button[contains(@onclick,'funCheckAll()')]")]
		public IWebElement CheckAll { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[contains(@onclick,'funClearAll()')]")]
		public IWebElement Clear { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_0_chkSelInst")]
		public IWebElement SelectInstruction { get; set; }

		[FindsBy(How = How.Id, Using = "dgridSelInstructions_dgridSelInstructions")]
		public IWebElement InstructionsTable { get; set; }

		#endregion

        #region Useful Methods
        public SelectInstructionsDlg WaitForScreenLoad()
        {
            this.SwitchToDialogContentFrame();
            this.WaitCreation(InstructionsTable);
            return this;
        }
        #endregion

    }
}
