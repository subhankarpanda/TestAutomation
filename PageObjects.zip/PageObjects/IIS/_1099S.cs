﻿using System;
using System.Threading;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumInternalHelpers;

namespace FASTSelenium.PageObjects.IIS
{
	public class _1099S : PageObject
	{
        public enum _1099SActiveProperty
        {
            PropertyDescription,
            SSNTINT,
            ActiveFirstName,
            ActiveLastName,
            ActiveAddress,
            ActiveCity,
            ActivecboState,
            ActiveZip,
            ForeignCountrySeller,
            ActiveForeignAddress
        }

        #region WebElements

        [FindsBy(How = How.Id, Using = "btnDeliver")]
        public IWebElement Deliver { get; set; }

        [FindsBy(How = How.Id, Using = "cboMethod")]
        public IWebElement Method { get; set; }

		[FindsBy(How = How.Id, Using = "rdoPropertyDescType_0")]
		public IWebElement Address { get; set; }

		[FindsBy(How = How.Id, Using = "rdoPropertyDescType_1")]
		public IWebElement AbbreviatedLegalDescription { get; set; }

		[FindsBy(How = How.Id, Using = "rdoPropertyDescType_2")]
		public IWebElement APN { get; set; }

		[FindsBy(How = How.Id, Using = "txtPropertyDesc")]
		public IWebElement PropertyDescription { get; set; }

        [FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_lblDateCreated")]
        public IWebElement DateCreated { get; set; }

        [FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_lblLastCorrected")]
        public IWebElement DateCorrected { get; set; }

        [FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_lblLastDelivered")]
        public IWebElement DateDelivered { get; set; }

		[FindsBy(How = How.Id, Using = "chkPropConsideration")]
		public IWebElement PropertyConsideration { get; set; }

		[FindsBy(How = How.LinkText, Using = "Active Records")]
		public IWebElement ActiveRecords { get; set; }

		[FindsBy(How = How.LinkText, Using = "Voided Records")]
		public IWebElement VoidedRecords { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_cmdAdhoc")]
		public IWebElement AdHoc { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_cmdVoid")]
		public IWebElement Void { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_cmdDelete")]
		public IWebElement Remove { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_gd1099sItems_0_txtGrossProceedsPerc")]
		public IWebElement GrossProceedPercentage { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_gd1099sItems_0_txtGrossProceeds")]
		public IWebElement GrossProceedDollor { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_gd1099sItems_0_txtBuyerRETaxPerc")]
		public IWebElement BuyerPartofRETAXPercentage { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_gd1099sItems_0_txtBuyerRETax")]
		public IWebElement BuyerPartofRETAXDollor { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_chkForeignCntSeller")]
		public IWebElement ForeignCountrySeller { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_cboPayeeIndicator")]
		public IWebElement PayeeIndicator { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_cboSSNTINType")]
		public IWebElement SSNTINType { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtSSNTIN")]
		public IWebElement SSNTIN { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_chkReadyForExtract")]
		public IWebElement ActiveReadyForExtract { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtFirstName")]
		public IWebElement ActiveFirstName { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtMiddleName")]
		public IWebElement ActiveMiddleName { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtLastName")]
		public IWebElement ActiveLastName { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtShortName")]
		public IWebElement ActiveShortName { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtAddress")]
		public IWebElement ActiveAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtCity")]
		public IWebElement ActiveCity { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_cboState")]
		public IWebElement ActivecboState { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtZip")]
		public IWebElement ActiveZip { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_txtForeignAddress")]
		public IWebElement ActiveForeignAddress { get; set; }

		[FindsBy(How = How.Id, Using = "tab1099s_ctrlEF1099sActive_gd1099sItems_gd1099sItems")]
		public IWebElement RecordSummaryTable { get; set; }

		[FindsBy(How = How.LinkText, Using = "/smsfast/FastNetApp1/images/checkbox.gif")]
		public IWebElement ImageCheckBox { get; set; }

        //TODO: ADD FindsByAttribute
        [FindsBy(How = How.XPath, Using = "//div[@id='pnlDisplay']/table/tbody/tr/td/table")]
        public IWebElement Ten99sSTable { get; set; }

        [FindsBy(How = How.LinkText, Using = "0 0 S1FN S S1LN Sir")]
		public IWebElement SellerORAdhocName { get; set; }

        [FindsByAttribute(How = How.Id, Using = "lblBuyersRETax")]
        public IWebElement BuyersRETaxAmountLabel { get; set; }

        [FindsBy(How = How.Id, Using = "lblSettlementDate")]
        public IWebElement SettlementDate { get; set; }

        #endregion

        public _1099S WaitForScreenToLoad(IWebElement element = null)
        {
            this.SwitchToContentFrame();
            this.WaitCreation(element ?? AdHoc);
            return this;
        }
        public _1099S Open()
        {
            FastDriver.LeftNavigation.Navigate<_1099S>(@"Home>Order Entry>Escrow Closing>1099-S");
            this.WaitForScreenToLoad();
            return this;
        }

        public void SetGrossProceedsDollor(string SellerFullName, string GrossProceedDollor)
        {
            this.WaitForScreenToLoad();
            IWebElement GrossProceedDollorSeller = this.RecordSummaryTable.PerformTableAction(1, SellerFullName, 4, TableAction.GetCell).Element.FindElement(By.TagName("Input"));
            GrossProceedDollorSeller.Click();
            Thread.Sleep(3000);
            FastDriver._1099S.WaitForScreenToLoad();
            GrossProceedDollorSeller.FAClick();
            GrossProceedDollorSeller.FASetText(GrossProceedDollor,false);
        }
        //
        public void SetGrossProceedsDollorAmount(string SellerFullName, string GrossProceedDollor)
        {
            this.WaitForScreenToLoad();
            IWebElement GrossProceedDollorSeller = this.RecordSummaryTable.PerformTableAction(1, SellerFullName, 5, TableAction.GetCell).Element.FindElement(By.TagName("Input"));
            //GrossProceedDollorSeller.Click();
            Thread.Sleep(3000);
            FastDriver._1099S.WaitForScreenToLoad();
           // GrossProceedDollorSeller.FAClick();
            GrossProceedDollorSeller.FASetText(GrossProceedDollor);
        }
        //
        public void Set1099sRecordDetails(string SellerFullName, _1099S page)
        {
            FastDriver._1099S.WaitForScreenToLoad();
            if (!string.IsNullOrEmpty(SellerFullName))
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, SellerFullName, 1, TableAction.Click);
            else
                FastDriver._1099S.RecordSummaryTable.PerformTableAction(1, 1, TableAction.Click);
            Thread.Sleep(2000);
            string Message=FastDriver.WebDriver.HandleDialogMessage();
            //"Settlement Date is earlier than Owning Office’s 1099-S Activity Date.\r\nSale Price is not fully distributed.\r\n"
            Thread.Sleep(3000);
            FastDriver._1099S.WaitForScreenToLoad();
            if (!string.IsNullOrEmpty(SellerFullName))
            {
                FastDriver._1099S.ActiveFirstName.FASetText("AdHocFN");
                FastDriver._1099S.ActiveFirstName.FASetText("AdHocLN");
            }
            FastDriver._1099S.Set1099SActiveProperty(page, _1099S._1099SActiveProperty.ActiveAddress, "Address line 1");
            FastDriver._1099S.Set1099SActiveProperty(page, _1099S._1099SActiveProperty.ActiveCity, "ALAMEDA");
            FastDriver._1099S.Set1099SActiveProperty(page, _1099S._1099SActiveProperty.ActivecboState, "CA");
            FastDriver._1099S.Set1099SActiveProperty(page, _1099S._1099SActiveProperty.ActiveZip, "92707");
        }

        #region Set1099SActiveProperty
        public void Set1099SActiveProperty(_1099S page, _1099SActiveProperty property, string value)
        {
            switch (property)
            {
                case _1099SActiveProperty.PropertyDescription:
                    page.PropertyDescription.FASetText(value);
                    break;
                case _1099SActiveProperty.SSNTINT:
                    page.SSNTIN.FASetText(value);
                    break;
                case _1099SActiveProperty.ActiveFirstName:
                    page.ActiveFirstName.FASetText(value);
                    break;
                case _1099SActiveProperty.ActiveLastName:
                    page.ActiveLastName.FASetText(value);
                    break;
                case _1099SActiveProperty.ActiveAddress:
                    page.ActiveAddress.FASetText(value);
                    break;
                case _1099SActiveProperty.ActiveCity:
                    page.ActiveCity.FASetText(value);
                    break;
                case _1099SActiveProperty.ActivecboState:
                    if (value == "")
                    {
                        page.ActivecboState.FASelectItemByIndex(0);
                    }
                    else
                    {
                        page.ActivecboState.FASelectItemBySendingKeys(value);
                    }
                    break;
                case _1099SActiveProperty.ActiveZip:
                    page.ActiveZip.FASetText(value);
                    break;
                case _1099SActiveProperty.ForeignCountrySeller:
                    page.ForeignCountrySeller.FAClick();
                    break;
                case _1099SActiveProperty.ActiveForeignAddress:
                    page.ActiveForeignAddress.FASetText(value);
                    break;
            }
        }
        #endregion

        public void CreateAdHoc(string GrossProceedDollor)
        {
            this.WaitForScreenToLoad();
            this.GrossProceedDollor.FASetText(GrossProceedDollor);
            this.SSNTIN.FASetText("123456789");
            this.ActiveFirstName.FASetText("Ad-HOC First Name");
            this.ActiveMiddleName.FASetText("A");
            this.ActiveLastName.FASetText("ADHOC- LAST Name");
            this.ActiveAddress.FASetText("AD-HOC Address");
            this.ActiveCity.FASetText("Santa ana");
            this.ActivecboState.FASelectItem("CA");
            this.ActiveZip.FASetText("12345");
            FastDriver.BottomFrame.Save();
        }
    }
}
